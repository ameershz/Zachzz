package com.example.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

@SuppressLint("ViewConstructor")
class InPlaceOverlayLayout(
    context: Context,
    private val windowManager: WindowManager,
    private val onDismissCallback: () -> Unit
) : FrameLayout(context) {

    private var isAttached = false
    private val blockViews = mutableListOf<View>()
    private var topControlBar: View? = null

    init {
        // Container setup
        setBackgroundColor(Color.parseColor("#15000000")) // Extremely subtle scrim for contrast
        isClickable = true
        isFocusable = false

        // Tap empty background to dismiss
        setOnClickListener {
            dismiss()
        }
    }

    @SuppressLint("SetTextI18n")
    fun show(
        blocks: List<InPlaceTranslatedBlock>,
        onOpenDetailCard: (String, String) -> Unit,
        onCopyAll: () -> Unit
    ) {
        clearBlocks()

        val displayMetrics = context.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels

        // 1. Create In-Place Translated Badges for each bounding box
        for ((index, block) in blocks.withIndex()) {
            val box = block.boundingBox

            // Clamp coordinates to screen bounds
            val left = box.left.coerceIn(8, screenWidth - 60)
            val top = box.top.coerceIn(dpToPx(60), screenHeight - 50)
            val width = box.width().coerceAtLeast(dpToPx(70)).coerceAtMost(screenWidth - left - 8)
            val height = box.height().coerceAtLeast(dpToPx(32)).coerceAtMost(screenHeight - top - 8)

            val badgeView = createTranslatedBadge(
                block = block,
                badgeWidth = width,
                badgeHeight = height
            )

            val params = LayoutParams(width, height).apply {
                this.leftMargin = left
                this.topMargin = top
            }

            addView(badgeView, params)
            blockViews.add(badgeView)
        }

        // 2. Create Floating Top Control Bar
        val controlBar = createTopControlBar(
            blockCount = blocks.size,
            onClose = { dismiss() },
            onDetailCard = {
                val fullEn = blocks.joinToString("\n\n") { it.originalText }
                val fullAr = blocks.joinToString("\n\n") { it.translatedText }
                dismiss()
                onOpenDetailCard(fullEn, fullAr)
            },
            onCopy = {
                val fullAr = blocks.joinToString("\n\n") { it.translatedText }
                copyToClipboard("Translations", fullAr)
                Toast.makeText(context, "تم نسخ جميع الترجمات (${blocks.size})", Toast.LENGTH_SHORT).show()
                onCopyAll()
            }
        )

        val controlParams = LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dpToPx(36)
        }
        addView(controlBar, controlParams)
        topControlBar = controlBar

        // Attach to WindowManager if not already attached
        attachToWindow()
    }

    @SuppressLint("SetTextI18n")
    private fun createTranslatedBadge(
        block: InPlaceTranslatedBlock,
        badgeWidth: Int,
        badgeHeight: Int
    ): View {
        var isShowingOriginal = false

        val badgeContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dpToPx(6), dpToPx(3), dpToPx(6), dpToPx(3))

            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE0D1424")) // Dark high-contrast glass
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#00E5FF"))
            }
            elevation = dpToPx(6).toFloat()
        }

        // Translation Text View
        val textView = TextView(context).apply {
            text = block.translatedText
            setTextColor(Color.parseColor("#FFFFFF"))
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD

            // Auto text size depending on bounding box height
            val calculatedSp = when {
                badgeHeight >= dpToPx(60) -> 14f
                badgeHeight >= dpToPx(40) -> 12f
                badgeHeight >= dpToPx(28) -> 11f
                else -> 10f
            }
            setTextSize(TypedValue.COMPLEX_UNIT_SP, calculatedSp)
            maxLines = (badgeHeight / dpToPx(16)).coerceAtLeast(1)
        }

        // Mini Lang Indicator Tag ("AR" / "EN")
        val langIndicator = TextView(context).apply {
            text = "AR"
            setTextColor(Color.parseColor("#00E676"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 8f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.END
        }

        badgeContainer.addView(textView)
        badgeContainer.addView(langIndicator)

        // Click to toggle between Arabic translation and original English text
        badgeContainer.setOnClickListener {
            isShowingOriginal = !isShowingOriginal
            if (isShowingOriginal) {
                textView.text = block.originalText
                textView.setTextColor(Color.parseColor("#FFD54F"))
                langIndicator.text = "EN"
                langIndicator.setTextColor(Color.parseColor("#FFD54F"))
                (badgeContainer.background as? GradientDrawable)?.setStroke(
                    dpToPx(1),
                    Color.parseColor("#FFD54F")
                )
            } else {
                textView.text = block.translatedText
                textView.setTextColor(Color.parseColor("#FFFFFF"))
                langIndicator.text = "AR"
                langIndicator.setTextColor(Color.parseColor("#00E676"))
                (badgeContainer.background as? GradientDrawable)?.setStroke(
                    dpToPx(1),
                    Color.parseColor("#00E5FF")
                )
            }
        }

        // Long click to copy single block
        badgeContainer.setOnLongClickListener {
            val textToCopy = if (isShowingOriginal) block.originalText else block.translatedText
            copyToClipboard("Text", textToCopy)
            Toast.makeText(context, "تم نسخ: $textToCopy", Toast.LENGTH_SHORT).show()
            true
        }

        return badgeContainer
    }

    @SuppressLint("SetTextI18n")
    private fun createTopControlBar(
        blockCount: Int,
        onClose: () -> Unit,
        onDetailCard: () -> Unit,
        onCopy: () -> Unit
    ): View {
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpToPx(12), dpToPx(6), dpToPx(10), dpToPx(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2090D18"))
                cornerRadius = dpToPx(24).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#3300E5FF"))
            }
            elevation = dpToPx(10).toFloat()
        }

        val countBadge = TextView(context).apply {
            text = "⚡ $blockCount ترجمة"
            setTextColor(Color.parseColor("#00E5FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, dpToPx(10), 0)
        }

        val copyBtn = createPillButton("نسخ", "#00E676") { onCopy() }
        val cardBtn = createPillButton("بطاقة", "#B388FF") { onDetailCard() }
        val closeBtn = createPillButton("✕", "#FF5252") { onClose() }

        bar.addView(countBadge)
        bar.addView(copyBtn)
        bar.addView(cardBtn)
        bar.addView(closeBtn)

        return bar
    }

    private fun createPillButton(label: String, colorHex: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            setTextColor(Color.parseColor(colorHex))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#22" + colorHex.removePrefix("#")))
                cornerRadius = dpToPx(12).toFloat()
            }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dpToPx(4), 0, 0, 0)
            }
            layoutParams = params
            setOnClickListener { onClick() }
        }
    }

    private fun attachToWindow() {
        if (isAttached) return

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        try {
            windowManager.addView(this, windowParams)
            isAttached = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismiss() {
        clearBlocks()
        if (isAttached) {
            try {
                windowManager.removeView(this)
            } catch (_: Exception) {}
            isAttached = false
            onDismissCallback()
        }
    }

    private fun clearBlocks() {
        for (view in blockViews) {
            try {
                removeView(view)
            } catch (_: Exception) {}
        }
        blockViews.clear()

        topControlBar?.let {
            try {
                removeView(it)
            } catch (_: Exception) {}
            topControlBar = null
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * context.resources.displayMetrics.density).toInt()
    }

    fun isShowing(): Boolean = isAttached
}
