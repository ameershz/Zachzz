package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.economy.EconomyManager
import com.example.game.inventory.FishInventory

/**
 * Modal dialogue for the Fish Shop ("Pelican Fishmonger") where players sell caught fish for gold.
 */
class FishShopModal(
    val economyManager: EconomyManager,
    val fishInventory: FishInventory,
    var onSoldFish: ((Int, Int) -> Unit)? = null,
    var onClose: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set

    private val modalRect = RectF()
    private val sellAllBtnRect = RectF()
    private val closeBtnRect = RectF()

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(175, 8, 14, 24)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 30, 48)
        style = Paint.Style.FILL
    }

    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113) // Fresh sea green trim
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 44, 68)
        style = Paint.Style.FILL
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 22f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val greetingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 210, 235)
        textAlign = Paint.Align.CENTER
        textSize = 14f
    }

    private val itemBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(14, 22, 36)
        style = Paint.Style.FILL
    }

    private val fishTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val fishSubTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 200, 220)
        textSize = 13f
    }

    private val valueTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(241, 196, 15) // Gold
        textAlign = Paint.Align.RIGHT
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val sellAllBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(39, 174, 96)
        style = Paint.Style.FILL
    }

    private val sellAllDisabledPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(60, 70, 85)
        style = Paint.Style.FILL
    }

    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val closeBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 60, 50)
        style = Paint.Style.FILL
    }

    fun open() {
        isOpen = true
    }

    fun close() {
        isOpen = false
        onClose?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false

        // Tap Sell All button
        if (sellAllBtnRect.contains(touchX, touchY)) {
            if (fishInventory.count > 0) {
                val (soldCount, totalEarned) = fishInventory.clearAndSellAll()
                if (totalEarned > 0) {
                    economyManager.earn(totalEarned)
                    onSoldFish?.invoke(soldCount, totalEarned)
                }
            }
            return true
        }

        // Tap Close button
        if (closeBtnRect.contains(touchX, touchY)) {
            close()
            return true
        }

        // Tap outside card dismisses
        if (!modalRect.contains(touchX, touchY)) {
            close()
            return true
        }

        return true
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        if (!isOpen) return

        // Dark dim backdrop
        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        // Card dimensions
        val isLandscape = screenW > screenH
        val cardW = if (isLandscape) (screenW * 0.72f).coerceIn(500f, 680f) else (screenW * 0.90f).coerceIn(320f, 480f)
        val cardH = if (isLandscape) (screenH * 0.88f).coerceIn(340f, 420f) else 440f.coerceAtMost(screenH * 0.88f)
        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        // Card frame
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBorderPaint)

        // Header
        val headerH = 56f
        val headerRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + headerH)
        canvas.drawRoundRect(headerRect, 18f, 18f, headerPaint)
        canvas.drawRect(cardLeft, cardTop + headerH - 12f, cardLeft + cardW, cardTop + headerH, headerPaint)

        canvas.drawText("🐟 Pelican Fishmonger", screenW * 0.5f, cardTop + 34f, titlePaint)
        canvas.drawText("I buy all fresh island catches at top market rates!", screenW * 0.5f, cardTop + headerH + 22f, greetingPaint)

        // List box of fish
        val listTop = cardTop + headerH + 34f
        val listH = 200f
        val listRect = RectF(cardLeft + 16f, listTop, cardLeft + cardW - 16f, listTop + listH)
        canvas.drawRoundRect(listRect, 12f, 12f, itemBoxPaint)

        val fishList = fishInventory.getFishList()
        if (fishList.isEmpty()) {
            val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(150, 165, 185)
                textAlign = Paint.Align.CENTER
                textSize = 16f
            }
            canvas.drawText("No fish in creel! Go cast your rod at the dock.", listRect.centerX(), listRect.centerY() + 6f, emptyPaint)
        } else {
            // Render up to 4 items in preview
            var itemY = listTop + 32f
            for (i in 0 until minOf(4, fishList.size)) {
                val fish = fishList[i]
                // Rarity badge
                val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = fish.species.rarity.color
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                }
                canvas.drawText("${fish.species.iconEmoji} ${fish.species.speciesName}", listRect.left + 14f, itemY, fishTextPaint)
                canvas.drawText("(${fish.species.rarity.displayName}, ${fish.formattedWeight})", listRect.left + 175f, itemY, badgePaint)
                canvas.drawText("+${fish.formattedValue}", listRect.right - 14f, itemY, valueTextPaint)
                itemY += 38f
            }
            if (fishList.size > 4) {
                val morePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(160, 190, 220)
                    textAlign = Paint.Align.CENTER
                    textSize = 13f
                }
                canvas.drawText("+ ${fishList.size - 4} more fish in creel", listRect.centerX(), listTop + listH - 12f, morePaint)
            }
        }

        // Summary footer
        val totalWorth = fishInventory.totalValue
        val summaryY = listRect.bottom + 32f
        val summaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 225, 90)
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("Total Value: $$totalWorth (${fishList.size}/10 fish)", cardLeft + 20f, summaryY, summaryPaint)

        // Buttons
        val btnH = 42f
        val sellBtnW = 150f
        sellAllBtnRect.set(cardLeft + cardW - sellBtnW - 16f, summaryY - 26f, cardLeft + cardW - 16f, summaryY + 16f)
        val canSell = fishList.isNotEmpty()
        canvas.drawRoundRect(sellAllBtnRect, 8f, 8f, if (canSell) sellAllBtnPaint else sellAllDisabledPaint)
        canvas.drawText(if (canSell) "SELL ALL ($$totalWorth)" else "EMPTY CREEL", sellAllBtnRect.centerX(), sellAllBtnRect.centerY() + 6f, btnTextPaint)

        // Close button
        val closeBtnW = 90f
        closeBtnRect.set(cardLeft + 20f, cardTop + cardH - 52f, cardLeft + 20f + closeBtnW, cardTop + cardH - 14f)
        canvas.drawRoundRect(closeBtnRect, 8f, 8f, closeBtnPaint)
        canvas.drawText("CLOSE", closeBtnRect.centerX(), closeBtnRect.centerY() + 6f, btnTextPaint)
    }
}
