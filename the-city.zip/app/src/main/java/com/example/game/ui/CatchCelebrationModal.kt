package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.fishing.CaughtFish

/**
 * Celebration modal popup shown upon successfully catching a fish.
 */
class CatchCelebrationModal(
    var onCollect: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set
    var caughtFish: CaughtFish? = null
        private set

    private val modalRect = RectF()
    private val collectBtnRect = RectF()

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(185, 5, 10, 20)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 28, 45)
        style = Paint.Style.FILL
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 220, 70)
        textAlign = Paint.Align.CENTER
        textSize = 22f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val fishNamePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 24f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val rarityPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val statsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 235, 255)
        textAlign = Paint.Align.CENTER
        textSize = 18f
    }

    private val collectBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113)
        style = Paint.Style.FILL
    }

    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun show(fish: CaughtFish) {
        caughtFish = fish
        isOpen = true
    }

    fun dismiss() {
        if (!isOpen) return
        isOpen = false
        caughtFish = null
        onCollect?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false
        dismiss()
        return true
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        val fish = caughtFish ?: return
        if (!isOpen) return

        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        val cardW = (screenW * 0.85f).coerceIn(300f, 420f)
        val cardH = 340f
        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = fish.species.rarity.color
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRoundRect(modalRect, 20f, 20f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 20f, 20f, borderPaint)

        // Celebration Header
        canvas.drawText("✨ EXCELLENT CATCH! ✨", screenW * 0.5f, cardTop + 44f, titlePaint)

        // Fish icon
        val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            textSize = 52f
        }
        canvas.drawText(fish.species.iconEmoji, screenW * 0.5f, cardTop + 115f, iconPaint)

        // Species name & Rarity
        canvas.drawText(fish.species.speciesName, screenW * 0.5f, cardTop + 160f, fishNamePaint)
        rarityPaint.color = fish.species.rarity.color
        canvas.drawText("[ ${fish.species.rarity.displayName.uppercase()} ]", screenW * 0.5f, cardTop + 190f, rarityPaint)

        // Stats: Weight & Market value
        canvas.drawText("Weight: ${fish.formattedWeight}   •   Value: ${fish.formattedValue}", screenW * 0.5f, cardTop + 232f, statsPaint)

        // Collect button
        val btnW = 160f
        val btnH = 46f
        collectBtnRect.set((screenW - btnW) * 0.5f, cardTop + 265f, (screenW + btnW) * 0.5f, cardTop + 265f + btnH)
        canvas.drawRoundRect(collectBtnRect, 10f, 10f, collectBtnPaint)
        canvas.drawText("KEEP IN CREEL", screenW * 0.5f, collectBtnRect.centerY() + 6f, btnTextPaint)
    }
}
