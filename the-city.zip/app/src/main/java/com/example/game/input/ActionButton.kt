package com.example.game.input

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.sin

/**
 * On-screen action/interaction button rendered on the lower-right corner.
 * Shows when near an interactable object with smooth bounce-in animation.
 */
class ActionButton {
    var x: Float = 900f
    var y: Float = 900f
    var radius: Float = 75f

    var isVisible: Boolean = false
    var isPressed: Boolean = false
    var label: String = "ACTION"
    var subLabel: String = ""

    var activePointerId: Int = -1

    // Animation scale 0..1
    var animScale: Float = 0f
    private var pulseTimer: Float = 0f

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 122, 0) // Warm energetic orange
        style = Paint.Style.FILL
    }

    private val bgPressedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 95, 0)
        style = Paint.Style.FILL
    }

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val pulseRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 165, 0)
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 28f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 255, 255, 255)
        textAlign = Paint.Align.CENTER
        textSize = 18f
        typeface = Typeface.DEFAULT
    }

    fun setDefaultPosition(screenW: Float, screenH: Float) {
        val shortDim = minOf(screenW, screenH)
        val density = (shortDim / 400f).coerceIn(1.8f, 2.7f)
        radius = 36f * density
        x = screenW - 40f - radius
        y = screenH - 36f - radius
        textPaint.textSize = 13.5f * density
        subTextPaint.textSize = 9.5f * density
    }

    fun update(deltaTime: Float) {
        val targetScale = if (isVisible) 1f else 0f
        animScale += (targetScale - animScale) * (deltaTime * 10f).coerceIn(0f, 1f)
        pulseTimer += deltaTime * 4f
    }

    fun contains(touchX: Float, touchY: Float): Boolean {
        if (!isVisible || animScale < 0.3f) return false
        val dx = touchX - x
        val dy = touchY - y
        // Slightly generous hit testing for comfortable thumb tap
        return (dx * dx + dy * dy) <= (radius * 1.25f) * (radius * 1.25f)
    }

    fun onTouchDown(pointerId: Int, touchX: Float, touchY: Float): Boolean {
        if (contains(touchX, touchY)) {
            activePointerId = pointerId
            isPressed = true
            return true
        }
        return false
    }

    fun onTouchUp(pointerId: Int, touchX: Float, touchY: Float): Boolean {
        if (pointerId == activePointerId) {
            val wasPressed = isPressed
            activePointerId = -1
            isPressed = false
            return wasPressed && contains(touchX, touchY)
        }
        return false
    }

    fun cancelTouch() {
        activePointerId = -1
        isPressed = false
    }

    fun render(canvas: Canvas) {
        if (animScale <= 0.01f) return

        canvas.save()
        val currentScale = animScale * if (isPressed) 0.92f else 1f
        canvas.translate(x, y)
        canvas.scale(currentScale, currentScale)

        // Pulsing halo when available
        val pulseRadius = radius + (sin(pulseTimer) * 0.5f + 0.5f) * 12f
        val pulseAlpha = ((1f - (pulseRadius - radius) / 12f) * 100).toInt().coerceIn(0, 150)
        pulseRingPaint.alpha = pulseAlpha
        canvas.drawCircle(0f, 0f, pulseRadius, pulseRingPaint)

        // Main button circular body
        canvas.drawCircle(0f, 0f, radius, if (isPressed) bgPressedPaint else bgPaint)
        canvas.drawCircle(0f, 0f, radius, ringPaint)

        // Subtle top gloss
        val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(60, 255, 255, 255)
            style = Paint.Style.FILL
        }
        val glossRect = RectF(-radius * 0.8f, -radius * 0.85f, radius * 0.8f, 0f)
        canvas.drawOval(glossRect, glossPaint)

        // Button text
        if (subLabel.isEmpty()) {
            val textY = textPaint.textSize * 0.35f
            canvas.drawText(label, 0f, textY, textPaint)
        } else {
            val textY = -4f
            val subY = textY + subTextPaint.textSize * 1.3f
            canvas.drawText(label, 0f, textY, textPaint)
            canvas.drawText(subLabel, 0f, subY, subTextPaint)
        }

        canvas.restore()
    }
}
