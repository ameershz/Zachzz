package com.example.game.input

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.hypot

/**
 * On-screen virtual joystick for 2D character movement.
 * Supports touch anchoring, deadzone filtering, and smooth return spring.
 */
class VirtualJoystick {
    var baseX: Float = 220f
    var baseY: Float = 900f
    var stickX: Float = 220f
    var stickY: Float = 900f

    var baseRadius: Float = 140f
    var stickRadius: Float = 60f

    var activePointerId: Int = -1
    var isDragging: Boolean = false

    // Output normalized direction vector [-1..1]
    var dirX: Float = 0f
        private set
    var dirY: Float = 0f
        private set
    var intensity: Float = 0f
        private set

    private val deadzone: Float = 0.12f

    // Visual paints
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 20, 24, 38)
        style = Paint.Style.FILL
    }

    private val baseRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val innerGuidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val stickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 74, 144, 226)
        style = Paint.Style.FILL
    }

    private val stickHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    fun setDefaultPosition(screenW: Float, screenH: Float) {
        val density = (screenW / 400f).coerceIn(1f, 3.5f)
        baseRadius = 60f * density
        stickRadius = 26f * density
        baseX = baseRadius * 1.5f
        baseY = screenH - baseRadius * 1.5f
        stickX = baseX
        stickY = baseY
    }

    fun onTouchDown(pointerId: Int, touchX: Float, touchY: Float) {
        activePointerId = pointerId
        isDragging = true
        // Center joystick at touch point if within comfortable left-bottom screen zone
        baseX = touchX
        baseY = touchY
        stickX = touchX
        stickY = touchY
        updateDirection(touchX, touchY)
    }

    fun onTouchMove(pointerId: Int, touchX: Float, touchY: Float) {
        if (pointerId != activePointerId) return
        updateDirection(touchX, touchY)
    }

    fun onTouchUp(pointerId: Int) {
        if (pointerId != activePointerId) return
        reset()
    }

    fun reset() {
        activePointerId = -1
        isDragging = false
        stickX = baseX
        stickY = baseY
        dirX = 0f
        dirY = 0f
        intensity = 0f
    }

    private fun updateDirection(touchX: Float, touchY: Float) {
        val dx = touchX - baseX
        val dy = touchY - baseY
        val distance = hypot(dx, dy)

        if (distance <= 0.0001f) {
            stickX = baseX
            stickY = baseY
            dirX = 0f
            dirY = 0f
            intensity = 0f
            return
        }

        // Clamp stick within base radius
        val clampedDist = distance.coerceAtMost(baseRadius)
        stickX = baseX + (dx / distance) * clampedDist
        stickY = baseY + (dy / distance) * clampedDist

        val rawIntensity = clampedDist / baseRadius
        if (rawIntensity < deadzone) {
            dirX = 0f
            dirY = 0f
            intensity = 0f
        } else {
            // Normalize non-deadzone intensity 0..1
            val remapped = (rawIntensity - deadzone) / (1f - deadzone)
            intensity = remapped.coerceIn(0f, 1f)
            dirX = (dx / distance) * intensity
            dirY = (dy / distance) * intensity
        }
    }

    fun render(canvas: Canvas) {
        // Draw base plate with glowing edge
        canvas.drawCircle(baseX, baseY, baseRadius, basePaint)
        canvas.drawCircle(baseX, baseY, baseRadius, baseRingPaint)
        canvas.drawCircle(baseX, baseY, baseRadius * 0.45f, innerGuidePaint)

        // Draw cross lines for directional feel
        canvas.drawLine(baseX - 16f, baseY, baseX + 16f, baseY, innerGuidePaint)
        canvas.drawLine(baseX, baseY - 16f, baseX, baseY + 16f, innerGuidePaint)

        // Draw connecting stem if dragging
        if (isDragging) {
            val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(120, 74, 144, 226)
                strokeWidth = stickRadius * 0.5f
                strokeCap = Paint.Cap.ROUND
            }
            canvas.drawLine(baseX, baseY, stickX, stickY, stemPaint)
        }

        // Draw thumb stick knob
        canvas.drawCircle(stickX, stickY, stickRadius, stickPaint)
        canvas.drawCircle(stickX, stickY, stickRadius, stickHighlightPaint)

        // Inner stick detail
        val innerKnobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(140, 255, 255, 255)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(stickX, stickY, stickRadius * 0.35f, innerKnobPaint)
    }
}
