package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.example.game.physics.CollisionSystem
import com.example.game.physics.RectCollider

/**
 * Manages the entire city neighborhood environment:
 * terrain, roads, buildings, trees, streetlamps, plaza fountain, parked cars,
 * and perimeter barriers.
 */
class World(val collisionSystem: CollisionSystem) {
    val width: Float = 2400f
    val height: Float = 2400f

    val roadNetwork = RoadNetwork()
    val buildings = mutableListOf<Building>()
    val trees = mutableListOf<Tree>()
    val lamps = mutableListOf<StreetLamp>()
    val benches = mutableListOf<ParkBench>()
    val cars = mutableListOf<ParkedCar>()
    val hydrants = mutableListOf<FireHydrant>()
    var fountain: Fountain? = null

    // Player spawn position: right in front of the Sweet Home door
    val spawnX: Float = 430f
    val spawnY: Float = 535f

    // Decorative perimeter fence / borders
    val perimeterFences = mutableListOf<RectCollider>()

    // Paints
    private val grassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(88, 142, 92) // Warm lush grass green
        style = Paint.Style.FILL
    }

    private val lawnVariationPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(80, 132, 84)
        style = Paint.Style.FILL
    }

    private val plazaStonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(205, 212, 222) // Polished cobblestone plaza
        style = Paint.Style.FILL
    }

    private val plazaGridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 188, 200)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val fencePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(240, 240, 245) // White picket fences
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val hedgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(40, 95, 48) // Thick boundary perimeter hedges
        style = Paint.Style.FILL
    }

    init {
        setupWorldBoundsAndPerimeter()
        setupBuildings()
        setupPlaza()
        setupProps()
        registerAllColliders()
    }

    private fun setupWorldBoundsAndPerimeter() {
        collisionSystem.worldBounds = RectCollider(60f, 60f, width - 60f, height - 60f)

        // Perimeter barrier colliders
        perimeterFences.add(RectCollider(0f, 0f, width, 60f, tag = "boundary_north"))
        perimeterFences.add(RectCollider(0f, height - 60f, width, height, tag = "boundary_south"))
        perimeterFences.add(RectCollider(0f, 0f, 60f, height, tag = "boundary_west"))
        perimeterFences.add(RectCollider(width - 60f, 0f, width, height, tag = "boundary_east"))
    }

    private fun setupBuildings() {
        // 1. Player Starting Home ("Sweet Home")
        buildings.add(
            Building(
                id = "building_home",
                name = "Sweet Home",
                type = BuildingType.PLAYER_HOME,
                left = 340f,
                top = 370f,
                width = 180f,
                height = 140f,
                entranceX = 430f,
                entranceY = 515f,
                wallColor = Color.rgb(220, 185, 145), // Warm stucco
                roofColor = Color.rgb(195, 75, 50),   // Terracotta clay tiles
                trimColor = Color.rgb(90, 50, 30),
                signText = "SWEET HOME",
                signBgColor = Color.rgb(140, 60, 40),
                interactionLabel = "REST",
                interactionSubLabel = "Relax & Sleep"
            )
        )

        // 2. Grocery Store ("Fresh Market") - KEY INTERACTIVE BUILDING
        buildings.add(
            Building(
                id = "building_grocery",
                name = "Fresh Market",
                type = BuildingType.GROCERY_STORE,
                left = 1300f,
                top = 350f,
                width = 220f,
                height = 150f,
                entranceX = 1410f,
                entranceY = 505f,
                wallColor = Color.rgb(235, 238, 242), // Clean modern white
                roofColor = Color.rgb(40, 140, 85),   // Forest green roof
                trimColor = Color.rgb(30, 95, 60),
                signText = "FRESH MARKET",
                signBgColor = Color.rgb(32, 125, 70),
                hasAwning = true,
                awningColor1 = Color.WHITE,
                awningColor2 = Color.rgb(38, 160, 90), // Green & White awning
                interactionLabel = "SHOP",
                interactionSubLabel = "Buy Food ($10)"
            )
        )

        // 3. Restaurant ("The Golden Diner")
        buildings.add(
            Building(
                id = "building_restaurant",
                name = "The Golden Diner",
                type = BuildingType.RESTAURANT,
                left = 1910f,
                top = 350f,
                width = 210f,
                height = 150f,
                entranceX = 2015f,
                entranceY = 505f,
                wallColor = Color.rgb(195, 80, 70),   // Brick diner red
                roofColor = Color.rgb(140, 40, 35),
                trimColor = Color.rgb(245, 205, 55),
                signText = "GOLDEN DINER",
                signBgColor = Color.rgb(175, 45, 35),
                hasAwning = true,
                awningColor1 = Color.rgb(245, 210, 60), // Gold & Red awning
                awningColor2 = Color.rgb(190, 40, 35),
                interactionLabel = "DINE",
                interactionSubLabel = "Hot Meal ($15)"
            )
        )

        // 4. Workshop ("Metro Mechanics")
        buildings.add(
            Building(
                id = "building_workshop",
                name = "Metro Mechanics",
                type = BuildingType.WORKSHOP,
                left = 320f,
                top = 1460f,
                width = 220f,
                height = 160f,
                entranceX = 460f,
                entranceY = 1625f,
                wallColor = Color.rgb(90, 105, 125), // Industrial steel blue
                roofColor = Color.rgb(55, 68, 85),
                trimColor = Color.rgb(245, 185, 30),
                signText = "METRO MECHANICS",
                signBgColor = Color.rgb(45, 60, 78),
                interactionLabel = "WORKSHOP",
                interactionSubLabel = "Tools ($25)"
            )
        )

        // 5. Gas Station ("Speedy Gas")
        buildings.add(
            Building(
                id = "building_gas_station",
                name = "Speedy Gas",
                type = BuildingType.GAS_STATION,
                left = 1890f,
                top = 1460f,
                width = 240f,
                height = 160f,
                entranceX = 2010f,
                entranceY = 1625f,
                wallColor = Color.rgb(242, 245, 248),
                roofColor = Color.rgb(225, 55, 40),
                trimColor = Color.rgb(20, 40, 80),
                signText = "SPEEDY GAS",
                signBgColor = Color.rgb(215, 45, 35),
                interactionLabel = "REFUEL",
                interactionSubLabel = "Energy Soda ($5)"
            )
        )

        // 6. Decorative Houses
        // Townhouse (Blue)
        buildings.add(
            Building(
                id = "house_blue",
                name = "Bluebell Cottage",
                type = BuildingType.DECORATIVE_HOUSE_A,
                left = 340f,
                top = 800f,
                width = 170f,
                height = 135f,
                entranceX = 425f,
                entranceY = 940f,
                wallColor = Color.rgb(175, 205, 225),
                roofColor = Color.rgb(60, 85, 120),
                trimColor = Color.rgb(240, 245, 255),
                signText = "No. 42"
            )
        )

        // Craftsman Bungalow (Peach)
        buildings.add(
            Building(
                id = "house_peach",
                name = "Maple Villa",
                type = BuildingType.DECORATIVE_HOUSE_B,
                left = 860f,
                top = 370f,
                width = 180f,
                height = 140f,
                entranceX = 950f,
                entranceY = 515f,
                wallColor = Color.rgb(240, 205, 180),
                roofColor = Color.rgb(145, 80, 50),
                trimColor = Color.rgb(255, 255, 255),
                signText = "No. 18"
            )
        )

        // Modern Villa (Sage green)
        buildings.add(
            Building(
                id = "house_sage",
                name = "Cedar House",
                type = BuildingType.DECORATIVE_HOUSE_C,
                left = 860f,
                top = 800f,
                width = 180f,
                height = 135f,
                entranceX = 950f,
                entranceY = 940f,
                wallColor = Color.rgb(195, 215, 195),
                roofColor = Color.rgb(85, 105, 85),
                trimColor = Color.rgb(50, 70, 50),
                signText = "No. 24"
            )
        )

        // Town Civic Hall / Library (Center-South)
        buildings.add(
            Building(
                id = "town_hall",
                name = "City Library",
                type = BuildingType.TOWN_HALL,
                left = 1250f,
                top = 1460f,
                width = 240f,
                height = 160f,
                entranceX = 1370f,
                entranceY = 1625f,
                wallColor = Color.rgb(230, 225, 215), // Elegant stone
                roofColor = Color.rgb(80, 140, 130),  // Oxidized copper roof
                trimColor = Color.rgb(180, 160, 130),
                signText = "CITY LIBRARY",
                signBgColor = Color.rgb(55, 105, 95),
                interactionLabel = "READ",
                interactionSubLabel = "City Archives"
            )
        )
    }

    private fun setupPlaza() {
        // Central Town Square Fountain at X=1420, Y=880
        fountain = Fountain(1420f, 880f, 60f)

        // Park benches surrounding plaza
        benches.add(ParkBench(1320f, 880f, isHorizontal = false))
        benches.add(ParkBench(1520f, 880f, isHorizontal = false))
        benches.add(ParkBench(1420f, 780f, isHorizontal = true))
        benches.add(ParkBench(1420f, 980f, isHorizontal = true))
    }

    private fun setupProps() {
        // Trees around neighborhoods
        val treeCoords = listOf(
            Pair(240f, 320f), Pair(240f, 480f), Pair(240f, 740f), Pair(240f, 900f),
            Pair(560f, 320f), Pair(560f, 480f), Pair(560f, 740f), Pair(560f, 900f),
            Pair(1080f, 320f), Pair(1080f, 480f), Pair(1080f, 740f), Pair(1080f, 900f),
            // Central park foliage
            Pair(1240f, 760f), Pair(1600f, 760f), Pair(1240f, 1000f), Pair(1600f, 1000f),
            // South industrial & commercial trees
            Pair(240f, 1400f), Pair(240f, 1650f), Pair(570f, 1400f), Pair(570f, 1650f),
            Pair(1150f, 1400f), Pair(1550f, 1400f), Pair(1780f, 1400f), Pair(2200f, 1400f)
        )
        for ((tx, ty) in treeCoords) {
            trees.add(Tree(tx, ty, size = 36f + (Math.sin(tx.toDouble() + ty.toDouble()) * 4f).toFloat()))
        }

        // Streetlamps along sidewalk edges
        val lampCoords = listOf(
            Pair(580f, 510f), Pair(720f, 510f), Pair(580f, 1120f), Pair(720f, 1120f),
            Pair(1680f, 510f), Pair(1820f, 510f), Pair(1680f, 1120f), Pair(1820f, 1120f),
            Pair(580f, 1750f), Pair(720f, 1750f), Pair(1680f, 1750f), Pair(1820f, 1750f),
            // Market street lamps
            Pair(1270f, 510f), Pair(1550f, 510f), Pair(1870f, 510f), Pair(2150f, 510f)
        )
        for ((lx, ly) in lampCoords) {
            lamps.add(StreetLamp(lx, ly))
        }

        // Fire hydrants near intersections
        hydrants.add(FireHydrant(570f, 650f))
        hydrants.add(FireHydrant(1670f, 650f))
        hydrants.add(FireHydrant(570f, 1280f))
        hydrants.add(FireHydrant(1670f, 1280f))

        // Parked decorative cars
        cars.add(ParkedCar(750f, 565f, Color.rgb(40, 115, 215), isHorizontal = true)) // Blue sedan
        cars.add(ParkedCar(1600f, 565f, Color.rgb(220, 50, 45), isHorizontal = true)) // Red compact
        cars.add(ParkedCar(1840f, 565f, Color.rgb(240, 195, 30), isHorizontal = true)) // Yellow taxi
        cars.add(ParkedCar(750f, 1215f, Color.rgb(65, 175, 95), isHorizontal = true)) // Green wagon
    }

    private fun registerAllColliders() {
        collisionSystem.clear()

        // Boundary fences
        collisionSystem.addColliders(perimeterFences)

        // Buildings
        for (b in buildings) {
            collisionSystem.addCollider(b.collider)
        }

        // Trees
        for (t in trees) {
            collisionSystem.addCollider(t.collider)
        }

        // Streetlamps
        for (l in lamps) {
            collisionSystem.addCollider(l.collider)
        }

        // Park benches
        for (b in benches) {
            collisionSystem.addCollider(b.collider)
        }

        // Fountain
        fountain?.let { collisionSystem.addCollider(it.collider) }

        // Parked cars
        for (c in cars) {
            collisionSystem.addCollider(c.collider)
        }

        // Hydrants
        for (h in hydrants) {
            collisionSystem.addCollider(h.collider)
        }
    }

    fun update(deltaTime: Float) {
        for (b in buildings) {
            b.update(deltaTime)
        }
        fountain?.update(deltaTime)
    }

    fun render(canvas: Canvas) {
        // 1. Base grass field
        canvas.drawRect(0f, 0f, width, height, grassPaint)

        // Subtle lawn patches for visual depth
        for (i in 0..15) {
            val patchX = (i * 157f) % (width - 200f) + 100f
            val patchY = (i * 223f) % (height - 200f) + 100f
            canvas.drawRoundRect(RectF(patchX, patchY, patchX + 140f, patchY + 90f), 30f, 30f, lawnVariationPaint)
        }

        // 2. Central Market Plaza Stone Paving
        val plazaRect = RectF(1220f, 680f, 1620f, 1080f)
        canvas.drawRoundRect(plazaRect, 20f, 20f, plazaStonePaint)

        // Plaza stone tile grid
        var xGrid = 1240f
        while (xGrid < 1620f) {
            canvas.drawLine(xGrid, 680f, xGrid, 1080f, plazaGridPaint)
            xGrid += 40f
        }
        var yGrid = 700f
        while (yGrid < 1080f) {
            canvas.drawLine(1220f, yGrid, 1620f, yGrid, plazaGridPaint)
            yGrid += 40f
        }

        // 3. Roads and Crosswalks
        roadNetwork.render(canvas)

        // 4. Park Benches
        for (b in benches) {
            b.render(canvas)
        }

        // 5. Fountain in Plaza
        fountain?.render(canvas)

        // 6. Parked Cars
        for (c in cars) {
            c.render(canvas)
        }

        // 7. Fire Hydrants
        for (h in hydrants) {
            h.render(canvas)
        }

        // 8. Buildings
        for (b in buildings) {
            b.render(canvas)
        }

        // 9. Streetlamps (with ground light glow)
        for (l in lamps) {
            l.render(canvas)
        }

        // 10. Trees (dense canopies rendered above ground level)
        for (t in trees) {
            t.render(canvas)
        }

        // 11. Perimeter Boundary Hedges & Barrier
        renderPerimeter(canvas)
    }

    private fun renderPerimeter(canvas: Canvas) {
        // Outer boundary hedges (green decorative wall)
        val hedgeThickness = 55f
        // North hedge
        canvas.drawRect(0f, 0f, width, hedgeThickness, hedgePaint)
        // South hedge
        canvas.drawRect(0f, height - hedgeThickness, width, height, hedgePaint)
        // West hedge
        canvas.drawRect(0f, 0f, hedgeThickness, height, hedgePaint)
        // East hedge
        canvas.drawRect(width - hedgeThickness, 0f, width, height, hedgePaint)

        // Inner white fence line
        canvas.drawRect(
            hedgeThickness,
            hedgeThickness,
            width - hedgeThickness,
            height - hedgeThickness,
            fencePaint
        )
    }

    /**
     * Determines a friendly contextual location name for the HUD based on player position.
     */
    fun getLocationName(px: Float, py: Float): String {
        return when {
            // Near buildings
            px in 300f..560f && py in 340f..560f -> "Sweet Home"
            px in 1260f..1560f && py in 320f..560f -> "Fresh Market"
            px in 1860f..2160f && py in 320f..560f -> "The Golden Diner"
            px in 300f..560f && py in 1400f..1660f -> "Metro Mechanics"
            px in 1850f..2170f && py in 1400f..1660f -> "Speedy Gas Station"
            px in 1200f..1520f && py in 1400f..1660f -> "City Library"
            // Plaza
            px in 1220f..1620f && py in 680f..1080f -> "Central Plaza"
            // Streets
            py in 1120f..1280f -> "Grand Boulevard"
            py in 500f..650f -> "Market Street"
            py in 1740f..1900f -> "Industrial Way"
            px in 570f..730f -> "Maple Avenue"
            px in 1670f..1830f -> "Commerce Avenue"
            px < 1100f && py < 1100f -> "Residential Grove"
            else -> "The City"
        }
    }
}
