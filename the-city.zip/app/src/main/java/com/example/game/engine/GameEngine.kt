package com.example.game.engine

import android.graphics.Canvas
import android.graphics.Color
import android.view.MotionEvent
import com.example.game.camera.Camera2D
import com.example.game.economy.EconomyManager
import com.example.game.input.ActionButton
import com.example.game.input.TouchController
import com.example.game.input.VirtualJoystick
import com.example.game.interaction.Interactable
import com.example.game.interaction.InteractionManager
import com.example.game.inventory.GameItem
import com.example.game.inventory.Inventory
import com.example.game.model.Building
import com.example.game.model.World
import com.example.game.physics.CollisionSystem
import com.example.game.player.Player
import com.example.game.ui.FloatingText
import com.example.game.ui.InGameHud
import com.example.game.ui.InGameShopModal

/**
 * Main coordinator of all game subsystems:
 * physics, entities, world rendering, camera follow, input, economy, and UI.
 */
class GameEngine {
    val collisionSystem = CollisionSystem()
    val world = World(collisionSystem)
    val player = Player(world.spawnX, world.spawnY)
    val camera = Camera2D()

    val economyManager = EconomyManager(initialMoney = 100)
    val inventory = Inventory()
    val interactionManager = InteractionManager()

    val joystick = VirtualJoystick()
    val actionButton = ActionButton()
    val touchController = TouchController(joystick, actionButton)

    val hud = InGameHud(economyManager, inventory)
    val shopModal = InGameShopModal(economyManager, inventory)

    private val floatingTexts = mutableListOf<FloatingText>()

    var screenWidth: Float = 1080f
    var screenHeight: Float = 1920f

    init {
        camera.setTarget(player.x, player.y, instant = true)
        setupInteractions()
        setupCallbacks()
    }

    private fun setupInteractions() {
        interactionManager.clear()

        for (building in world.buildings) {
            val interactable = when (building.id) {
                "building_grocery" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "SHOP",
                        actionSubLabel = "Food ($10)",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 90f,
                        onTrigger = {
                            shopModal.open(
                                title = "Fresh Market",
                                item = GameItem.FOOD,
                                greeting = "Welcome to Fresh Market! Buy nutritious food for $10."
                            )
                        }
                    )
                }

                "building_home" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "REST",
                        actionSubLabel = "Sweet Home",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 90f,
                        onTrigger = {
                            addFloatingText(player.x, player.y - 45f, "✨ Rested at Home!", Color.rgb(100, 240, 160))
                        }
                    )
                }

                "building_restaurant" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "DINE",
                        actionSubLabel = "Meal ($15)",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 90f,
                        onTrigger = {
                            shopModal.open(
                                title = "The Golden Diner",
                                item = GameItem.HOT_MEAL,
                                greeting = "Welcome! Order our sizzling chef special burger combo for $15."
                            )
                        }
                    )
                }

                "building_workshop" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "TOOLS",
                        actionSubLabel = "Kit ($25)",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 90f,
                        onTrigger = {
                            shopModal.open(
                                title = "Metro Mechanics",
                                item = GameItem.TOOL_KIT,
                                greeting = "Need gear? Heavy-duty mechanic wrench toolkit for $25."
                            )
                        }
                    )
                }

                "building_gas_station" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "SNACK",
                        actionSubLabel = "Soda ($5)",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 95f,
                        onTrigger = {
                            shopModal.open(
                                title = "Speedy Gas",
                                item = GameItem.ENERGY_SODA,
                                greeting = "Cold refreshment on the go! Grab a Turbo Cola for $5."
                            )
                        }
                    )
                }

                else -> null
            }

            if (interactable != null) {
                interactionManager.register(interactable)
            }
        }
    }

    private fun setupCallbacks() {
        touchController.onActionClicked = {
            if (!shopModal.isOpen) {
                interactionManager.triggerActive()
            }
        }

        touchController.onScreenTapped = { tx, ty ->
            if (shopModal.isOpen) {
                shopModal.onTouch(tx, ty)
            } else {
                false
            }
        }

        shopModal.onBuySuccess = { item ->
            addFloatingText(player.x, player.y - 40f, "+1 ${item.name}!", Color.rgb(90, 240, 140))
            addFloatingText(player.x, player.y - 15f, "-$${item.price}", Color.rgb(255, 120, 100))
        }
    }

    fun onSurfaceChanged(width: Float, height: Float) {
        screenWidth = width
        screenHeight = height

        camera.resize(width, height)
        camera.setWorldBounds(collisionSystem.worldBounds)
        camera.setTarget(player.x, player.y, instant = true)

        joystick.setDefaultPosition(width, height)
        actionButton.setDefaultPosition(width, height)
    }

    fun update(deltaTime: Float) {
        // Clamp large delta times (e.g. after app pause)
        val dt = deltaTime.coerceIn(0.001f, 0.05f)

        // Update world environment (animations, smoke, fountain)
        world.update(dt)

        // If shop modal is open, don't move character
        if (!shopModal.isOpen) {
            player.update(
                deltaTime = dt,
                inputDirX = joystick.dirX,
                inputDirY = joystick.dirY,
                inputIntensity = joystick.intensity,
                collisionSystem = collisionSystem
            )

            // Update camera smoothly following player
            camera.setTarget(player.x, player.y)

            // Check interactions near player
            interactionManager.update(player.x, player.y)

            // Update action button state
            val active = interactionManager.activeInteractable
            if (active != null) {
                actionButton.isVisible = true
                actionButton.label = active.actionLabel
                actionButton.subLabel = active.actionSubLabel
            } else {
                actionButton.isVisible = false
            }
        } else {
            // Cancel player velocity when shop is opened
            player.vx = 0f
            player.vy = 0f
            actionButton.isVisible = false
            joystick.reset()
        }

        camera.update(dt)
        actionButton.update(dt)

        // Update HUD info
        hud.currentLocationName = world.getLocationName(player.x, player.y)
        hud.activeInteractable = interactionManager.activeInteractable
        hud.update(dt)

        // Update floating text notifications
        val textIterator = floatingTexts.iterator()
        while (textIterator.hasNext()) {
            val ft = textIterator.next()
            ft.update(dt)
            if (ft.isDead) {
                textIterator.remove()
            }
        }
    }

    fun render(canvas: Canvas) {
        // Clear background
        canvas.drawColor(Color.rgb(35, 45, 55))

        // 1. Render World Space with Camera transform
        camera.applyTransform(canvas)

        // World terrain, roads, buildings, and environmental props
        world.render(canvas)

        // Player character with shadows and directional animations
        player.render(canvas)

        // In-world floating texts
        for (ft in floatingTexts) {
            ft.render(canvas)
        }

        canvas.restore()

        // 2. Render Screen Space (HUD, Controls, Overlays)
        // HUD at top of screen
        hud.render(canvas, screenWidth, screenHeight)

        // Virtual joystick on bottom left
        if (!shopModal.isOpen) {
            joystick.render(canvas)
            actionButton.render(canvas)
        }

        // In-game Shop Modal Overlay (if open)
        if (shopModal.isOpen) {
            shopModal.render(canvas, screenWidth, screenHeight)
        }
    }

    fun handleTouchEvent(event: MotionEvent): Boolean {
        return touchController.handleTouchEvent(event, screenWidth, screenHeight)
    }

    fun addFloatingText(wx: Float, wy: Float, text: String, color: Int = Color.rgb(255, 220, 60)) {
        floatingTexts.add(FloatingText(wx, wy, text, color))
    }
}
