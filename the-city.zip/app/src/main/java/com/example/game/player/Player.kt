package com.example.game.player

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.example.game.physics.CollisionSystem
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Animated 2D player character with directional rendering, walk/idle animations,
 * smooth acceleration/deceleration physics, and dust particles.
 */
class Player(startX: Float, startY: Float) {
    var x: Float = startX
    var y: Float = startY

    var vx: Float = 0f
    var vy: Float = 0f

    // Physics parameters
    val maxSpeed: Float = 220f // units per second
    val acceleration: Float = 1400f
    val friction: Float = 1200f

    // Collision half-extents (centered around feet for natural depth sorting)
    val colliderHalfWidth: Float = 14f
    val colliderHalfHeight: Float = 10f

    // Facing direction
    var direction: PlayerDirection = PlayerDirection.SOUTH

    // Animation state
    var isMoving: Boolean = false
        private set
    private var walkCycle: Float = 0f
    private var idleTimer: Float = 0f
    private var dustSpawnTimer: Float = 0f

    // Dust particles
    private val dustParticles = mutableListOf<DustParticle>()

    // Reusable Paints
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(85, 10, 15, 25)
        style = Paint.Style.FILL
    }

    private val skinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 219, 188)
        style = Paint.Style.FILL
    }

    private val hairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(75, 45, 25)
        style = Paint.Style.FILL
    }

    private val capPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(33, 115, 240) // Vibrant cobalt blue
        style = Paint.Style.FILL
    }

    private val capVisorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 80, 190)
        style = Paint.Style.FILL
    }

    private val jacketPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(245, 95, 45) // Coral/Orange stylish jacket
        style = Paint.Style.FILL
    }

    private val jacketTrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val bagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(139, 90, 43) // Leather satchel
        style = Paint.Style.FILL
    }

    private val pantsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(40, 60, 95) // Dark denim
        style = Paint.Style.FILL
    }

    private val bootsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(55, 35, 20) // Leather boots
        style = Paint.Style.FILL
    }

    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(30, 30, 40)
        style = Paint.Style.FILL
    }

    private val dustPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 200, 195, 185)
        style = Paint.Style.FILL
    }

    data class DustParticle(
        var px: Float,
        var py: Float,
        var vx: Float,
        var vy: Float,
        var life: Float = 0.4f,
        val maxLife: Float = 0.4f,
        var radius: Float = 4f
    )

    fun update(
        deltaTime: Float,
        inputDirX: Float,
        inputDirY: Float,
        inputIntensity: Float,
        collisionSystem: CollisionSystem
    ) {
        // Update idle / walk animations
        idleTimer += deltaTime

        val hasInput = inputIntensity > 0.05f && (inputDirX != 0f || inputDirY != 0f)

        if (hasInput) {
            // Target velocity from joystick
            val targetVx = inputDirX * maxSpeed * inputIntensity
            val targetVy = inputDirY * maxSpeed * inputIntensity

            // Accelerate towards target velocity
            val accelStep = acceleration * deltaTime
            vx = moveTowards(vx, targetVx, accelStep)
            vy = moveTowards(vy, targetVy, accelStep)

            // Update direction based on primary input axis
            if (abs(inputDirX) > abs(inputDirY)) {
                direction = if (inputDirX > 0f) PlayerDirection.EAST else PlayerDirection.WEST
            } else {
                direction = if (inputDirY > 0f) PlayerDirection.SOUTH else PlayerDirection.NORTH
            }
        } else {
            // Decelerate with friction
            val frictionStep = friction * deltaTime
            vx = moveTowards(vx, 0f, frictionStep)
            vy = moveTowards(vy, 0f, frictionStep)
        }

        val speed = hypot(vx, vy)
        isMoving = speed > 10f

        if (isMoving) {
            walkCycle += deltaTime * (speed / 18f)

            // Spawn footstep dust particles
            dustSpawnTimer += deltaTime
            if (dustSpawnTimer > 0.12f) {
                dustSpawnTimer = 0f
                dustParticles.add(
                    DustParticle(
                        px = x + (Math.random().toFloat() - 0.5f) * 12f,
                        py = y + 4f,
                        vx = -vx * 0.1f + (Math.random().toFloat() - 0.5f) * 15f,
                        vy = -vy * 0.1f - (Math.random().toFloat() * 10f),
                        radius = (3f + Math.random().toFloat() * 3f)
                    )
                )
            }
        } else {
            // Smoothly align walk cycle back towards 0 when stopping
            walkCycle = moveTowards(walkCycle, 0f, deltaTime * 6f)
        }

        // Apply movement with solid obstacle collision resolution
        val targetX = x + vx * deltaTime
        val targetY = y + vy * deltaTime

        val resolved = collisionSystem.resolveMovement(
            currentX = x,
            currentY = y,
            targetX = targetX,
            targetY = targetY,
            halfWidth = colliderHalfWidth,
            halfHeight = colliderHalfHeight
        )

        // If collision stopped movement along an axis, zero out that velocity
        if (resolved.x == x && targetX != x) vx = 0f
        if (resolved.y == y && targetY != y) vy = 0f

        x = resolved.x
        y = resolved.y

        // Update dust particles
        val iterator = dustParticles.iterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.life -= deltaTime
            p.px += p.vx * deltaTime
            p.py += p.vy * deltaTime
            p.radius += deltaTime * 2f
            if (p.life <= 0f) {
                iterator.remove()
            }
        }
    }

    private fun moveTowards(current: Float, target: Float, maxDelta: Float): Float {
        return if (abs(target - current) <= maxDelta) {
            target
        } else {
            current + kotlin.math.sign(target - current) * maxDelta
        }
    }

    fun render(canvas: Canvas) {
        // Render dust particles behind player
        for (p in dustParticles) {
            val alpha = (p.life / p.maxLife * 120).toInt().coerceIn(0, 150)
            dustPaint.alpha = alpha
            canvas.drawCircle(p.px, p.py, p.radius, dustPaint)
        }

        canvas.save()
        canvas.translate(x, y)

        // 1. Soft oval drop shadow
        val shadowScale = if (isMoving) 1f + sin(walkCycle * 2f) * 0.08f else 1f + sin(idleTimer * 3f) * 0.04f
        val shadowRect = RectF(-16f * shadowScale, -4f, 16f * shadowScale, 6f)
        canvas.drawOval(shadowRect, shadowPaint)

        // Bobbing vertical offset
        val bob = if (isMoving) abs(sin(walkCycle)) * 4f else sin(idleTimer * 3.5f) * 1.5f

        // Draw character according to facing direction
        when (direction) {
            PlayerDirection.SOUTH -> renderFacingSouth(canvas, bob)
            PlayerDirection.NORTH -> renderFacingNorth(canvas, bob)
            PlayerDirection.EAST -> renderFacingSide(canvas, bob, isFlipped = false)
            PlayerDirection.WEST -> renderFacingSide(canvas, bob, isFlipped = true)
        }

        canvas.restore()
    }

    private fun renderFacingSouth(canvas: Canvas, bob: Float) {
        val legStep = if (isMoving) sin(walkCycle) * 8f else 0f
        val armSwing = if (isMoving) sin(walkCycle) * 7f else 0f

        // 2. Boots / Feet
        // Left foot
        canvas.drawRoundRect(
            RectF(-12f, -bob + legStep - 4f, -4f, -bob + legStep + 5f),
            3f, 3f, bootsPaint
        )
        // Right foot
        canvas.drawRoundRect(
            RectF(4f, -bob - legStep - 4f, 12f, -bob - legStep + 5f),
            3f, 3f, bootsPaint
        )

        // 3. Pants / Legs
        canvas.drawRoundRect(
            RectF(-11f, -bob - 14f, -4f, -bob - 2f),
            2f, 2f, pantsPaint
        )
        canvas.drawRoundRect(
            RectF(4f, -bob - 14f, 11f, -bob - 2f),
            2f, 2f, pantsPaint
        )

        // 4. Torso / Jacket
        val torsoRect = RectF(-13f, -bob - 29f, 13f, -bob - 13f)
        canvas.drawRoundRect(torsoRect, 4f, 4f, jacketPaint)

        // Zipper / Trim line down center
        canvas.drawLine(0f, -bob - 28f, 0f, -bob - 13f, jacketTrimPaint)

        // Collar notch
        canvas.drawRoundRect(RectF(-7f, -bob - 30f, 7f, -bob - 26f), 2f, 2f, capVisorPaint)

        // Arms
        // Left arm
        canvas.drawRoundRect(
            RectF(-17f, -bob - 27f + armSwing, -12f, -bob - 16f + armSwing),
            3f, 3f, jacketPaint
        )
        // Right arm
        canvas.drawRoundRect(
            RectF(12f, -bob - 27f - armSwing, 17f, -bob - 16f - armSwing),
            3f, 3f, jacketPaint
        )

        // 5. Head
        val headY = -bob - 37f
        canvas.drawCircle(0f, headY, 11f, skinPaint)

        // Hair fringes
        canvas.drawArc(RectF(-11f, headY - 11f, 11f, headY + 3f), 180f, 180f, true, hairPaint)

        // Eyes
        canvas.drawCircle(-4.5f, headY - 1f, 1.8f, eyePaint)
        canvas.drawCircle(4.5f, headY - 1f, 1.8f, eyePaint)

        // 6. Cap
        // Cap dome
        canvas.drawArc(RectF(-12f, headY - 14f, 12f, headY - 1f), 170f, 200f, true, capPaint)
        // Cap visor (pointing slightly down in front)
        canvas.drawRoundRect(RectF(-10f, headY - 7f, 10f, headY - 3f), 2f, 2f, capVisorPaint)
        // Cap top button
        canvas.drawCircle(0f, headY - 13f, 2.5f, jacketPaint)
    }

    private fun renderFacingNorth(canvas: Canvas, bob: Float) {
        val legStep = if (isMoving) sin(walkCycle) * 8f else 0f
        val armSwing = if (isMoving) sin(walkCycle) * 7f else 0f

        // Boots
        canvas.drawRoundRect(
            RectF(-12f, -bob - legStep - 4f, -4f, -bob - legStep + 5f),
            3f, 3f, bootsPaint
        )
        canvas.drawRoundRect(
            RectF(4f, -bob + legStep - 4f, 12f, -bob + legStep + 5f),
            3f, 3f, bootsPaint
        )

        // Pants
        canvas.drawRoundRect(RectF(-11f, -bob - 14f, -4f, -bob - 2f), 2f, 2f, pantsPaint)
        canvas.drawRoundRect(RectF(4f, -bob - 14f, 11f, -bob - 2f), 2f, 2f, pantsPaint)

        // Torso / Jacket Back
        val torsoRect = RectF(-13f, -bob - 29f, 13f, -bob - 13f)
        canvas.drawRoundRect(torsoRect, 4f, 4f, jacketPaint)

        // Satchel backpack on back
        canvas.drawRoundRect(RectF(-8f, -bob - 26f, 8f, -bob - 16f), 3f, 3f, bagPaint)

        // Arms
        canvas.drawRoundRect(
            RectF(-17f, -bob - 27f - armSwing, -12f, -bob - 16f - armSwing),
            3f, 3f, jacketPaint
        )
        canvas.drawRoundRect(
            RectF(12f, -bob - 27f + armSwing, 17f, -bob - 16f + armSwing),
            3f, 3f, jacketPaint
        )

        // Head Back
        val headY = -bob - 37f
        canvas.drawCircle(0f, headY, 11f, hairPaint)

        // Turned cap dome
        canvas.drawArc(RectF(-12f, headY - 14f, 12f, headY - 2f), 160f, 220f, true, capPaint)
        // Cap snapback strap
        canvas.drawRoundRect(RectF(-5f, headY - 4f, 5f, headY - 1f), 1.5f, 1.5f, capVisorPaint)
        // Cap top button
        canvas.drawCircle(0f, headY - 13f, 2.5f, jacketPaint)
    }

    private fun renderFacingSide(canvas: Canvas, bob: Float, isFlipped: Boolean) {
        canvas.save()
        if (isFlipped) {
            canvas.scale(-1f, 1f)
        }

        val stride = if (isMoving) sin(walkCycle) * 10f else 0f
        val armSwing = if (isMoving) sin(walkCycle) * 9f else 0f

        // Back leg & boot
        canvas.drawRoundRect(
            RectF(-stride - 5f, -bob - 13f, -stride + 3f, -bob - 2f),
            2f, 2f, pantsPaint
        )
        canvas.drawRoundRect(
            RectF(-stride - 5f, -bob - 4f, -stride + 7f, -bob + 5f),
            3f, 3f, bootsPaint
        )

        // Back arm
        canvas.drawRoundRect(
            RectF(-armSwing - 5f, -bob - 27f, -armSwing + 3f, -bob - 16f),
            3f, 3f, jacketPaint
        )

        // Torso
        val torsoRect = RectF(-9f, -bob - 29f, 9f, -bob - 13f)
        canvas.drawRoundRect(torsoRect, 4f, 4f, jacketPaint)

        // Satchel strap
        val strapPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(110, 70, 30)
            strokeWidth = 3f
        }
        canvas.drawLine(-7f, -bob - 28f, 7f, -bob - 15f, strapPaint)

        // Front leg & boot
        canvas.drawRoundRect(
            RectF(stride - 5f, -bob - 13f, stride + 3f, -bob - 2f),
            2f, 2f, pantsPaint
        )
        canvas.drawRoundRect(
            RectF(stride - 5f, -bob - 4f, stride + 7f, -bob + 5f),
            3f, 3f, bootsPaint
        )

        // Front arm
        canvas.drawRoundRect(
            RectF(armSwing - 4f, -bob - 27f, armSwing + 4f, -bob - 16f),
            3f, 3f, jacketPaint
        )

        // Head
        val headY = -bob - 37f
        canvas.drawCircle(1f, headY, 11f, skinPaint)

        // Hair at back of head
        canvas.drawArc(RectF(-11f, headY - 11f, 1f, headY + 5f), 90f, 180f, true, hairPaint)

        // Eye profile
        canvas.drawCircle(6f, headY - 1.5f, 1.8f, eyePaint)

        // Cap dome
        canvas.drawArc(RectF(-11f, headY - 14f, 12f, headY - 2f), 150f, 240f, true, capPaint)
        // Cap visor extending forward to the right
        canvas.drawRoundRect(RectF(6f, headY - 8f, 17f, headY - 3f), 2.5f, 2.5f, capVisorPaint)
        // Cap button
        canvas.drawCircle(0f, headY - 13f, 2.5f, jacketPaint)

        canvas.restore()
    }
}
