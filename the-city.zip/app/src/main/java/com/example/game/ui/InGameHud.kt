package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.economy.EconomyManager
import com.example.game.interaction.Interactable
import com.example.game.inventory.GameItem
import com.example.game.inventory.Inventory
import kotlin.math.sin

/**
 * Minimalist, polished game HUD rendered cleanly over the top of the game screen.
 * Displays wallet balance, current neighborhood location, inventory count,
 * and interaction status prompts.
 */
class InGameHud(
    val economyManager: EconomyManager,
    val inventory: Inventory
) {
    var currentLocationName: String = "The City"
    var activeInteractable: Interactable? = null

    private var promptPulseTimer: Float = 0f

    // Paints
    private val pillBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 18, 25, 38) // Translucent dark slate
        style = Paint.Style.FILL
    }

    private val pillBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val goldCoinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 205, 50)
        style = Paint.Style.FILL
    }

    private val moneyTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 225, 90)
        textSize = 20f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val locationTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val inventoryTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 240, 255)
        textAlign = Paint.Align.RIGHT
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val promptBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 25, 32, 48)
        style = Paint.Style.FILL
    }

    private val promptBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 140, 40) // Pulsing orange
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val promptTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 245, 230)
        textAlign = Paint.Align.CENTER
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun update(deltaTime: Float) {
        promptPulseTimer += deltaTime * 5f
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float, safeTopInset: Float = 48f) {
        val topY = safeTopInset + 20f

        // 1. Top-Left: Money Chip
        val moneyStr = economyManager.formattedBalance()
        val moneyPillW = 125f
        val pillH = 40f
        val moneyRect = RectF(24f, topY, 24f + moneyPillW, topY + pillH)
        canvas.drawRoundRect(moneyRect, 20f, 20f, pillBgPaint)
        canvas.drawRoundRect(moneyRect, 20f, 20f, pillBorderPaint)

        // Coin icon
        val coinX = moneyRect.left + 22f
        val coinY = moneyRect.centerY()
        canvas.drawCircle(coinX, coinY, 9f, goldCoinPaint)
        val coinHolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(190, 140, 20)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawCircle(coinX, coinY, 6f, coinHolePaint)

        // Money amount text
        canvas.drawText(moneyStr, coinX + 16f, coinY + moneyTextPaint.textSize * 0.35f, moneyTextPaint)

        // 2. Top-Center: Location Pill
        val locTextW = locationTextPaint.measureText(currentLocationName)
        val locPillW = (locTextW + 48f).coerceAtLeast(160f)
        val locLeft = (screenW - locPillW) * 0.5f
        val locRect = RectF(locLeft, topY, locLeft + locPillW, topY + pillH)
        canvas.drawRoundRect(locRect, 20f, 20f, pillBgPaint)
        canvas.drawRoundRect(locRect, 20f, 20f, pillBorderPaint)

        canvas.drawText(currentLocationName, screenW * 0.5f, locRect.centerY() + locationTextPaint.textSize * 0.35f, locationTextPaint)

        // 3. Top-Right: Inventory Badge (shows Food count)
        val foodCount = inventory.getFoodCount()
        val invStr = "🍞 Food: $foodCount"
        val invTextW = inventoryTextPaint.measureText(invStr)
        val invPillW = invTextW + 36f
        val invRight = screenW - 24f
        val invRect = RectF(invRight - invPillW, topY, invRight, topY + pillH)
        canvas.drawRoundRect(invRect, 20f, 20f, pillBgPaint)
        canvas.drawRoundRect(invRect, 20f, 20f, pillBorderPaint)

        canvas.drawText(invStr, invRight - 18f, invRect.centerY() + inventoryTextPaint.textSize * 0.35f, inventoryTextPaint)

        // 4. Proximity Interaction Notification Prompt (Bottom center above controls)
        activeInteractable?.let { interactable ->
            val promptStr = "Near ${interactable.name} • Tap ${interactable.actionLabel}"
            val promptW = promptTextPaint.measureText(promptStr) + 40f
            val promptH = 36f
            val promptY = screenH - 180f
            val promptLeft = (screenW - promptW) * 0.5f

            val promptRect = RectF(promptLeft, promptY, promptLeft + promptW, promptY + promptH)
            canvas.drawRoundRect(promptRect, 18f, 18f, promptBgPaint)

            val pulseAlpha = (140 + sin(promptPulseTimer) * 80).toInt().coerceIn(60, 255)
            promptBorderPaint.alpha = pulseAlpha
            canvas.drawRoundRect(promptRect, 18f, 18f, promptBorderPaint)

            canvas.drawText(promptStr, screenW * 0.5f, promptRect.centerY() + promptTextPaint.textSize * 0.35f, promptTextPaint)
        }
    }
}
