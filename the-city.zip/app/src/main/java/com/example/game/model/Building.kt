package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.physics.RectCollider
import kotlin.math.sin

/**
 * Detailed 2D top-down building entity with stylized vector graphics,
 * storefront signage, awnings, windows, and solid collision box.
 */
class Building(
    val id: String,
    val name: String,
    val type: BuildingType,
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    val entranceX: Float,
    val entranceY: Float,
    val wallColor: Int,
    val roofColor: Int,
    val trimColor: Int,
    val signText: String,
    val signBgColor: Int = Color.rgb(30, 40, 55),
    val signTextColor: Int = Color.WHITE,
    val hasAwning: Boolean = false,
    val awningColor1: Int = Color.WHITE,
    val awningColor2: Int = Color.RED,
    val interactionLabel: String = "ENTER",
    val interactionSubLabel: String = ""
) {
    val right: Float get() = left + width
    val bottom: Float get() = top + height
    val centerX: Float get() = left + width * 0.5f
    val centerY: Float get() = top + height * 0.5f

    // Collision box (covers main structure; entrance area is clear for walking up to door)
    val collider: RectCollider = RectCollider(
        left = left + 4f,
        top = top + 8f,
        right = right - 4f,
        bottom = bottom - 8f,
        tag = id
    )

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(75, 15, 20, 30)
        style = Paint.Style.FILL
    }

    private val wallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = wallColor
        style = Paint.Style.FILL
    }

    private val roofPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = roofColor
        style = Paint.Style.FILL
    }

    private val roofShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 0, 0, 0)
        style = Paint.Style.FILL
    }

    private val trimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = trimColor
        style = Paint.Style.FILL
    }

    private val doorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(90, 55, 30) // Dark wood
        style = Paint.Style.FILL
    }

    private val windowGlassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 220, 240) // Sky reflection
        style = Paint.Style.FILL
    }

    private val windowFramePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val signBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = signBgColor
        style = Paint.Style.FILL
    }

    private val signTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = signTextColor
        textAlign = Paint.Align.CENTER
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val entryMatPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 40, 45, 55)
        style = Paint.Style.FILL
    }

    private var smokeTimer: Float = 0f

    fun update(deltaTime: Float) {
        smokeTimer += deltaTime
    }

    fun render(canvas: Canvas) {
        // 1. Building cast ground shadow (offset towards bottom-right)
        val shadowRect = RectF(left + 8f, top + 15f, right + 18f, bottom + 16f)
        canvas.drawRoundRect(shadowRect, 10f, 10f, shadowPaint)

        // 2. Doorstep / entry mat
        val matW = 44f
        val matH = 16f
        val matRect = RectF(entranceX - matW * 0.5f, bottom - 6f, entranceX + matW * 0.5f, bottom + matH - 6f)
        canvas.drawRoundRect(matRect, 3f, 3f, entryMatPaint)

        // 3. Main building base wall
        val baseRect = RectF(left, top + 35f, right, bottom)
        canvas.drawRoundRect(baseRect, 8f, 8f, wallPaint)

        // Wall plinth base trim
        val plinthRect = RectF(left, bottom - 10f, right, bottom)
        canvas.drawRect(plinthRect, trimPaint)

        // 4. Windows and Doors
        renderWindowsAndDoors(canvas)

        // 5. Roof rendering
        renderRoof(canvas)

        // 6. Awning if applicable (e.g. Grocery Store, Restaurant)
        if (hasAwning) {
            renderAwning(canvas)
        }

        // 7. Storefront Sign
        if (signText.isNotEmpty()) {
            renderSign(canvas)
        }

        // Special building visual features
        when (type) {
            BuildingType.GAS_STATION -> renderGasStationPumps(canvas)
            BuildingType.WORKSHOP -> renderWorkshopDetails(canvas)
            BuildingType.PLAYER_HOME -> renderHomeChimney(canvas)
            else -> {}
        }
    }

    private fun renderWindowsAndDoors(canvas: Canvas) {
        val doorW = 34f
        val doorH = 50f
        val doorX = entranceX - doorW * 0.5f
        val doorY = bottom - doorH

        // Door frame
        canvas.drawRoundRect(RectF(doorX - 2f, doorY - 2f, doorX + doorW + 2f, bottom), 4f, 4f, trimPaint)
        // Door body
        canvas.drawRoundRect(RectF(doorX, doorY, doorX + doorW, bottom), 3f, 3f, doorPaint)

        // Door glass pane
        val doorGlassRect = RectF(doorX + 5f, doorY + 6f, doorX + doorW - 5f, doorY + 24f)
        canvas.drawRoundRect(doorGlassRect, 2f, 2f, windowGlassPaint)
        // Doorknob
        val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(240, 200, 80)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(doorX + doorW - 6f, doorY + 32f, 2.5f, knobPaint)

        // Windows on left and right sides of door
        val winW = 36f
        val winH = 34f
        val winY = bottom - 54f

        val leftWinX = left + 18f
        if (leftWinX + winW < doorX - 10f) {
            val winRect = RectF(leftWinX, winY, leftWinX + winW, winY + winH)
            canvas.drawRoundRect(winRect, 3f, 3f, windowGlassPaint)
            canvas.drawRoundRect(winRect, 3f, 3f, windowFramePaint)
            // Window cross
            canvas.drawLine(leftWinX + winW * 0.5f, winY, leftWinX + winW * 0.5f, winY + winH, windowFramePaint)
            canvas.drawLine(leftWinX, winY + winH * 0.5f, leftWinX + winW, winY + winH * 0.5f, windowFramePaint)
        }

        val rightWinX = right - winW - 18f
        if (rightWinX > doorX + doorW + 10f) {
            val winRect = RectF(rightWinX, winY, rightWinX + winW, winY + winH)
            canvas.drawRoundRect(winRect, 3f, 3f, windowGlassPaint)
            canvas.drawRoundRect(winRect, 3f, 3f, windowFramePaint)
            canvas.drawLine(rightWinX + winW * 0.5f, winY, rightWinX + winW * 0.5f, winY + winH, windowFramePaint)
            canvas.drawLine(rightWinX, winY + winH * 0.5f, rightWinX + winW, winY + winH * 0.5f, windowFramePaint)
        }
    }

    private fun renderRoof(canvas: Canvas) {
        val roofOverhang = 8f
        val roofHeight = 48f
        val roofRect = RectF(left - roofOverhang, top, right + roofOverhang, top + roofHeight)
        canvas.drawRoundRect(roofRect, 6f, 6f, roofPaint)

        // Roof overhang shadow under eaves
        val eaveShadow = RectF(left, top + roofHeight, right, top + roofHeight + 6f)
        canvas.drawRect(eaveShadow, roofShadowPaint)

        // Slanted roof tile lines
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(40, 255, 255, 255)
            strokeWidth = 2f
        }
        val step = 20f
        var xLine = left
        while (xLine < right) {
            canvas.drawLine(xLine, top + 4f, xLine, top + roofHeight - 4f, linePaint)
            xLine += step
        }
    }

    private fun renderAwning(canvas: Canvas) {
        val awningY = bottom - 66f
        val awningH = 22f
        val awningLeft = left + 10f
        val awningRight = right - 10f
        val totalW = awningRight - awningLeft
        val stripeCount = (totalW / 18f).toInt().coerceAtLeast(4)
        val stripeW = totalW / stripeCount

        val p1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = awningColor1 }
        val p2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = awningColor2 }

        for (i in 0 until stripeCount) {
            val sX = awningLeft + i * stripeW
            val stripeRect = RectF(sX, awningY, sX + stripeW, awningY + awningH)
            canvas.drawRect(stripeRect, if (i % 2 == 0) p1 else p2)

            // Scalloped bottom fringe
            val scallopRect = RectF(sX, awningY + awningH - 4f, sX + stripeW, awningY + awningH + 6f)
            canvas.drawOval(scallopRect, if (i % 2 == 0) p1 else p2)
        }

        // Awning shadow
        val awShadow = RectF(awningLeft, awningY + awningH + 4f, awningRight, awningY + awningH + 9f)
        canvas.drawRect(awShadow, roofShadowPaint)
    }

    private fun renderSign(canvas: Canvas) {
        val signW = (width * 0.7f).coerceIn(120f, 220f)
        val signH = 28f
        val signX = centerX - signW * 0.5f
        val signY = top + 14f

        val signRect = RectF(signX, signY, signX + signW, signY + signH)
        // Sign shadow
        canvas.drawRoundRect(RectF(signX + 2f, signY + 2f, signX + signW + 2f, signY + signH + 2f), 4f, 4f, roofShadowPaint)
        // Sign board
        canvas.drawRoundRect(signRect, 4f, 4f, signBgPaint)

        // Sign border
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(180, 255, 255, 255)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(signRect, 4f, 4f, borderPaint)

        // Sign text
        val textY = signY + signH * 0.5f + signTextPaint.textSize * 0.35f
        canvas.drawText(signText, centerX, textY, signTextPaint)
    }

    private fun renderHomeChimney(canvas: Canvas) {
        val chimX = right - 32f
        val chimY = top - 12f
        val chimW = 18f
        val chimH = 26f

        val chimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(160, 60, 45) // Brick red
            style = Paint.Style.FILL
        }
        canvas.drawRect(chimX, chimY, chimX + chimW, chimY + chimH, chimPaint)
        canvas.drawRect(chimX - 3f, chimY - 3f, chimX + chimW + 3f, chimY + 2f, trimPaint)

        // Smoke puff puffs
        val smokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(90, 230, 235, 240)
            style = Paint.Style.FILL
        }
        val t = smokeTimer
        for (i in 0..2) {
            val puffAge = (t * 0.8f + i * 0.7f) % 2.1f
            val puffY = chimY - puffAge * 22f
            val puffX = chimX + chimW * 0.5f + sin(puffAge * 3f) * 6f
            val puffRadius = 5f + puffAge * 4f
            val alpha = ((1f - puffAge / 2.1f) * 80).toInt().coerceIn(0, 90)
            smokePaint.alpha = alpha
            canvas.drawCircle(puffX, puffY, puffRadius, smokePaint)
        }
    }

    private fun renderWorkshopDetails(canvas: Canvas) {
        // Roll-up garage shutter door
        val doorW = 58f
        val doorH = 55f
        val doorX = left + 20f
        val doorY = bottom - doorH

        val shutterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(180, 190, 205)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(doorX, doorY, doorX + doorW, bottom), 4f, 4f, shutterPaint)

        // Horizontal slat lines
        val slatPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(140, 150, 165)
            strokeWidth = 2f
        }
        var yLine = doorY + 6f
        while (yLine < bottom) {
            canvas.drawLine(doorX + 2f, yLine, doorX + doorW - 2f, yLine, slatPaint)
            yLine += 8f
        }

        // Yellow and black caution stripe bar along bottom of shutter
        val stripeH = 8f
        val cautionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(240, 195, 30)
            style = Paint.Style.FILL
        }
        canvas.drawRect(doorX, bottom - stripeH, doorX + doorW, bottom, cautionPaint)
    }

    private fun renderGasStationPumps(canvas: Canvas) {
        // Large gas pump island in front of store
        val islandX = left + 25f
        val islandY = bottom + 35f
        val islandW = width - 50f
        val islandH = 26f

        val islandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(190, 200, 210) // Concrete island curb
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(islandX, islandY, islandX + islandW, islandY + islandH), 10f, 10f, islandPaint)

        // Two gas pumps
        val pumpPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(235, 60, 45) // Bright red gas pumps
            style = Paint.Style.FILL
        }
        val pumpScreenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(40, 45, 50)
            style = Paint.Style.FILL
        }

        val pumpW = 20f
        val pumpH = 34f

        // Pump 1
        val p1X = islandX + 30f
        val p1Y = islandY - 8f
        canvas.drawRoundRect(RectF(p1X, p1Y, p1X + pumpW, p1Y + pumpH), 4f, 4f, pumpPaint)
        canvas.drawRect(p1X + 3f, p1Y + 4f, p1X + pumpW - 3f, p1Y + 12f, pumpScreenPaint)

        // Pump 2
        val p2X = islandX + islandW - 50f
        val p2Y = islandY - 8f
        canvas.drawRoundRect(RectF(p2X, p2Y, p2X + pumpW, p2Y + pumpH), 4f, 4f, pumpPaint)
        canvas.drawRect(p2X + 3f, p2Y + 4f, p2X + pumpW - 3f, p2Y + 12f, pumpScreenPaint)

        // Overhead Canopy roof over fuel island
        val canopyX = islandX - 15f
        val canopyY = islandY - 32f
        val canopyW = islandW + 30f
        val canopyH = 20f
        val canopyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(240, 245, 250)
            style = Paint.Style.FILL
        }
        val canopyBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(235, 60, 45)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(RectF(canopyX, canopyY, canopyX + canopyW, canopyY + canopyH), 4f, 4f, canopyPaint)
        canvas.drawRoundRect(RectF(canopyX, canopyY, canopyX + canopyW, canopyY + canopyH), 4f, 4f, canopyBorder)

        // Canopy support pillars
        val pillarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(100, 110, 125)
            strokeWidth = 6f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawLine(p1X + pumpW * 0.5f, canopyY + canopyH, p1X + pumpW * 0.5f, islandY + 5f, pillarPaint)
        canvas.drawLine(p2X + pumpW * 0.5f, canopyY + canopyH, p2X + pumpW * 0.5f, islandY + 5f, pillarPaint)
    }
}
