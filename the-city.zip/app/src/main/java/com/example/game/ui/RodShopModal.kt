package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.economy.EconomyManager
import com.example.game.fishing.FishingRod

/**
 * Modal dialogue for the Tackle & Rod Shop ("Harbor Rods") where players buy & equip fishing rods.
 * Features responsive card layout, wrapped descriptions, stat badges, and strict clipping.
 */
class RodShopModal(
    val economyManager: EconomyManager,
    var equippedRod: FishingRod,
    val purchasedRods: MutableSet<String>,
    var onRodEquipped: ((FishingRod) -> Unit)? = null,
    var onRodPurchased: ((FishingRod) -> Unit)? = null,
    var onClose: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set

    private val modalRect = RectF()
    private val closeBtnRect = RectF()
    private val rodActionRects = mutableMapOf<String, RectF>()

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 8, 14, 24)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(22, 32, 50)
        style = Paint.Style.FILL
    }

    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(241, 196, 15) // Golden fishing trim
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(32, 46, 72)
        style = Paint.Style.FILL
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 21f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val greetingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 210, 235)
        textAlign = Paint.Align.CENTER
        textSize = 13f
    }

    private val itemBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(15, 24, 38)
        style = Paint.Style.FILL
    }

    private val itemBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private val rodNamePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 225, 110)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val priceTagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(241, 196, 15)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val statBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(78, 205, 196) // Seafoam turquoise
        textSize = 11.5f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val rodDescPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(185, 200, 220)
        textSize = 11f
    }

    private val actionBtnActive = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113)
        style = Paint.Style.FILL
    }

    private val actionBtnEquipped = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(52, 152, 219)
        style = Paint.Style.FILL
    }

    private val actionBtnDisabled = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(65, 75, 90)
        style = Paint.Style.FILL
    }

    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val closeBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 60, 50)
        style = Paint.Style.FILL
    }

    private val walletTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 215, 65)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun open() {
        isOpen = true
    }

    fun close() {
        isOpen = false
        onClose?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false

        // Tap Close button
        if (closeBtnRect.contains(touchX, touchY)) {
            close()
            return true
        }

        // Tap on Rod action buttons
        for (rod in FishingRod.ALL_RODS) {
            val rect = rodActionRects[rod.id] ?: continue
            if (rect.contains(touchX, touchY)) {
                val isOwned = purchasedRods.contains(rod.id)
                val isEquipped = equippedRod.id == rod.id

                if (isEquipped) {
                    return true
                }

                if (isOwned) {
                    equippedRod = rod
                    onRodEquipped?.invoke(rod)
                    return true
                } else {
                    if (economyManager.canAfford(rod.price)) {
                        if (economyManager.spend(rod.price)) {
                            purchasedRods.add(rod.id)
                            equippedRod = rod
                            onRodPurchased?.invoke(rod)
                            onRodEquipped?.invoke(rod)
                        }
                    }
                    return true
                }
            }
        }

        // Tap outside card dismisses
        if (!modalRect.contains(touchX, touchY)) {
            close()
            return true
        }

        return true
    }

    private fun breakTextIntoLines(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (maxWidth <= 20f) return listOf(text)
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val candidate = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(candidate) <= maxWidth) {
                currentLine = candidate
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine)
                }
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine)
        }
        return lines
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        if (!isOpen) return

        val isLandscape = screenW > screenH

        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        // Calculate card size responsive to orientation
        val cardW = if (isLandscape) {
            (screenW * 0.78f).coerceIn(560f, 780f)
        } else {
            (screenW * 0.92f).coerceIn(340f, 520f)
        }

        val cardH = if (isLandscape) {
            (screenH * 0.90f).coerceIn(360f, 440f)
        } else {
            530f.coerceAtMost(screenH * 0.88f)
        }

        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        canvas.drawRoundRect(modalRect, 18f, 18f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBorderPaint)

        // Header
        val headerH = if (isLandscape) 46f else 54f
        val headerRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + headerH)
        canvas.drawRoundRect(headerRect, 18f, 18f, headerPaint)
        canvas.drawRect(cardLeft, cardTop + headerH - 12f, cardLeft + cardW, cardTop + headerH, headerPaint)

        titlePaint.textSize = if (isLandscape) 19f else 22f
        canvas.drawText("🎣 Harbor Tackle & Rods", screenW * 0.5f, cardTop + (headerH * 0.58f), titlePaint)

        // Subtitle greeting
        val greetingY = cardTop + headerH + (if (isLandscape) 14f else 20f)
        canvas.drawText("Upgrade rods to hook faster bites and rare ocean titans!", screenW * 0.5f, greetingY, greetingPaint)

        // Rod items layout calculation
        val footerH = if (isLandscape) 40f else 48f
        val contentTop = greetingY + (if (isLandscape) 8f else 14f)
        val availableH = (cardTop + cardH - footerH) - contentTop
        val itemSpacing = if (isLandscape) 6f else 10f
        val itemH = ((availableH - itemSpacing * 2) / 3f).coerceIn(if (isLandscape) 74f else 96f, 115f)

        val btnW = if (isLandscape) 100f else 95f
        val btnH = if (isLandscape) 32f else 36f

        var currentItemY = contentTop

        for (rod in FishingRod.ALL_RODS) {
            val itemRect = RectF(cardLeft + 14f, currentItemY, cardLeft + cardW - 14f, currentItemY + itemH)

            // Draw item background box
            canvas.drawRoundRect(itemRect, 8f, 8f, itemBoxPaint)
            canvas.drawRoundRect(itemRect, 8f, 8f, itemBorderPaint)

            // Strict clipping to ensure NO text or graphics can ever bleed out of the rod item
            canvas.save()
            canvas.clipRect(itemRect)

            // 1. Icon badge on left
            val iconSize = if (isLandscape) 38f else 44f
            val iconRect = RectF(itemRect.left + 10f, itemRect.centerY() - iconSize * 0.5f, itemRect.left + 10f + iconSize, itemRect.centerY() + iconSize * 0.5f)
            val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = rod.rodColor
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(iconRect, 6f, 6f, iconPaint)
            val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                textSize = if (isLandscape) 20f else 24f
            }
            canvas.drawText("🎣", iconRect.centerX(), iconRect.centerY() + emojiPaint.textSize * 0.35f, emojiPaint)

            // 2. Action Button on right
            val btnRect = RectF(itemRect.right - btnW - 10f, itemRect.centerY() - btnH * 0.5f, itemRect.right - 10f, itemRect.centerY() + btnH * 0.5f)
            rodActionRects[rod.id] = btnRect

            val isOwned = purchasedRods.contains(rod.id)
            val isEquipped = equippedRod.id == rod.id
            val canAfford = economyManager.canAfford(rod.price)

            when {
                isEquipped -> {
                    canvas.drawRoundRect(btnRect, 6f, 6f, actionBtnEquipped)
                    canvas.drawText("EQUIPPED", btnRect.centerX(), btnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)
                }
                isOwned -> {
                    canvas.drawRoundRect(btnRect, 6f, 6f, actionBtnActive)
                    canvas.drawText("EQUIP", btnRect.centerX(), btnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)
                }
                canAfford -> {
                    canvas.drawRoundRect(btnRect, 6f, 6f, actionBtnActive)
                    canvas.drawText("BUY $${rod.price}", btnRect.centerX(), btnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)
                }
                else -> {
                    canvas.drawRoundRect(btnRect, 6f, 6f, actionBtnDisabled)
                    canvas.drawText("BUY $${rod.price}", btnRect.centerX(), btnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)
                }
            }

            // 3. Middle Text Content (Guaranteed bounded inside itemRect)
            val textLeft = iconRect.right + 10f
            val textMaxRight = btnRect.left - 10f
            val maxTextW = (textMaxRight - textLeft).coerceAtLeast(80f)

            // Line 1: Name and Price
            val priceStr = if (rod.price == 0) "Starter" else "$${rod.price}"
            val line1Y = itemRect.top + (if (isLandscape) 18f else 22f)
            canvas.drawText(rod.name, textLeft, line1Y, rodNamePaint)

            val nameW = rodNamePaint.measureText(rod.name)
            if (nameW + 12f + priceTagPaint.measureText("($priceStr)") <= maxTextW) {
                canvas.drawText("• $priceStr", textLeft + nameW + 8f, line1Y, priceTagPaint)
            }

            // Line 2: Stat Badges
            val statsSummary = when (rod.id) {
                FishingRod.WOODEN_ROD.id -> "🎯 Base Zone  ⚡ 1.0x Speed  🍀 Base Luck"
                FishingRod.REINFORCED_ROD.id -> "🎯 +25% Zone  ⚡ 20% Faster  🍀 1.8x Luck"
                FishingRod.MASTER_ROD.id -> "🎯 +50% Zone  ⚡ 40% Faster  🍀 3.2x Legend"
                else -> "🎯 +${(rod.catchZoneBonus * 100).toInt()}% Zone  ⚡ Faster"
            }
            val line2Y = line1Y + (if (isLandscape) 17f else 21f)
            canvas.drawText(statsSummary, textLeft, line2Y, statBadgePaint)

            // Line 3: Description (Wrapped to fit maxTextW)
            val descLines = breakTextIntoLines(rod.description, rodDescPaint, maxTextW)
            var descY = line2Y + (if (isLandscape) 15f else 18f)
            val maxDescLines = if (isLandscape) 1 else 2
            for (lineIdx in 0 until minOf(maxDescLines, descLines.size)) {
                if (descY < itemRect.bottom - 4f) {
                    canvas.drawText(descLines[lineIdx], textLeft, descY, rodDescPaint)
                    descY += 14f
                }
            }

            canvas.restore()

            currentItemY += itemH + itemSpacing
        }

        // Footer: Wallet balance & Close
        val footerY = cardTop + cardH - (if (isLandscape) 18f else 22f)
        canvas.drawText("💰 Wallet: ${economyManager.formattedBalance()}", cardLeft + 20f, footerY, walletTextPaint)

        closeBtnRect.set(cardLeft + cardW - 105f, footerY - 22f, cardLeft + cardW - 18f, footerY + 12f)
        canvas.drawRoundRect(closeBtnRect, 8f, 8f, closeBtnPaint)
        canvas.drawText("CLOSE", closeBtnRect.centerX(), closeBtnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)
    }
}
