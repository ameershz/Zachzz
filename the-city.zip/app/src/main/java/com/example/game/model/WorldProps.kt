package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.example.game.physics.RectCollider
import kotlin.math.sin

/**
 * Environmental decorative and solid props (Trees, Streetlamps, Benches, Fountain, Cars, Fences).
 */

class Tree(
    val x: Float,
    val y: Float,
    val size: Float = 38f
) {
    val collider: RectCollider = RectCollider(
        left = x - 10f,
        top = y - 8f,
        right = x + 10f,
        bottom = y + 10f,
        tag = "tree"
    )

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 10, 20, 15)
        style = Paint.Style.FILL
    }

    private val trunkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(105, 65, 35)
        style = Paint.Style.FILL
    }

    private val canopyDarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(42, 135, 68) // Deep foliage
        style = Paint.Style.FILL
    }

    private val canopyLightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(65, 175, 88) // Highlight foliage
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        // Drop shadow
        val shadowRect = RectF(x - size * 0.9f, y - size * 0.1f, x + size * 1.1f, y + size * 0.5f)
        canvas.drawOval(shadowRect, shadowPaint)

        // Trunk
        val trunkRect = RectF(x - 7f, y - 10f, x + 7f, y + 10f)
        canvas.drawRoundRect(trunkRect, 3f, 3f, trunkPaint)

        // Canopy base layer
        canvas.drawCircle(x, y - 24f, size, canopyDarkPaint)

        // Overlapping leafy puffs
        canvas.drawCircle(x - size * 0.35f, y - 30f, size * 0.65f, canopyLightPaint)
        canvas.drawCircle(x + size * 0.3f, y - 28f, size * 0.6f, canopyDarkPaint)
        canvas.drawCircle(x, y - 36f, size * 0.7f, canopyLightPaint)

        // Subtle top leaf highlight
        val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(90, 160, 235, 120)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(x - size * 0.15f, y - 40f, size * 0.35f, highlightPaint)
    }
}

class StreetLamp(
    val x: Float,
    val y: Float
) {
    val collider: RectCollider = RectCollider(
        left = x - 6f,
        top = y - 6f,
        right = x + 6f,
        bottom = y + 6f,
        tag = "lamp"
    )

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 0, 0, 0)
        style = Paint.Style.FILL
    }

    private val polePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(50, 55, 65) // Cast iron
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
    }

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(40, 45, 55)
        style = Paint.Style.FILL
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(40, 255, 235, 150) // Warm lamp glow halo on ground
        style = Paint.Style.FILL
    }

    private val lanternPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 245, 180) // Glowing lantern bulb
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        // Ground light pool halo
        canvas.drawCircle(x, y + 5f, 48f, glowPaint)

        // Drop shadow for pole
        canvas.drawLine(x, y, x + 16f, y + 10f, shadowPaint)

        // Pole base
        canvas.drawRoundRect(RectF(x - 6f, y - 4f, x + 6f, y + 5f), 2f, 2f, basePaint)

        // Vertical post
        canvas.drawLine(x, y, x, y - 44f, polePaint)

        // Cross bracket arm
        canvas.drawLine(x - 8f, y - 42f, x + 8f, y - 42f, polePaint)

        // Lantern head
        val lanternRect = RectF(x - 5f, y - 50f, x + 5f, y - 40f)
        canvas.drawRoundRect(lanternRect, 2f, 2f, lanternPaint)
        canvas.drawCircle(x, y - 45f, 3f, lanternPaint)
    }
}

class ParkBench(
    val x: Float,
    val y: Float,
    val isHorizontal: Boolean = true
) {
    val collider: RectCollider = if (isHorizontal) {
        RectCollider(x - 20f, y - 8f, x + 20f, y + 8f, tag = "bench")
    } else {
        RectCollider(x - 8f, y - 20f, x + 8f, y + 20f, tag = "bench")
    }

    private val woodPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(155, 95, 45) // Teak wood slats
        style = Paint.Style.FILL
    }

    private val ironPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(40, 45, 50)
        style = Paint.Style.FILL
    }

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 0, 0, 0)
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        if (isHorizontal) {
            canvas.drawRoundRect(RectF(x - 22f, y - 4f, x + 24f, y + 10f), 3f, 3f, shadowPaint)
            // Iron legs
            canvas.drawRect(x - 18f, y - 7f, x - 15f, y + 7f, ironPaint)
            canvas.drawRect(x + 15f, y - 7f, x + 18f, y + 7f, ironPaint)
            // Slats
            canvas.drawRoundRect(RectF(x - 20f, y - 7f, x + 20f, y - 2f), 2f, 2f, woodPaint)
            canvas.drawRoundRect(RectF(x - 20f, y + 1f, x + 20f, y + 6f), 2f, 2f, woodPaint)
        } else {
            canvas.drawRoundRect(RectF(x - 4f, y - 22f, x + 10f, y + 24f), 3f, 3f, shadowPaint)
            canvas.drawRect(x - 7f, y - 18f, x + 7f, y - 15f, ironPaint)
            canvas.drawRect(x - 7f, y + 15f, x + 7f, y + 18f, ironPaint)
            canvas.drawRoundRect(RectF(x - 7f, y - 20f, x - 2f, y + 20f), 2f, 2f, woodPaint)
            canvas.drawRoundRect(RectF(x + 1f, y - 20f, x + 6f, y + 20f), 2f, 2f, woodPaint)
        }
    }
}

class Fountain(
    val x: Float,
    val y: Float,
    val radius: Float = 55f
) {
    val collider: RectCollider = RectCollider(
        left = x - radius * 0.85f,
        top = y - radius * 0.85f,
        right = x + radius * 0.85f,
        bottom = y + radius * 0.85f,
        tag = "fountain"
    )

    private val stonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 185, 195)
        style = Paint.Style.FILL
    }

    private val stoneRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(140, 145, 155)
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(65, 160, 225) // Vibrant sparkling pool
        style = Paint.Style.FILL
    }

    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val centerJetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 255, 255)
        style = Paint.Style.FILL
    }

    private var rippleTimer: Float = 0f

    fun update(deltaTime: Float) {
        rippleTimer += deltaTime
    }

    fun render(canvas: Canvas) {
        // Outer stone basin
        canvas.drawCircle(x, y, radius, stonePaint)
        canvas.drawCircle(x, y, radius, stoneRimPaint)

        // Water basin
        val waterRadius = radius - 6f
        canvas.drawCircle(x, y, waterRadius, waterPaint)

        // Animated water ripples
        for (i in 0..2) {
            val progress = (rippleTimer * 0.7f + i * 0.33f) % 1f
            val r = progress * (waterRadius - 10f) + 8f
            val alpha = ((1f - progress) * 140).toInt().coerceIn(0, 140)
            ripplePaint.alpha = alpha
            canvas.drawCircle(x, y, r, ripplePaint)
        }

        // Center pedestal
        canvas.drawCircle(x, y, 14f, stonePaint)
        canvas.drawCircle(x, y, 14f, stoneRimPaint)

        // Water jet spray
        val jetPulse = sin(rippleTimer * 6f) * 2f
        canvas.drawCircle(x, y, 6f + jetPulse, centerJetPaint)
    }
}

class ParkedCar(
    val x: Float,
    val y: Float,
    val color: Int,
    val isHorizontal: Boolean = true
) {
    val collider: RectCollider = if (isHorizontal) {
        RectCollider(x - 38f, y - 18f, x + 38f, y + 18f, tag = "car")
    } else {
        RectCollider(x - 18f, y - 38f, x + 18f, y + 38f, tag = "car")
    }

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 0, 0, 0)
        style = Paint.Style.FILL
    }

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.FILL
    }

    private val glassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.rgb(70, 95, 115) // Tinted windshield
        style = Paint.Style.FILL
    }

    private val roofPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        // Slightly darker tint of car color
        val r = (Color.red(color) * 0.85f).toInt()
        val g = (Color.green(color) * 0.85f).toInt()
        val b = (Color.blue(color) * 0.85f).toInt()
        this.color = Color.rgb(r, g, b)
        style = Paint.Style.FILL
    }

    private val headlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.rgb(255, 245, 180)
        style = Paint.Style.FILL
    }

    private val taillightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = Color.rgb(220, 40, 30)
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        if (isHorizontal) {
            // Shadow
            canvas.drawRoundRect(RectF(x - 39f, y - 16f, x + 41f, y + 22f), 8f, 8f, shadowPaint)
            // Car body
            val carRect = RectF(x - 38f, y - 18f, x + 38f, y + 18f)
            canvas.drawRoundRect(carRect, 8f, 8f, bodyPaint)
            // Windshield and rear glass
            canvas.drawRoundRect(RectF(x - 22f, y - 14f, x + 22f, y + 14f), 5f, 5f, glassPaint)
            // Roof
            canvas.drawRoundRect(RectF(x - 14f, y - 12f, x + 14f, y + 12f), 4f, 4f, roofPaint)
            // Headlights (Right side front)
            canvas.drawCircle(x + 36f, y - 11f, 3f, headlightPaint)
            canvas.drawCircle(x + 36f, y + 11f, 3f, headlightPaint)
            // Taillights (Left side rear)
            canvas.drawCircle(x - 36f, y - 11f, 3f, taillightPaint)
            canvas.drawCircle(x - 36f, y + 11f, 3f, taillightPaint)
        } else {
            // Shadow
            canvas.drawRoundRect(RectF(x - 16f, y - 39f, x + 22f, y + 41f), 8f, 8f, shadowPaint)
            // Car body
            val carRect = RectF(x - 18f, y - 38f, x + 18f, y + 38f)
            canvas.drawRoundRect(carRect, 8f, 8f, bodyPaint)
            // Glass
            canvas.drawRoundRect(RectF(x - 14f, y - 22f, x + 14f, y + 22f), 5f, 5f, glassPaint)
            // Roof
            canvas.drawRoundRect(RectF(x - 12f, y - 14f, x + 12f, y + 14f), 4f, 4f, roofPaint)
            // Headlights (Bottom front)
            canvas.drawCircle(x - 11f, y + 36f, 3f, headlightPaint)
            canvas.drawCircle(x + 11f, y + 36f, 3f, headlightPaint)
            // Taillights (Top rear)
            canvas.drawCircle(x - 11f, y - 36f, 3f, taillightPaint)
            canvas.drawCircle(x + 11f, y - 36f, 3f, taillightPaint)
        }
    }
}

class FireHydrant(
    val x: Float,
    val y: Float
) {
    val collider: RectCollider = RectCollider(x - 6f, y - 6f, x + 6f, y + 6f, tag = "hydrant")

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(50, 0, 0, 0)
        style = Paint.Style.FILL
    }
    private val redPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(225, 45, 35)
        style = Paint.Style.FILL
    }
    private val brassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(230, 195, 75)
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        canvas.drawOval(RectF(x - 6f, y, x + 8f, y + 6f), shadowPaint)
        canvas.drawRoundRect(RectF(x - 5f, y - 14f, x + 5f, y + 2f), 2f, 2f, redPaint)
        // Side nozzle caps
        canvas.drawCircle(x - 6f, y - 6f, 2.5f, brassPaint)
        canvas.drawCircle(x + 6f, y - 6f, 2.5f, brassPaint)
        // Top cap
        canvas.drawCircle(x, y - 14f, 3f, brassPaint)
    }
}
