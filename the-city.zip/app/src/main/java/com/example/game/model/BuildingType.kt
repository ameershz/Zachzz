package com.example.game.model

enum class BuildingType {
    PLAYER_HOME,
    GROCERY_STORE,
    RESTAURANT,
    WORKSHOP,
    GAS_STATION,
    DECORATIVE_HOUSE_A,
    DECORATIVE_HOUSE_B,
    DECORATIVE_HOUSE_C,
    TOWN_HALL
}
