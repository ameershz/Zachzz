package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.game.economy.EconomyManager
import com.example.game.inventory.GameItem
import com.example.game.inventory.Inventory
import com.example.game.physics.CollisionSystem
import com.example.game.physics.RectCollider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("The City", appName)
    }

    @Test
    fun `economy manager starts with 100 dollars and handles transactions`() {
        val economy = EconomyManager(100)
        assertEquals(100, economy.money)
        assertEquals("$100", economy.formattedBalance())

        assertTrue(economy.canAfford(10))
        assertTrue(economy.spend(10))
        assertEquals(90, economy.money)

        assertFalse(economy.canAfford(150))
        assertFalse(economy.spend(150))
        assertEquals(90, economy.money)
    }

    @Test
    fun `inventory adds and counts food items correctly`() {
        val inventory = Inventory()
        assertEquals(0, inventory.getFoodCount())

        inventory.addItem(GameItem.FOOD, 1)
        assertEquals(1, inventory.getFoodCount())

        inventory.addItem(GameItem.FOOD, 2)
        assertEquals(3, inventory.getFoodCount())
    }

    @Test
    fun `collision system resolves movement without sticking to obstacles`() {
        val collisionSystem = CollisionSystem()
        collisionSystem.worldBounds = RectCollider(0f, 0f, 1000f, 1000f)

        // Add a solid building obstacle at (200, 200, 400, 400)
        collisionSystem.addCollider(RectCollider(200f, 200f, 400f, 400f))

        // Moving towards the obstacle from x=150 should stop at barrier or slide
        val resolved = collisionSystem.resolveMovement(
            currentX = 180f,
            currentY = 250f,
            targetX = 210f, // would penetrate
            targetY = 260f,
            halfWidth = 10f,
            halfHeight = 10f
        )

        // X should not enter the box (resolved.x stays at 180f), while Y is allowed to slide to 260f
        assertEquals(180f, resolved.x, 0.1f)
        assertEquals(260f, resolved.y, 0.1f)
    }
}
