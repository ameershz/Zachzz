package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var mediaProjectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        setContent {
            MyApplicationTheme {
                MainScreen(
                    onStartServiceWithToken = { resultCode, data, srcLang, targetLang ->
                        startFloatService(resultCode, data, srcLang, targetLang)
                    },
                    onStopService = {
                        stopFloatService()
                    },
                    getMediaProjectionIntent = {
                        mediaProjectionManager.createScreenCaptureIntent()
                    }
                )
            }
        }
    }

    private fun startFloatService(resultCode: Int, data: Intent, srcLang: String, targetLang: String) {
        val serviceIntent = Intent(this, FloatService::class.java).apply {
            putExtra(FloatService.EXTRA_RESULT_CODE, resultCode)
            putExtra(FloatService.EXTRA_RESULT_DATA, data)
            putExtra(FloatService.EXTRA_SOURCE_LANG, srcLang)
            putExtra(FloatService.EXTRA_TARGET_LANG, targetLang)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "تم تشغيل الفقاعة العائمة بنجاح! يمكنك الآن التنقل لأي تطبيق", Toast.LENGTH_LONG).show()
    }

    private fun stopFloatService() {
        val stopIntent = Intent(this, FloatService::class.java).apply {
            action = FloatService.ACTION_STOP_SERVICE
        }
        startService(stopIntent)
        Toast.makeText(this, "تم إيقاف الفقاعة العائمة", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onStartServiceWithToken: (Int, Intent, String, String) -> Unit,
    onStopService: () -> Unit,
    getMediaProjectionIntent: () -> Intent
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    // Permissions state
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }
    var isServiceRunning by remember { mutableStateOf(FloatService.isRunning) }

    // Selected Languages
    var sourceLang by remember { mutableStateOf("auto") }
    var targetLang by remember { mutableStateOf("ar") }

    // ML Kit On-Device Model Download Status
    val downloadStatus by TranslationHelper.downloadStatus.collectAsState()

    // Trigger initial language model check/download on startup
    LaunchedEffect(Unit) {
        TranslationHelper.initAndDownloadModels(context)
    }

    // Recheck permissions on resume
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = Settings.canDrawOverlays(context)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    hasNotificationPermission = ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_GRANTED
                }
                isServiceRunning = FloatService.isRunning
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Overlay Activity Result Launcher
    val overlayLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        hasOverlayPermission = Settings.canDrawOverlays(context)
    }

    // Notification Permission Launcher
    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasNotificationPermission = isGranted
    }

    // MediaProjection Activity Result Launcher
    val projectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            onStartServiceWithToken(result.resultCode, result.data!!, sourceLang, targetLang)
            isServiceRunning = true
        } else {
            Toast.makeText(context, "تم إلغاء إذن التقاط الشاشة", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF0284C7), Color(0xFF0F172A))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = "Translator",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "مترجم الشاشة العائم",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Floating Screen Translator",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Service Status Card
            ServiceStatusCard(
                isRunning = isServiceRunning,
                hasOverlayPermission = hasOverlayPermission,
                hasNotificationPermission = hasNotificationPermission,
                onStartClicked = {
                    if (!hasOverlayPermission) {
                        Toast.makeText(context, "يرجى تفعيل صلاحية الظهور فوق التطبيقات أولاً", Toast.LENGTH_SHORT).show()
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        overlayLauncher.launch(intent)
                        return@ServiceStatusCard
                    }
                    if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        return@ServiceStatusCard
                    }
                    // Request Screen Capture Token
                    projectionLauncher.launch(getMediaProjectionIntent())
                },
                onStopClicked = {
                    onStopService()
                    isServiceRunning = false
                }
            )

            // ML Kit On-Device Translation Model Status Card
            LanguageModelStatusCard(
                status = downloadStatus,
                onRetry = {
                    TranslationHelper.initAndDownloadModels(context, force = true)
                }
            )

            // Permissions Card
            PermissionsCard(
                hasOverlayPermission = hasOverlayPermission,
                hasNotificationPermission = hasNotificationPermission,
                onRequestOverlay = {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    overlayLauncher.launch(intent)
                },
                onRequestNotification = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            )

            // Language Selection Card
            LanguageSelectionCard(
                sourceLang = sourceLang,
                targetLang = targetLang,
                onSwap = {
                    val temp = if (sourceLang == "auto") "en" else sourceLang
                    sourceLang = targetLang
                    targetLang = temp
                },
                onSourceChange = { sourceLang = it },
                onTargetChange = { targetLang = it }
            )

            // Orientation Fix Feature Information Card
            OrientationFixCard()

            // Live On-Screen Test Card (User can tap the floating bubble right on this screen!)
            LiveTestCard()

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun ServiceStatusCard(
    isRunning: Boolean,
    hasOverlayPermission: Boolean,
    hasNotificationPermission: Boolean,
    onStartClicked: () -> Unit,
    onStopClicked: () -> Unit
) {
    val statusBg by animateColorAsState(
        targetValue = if (isRunning) Color(0xFF065F46) else MaterialTheme.colorScheme.surfaceVariant,
        label = "statusBg"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("service_status_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = statusBg)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(if (isRunning) Color(0xFF10B981) else Color(0xFF94A3B8))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRunning) "الفقاعة العائمة نشطة" else "الفقاعة متوقفة",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (isRunning) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = if (isRunning) "Foreground Service ON" else "OFF",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (isRunning) Color(0xFF6EE7B7) else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = if (isRunning) {
                    "الفقاعة العائمة تظهر الآن فوق كافة التطبيقات. المس الفقاعة في أي وقت لالتقاط الشاشة وترجمة النصوص فورياً."
                } else {
                    "قم بتشغيل الخدمة لتبدأ الفقاعة في الظهور فوق الشاشة. ميزة الدوران الذكية تضمن عدم خروج الفقاعة من الشاشة عند التدوير."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = if (isRunning) Color(0xFFE2E8F0) else MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (!isRunning) {
                Button(
                    onClick = onStartClicked,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_start_service"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0284C7)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تشغيل مترجم الشاشة العائم",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            } else {
                Button(
                    onClick = onStopClicked,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("btn_stop_service"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDC2626)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "إيقاف الخدمة العائمة",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
fun PermissionsCard(
    hasOverlayPermission: Boolean,
    hasNotificationPermission: Boolean,
    onRequestOverlay: () -> Unit,
    onRequestNotification: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "صلاحيات النظام المطلوبة",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            // Overlay Permission Row
            PermissionItem(
                title = "الظهور فوق التطبيقات (Overlay)",
                description = "مطلوبة لعرض الفقاعة العائمة ونافذة الترجمة المنبثقة",
                isGranted = hasOverlayPermission,
                onRequest = onRequestOverlay
            )

            // Notification Permission Row
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                PermissionItem(
                    title = "إشعارات الخدمة (Notification)",
                    description = "مطلوبة لعمل Foreground Service بنوع MediaProjection",
                    isGranted = hasNotificationPermission,
                    onRequest = onRequestNotification
                )
            }
        }
    }
}

@Composable
fun PermissionItem(
    title: String,
    description: String,
    isGranted: Boolean,
    onRequest: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (isGranted) Color(0xFF10B981) else Color(0xFFF59E0B),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (isGranted) {
            Text(
                text = "مفعلة ✓",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFF10B981)
            )
        } else {
            Button(
                onClick = onRequest,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("منح الإذن", fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun LanguageSelectionCard(
    sourceLang: String,
    targetLang: String,
    onSwap: () -> Unit,
    onSourceChange: (String) -> Unit,
    onTargetChange: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "لغات الترجمة الفورية",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Source Language Box
                LanguageBox(
                    label = "من (Source):",
                    languageCode = sourceLang,
                    displayName = if (sourceLang == "auto") "تلقائي (Auto)" else sourceLang.uppercase(),
                    modifier = Modifier.weight(1f)
                )

                // Swap Button
                IconButton(
                    onClick = onSwap,
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = "Swap Languages",
                        tint = Color(0xFF0284C7)
                    )
                }

                // Target Language Box
                LanguageBox(
                    label = "إلى (Target):",
                    languageCode = targetLang,
                    displayName = if (targetLang == "ar") "العربية (AR)" else targetLang.uppercase(),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun LanguageBox(
    label: String,
    languageCode: String,
    displayName: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .padding(10.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = displayName,
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
            color = Color(0xFF0284C7)
        )
    }
}

@Composable
fun OrientationFixCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ScreenShare,
                    contentDescription = null,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "معمارية معالجة الدوران الذكية (Point Fix)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            Text(
                text = "يستخدم التطبيق دالة مساعدة متقدمة تجلب أبعاد الشاشة الحقيقية عبر Point(x, y) من WindowManager، وتنفذ مقارنة يدوية صارمة (if (x < y)) لتحديد الوضع العمودي والأفقي ديناميكياً. يتيح ذلك تقييد حركة الفقاعة ضمن حدود السحب الحقيقية وتحديث إحداثياتها فور تدوير الشاشة بدون فقدانها.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun LiveTestCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFA800))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "منطقة اختبار الترجمة الحية فوق النص",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            Text(
                text = "جرب النقر على الفقاعة العائمة الآن! ستلاحظ ظهور الترجمة مباشرة كطبقة عائمة تغطي النص الأصلي بالكامل دون فتح أي بطاقة أو نافذة خارجية:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F172A))
                    .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Sample English Article for In-Place Translation",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFF38BDF8)
                )

                Text(
                    text = "Welcome to the real-time screen translator. This application allows you to read foreign articles, messages, and social media posts seamlessly.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFF1F5F9)
                )

                Text(
                    text = "Features included:\n• Dynamic screen orientation boundary fix\n• In-place text overlay directly matching screen coordinates\n• Offline and online translation with text-to-speech",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFCBD5E1)
                )
            }

            Text(
                text = "نصيحة: انقر على أي نص مترجم لنسخه وسماعه، أو انقر على [✕ إغلاق الترجمة] لإخفاء الطبقة.",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF10B981)
            )
        }
    }
}

@Composable
fun LanguageModelStatusCard(
    status: ModelDownloadStatus,
    onRetry: () -> Unit
) {
    val containerBg = when (status) {
        is ModelDownloadStatus.Ready -> Color(0xFF064E3B)
        is ModelDownloadStatus.Downloading -> Color(0xFF1E293B)
        is ModelDownloadStatus.Error -> Color(0xFF450A0A)
        else -> MaterialTheme.colorScheme.surfaceVariant
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("model_status_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = containerBg)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = when (status) {
                            is ModelDownloadStatus.Ready -> Icons.Default.CheckCircle
                            is ModelDownloadStatus.Downloading -> Icons.Default.CloudDownload
                            is ModelDownloadStatus.Error -> Icons.Default.Warning
                            else -> Icons.Default.Translate
                        },
                        contentDescription = "Model Status",
                        tint = when (status) {
                            is ModelDownloadStatus.Ready -> Color(0xFF34D399)
                            is ModelDownloadStatus.Downloading -> Color(0xFF38BDF8)
                            is ModelDownloadStatus.Error -> Color(0xFFF87171)
                            else -> MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "محرك الترجمة على الجهاز (On-Device ML Kit)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        Text(
                            text = when (status) {
                                is ModelDownloadStatus.Ready -> "حزم اللغات مثبّتة ومكتملة (English & Arabic)"
                                is ModelDownloadStatus.Downloading -> "جاري تحميل حزمتي اللغات لمرة واحدة..."
                                is ModelDownloadStatus.Checking -> "جاري التحقق من توفر الحزم..."
                                is ModelDownloadStatus.Error -> "فشل تحميل حزم الترجمة"
                                is ModelDownloadStatus.Idle -> "الحزم بحاجة للتحميل لمرة واحدة"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFE2E8F0)
                        )
                    }
                }

                if (status is ModelDownloadStatus.Error || status is ModelDownloadStatus.Idle) {
                    IconButton(onClick = onRetry) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Retry",
                            tint = Color.White
                        )
                    }
                }
            }

            when (status) {
                is ModelDownloadStatus.Downloading -> {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp)),
                        color = Color(0xFF38BDF8),
                        trackColor = Color(0xFF334155)
                    )
                    Text(
                        text = "يتم تحميل الحزمتين لمرة واحدة فقط (حوالي 30 ميجابايت) لتمكين الترجمة الفورية بالكامل دون إنترنت.",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF94A3B8)
                    )
                }
                is ModelDownloadStatus.Ready -> {
                    Text(
                        text = "✓ الترجمة تعمل محلياً 100% داخل المعالج، بخصوصية تامة وسرعة فائقة وبدون استهلاك للإنترنت.",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFA7F3D0)
                    )
                }
                is ModelDownloadStatus.Error -> {
                    Text(
                        text = status.message,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFFFCA5A5)
                    )
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إعادة محاولة التحميل الآن")
                    }
                }
                else -> Unit
            }
        }
    }
}
