package com.example.data.remote

import com.example.aicore.knowledge.KnowledgeManager
import com.example.aicore.memory.MemoryManager
import com.example.aicore.model.ModelManager
import com.example.aicore.personality.PersonalityManager
import com.example.aicore.personality.PersonalityStyle
import com.example.domain.model.ChatMessage
import kotlinx.coroutines.delay

/**
 * Mock implementation of AIService for V1 & AI Core.
 * Delivers context-aware, structured responses in Arabic and English,
 * and dynamically adapts to the active AI Model, Personality Style, Rules, Memory, and Knowledge Base (RAG).
 */
class MockAIServiceImpl(
    private val personalityManager: PersonalityManager? = null,
    private val modelManager: ModelManager? = null,
    private val memoryManager: MemoryManager? = null,
    private val knowledgeManager: KnowledgeManager? = null
) : AIService {

    override suspend fun generateCompletion(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String
    ): String {
        // Simulate realistic network & inference delay
        delay(850)

        val clean = prompt.trim().lowercase()
        val currentStyle = personalityManager?.personality?.value?.style ?: PersonalityStyle.BALANCED
        val activeModel = modelManager?.activeModel?.value

        // Check RAG Knowledge Base first if relevant knowledge chunks match the prompt
        val ragContext = knowledgeManager?.retrieveRagContext(prompt)
        if (ragContext != null && ragContext.hasKnowledge && !clean.contains("من أنت") && !clean.contains("who are you")) {
            val primaryChunk = ragContext.relevantChunks.first()
            val sources = ragContext.relevantChunks.joinToString("، ") { "\"${it.title}\"" }
            return "📚 **إجابة مستندة إلى قاعدة المعرفة (RAG):**\n\n" +
                    "${primaryChunk.text}\n\n" +
                    "---\n" +
                    "📌 _المصدر الموثق: $sources (${primaryChunk.sourceType.titleAr})_"
        }

        return when {
            // Questions about Knowledge Base / RAG
            clean.contains("قاعدة المعرفة") || clean.contains("معرفة") || clean.contains("rag") || clean.contains("knowledge base") || clean.contains("مستندات") || clean.contains("pdf") -> {
                "نظام **قاعدة المعرفة واسترجاع المعلومات (Knowledge Base + RAG)** في Ameer AI:\n\n" +
                        "• **المعمارية:** محرك RAG مدمج يقوم بتقسيم النصوص (Chunking) وتوليد مطابقة دلالية دقيقة.\n" +
                        "• **التخزين:** قاعدة بيانات Room Database المحلية لتخزين المقالات والتوثيقات.\n" +
                        "• **المدخلات:** يدعم إدخال النصوص وتصنيفها حالياً، ومجهز معمارياً لاستقبال وفهرسة ملفات PDF.\n\n" +
                        "يمكنك إضافة وإدارة مراجعك المعرفية في أي وقت من شاشة الإعدادات > قاعدة المعرفة."
            }

            // Questions about Memory / What do you remember about me?
            clean.contains("تتذكر عني") || clean.contains("ذاكرتك") || clean.contains("ماذا تعرف عني") || clean.contains("remember about me") || clean.contains("what do you remember") -> {
                val memoryContext = memoryManager?.buildMemoryContext(prompt, history)
                val memories = memoryContext?.relevantMemories ?: emptyList()

                if (memories.isNotEmpty()) {
                    val list = memories.joinToString("\n") { "• **${it.key}:** ${it.content} _(${it.category.titleAr})_" }
                    "إليك ما أتذكره عنك في الذاكرة طويلة المدى:\n\n$list\n\nيمكنك إدارة وحذف أي معلومة في أي وقت من شاشة الإعدادات > نظام الذاكرة."
                } else {
                    "لا توجد معلومات محفوظة عنك حالياً في الذاكرة طويلة المدى.\n\n" +
                            "يمكنك إخباري بحفظ أي شيء عبر قول: \"احفظ أن...\" أو \"تذكر أن...\"، أو إضافتها يدوياً من شاشة الإعدادات > نظام الذاكرة الذكية! 🧠"
                }
            }

            // User asking "ما هو اسمي؟" or "من أنا؟"
            (clean.contains("ما هو اسمي") || clean.contains("ما اسمي") || clean.contains("هل تعرف اسمي") || clean.contains("من أنا") || clean.contains("what is my name")) && memoryManager != null -> {
                val memoryContext = memoryManager.buildMemoryContext(prompt, history)
                val nameMemory = memoryContext.relevantMemories.find {
                    it.key.contains("اسم") || it.content.contains("اسمي") || it.category == com.example.domain.model.MemoryCategory.USER_PROFILE
                }
                if (nameMemory != null) {
                    "حسب ما أتذكره في الذاكرة طويلة المدى، اسمك هو: **${nameMemory.content}**! ✨"
                } else {
                    "لم تخبرني باسمك بعد! يمكنك قول: \"تذكر أن اسمي [اسمك]\" وسأحفظه فوراً في الذاكرة طويلة المدى."
                }
            }

            // User asking about saved preferences or job / field
            memoryManager != null && (clean.contains("تفضيل") || clean.contains("أفضل") || clean.contains("أحب") || clean.contains("عملي") || clean.contains("وظيفتي") || clean.contains("تخصصي")) &&
                    memoryManager.buildMemoryContext(prompt, history).relevantMemories.isNotEmpty() -> {
                val memoryContext = memoryManager.buildMemoryContext(prompt, history)
                val relevant = memoryContext.relevantMemories.first()
                "بناءً على معلوماتك المحفوظة في نظام الذاكرة الذكية:\n• **${relevant.key}:** ${relevant.content}\n\nيسعدني دائماً تذكر تفضيلاتك لتقديم إجابات مخصصة لك!"
            }

            // Questions about Models / Model Manager
            clean.contains("نموذج") || clean.contains("model") || clean.contains("محرك") || clean.contains("engine") -> {
                val modelName = activeModel?.displayName ?: "Ameer Core Engine V1"
                val window = activeModel?.contextWindow ?: "32K Tokens"
                val provider = activeModel?.provider?.title ?: "محلي"

                "معلومات محرك الذكاء الاصطناعي الحالي:\n\n" +
                        "• **النموذج النشط:** $modelName\n" +
                        "• **المزود:** $provider\n" +
                        "• **نافذة السياق:** $window\n" +
                        "• **الحالة:** يعمل محلياً بكفاءة وسرعة عالية.\n\n" +
                        "يمكنك استعراض النماذج المستقبلية وتبديلها من شاشة الإعدادات > إدارة النماذج."
            }

            // Questions about Personality & Rules
            clean.contains("شخصي") || clean.contains("قوانين") || clean.contains("قواعد") || clean.contains("rules") || clean.contains("personality") -> {
                val rulesList = personalityManager?.personality?.value?.rules
                    ?.filter { it.isEnabled }
                    ?.joinToString("\n") { "• **${it.title}:** ${it.description}" }
                    ?: "• الالتزام بالدقة والاحترام والتنسيق المنظم."

                "نظام شخصية وقوانين المساعد **$assistantName**:\n\n" +
                        "• **الأسلوب الحالي:** ${currentStyle.titleAr} (${currentStyle.descriptionAr})\n\n" +
                        "**القواعد النشطة:**\n$rulesList\n\n" +
                        "يمكنك تخصيص الأسلوب والقوانين بحرية من شاشة الإعدادات."
            }

            // Identity / Who are you
            clean.contains("من أنت") || clean.contains("اسمك") || clean.contains("who are you") || clean.contains("your name") -> {
                when (currentStyle) {
                    PersonalityStyle.CONCISE -> {
                        "أنا **$assistantName**، مساعدك الشخصي الذكي العامل بنظام AI Core والذاكرة الذكية وقاعدة المعرفة RAG."
                    }
                    PersonalityStyle.PROFESSIONAL -> {
                        "تحية طيبة. أنا **$assistantName**، مساعد ذكي مبني وفق معمارية Clean Architecture + AI Core مزود بنظام ذاكرة مخصص وقاعدة معرفة (RAG Engine) لاسترجاع الحقائق بدقة."
                    }
                    PersonalityStyle.CREATIVE -> {
                        "أهلاً بك! أنا **$assistantName**، رفيقك الذكي ومساعدك المتكامل المزود بذاكرة ذكية وقاعدة معرفة متجددة! ✨ ما الذي سنبدعه اليوم؟"
                    }
                    PersonalityStyle.BALANCED -> {
                        "أهلاً بك! أنا **$assistantName**، مساعدك الذكي المخصص لخدمتك.\n\n" +
                                "تم تزويدي بطبقة AI Core ونظام الذاكرة الذكية وقاعدة المعرفة (RAG) لإجابة أدق.\n" +
                                "كيف يمكنني مساعدتك اليوم؟"
                    }
                }
            }

            // Arabic Greetings
            clean.contains("مرحبا") || clean.contains("سلام") || clean.contains("أهلا") || clean.contains("مساء الخير") || clean.contains("صباح الخير") -> {
                when (currentStyle) {
                    PersonalityStyle.CONCISE -> "أهلاً بك ومرحباً. كيف أساعدك؟"
                    PersonalityStyle.PROFESSIONAL -> "وعليكم السلام ورحمة الله وبركاته. مرحباً بك، أنا جاهز لمعالجة استفساراتك وتنظيم مهامك."
                    PersonalityStyle.CREATIVE -> "يا مرحباً وأهلاً وسهلاً! يسعدني جداً التحدث معك اليوم. فلنبدأ رحلة استكشاف ممتعة معاً! 🚀"
                    PersonalityStyle.BALANCED -> "وعليكم السلام ورحمة الله وبركاته! أهلاً بك وسهلاً.\nأنا هنا لمساعدتك في كتابة الأكواد، التخطيط، أو تبادل الأفكار. ما الذي يشغل بالك اليوم؟ ✨"
                }
            }

            // English Greetings
            clean.contains("hello") || clean.contains("hi") || clean.contains("hey") || clean.contains("good morning") || clean.contains("good evening") -> {
                when (currentStyle) {
                    PersonalityStyle.CONCISE -> "Hello! How can I assist you today?"
                    PersonalityStyle.PROFESSIONAL -> "Greetings. I am **$assistantName**, ready to assist you with structured analysis and technical guidance."
                    PersonalityStyle.CREATIVE -> "Hello there! Wonderful to connect with you. Let's create something brilliant together today! 🌟"
                    PersonalityStyle.BALANCED -> "Hello there! I am **$assistantName**, your AI assistant powered by AI Core, Smart Memory and Knowledge RAG. How can I help you today?"
                }
            }

            // Code & Development
            clean.contains("كود") || clean.contains("برمجة") || clean.contains("kotlin") || clean.contains("compose") || clean.contains("code") || clean.contains("android") -> {
                "إليك نموذج برمجي يوضح معمارية **Knowledge Base + RAG** في **AI Core** بلغة **Kotlin**:\n\n" +
                        "```kotlin\n" +
                        "// استرجاع المعرفة عبر RAG وتنفيذ المحرك\n" +
                        "val ragContext = knowledgeManager.retrieveRagContext(prompt)\n" +
                        "val response = aiCoreEngine.generateResponse(prompt, history)\n" +
                        "```\n\n" +
                        "تم دمج قاعدة المعرفة محلياً باستخدام Room Database وبدون أي اعتماد على API خارجي."
            }

            // Planning & Productivity
            clean.contains("خطة") || clean.contains("تنظيم") || clean.contains("plan") || clean.contains("organize") || clean.contains("todo") -> {
                when (currentStyle) {
                    PersonalityStyle.CONCISE -> {
                        "خطة سريعة:\n1. أهم أولوية أولاً (90 دقيقة).\n2. مراجعة المهام الثانوية.\n3. تقييم الإنجاز."
                    }
                    else -> {
                        "إليك مقترح خطة عمل ذكية ومرتبة وفق أسلوب (${currentStyle.titleAr}):\n\n" +
                                "1. **المهمة المركزية (الأولوية القصوى):** إنجاز أهم هدف في الصباح الباكر.\n" +
                                "2. **جلسة تركيز بنظام بومودورو (25/5):** تركيز كامل بدون مشتتات.\n" +
                                "3. **مراجعة التقدم والتنقيح:** فحص ما تم إنجازه وإعادة الترتيب.\n" +
                                "4. **استراحة تجديد الطاقة:** شرب الماء وأخذ نزهة قصيرة.\n\n" +
                                "هل تحب أن نحدد تفاصيل مهمتك الأساسية الآن؟"
                    }
                }
            }

            // General / Default response
            else -> {
                when (currentStyle) {
                    PersonalityStyle.CONCISE -> {
                        "تمت معالجة استفسارك: \"$prompt\". تم الفحص عبر نظام الذاكرة وقاعدة المعرفة RAG والمحرك ${activeModel?.displayName ?: "Ameer Core V1"}."
                    }
                    PersonalityStyle.PROFESSIONAL -> {
                        "تأكيد استلام الطلب: \"$prompt\".\n\n" +
                                "تمت المعالجة وفق محددات النموذج (${activeModel?.displayName ?: "Ameer Core V1"}) ونظام الذاكرة وقاعدة المعرفة.\n" +
                                "أنا في انتظار توجيهاتك القادمة لمتابعة العمل."
                    }
                    PersonalityStyle.CREATIVE -> {
                        "فكرة رائعة وسؤال مميز: \"$prompt\"! 💡\n\n" +
                                "قمت بتحليله وربطه بسياق الذاكرة والمعرفة. هناك دائماً مساحة للابتكار والمضي قدماً نحو حلول ذكية وغير تقليدية. كيف نطور هذا الأمر تالياً؟"
                    }
                    PersonalityStyle.BALANCED -> {
                        "شكراً على رسالتك: \"$prompt\"\n\n" +
                                "بصفتي **$assistantName**، قمت بمعالجة طلبك عبر طبقة AI Core والذاكرة الذكية وفحص قاعدة المعرفة RAG وحفظ المحادثة محلياً في Room Database.\n\n" +
                                "• النمط النشط: ${currentStyle.titleAr}\n" +
                                "• المحرك: ${activeModel?.displayName ?: "Ameer Core Engine V1"}\n\n" +
                                "هل تريد استكشاف المزيد أو إضافة معلومات جديدة لقاعدة المعرفة؟"
                    }
                }
            }
        }
    }
}
