package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.KnowledgeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface KnowledgeDao {
    @Query("SELECT * FROM knowledge_base ORDER BY updatedAt DESC")
    fun getAllKnowledgeFlow(): Flow<List<KnowledgeEntity>>

    @Query("SELECT * FROM knowledge_base ORDER BY updatedAt DESC")
    suspend fun getAllKnowledgeList(): List<KnowledgeEntity>

    @Query("SELECT * FROM knowledge_base WHERE id = :id LIMIT 1")
    suspend fun getKnowledgeById(id: Long): KnowledgeEntity?

    @Query("SELECT * FROM knowledge_base WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%' OR tags LIKE '%' || :query || '%'")
    suspend fun searchKnowledge(query: String): List<KnowledgeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKnowledge(item: KnowledgeEntity): Long

    @Update
    suspend fun updateKnowledge(item: KnowledgeEntity)

    @Query("DELETE FROM knowledge_base WHERE id = :id")
    suspend fun deleteKnowledgeById(id: Long)

    @Query("DELETE FROM knowledge_base")
    suspend fun clearAllKnowledge()

    @Query("SELECT COUNT(*) FROM knowledge_base")
    suspend fun getKnowledgeCount(): Int
}
