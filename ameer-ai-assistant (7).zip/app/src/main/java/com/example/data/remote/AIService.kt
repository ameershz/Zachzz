package com.example.data.remote

import com.example.domain.model.ChatMessage

/**
 * Service interface for AI response generation.
 *
 * Current: [MockAIServiceImpl]
 * Future: Easily swap with GeminiAIServiceImpl or any REST/gRPC client
 * without modifying domain layer or presentation layer.
 */
interface AIService {
    suspend fun generateCompletion(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String
    ): String
}
