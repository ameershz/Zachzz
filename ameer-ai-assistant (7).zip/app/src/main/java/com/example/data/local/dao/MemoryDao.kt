package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.MemoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories WHERE type = 'LONG_TERM' ORDER BY lastAccessed DESC")
    fun getAllLongTermMemories(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories WHERE type = 'LONG_TERM' ORDER BY lastAccessed DESC")
    suspend fun getLongTermMemoriesList(): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE id = :id LIMIT 1")
    suspend fun getMemoryById(id: Long): MemoryEntity?

    @Query("SELECT * FROM memories WHERE `key` LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%'")
    suspend fun searchMemories(query: String): List<MemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(memory: MemoryEntity): Long

    @Update
    suspend fun updateMemory(memory: MemoryEntity)

    @Query("UPDATE memories SET lastAccessed = :time WHERE id = :id")
    suspend fun updateLastAccessed(id: Long, time: Long)

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteMemoryById(id: Long)

    @Query("DELETE FROM memories WHERE type = 'LONG_TERM'")
    suspend fun clearAllLongTermMemories()

    @Query("DELETE FROM memories")
    suspend fun clearAllMemories()
}
