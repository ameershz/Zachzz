package com.example.data.repository

import com.example.data.local.dao.MemoryDao
import com.example.data.local.entity.MemoryEntity
import com.example.domain.model.MemoryItem
import com.example.domain.repository.MemoryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class MemoryRepositoryImpl(
    private val memoryDao: MemoryDao
) : MemoryRepository {

    override fun getLongTermMemories(): Flow<List<MemoryItem>> {
        return memoryDao.getAllLongTermMemories().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun getAllMemoriesList(): List<MemoryItem> = withContext(Dispatchers.IO) {
        memoryDao.getLongTermMemoriesList().map { it.toDomain() }
    }

    override suspend fun getMemoryById(id: Long): MemoryItem? = withContext(Dispatchers.IO) {
        memoryDao.getMemoryById(id)?.toDomain()
    }

    override suspend fun saveMemory(memory: MemoryItem): Long = withContext(Dispatchers.IO) {
        val entity = MemoryEntity.fromDomain(memory)
        memoryDao.insertMemory(entity)
    }

    override suspend fun updateMemory(memory: MemoryItem) = withContext(Dispatchers.IO) {
        val entity = MemoryEntity.fromDomain(memory)
        memoryDao.updateMemory(entity)
    }

    override suspend fun deleteMemory(id: Long) = withContext(Dispatchers.IO) {
        memoryDao.deleteMemoryById(id)
    }

    override suspend fun clearAllLongTermMemories() = withContext(Dispatchers.IO) {
        memoryDao.clearAllLongTermMemories()
    }

    override suspend fun searchMemories(query: String): List<MemoryItem> = withContext(Dispatchers.IO) {
        val clean = query.trim()
        if (clean.isEmpty()) {
            memoryDao.getLongTermMemoriesList().map { it.toDomain() }
        } else {
            memoryDao.searchMemories(clean).map { it.toDomain() }
        }
    }

    override suspend fun getRelevantMemories(prompt: String): List<MemoryItem> = withContext(Dispatchers.IO) {
        val all = memoryDao.getLongTermMemoriesList()
        if (all.isEmpty()) return@withContext emptyList()

        val tokens = prompt.lowercase()
            .split(" ", "،", ",", ".", "؟", "?")
            .filter { it.length > 2 }

        val relevant = all.filter { memory ->
            val keyLower = memory.key.lowercase()
            val contentLower = memory.content.lowercase()

            // Check if any significant token is in the key or content
            tokens.any { token ->
                keyLower.contains(token) || contentLower.contains(token)
            } || prompt.contains("تتذكر") || prompt.contains("عني") || prompt.contains("تذكر") || prompt.contains("اسمي")
        }

        // Touch lastAccessed for relevant memories
        val now = System.currentTimeMillis()
        relevant.forEach {
            memoryDao.updateLastAccessed(it.id, now)
        }

        relevant.map { it.toDomain() }
    }
}
