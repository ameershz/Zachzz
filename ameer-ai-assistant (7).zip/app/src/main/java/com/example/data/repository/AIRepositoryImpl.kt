package com.example.data.repository

import com.example.aicore.engine.AICoreEngine
import com.example.domain.model.ChatMessage
import com.example.domain.repository.AIRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AIRepositoryImpl(
    private val aiCoreEngine: AICoreEngine
) : AIRepository {

    override suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String
    ): Result<String> = withContext(Dispatchers.IO) {
        aiCoreEngine.generateResponse(prompt, history)
    }
}
