package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.knowledge.KnowledgeCategory
import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.model.knowledge.KnowledgeSourceType

@Entity(tableName = "knowledge_base")
data class KnowledgeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val category: String,
    val sourceType: String,
    val tags: String,
    val sourceFileName: String? = null,
    val sourceUri: String? = null,
    val pageCount: Int? = null,
    val createdAt: Long,
    val updatedAt: Long
) {
    fun toDomain(): KnowledgeItem {
        val parsedCategory = try {
            KnowledgeCategory.valueOf(category)
        } catch (e: Exception) {
            KnowledgeCategory.GENERAL
        }

        val parsedSource = try {
            KnowledgeSourceType.valueOf(sourceType)
        } catch (e: Exception) {
            KnowledgeSourceType.MANUAL_TEXT
        }

        val parsedTags = if (tags.isNotBlank()) {
            tags.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            emptyList()
        }

        return KnowledgeItem(
            id = id,
            title = title,
            content = content,
            category = parsedCategory,
            sourceType = parsedSource,
            tags = parsedTags,
            sourceFileName = sourceFileName,
            sourceUri = sourceUri,
            pageCount = pageCount,
            createdAt = createdAt,
            updatedAt = updatedAt
        )
    }

    companion object {
        fun fromDomain(item: KnowledgeItem): KnowledgeEntity {
            return KnowledgeEntity(
                id = item.id,
                title = item.title,
                content = item.content,
                category = item.category.name,
                sourceType = item.sourceType.name,
                tags = item.tags.joinToString(","),
                sourceFileName = item.sourceFileName,
                sourceUri = item.sourceUri,
                pageCount = item.pageCount,
                createdAt = item.createdAt,
                updatedAt = item.updatedAt
            )
        }
    }
}
