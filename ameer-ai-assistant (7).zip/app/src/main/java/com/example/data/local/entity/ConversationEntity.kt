package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.Conversation

@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val createdAt: Long,
    val lastModified: Long
) {
    fun toDomain(): Conversation {
        return Conversation(
            id = id,
            title = title,
            createdAt = createdAt,
            lastModified = lastModified
        )
    }

    companion object {
        fun fromDomain(conv: Conversation): ConversationEntity {
            return ConversationEntity(
                id = conv.id,
                title = conv.title,
                createdAt = conv.createdAt,
                lastModified = conv.lastModified
            )
        }
    }
}
