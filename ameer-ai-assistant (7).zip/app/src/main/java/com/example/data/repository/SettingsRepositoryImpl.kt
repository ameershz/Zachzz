package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.domain.model.AssistantSettings
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepositoryImpl(
    context: Context
) : SettingsRepository {

    private val prefs: SharedPreferences = context.getSharedPreferences("ameer_ai_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    private val settingsFlow: Flow<AssistantSettings> = _settings.asStateFlow()

    private fun loadSettings(): AssistantSettings {
        val name = prefs.getString(KEY_ASSISTANT_NAME, "Ameer AI") ?: "Ameer AI"
        val voiceEnabled = prefs.getBoolean(KEY_VOICE_MODE, false)
        return AssistantSettings(
            assistantName = name,
            isVoiceModeEnabled = voiceEnabled
        )
    }

    override fun getSettings(): Flow<AssistantSettings> = settingsFlow

    override suspend fun updateAssistantName(name: String) {
        val trimmed = name.trim().ifEmpty { "Ameer AI" }
        prefs.edit().putString(KEY_ASSISTANT_NAME, trimmed).apply()
        _settings.value = _settings.value.copy(assistantName = trimmed)
    }

    override suspend fun toggleVoiceMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_VOICE_MODE, enabled).apply()
        _settings.value = _settings.value.copy(isVoiceModeEnabled = enabled)
    }

    companion object {
        private const val KEY_ASSISTANT_NAME = "assistant_name"
        private const val KEY_VOICE_MODE = "voice_mode"
    }
}
