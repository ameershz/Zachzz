package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.example.domain.model.ChatMessage
import com.example.domain.model.MessageSender

@Entity(
    tableName = "messages",
    indices = [Index(value = ["conversationId"])]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val conversationId: Long,
    val sender: String,
    val content: String,
    val timestamp: Long
) {
    fun toDomain(): ChatMessage {
        return ChatMessage(
            id = id,
            conversationId = conversationId,
            sender = if (sender == MessageSender.ASSISTANT.name) MessageSender.ASSISTANT else MessageSender.USER,
            content = content,
            timestamp = timestamp,
            isPending = false
        )
    }

    companion object {
        fun fromDomain(chatMessage: ChatMessage): MessageEntity {
            return MessageEntity(
                id = chatMessage.id,
                conversationId = chatMessage.conversationId,
                sender = chatMessage.sender.name,
                content = chatMessage.content,
                timestamp = chatMessage.timestamp
            )
        }
    }
}
