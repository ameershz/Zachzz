package com.example.data.repository

import com.example.data.local.dao.KnowledgeDao
import com.example.data.local.entity.KnowledgeEntity
import com.example.domain.model.knowledge.KnowledgeChunk
import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.repository.KnowledgeRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class KnowledgeRepositoryImpl(
    private val knowledgeDao: KnowledgeDao
) : KnowledgeRepository {

    override fun getKnowledgeFlow(): Flow<List<KnowledgeItem>> {
        return knowledgeDao.getAllKnowledgeFlow().map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun getAllKnowledge(): List<KnowledgeItem> = withContext(Dispatchers.IO) {
        knowledgeDao.getAllKnowledgeList().map { it.toDomain() }
    }

    override suspend fun getKnowledgeById(id: Long): KnowledgeItem? = withContext(Dispatchers.IO) {
        knowledgeDao.getKnowledgeById(id)?.toDomain()
    }

    override suspend fun searchKnowledge(query: String): List<KnowledgeItem> = withContext(Dispatchers.IO) {
        val clean = query.trim()
        if (clean.isEmpty()) {
            knowledgeDao.getAllKnowledgeList().map { it.toDomain() }
        } else {
            knowledgeDao.searchKnowledge(clean).map { it.toDomain() }
        }
    }

    override suspend fun saveKnowledge(item: KnowledgeItem): Long = withContext(Dispatchers.IO) {
        val entity = KnowledgeEntity.fromDomain(item)
        knowledgeDao.insertKnowledge(entity)
    }

    override suspend fun updateKnowledge(item: KnowledgeItem) = withContext(Dispatchers.IO) {
        val entity = KnowledgeEntity.fromDomain(item)
        knowledgeDao.updateKnowledge(entity)
    }

    override suspend fun deleteKnowledge(id: Long) = withContext(Dispatchers.IO) {
        knowledgeDao.deleteKnowledgeById(id)
    }

    override suspend fun clearAllKnowledge() = withContext(Dispatchers.IO) {
        knowledgeDao.clearAllKnowledge()
    }

    override suspend fun retrieveRelevantChunks(query: String, topK: Int): List<KnowledgeChunk> = withContext(Dispatchers.IO) {
        val allItems = knowledgeDao.getAllKnowledgeList().map { it.toDomain() }
        if (allItems.isEmpty()) return@withContext emptyList()

        val queryTokens = tokenize(query)
        if (queryTokens.isEmpty()) return@withContext emptyList()

        val scoredChunks = mutableListOf<KnowledgeChunk>()

        for (item in allItems) {
            // Split content into semantically coherent paragraphs or sentence chunks
            val paragraphs = item.content.split("\n\n", "\n").filter { it.trim().length > 10 }
            val chunksToScore = if (paragraphs.isNotEmpty()) paragraphs else listOf(item.content)

            for ((index, chunkText) in chunksToScore.withIndex()) {
                val chunkTokens = tokenize(chunkText)
                val titleTokens = tokenize(item.title)
                val tagTokens = item.tags.flatMap { tokenize(it) }

                var matchScore = 0f

                for (qToken in queryTokens) {
                    // Exact or prefix match in title has highest weight (3.0)
                    if (titleTokens.any { it.contains(qToken) || qToken.contains(it) }) {
                        matchScore += 3.0f
                    }
                    // Match in tags (2.0)
                    if (tagTokens.any { it.contains(qToken) || qToken.contains(it) }) {
                        matchScore += 2.0f
                    }
                    // Match in chunk body (1.0)
                    if (chunkTokens.any { it.contains(qToken) || qToken.contains(it) }) {
                        matchScore += 1.0f
                    }
                }

                // Boost score if consecutive phrase occurs in chunk
                if (chunkText.contains(query.trim(), ignoreCase = true)) {
                    matchScore += 4.0f
                }

                if (matchScore > 0.8f) {
                    scoredChunks.add(
                        KnowledgeChunk(
                            chunkId = "${item.id}_chunk_$index",
                            knowledgeId = item.id,
                            title = item.title,
                            text = chunkText.trim(),
                            relevanceScore = matchScore,
                            sourceType = item.sourceType
                        )
                    )
                }
            }
        }

        scoredChunks.sortedByDescending { it.relevanceScore }.take(topK)
    }

    private fun tokenize(text: String): List<String> {
        val stopWords = setOf(
            "في", "من", "على", "إلى", "عن", "مع", "هذا", "هذه", "التي", "الذي", "ما", "هل", "كيف", "هو", "هي", "أن", "إن", "كان", "يكون",
            "the", "is", "at", "which", "on", "in", "a", "an", "and", "or", "to", "for", "with"
        )
        return text.lowercase()
            .split(" ", "،", ",", ".", "؟", "?", "!", ":", ";", "(", ")", "[", "]", "\n", "\t")
            .map { it.trim() }
            .filter { it.length > 1 && !stopWords.contains(it) }
    }
}
