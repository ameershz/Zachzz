package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.model.MemoryCategory
import com.example.domain.model.MemoryItem
import com.example.domain.model.MemoryType

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val key: String,
    val content: String,
    val type: String,
    val category: String,
    val createdAt: Long,
    val lastAccessed: Long
) {
    fun toDomain(): MemoryItem {
        val parsedType = try {
            MemoryType.valueOf(type)
        } catch (e: Exception) {
            MemoryType.LONG_TERM
        }

        val parsedCategory = try {
            MemoryCategory.valueOf(category)
        } catch (e: Exception) {
            MemoryCategory.FACT
        }

        return MemoryItem(
            id = id,
            key = key,
            content = content,
            type = parsedType,
            category = parsedCategory,
            createdAt = createdAt,
            lastAccessed = lastAccessed
        )
    }

    companion object {
        fun fromDomain(item: MemoryItem): MemoryEntity {
            return MemoryEntity(
                id = item.id,
                key = item.key,
                content = item.content,
                type = item.type.name,
                category = item.category.name,
                createdAt = item.createdAt,
                lastAccessed = item.lastAccessed
            )
        }
    }
}
