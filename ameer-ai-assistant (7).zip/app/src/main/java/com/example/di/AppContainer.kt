package com.example.di

import android.content.Context
import com.example.aicore.engine.AICoreEngine
import com.example.aicore.engine.AICoreEngineImpl
import com.example.aicore.knowledge.KnowledgeManager
import com.example.aicore.knowledge.KnowledgeManagerImpl
import com.example.aicore.localmodel.LocalAIService
import com.example.aicore.localmodel.LocalAIServiceImpl
import com.example.aicore.localmodel.LocalInferenceEngineImpl
import com.example.aicore.localmodel.ModelDownloader
import com.example.aicore.localmodel.ModelDownloaderImpl
import com.example.aicore.localmodel.ModelLoader
import com.example.aicore.localmodel.ModelLoaderImpl
import com.example.aicore.localmodel.ModelSelector
import com.example.aicore.localmodel.ModelSelectorImpl
import com.example.aicore.memory.MemoryManager
import com.example.aicore.memory.MemoryManagerImpl
import com.example.aicore.model.ModelManager
import com.example.aicore.model.ModelManagerImpl
import com.example.aicore.personality.PersonalityManager
import com.example.aicore.personality.PersonalityManagerImpl
import com.example.data.local.AppDatabase
import com.example.data.remote.AIService
import com.example.data.repository.AIRepositoryImpl
import com.example.data.repository.ChatRepositoryImpl
import com.example.data.repository.KnowledgeRepositoryImpl
import com.example.data.repository.MemoryRepositoryImpl
import com.example.data.repository.SettingsRepositoryImpl
import com.example.domain.repository.AIRepository
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.KnowledgeRepository
import com.example.domain.repository.MemoryRepository
import com.example.domain.repository.SettingsRepository
import com.example.domain.usecase.ClearChatUseCase
import com.example.domain.usecase.CreateConversationUseCase
import com.example.domain.usecase.DeleteConversationUseCase
import com.example.domain.usecase.GetAssistantSettingsUseCase
import com.example.domain.usecase.GetConversationsUseCase
import com.example.domain.usecase.GetMessagesUseCase
import com.example.domain.usecase.SelectConversationUseCase
import com.example.domain.usecase.SendMessageUseCase
import com.example.domain.usecase.UpdateAssistantSettingsUseCase
import com.example.domain.usecase.knowledge.ClearAllKnowledgeUseCase
import com.example.domain.usecase.knowledge.DeleteKnowledgeUseCase
import com.example.domain.usecase.knowledge.GetKnowledgeBaseUseCase
import com.example.domain.usecase.knowledge.RetrieveKnowledgeUseCase
import com.example.domain.usecase.knowledge.SaveKnowledgeUseCase
import com.example.domain.usecase.knowledge.SearchKnowledgeUseCase
import com.example.domain.usecase.knowledge.UpdateKnowledgeUseCase
import com.example.domain.usecase.memory.ClearAllMemoriesUseCase
import com.example.domain.usecase.memory.DeleteMemoryUseCase
import com.example.domain.usecase.memory.GetMemoriesUseCase
import com.example.domain.usecase.memory.GetRelevantMemoriesUseCase
import com.example.domain.usecase.memory.SaveMemoryUseCase
import com.example.domain.usecase.memory.SearchMemoriesUseCase
import com.example.domain.usecase.memory.UpdateMemoryUseCase

/**
 * Dependency container providing single-source-of-truth instances
 * for AI Core, Local AI Model Downloader, Multi-Model Engine, Model Selector, Memory System, Knowledge Base (RAG), Database, Repositories, and UseCases.
 */
class AppContainer(context: Context) {

    private val database: AppDatabase by lazy {
        AppDatabase.getDatabase(context)
    }

    // Memory System
    val memoryRepository: MemoryRepository by lazy {
        MemoryRepositoryImpl(database.memoryDao())
    }

    val memoryManager: MemoryManager by lazy {
        MemoryManagerImpl(memoryRepository)
    }

    // Knowledge Base System (RAG)
    val knowledgeRepository: KnowledgeRepository by lazy {
        KnowledgeRepositoryImpl(database.knowledgeDao())
    }

    val knowledgeManager: KnowledgeManager by lazy {
        KnowledgeManagerImpl(knowledgeRepository)
    }

    // Local AI Model Downloader & On-Device Storage
    val modelDownloader: ModelDownloader by lazy {
        ModelDownloaderImpl(context)
    }

    // Local AI Model Engine & Loader (GGUF & Multi-Model Support)
    val modelLoader: ModelLoader by lazy {
        ModelLoaderImpl(context)
    }

    val modelSelector: ModelSelector by lazy {
        ModelSelectorImpl(modelLoader, context)
    }

    // AI Core layer components
    val personalityManager: PersonalityManager by lazy {
        PersonalityManagerImpl(context)
    }

    val modelManager: ModelManager by lazy {
        ModelManagerImpl(context, modelLoader, modelDownloader)
    }

    val localAiService: LocalAIService by lazy {
        LocalAIServiceImpl(
            modelLoader = modelLoader,
            modelDownloader = modelDownloader,
            modelSelector = modelSelector,
            inferenceEngine = LocalInferenceEngineImpl(modelDownloader = modelDownloader),
            personalityManager = personalityManager,
            memoryManager = memoryManager,
            knowledgeManager = knowledgeManager
        )
    }

    val aiService: AIService by lazy {
        localAiService
    }

    val aiCoreEngine: AICoreEngine by lazy {
        AICoreEngineImpl(
            modelManager = modelManager,
            personalityManager = personalityManager,
            memoryManager = memoryManager,
            knowledgeManager = knowledgeManager,
            localAiService = localAiService
        )
    }

    val aiRepository: AIRepository by lazy {
        AIRepositoryImpl(aiCoreEngine)
    }

    val chatRepository: ChatRepository by lazy {
        ChatRepositoryImpl(
            conversationDao = database.conversationDao(),
            messageDao = database.messageDao()
        )
    }

    val settingsRepository: SettingsRepository by lazy {
        SettingsRepositoryImpl(context)
    }

    // Chat & Conversation UseCases
    val sendMessageUseCase: SendMessageUseCase by lazy {
        SendMessageUseCase(chatRepository, aiRepository)
    }

    val getMessagesUseCase: GetMessagesUseCase by lazy {
        GetMessagesUseCase(chatRepository)
    }

    val clearChatUseCase: ClearChatUseCase by lazy {
        ClearChatUseCase(chatRepository)
    }

    val getAssistantSettingsUseCase: GetAssistantSettingsUseCase by lazy {
        GetAssistantSettingsUseCase(settingsRepository)
    }

    val updateAssistantSettingsUseCase: UpdateAssistantSettingsUseCase by lazy {
        UpdateAssistantSettingsUseCase(settingsRepository)
    }

    val createConversationUseCase: CreateConversationUseCase by lazy {
        CreateConversationUseCase(chatRepository)
    }

    val getConversationsUseCase: GetConversationsUseCase by lazy {
        GetConversationsUseCase(chatRepository)
    }

    val deleteConversationUseCase: DeleteConversationUseCase by lazy {
        DeleteConversationUseCase(chatRepository)
    }

    val selectConversationUseCase: SelectConversationUseCase by lazy {
        SelectConversationUseCase(chatRepository)
    }

    // Memory System UseCases
    val saveMemoryUseCase: SaveMemoryUseCase by lazy {
        SaveMemoryUseCase(memoryRepository)
    }

    val updateMemoryUseCase: UpdateMemoryUseCase by lazy {
        UpdateMemoryUseCase(memoryRepository)
    }

    val getMemoriesUseCase: GetMemoriesUseCase by lazy {
        GetMemoriesUseCase(memoryRepository)
    }

    val deleteMemoryUseCase: DeleteMemoryUseCase by lazy {
        DeleteMemoryUseCase(memoryRepository)
    }

    val clearAllMemoriesUseCase: ClearAllMemoriesUseCase by lazy {
        ClearAllMemoriesUseCase(memoryRepository)
    }

    val searchMemoriesUseCase: SearchMemoriesUseCase by lazy {
        SearchMemoriesUseCase(memoryRepository)
    }

    val getRelevantMemoriesUseCase: GetRelevantMemoriesUseCase by lazy {
        GetRelevantMemoriesUseCase(memoryRepository)
    }

    // Knowledge Base UseCases (RAG)
    val getKnowledgeBaseUseCase: GetKnowledgeBaseUseCase by lazy {
        GetKnowledgeBaseUseCase(knowledgeRepository)
    }

    val saveKnowledgeUseCase: SaveKnowledgeUseCase by lazy {
        SaveKnowledgeUseCase(knowledgeRepository)
    }

    val updateKnowledgeUseCase: UpdateKnowledgeUseCase by lazy {
        UpdateKnowledgeUseCase(knowledgeRepository)
    }

    val deleteKnowledgeUseCase: DeleteKnowledgeUseCase by lazy {
        DeleteKnowledgeUseCase(knowledgeRepository)
    }

    val clearAllKnowledgeUseCase: ClearAllKnowledgeUseCase by lazy {
        ClearAllKnowledgeUseCase(knowledgeRepository)
    }

    val searchKnowledgeUseCase: SearchKnowledgeUseCase by lazy {
        SearchKnowledgeUseCase(knowledgeRepository)
    }

    val retrieveKnowledgeUseCase: RetrieveKnowledgeUseCase by lazy {
        RetrieveKnowledgeUseCase(knowledgeRepository)
    }
}
