package com.example.aicore.localmodel

/**
 * Execution and lifecycle states of the Real On-Device Local Model Engine.
 * Covers explicit execution states: Model Loaded, Loading, Error, Not Available.
 */
sealed class ModelLoadingState(val statusTitleAr: String) {

    data object NotAvailable : ModelLoadingState("غير متاح (يحتاج تحميل)")

    data class Loading(
        val descriptor: LocalModelDescriptor,
        val progress: Float, // 0.0f to 1.0f
        val phaseMessage: String
    ) : ModelLoadingState("جاري التحميل في الذاكرة ⏳")

    data class ModelLoaded(
        val descriptor: LocalModelDescriptor,
        val memoryUsageMb: Int,
        val activeThreads: Int,
        val loadedTimestamp: Long = System.currentTimeMillis()
    ) : ModelLoadingState("النموذج محمّل وجاهز للاستدلال 🚀")

    data class Error(
        val descriptor: LocalModelDescriptor?,
        val errorMessage: String,
        val cause: Throwable? = null
    ) : ModelLoadingState("خطأ في تشغيل النموذج ⚠️")

    data object Unloaded : ModelLoadingState("غير محمّل")
}

// Top-level alias for backwards compatibility
typealias ReadyState = ModelLoadingState.ModelLoaded
