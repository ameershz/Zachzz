package com.example.aicore.model

import android.content.Context
import android.content.SharedPreferences
import com.example.aicore.localmodel.DownloadState
import com.example.aicore.localmodel.LocalModelDescriptor
import com.example.aicore.localmodel.ModelDownloader
import com.example.aicore.localmodel.ModelLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Data model representing the on-device status of a local AI model.
 */
data class LocalModelInfo(
    val descriptor: LocalModelDescriptor,
    val name: String,
    val sizeBytes: Long,
    val formattedSize: String,
    val isDownloaded: Boolean,
    val isActive: Boolean,
    val downloadState: DownloadState,
    val filePath: String?
)

/**
 * Manager responsible for tracking all local models on device,
 * their downloaded states, disk space, and managing the persistent active model.
 */
interface ModelManager {
    val activeModel: StateFlow<AIModel>
    val activeDescriptor: StateFlow<LocalModelDescriptor>
    val localModelsInfo: StateFlow<List<LocalModelInfo>>

    fun getAvailableModels(): List<AIModel>
    fun selectModel(modelId: String): Boolean
    suspend fun activateLocalModel(modelId: String): Boolean
    fun isModelReadyForInference(): Boolean
    fun getModelInfo(modelId: String): LocalModelInfo?
    fun getTotalStorageUsageFormatted(): String
}

class ModelManagerImpl(
    private val context: Context? = null,
    private val modelLoader: ModelLoader? = null,
    private val modelDownloader: ModelDownloader? = null
) : ModelManager {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val prefs: SharedPreferences? = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val allDescriptors = LocalModelDescriptor.getAvailableDescriptors()
    private val models: List<AIModel> = AIModel.getDefaultModels()

    private val _activeDescriptor = MutableStateFlow(loadActiveDescriptor())
    override val activeDescriptor: StateFlow<LocalModelDescriptor> = _activeDescriptor.asStateFlow()

    private val _activeModel = MutableStateFlow(loadActiveModel())
    override val activeModel: StateFlow<AIModel> = _activeModel.asStateFlow()

    private val _localModelsInfo = MutableStateFlow<List<LocalModelInfo>>(emptyList())
    override val localModelsInfo: StateFlow<List<LocalModelInfo>> = _localModelsInfo.asStateFlow()

    init {
        refreshModelsInfo()
        observeDownloaderAndLoader()
    }

    private fun loadActiveDescriptor(): LocalModelDescriptor {
        val savedId = prefs?.getString(KEY_ACTIVE_DESCRIPTOR_ID, LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM.id)
        return allDescriptors.find { it.id == savedId } ?: LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM
    }

    private fun loadActiveModel(): AIModel {
        val savedId = prefs?.getString(KEY_ACTIVE_MODEL_ID, AIModel.QWEN_2_5_1_5B.id)
        return models.find { it.id == savedId } ?: AIModel.QWEN_2_5_1_5B
    }

    private fun observeDownloaderAndLoader() {
        if (modelDownloader != null && modelLoader != null) {
            scope.launch {
                combine(
                    modelDownloader.modelDownloadStates,
                    modelLoader.activeDescriptor
                ) { downloadStates, activeDesc ->
                    buildModelsInfoList(downloadStates, activeDesc)
                }.collect { updatedList ->
                    _localModelsInfo.value = updatedList
                }
            }
        } else {
            refreshModelsInfo()
        }
    }

    private fun refreshModelsInfo() {
        val activeDesc = _activeDescriptor.value
        val downloadStates = modelDownloader?.modelDownloadStates?.value ?: emptyMap()
        _localModelsInfo.value = buildModelsInfoList(downloadStates, activeDesc)
    }

    private fun buildModelsInfoList(
        downloadStates: Map<String, DownloadState>,
        activeDesc: LocalModelDescriptor
    ): List<LocalModelInfo> {
        return allDescriptors.map { desc ->
            val isDownloaded = modelDownloader?.isModelDownloaded(desc) ?: desc.isBundledReady
            val downloadState = downloadStates[desc.id] ?: if (isDownloaded) {
                DownloadState.Completed(
                    modelId = desc.id,
                    localFilePath = modelDownloader?.getDownloadedFile(desc)?.absolutePath ?: desc.localFileName,
                    fileSizeBytes = desc.sizeBytes
                )
            } else {
                DownloadState.Idle
            }
            val file = modelDownloader?.getDownloadedFile(desc)

            LocalModelInfo(
                descriptor = desc,
                name = desc.name,
                sizeBytes = desc.sizeBytes,
                formattedSize = desc.formattedSize,
                isDownloaded = isDownloaded,
                isActive = desc.id == activeDesc.id,
                downloadState = downloadState,
                filePath = file?.absolutePath
            )
        }
    }

    override fun getAvailableModels(): List<AIModel> = models

    override fun selectModel(modelId: String): Boolean {
        val targetModel = models.find { it.id == modelId } ?: return false
        val matchingDesc = allDescriptors.find { it.id == modelId }

        prefs?.edit()
            ?.putString(KEY_ACTIVE_MODEL_ID, targetModel.id)
            ?.apply()
        _activeModel.value = targetModel

        if (matchingDesc != null) {
            prefs?.edit()
                ?.putString(KEY_ACTIVE_DESCRIPTOR_ID, matchingDesc.id)
                ?.apply()
            _activeDescriptor.value = matchingDesc
            scope.launch {
                modelLoader?.loadModel(matchingDesc)
            }
        }
        refreshModelsInfo()
        return true
    }

    override suspend fun activateLocalModel(modelId: String): Boolean {
        val matchingDesc = allDescriptors.find { it.id == modelId } ?: return false
        val isDownloaded = modelDownloader?.isModelDownloaded(matchingDesc) ?: matchingDesc.isBundledReady

        if (!isDownloaded) {
            return false
        }

        prefs?.edit()
            ?.putString(KEY_ACTIVE_DESCRIPTOR_ID, matchingDesc.id)
            ?.apply()
        _activeDescriptor.value = matchingDesc

        val matchingModel = models.find { it.id == modelId }
        if (matchingModel != null) {
            prefs?.edit()
                ?.putString(KEY_ACTIVE_MODEL_ID, matchingModel.id)
                ?.apply()
            _activeModel.value = matchingModel
        }

        val loadResult = modelLoader?.loadModel(matchingDesc)
        refreshModelsInfo()
        return loadResult?.isSuccess ?: true
    }

    override fun isModelReadyForInference(): Boolean {
        val currentDesc = _activeDescriptor.value
        return modelDownloader?.isModelDownloaded(currentDesc) ?: currentDesc.isBundledReady
    }

    override fun getModelInfo(modelId: String): LocalModelInfo? {
        return _localModelsInfo.value.find { it.descriptor.id == modelId }
    }

    override fun getTotalStorageUsageFormatted(): String {
        return modelDownloader?.getTotalModelsStorageUsageFormatted() ?: "0 MB"
    }

    companion object {
        private const val PREFS_NAME = "ameer_ai_model_prefs"
        private const val KEY_ACTIVE_MODEL_ID = "active_model_id"
        private const val KEY_ACTIVE_DESCRIPTOR_ID = "active_descriptor_id"
    }
}
