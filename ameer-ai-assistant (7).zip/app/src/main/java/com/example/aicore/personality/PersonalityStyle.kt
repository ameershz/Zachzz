package com.example.aicore.personality

/**
 * Defines the response style and communication tone of Ameer AI.
 */
enum class PersonalityStyle(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val promptInstruction: String
) {
    BALANCED(
        id = "balanced",
        titleAr = "متوازن وحكيم",
        titleEn = "Balanced",
        descriptionAr = "أسلوب تفاعلي ذكي يجمع بين الدقة والود ووضوح الإجابة.",
        promptInstruction = "اجعل أسلوبك متوازناً، ودوداً، ودقيقاً. اشرح بوضوح دون إطالة مفرطة أو اختصار مخل."
    ),
    PROFESSIONAL(
        id = "professional",
        titleAr = "مهني وأكاديمي",
        titleEn = "Professional",
        descriptionAr = "أسلوب رسمي، علمي، ومنظم يركز على أعلى معايير الاحترافية.",
        promptInstruction = "اجعل أسلوبك مهنياً، رسمياً، ومنهجياً مع الاستشهاد بالحقائق والتركيز على الدقة والترتيب."
    ),
    CREATIVE(
        id = "creative",
        titleAr = "إبداعي وتفاعلي",
        titleEn = "Creative",
        descriptionAr = "أسلوب غني بالأفكار المبتكرة، مرن، ومحفز للتفكير الإبداعي.",
        promptInstruction = "اجعل أسلوبك إبداعياً، جذاباً، ومحفزاً للأفكار الجديدة مع استخدام أمثلة ملهمة وتعبيرات حيوية."
    ),
    CONCISE(
        id = "concise",
        titleAr = "موجز ومباشر",
        titleEn = "Concise",
        descriptionAr = "إجابات سريعة ونقاط محددة بدون مقدمات طويلة.",
        promptInstruction = "كن موجزاً ومباشراً جداً. اعتمد على النقاط المحددة وتجنب أي حشو أو مقدمات إضافية."
    );

    companion object {
        fun fromId(id: String): PersonalityStyle {
            return entries.find { it.id == id } ?: BALANCED
        }
    }
}
