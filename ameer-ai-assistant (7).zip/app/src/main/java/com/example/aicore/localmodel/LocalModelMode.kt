package com.example.aicore.localmodel

/**
 * Operating execution modes for Local AI Models in Ameer AI.
 */
enum class LocalModelMode(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val badge: String,
    val descriptionAr: String,
    val targetUseCases: String
) {
    FAST(
        id = "fast_mode",
        titleAr = "الوضع السريع (Fast Mode)",
        titleEn = "Fast Mode",
        badge = "سريع وموفر للطاقة",
        descriptionAr = "مُحسّن للسرعة الفائقة واستهلاك الذاكرة المنخفض (<800MB). مثالي للمحادثات اليومية والأسئلة السريعة.",
        targetUseCases = "محادثات فورية • تلخيص سريع • استهلاك بطارية خفيف"
    ),
    PRO(
        id = "pro_mode",
        titleAr = "الوضع المتقدم (Pro Mode)",
        titleEn = "Pro Mode",
        badge = "استدلال عميق ودقة فائقة",
        descriptionAr = "مُحسّن للتفكير المعقد وكتابة الأكواد والتحليل المنطقي العميق ودمج سياق RAG المكثف.",
        targetUseCases = "برمجة متقدمة • تحليل مستندات RAG • استدلال متعدد الخطوات"
    ),
    AUTO_ADAPTIVE(
        id = "auto_mode",
        titleAr = "التحديد التلقائي الذكي (Auto)",
        titleEn = "Auto-Adaptive",
        badge = "تكيف تلقائي مع العتاد",
        descriptionAr = "يختار النظام النموذج الأنسب تلقائياً (Fast أو Pro) بناءً على عتاد الجهاز وحجم الرام المتوفر.",
        targetUseCases = "أفضل توازن تلقائي بين السرعة والدقة وفق قدرات الهاتف"
    );

    companion object {
        fun fromId(id: String): LocalModelMode = entries.find { it.id == id } ?: AUTO_ADAPTIVE
    }
}

/**
 * Categorizes models into lightweight (Fast) or high-capacity (Pro) tiers.
 */
enum class ModelTier(val titleAr: String, val badge: String) {
    FAST_TIER("فئة النماذج السريعة (0.5B - 1.5B)", "Fast Tier"),
    PRO_TIER("فئة النماذج المتقدمة (2B - 3.5B)", "Pro Tier")
}
