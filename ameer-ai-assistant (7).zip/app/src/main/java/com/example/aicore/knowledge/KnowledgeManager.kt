package com.example.aicore.knowledge

import com.example.domain.model.knowledge.KnowledgeCategory
import com.example.domain.model.knowledge.KnowledgeChunk
import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.model.knowledge.KnowledgeSourceType
import com.example.domain.model.knowledge.RagContext
import com.example.domain.repository.KnowledgeRepository
import kotlinx.coroutines.flow.Flow

interface KnowledgeManager {
    val knowledgeBase: Flow<List<KnowledgeItem>>

    suspend fun retrieveRagContext(prompt: String): RagContext

    suspend fun addKnowledge(
        title: String,
        content: String,
        category: KnowledgeCategory = KnowledgeCategory.GENERAL,
        sourceType: KnowledgeSourceType = KnowledgeSourceType.MANUAL_TEXT,
        tags: List<String> = emptyList(),
        sourceFileName: String? = null,
        pageCount: Int? = null
    ): KnowledgeItem

    suspend fun updateKnowledge(item: KnowledgeItem)
    suspend fun deleteKnowledge(id: Long)
    suspend fun clearAllKnowledge()
    suspend fun searchKnowledge(query: String): List<KnowledgeItem>
}

class KnowledgeManagerImpl(
    private val knowledgeRepository: KnowledgeRepository
) : KnowledgeManager {

    override val knowledgeBase: Flow<List<KnowledgeItem>> = knowledgeRepository.getKnowledgeFlow()

    override suspend fun retrieveRagContext(prompt: String): RagContext {
        val chunks = knowledgeRepository.retrieveRelevantChunks(prompt, topK = 3)

        val promptBlock = if (chunks.isNotEmpty()) {
            val builder = StringBuilder()
            builder.appendLine("=== سياق المعرفة المسترجع (RAG Knowledge Base Context) ===")
            chunks.forEachIndexed { idx, chunk ->
                builder.appendLine("[$idx] المصدر: \"${chunk.title}\" (${chunk.sourceType.titleAr}):")
                builder.appendLine("    ${chunk.text}")
            }
            builder.appendLine("اعتمد على هذه الحقائق الموثقة للإجابة بدقة متناهية ونسب المعلومات لمصدرها عند الاقتضاء.")
            builder.toString().trim()
        } else {
            ""
        }

        return RagContext(
            relevantChunks = chunks,
            ragPromptBlock = promptBlock
        )
    }

    override suspend fun addKnowledge(
        title: String,
        content: String,
        category: KnowledgeCategory,
        sourceType: KnowledgeSourceType,
        tags: List<String>,
        sourceFileName: String?,
        pageCount: Int?
    ): KnowledgeItem {
        val item = KnowledgeItem(
            title = title.trim(),
            content = content.trim(),
            category = category,
            sourceType = sourceType,
            tags = tags,
            sourceFileName = sourceFileName,
            pageCount = pageCount,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        val id = knowledgeRepository.saveKnowledge(item)
        return item.copy(id = id)
    }

    override suspend fun updateKnowledge(item: KnowledgeItem) {
        knowledgeRepository.updateKnowledge(item.copy(updatedAt = System.currentTimeMillis()))
    }

    override suspend fun deleteKnowledge(id: Long) {
        knowledgeRepository.deleteKnowledge(id)
    }

    override suspend fun clearAllKnowledge() {
        knowledgeRepository.clearAllKnowledge()
    }

    override suspend fun searchKnowledge(query: String): List<KnowledgeItem> {
        return knowledgeRepository.searchKnowledge(query)
    }
}
