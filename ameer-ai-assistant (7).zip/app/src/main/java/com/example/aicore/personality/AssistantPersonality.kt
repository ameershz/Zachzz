package com.example.aicore.personality

/**
 * Combines the assistant identity, personality tone, active rules,
 * and compiles them into a unified system instruction prompt.
 */
data class AssistantPersonality(
    val assistantName: String = "Ameer AI",
    val style: PersonalityStyle = PersonalityStyle.BALANCED,
    val rules: List<AssistantRule> = AssistantRule.getDefaultRules(),
    val customInstructions: String = ""
) {
    /**
     * Builds the unified system instruction prompt that guides AI response generation.
     */
    fun buildSystemPrompt(): String {
        val builder = StringBuilder()
        builder.appendLine("أنت $assistantName، مساعد ذكي شخصي متطور مبني بأحدث التقنيات.")
        builder.appendLine("الأسلوب والسمة المعتمدة: ${style.titleAr} (${style.titleEn}).")
        builder.appendLine("توجيه الأسلوب: ${style.promptInstruction}")
        builder.appendLine()
        builder.appendLine("قواعد وتعليمات العمل الأساسية:")

        rules.filter { it.isEnabled }.forEachIndexed { index, rule ->
            builder.appendLine("${index + 1}. ${rule.title}: ${rule.description}")
        }

        if (customInstructions.isNotBlank()) {
            builder.appendLine()
            builder.appendLine("تعليمات مخصصة إضافية:")
            builder.appendLine(customInstructions.trim())
        }

        return builder.toString().trim()
    }
}
