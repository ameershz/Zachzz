package com.example.aicore.engine

import com.example.aicore.knowledge.KnowledgeManager
import com.example.aicore.localmodel.LocalAIService
import com.example.aicore.memory.MemoryManager
import com.example.aicore.model.AIModel
import com.example.aicore.model.ModelManager
import com.example.aicore.personality.AssistantPersonality
import com.example.aicore.personality.PersonalityManager
import com.example.domain.model.ChatMessage

/**
 * The Central AI Core Engine orchestrating the complete pipeline:
 * User Input -> Memory Retrieval -> Knowledge Base (RAG) -> Personality Rules -> Local AI Model Engine -> Grounded Response
 */
interface AICoreEngine {
    val modelManager: ModelManager
    val personalityManager: PersonalityManager
    val memoryManager: MemoryManager
    val knowledgeManager: KnowledgeManager
    val localAiService: LocalAIService

    suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>
    ): Result<String>
}

class AICoreEngineImpl(
    override val modelManager: ModelManager,
    override val personalityManager: PersonalityManager,
    override val memoryManager: MemoryManager,
    override val knowledgeManager: KnowledgeManager,
    override val localAiService: LocalAIService
) : AICoreEngine {

    override suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>
    ): Result<String> {
        return try {
            // 1. Memory Detection & Auto-Save
            val newlySavedMemory = memoryManager.detectAndAutoSaveMemory(prompt)

            // 2. Memory Retrieval (Short-Term context + Long-Term matching)
            val memoryContext = memoryManager.buildMemoryContext(prompt, history)

            // 3. Knowledge Base Retrieval (Internal RAG semantic chunks)
            val ragContext = knowledgeManager.retrieveRagContext(prompt)

            // 4. Personality Rules & System Prompt
            val currentPersonality = personalityManager.personality.value
            val systemPrompt = currentPersonality.buildSystemPrompt()

            // 5. Local AI Model Engine Execution (On-Device Inference)
            val response = localAiService.generateLocalCompletion(
                prompt = prompt,
                history = history,
                assistantName = currentPersonality.assistantName,
                systemPrompt = systemPrompt,
                ragContext = ragContext.ragPromptBlock.takeIf { it.isNotBlank() },
                memoryContext = memoryContext.memoryInstructionBlock.takeIf { it.isNotBlank() }
            )

            // 6. Response formatting with memory acknowledgment if a fact was just saved
            val finalReply = if (newlySavedMemory != null) {
                "✨ **تم حفظ هذه المعلومة في الذاكرة طويلة المدى:**\n" +
                        "• [${newlySavedMemory.key}]: ${newlySavedMemory.content}\n\n" +
                        response
            } else {
                response
            }

            Result.success(finalReply)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
