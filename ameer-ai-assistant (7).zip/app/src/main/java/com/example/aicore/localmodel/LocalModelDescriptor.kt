package com.example.aicore.localmodel

import java.util.Locale

/**
 * Model format for on-device inference engines.
 */
enum class ModelFormat(val titleAr: String, val extension: String) {
    GGUF("تنسيق GGUF الموحد (llama.cpp)", ".gguf"),
    ONNX("تنسيق ONNX Runtime", ".onnx"),
    TFLITE("تنسيق TensorFlow Lite", ".tflite"),
    NATIVE_CORE("محرك Ameer Core الداخلي", ".bin")
}

/**
 * Quantization level for optimized mobile CPU/GPU memory footprint.
 */
enum class ModelQuantization(val title: String, val bitsPerWeight: Float, val memoryDescription: String) {
    Q4_K_M("4-bit (Q4_K_M متوازن)", 4.5f, "حجم صغير جداً وأداء فائق السرعة على الهاتف"),
    Q4_0("4-bit (Q4_0 قياسي)", 4.0f, "استهلاك ذاكرة منخفض جداً"),
    Q8_0("8-bit (Q8_0 عالي الدقة)", 8.0f, "دقة عالية مع استهلاك ذاكرة متوسط"),
    FP16("16-bit (نصف دقة كاملة)", 16.0f, "أعلى دقة، مخصص للهواتف الرائدة"),
    INT8("8-bit صحيح", 8.0f, "متوافق مع مسرعات NNAPI")
}

/**
 * Hardware execution backend on Android devices.
 */
enum class HardwareBackend(val titleAr: String, val badge: String) {
    CPU_THREADED("معالج الهاتف (CPU متعدد الأنوية)", "CPU"),
    GPU_VULKAN("معالج الرسوميات (Vulkan GPU)", "GPU"),
    NNAPI_NPU("وحدة المعالجة العصبية (NPU / NNAPI)", "NPU"),
    AUTO("تحديد تلقائي للأمثل", "Auto")
}

/**
 * Architecture type of the local neural model.
 */
enum class ModelArchitecture(val displayName: String) {
    AMEER_NATIVE("Ameer Native Core Architecture"),
    QWEN_2_5("Qwen 2.5 Architecture"),
    LLAMA_3("Llama 3.2 Architecture"),
    GEMMA_2("Gemma 2 Architecture"),
    PHI_3_5("Phi 3.5 Architecture"),
    MISTRAL("Mistral Architecture")
}

/**
 * Complete metadata and parameters specification for on-device local AI models.
 */
data class LocalModelDescriptor(
    val id: String,
    val name: String,
    val tier: ModelTier,
    val architecture: ModelArchitecture,
    val format: ModelFormat,
    val quantization: ModelQuantization,
    val backend: HardwareBackend = HardwareBackend.CPU_THREADED,
    val contextLengthTokens: Int = 4096,
    val parameterCount: String = "1.5B",
    val requiredRamMb: Int = 1200,
    val sizeBytes: Long = 986L * 1024 * 1024,
    val downloadUrl: String? = null,
    val localFileName: String = "model.gguf",
    val isBundledReady: Boolean = false,
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val threadsCount: Int = Runtime.getRuntime().availableProcessors().coerceIn(2, 8),
    val descriptionAr: String = "",
    val speedRating: String = "⚡⚡⚡⚡",
    val reasoningRating: String = "⭐⭐⭐⭐"
) {
    val estimatedRamMb: Int
        get() = requiredRamMb

    val formattedSize: String
        get() = formatBytes(sizeBytes)

    companion object {
        fun formatBytes(bytes: Long): String {
            val mb = bytes / (1024.0 * 1024.0)
            return if (mb >= 1024.0) {
                String.format(Locale.US, "%.2f GB", mb / 1024.0)
            } else {
                String.format(Locale.US, "%.0f MB", mb)
            }
        }

        // =========================================================================
        // REAL MODEL FOR DOWNLOAD & INFERENCE: Qwen2.5-1.5B-Instruct GGUF Q4_K_M
        // =========================================================================
        val QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM = LocalModelDescriptor(
            id = "qwen2.5-1.5b-instruct-gguf-q4km",
            name = "Qwen2.5-1.5B-Instruct GGUF Q4_K_M",
            tier = ModelTier.FAST_TIER,
            architecture = ModelArchitecture.QWEN_2_5,
            format = ModelFormat.GGUF,
            quantization = ModelQuantization.Q4_K_M,
            backend = HardwareBackend.CPU_THREADED,
            contextLengthTokens = 32768,
            parameterCount = "1.54B",
            requiredRamMb = 1200,
            sizeBytes = 986L * 1024 * 1024, // 986 MB
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf",
            localFileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf",
            isBundledReady = false,
            temperature = 0.7f,
            descriptionAr = "النموذج الذكي الحقيقي المعتمد: أداء فائق في فهم اللغة العربية والإنجليزية، دقة برمجية واستدلال منطقي ممتاز، مع حجم مكمم خفيف وموفر للذاكرة.",
            speedRating = "⚡⚡⚡⚡⚡",
            reasoningRating = "⭐⭐⭐⭐⭐"
        )

        // ==========================================
        // FAST MODE MODELS (0.5B - 1.5B)
        // ==========================================

        val AMEER_FAST_CORE = LocalModelDescriptor(
            id = "ameer-fast-core-v1",
            name = "Ameer Fast Core (0.8B)",
            tier = ModelTier.FAST_TIER,
            architecture = ModelArchitecture.AMEER_NATIVE,
            format = ModelFormat.NATIVE_CORE,
            quantization = ModelQuantization.Q4_0,
            backend = HardwareBackend.CPU_THREADED,
            contextLengthTokens = 16384,
            parameterCount = "0.8B",
            requiredRamMb = 350,
            sizeBytes = 340L * 1024 * 1024,
            downloadUrl = null,
            localFileName = "ameer_fast_core_v1.bin",
            isBundledReady = true,
            temperature = 0.65f,
            descriptionAr = "محرك مدمج فائق السرعة، استجابة شبه فورية واستهلاك بطارية منخفض جداً.",
            speedRating = "⚡⚡⚡⚡⚡",
            reasoningRating = "⭐⭐⭐"
        )

        val LLAMA_3_2_1B_FAST_GGUF = LocalModelDescriptor(
            id = "llama-3.2-1b-fast-gguf",
            name = "Llama-3.2-1B (Fast GGUF)",
            tier = ModelTier.FAST_TIER,
            architecture = ModelArchitecture.LLAMA_3,
            format = ModelFormat.GGUF,
            quantization = ModelQuantization.Q4_K_M,
            backend = HardwareBackend.CPU_THREADED,
            contextLengthTokens = 8192,
            parameterCount = "1.23B",
            requiredRamMb = 720,
            sizeBytes = 740L * 1024 * 1024,
            downloadUrl = "https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf",
            localFileName = "llama-3.2-1b-instruct-q4_k_m.gguf",
            isBundledReady = false,
            temperature = 0.65f,
            descriptionAr = "نموذج Llama مخصص للسرعة الفائقة مع استهلاك ذاكرة منخفض.",
            speedRating = "⚡⚡⚡⚡",
            reasoningRating = "⭐⭐⭐⭐"
        )

        val QWEN_2_5_0_5B_FAST_GGUF = LocalModelDescriptor(
            id = "qwen-2.5-0.5b-fast-gguf",
            name = "Qwen2.5-0.5B (Pocket GGUF)",
            tier = ModelTier.FAST_TIER,
            architecture = ModelArchitecture.QWEN_2_5,
            format = ModelFormat.GGUF,
            quantization = ModelQuantization.Q4_0,
            backend = HardwareBackend.CPU_THREADED,
            contextLengthTokens = 8192,
            parameterCount = "0.49B",
            requiredRamMb = 280,
            sizeBytes = 310L * 1024 * 1024,
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_0.gguf",
            localFileName = "qwen2.5-0.5b-instruct-q4_0.gguf",
            isBundledReady = false,
            temperature = 0.6f,
            descriptionAr = "أخف نموذج GGUF ممكن، يعمل بسلاسة حتى على الهواتف الاقتصادية.",
            speedRating = "⚡⚡⚡⚡⚡",
            reasoningRating = "⭐⭐"
        )

        // ==========================================
        // PRO MODE MODELS (2B - 3.5B)
        // ==========================================

        val AMEER_PRO_CORE = LocalModelDescriptor(
            id = "ameer-pro-core-v1",
            name = "Ameer Pro Reasoning Core (3.2B)",
            tier = ModelTier.PRO_TIER,
            architecture = ModelArchitecture.AMEER_NATIVE,
            format = ModelFormat.NATIVE_CORE,
            quantization = ModelQuantization.Q8_0,
            backend = HardwareBackend.CPU_THREADED,
            contextLengthTokens = 32768,
            parameterCount = "3.2B",
            requiredRamMb = 1250,
            sizeBytes = 1250L * 1024 * 1024,
            downloadUrl = null,
            localFileName = "ameer_pro_core_v1.bin",
            isBundledReady = true,
            temperature = 0.7f,
            descriptionAr = "محرك التفكير العميق للمهام البرمجية والاستدلال المنطقي المعقد وتحليل RAG المكثف.",
            speedRating = "⚡⚡⚡",
            reasoningRating = "⭐⭐⭐⭐⭐"
        )

        val GEMMA_2_2B_PRO_GGUF = LocalModelDescriptor(
            id = "gemma-2-2b-pro-gguf",
            name = "Gemma-2-2B-IT (Pro GGUF + GPU)",
            tier = ModelTier.PRO_TIER,
            architecture = ModelArchitecture.GEMMA_2,
            format = ModelFormat.GGUF,
            quantization = ModelQuantization.Q4_K_M,
            backend = HardwareBackend.GPU_VULKAN,
            contextLengthTokens = 8192,
            parameterCount = "2.61B",
            requiredRamMb = 1550,
            sizeBytes = 1550L * 1024 * 1024,
            downloadUrl = "https://huggingface.co/bartowski/gemma-2-2b-it-GGUF/resolve/main/gemma-2-2b-it-Q4_K_M.gguf",
            localFileName = "gemma-2-2b-it-q4_k_m.gguf",
            isBundledReady = false,
            temperature = 0.7f,
            descriptionAr = "نموذج Google الاستدلالي المتقدم مع تسريع معالج الرسوميات Vulkan GPU.",
            speedRating = "⚡⚡⚡⚡",
            reasoningRating = "⭐⭐⭐⭐⭐"
        )

        val QWEN_2_5_3B_PRO_GGUF = LocalModelDescriptor(
            id = "qwen-2.5-3b-pro-gguf",
            name = "Qwen2.5-3B-Instruct (Pro GGUF)",
            tier = ModelTier.PRO_TIER,
            architecture = ModelArchitecture.QWEN_2_5,
            format = ModelFormat.GGUF,
            quantization = ModelQuantization.Q4_K_M,
            backend = HardwareBackend.CPU_THREADED,
            contextLengthTokens = 32768,
            parameterCount = "3.09B",
            requiredRamMb = 1750,
            sizeBytes = 1850L * 1024 * 1024,
            downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
            localFileName = "qwen2.5-3b-instruct-q4_k_m.gguf",
            isBundledReady = false,
            temperature = 0.7f,
            descriptionAr = "أعلى دقة لغوية وبرمجية وتفكير متعدد الخطوات باللغتين العربية والإنجليزية.",
            speedRating = "⚡⚡⚡",
            reasoningRating = "⭐⭐⭐⭐⭐"
        )

        // Compatibility aliases
        val AMEER_LOCAL_ENGINE = AMEER_FAST_CORE
        val LLAMA_3_2_1B_GGUF = LLAMA_3_2_1B_FAST_GGUF
        val GEMMA_2_2B_GGUF = GEMMA_2_2B_PRO_GGUF
        val QWEN_2_5_1_5B_GGUF = QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM

        fun getFastModeDescriptors(): List<LocalModelDescriptor> = listOf(
            QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM,
            AMEER_FAST_CORE,
            LLAMA_3_2_1B_FAST_GGUF,
            QWEN_2_5_0_5B_FAST_GGUF
        )

        fun getProModeDescriptors(): List<LocalModelDescriptor> = listOf(
            AMEER_PRO_CORE,
            GEMMA_2_2B_PRO_GGUF,
            QWEN_2_5_3B_PRO_GGUF
        )

        fun getAvailableDescriptors(): List<LocalModelDescriptor> = listOf(
            QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM,
            AMEER_FAST_CORE,
            AMEER_PRO_CORE,
            LLAMA_3_2_1B_FAST_GGUF,
            GEMMA_2_2B_PRO_GGUF,
            QWEN_2_5_3B_PRO_GGUF,
            QWEN_2_5_0_5B_FAST_GGUF
        )
    }
}
