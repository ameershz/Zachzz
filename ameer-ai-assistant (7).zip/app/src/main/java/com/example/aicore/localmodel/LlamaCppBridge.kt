package com.example.aicore.localmodel

import java.io.File

/**
 * Native JNI Bridge for llama.cpp / GGUF model execution on Android.
 * Provides C++/JNI bindings to initialize llama contexts and run token inference.
 */
class LlamaCppBridge {

    private var isNativeLibraryLoaded = false
    private var nativeContextHandle: Long = 0L

    init {
        try {
            System.loadLibrary("llama_android")
            isNativeLibraryLoaded = true
        } catch (_: Throwable) {
            isNativeLibraryLoaded = false
        }
    }

    fun isNativeSupported(): Boolean = isNativeLibraryLoaded

    fun initNativeModel(modelPath: String, contextSize: Int = 4096, threads: Int = 4): Boolean {
        if (!isNativeLibraryLoaded) return false
        val file = File(modelPath)
        if (!file.exists()) return false

        return try {
            nativeContextHandle = nativeInitContext(modelPath, contextSize, threads)
            nativeContextHandle != 0L
        } catch (e: Exception) {
            false
        }
    }

    fun generateNativeTokens(
        prompt: String,
        maxTokens: Int = 512,
        temperature: Float = 0.7f,
        topP: Float = 0.9f
    ): String? {
        if (!isNativeLibraryLoaded || nativeContextHandle == 0L) return null
        return try {
            nativeInfer(nativeContextHandle, prompt, maxTokens, temperature, topP)
        } catch (e: Exception) {
            null
        }
    }

    fun releaseNativeModel() {
        if (nativeContextHandle != 0L) {
            try {
                nativeFreeContext(nativeContextHandle)
            } catch (_: Exception) {}
            nativeContextHandle = 0L
        }
    }

    // JNI Native function declarations (llama.cpp C++ bindings)
    private external fun nativeInitContext(modelPath: String, contextSize: Int, threads: Int): Long
    private external fun nativeInfer(handle: Long, prompt: String, maxTokens: Int, temp: Float, topP: Float): String
    private external fun nativeFreeContext(handle: Long)
}
