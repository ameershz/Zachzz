package com.example.aicore.localmodel

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Intelligent Model Selector responsible for picking the optimal Local AI Model
 * based on device specifications or user preference (Fast Mode vs Pro Mode vs Auto-Adaptive).
 */
interface ModelSelector {
    val activeMode: StateFlow<LocalModelMode>
    val activeDescriptor: StateFlow<LocalModelDescriptor>
    val recommendedMode: LocalModelMode
    val deviceCapabilityReport: DeviceCapabilityReport

    suspend fun setMode(mode: LocalModelMode): Boolean
    suspend fun selectExplicitModel(descriptorId: String): Boolean
    fun getModelsForActiveMode(): List<LocalModelDescriptor>
}

data class DeviceCapabilityReport(
    val cpuCores: Int,
    val totalRamMb: Long,
    val ramTier: String,
    val recommendedTier: ModelTier,
    val recommendationReasonAr: String
)

class ModelSelectorImpl(
    private val modelLoader: ModelLoader,
    private val context: Context? = null
) : ModelSelector {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val prefs: SharedPreferences? = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    override val deviceCapabilityReport: DeviceCapabilityReport = analyzeDeviceCapabilities()

    override val recommendedMode: LocalModelMode = when (deviceCapabilityReport.recommendedTier) {
        ModelTier.PRO_TIER -> LocalModelMode.PRO
        ModelTier.FAST_TIER -> LocalModelMode.FAST
    }

    private val _activeMode = MutableStateFlow(loadInitialMode())
    override val activeMode: StateFlow<LocalModelMode> = _activeMode.asStateFlow()

    override val activeDescriptor: StateFlow<LocalModelDescriptor> = modelLoader.activeDescriptor

    init {
        // Apply initial model selection based on saved mode or device recommendation
        scope.launch {
            applyModeSelection(_activeMode.value)
        }
    }

    private fun loadInitialMode(): LocalModelMode {
        val savedModeId = prefs?.getString(KEY_ACTIVE_MODE, LocalModelMode.AUTO_ADAPTIVE.id)
            ?: LocalModelMode.AUTO_ADAPTIVE.id
        return LocalModelMode.fromId(savedModeId)
    }

    override suspend fun setMode(mode: LocalModelMode): Boolean {
        _activeMode.value = mode
        prefs?.edit()?.putString(KEY_ACTIVE_MODE, mode.id)?.apply()
        return applyModeSelection(mode)
    }

    override suspend fun selectExplicitModel(descriptorId: String): Boolean {
        return modelLoader.selectAndApplyModel(descriptorId)
    }

    override fun getModelsForActiveMode(): List<LocalModelDescriptor> {
        return when (_activeMode.value) {
            LocalModelMode.FAST -> LocalModelDescriptor.getFastModeDescriptors()
            LocalModelMode.PRO -> LocalModelDescriptor.getProModeDescriptors()
            LocalModelMode.AUTO_ADAPTIVE -> LocalModelDescriptor.getAvailableDescriptors()
        }
    }

    private suspend fun applyModeSelection(mode: LocalModelMode): Boolean {
        val targetDescriptor = when (mode) {
            LocalModelMode.FAST -> LocalModelDescriptor.AMEER_FAST_CORE
            LocalModelMode.PRO -> LocalModelDescriptor.AMEER_PRO_CORE
            LocalModelMode.AUTO_ADAPTIVE -> {
                if (deviceCapabilityReport.recommendedTier == ModelTier.PRO_TIER) {
                    LocalModelDescriptor.AMEER_PRO_CORE
                } else {
                    LocalModelDescriptor.AMEER_FAST_CORE
                }
            }
        }
        val result = modelLoader.loadModel(targetDescriptor)
        return result.isSuccess
    }

    private fun analyzeDeviceCapabilities(): DeviceCapabilityReport {
        val cores = Runtime.getRuntime().availableProcessors()
        val maxMemoryMb = Runtime.getRuntime().maxMemory() / (1024 * 1024)

        // Threshold evaluation
        val isHighEnd = cores >= 6 && maxMemoryMb >= 512
        val recommendedTier = if (isHighEnd) ModelTier.PRO_TIER else ModelTier.FAST_TIER
        val ramTier = if (isHighEnd) "أداء عالي (High Capability)" else "أداء قياسي (Standard Capability)"

        val reason = if (isHighEnd) {
            "تم رصد $cores أنوية معالجة وذاكرة كافية؛ جهازك مؤهل لتشغيل نماذج Pro Mode والاستدلال العميق بكفاءة."
        } else {
            "جهازك يعمل بكفاءة مثالية مع Fast Mode لتحقيق استجابة فائقة السرعة وتوفير البطارية والذاكرة."
        }

        return DeviceCapabilityReport(
            cpuCores = cores,
            totalRamMb = maxMemoryMb,
            ramTier = ramTier,
            recommendedTier = recommendedTier,
            recommendationReasonAr = reason
        )
    }

    companion object {
        private const val PREFS_NAME = "ameer_ai_model_selector_prefs"
        private const val KEY_ACTIVE_MODE = "active_model_mode"
    }
}
