package com.example.aicore.localmodel

/**
 * Lifecycle states of the On-Device Model Downloader.
 */
sealed class DownloadState {
    data object Idle : DownloadState()

    data class Downloading(
        val modelId: String,
        val progress: Float, // 0.0f to 1.0f
        val downloadedBytes: Long,
        val totalBytes: Long,
        val speedBytesPerSec: Long = 0L,
        val speedFormatted: String = "",
        val etaFormatted: String = ""
    ) : DownloadState() {
        val progressPercentage: Int
            get() = (progress * 100).toInt().coerceIn(0, 100)
    }

    data class Paused(
        val modelId: String,
        val progress: Float,
        val downloadedBytes: Long,
        val totalBytes: Long
    ) : DownloadState() {
        val progressPercentage: Int
            get() = (progress * 100).toInt().coerceIn(0, 100)
    }

    data class Completed(
        val modelId: String,
        val localFilePath: String,
        val fileSizeBytes: Long
    ) : DownloadState()

    data class Failed(
        val modelId: String,
        val errorMessage: String,
        val errorCause: Throwable? = null
    ) : DownloadState()
}
