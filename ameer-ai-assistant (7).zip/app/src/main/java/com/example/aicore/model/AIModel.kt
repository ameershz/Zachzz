package com.example.aicore.model

import com.example.aicore.localmodel.LocalModelDescriptor

enum class ModelProvider(val title: String) {
    LOCAL_NATIVE("Ameer Local Neural Engine (محلي)"),
    LOCAL_GGUF("تنسيق GGUF On-Device (محلي)"),
    LOCAL_ON_DEVICE("Gemma On-Device (محلي)"),
    CUSTOM_SERVER("خادم مخصص (REST API)")
}

/**
 * Metadata and specification of an AI model in Ameer AI Core.
 */
data class AIModel(
    val id: String,
    val displayName: String,
    val provider: ModelProvider,
    val descriptionAr: String,
    val contextWindow: String,
    val isAvailableNow: Boolean,
    val badge: String
) {
    companion object {
        val QWEN_2_5_1_5B = AIModel(
            id = LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM.id,
            displayName = "Qwen2.5-1.5B-Instruct GGUF Q4_K_M",
            provider = ModelProvider.LOCAL_GGUF,
            descriptionAr = "النموذج الذكي الحقيقي المعتمد: أداء فائق في فهم اللغة العربية، دقة برمجية واستدلال منطقي.",
            contextWindow = "32K Tokens",
            isAvailableNow = true,
            badge = "النموذج الحقيقي الموصى به"
        )

        val LOCAL_CORE_V1 = AIModel(
            id = LocalModelDescriptor.AMEER_FAST_CORE.id,
            displayName = "Ameer Fast Core (0.8B)",
            provider = ModelProvider.LOCAL_NATIVE,
            descriptionAr = "محرك ذكاء اصطناعي محلي مدمج فائق السرعة، معالجة فورية على الهاتف بدون إنترنت.",
            contextWindow = "16K Tokens",
            isAvailableNow = true,
            badge = "مدمج وجاهز فوراً"
        )

        val LLAMA_3_2_GGUF = AIModel(
            id = LocalModelDescriptor.LLAMA_3_2_1B_FAST_GGUF.id,
            displayName = "Llama-3.2-1B-Instruct (Fast GGUF)",
            provider = ModelProvider.LOCAL_GGUF,
            descriptionAr = "تنسيق GGUF متوازن Q4_K_M للاستدلال السريع عبر مكتبة llama.cpp.",
            contextWindow = "8K Tokens",
            isAvailableNow = true,
            badge = "GGUF Q4_K_M"
        )

        val GEMMA_2_2B_GGUF = AIModel(
            id = LocalModelDescriptor.GEMMA_2_2B_PRO_GGUF.id,
            displayName = "Gemma-2-2B-IT (Pro GGUF + GPU)",
            provider = ModelProvider.LOCAL_GGUF,
            descriptionAr = "نموذج Google المتقدم للأجهزة المحمولة مع تسريع GPU Vulkan.",
            contextWindow = "8K Tokens",
            isAvailableNow = true,
            badge = "GGUF + GPU"
        )

        val AMEER_PRO_CORE = AIModel(
            id = LocalModelDescriptor.AMEER_PRO_CORE.id,
            displayName = "Ameer Pro Reasoning Core (3.2B)",
            provider = ModelProvider.LOCAL_NATIVE,
            descriptionAr = "محرك التفكير العميق للمهام البرمجية والاستدلال المنطقي المعقد.",
            contextWindow = "32K Tokens",
            isAvailableNow = true,
            badge = "Pro Mode 🧠"
        )

        // Aliases for compatibility
        val QWEN_2_5_GGUF = QWEN_2_5_1_5B

        fun getDefaultModels(): List<AIModel> = listOf(
            QWEN_2_5_1_5B,
            LOCAL_CORE_V1,
            AMEER_PRO_CORE,
            LLAMA_3_2_GGUF,
            GEMMA_2_2B_GGUF
        )
    }
}
