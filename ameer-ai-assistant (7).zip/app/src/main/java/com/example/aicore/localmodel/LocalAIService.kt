package com.example.aicore.localmodel

import com.example.aicore.knowledge.KnowledgeManager
import com.example.aicore.memory.MemoryManager
import com.example.aicore.personality.PersonalityManager
import com.example.data.remote.AIService
import com.example.domain.model.ChatMessage

/**
 * High-level Local AI Service interface replacing MockAIService.
 * Directly runs inference on the local on-device engine without any external API calls.
 */
interface LocalAIService : AIService {
    val modelLoader: ModelLoader
    val modelDownloader: ModelDownloader?
        get() = null
    val modelSelector: ModelSelector?
        get() = null
    val inferenceEngine: LocalInferenceEngine

    suspend fun generateLocalCompletion(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String,
        systemPrompt: String? = null,
        ragContext: String? = null,
        memoryContext: String? = null
    ): String
}

class LocalAIServiceImpl(
    override val modelLoader: ModelLoader,
    override val modelDownloader: ModelDownloader? = null,
    override val modelSelector: ModelSelector? = null,
    override val inferenceEngine: LocalInferenceEngine = LocalInferenceEngineImpl(modelDownloader = modelDownloader),
    private val personalityManager: PersonalityManager? = null,
    private val memoryManager: MemoryManager? = null,
    private val knowledgeManager: KnowledgeManager? = null
) : LocalAIService {

    override suspend fun generateCompletion(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String
    ): String {
        val currentPersonality = personalityManager?.personality?.value
        val systemPrompt = currentPersonality?.buildSystemPrompt()
            ?: "أنت مساعد ذكي مبني وفق معمارية Clean Architecture + AI Core."

        val ragContext = knowledgeManager?.retrieveRagContext(prompt)?.ragPromptBlock
        val memoryContext = memoryManager?.buildMemoryContext(prompt, history)?.memoryInstructionBlock

        return generateLocalCompletion(
            prompt = prompt,
            history = history,
            assistantName = assistantName,
            systemPrompt = systemPrompt,
            ragContext = ragContext,
            memoryContext = memoryContext
        )
    }

    override suspend fun generateLocalCompletion(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String,
        systemPrompt: String?,
        ragContext: String?,
        memoryContext: String?
    ): String {
        val activeDescriptor = modelLoader.activeDescriptor.value

        // Check if the model is downloaded on device (if not bundled)
        val isDownloaded = modelDownloader?.isModelDownloaded(activeDescriptor) ?: activeDescriptor.isBundledReady
        if (!isDownloaded) {
            return "⚠️ **تنبيه العقل المحلي (Local AI Brain):**\n\n" +
                    "النموذج المختار **${activeDescriptor.name}** لم يتم تحميله بعد على مساحة تخزين هاتفك.\n\n" +
                    "📥 **لتشغيل الإجابات والاستدلال المحلي:**\n" +
                    "1. توجّه إلى قائمة **الإعدادات** > **إدارة العقل المحلي**.\n" +
                    "2. اضغط على زر **تحميل** بجانب **${activeDescriptor.name}** (حجم: ${activeDescriptor.formattedSize}).\n" +
                    "3. أو يمكنك تفعيل النموذج المدمج **Ameer Fast Core** فوراً بدون تحميل."
        }

        val formattedTemplate = inferenceEngine.buildPromptTemplate(
            systemPrompt = systemPrompt ?: "أنت $assistantName، مساعد ذكي محلي.",
            memoryContext = memoryContext,
            ragContext = ragContext,
            history = history,
            userPrompt = prompt,
            assistantName = assistantName
        )

        return inferenceEngine.infer(
            formattedPrompt = formattedTemplate,
            descriptor = activeDescriptor
        )
    }
}
