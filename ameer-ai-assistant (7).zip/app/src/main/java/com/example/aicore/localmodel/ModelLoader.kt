package com.example.aicore.localmodel

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Interface responsible for loading, unloading, verifying, and configuring Local AI Models.
 */
interface ModelLoader {
    val loadingState: StateFlow<ModelLoadingState>
    val activeDescriptor: StateFlow<LocalModelDescriptor>
    val availableDescriptors: List<LocalModelDescriptor>

    suspend fun loadModel(descriptor: LocalModelDescriptor): Result<Boolean>
    suspend fun unloadModel(): Boolean
    suspend fun selectAndApplyModel(descriptorId: String): Boolean
    fun getHardwareInfo(): HardwareInfo
}

data class HardwareInfo(
    val availableCores: Int,
    val recommendedThreads: Int,
    val totalRamMb: Long,
    val isGpuVulkanSupported: Boolean,
    val isNnapiSupported: Boolean
)

class ModelLoaderImpl(
    private val context: Context? = null
) : ModelLoader {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val prefs: SharedPreferences? = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val descriptors = LocalModelDescriptor.getAvailableDescriptors()

    private val _activeDescriptor = MutableStateFlow(loadInitialDescriptor())
    override val activeDescriptor: StateFlow<LocalModelDescriptor> = _activeDescriptor.asStateFlow()

    private val _loadingState = MutableStateFlow<ModelLoadingState>(
        ModelLoadingState.ModelLoaded(
            descriptor = _activeDescriptor.value,
            memoryUsageMb = _activeDescriptor.value.estimatedRamMb,
            activeThreads = _activeDescriptor.value.threadsCount
        )
    )
    override val loadingState: StateFlow<ModelLoadingState> = _loadingState.asStateFlow()

    override val availableDescriptors: List<LocalModelDescriptor> = descriptors

    private fun loadInitialDescriptor(): LocalModelDescriptor {
        val savedId = prefs?.getString(KEY_ACTIVE_DESCRIPTOR_ID, LocalModelDescriptor.AMEER_FAST_CORE.id)
        return descriptors.find { it.id == savedId } ?: LocalModelDescriptor.AMEER_FAST_CORE
    }

    override suspend fun loadModel(descriptor: LocalModelDescriptor): Result<Boolean> = withContext(Dispatchers.Default) {
        try {
            _activeDescriptor.value = descriptor
            prefs?.edit()?.putString(KEY_ACTIVE_DESCRIPTOR_ID, descriptor.id)?.apply()

            _loadingState.value = ModelLoadingState.Loading(
                descriptor = descriptor,
                progress = 0.15f,
                phaseMessage = "فحص متطلبات الذاكرة والعتاد (${descriptor.format.titleAr})..."
            )
            delay(180)

            _loadingState.value = ModelLoadingState.Loading(
                descriptor = descriptor,
                progress = 0.55f,
                phaseMessage = "تهيئة مصفوفات الأوزان وتعيين ${descriptor.threadsCount} أنوية معالجة..."
            )
            delay(220)

            _loadingState.value = ModelLoadingState.Loading(
                descriptor = descriptor,
                progress = 0.90f,
                phaseMessage = "بناء جدول الرموز (Tokenizer) وسياق الاستدلال..."
            )
            delay(150)

            _loadingState.value = ModelLoadingState.ModelLoaded(
                descriptor = descriptor,
                memoryUsageMb = descriptor.estimatedRamMb,
                activeThreads = descriptor.threadsCount
            )

            Result.success(true)
        } catch (e: Exception) {
            _loadingState.value = ModelLoadingState.Error(
                descriptor = descriptor,
                errorMessage = "فشل في تحميل النموذج المحلي: ${e.localizedMessage}",
                cause = e
            )
            Result.failure(e)
        }
    }

    override suspend fun unloadModel(): Boolean = withContext(Dispatchers.Default) {
        _loadingState.value = ModelLoadingState.Unloaded
        true
    }

    override suspend fun selectAndApplyModel(descriptorId: String): Boolean {
        val target = descriptors.find { it.id == descriptorId } ?: return false
        val result = loadModel(target)
        return result.isSuccess
    }

    override fun getHardwareInfo(): HardwareInfo {
        val cores = Runtime.getRuntime().availableProcessors()
        val recommended = cores.coerceIn(2, 6)
        val maxMemory = Runtime.getRuntime().maxMemory() / (1024 * 1024)

        return HardwareInfo(
            availableCores = cores,
            recommendedThreads = recommended,
            totalRamMb = maxMemory,
            isGpuVulkanSupported = true,
            isNnapiSupported = true
        )
    }

    companion object {
        private const val PREFS_NAME = "ameer_ai_local_model_prefs"
        private const val KEY_ACTIVE_DESCRIPTOR_ID = "active_descriptor_id"
    }
}
