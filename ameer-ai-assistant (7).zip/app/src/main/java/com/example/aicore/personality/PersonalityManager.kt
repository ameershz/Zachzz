package com.example.aicore.personality

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface PersonalityManager {
    val personality: StateFlow<AssistantPersonality>
    fun setAssistantName(name: String)
    fun setStyle(style: PersonalityStyle)
    fun toggleRule(ruleId: String, isEnabled: Boolean)
    fun setCustomInstructions(instructions: String)
    fun resetToDefaults()
}

class PersonalityManagerImpl(context: Context? = null) : PersonalityManager {

    private val prefs: SharedPreferences? = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _personality = MutableStateFlow(loadPersonality())
    override val personality: StateFlow<AssistantPersonality> = _personality.asStateFlow()

    private fun loadPersonality(): AssistantPersonality {
        val name = prefs?.getString(KEY_NAME, "Ameer AI") ?: "Ameer AI"
        val styleId = prefs?.getString(KEY_STYLE, PersonalityStyle.BALANCED.id) ?: PersonalityStyle.BALANCED.id
        val style = PersonalityStyle.fromId(styleId)
        val custom = prefs?.getString(KEY_CUSTOM_INSTRUCTIONS, "") ?: ""

        val defaultRules = AssistantRule.getDefaultRules().map { rule ->
            val isEnabled = prefs?.getBoolean(KEY_RULE_PREFIX + rule.id, rule.isEnabled) ?: rule.isEnabled
            rule.copy(isEnabled = isEnabled)
        }

        return AssistantPersonality(
            assistantName = name,
            style = style,
            rules = defaultRules,
            customInstructions = custom
        )
    }

    override fun setAssistantName(name: String) {
        val clean = name.trim().ifEmpty { "Ameer AI" }
        prefs?.edit()?.putString(KEY_NAME, clean)?.apply()
        _personality.value = _personality.value.copy(assistantName = clean)
    }

    override fun setStyle(style: PersonalityStyle) {
        prefs?.edit()?.putString(KEY_STYLE, style.id)?.apply()
        _personality.value = _personality.value.copy(style = style)
    }

    override fun toggleRule(ruleId: String, isEnabled: Boolean) {
        prefs?.edit()?.putBoolean(KEY_RULE_PREFIX + ruleId, isEnabled)?.apply()
        val updatedRules = _personality.value.rules.map {
            if (it.id == ruleId) it.copy(isEnabled = isEnabled) else it
        }
        _personality.value = _personality.value.copy(rules = updatedRules)
    }

    override fun setCustomInstructions(instructions: String) {
        prefs?.edit()?.putString(KEY_CUSTOM_INSTRUCTIONS, instructions)?.apply()
        _personality.value = _personality.value.copy(customInstructions = instructions)
    }

    override fun resetToDefaults() {
        val editor = prefs?.edit()
        editor?.remove(KEY_STYLE)
        editor?.remove(KEY_CUSTOM_INSTRUCTIONS)
        AssistantRule.getDefaultRules().forEach { rule ->
            editor?.remove(KEY_RULE_PREFIX + rule.id)
        }
        editor?.apply()
        _personality.value = loadPersonality()
    }

    companion object {
        private const val PREFS_NAME = "ameer_ai_personality_prefs"
        private const val KEY_NAME = "assistant_name"
        private const val KEY_STYLE = "personality_style"
        private const val KEY_CUSTOM_INSTRUCTIONS = "custom_instructions"
        private const val KEY_RULE_PREFIX = "rule_enabled_"
    }
}
