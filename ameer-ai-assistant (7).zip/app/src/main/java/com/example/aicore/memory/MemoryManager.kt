package com.example.aicore.memory

import com.example.domain.model.ChatMessage
import com.example.domain.model.MemoryCategory
import com.example.domain.model.MemoryItem
import com.example.domain.model.MemoryType
import com.example.domain.repository.MemoryRepository
import kotlinx.coroutines.flow.Flow

data class MemoryContext(
    val relevantMemories: List<MemoryItem>,
    val shortTermRecentCount: Int,
    val memoryInstructionBlock: String
)

interface MemoryManager {
    val longTermMemories: Flow<List<MemoryItem>>

    suspend fun buildMemoryContext(
        prompt: String,
        history: List<ChatMessage>
    ): MemoryContext

    suspend fun saveExplicitMemory(
        key: String,
        content: String,
        category: MemoryCategory = MemoryCategory.FACT
    ): MemoryItem

    suspend fun detectAndAutoSaveMemory(prompt: String): MemoryItem?
    suspend fun deleteMemory(id: Long)
    suspend fun clearAllMemories()
}

class MemoryManagerImpl(
    private val memoryRepository: MemoryRepository
) : MemoryManager {

    override val longTermMemories: Flow<List<MemoryItem>> = memoryRepository.getLongTermMemories()

    override suspend fun buildMemoryContext(
        prompt: String,
        history: List<ChatMessage>
    ): MemoryContext {
        // 1. Short-term context: last 6 messages
        val shortTermWindow = history.takeLast(6)

        // 2. Long-term memory retrieval: relevant to current prompt
        val relevantLongTerm = memoryRepository.getRelevantMemories(prompt)

        // 3. Format Memory Context Block
        val blockBuilder = StringBuilder()
        if (relevantLongTerm.isNotEmpty()) {
            blockBuilder.appendLine("=== سياق الذاكرة طويلة المدى المحفوظة عن المستخدم ===")
            relevantLongTerm.forEach { memory ->
                blockBuilder.appendLine("• [${memory.category.titleAr}] ${memory.key}: ${memory.content}")
            }
            blockBuilder.appendLine("استخدم هذه المعلومات لتقديم إجابة مخصصة ومراعية لتفضيلات وهوية المستخدم.")
        }

        return MemoryContext(
            relevantMemories = relevantLongTerm,
            shortTermRecentCount = shortTermWindow.size,
            memoryInstructionBlock = blockBuilder.toString().trim()
        )
    }

    override suspend fun saveExplicitMemory(
        key: String,
        content: String,
        category: MemoryCategory
    ): MemoryItem {
        val item = MemoryItem(
            key = key.trim(),
            content = content.trim(),
            type = MemoryType.LONG_TERM,
            category = category,
            createdAt = System.currentTimeMillis(),
            lastAccessed = System.currentTimeMillis()
        )
        val id = memoryRepository.saveMemory(item)
        return item.copy(id = id)
    }

    override suspend fun detectAndAutoSaveMemory(prompt: String): MemoryItem? {
        val trimmed = prompt.trim()

        // Check for explicit commands like "تذكر أن...", "احفظ أن...", "remember that..."
        val triggers = listOf(
            "تذكر أنني" to MemoryCategory.USER_PROFILE,
            "تذكر أن" to MemoryCategory.FACT,
            "احفظ أنني" to MemoryCategory.USER_PROFILE,
            "احفظ أن" to MemoryCategory.FACT,
            "تذكر أن اسمي" to MemoryCategory.USER_PROFILE,
            "احفظ أن اسمي" to MemoryCategory.USER_PROFILE,
            "تذكر تفضيلي" to MemoryCategory.PREFERENCE,
            "احفظ تفضيلي" to MemoryCategory.PREFERENCE,
            "remember that i am" to MemoryCategory.USER_PROFILE,
            "remember that" to MemoryCategory.FACT,
            "save that" to MemoryCategory.FACT
        )

        for ((trigger, category) in triggers) {
            val idx = trimmed.indexOf(trigger, ignoreCase = true)
            if (idx != -1) {
                val fact = trimmed.substring(idx + trigger.length).trim(':', ' ', '،', '-')
                if (fact.length > 2) {
                    val key = when {
                        fact.contains("اسمي") || trigger.contains("اسمي") -> "اسم المستخدم"
                        fact.contains("أحب") || fact.contains("أفضل") || fact.contains("prefer") -> "تفضيل شخصي"
                        fact.contains("أعمل") || fact.contains("أدرس") -> "المهنة / التخصص"
                        else -> "معلومة هامة"
                    }
                    return saveExplicitMemory(key, fact, category)
                }
            }
        }
        return null
    }

    override suspend fun deleteMemory(id: Long) {
        memoryRepository.deleteMemory(id)
    }

    override suspend fun clearAllMemories() {
        memoryRepository.clearAllLongTermMemories()
    }
}
