package com.example.domain.repository

import com.example.domain.model.MemoryItem
import kotlinx.coroutines.flow.Flow

/**
 * Domain interface for Memory System persistence and recall.
 */
interface MemoryRepository {
    fun getLongTermMemories(): Flow<List<MemoryItem>>
    suspend fun getAllMemoriesList(): List<MemoryItem>
    suspend fun getMemoryById(id: Long): MemoryItem?
    suspend fun saveMemory(memory: MemoryItem): Long
    suspend fun updateMemory(memory: MemoryItem)
    suspend fun deleteMemory(id: Long)
    suspend fun clearAllLongTermMemories()
    suspend fun searchMemories(query: String): List<MemoryItem>
    suspend fun getRelevantMemories(prompt: String): List<MemoryItem>
}
