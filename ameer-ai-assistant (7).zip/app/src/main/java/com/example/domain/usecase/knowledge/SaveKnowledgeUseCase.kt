package com.example.domain.usecase.knowledge

import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.repository.KnowledgeRepository

class SaveKnowledgeUseCase(
    private val knowledgeRepository: KnowledgeRepository
) {
    suspend operator fun invoke(item: KnowledgeItem): Long {
        require(item.title.isNotBlank()) { "Knowledge title cannot be blank" }
        require(item.content.isNotBlank()) { "Knowledge content cannot be blank" }
        return knowledgeRepository.saveKnowledge(item)
    }
}
