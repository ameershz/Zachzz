package com.example.domain.usecase.memory

import com.example.domain.model.ChatMessage
import com.example.domain.model.MemoryCategory
import com.example.domain.model.MemoryItem
import com.example.domain.model.memory.RetrievedMemoryContext
import com.example.domain.repository.MemoryRepository

/**
 * Coordinates Short-Term context (sliding window of active chat)
 * and Long-Term persistent memories to inject into the AI Core reasoning flow.
 */
class RetrieveRelevantContextUseCase(
    private val memoryRepository: MemoryRepository
) {
    suspend operator fun invoke(
        prompt: String,
        history: List<ChatMessage>
    ): RetrievedMemoryContext {
        // 1. Short-Term Memory: summarize recent exchanges (last 4 messages)
        val shortTermSummary = if (history.isNotEmpty()) {
            val recent = history.takeLast(4)
            recent.joinToString(separator = " | ") {
                "${it.sender.name}: ${it.content.take(60)}"
            }
        } else {
            ""
        }

        // 2. Long-Term Memory: retrieve snapshot of saved user preferences and facts
        val allMemories: List<MemoryItem> = memoryRepository.getAllMemoriesList()

        // Filter or rank memories relevant to the prompt, or retain user profile & preferences
        val promptWords = prompt.lowercase().split("\\s+".toRegex()).filter { it.length > 2 }
        val matched = allMemories.filter { item ->
            val contentLower = (item.key + " " + item.content).lowercase()
            promptWords.any { word -> contentLower.contains(word) } ||
                    item.category == MemoryCategory.USER_PROFILE ||
                    item.category == MemoryCategory.PREFERENCE
        }

        val selectedMemories = if (matched.isNotEmpty()) matched else allMemories.take(5)

        return RetrievedMemoryContext(
            recentMessagesSummary = shortTermSummary,
            relevantLongTermMemories = selectedMemories
        )
    }
}
