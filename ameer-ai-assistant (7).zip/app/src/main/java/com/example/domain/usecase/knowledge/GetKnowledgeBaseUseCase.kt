package com.example.domain.usecase.knowledge

import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.repository.KnowledgeRepository
import kotlinx.coroutines.flow.Flow

class GetKnowledgeBaseUseCase(
    private val knowledgeRepository: KnowledgeRepository
) {
    operator fun invoke(): Flow<List<KnowledgeItem>> {
        return knowledgeRepository.getKnowledgeFlow()
    }
}
