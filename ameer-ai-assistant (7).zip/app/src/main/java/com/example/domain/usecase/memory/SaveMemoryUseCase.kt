package com.example.domain.usecase.memory

import com.example.domain.model.MemoryItem
import com.example.domain.repository.MemoryRepository

class SaveMemoryUseCase(
    private val memoryRepository: MemoryRepository
) {
    suspend operator fun invoke(memory: MemoryItem): Long {
        require(memory.key.isNotBlank()) { "Memory key cannot be blank" }
        require(memory.content.isNotBlank()) { "Memory content cannot be blank" }
        return memoryRepository.saveMemory(memory)
    }
}
