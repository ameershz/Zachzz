package com.example.domain.usecase.knowledge

import com.example.domain.repository.KnowledgeRepository

class ClearAllKnowledgeUseCase(
    private val knowledgeRepository: KnowledgeRepository
) {
    suspend operator fun invoke() {
        knowledgeRepository.clearAllKnowledge()
    }
}
