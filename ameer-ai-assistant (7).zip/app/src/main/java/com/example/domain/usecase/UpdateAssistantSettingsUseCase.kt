package com.example.domain.usecase

import com.example.domain.repository.SettingsRepository

class UpdateAssistantSettingsUseCase(
    private val settingsRepository: SettingsRepository
) {
    suspend fun updateName(name: String) {
        settingsRepository.updateAssistantName(name)
    }

    suspend fun toggleVoice(enabled: Boolean) {
        settingsRepository.toggleVoiceMode(enabled)
    }
}
