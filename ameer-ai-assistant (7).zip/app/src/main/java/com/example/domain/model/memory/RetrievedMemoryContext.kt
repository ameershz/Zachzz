package com.example.domain.model.memory

import com.example.domain.model.MemoryItem

/**
 * Encapsulates both Short-Term conversation context and Long-Term retrieved memories
 * to be injected into the AI Core reasoning pipeline.
 */
data class RetrievedMemoryContext(
    val recentMessagesSummary: String = "",
    val relevantLongTermMemories: List<MemoryItem> = emptyList()
) {
    fun hasMemories(): Boolean = relevantLongTermMemories.isNotEmpty() || recentMessagesSummary.isNotBlank()

    fun formatForPrompt(): String {
        if (!hasMemories()) return ""

        val builder = StringBuilder()
        builder.appendLine("=== سياق الذاكرة الذكية المسترجعة (Memory System) ===")

        if (relevantLongTermMemories.isNotEmpty()) {
            builder.appendLine("• الذاكرة طويلة الأمد (معلومات وتفضيلات المستخدم المستمرة):")
            relevantLongTermMemories.forEach { memory ->
                builder.appendLine("  - [${memory.category.titleAr}] ${memory.key}: ${memory.content}")
            }
        }

        if (recentMessagesSummary.isNotBlank()) {
            builder.appendLine("• سياق الذاكرة قصيرة الأمد (سياق الجلسة الحالية):")
            builder.appendLine("  $recentMessagesSummary")
        }

        return builder.toString().trim()
    }
}
