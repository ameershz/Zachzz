package com.example.domain.usecase.knowledge

import com.example.domain.model.knowledge.KnowledgeChunk
import com.example.domain.repository.KnowledgeRepository

class RetrieveKnowledgeUseCase(
    private val knowledgeRepository: KnowledgeRepository
) {
    suspend operator fun invoke(query: String, topK: Int = 3): List<KnowledgeChunk> {
        return knowledgeRepository.retrieveRelevantChunks(query, topK)
    }
}
