package com.example.domain.model

data class Conversation(
    val id: Long = 0,
    val title: String = "Main Chat",
    val createdAt: Long = System.currentTimeMillis(),
    val lastModified: Long = System.currentTimeMillis()
)
