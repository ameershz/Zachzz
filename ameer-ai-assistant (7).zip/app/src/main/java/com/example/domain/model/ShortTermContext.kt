package com.example.domain.model

/**
 * Encapsulates the active session context (Short-Term Memory).
 */
data class ShortTermContext(
    val conversationId: Long,
    val recentMessages: List<ChatMessage>,
    val topicSummary: String? = null
)
