package com.example.domain.usecase.memory

import com.example.domain.model.MemoryItem
import com.example.domain.repository.MemoryRepository

class GetRelevantMemoriesUseCase(
    private val memoryRepository: MemoryRepository
) {
    suspend operator fun invoke(prompt: String): List<MemoryItem> {
        return memoryRepository.getRelevantMemories(prompt)
    }
}
