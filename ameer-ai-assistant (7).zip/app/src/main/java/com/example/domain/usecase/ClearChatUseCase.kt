package com.example.domain.usecase

import com.example.domain.repository.ChatRepository

class ClearChatUseCase(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(conversationId: Long) {
        chatRepository.clearMessages(conversationId)
    }

    suspend operator fun invoke() {
        val defaultConv = chatRepository.getOrCreateDefaultConversation()
        chatRepository.clearMessages(defaultConv.id)
    }
}
