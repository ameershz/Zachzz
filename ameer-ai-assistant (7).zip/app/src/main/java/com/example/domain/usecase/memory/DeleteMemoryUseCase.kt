package com.example.domain.usecase.memory

import com.example.domain.repository.MemoryRepository

class DeleteMemoryUseCase(
    private val memoryRepository: MemoryRepository
) {
    suspend operator fun invoke(id: Long) {
        memoryRepository.deleteMemory(id)
    }
}
