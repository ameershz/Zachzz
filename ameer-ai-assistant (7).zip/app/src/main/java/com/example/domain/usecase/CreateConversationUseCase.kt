package com.example.domain.usecase

import com.example.domain.model.Conversation
import com.example.domain.repository.ChatRepository

class CreateConversationUseCase(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(title: String = "محادثة جديدة"): Conversation {
        return chatRepository.createConversation(title)
    }
}
