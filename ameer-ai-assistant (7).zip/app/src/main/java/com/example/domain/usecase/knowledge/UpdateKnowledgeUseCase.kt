package com.example.domain.usecase.knowledge

import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.repository.KnowledgeRepository

class UpdateKnowledgeUseCase(
    private val knowledgeRepository: KnowledgeRepository
) {
    suspend operator fun invoke(item: KnowledgeItem) {
        require(item.title.isNotBlank()) { "Knowledge title cannot be blank" }
        require(item.content.isNotBlank()) { "Knowledge content cannot be blank" }
        knowledgeRepository.updateKnowledge(item)
    }
}
