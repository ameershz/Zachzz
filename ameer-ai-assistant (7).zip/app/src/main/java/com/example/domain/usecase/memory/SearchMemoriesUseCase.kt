package com.example.domain.usecase.memory

import com.example.domain.model.MemoryItem
import com.example.domain.repository.MemoryRepository

class SearchMemoriesUseCase(
    private val memoryRepository: MemoryRepository
) {
    suspend operator fun invoke(query: String): List<MemoryItem> {
        return memoryRepository.searchMemories(query)
    }
}
