package com.example.domain.model

/**
 * Distinguishes between conversational session context (Short-Term)
 * and persistent user facts/preferences (Long-Term).
 */
enum class MemoryType {
    SHORT_TERM,
    LONG_TERM
}
