package com.example.domain.model

enum class MemoryCategory(val titleAr: String) {
    USER_PROFILE("الملف الشخصي والاسم"),
    PREFERENCE("التفضيلات والأسلوب المفضل"),
    FACT("حقائق ومعلومات عامة"),
    CUSTOM("مخصص")
}
