package com.example.domain.usecase

import com.example.domain.model.AssistantSettings
import com.example.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow

class GetAssistantSettingsUseCase(
    private val settingsRepository: SettingsRepository
) {
    operator fun invoke(): Flow<AssistantSettings> {
        return settingsRepository.getSettings()
    }
}
