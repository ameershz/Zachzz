package com.example.domain.repository

import com.example.domain.model.ChatMessage

/**
 * Domain interface for AI text generation.
 * Decouples the business logic from any specific AI service or remote API.
 */
interface AIRepository {
    suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String
    ): Result<String>
}
