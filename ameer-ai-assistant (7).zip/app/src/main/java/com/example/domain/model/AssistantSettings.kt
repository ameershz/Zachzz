package com.example.domain.model

data class AssistantSettings(
    val assistantName: String = "Ameer AI",
    val isVoiceModeEnabled: Boolean = false,
    val systemPrompt: String = "You are Ameer AI, an intelligent, helpful, and concise AI assistant."
)
