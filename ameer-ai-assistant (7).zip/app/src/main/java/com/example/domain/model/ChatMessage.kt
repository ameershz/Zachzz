package com.example.domain.model

data class ChatMessage(
    val id: Long = 0,
    val conversationId: Long = 1,
    val sender: MessageSender,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isPending: Boolean = false
)
