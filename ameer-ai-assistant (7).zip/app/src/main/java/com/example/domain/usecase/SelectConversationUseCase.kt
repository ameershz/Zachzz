package com.example.domain.usecase

import com.example.domain.model.Conversation
import com.example.domain.repository.ChatRepository

class SelectConversationUseCase(
    private val chatRepository: ChatRepository
) {
    suspend operator fun invoke(conversationId: Long): Conversation? {
        return chatRepository.getConversationById(conversationId)
    }
}
