package com.example.domain.usecase.knowledge

import com.example.domain.repository.KnowledgeRepository

class DeleteKnowledgeUseCase(
    private val knowledgeRepository: KnowledgeRepository
) {
    suspend operator fun invoke(id: Long) {
        knowledgeRepository.deleteKnowledge(id)
    }
}
