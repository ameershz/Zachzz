package com.example.domain.usecase

import com.example.domain.model.ChatMessage
import com.example.domain.repository.ChatRepository
import kotlinx.coroutines.flow.Flow

class GetMessagesUseCase(
    private val chatRepository: ChatRepository
) {
    operator fun invoke(conversationId: Long): Flow<List<ChatMessage>> {
        return chatRepository.getMessages(conversationId)
    }
}
