package com.example.domain.usecase.memory

import com.example.domain.model.MemoryItem
import com.example.domain.repository.MemoryRepository
import kotlinx.coroutines.flow.Flow

class GetMemoriesUseCase(
    private val memoryRepository: MemoryRepository
) {
    operator fun invoke(): Flow<List<MemoryItem>> {
        return memoryRepository.getLongTermMemories()
    }
}
