package com.example.domain.usecase.memory

import com.example.domain.repository.MemoryRepository

class ClearAllMemoriesUseCase(
    private val memoryRepository: MemoryRepository
) {
    suspend operator fun invoke() {
        memoryRepository.clearAllLongTermMemories()
    }
}
