package com.example.domain.repository

import com.example.domain.model.knowledge.KnowledgeChunk
import com.example.domain.model.knowledge.KnowledgeItem
import kotlinx.coroutines.flow.Flow

interface KnowledgeRepository {
    fun getKnowledgeFlow(): Flow<List<KnowledgeItem>>
    suspend fun getAllKnowledge(): List<KnowledgeItem>
    suspend fun getKnowledgeById(id: Long): KnowledgeItem?
    suspend fun searchKnowledge(query: String): List<KnowledgeItem>
    suspend fun saveKnowledge(item: KnowledgeItem): Long
    suspend fun updateKnowledge(item: KnowledgeItem)
    suspend fun deleteKnowledge(id: Long)
    suspend fun clearAllKnowledge()
    suspend fun retrieveRelevantChunks(query: String, topK: Int = 3): List<KnowledgeChunk>
}
