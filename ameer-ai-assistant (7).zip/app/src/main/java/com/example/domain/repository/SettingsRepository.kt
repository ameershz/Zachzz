package com.example.domain.repository

import com.example.domain.model.AssistantSettings
import kotlinx.coroutines.flow.Flow

/**
 * Domain interface for assistant preferences and configuration.
 */
interface SettingsRepository {
    fun getSettings(): Flow<AssistantSettings>
    suspend fun updateAssistantName(name: String)
    suspend fun toggleVoiceMode(enabled: Boolean)
}
