package com.example.domain.usecase.memory

import com.example.domain.model.MemoryItem
import com.example.domain.repository.MemoryRepository

class UpdateMemoryUseCase(
    private val memoryRepository: MemoryRepository
) {
    suspend operator fun invoke(memory: MemoryItem) {
        require(memory.key.isNotBlank()) { "Memory key cannot be blank" }
        require(memory.content.isNotBlank()) { "Memory content cannot be blank" }
        memoryRepository.updateMemory(memory)
    }
}
