package com.example.domain.model

/**
 * Domain model representing a single remembered piece of information.
 */
data class MemoryItem(
    val id: Long = 0,
    val key: String,
    val content: String,
    val type: MemoryType = MemoryType.LONG_TERM,
    val category: MemoryCategory = MemoryCategory.FACT,
    val createdAt: Long = System.currentTimeMillis(),
    val lastAccessed: Long = System.currentTimeMillis()
)
