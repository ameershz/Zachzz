package com.example.domain.model.knowledge

enum class KnowledgeSourceType(val titleAr: String, val badge: String) {
    MANUAL_TEXT("نص يدوي", "نص"),
    DOCUMENT_PDF("مستند PDF (مُجهز)", "PDF"),
    NOTE("ملاحظة معرفية", "ملاحظة"),
    ARTICLE("مقال / مرجع", "مرجع")
}

enum class KnowledgeCategory(val titleAr: String) {
    TECHNICAL("تقني وبرمجي"),
    GENERAL("عام وثقافي"),
    WORK_STUDY("عمل ودراسة"),
    DOCUMENTATION("توثيق ومراجع"),
    CUSTOM("مخصص")
}

/**
 * Domain entity representing an indexed item in Ameer AI's Knowledge Base.
 */
data class KnowledgeItem(
    val id: Long = 0,
    val title: String,
    val content: String,
    val category: KnowledgeCategory = KnowledgeCategory.GENERAL,
    val sourceType: KnowledgeSourceType = KnowledgeSourceType.MANUAL_TEXT,
    val tags: List<String> = emptyList(),
    val sourceFileName: String? = null,
    val sourceUri: String? = null,
    val pageCount: Int? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

/**
 * Represents a discrete relevant chunk extracted during RAG retrieval.
 */
data class KnowledgeChunk(
    val chunkId: String,
    val knowledgeId: Long,
    val title: String,
    val text: String,
    val relevanceScore: Float,
    val sourceType: KnowledgeSourceType = KnowledgeSourceType.MANUAL_TEXT
)

/**
 * Encapsulates the retrieved RAG context to be injected into the reasoning prompt.
 */
data class RagContext(
    val relevantChunks: List<KnowledgeChunk> = emptyList(),
    val ragPromptBlock: String = ""
) {
    val hasKnowledge: Boolean get() = relevantChunks.isNotEmpty()
}
