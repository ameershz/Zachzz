package com.example.domain.usecase.knowledge

import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.repository.KnowledgeRepository

class SearchKnowledgeUseCase(
    private val knowledgeRepository: KnowledgeRepository
) {
    suspend operator fun invoke(query: String): List<KnowledgeItem> {
        return knowledgeRepository.searchKnowledge(query)
    }
}
