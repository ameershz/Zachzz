package com.example.domain.model

enum class MessageSender {
    USER,
    ASSISTANT
}
