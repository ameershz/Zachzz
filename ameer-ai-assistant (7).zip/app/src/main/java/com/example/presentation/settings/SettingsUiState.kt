package com.example.presentation.settings

import com.example.aicore.localmodel.DeviceCapabilityReport
import com.example.aicore.localmodel.DownloadState
import com.example.aicore.localmodel.HardwareInfo
import com.example.aicore.localmodel.LocalModelDescriptor
import com.example.aicore.localmodel.LocalModelMode
import com.example.aicore.localmodel.ModelLoadingState
import com.example.aicore.model.AIModel
import com.example.aicore.model.LocalModelInfo
import com.example.aicore.personality.AssistantRule
import com.example.aicore.personality.PersonalityStyle
import com.example.domain.model.MemoryCategory
import com.example.domain.model.MemoryItem
import com.example.domain.model.knowledge.KnowledgeCategory
import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.model.knowledge.KnowledgeSourceType

data class SettingsUiState(
    val assistantName: String = "Ameer AI",
    val personalityStyle: PersonalityStyle = PersonalityStyle.BALANCED,
    val rules: List<AssistantRule> = AssistantRule.getDefaultRules(),
    val availableModels: List<AIModel> = AIModel.getDefaultModels(),
    val activeModel: AIModel = AIModel.QWEN_2_5_1_5B,

    // Multi-Model Local AI Engine & Mode Selector
    val activeMode: LocalModelMode = LocalModelMode.AUTO_ADAPTIVE,
    val localDescriptors: List<LocalModelDescriptor> = LocalModelDescriptor.getAvailableDescriptors(),
    val fastModeDescriptors: List<LocalModelDescriptor> = LocalModelDescriptor.getFastModeDescriptors(),
    val proModeDescriptors: List<LocalModelDescriptor> = LocalModelDescriptor.getProModeDescriptors(),
    val activeLocalDescriptor: LocalModelDescriptor = LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM,
    val modelLoadingState: ModelLoadingState = ModelLoadingState.ModelLoaded(
        descriptor = LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM,
        memoryUsageMb = LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM.estimatedRamMb,
        activeThreads = LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM.threadsCount
    ),
    val hardwareInfo: HardwareInfo? = null,
    val deviceReport: DeviceCapabilityReport? = null,

    // Local Model Downloader & Management ("إدارة العقل المحلي")
    val localModelsInfo: List<LocalModelInfo> = emptyList(),
    val downloadStates: Map<String, DownloadState> = emptyMap(),
    val totalStorageUsage: String = "0 MB",

    // Memory System
    val memories: List<MemoryItem> = emptyList(),
    val memorySearchQuery: String = "",
    val isAddMemoryDialogOpen: Boolean = false,
    val newMemoryKey: String = "",
    val newMemoryContent: String = "",
    val newMemoryCategory: MemoryCategory = MemoryCategory.FACT,
    val isEditMemoryDialogOpen: Boolean = false,
    val editingMemoryId: Long? = null,
    val editMemoryKey: String = "",
    val editMemoryContent: String = "",
    val editMemoryCategory: MemoryCategory = MemoryCategory.FACT,
    val isClearMemoriesDialogOpen: Boolean = false,
    val memoryToDelete: MemoryItem? = null,

    // Knowledge Base System (RAG)
    val knowledgeList: List<KnowledgeItem> = emptyList(),
    val knowledgeSearchQuery: String = "",
    val isAddKnowledgeDialogOpen: Boolean = false,
    val newKnowledgeTitle: String = "",
    val newKnowledgeContent: String = "",
    val newKnowledgeCategory: KnowledgeCategory = KnowledgeCategory.GENERAL,
    val newKnowledgeSourceType: KnowledgeSourceType = KnowledgeSourceType.MANUAL_TEXT,
    val newKnowledgeTags: String = "",
    val isEditKnowledgeDialogOpen: Boolean = false,
    val editingKnowledgeId: Long? = null,
    val editKnowledgeTitle: String = "",
    val editKnowledgeContent: String = "",
    val editKnowledgeCategory: KnowledgeCategory = KnowledgeCategory.GENERAL,
    val editKnowledgeSourceType: KnowledgeSourceType = KnowledgeSourceType.MANUAL_TEXT,
    val editKnowledgeTags: String = "",
    val isClearKnowledgeDialogOpen: Boolean = false,

    // General Settings
    val isVoiceModeEnabled: Boolean = false,
    val isEditingName: Boolean = false,
    val nameInputText: String = "Ameer AI",
    val isClearDialogOpen: Boolean = false,
    val messageSnackbar: String? = null
) {
    val displayedMemories: List<MemoryItem>
        get() = if (memorySearchQuery.isBlank()) {
            memories
        } else {
            val q = memorySearchQuery.trim().lowercase()
            memories.filter {
                it.key.lowercase().contains(q) ||
                it.content.lowercase().contains(q) ||
                it.category.titleAr.lowercase().contains(q)
            }
        }

    val displayedKnowledge: List<KnowledgeItem>
        get() = if (knowledgeSearchQuery.isBlank()) {
            knowledgeList
        } else {
            val q = knowledgeSearchQuery.trim().lowercase()
            knowledgeList.filter {
                it.title.lowercase().contains(q) ||
                it.content.lowercase().contains(q) ||
                it.category.titleAr.lowercase().contains(q) ||
                it.tags.any { tag -> tag.lowercase().contains(q) }
            }
        }
}
