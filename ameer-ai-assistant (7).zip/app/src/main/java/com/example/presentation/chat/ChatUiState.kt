package com.example.presentation.chat

import com.example.domain.model.ChatMessage
import com.example.domain.model.Conversation
import com.example.utils.Constants

data class ChatUiState(
    val currentConversationId: Long = Constants.DEFAULT_CONVERSATION_ID,
    val currentConversationTitle: String = "المحادثة الرئيسية",
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val isGenerating: Boolean = false,
    val assistantName: String = Constants.DEFAULT_ASSISTANT_NAME,
    val suggestions: List<String> = Constants.QUICK_PROMPTS,
    val errorMessage: String? = null,
    val isClearDialogOpen: Boolean = false
)
