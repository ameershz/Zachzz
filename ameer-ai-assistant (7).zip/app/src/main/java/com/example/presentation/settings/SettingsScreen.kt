package com.example.presentation.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.aicore.localmodel.DownloadState
import com.example.aicore.localmodel.LocalModelDescriptor
import com.example.aicore.localmodel.LocalModelMode
import com.example.aicore.localmodel.ModelLoadingState
import com.example.aicore.localmodel.ModelTier
import com.example.aicore.personality.PersonalityStyle
import com.example.domain.model.MemoryCategory
import com.example.domain.model.MemoryItem
import com.example.domain.model.knowledge.KnowledgeCategory
import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.model.knowledge.KnowledgeSourceType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    uiState: SettingsUiState,
    onNavigateBack: () -> Unit,
    onNameInputChanged: (String) -> Unit,
    onSaveName: () -> Unit,
    onSetEditingName: (Boolean) -> Unit,
    onSelectPersonalityStyle: (PersonalityStyle) -> Unit,
    onToggleRule: (String, Boolean) -> Unit,
    onSelectModel: (String) -> Unit,
    onSelectMode: (LocalModelMode) -> Unit = {},
    onSelectLocalDescriptor: (String) -> Unit = {},
    // Local Brain & Model Downloader Callbacks
    onStartDownloadModel: (String) -> Unit = {},
    onPauseDownloadModel: (String) -> Unit = {},
    onResumeDownloadModel: (String) -> Unit = {},
    onActivateModel: (String) -> Unit = {},
    onDeleteModel: (String) -> Unit = {},
    // Memory System Callbacks
    onShowAddMemoryDialog: () -> Unit,
    onDismissAddMemoryDialog: () -> Unit,
    onNewMemoryKeyChanged: (String) -> Unit,
    onNewMemoryContentChanged: (String) -> Unit,
    onNewMemoryCategoryChanged: (MemoryCategory) -> Unit,
    onSaveNewMemory: () -> Unit,
    onMemorySearchQueryChanged: (String) -> Unit = {},
    onShowEditMemoryDialog: (MemoryItem) -> Unit = {},
    onDismissEditMemoryDialog: () -> Unit = {},
    onEditMemoryKeyChanged: (String) -> Unit = {},
    onEditMemoryContentChanged: (String) -> Unit = {},
    onEditMemoryCategoryChanged: (MemoryCategory) -> Unit = {},
    onSaveEditedMemory: () -> Unit = {},
    onDeleteMemory: (Long) -> Unit,
    onShowClearMemoriesDialog: () -> Unit,
    onDismissClearMemoriesDialog: () -> Unit,
    onConfirmClearAllMemories: () -> Unit,
    // Knowledge Base System Callbacks (RAG)
    onKnowledgeSearchQueryChanged: (String) -> Unit = {},
    onShowAddKnowledgeDialog: () -> Unit = {},
    onDismissAddKnowledgeDialog: () -> Unit = {},
    onNewKnowledgeTitleChanged: (String) -> Unit = {},
    onNewKnowledgeContentChanged: (String) -> Unit = {},
    onNewKnowledgeCategoryChanged: (KnowledgeCategory) -> Unit = {},
    onNewKnowledgeSourceTypeChanged: (KnowledgeSourceType) -> Unit = {},
    onNewKnowledgeTagsChanged: (String) -> Unit = {},
    onSaveNewKnowledge: () -> Unit = {},
    onShowEditKnowledgeDialog: (KnowledgeItem) -> Unit = {},
    onDismissEditKnowledgeDialog: () -> Unit = {},
    onEditKnowledgeTitleChanged: (String) -> Unit = {},
    onEditKnowledgeContentChanged: (String) -> Unit = {},
    onEditKnowledgeCategoryChanged: (KnowledgeCategory) -> Unit = {},
    onEditKnowledgeSourceTypeChanged: (KnowledgeSourceType) -> Unit = {},
    onEditKnowledgeTagsChanged: (String) -> Unit = {},
    onSaveEditedKnowledge: () -> Unit = {},
    onDeleteKnowledge: (Long) -> Unit = {},
    onShowClearKnowledgeDialog: () -> Unit = {},
    onDismissClearKnowledgeDialog: () -> Unit = {},
    onConfirmClearAllKnowledge: () -> Unit = {},
    // Other settings
    onToggleVoiceMode: (Boolean) -> Unit,
    onShowClearDialog: () -> Unit,
    onDismissClearDialog: () -> Unit,
    onConfirmClear: () -> Unit,
    onSnackbarShown: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.messageSnackbar) {
        uiState.messageSnackbar?.let { message ->
            snackbarHostState.showSnackbar(message)
            onSnackbarShown()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(id = R.string.settings_title),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Section 1: Assistant Identity & Name
            Text(
                text = "هوية المساعد الذكي",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = stringResource(id = R.string.assistant_name_label),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = uiState.assistantName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        IconButton(
                            onClick = { onSetEditingName(!uiState.isEditingName) },
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("edit_name_button")
                        ) {
                            Icon(
                                imageVector = if (uiState.isEditingName) Icons.Default.Check else Icons.Default.Edit,
                                contentDescription = "Edit Name",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    if (uiState.isEditingName) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = uiState.nameInputText,
                                onValueChange = onNameInputChanged,
                                label = { Text("الاسم الجديد") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("name_text_field"),
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = onSaveName,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("save_name_button")
                            ) {
                                Text("حفظ")
                            }
                        }
                    }
                }
            }

            // Section 2: Local Brain Management & Model Downloader (إدارة العقل المحلي)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "إدارة العقل المحلي (Local AI Brain)",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storage,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "المساحة: ${uiState.totalStorageUsage}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Active Brain Status Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Psychology,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "العقل النشط: ${uiState.activeLocalDescriptor.name}",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                val statusText = when (val state = uiState.modelLoadingState) {
                                    is ModelLoadingState.ModelLoaded -> "جاهز ويعمل محلياً 100% (${uiState.activeLocalDescriptor.quantization.name})"
                                    is ModelLoadingState.Loading -> state.phaseMessage
                                    is ModelLoadingState.NotAvailable -> "غير متاح (يحتاج تحميل من أسفل الصفحة)"
                                    is ModelLoadingState.Unloaded -> "غير محمل في الذاكرة"
                                    is ModelLoadingState.Error -> "خطأ في التحميل: ${state.errorMessage}"
                                }
                                Text(
                                    text = statusText,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = "ON-DEVICE",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Operating Mode Switcher (Fast Mode / Pro Mode / Auto Adaptive)
                    Text(
                        text = "وضع التشغيل والاستدلال:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LocalModelMode.entries.forEach { mode ->
                            val isModeActive = uiState.activeMode == mode
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isModeActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                border = if (isModeActive) {
                                    androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                                } else null,
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSelectMode(mode) }
                                    .testTag("mode_${mode.id}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = when (mode) {
                                            LocalModelMode.FAST -> "⚡ Fast Mode"
                                            LocalModelMode.PRO -> "🧠 Pro Mode"
                                            LocalModelMode.AUTO_ADAPTIVE -> "🤖 Auto"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = if (isModeActive) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isModeActive) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = mode.badge,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 8.sp,
                                        color = if (isModeActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // Active Mode Description Banner
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "${uiState.activeMode.titleAr}: ${uiState.activeMode.descriptionAr}",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "الاستخدامات: ${uiState.activeMode.targetUseCases}",
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Models Downloader & Manager List
                    Text(
                        text = "النماذج المتاحة للتحميل والتشغيل على الجهاز:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )

                    uiState.localDescriptors.forEach { descriptor ->
                        val isSelected = descriptor.id == uiState.activeLocalDescriptor.id
                        val downloadState = uiState.downloadStates[descriptor.id] ?: DownloadState.Idle
                        val isDownloaded = descriptor.isBundledReady || downloadState is DownloadState.Completed

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surface,
                            border = if (isSelected) {
                                androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                            } else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("local_model_card_${descriptor.id}")
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Model Header (Name, Format, Quantization, Size)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = descriptor.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (descriptor.id == LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM.id) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = MaterialTheme.colorScheme.primary
                                                ) {
                                                    Text(
                                                        text = "نموذج معتمد ⭐",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onPrimary,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(3.dp))

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (descriptor.tier == ModelTier.FAST_TIER) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.secondaryContainer
                                            ) {
                                                Text(
                                                    text = if (descriptor.tier == ModelTier.FAST_TIER) "Fast ⚡" else "Pro 🧠",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (descriptor.tier == ModelTier.FAST_TIER) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSecondaryContainer,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant
                                            ) {
                                                Text(
                                                    text = descriptor.quantization.name,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 9.sp,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant
                                            ) {
                                                Text(
                                                    text = descriptor.formattedSize,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.surfaceVariant
                                            ) {
                                                Text(
                                                    text = "رام ~${descriptor.requiredRamMb}MB",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 9.sp,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }

                                    if (isSelected) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.primaryContainer
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = "Active",
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text(
                                                    text = "النشط",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }
                                    }
                                }

                                Text(
                                    text = descriptor.descriptionAr,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                // Download Progress View
                                if (downloadState is DownloadState.Downloading) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "جاري التحميل: ${downloadState.progressPercentage}% (${downloadState.speedFormatted})",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = downloadState.etaFormatted,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        LinearProgressIndicator(
                                            progress = { downloadState.progress },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(6.dp)
                                                .clip(RoundedCornerShape(3.dp))
                                        )
                                    }
                                } else if (downloadState is DownloadState.Paused) {
                                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = "متوقف مؤقتاً عند: ${downloadState.progressPercentage}%",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.tertiary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        LinearProgressIndicator(
                                            progress = { downloadState.progress },
                                            color = MaterialTheme.colorScheme.tertiary,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(6.dp)
                                                .clip(RoundedCornerShape(3.dp))
                                        )
                                    }
                                }

                                // Action Buttons (Download, Pause, Resume, Activate, Delete)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    when {
                                        downloadState is DownloadState.Downloading -> {
                                            OutlinedButton(
                                                onClick = { onPauseDownloadModel(descriptor.id) },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.weight(1f).testTag("pause_download_${descriptor.id}")
                                            ) {
                                                Icon(imageVector = Icons.Default.Pause, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("إيقاف مؤقت", fontSize = 11.sp)
                                            }
                                        }
                                        downloadState is DownloadState.Paused -> {
                                            Button(
                                                onClick = { onResumeDownloadModel(descriptor.id) },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.weight(1f).testTag("resume_download_${descriptor.id}")
                                            ) {
                                                Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("استئناف التحميل", fontSize = 11.sp)
                                            }
                                        }
                                        isDownloaded -> {
                                            if (!isSelected) {
                                                Button(
                                                    onClick = { onActivateModel(descriptor.id) },
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f).testTag("activate_model_${descriptor.id}")
                                                ) {
                                                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("تشغيل العقل 🚀", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                }
                                            } else {
                                                Button(
                                                    onClick = { onActivateModel(descriptor.id) },
                                                    shape = RoundedCornerShape(10.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                                    modifier = Modifier.weight(1f).testTag("reload_model_${descriptor.id}")
                                                ) {
                                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("النموذج النشط حالياً", fontSize = 11.sp)
                                                }
                                            }

                                            if (!descriptor.isBundledReady) {
                                                OutlinedButton(
                                                    onClick = { onDeleteModel(descriptor.id) },
                                                    shape = RoundedCornerShape(10.dp),
                                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                                    modifier = Modifier.testTag("delete_model_${descriptor.id}")
                                                ) {
                                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete model file", modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("حذف", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                        else -> {
                                            Button(
                                                onClick = { onStartDownloadModel(descriptor.id) },
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth().testTag("download_model_${descriptor.id}")
                                            ) {
                                                Icon(imageVector = Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("تحميل النموذج (${descriptor.formattedSize})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 3: AI Core - Knowledge Base + RAG System
            Text(
                text = "قاعدة المعرفة واسترجاع المعلومات (Knowledge Base + RAG)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Book,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "قاعدة المعرفة الداخلية (RAG Engine)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${uiState.knowledgeList.size} مراجع مفهرسة في Room",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Button(
                            onClick = onShowAddKnowledgeDialog,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("add_knowledge_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة مرجع")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (uiState.knowledgeList.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "لا توجد مراجع معرفية مضافة حالياً.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "أضف نصوصك وتوثيقاتك البرمجية أو مراجعك المعرفية ليعتمد عليها محرك RAG المحلي في إجابات دقيقة وموثقة.",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = uiState.knowledgeSearchQuery,
                                onValueChange = onKnowledgeSearchQueryChanged,
                                placeholder = { Text("بحث في قاعدة المعرفة (العنوان، المحتوى، الوسوم...)", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search Knowledge",
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                trailingIcon = {
                                    if (uiState.knowledgeSearchQuery.isNotEmpty()) {
                                        IconButton(onClick = { onKnowledgeSearchQueryChanged("") }) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Clear search",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("knowledge_search_field")
                            )

                            if (uiState.displayedKnowledge.isEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(
                                        modifier = Modifier.padding(14.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "لا توجد نتائج مطابقة لبحثك: \"${uiState.knowledgeSearchQuery}\"",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            } else {
                                uiState.displayedKnowledge.forEach { knowledge ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        tonalElevation = 1.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("knowledge_item_${knowledge.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.Top,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = when (knowledge.sourceType) {
                                                            KnowledgeSourceType.DOCUMENT_PDF -> Icons.Default.PictureAsPdf
                                                            KnowledgeSourceType.MANUAL_TEXT -> Icons.Default.Description
                                                            KnowledgeSourceType.ARTICLE -> Icons.Default.Book
                                                            KnowledgeSourceType.NOTE -> Icons.Default.Lightbulb
                                                        },
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = knowledge.title,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = MaterialTheme.colorScheme.secondaryContainer
                                                    ) {
                                                        Text(
                                                            text = knowledge.category.titleAr,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontSize = 10.sp,
                                                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = knowledge.content,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    maxLines = 3,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                if (knowledge.tags.isNotEmpty()) {
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = "الوسوم: ${knowledge.tags.joinToString(" • ")}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                                                    )
                                                }
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(
                                                    onClick = { onShowEditKnowledgeDialog(knowledge) },
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .testTag("edit_knowledge_${knowledge.id}")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Edit,
                                                        contentDescription = "Edit Knowledge",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }

                                                IconButton(
                                                    onClick = { onDeleteKnowledge(knowledge.id) },
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .testTag("delete_knowledge_${knowledge.id}")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Delete Knowledge",
                                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = onShowClearKnowledgeDialog,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("clear_all_knowledge_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteSweep,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("مسح كافة مراجع قاعدة المعرفة")
                            }
                        }
                    }
                }
            }

            // Section 4: AI Core - Smart Memory System
            Text(
                text = "نظام الذاكرة الذكية (Smart Memory System)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "الذاكرة طويلة المدى",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${uiState.memories.size} معلومات محفوظة في Room",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Button(
                            onClick = onShowAddMemoryDialog,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("add_memory_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (uiState.memories.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "لا توجد ذكريات محفوظة حالياً.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "أضف اسمك أو تفضيلاتك وسيتذكرها المحرك المحلي دائماً، أو قل له في المحادثة: \"احفظ أن...\"!",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = uiState.memorySearchQuery,
                                onValueChange = onMemorySearchQueryChanged,
                                placeholder = { Text("بحث في الذاكرة (الاسم، التفضيل، المعلومة...)", fontSize = 12.sp) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search",
                                        modifier = Modifier.size(18.dp)
                                    )
                                },
                                trailingIcon = {
                                    if (uiState.memorySearchQuery.isNotEmpty()) {
                                        IconButton(onClick = { onMemorySearchQueryChanged("") }) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Clear search",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("memory_search_field")
                            )

                            if (uiState.displayedMemories.isEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(
                                        modifier = Modifier.padding(14.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "لا توجد نتائج مطابقة لبحثك: \"${uiState.memorySearchQuery}\"",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            } else {
                                uiState.displayedMemories.forEach { memory ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surface,
                                        tonalElevation = 1.dp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("memory_item_${memory.id}")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        text = memory.key,
                                                        style = MaterialTheme.typography.bodyMedium,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = MaterialTheme.colorScheme.primaryContainer
                                                    ) {
                                                        Text(
                                                            text = memory.category.titleAr,
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontSize = 10.sp,
                                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = memory.content,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(
                                                    onClick = { onShowEditMemoryDialog(memory) },
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .testTag("edit_memory_${memory.id}")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Edit,
                                                        contentDescription = "Edit Memory",
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }

                                                IconButton(
                                                    onClick = { onDeleteMemory(memory.id) },
                                                    modifier = Modifier
                                                        .size(36.dp)
                                                        .testTag("delete_memory_${memory.id}")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Delete Memory",
                                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = onShowClearMemoriesDialog,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("clear_all_memories_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteSweep,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("مسح كل الذكريات المحفوظة")
                            }
                        }
                    }
                }
            }

            // Section 5: AI Core - Personality System
            Text(
                text = "نظام الشخصية وأسلوب الرد (Personality System)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اختر أسلوب المساعد في التفكير والردود:",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        PersonalityStyle.entries.forEach { style ->
                            val isSelected = style == uiState.personalityStyle
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                border = if (isSelected) {
                                    androidx.compose.foundation.BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                                } else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onSelectPersonalityStyle(style) }
                                    .testTag("style_item_${style.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${style.titleAr} (${style.titleEn})",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = style.descriptionAr,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 11.sp,
                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "Selected",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Section 6: AI Core - Rules System
            Text(
                text = "قوانين وتعليمات المساعد (Rules System)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Gavel,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "القواعد الثابتة التي تحكم سلوك المساعد:",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    uiState.rules.forEach { rule ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = rule.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = rule.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Switch(
                                checked = rule.isEnabled,
                                onCheckedChange = { isChecked -> onToggleRule(rule.id, isChecked) },
                                modifier = Modifier.testTag("rule_switch_${rule.id}")
                            )
                        }
                    }
                }
            }

            // Section 7: Voice Mode (Preparation)
            Text(
                text = "الوضع الصوتي (تجهيز V2)",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(id = R.string.voice_mode),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = stringResource(id = R.string.voice_mode_desc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }

                    Switch(
                        checked = uiState.isVoiceModeEnabled,
                        onCheckedChange = onToggleVoiceMode,
                        modifier = Modifier.testTag("voice_mode_switch")
                    )
                }
            }

            // Section 8: Data & Storage (Room DB)
            Text(
                text = "إدارة المحادثات والتخزين",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "قاعدة بيانات محلية (Room Database)",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "يتم حفظ جميع الرسائل والمحادثات والذكريات وقاعدة المعرفة بأمان محلياً على جهازك.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onShowClearDialog,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("settings_clear_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "مسح جميع الرسائل والمحادثات")
                    }
                }
            }

            // Section 9: Future Architecture Roadmap
            Text(
                text = "معمارية التطبيق والتجهيز المستقبلي",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    RoadmapItem(
                        icon = Icons.Default.Speed,
                        title = "Local AI Model Engine & GGUF",
                        status = "تم بناؤه وتكامله بنجاح في AI Core (On-Device Inference)!"
                    )
                    RoadmapItem(
                        icon = Icons.Default.Book,
                        title = "Knowledge Base & RAG Engine",
                        status = "تم بناؤه وتكامله بنجاح في AI Core + Room!"
                    )
                    RoadmapItem(
                        icon = Icons.Default.Memory,
                        title = "Smart Memory Engine",
                        status = "تم تأسيسه بنجاح وربطه بـ Room و AI Core!"
                    )
                    RoadmapItem(
                        icon = Icons.Default.Mic,
                        title = "Voice Input (Speech-To-Text)",
                        status = "واجهة مجهزة (Ready to plug SpeechRecognizer)"
                    )
                    RoadmapItem(
                        icon = Icons.Default.RecordVoiceOver,
                        title = "Text To Speech (TTS)",
                        status = "واجهة مجهزة (Ready to plug TextToSpeech)"
                    )
                    RoadmapItem(
                        icon = Icons.Default.Build,
                        title = "Tools System (Function Calling)",
                        status = "مُجهز لتنفيذ أدوات خارجية وأتمتة المهام"
                    )
                }
            }

            // Section 10: About Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(id = R.string.about_title),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(id = R.string.about_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // ==========================================
    // Knowledge Base Dialogs (Add / Edit / Clear)
    // ==========================================

    if (uiState.isAddKnowledgeDialogOpen) {
        AlertDialog(
            onDismissRequest = onDismissAddKnowledgeDialog,
            title = {
                Text(
                    text = "إضافة مرجع لقاعدة المعرفة (RAG)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = uiState.newKnowledgeTitle,
                        onValueChange = onNewKnowledgeTitleChanged,
                        label = { Text("عنوان المرجع المعرفي") },
                        placeholder = { Text("مثال: توثيق API الدفع، ملخص كتاب...") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_knowledge_title_field")
                    )

                    OutlinedTextField(
                        value = uiState.newKnowledgeContent,
                        onValueChange = onNewKnowledgeContentChanged,
                        label = { Text("نص المحتوى المعرفي") },
                        placeholder = { Text("أدخل النص أو التوثيق الذي سيعتمد عليه RAG...") },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_knowledge_content_field")
                    )

                    OutlinedTextField(
                        value = uiState.newKnowledgeTags,
                        onValueChange = onNewKnowledgeTagsChanged,
                        label = { Text("الوسوم (مفصولة بفواصل)") },
                        placeholder = { Text("مثال: kotlin, android, auth") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "نوع المصدر:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        KnowledgeSourceType.entries.forEach { type ->
                            FilterChip(
                                selected = type == uiState.newKnowledgeSourceType,
                                onClick = { onNewKnowledgeSourceTypeChanged(type) },
                                label = { Text(type.badge, fontSize = 10.sp) }
                            )
                        }
                    }

                    if (uiState.newKnowledgeSourceType == KnowledgeSourceType.DOCUMENT_PDF) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "📄 تم تفعيل وضع تجهيز PDF: سيتم وسم المرجع كملف مستند مفهرس مع دعم استخراج الفقرات تلقائياً.",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    Text(
                        text = "التصنيف:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        KnowledgeCategory.entries.take(3).forEach { cat ->
                            FilterChip(
                                selected = cat == uiState.newKnowledgeCategory,
                                onClick = { onNewKnowledgeCategoryChanged(cat) },
                                label = { Text(cat.titleAr, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onSaveNewKnowledge,
                    enabled = uiState.newKnowledgeTitle.isNotBlank() && uiState.newKnowledgeContent.isNotBlank(),
                    modifier = Modifier.testTag("confirm_add_knowledge_button")
                ) {
                    Text("حفظ في RAG")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissAddKnowledgeDialog) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (uiState.isEditKnowledgeDialogOpen) {
        AlertDialog(
            onDismissRequest = onDismissEditKnowledgeDialog,
            title = {
                Text(
                    text = "تعديل المرجع المعرفي",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = uiState.editKnowledgeTitle,
                        onValueChange = onEditKnowledgeTitleChanged,
                        label = { Text("عنوان المرجع") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_knowledge_title_field")
                    )

                    OutlinedTextField(
                        value = uiState.editKnowledgeContent,
                        onValueChange = onEditKnowledgeContentChanged,
                        label = { Text("المحتوى المعرفي") },
                        minLines = 3,
                        maxLines = 6,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_knowledge_content_field")
                    )

                    OutlinedTextField(
                        value = uiState.editKnowledgeTags,
                        onValueChange = onEditKnowledgeTagsChanged,
                        label = { Text("الوسوم (مفصولة بفواصل)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "التصنيف:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        KnowledgeCategory.entries.take(3).forEach { cat ->
                            FilterChip(
                                selected = cat == uiState.editKnowledgeCategory,
                                onClick = { onEditKnowledgeCategoryChanged(cat) },
                                label = { Text(cat.titleAr, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onSaveEditedKnowledge,
                    enabled = uiState.editKnowledgeTitle.isNotBlank() && uiState.editKnowledgeContent.isNotBlank(),
                    modifier = Modifier.testTag("confirm_edit_knowledge_button")
                ) {
                    Text("حفظ التعديل")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissEditKnowledgeDialog) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (uiState.isClearKnowledgeDialogOpen) {
        AlertDialog(
            onDismissRequest = onDismissClearKnowledgeDialog,
            title = {
                Text(
                    text = "مسح قاعدة المعرفة RAG",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف جميع المراجع والبيانات المفهرسة في قاعدة المعرفة؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onConfirmClearAllKnowledge,
                    modifier = Modifier.testTag("confirm_clear_knowledge_button")
                ) {
                    Text(
                        text = "مسح نهائي لقاعدة المعرفة",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismissClearKnowledgeDialog,
                    modifier = Modifier.testTag("cancel_clear_knowledge_button")
                ) {
                    Text(text = "إلغاء")
                }
            }
        )
    }

    // ==========================================
    // Memory Dialogs (Add / Edit / Clear)
    // ==========================================

    if (uiState.isAddMemoryDialogOpen) {
        AlertDialog(
            onDismissRequest = onDismissAddMemoryDialog,
            title = {
                Text(
                    text = "إضافة معلومة للذاكرة طويلة المدى",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = uiState.newMemoryKey,
                        onValueChange = onNewMemoryKeyChanged,
                        label = { Text("عنوان / مفتاح الذاكرة") },
                        placeholder = { Text("مثال: اسم المستخدم، التخصص، لغة البرمجة...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = uiState.newMemoryContent,
                        onValueChange = onNewMemoryContentChanged,
                        label = { Text("المعلومة أو التفضيل") },
                        placeholder = { Text("مثال: أعمل كمهندس برمجيات وأفضل لغة Kotlin...") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "التصنيف:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MemoryCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = cat == uiState.newMemoryCategory,
                                onClick = { onNewMemoryCategoryChanged(cat) },
                                label = { Text(cat.titleAr, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onSaveNewMemory,
                    enabled = uiState.newMemoryKey.isNotBlank() && uiState.newMemoryContent.isNotBlank()
                ) {
                    Text("حفظ في الذاكرة")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissAddMemoryDialog) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (uiState.isEditMemoryDialogOpen) {
        AlertDialog(
            onDismissRequest = onDismissEditMemoryDialog,
            title = {
                Text(
                    text = "تعديل الذاكرة المحفوظة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = uiState.editMemoryKey,
                        onValueChange = onEditMemoryKeyChanged,
                        label = { Text("عنوان / مفتاح الذاكرة") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_memory_key_field")
                    )

                    OutlinedTextField(
                        value = uiState.editMemoryContent,
                        onValueChange = onEditMemoryContentChanged,
                        label = { Text("المعلومة أو التفضيل") },
                        maxLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("edit_memory_content_field")
                    )

                    Text(
                        text = "التصنيف:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        MemoryCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = cat == uiState.editMemoryCategory,
                                onClick = { onEditMemoryCategoryChanged(cat) },
                                label = { Text(cat.titleAr, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onSaveEditedMemory,
                    enabled = uiState.editMemoryKey.isNotBlank() && uiState.editMemoryContent.isNotBlank(),
                    modifier = Modifier.testTag("confirm_edit_memory_button")
                ) {
                    Text("حفظ التعديل")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismissEditMemoryDialog,
                    modifier = Modifier.testTag("cancel_edit_memory_button")
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (uiState.isClearMemoriesDialogOpen) {
        AlertDialog(
            onDismissRequest = onDismissClearMemoriesDialog,
            title = {
                Text(
                    text = "مسح كل الذكريات",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف جميع المعلومات المحفوظة في الذاكرة طويلة المدى؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onConfirmClearAllMemories,
                    modifier = Modifier.testTag("confirm_clear_memories_button")
                ) {
                    Text(
                        text = "مسح نهائي للذاكرة",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismissClearMemoriesDialog,
                    modifier = Modifier.testTag("cancel_clear_memories_button")
                ) {
                    Text(text = "إلغاء")
                }
            }
        )
    }

    if (uiState.isClearDialogOpen) {
        AlertDialog(
            onDismissRequest = onDismissClearDialog,
            title = {
                Text(
                    text = "مسح المحادثات",
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف جميع المحادثات والرسائل المحفوظة في قاعدة بيانات Room؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onConfirmClear,
                    modifier = Modifier.testTag("settings_confirm_delete_button")
                ) {
                    Text(
                        text = "مسح نهائي",
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismissClearDialog,
                    modifier = Modifier.testTag("settings_cancel_delete_button")
                ) {
                    Text(text = "إلغاء")
                }
            }
        )
    }
}

@Composable
private fun RoadmapItem(
    icon: ImageVector,
    title: String,
    status: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = status,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }
    }
}
