package com.example.presentation.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.usecase.ClearChatUseCase
import com.example.domain.usecase.CreateConversationUseCase
import com.example.domain.usecase.GetAssistantSettingsUseCase
import com.example.domain.usecase.GetMessagesUseCase
import com.example.domain.usecase.SelectConversationUseCase
import com.example.domain.usecase.SendMessageUseCase
import com.example.utils.Constants
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChatViewModel(
    private val sendMessageUseCase: SendMessageUseCase,
    private val getMessagesUseCase: GetMessagesUseCase,
    private val clearChatUseCase: ClearChatUseCase,
    private val getAssistantSettingsUseCase: GetAssistantSettingsUseCase,
    private val createConversationUseCase: CreateConversationUseCase,
    private val selectConversationUseCase: SelectConversationUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private var messagesJob: Job? = null

    init {
        observeSettings()
        switchConversation(Constants.DEFAULT_CONVERSATION_ID)
    }

    private fun observeSettings() {
        viewModelScope.launch {
            getAssistantSettingsUseCase()
                .catch { /* Fallback to default */ }
                .collect { settings ->
                    _uiState.update { it.copy(assistantName = settings.assistantName) }
                }
        }
    }

    fun switchConversation(conversationId: Long) {
        messagesJob?.cancel()
        _uiState.update {
            it.copy(
                currentConversationId = conversationId,
                inputText = "",
                isGenerating = false,
                errorMessage = null
            )
        }

        // Fetch conversation details to update title
        viewModelScope.launch {
            val conversation = selectConversationUseCase(conversationId)
            if (conversation != null) {
                _uiState.update { it.copy(currentConversationTitle = conversation.title) }
            }
        }

        // Observe messages for this specific conversation
        messagesJob = viewModelScope.launch {
            getMessagesUseCase(conversationId)
                .catch { error ->
                    _uiState.update { it.copy(errorMessage = error.message) }
                }
                .collect { messageList ->
                    _uiState.update { it.copy(messages = messageList) }
                }
        }
    }

    fun startNewConversation(onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val newConversation = createConversationUseCase("محادثة جديدة")
            switchConversation(newConversation.id)
            onCreated(newConversation.id)
        }
    }

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage(customPrompt: String? = null) {
        val prompt = (customPrompt ?: _uiState.value.inputText).trim()
        if (prompt.isEmpty() || _uiState.value.isGenerating) return

        val conversationId = _uiState.value.currentConversationId

        // Clear input text immediately
        _uiState.update { it.copy(inputText = "", isGenerating = true, errorMessage = null) }

        viewModelScope.launch {
            val result = sendMessageUseCase(
                content = prompt,
                conversationId = conversationId,
                currentHistory = _uiState.value.messages,
                assistantName = _uiState.value.assistantName
            )

            // Refresh conversation title in UI
            val conversation = selectConversationUseCase(conversationId)
            val updatedTitle = conversation?.title ?: _uiState.value.currentConversationTitle

            _uiState.update { state ->
                state.copy(
                    isGenerating = false,
                    currentConversationTitle = updatedTitle,
                    errorMessage = result.exceptionOrNull()?.message
                )
            }
        }
    }

    fun showClearDialog() {
        _uiState.update { it.copy(isClearDialogOpen = true) }
    }

    fun dismissClearDialog() {
        _uiState.update { it.copy(isClearDialogOpen = false) }
    }

    fun confirmClearChat() {
        viewModelScope.launch {
            clearChatUseCase(_uiState.value.currentConversationId)
            _uiState.update { it.copy(isClearDialogOpen = false) }
        }
    }

    class Factory(
        private val sendMessageUseCase: SendMessageUseCase,
        private val getMessagesUseCase: GetMessagesUseCase,
        private val clearChatUseCase: ClearChatUseCase,
        private val getAssistantSettingsUseCase: GetAssistantSettingsUseCase,
        private val createConversationUseCase: CreateConversationUseCase,
        private val selectConversationUseCase: SelectConversationUseCase
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ChatViewModel(
                sendMessageUseCase = sendMessageUseCase,
                getMessagesUseCase = getMessagesUseCase,
                clearChatUseCase = clearChatUseCase,
                getAssistantSettingsUseCase = getAssistantSettingsUseCase,
                createConversationUseCase = createConversationUseCase,
                selectConversationUseCase = selectConversationUseCase
            ) as T
        }
    }
}
