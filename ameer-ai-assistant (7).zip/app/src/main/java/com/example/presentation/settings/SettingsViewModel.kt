package com.example.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.aicore.localmodel.DownloadState
import com.example.aicore.localmodel.LocalModelDescriptor
import com.example.aicore.localmodel.LocalModelMode
import com.example.aicore.localmodel.ModelDownloader
import com.example.aicore.localmodel.ModelLoader
import com.example.aicore.localmodel.ModelSelector
import com.example.aicore.memory.MemoryManager
import com.example.aicore.model.ModelManager
import com.example.aicore.personality.PersonalityManager
import com.example.aicore.personality.PersonalityStyle
import com.example.domain.model.MemoryCategory
import com.example.domain.model.MemoryItem
import com.example.domain.model.knowledge.KnowledgeCategory
import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.model.knowledge.KnowledgeSourceType
import com.example.domain.usecase.ClearChatUseCase
import com.example.domain.usecase.GetAssistantSettingsUseCase
import com.example.domain.usecase.UpdateAssistantSettingsUseCase
import com.example.domain.usecase.knowledge.ClearAllKnowledgeUseCase
import com.example.domain.usecase.knowledge.DeleteKnowledgeUseCase
import com.example.domain.usecase.knowledge.GetKnowledgeBaseUseCase
import com.example.domain.usecase.knowledge.SaveKnowledgeUseCase
import com.example.domain.usecase.knowledge.SearchKnowledgeUseCase
import com.example.domain.usecase.knowledge.UpdateKnowledgeUseCase
import com.example.domain.usecase.memory.ClearAllMemoriesUseCase
import com.example.domain.usecase.memory.DeleteMemoryUseCase
import com.example.domain.usecase.memory.GetMemoriesUseCase
import com.example.domain.usecase.memory.SaveMemoryUseCase
import com.example.domain.usecase.memory.SearchMemoriesUseCase
import com.example.domain.usecase.memory.UpdateMemoryUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val personalityManager: PersonalityManager,
    private val modelManager: ModelManager,
    private val modelLoader: ModelLoader,
    private val modelDownloader: ModelDownloader,
    private val modelSelector: ModelSelector,
    private val memoryManager: MemoryManager,
    private val getMemoriesUseCase: GetMemoriesUseCase,
    private val saveMemoryUseCase: SaveMemoryUseCase,
    private val updateMemoryUseCase: UpdateMemoryUseCase,
    private val deleteMemoryUseCase: DeleteMemoryUseCase,
    private val clearAllMemoriesUseCase: ClearAllMemoriesUseCase,
    private val searchMemoriesUseCase: SearchMemoriesUseCase,
    private val getKnowledgeBaseUseCase: GetKnowledgeBaseUseCase,
    private val saveKnowledgeUseCase: SaveKnowledgeUseCase,
    private val updateKnowledgeUseCase: UpdateKnowledgeUseCase,
    private val deleteKnowledgeUseCase: DeleteKnowledgeUseCase,
    private val clearAllKnowledgeUseCase: ClearAllKnowledgeUseCase,
    private val searchKnowledgeUseCase: SearchKnowledgeUseCase,
    private val getSettingsUseCase: GetAssistantSettingsUseCase,
    private val updateSettingsUseCase: UpdateAssistantSettingsUseCase,
    private val clearChatUseCase: ClearChatUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        SettingsUiState(
            availableModels = modelManager.getAvailableModels(),
            activeModel = modelManager.activeModel.value,
            activeMode = modelSelector.activeMode.value,
            localDescriptors = modelLoader.availableDescriptors,
            fastModeDescriptors = LocalModelDescriptor.getFastModeDescriptors(),
            proModeDescriptors = LocalModelDescriptor.getProModeDescriptors(),
            activeLocalDescriptor = modelLoader.activeDescriptor.value,
            hardwareInfo = modelLoader.getHardwareInfo(),
            deviceReport = modelSelector.deviceCapabilityReport,
            localModelsInfo = modelManager.localModelsInfo.value,
            downloadStates = modelDownloader.modelDownloadStates.value,
            totalStorageUsage = modelDownloader.getTotalModelsStorageUsageFormatted()
        )
    )
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        observeSettings()
        observePersonality()
        observeModel()
        observeModelLoader()
        observeModelDownloader()
        observeModelSelector()
        observeMemories()
        observeKnowledge()
    }

    private fun observeSettings() {
        viewModelScope.launch {
            getSettingsUseCase().collect { settings ->
                _uiState.update {
                    it.copy(
                        assistantName = settings.assistantName,
                        nameInputText = settings.assistantName,
                        isVoiceModeEnabled = settings.isVoiceModeEnabled
                    )
                }
            }
        }
    }

    private fun observePersonality() {
        viewModelScope.launch {
            personalityManager.personality.collect { p ->
                _uiState.update {
                    it.copy(
                        assistantName = p.assistantName,
                        personalityStyle = p.style,
                        rules = p.rules
                    )
                }
            }
        }
    }

    private fun observeModel() {
        viewModelScope.launch {
            modelManager.activeModel.collect { model ->
                _uiState.update { it.copy(activeModel = model) }
            }
        }
        viewModelScope.launch {
            modelManager.localModelsInfo.collect { list ->
                _uiState.update {
                    it.copy(
                        localModelsInfo = list,
                        totalStorageUsage = modelDownloader.getTotalModelsStorageUsageFormatted()
                    )
                }
            }
        }
    }

    private fun observeModelLoader() {
        viewModelScope.launch {
            modelLoader.loadingState.collect { state ->
                _uiState.update { it.copy(modelLoadingState = state) }
            }
        }
        viewModelScope.launch {
            modelLoader.activeDescriptor.collect { descriptor ->
                _uiState.update { it.copy(activeLocalDescriptor = descriptor) }
            }
        }
    }

    private fun observeModelDownloader() {
        viewModelScope.launch {
            modelDownloader.modelDownloadStates.collect { states ->
                _uiState.update {
                    it.copy(
                        downloadStates = states,
                        totalStorageUsage = modelDownloader.getTotalModelsStorageUsageFormatted()
                    )
                }
            }
        }
    }

    private fun observeModelSelector() {
        viewModelScope.launch {
            modelSelector.activeMode.collect { mode ->
                _uiState.update { it.copy(activeMode = mode) }
            }
        }
    }

    private fun observeMemories() {
        viewModelScope.launch {
            getMemoriesUseCase().collect { memoryList ->
                _uiState.update { it.copy(memories = memoryList) }
            }
        }
    }

    private fun observeKnowledge() {
        viewModelScope.launch {
            getKnowledgeBaseUseCase().collect { knowledgeList ->
                _uiState.update { it.copy(knowledgeList = knowledgeList) }
            }
        }
    }

    fun setEditingName(isEditing: Boolean) {
        _uiState.update { it.copy(isEditingName = isEditing) }
    }

    fun onNameInputChanged(newName: String) {
        _uiState.update { it.copy(nameInputText = newName) }
    }

    fun saveAssistantName() {
        val newName = _uiState.value.nameInputText.trim()
        if (newName.isNotEmpty()) {
            viewModelScope.launch {
                updateSettingsUseCase.updateName(newName)
                personalityManager.setAssistantName(newName)
                _uiState.update {
                    it.copy(
                        isEditingName = false,
                        messageSnackbar = "تم تحديث اسم المساعد بنجاح"
                    )
                }
            }
        }
    }

    fun setPersonalityStyle(style: PersonalityStyle) {
        personalityManager.setStyle(style)
        _uiState.update {
            it.copy(
                messageSnackbar = "تم اعتماد أسلوب: ${style.titleAr}"
            )
        }
    }

    fun toggleRule(ruleId: String, isEnabled: Boolean) {
        personalityManager.toggleRule(ruleId, isEnabled)
    }

    fun selectModel(modelId: String) {
        val success = modelManager.selectModel(modelId)
        if (success) {
            val selected = modelManager.activeModel.value
            _uiState.update {
                it.copy(
                    messageSnackbar = "تم اختيار نموذج: ${selected.displayName}"
                )
            }
        }
    }

    fun setOperatingMode(mode: LocalModelMode) {
        viewModelScope.launch {
            modelSelector.setMode(mode)
            _uiState.update {
                it.copy(
                    activeMode = mode,
                    messageSnackbar = "تم تفعيل: ${mode.titleAr}"
                )
            }
        }
    }

    fun selectLocalDescriptor(descriptorId: String) {
        viewModelScope.launch {
            val success = modelSelector.selectExplicitModel(descriptorId)
            if (success) {
                val descriptor = modelLoader.activeDescriptor.value
                modelManager.selectModel(descriptor.id)
                _uiState.update {
                    it.copy(
                        messageSnackbar = "تم تفعيل النموذج المحلي: ${descriptor.name}"
                    )
                }
            }
        }
    }

    // =========================================================================
    // Local Brain / Model Downloader Management ("إدارة العقل المحلي")
    // =========================================================================

    fun startDownloadModel(modelId: String) {
        val descriptor = modelLoader.availableDescriptors.find { it.id == modelId } ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(messageSnackbar = "بدء تحميل ${descriptor.name} (${descriptor.formattedSize})...") }
            modelDownloader.startDownload(descriptor)
        }
    }

    fun pauseDownloadModel(modelId: String) {
        viewModelScope.launch {
            modelDownloader.pauseDownload(modelId)
            _uiState.update { it.copy(messageSnackbar = "تم إيقاف التحميل مؤقتاً") }
        }
    }

    fun resumeDownloadModel(modelId: String) {
        val descriptor = modelLoader.availableDescriptors.find { it.id == modelId } ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(messageSnackbar = "استئناف تحميل ${descriptor.name}...") }
            modelDownloader.resumeDownload(descriptor)
        }
    }

    fun activateModel(modelId: String) {
        val descriptor = modelLoader.availableDescriptors.find { it.id == modelId } ?: return
        viewModelScope.launch {
            val success = modelManager.activateLocalModel(modelId)
            if (success) {
                modelLoader.loadModel(descriptor)
                _uiState.update {
                    it.copy(
                        messageSnackbar = "🚀 تم تشغيل وتفعيل العقل المحلي: ${descriptor.name}"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        messageSnackbar = "⚠️ يجب تحميل النموذج أولاً قبل تشغيله!"
                    )
                }
            }
        }
    }

    fun deleteModel(modelId: String) {
        val descriptor = modelLoader.availableDescriptors.find { it.id == modelId } ?: return
        viewModelScope.launch {
            val deleted = modelDownloader.deleteDownloadedModel(descriptor)
            if (deleted) {
                // If the deleted model was active, switch to bundled fast core
                if (modelLoader.activeDescriptor.value.id == modelId) {
                    modelManager.activateLocalModel(LocalModelDescriptor.AMEER_FAST_CORE.id)
                }
                _uiState.update {
                    it.copy(
                        totalStorageUsage = modelDownloader.getTotalModelsStorageUsageFormatted(),
                        messageSnackbar = "تم حذف ملف النموذج وتحرير المساحة بنجاح"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        messageSnackbar = "لا يمكن حذف نموذج النظام المدمج"
                    )
                }
            }
        }
    }

    // Memory Search
    fun onMemorySearchQueryChanged(query: String) {
        _uiState.update { it.copy(memorySearchQuery = query) }
    }

    // Add Memory Dialog Actions
    fun showAddMemoryDialog() {
        _uiState.update {
            it.copy(
                isAddMemoryDialogOpen = true,
                newMemoryKey = "",
                newMemoryContent = "",
                newMemoryCategory = MemoryCategory.FACT
            )
        }
    }

    fun dismissAddMemoryDialog() {
        _uiState.update { it.copy(isAddMemoryDialogOpen = false) }
    }

    fun onNewMemoryKeyChanged(key: String) {
        _uiState.update { it.copy(newMemoryKey = key) }
    }

    fun onNewMemoryContentChanged(content: String) {
        _uiState.update { it.copy(newMemoryContent = content) }
    }

    fun onNewMemoryCategoryChanged(category: MemoryCategory) {
        _uiState.update { it.copy(newMemoryCategory = category) }
    }

    fun saveNewMemory() {
        val key = _uiState.value.newMemoryKey.trim()
        val content = _uiState.value.newMemoryContent.trim()
        val category = _uiState.value.newMemoryCategory

        if (key.isNotEmpty() && content.isNotEmpty()) {
            viewModelScope.launch {
                saveMemoryUseCase(
                    MemoryItem(
                        key = key,
                        content = content,
                        category = category
                    )
                )
                _uiState.update {
                    it.copy(
                        isAddMemoryDialogOpen = false,
                        newMemoryKey = "",
                        newMemoryContent = "",
                        messageSnackbar = "تم حفظ المعلومة في الذاكرة بنجاح"
                    )
                }
            }
        }
    }

    // Edit Memory Dialog Actions
    fun showEditMemoryDialog(memory: MemoryItem) {
        _uiState.update {
            it.copy(
                isEditMemoryDialogOpen = true,
                editingMemoryId = memory.id,
                editMemoryKey = memory.key,
                editMemoryContent = memory.content,
                editMemoryCategory = memory.category
            )
        }
    }

    fun dismissEditMemoryDialog() {
        _uiState.update {
            it.copy(
                isEditMemoryDialogOpen = false,
                editingMemoryId = null
            )
        }
    }

    fun onEditMemoryKeyChanged(key: String) {
        _uiState.update { it.copy(editMemoryKey = key) }
    }

    fun onEditMemoryContentChanged(content: String) {
        _uiState.update { it.copy(editMemoryContent = content) }
    }

    fun onEditMemoryCategoryChanged(category: MemoryCategory) {
        _uiState.update { it.copy(editMemoryCategory = category) }
    }

    fun saveEditedMemory() {
        val id = _uiState.value.editingMemoryId ?: return
        val key = _uiState.value.editMemoryKey.trim()
        val content = _uiState.value.editMemoryContent.trim()
        val category = _uiState.value.editMemoryCategory

        if (key.isNotEmpty() && content.isNotEmpty()) {
            viewModelScope.launch {
                val existing = _uiState.value.memories.find { it.id == id }
                if (existing != null) {
                    updateMemoryUseCase(
                        existing.copy(
                            key = key,
                            content = content,
                            category = category,
                            lastAccessed = System.currentTimeMillis()
                        )
                    )
                }
                _uiState.update {
                    it.copy(
                        isEditMemoryDialogOpen = false,
                        editingMemoryId = null,
                        messageSnackbar = "تم تحديث الذاكرة بنجاح"
                    )
                }
            }
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            deleteMemoryUseCase(id)
            _uiState.update {
                it.copy(messageSnackbar = "تم حذف المعلومة من الذاكرة")
            }
        }
    }

    fun showClearMemoriesDialog() {
        _uiState.update { it.copy(isClearMemoriesDialogOpen = true) }
    }

    fun dismissClearMemoriesDialog() {
        _uiState.update { it.copy(isClearMemoriesDialogOpen = false) }
    }

    fun confirmClearAllMemories() {
        viewModelScope.launch {
            clearAllMemoriesUseCase()
            _uiState.update {
                it.copy(
                    isClearMemoriesDialogOpen = false,
                    messageSnackbar = "تم مسح جميع الذكريات طويلة المدى"
                )
            }
        }
    }

    // =========================================================================
    // Knowledge Base System Actions (RAG)
    // =========================================================================

    fun onKnowledgeSearchQueryChanged(query: String) {
        _uiState.update { it.copy(knowledgeSearchQuery = query) }
    }

    fun showAddKnowledgeDialog() {
        _uiState.update {
            it.copy(
                isAddKnowledgeDialogOpen = true,
                newKnowledgeTitle = "",
                newKnowledgeContent = "",
                newKnowledgeCategory = KnowledgeCategory.GENERAL,
                newKnowledgeSourceType = KnowledgeSourceType.MANUAL_TEXT,
                newKnowledgeTags = ""
            )
        }
    }

    fun dismissAddKnowledgeDialog() {
        _uiState.update { it.copy(isAddKnowledgeDialogOpen = false) }
    }

    fun onNewKnowledgeTitleChanged(title: String) {
        _uiState.update { it.copy(newKnowledgeTitle = title) }
    }

    fun onNewKnowledgeContentChanged(content: String) {
        _uiState.update { it.copy(newKnowledgeContent = content) }
    }

    fun onNewKnowledgeCategoryChanged(category: KnowledgeCategory) {
        _uiState.update { it.copy(newKnowledgeCategory = category) }
    }

    fun onNewKnowledgeSourceTypeChanged(sourceType: KnowledgeSourceType) {
        _uiState.update { it.copy(newKnowledgeSourceType = sourceType) }
    }

    fun onNewKnowledgeTagsChanged(tags: String) {
        _uiState.update { it.copy(newKnowledgeTags = tags) }
    }

    fun saveNewKnowledge() {
        val title = _uiState.value.newKnowledgeTitle.trim()
        val content = _uiState.value.newKnowledgeContent.trim()
        val category = _uiState.value.newKnowledgeCategory
        val sourceType = _uiState.value.newKnowledgeSourceType
        val tags = _uiState.value.newKnowledgeTags
            .split(",", "،")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        if (title.isNotEmpty() && content.isNotEmpty()) {
            viewModelScope.launch {
                saveKnowledgeUseCase(
                    KnowledgeItem(
                        title = title,
                        content = content,
                        category = category,
                        sourceType = sourceType,
                        tags = tags
                    )
                )
                _uiState.update {
                    it.copy(
                        isAddKnowledgeDialogOpen = false,
                        newKnowledgeTitle = "",
                        newKnowledgeContent = "",
                        newKnowledgeTags = "",
                        messageSnackbar = "تمت إضافة المرجع إلى قاعدة المعرفة بنجاح"
                    )
                }
            }
        }
    }

    fun showEditKnowledgeDialog(item: KnowledgeItem) {
        _uiState.update {
            it.copy(
                isEditKnowledgeDialogOpen = true,
                editingKnowledgeId = item.id,
                editKnowledgeTitle = item.title,
                editKnowledgeContent = item.content,
                editKnowledgeCategory = item.category,
                editKnowledgeSourceType = item.sourceType,
                editKnowledgeTags = item.tags.joinToString(", ")
            )
        }
    }

    fun dismissEditKnowledgeDialog() {
        _uiState.update {
            it.copy(
                isEditKnowledgeDialogOpen = false,
                editingKnowledgeId = null
            )
        }
    }

    fun onEditKnowledgeTitleChanged(title: String) {
        _uiState.update { it.copy(editKnowledgeTitle = title) }
    }

    fun onEditKnowledgeContentChanged(content: String) {
        _uiState.update { it.copy(editKnowledgeContent = content) }
    }

    fun onEditKnowledgeCategoryChanged(category: KnowledgeCategory) {
        _uiState.update { it.copy(editKnowledgeCategory = category) }
    }

    fun onEditKnowledgeSourceTypeChanged(sourceType: KnowledgeSourceType) {
        _uiState.update { it.copy(editKnowledgeSourceType = sourceType) }
    }

    fun onEditKnowledgeTagsChanged(tags: String) {
        _uiState.update { it.copy(editKnowledgeTags = tags) }
    }

    fun saveEditedKnowledge() {
        val id = _uiState.value.editingKnowledgeId ?: return
        val title = _uiState.value.editKnowledgeTitle.trim()
        val content = _uiState.value.editKnowledgeContent.trim()
        val category = _uiState.value.editKnowledgeCategory
        val sourceType = _uiState.value.editKnowledgeSourceType
        val tags = _uiState.value.editKnowledgeTags
            .split(",", "،")
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        if (title.isNotEmpty() && content.isNotEmpty()) {
            viewModelScope.launch {
                val existing = _uiState.value.knowledgeList.find { it.id == id }
                if (existing != null) {
                    updateKnowledgeUseCase(
                        existing.copy(
                            title = title,
                            content = content,
                            category = category,
                            sourceType = sourceType,
                            tags = tags,
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                }
                _uiState.update {
                    it.copy(
                        isEditKnowledgeDialogOpen = false,
                        editingKnowledgeId = null,
                        messageSnackbar = "تم تحديث المرجع المعرفي بنجاح"
                    )
                }
            }
        }
    }

    fun deleteKnowledge(id: Long) {
        viewModelScope.launch {
            deleteKnowledgeUseCase(id)
            _uiState.update {
                it.copy(messageSnackbar = "تم حذف المرجع من قاعدة المعرفة")
            }
        }
    }

    fun showClearKnowledgeDialog() {
        _uiState.update { it.copy(isClearKnowledgeDialogOpen = true) }
    }

    fun dismissClearKnowledgeDialog() {
        _uiState.update { it.copy(isClearKnowledgeDialogOpen = false) }
    }

    fun confirmClearAllKnowledge() {
        viewModelScope.launch {
            clearAllKnowledgeUseCase()
            _uiState.update {
                it.copy(
                    isClearKnowledgeDialogOpen = false,
                    messageSnackbar = "تم مسح جميع مراجع قاعدة المعرفة"
                )
            }
        }
    }

    // =========================================================================
    // General Settings Actions
    // =========================================================================

    fun toggleVoiceMode(isEnabled: Boolean) {
        viewModelScope.launch {
            updateSettingsUseCase.toggleVoice(isEnabled)
            _uiState.update {
                it.copy(
                    isVoiceModeEnabled = isEnabled,
                    messageSnackbar = if (isEnabled) "تم تفعيل الوضع الصوتي" else "تم تعطيل الوضع الصوتي"
                )
            }
        }
    }

    fun showClearDialog() {
        _uiState.update { it.copy(isClearDialogOpen = true) }
    }

    fun dismissClearDialog() {
        _uiState.update { it.copy(isClearDialogOpen = false) }
    }

    fun confirmClearAllConversations() {
        viewModelScope.launch {
            clearChatUseCase()
            _uiState.update {
                it.copy(
                    isClearDialogOpen = false,
                    messageSnackbar = "تم مسح المحادثات والرسائل بنجاح"
                )
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(messageSnackbar = null) }
    }

    class Factory(
        private val personalityManager: PersonalityManager,
        private val modelManager: ModelManager,
        private val modelLoader: ModelLoader,
        private val modelDownloader: ModelDownloader,
        private val modelSelector: ModelSelector,
        private val memoryManager: MemoryManager,
        private val getMemoriesUseCase: GetMemoriesUseCase,
        private val saveMemoryUseCase: SaveMemoryUseCase,
        private val updateMemoryUseCase: UpdateMemoryUseCase,
        private val deleteMemoryUseCase: DeleteMemoryUseCase,
        private val clearAllMemoriesUseCase: ClearAllMemoriesUseCase,
        private val searchMemoriesUseCase: SearchMemoriesUseCase,
        private val getKnowledgeBaseUseCase: GetKnowledgeBaseUseCase,
        private val saveKnowledgeUseCase: SaveKnowledgeUseCase,
        private val updateKnowledgeUseCase: UpdateKnowledgeUseCase,
        private val deleteKnowledgeUseCase: DeleteKnowledgeUseCase,
        private val clearAllKnowledgeUseCase: ClearAllKnowledgeUseCase,
        private val searchKnowledgeUseCase: SearchKnowledgeUseCase,
        private val getSettingsUseCase: GetAssistantSettingsUseCase,
        private val updateSettingsUseCase: UpdateAssistantSettingsUseCase,
        private val clearChatUseCase: ClearChatUseCase
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(
                personalityManager = personalityManager,
                modelManager = modelManager,
                modelLoader = modelLoader,
                modelDownloader = modelDownloader,
                modelSelector = modelSelector,
                memoryManager = memoryManager,
                getMemoriesUseCase = getMemoriesUseCase,
                saveMemoryUseCase = saveMemoryUseCase,
                updateMemoryUseCase = updateMemoryUseCase,
                deleteMemoryUseCase = deleteMemoryUseCase,
                clearAllMemoriesUseCase = clearAllMemoriesUseCase,
                searchMemoriesUseCase = searchMemoriesUseCase,
                getKnowledgeBaseUseCase = getKnowledgeBaseUseCase,
                saveKnowledgeUseCase = saveKnowledgeUseCase,
                updateKnowledgeUseCase = updateKnowledgeUseCase,
                deleteKnowledgeUseCase = deleteKnowledgeUseCase,
                clearAllKnowledgeUseCase = clearAllKnowledgeUseCase,
                searchKnowledgeUseCase = searchKnowledgeUseCase,
                getSettingsUseCase = getSettingsUseCase,
                updateSettingsUseCase = updateSettingsUseCase,
                clearChatUseCase = clearChatUseCase
            ) as T
        }
    }
}
