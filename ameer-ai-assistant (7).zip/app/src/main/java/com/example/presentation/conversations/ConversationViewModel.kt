package com.example.presentation.conversations

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.model.Conversation
import com.example.domain.usecase.CreateConversationUseCase
import com.example.domain.usecase.DeleteConversationUseCase
import com.example.domain.usecase.GetConversationsUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ConversationListUiState(
    val conversations: List<Conversation> = emptyList(),
    val selectedConversationId: Long = 1L,
    val conversationToDelete: Conversation? = null,
    val isDeleteDialogOpen: Boolean = false
)

class ConversationViewModel(
    private val getConversationsUseCase: GetConversationsUseCase,
    private val createConversationUseCase: CreateConversationUseCase,
    private val deleteConversationUseCase: DeleteConversationUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConversationListUiState())
    val uiState: StateFlow<ConversationListUiState> = _uiState.asStateFlow()

    init {
        observeConversations()
    }

    private fun observeConversations() {
        viewModelScope.launch {
            getConversationsUseCase().collect { list ->
                _uiState.update { it.copy(conversations = list) }
            }
        }
    }

    fun setSelectedConversation(id: Long) {
        _uiState.update { it.copy(selectedConversationId = id) }
    }

    fun createNewConversation(onCreated: (Long) -> Unit) {
        viewModelScope.launch {
            val newConversation = createConversationUseCase("محادثة جديدة")
            _uiState.update { it.copy(selectedConversationId = newConversation.id) }
            onCreated(newConversation.id)
        }
    }

    fun promptDeleteConversation(conversation: Conversation) {
        _uiState.update {
            it.copy(
                conversationToDelete = conversation,
                isDeleteDialogOpen = true
            )
        }
    }

    fun dismissDeleteDialog() {
        _uiState.update {
            it.copy(
                conversationToDelete = null,
                isDeleteDialogOpen = false
            )
        }
    }

    fun confirmDeleteConversation(onActiveDeleted: (Long) -> Unit) {
        val target = _uiState.value.conversationToDelete ?: return
        viewModelScope.launch {
            deleteConversationUseCase(target.id)
            val remaining = _uiState.value.conversations.filter { it.id != target.id }

            if (target.id == _uiState.value.selectedConversationId) {
                // If deleted current active conversation, switch to the newest remaining or create one
                val nextActiveId = remaining.firstOrNull()?.id
                if (nextActiveId != null) {
                    _uiState.update {
                        it.copy(
                            selectedConversationId = nextActiveId,
                            conversationToDelete = null,
                            isDeleteDialogOpen = false
                        )
                    }
                    onActiveDeleted(nextActiveId)
                } else {
                    val fresh = createConversationUseCase("المحادثة الرئيسية")
                    _uiState.update {
                        it.copy(
                            selectedConversationId = fresh.id,
                            conversationToDelete = null,
                            isDeleteDialogOpen = false
                        )
                    }
                    onActiveDeleted(fresh.id)
                }
            } else {
                _uiState.update {
                    it.copy(
                        conversationToDelete = null,
                        isDeleteDialogOpen = false
                    )
                }
            }
        }
    }

    class Factory(
        private val getConversationsUseCase: GetConversationsUseCase,
        private val createConversationUseCase: CreateConversationUseCase,
        private val deleteConversationUseCase: DeleteConversationUseCase
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ConversationViewModel(
                getConversationsUseCase = getConversationsUseCase,
                createConversationUseCase = createConversationUseCase,
                deleteConversationUseCase = deleteConversationUseCase
            ) as T
        }
    }
}
