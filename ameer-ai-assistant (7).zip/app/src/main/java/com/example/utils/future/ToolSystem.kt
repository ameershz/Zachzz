package com.example.utils.future

/**
 * Extensible interface reserved for Future V2 Agentic Tool Execution / Function Calling.
 *
 * Implementation Roadmap:
 * - Allows Ameer AI to invoke tools dynamically (e.g., Weather API, Calendar,
 *   Web Search, Device Calculator, Notes).
 */
interface AITool {
    val name: String
    val description: String
    val parametersSchema: Map<String, String>

    suspend fun execute(parameters: Map<String, Any?>): ToolExecutionResult
}

data class ToolExecutionResult(
    val success: Boolean,
    val resultSummary: String,
    val data: Map<String, Any?> = emptyMap()
)

interface ToolRegistry {
    fun registerTool(tool: AITool)
    fun getRegisteredTools(): List<AITool>
    suspend fun executeTool(name: String, parameters: Map<String, Any?>): ToolExecutionResult?
}
