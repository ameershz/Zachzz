package com.example.utils.future

/**
 * Extensible interface reserved for Future V2 Text-To-Speech (TTS).
 *
 * Implementation Roadmap:
 * - Can be implemented using Android's native [android.speech.tts.TextToSpeech]
 *   or neural TTS services (Google Cloud TTS / ElevenLabs API).
 */
interface TtsManager {
    fun speak(text: String, onComplete: () -> Unit = {})
    fun stop()
    fun isSpeaking(): Boolean
    fun shutdown()
}
