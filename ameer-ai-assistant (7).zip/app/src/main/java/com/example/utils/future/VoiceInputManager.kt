package com.example.utils.future

import kotlinx.coroutines.flow.Flow

/**
 * Extensible interface reserved for Future V2 Voice Input (Speech-To-Text).
 *
 * Implementation Roadmap:
 * - Can be implemented using Android's native [android.speech.SpeechRecognizer]
 *   or cloud streaming speech-to-text models (Whisper / Gemini Multimodal Live).
 */
interface VoiceInputManager {
    fun isVoiceInputSupported(): Boolean
    fun startListening(): Flow<VoiceRecognitionState>
    fun stopListening()
}

sealed class VoiceRecognitionState {
    data object Idle : VoiceRecognitionState()
    data object Listening : VoiceRecognitionState()
    data class PartialResult(val text: String) : VoiceRecognitionState()
    data class FinalResult(val text: String) : VoiceRecognitionState()
    data class Error(val message: String) : VoiceRecognitionState()
}
