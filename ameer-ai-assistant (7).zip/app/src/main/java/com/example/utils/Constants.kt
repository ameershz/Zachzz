package com.example.utils

object Constants {
    const val DATABASE_NAME = "ameer_ai_database"
    const val DEFAULT_CONVERSATION_ID = 1L
    const val DEFAULT_ASSISTANT_NAME = "Ameer AI"

    val QUICK_PROMPTS = listOf(
        "من أنت؟",
        "اكتب كود Kotlin",
        "اقترح خطة لليوم",
        "ما هي المعمارية المستخدمة؟"
    )
}
