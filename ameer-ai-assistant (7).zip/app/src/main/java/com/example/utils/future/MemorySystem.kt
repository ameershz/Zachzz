package com.example.utils.future

/**
 * Extensible interface reserved for Future V2 Long-Term AI Memory System.
 *
 * Implementation Roadmap:
 * - Can store user preferences, key personal facts, and vector embeddings
 *   to provide persistent recall across multiple conversation sessions.
 */
interface MemorySystem {
    suspend fun saveMemory(key: String, fact: String)
    suspend fun retrieveMemories(query: String): List<String>
    suspend fun clearAllMemories()
}
