package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.KnowledgeEntity
import com.example.domain.model.knowledge.KnowledgeCategory
import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.model.knowledge.KnowledgeSourceType
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Ameer AI", appName)
    }

    @Test
    fun `test Room KnowledgeDao operations`() = runTest {
        val dao = db.knowledgeDao()
        assertEquals(0, dao.getKnowledgeCount())

        val item = KnowledgeItem(
            title = "توثيق المعمارية النظيفة",
            content = "تقسم المعمارية إلى طبقات: UI, Domain, Data, AICore لضمان العزل الكامل.",
            category = KnowledgeCategory.TECHNICAL,
            sourceType = KnowledgeSourceType.MANUAL_TEXT,
            tags = listOf("clean", "architecture", "kotlin")
        )

        val entity = KnowledgeEntity.fromDomain(item)
        val id = dao.insertKnowledge(entity)
        assertTrue(id > 0)
        assertEquals(1, dao.getKnowledgeCount())

        val loaded = dao.getKnowledgeById(id)
        assertNotNull(loaded)
        assertEquals("توثيق المعمارية النظيفة", loaded?.title)
        assertEquals(KnowledgeCategory.TECHNICAL, loaded?.toDomain()?.category)

        // Test search
        val searchResults = dao.searchKnowledge("طبقات")
        assertEquals(1, searchResults.size)

        // Test flow
        val flowItems = dao.getAllKnowledgeFlow().first()
        assertEquals(1, flowItems.size)

        // Test delete
        dao.deleteKnowledgeById(id)
        assertEquals(0, dao.getKnowledgeCount())
    }
}
