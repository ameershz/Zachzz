# Ameer AI Assistant (مساعد أمير الذكي) - V1.2 (AI Core)

تطبيق أندرويد متطور واحترافي لمساعد الذكاء الاصطناعي **Ameer AI Assistant**، مبني بالكامل باستخدام **Kotlin** و **Jetpack Compose** وفق أفضل الممارسات البرمجية ومعمارية **Clean Architecture + MVVM** مع قاعدة بيانات محلية سريعة **Room Database** وطبقة **AI Core** المستقلة.

---

## 🌟 الجديد في تحديث AI Core (V1.2)

- 🧠 **طبقة AI Core المستقلة:**
  - معمارية متقدمة تفصل منطق الذكاء الاصطناعي ومحركاته عن واجهات المستخدم ومنطق الأعمال.
  - تعمل محلياً بالكامل وبدون استهلاك بيانات، ومجهزة للتبديل والترقية المستقبلية دون تعديل الـ UI.

- 🎭 **نظام الشخصية وأسلوب الرد (Personality System):**
  - أساليب متعددة للتفكير والردود:
    - **متوازن وحكيم (Balanced):** جمع متقن بين الود والدقة.
    - **مهني وأكاديمي (Professional):** صياغة رسمية، علمية، ومنهجية.
    - **إبداعي وتفاعلي (Creative):** غني بالأفكار المبتكرة والتحفيز.
    - **موجز ومباشر (Concise):** إجابات مباشرة وسريعة بنقاط مركزة.

- ⚖️ **نظام القوانين والتعليمات الثابتة (Rules System):**
  - قواعد ثابتة تحكم سلوك المساعد:
    - **الهوية الثابتة:** الحفاظ على هوية Ameer AI كمساعد شخصي مخلص.
    - **الأمانة المعرفية والدقة:** الصدق المعرفي وتجنب اختلاق المعلومات.
    - **التنسيق المنظم (Markdown):** تنسيق العناوين والجداول والأكواد.
    - **الطلاقة ثنائية اللغة:** لغة عربية فصحى نقية مع دعم الإنجليزية.
    - **اللباقة والأمان:** احترام المستخدم والحفاظ على إيجابية المحادثة.

- 🤖 **مدير النماذج (Model Manager):**
  - إدارة نماذج الذكاء الاصطناعي مستقبلاً بدون لمس كود الواجهة:
    - `Ameer Core Engine V1`: النموذج النشط حالياً (محلي/أوفلاين).
    - `Gemini 2.0 Flash`: نموذج سحابي مُجهز للتفعيل في V2.
    - `Gemini 1.5 Pro`: نموذج استدلال متقدم مُجهز للتفعيل في V2.
    - `Gemma 2B On-Device`: نموذج محلي على معالج الهاتف مُجهز للتفعيل.

---

## 🌟 المميزات الأساسية

- 💬 **واجهة محادثة عصرية (Modern Chat Interface):**
  - تصميم عصري بأسلوب Material Design 3.
  - فقاعات رسائل مميزة للمستخدم والمساعد مع إمكانية نسخ الردود وعرض وقت الإرسال.
  - مؤشر تفاعلي لحالة كتابة/تفكير المساعد الذكي.
  - التمرير التلقائي لأحدث رسالة (Auto-scroll).
  - ضبط ذكي للحواف (`WindowInsets`) بدون أي فراغ فوق لوحة المفاتيح.

- 🗂️ **نظام المحادثات المتعددة (Multi-Conversation Management):**
  - سجل محادثات مستقل (`ConversationListScreen`).
  - زر "محادثة جديدة" مع حفظ كامل واسترجاع تلقائي للجلسات.
  - تحديث عنوان الجلسة تلقائياً بحسب السؤال الأول.

- 🗄️ **قاعدة بيانات محلية (Room Database Persistence):**
  - تخزين دائم لكافة المحادثات والرسائل على الجهاز.
  - تحديث واجهات المستخدم بشكل فوري وتفاعلي عبر `Kotlin Flow`.

- ⚙️ **شاشة إعدادات متكاملة (Settings Screen):**
  - تخصيص اسم المساعد، اختيار أسلوب الرد، تفعيل/تعطيل القوانين.
  - استعراض وتبديل نماذج الذكاء الاصطناعي.
  - تفعيل الوضع الصوتي (تجهيز V2) ومسح المحادثات بأمان.

---

## 🏗️ المعمارية البرمجية (Clean Architecture + AI Core)

```text
app/src/main/java/com/example/
├── AmeerAiApplication.kt              # فئة التطبيق الرئيسية
├── MainActivity.kt                    # نشاط التطبيق الرئيسي وإدارة الشاشات
│
├── aicore/                            # طبقة AI Core (الجديدة)
│   ├── engine/                        # AICoreEngine (المحرك المنسق)
│   ├── model/                         # AIModel & ModelManager (إدارة النماذج)
│   └── personality/                   # PersonalityStyle, AssistantRule, PersonalityManager
│
├── data/                              # طبقة البيانات (Data Layer)
│   ├── local/                         # قاعدة بيانات Room (Entities, DAOs, Database)
│   ├── remote/                        # خدمات الذكاء الاصطناعي (AIService, MockAIService)
│   └── repository/                    # تنفيذ المستودعات (Repository Implementations)
│
├── domain/                            # طبقة منطق الأعمال (Domain Layer)
│   ├── model/                         # نماذج البيانات (ChatMessage, Conversation, Settings)
│   ├── repository/                    # عقود المستودعات التجريدية (AIRepository, ChatRepository)
│   └── usecase/                       # حالات الاستخدام المستقلة
│
├── presentation/                      # طبقة الواجهات (Presentation Layer)
│   ├── chat/                          # شاشة ومنطق المحادثة
│   ├── conversations/                 # شاشة وسجل المحادثات
│   ├── settings/                      # شاشة ومنطق الإعدادات ونظام الشخصية والنماذج
│   └── components/                    # مكونات الواجهة القابلة لإعادة الاستخدام
│
└── di/
    └── AppContainer.kt                # حاوية حقن الاعتماديات المركزية
```

---

## 🛠️ المتطلبات والتقنيات (Tech Stack)

- **Language:** Kotlin 2.2+
- **UI Toolkit:** Jetpack Compose (Material 3)
- **Architecture:** Clean Architecture + MVVM + AI Core
- **Local Database:** Room Database 2.7+ (مع KSP)
- **Asynchronous & Reactive:** Coroutines & Kotlin Flow
- **Build System:** Gradle (Kotlin DSL - `.gradle.kts`)
- **Compatibility:** Android 7.0 (API Level 24) فما فوق
