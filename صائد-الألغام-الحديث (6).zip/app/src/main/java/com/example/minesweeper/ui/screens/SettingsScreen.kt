package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.ChordingTrigger
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

@Composable
fun SettingsScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    val settings = uiState.settings

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RetroLightGray)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RetroPanelGray)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = NavyPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "إعدادات اللعبة ⚙️",
                        color = NavyPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "تخصيص الصوت، الاهتزاز وطريقة الكشف",
                        color = NavyPrimary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Chording Settings Card
                RetroBeveledCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "طريقة كشف المربعات المحيطة (Chording)",
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "عندما يكون الرقم محاطاً بالأعلام الصحيحة، كشف الباقي تلقائياً",
                            color = NavyPrimary.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        ChordingTrigger.values().forEach { trigger ->
                            val isSelected = settings.chordingTrigger == trigger
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updateSettings(settings.copy(chordingTrigger = trigger))
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = {
                                        viewModel.updateSettings(settings.copy(chordingTrigger = trigger))
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = NavyPrimary)
                                )
                                Column(modifier = Modifier.padding(start = 8.dp)) {
                                    Text(
                                        text = trigger.titleAr,
                                        color = if (isSelected) NavyPrimary else NavyPrimary.copy(alpha = 0.8f),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = trigger.description,
                                        color = NavyPrimary.copy(alpha = 0.6f),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Audio & Haptics Card
                RetroBeveledCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "الأصوات والتفاعل",
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )

                        SettingsToggleRow(
                            title = "تأثيرات الصوت 🔊",
                            description = "تشغيل أصوات النقر، الفوز والانفجار",
                            checked = settings.soundEffectsEnabled,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(soundEffectsEnabled = it)) }
                        )

                        SettingsToggleRow(
                            title = "الاهتزاز (Haptics) 📳",
                            description = "اهتزاز خفيف عند الكشف ووضع الأعلام",
                            checked = settings.hapticFeedbackEnabled,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(hapticFeedbackEnabled = it)) }
                        )

                        SettingsToggleRow(
                            title = "قفل التكبير افتراضياً 🔍",
                            description = "منع التكبير التلقائي عند بدء اللعبة",
                            checked = settings.lockZoomByDefault,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(lockZoomByDefault = it)) }
                        )
                    }
                }

                // Themes & Customization shortcut
                RetroBeveledCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(ScreenState.THEMES) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = "الثيمات",
                                tint = NavyPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "اختيار الثيم والمظهر (12 ثيم)",
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "اختر بين النمط الكلاسيكي، الليلي، نيون، والمزيد",
                                    color = NavyPrimary.copy(alpha = 0.7f),
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Text("◀", color = NavyPrimary, fontSize = 16.sp)
                    }
                }

                // About / Info Card
                RetroBeveledCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "حول",
                            tint = NavyPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "صائد الألغام — إصدار احترافي",
                                color = NavyPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "مستوحى من أصول Minesweeper Go الكلاسيكية",
                                color = NavyPrimary.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = NavyPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = description,
                color = NavyPrimary.copy(alpha = 0.7f),
                fontSize = 11.sp
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = NavyPrimary
            )
        )
    }
}
