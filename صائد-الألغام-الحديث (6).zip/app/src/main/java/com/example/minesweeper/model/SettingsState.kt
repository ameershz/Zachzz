package com.example.minesweeper.model

enum class ChordingTrigger(val titleAr: String, val description: String) {
    LONG_PRESS("الضغط المطول", "اضغط مطولاً على الرقم لكشف المربعات الآمنة المحيطة"),
    DOUBLE_TAP("النقر المزدوج", "انقر مرتين متتاليتين بسرعة على الرقم"),
    SINGLE_TAP("النقر المباشر", "انقر نقرة واحدة على الرقم المكتمل أعلامه")
}

data class SettingsState(
    val chordingTrigger: ChordingTrigger = ChordingTrigger.LONG_PRESS,
    val volumeKeyToggleEnabled: Boolean = true,
    val hapticFeedbackEnabled: Boolean = true,
    val soundEffectsEnabled: Boolean = true,
    val lockZoomByDefault: Boolean = false,
    val guessFreeOptionEnabled: Boolean = false,
    val portraitExpertOrientation: Boolean = false,
    val selectedThemeId: String = "classic_retro"
)
