package com.example.minesweeper.engine

import com.example.minesweeper.model.Cell
import com.example.minesweeper.model.GameStatus
import kotlin.random.Random

class MinesweeperEngine(
    val rows: Int,
    val cols: Int,
    val totalMines: Int,
    val isGuessFreeRequested: Boolean = false
) {
    var grid: List<List<Cell>> = List(rows) { r ->
        List(cols) { c -> Cell(row = r, col = c) }
    }
        private set

    var status: GameStatus = GameStatus.NOT_STARTED
        private set

    var isFirstClick: Boolean = true
        private set

    var threeBV: Int = 0
        private set

    var clicksCount: Int = 0
        private set

    var effectiveClicksCount: Int = 0
        private set

    val totalCells: Int = rows * cols
    val safeCellsCount: Int = totalCells - totalMines

    val revealedCount: Int
        get() = grid.sumOf { row -> row.count { it.isRevealed && !it.isMine } }

    val flaggedCount: Int
        get() = grid.sumOf { row -> row.count { it.isFlagged } }

    val remainingMines: Int
        get() = totalMines - flaggedCount

    fun getNeighbors(r: Int, c: Int): List<Pair<Int, Int>> {
        val list = mutableListOf<Pair<Int, Int>>()
        for (dr in -1..1) {
            for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                val nr = r + dr
                val nc = c + dc
                if (nr in 0 until rows && nc in 0 until cols) {
                    list.add(nr to nc)
                }
            }
        }
        return list
    }

    private fun generateBoard(firstR: Int, firstC: Int) {
        val maxAttempts = if (isGuessFreeRequested) 30 else 1
        var chosenGrid: List<List<Cell>>? = null

        for (attempt in 0 until maxAttempts) {
            val candidateGrid = List(rows) { r ->
                MutableList(cols) { c -> Cell(row = r, col = c) }
            }

            // Exclude first click and its immediate 8 neighbors for an opening if possible
            val forbidden = mutableSetOf<Pair<Int, Int>>()
            forbidden.add(firstR to firstC)
            if (totalCells - 9 >= totalMines) {
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        val nr = firstR + dr
                        val nc = firstC + dc
                        if (nr in 0 until rows && nc in 0 until cols) {
                            forbidden.add(nr to nc)
                        }
                    }
                }
            }

            val allCoords = mutableListOf<Pair<Int, Int>>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if ((r to c) !in forbidden) {
                        allCoords.add(r to c)
                    }
                }
            }
            allCoords.shuffle(Random)

            val minePositions = allCoords.take(totalMines).toSet()

            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val isMine = (r to c) in minePositions
                    candidateGrid[r][c] = candidateGrid[r][c].copy(isMine = isMine)
                }
            }

            // Calculate adjacent mines
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (!candidateGrid[r][c].isMine) {
                        val count = getNeighbors(r, c).count { (nr, nc) -> candidateGrid[nr][nc].isMine }
                        candidateGrid[r][c] = candidateGrid[r][c].copy(adjacentMines = count)
                    }
                }
            }

            val candidateList = candidateGrid.map { it.toList() }
            if (!isGuessFreeRequested || GuessFreeSolver.isSolvable(candidateList, rows, cols, firstR, firstC)) {
                chosenGrid = candidateList
                break
            } else if (chosenGrid == null) {
                chosenGrid = candidateList // Fallback to best effort
            }
        }

        grid = chosenGrid ?: grid
        threeBV = ThreeBVCalculator.calculate(grid, rows, cols)
    }

    fun revealCell(r: Int, c: Int): RevealResult {
        if (status == GameStatus.WON || status == GameStatus.LOST) return RevealResult.NoOp
        val cell = grid[r][c]
        if (cell.isRevealed || cell.isFlagged) return RevealResult.NoOp

        clicksCount++

        if (isFirstClick) {
            generateBoard(r, c)
            isFirstClick = false
            status = GameStatus.IN_PROGRESS
        }

        val target = grid[r][c]
        val mutableGrid = grid.map { it.toMutableList() }.toMutableList()

        if (target.isMine) {
            mutableGrid[r][c] = target.copy(isRevealed = true, isExplodedMine = true)
            for (row in 0 until rows) {
                for (col in 0 until cols) {
                    val curr = mutableGrid[row][col]
                    if (curr.isMine) {
                        mutableGrid[row][col] = curr.copy(isRevealed = true)
                    }
                }
            }
            grid = mutableGrid.map { it.toList() }
            status = GameStatus.LOST
            return RevealResult.HitMine(r, c)
        }

        effectiveClicksCount++
        revealFloodFill(mutableGrid, r, c)
        grid = mutableGrid.map { it.toList() }

        if (checkWin()) {
            status = GameStatus.WON
            grid = grid.map { row ->
                row.map { curr ->
                    if (curr.isMine && !curr.isFlagged) curr.copy(isFlagged = true) else curr
                }
            }
            return RevealResult.Win
        }

        return RevealResult.Success
    }

    private fun revealFloodFill(mutableGrid: MutableList<MutableList<Cell>>, startR: Int, startC: Int) {
        val queue = ArrayDeque<Pair<Int, Int>>()
        if (!mutableGrid[startR][startC].isRevealed && !mutableGrid[startR][startC].isFlagged) {
            mutableGrid[startR][startC] = mutableGrid[startR][startC].copy(isRevealed = true, isHinted = false)
            if (mutableGrid[startR][startC].adjacentMines == 0) {
                queue.add(startR to startC)
            }
        }

        while (queue.isNotEmpty()) {
            val (currR, currC) = queue.removeFirst()
            for ((nr, nc) in getNeighbors(currR, currC)) {
                val neighbor = mutableGrid[nr][nc]
                if (!neighbor.isRevealed && !neighbor.isFlagged && !neighbor.isMine) {
                    mutableGrid[nr][nc] = neighbor.copy(isRevealed = true, isHinted = false)
                    if (neighbor.adjacentMines == 0) {
                        queue.add(nr to nc)
                    }
                }
            }
        }
    }

    fun toggleFlag(r: Int, c: Int): Boolean {
        if (status == GameStatus.WON || status == GameStatus.LOST) return false
        val cell = grid[r][c]
        if (cell.isRevealed) return false

        clicksCount++
        val newFlag = !cell.isFlagged
        grid = grid.mapIndexed { ri, row ->
            row.mapIndexed { ci, cl ->
                if (ri == r && ci == c) cl.copy(isFlagged = newFlag) else cl
            }
        }
        return newFlag
    }

    fun chordCell(r: Int, c: Int): RevealResult {
        if (status != GameStatus.IN_PROGRESS) return RevealResult.NoOp
        val cell = grid[r][c]
        if (!cell.isRevealed || cell.adjacentMines == 0) return RevealResult.NoOp

        val neighbors = getNeighbors(r, c)
        val flaggedCount = neighbors.count { (nr, nc) -> grid[nr][nc].isFlagged }

        if (flaggedCount == cell.adjacentMines) {
            clicksCount++
            effectiveClicksCount++
            var hitMine = false
            var mineCoords: Pair<Int, Int>? = null

            val mutableGrid = grid.map { it.toMutableList() }.toMutableList()

            for ((nr, nc) in neighbors) {
                val neighbor = mutableGrid[nr][nc]
                if (!neighbor.isRevealed && !neighbor.isFlagged) {
                    if (neighbor.isMine) {
                        hitMine = true
                        mineCoords = nr to nc
                        mutableGrid[nr][nc] = neighbor.copy(isRevealed = true, isExplodedMine = true)
                    } else {
                        mutableGrid[nr][nc] = neighbor.copy(isRevealed = true, isHinted = false)
                    }
                }
            }

            if (hitMine) {
                for (row in 0 until rows) {
                    for (col in 0 until cols) {
                        val curr = mutableGrid[row][col]
                        if (curr.isMine) {
                            mutableGrid[row][col] = curr.copy(isRevealed = true)
                        }
                    }
                }
                grid = mutableGrid.map { it.toList() }
                status = GameStatus.LOST
                return RevealResult.HitMine(mineCoords?.first ?: r, mineCoords?.second ?: c)
            }

            // Trigger flood fill for any 0-mine neighbors revealed by chord
            val queue = ArrayDeque<Pair<Int, Int>>()
            for ((nr, nc) in neighbors) {
                val neighbor = mutableGrid[nr][nc]
                if (neighbor.isRevealed && !neighbor.isMine && neighbor.adjacentMines == 0) {
                    queue.add(nr to nc)
                }
            }

            while (queue.isNotEmpty()) {
                val (currR, currC) = queue.removeFirst()
                for ((nr, nc) in getNeighbors(currR, currC)) {
                    val neighbor = mutableGrid[nr][nc]
                    if (!neighbor.isRevealed && !neighbor.isFlagged && !neighbor.isMine) {
                        mutableGrid[nr][nc] = neighbor.copy(isRevealed = true, isHinted = false)
                        if (neighbor.adjacentMines == 0) {
                            queue.add(nr to nc)
                        }
                    }
                }
            }

            grid = mutableGrid.map { it.toList() }

            if (checkWin()) {
                status = GameStatus.WON
                grid = grid.map { row ->
                    row.map { curr ->
                        if (curr.isMine && !curr.isFlagged) curr.copy(isFlagged = true) else curr
                    }
                }
                return RevealResult.Win
            }

            return RevealResult.Success
        }
        return RevealResult.NoOp
    }

    fun useSmartHint(): Pair<Int, Int>? {
        if (status != GameStatus.IN_PROGRESS && !isFirstClick) return null

        if (isFirstClick) {
            return Pair(rows / 2, cols / 2)
        }

        var candidate: Pair<Int, Int>? = null

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (cell.isRevealed && cell.adjacentMines > 0) {
                    val neighbors = getNeighbors(r, c)
                    val flagged = neighbors.count { (nr, nc) -> grid[nr][nc].isFlagged }
                    if (flagged == cell.adjacentMines) {
                        val safe = neighbors.firstOrNull { (nr, nc) -> !grid[nr][nc].isRevealed && !grid[nr][nc].isFlagged }
                        if (safe != null) {
                            candidate = safe
                            break
                        }
                    }
                }
            }
            if (candidate != null) break
        }

        if (candidate == null) {
            val safeCells = mutableListOf<Pair<Int, Int>>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val cell = grid[r][c]
                    if (!cell.isMine && !cell.isRevealed && !cell.isFlagged) {
                        safeCells.add(r to c)
                    }
                }
            }
            if (safeCells.isNotEmpty()) {
                candidate = safeCells.random()
            }
        }

        candidate?.let { (cr, cc) ->
            grid = grid.mapIndexed { ri, row ->
                row.mapIndexed { ci, cl ->
                    if (ri == cr && ci == cc) cl.copy(isHinted = true) else cl
                }
            }
        }
        return candidate
    }

    fun useMagicWand(): List<Pair<Int, Int>> {
        if (status != GameStatus.IN_PROGRESS && !isFirstClick) return emptyList()

        if (isFirstClick) {
            revealCell(rows / 2, cols / 2)
            return listOf(rows / 2 to cols / 2)
        }

        val safeCells = mutableListOf<Pair<Int, Int>>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (!cell.isMine && !cell.isRevealed && !cell.isFlagged) {
                    safeCells.add(r to c)
                }
            }
        }

        if (safeCells.isEmpty()) return emptyList()

        val center = safeCells.random()
        val revealedList = mutableListOf<Pair<Int, Int>>()

        val mutableGrid = grid.map { it.toMutableList() }.toMutableList()
        revealFloodFill(mutableGrid, center.first, center.second)
        grid = mutableGrid.map { it.toList() }
        revealedList.add(center)

        if (checkWin()) {
            status = GameStatus.WON
        }
        return revealedList
    }

    fun revive(explodedR: Int, explodedC: Int): Boolean {
        if (status != GameStatus.LOST) return false
        val mutableGrid = grid.map { it.toMutableList() }.toMutableList()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = mutableGrid[r][c]
                if (cell.isMine) {
                    if (r == explodedR && c == explodedC) {
                        mutableGrid[r][c] = cell.copy(isRevealed = false, isExplodedMine = false, isFlagged = true)
                    } else if (cell.isRevealed && !cell.isFlagged) {
                        mutableGrid[r][c] = cell.copy(isRevealed = false)
                    }
                }
            }
        }
        grid = mutableGrid.map { it.toList() }
        status = GameStatus.IN_PROGRESS
        return true
    }

    private fun checkWin(): Boolean {
        return revealedCount >= safeCellsCount
    }

    sealed class RevealResult {
        object NoOp : RevealResult()
        object Success : RevealResult()
        object Win : RevealResult()
        data class HitMine(val r: Int, val c: Int) : RevealResult()
    }
}
