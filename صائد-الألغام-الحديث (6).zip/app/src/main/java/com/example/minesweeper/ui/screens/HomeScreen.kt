package com.example.minesweeper.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.model.BoardDifficulty
import com.example.minesweeper.model.GameMode
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

val NavyPrimary = Color(0xFF1C2A39)
val RetroLightGray = Color(0xFFC0C0C0)
val RetroPanelGray = Color(0xFFD6D6D6)
val RetroWhiteHighlight = Color(0xFFFFFFFF)
val RetroDarkShadow = Color(0xFF707070)

@Composable
fun HomeScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    var showDifficultyDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RetroLightGray)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Logo & Title with Red Flag motif
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .drawBehind {
                            val stroke = 3.dp.toPx()
                            drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                            drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                            drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                            drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                        }
                        .background(RetroPanelGray),
                    contentAlignment = Alignment.Center
                ) {
                    Text("💣🚩", fontSize = 26.sp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "صائد الألغام",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = NavyPrimary,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Big GO Play Button (Authentic primary action)
            RetroButton(
                onClick = { showDifficultyDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .testTag("play_menu_button"),
                containerColor = NavyPrimary
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "ابدأ",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GO — ابدأ اللعب",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Grid (Campaign, Tournaments, Themes, Stats, Settings)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                RetroMenuButton(
                    title = "الحملة (المراحل)",
                    subtitle = "15 مرحلة متدرجة بالتحديات",
                    icon = Icons.Default.Map,
                    tag = "campaign_menu_button",
                    onClick = { viewModel.navigateTo(ScreenState.CAMPAIGN) }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RetroSubMenuButton(
                        title = "البطولات",
                        icon = Icons.Default.EmojiEvents,
                        modifier = Modifier.weight(1f),
                        tag = "tournaments_menu_button",
                        onClick = { viewModel.navigateTo(ScreenState.TOURNAMENTS) }
                    )
                    RetroSubMenuButton(
                        title = "الثيمات",
                        icon = Icons.Default.Palette,
                        modifier = Modifier.weight(1f),
                        tag = "themes_menu_button",
                        onClick = { viewModel.navigateTo(ScreenState.THEMES) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RetroSubMenuButton(
                        title = "الإحصائيات",
                        icon = Icons.Default.BarChart,
                        modifier = Modifier.weight(1f),
                        tag = "stats_menu_button",
                        onClick = { viewModel.navigateTo(ScreenState.STATS) }
                    )
                    RetroSubMenuButton(
                        title = "الإعدادات",
                        icon = Icons.Default.Settings,
                        modifier = Modifier.weight(1f),
                        tag = "settings_menu_button",
                        onClick = { viewModel.navigateTo(ScreenState.SETTINGS) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Difficulty & Game Launch Dialog
        if (showDifficultyDialog) {
            DifficultySelectionDialog(
                currentGuessFree = uiState.isGuessFree,
                onDismiss = { showDifficultyDialog = false },
                onStartGame = { diff, mode, guessFree, r, c, m ->
                    showDifficultyDialog = false
                    viewModel.startNewGame(
                        difficulty = diff,
                        mode = mode,
                        customRows = r,
                        customCols = c,
                        customMines = m,
                        guessFree = guessFree
                    )
                }
            )
        }
    }
}

@Composable
fun RetroBeveledCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .drawBehind {
                val stroke = 2.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(RetroPanelGray)
    ) {
        content()
    }
}

@Composable
fun RetroButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = RetroPanelGray,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .drawBehind {
                val stroke = 3.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(containerColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
private fun RetroMenuButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tag: String,
    onClick: () -> Unit
) {
    RetroButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = NavyPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Column {
                    Text(
                        text = title,
                        color = NavyPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = subtitle,
                        color = NavyPrimary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }
            Text("◀", color = NavyPrimary, fontSize = 16.sp)
        }
    }
}

@Composable
private fun RetroSubMenuButton(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    tag: String,
    onClick: () -> Unit
) {
    RetroButton(
        onClick = onClick,
        modifier = modifier
            .height(56.dp)
            .testTag(tag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = NavyPrimary,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = title,
                color = NavyPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DifficultySelectionDialog(
    currentGuessFree: Boolean,
    onDismiss: () -> Unit,
    onStartGame: (BoardDifficulty, GameMode, Boolean, Int, Int, Int) -> Unit
) {
    var selectedDifficulty by remember { mutableStateOf(BoardDifficulty.BEGINNER) }
    var selectedMode by remember { mutableStateOf(GameMode.CLASSIC) }
    var guessFree by remember { mutableStateOf(currentGuessFree) }

    var customR by remember { mutableIntStateOf(10) }
    var customC by remember { mutableIntStateOf(10) }
    var customM by remember { mutableIntStateOf(15) }

    Dialog(onDismissRequest = onDismiss) {
        RetroBeveledCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("difficulty_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "اختر الصعوبة والطور 🎮",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = NavyPrimary
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Mode toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetroLightGray, RoundedCornerShape(4.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (selectedMode == GameMode.CLASSIC) NavyPrimary else Color.Transparent)
                            .clickable { selectedMode = GameMode.CLASSIC }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "حر كلاسيك",
                            color = if (selectedMode == GameMode.CLASSIC) Color.White else NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (selectedMode == GameMode.TIMER) NavyPrimary else Color.Transparent)
                            .clickable { selectedMode = GameMode.TIMER }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "تحدي المؤقت ⏱️",
                            color = if (selectedMode == GameMode.TIMER) Color.White else NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Difficulties List (Authentic Minesweeper Go format: Field {cols}x{rows} - {mines} mines)
                listOf(
                    BoardDifficulty.BEGINNER,
                    BoardDifficulty.INTERMEDIATE,
                    BoardDifficulty.EXPERT,
                    BoardDifficulty.CUSTOM
                ).forEach { diff ->
                    val isSelected = selectedDifficulty == diff
                    val desc = when (diff) {
                        BoardDifficulty.BEGINNER -> "حقل 9×9 - 10 ألغام"
                        BoardDifficulty.INTERMEDIATE -> "حقل 16×16 - 40 لغماً"
                        BoardDifficulty.EXPERT -> "حقل 30×16 (أو عمودي 16×30) - 99 لغماً"
                        BoardDifficulty.CUSTOM -> "حقل مخصص حسب رغبتك"
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .drawBehind {
                                val stroke = if (isSelected) 2.dp.toPx() else 1.dp.toPx()
                                drawLine(if (isSelected) NavyPrimary else RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                                drawLine(if (isSelected) NavyPrimary else RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                                drawLine(if (isSelected) NavyPrimary else RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                                drawLine(if (isSelected) NavyPrimary else RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                            }
                            .background(if (isSelected) Color(0xFFE2E8F0) else RetroPanelGray)
                            .clickable { selectedDifficulty = diff }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = diff.titleAr,
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = desc,
                                    color = NavyPrimary.copy(alpha = 0.7f),
                                    fontSize = 12.sp
                                )
                            }
                            if (isSelected) {
                                Text("✔", color = NavyPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (selectedDifficulty == BoardDifficulty.CUSTOM) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RetroLightGray, RoundedCornerShape(4.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "الصفوف: $customR  |  الأعمدة: $customC  |  الألغام: $customM",
                            color = NavyPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            Button(onClick = { if (customR > 6) customR-- }) { Text("- صف") }
                            Button(onClick = { if (customR < 24) customR++ }) { Text("+ صف") }
                            Button(onClick = { if (customM > 3) customM-- }) { Text("- لغم") }
                            Button(onClick = { if (customM < (customR * customC) / 3) customM++ }) { Text("+ لغم") }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Guess-Free switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetroLightGray, RoundedCornerShape(4.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "خيار «بدون تخمين» 🧠",
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "لوحات قابلة للحل 100% بالمنطق",
                            color = NavyPrimary.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = guessFree,
                        onCheckedChange = { guessFree = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NavyPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RetroButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Text("إلغاء", color = NavyPrimary, fontWeight = FontWeight.Bold)
                    }

                    RetroButton(
                        onClick = {
                            onStartGame(selectedDifficulty, selectedMode, guessFree, customR, customC, customM)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("start_game_confirm_button"),
                        containerColor = NavyPrimary
                    ) {
                        Text("ابدأ اللعب GO 🚀", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
