package com.example.minesweeper.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.GameStatus
import com.example.minesweeper.model.MinesweeperTheme

val RetroLightGray = Color(0xFFC0C0C0)
val RetroPanelGray = Color(0xFFD6D6D6)
val RetroWhiteHighlight = Color(0xFFFFFFFF)
val RetroDarkShadow = Color(0xFF707070)
val NavyPrimary = Color(0xFF1C2A39)

@Composable
fun TopGameHUD(
    remainingMines: Int,
    timerSeconds: Int,
    gameStatus: GameStatus,
    isInteracting: Boolean,
    theme: MinesweeperTheme,
    onResetClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = if (theme.isRetroBeveled) RetroLightGray else theme.boardBackground,
        tonalElevation = 4.dp
    ) {
        // Force LTR so physical left is mines and physical right is timer regardless of system RTL
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (theme.isRetroBeveled) Color(0xFFB0B0B0) else Color(0x22FFFFFF),
                        shape = RoundedCornerShape(6.dp)
                    )
                    .border(
                        2.dp,
                        if (theme.isRetroBeveled) RetroDarkShadow else Color.Transparent,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Remaining Mines Digital Display (Far Left)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "الألغام",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (theme.isRetroBeveled) Color.DarkGray else Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    DigitalLedDisplay(value = remainingMines)
                }

                // Smiley Reset Face Button (Center)
                RetroFaceButton(
                    status = gameStatus,
                    isInteractingWithBoard = isInteracting,
                    onClick = onResetClick
                )

                // Timer Digital Display (Far Right)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "الوقت",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (theme.isRetroBeveled) Color.DarkGray else Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    DigitalLedDisplay(value = timerSeconds)
                }
            }
        }
    }
}

@Composable
fun BottomControlsHUD(
    isFlagMode: Boolean,
    onToggleFlagMode: () -> Unit,
    hintsCount: Int,
    wandsCount: Int,
    onHintClick: () -> Unit,
    onWandClick: () -> Unit,
    onBackClick: () -> Unit,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = RetroLightGray,
        tonalElevation = 8.dp
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        val stroke = 2.dp.toPx()
                        drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Back Arrow (Far Left)
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(44.dp)
                        .drawBeveledBox()
                        .testTag("hud_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = NavyPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // 2. Magic Wand with Counter
                ToolButtonWithCounter(
                    icon = "🪄",
                    count = wandsCount,
                    onClick = onWandClick,
                    tag = "boost_wand"
                )

                // 3. Center Mode Toggle Button (Square Beveled Box with Shovel / Flag)
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .drawBeveledBox(isPressed = isFlagMode)
                        .clickable(onClick = onToggleFlagMode)
                        .testTag("mode_toggle_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isFlagMode) "🚩" else "⛏️",
                        fontSize = 22.sp
                    )
                }

                // 4. Hint Button with Counter
                ToolButtonWithCounter(
                    icon = "💡",
                    count = hintsCount,
                    onClick = onHintClick,
                    tag = "boost_hint"
                )

                // 5. Settings Gear (Far Right)
                IconButton(
                    onClick = onSettingsClick,
                    modifier = Modifier
                        .size(44.dp)
                        .drawBeveledBox()
                        .testTag("hud_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات",
                        tint = NavyPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ToolButtonWithCounter(
    icon: String,
    count: Int,
    onClick: () -> Unit,
    tag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(tag)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .drawBeveledBox(),
            contentAlignment = Alignment.Center
        ) {
            Text(text = icon, fontSize = 20.sp)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "$count",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )
    }
}

@Composable
fun Modifier.drawBeveledBox(isPressed: Boolean = false): Modifier {
    val light = if (isPressed) RetroDarkShadow else RetroWhiteHighlight
    val shadow = if (isPressed) RetroWhiteHighlight else RetroDarkShadow
    return this
        .background(RetroPanelGray)
        .drawBehind {
            val stroke = 2.dp.toPx()
            // Top and left
            drawLine(light, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
            drawLine(light, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
            // Bottom and right
            drawLine(shadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
            drawLine(shadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
        }
}
