package com.example.minesweeper.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.minesweeper.model.AvailableThemes
import com.example.minesweeper.model.Cell
import com.example.minesweeper.model.ChordingTrigger
import com.example.minesweeper.model.MinesweeperTheme

@Composable
fun MinefieldGrid(
    grid: List<List<Cell>>,
    theme: MinesweeperTheme,
    isFlagMode: Boolean,
    chordingTrigger: ChordingTrigger,
    isZoomLocked: Boolean,
    isGameLost: Boolean = false,
    onCellClick: (Int, Int) -> Unit,
    onCellLongClick: (Int, Int) -> Unit,
    onCellDoubleTap: (Int, Int) -> Unit,
    onPressStateChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .background(theme.floor)
    ) {
        val containerWidthPx = constraints.maxWidth.toFloat()
        val containerHeightPx = constraints.maxHeight.toFloat()

        if (containerWidthPx <= 0f || containerHeightPx <= 0f) return@BoxWithConstraints

        val density = LocalDensity.current
        val haptic = LocalHapticFeedback.current
        val viewConfig = LocalViewConfiguration.current
        val touchSlop = viewConfig.touchSlop

        val numRows = maxOf(1, grid.size)
        val numCols = maxOf(1, grid.firstOrNull()?.size ?: 1)

        // Natural board orientation without forced rotation
        val isRotated = false
        val displayCols = numCols
        val displayRows = numRows

        val boardMarginDp = 16.dp
        val boardMarginPx = with(density) { boardMarginDp.toPx() }

        val availWidthPx = maxOf(10f, containerWidthPx - boardMarginPx)
        val availHeightPx = maxOf(10f, containerHeightPx - boardMarginPx)

        // Fit cell size in pixels:
        val fitCellWidth = availWidthPx / displayCols
        val fitCellHeight = availHeightPx / displayRows
        val fitCellSizePx = minOf(fitCellWidth, fitCellHeight)

        val scaleMin = 1.0f
        // Max zoom: cell size reaches ~containerWidth / 6 (per reference rule)
        val maxCellSizePx = containerWidthPx / 6f
        val scaleMax = maxOf(3.0f, maxCellSizePx / fitCellSizePx)

        // Initial base origin (centered)
        val initialOriginX = (containerWidthPx - displayCols * fitCellSizePx) / 2f
        val initialOriginY = (containerHeightPx - displayRows * fitCellSizePx) / 2f

        var scale by remember { mutableFloatStateOf(1f) }
        var originX by remember { mutableFloatStateOf(initialOriginX) }
        var originY by remember { mutableFloatStateOf(initialOriginY) }

        var pressedCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }
        var lastTapCell by remember { mutableStateOf<Pair<Int, Int>?>(null) }
        var lastTapTime by remember { mutableStateOf(0L) }

        // Reset scale and re-center whenever grid or orientation changes
        LaunchedEffect(grid, isRotated, containerWidthPx, containerHeightPx) {
            scale = 1f
            originX = (containerWidthPx - displayCols * fitCellSizePx) / 2f
            originY = (containerHeightPx - displayRows * fitCellSizePx) / 2f
            pressedCell = null
            lastTapCell = null
            lastTapTime = 0L
        }

        // Clamp origin so board edges never exceed container boundaries, and centers when fit
        fun clampOrigin(s: Float, targetX: Float, targetY: Float): Pair<Float, Float> {
            val scaledBoardW = displayCols * (fitCellSizePx * s)
            val scaledBoardH = displayRows * (fitCellSizePx * s)

            val clampedX = if (scaledBoardW <= containerWidthPx) {
                (containerWidthPx - scaledBoardW) / 2f
            } else {
                val minX = containerWidthPx - scaledBoardW
                targetX.coerceIn(minX, 0f)
            }

            val clampedY = if (scaledBoardH <= containerHeightPx) {
                (containerHeightPx - scaledBoardH) / 2f
            } else {
                val minY = containerHeightPx - scaledBoardH
                targetY.coerceIn(minY, 0f)
            }

            return clampedX to clampedY
        }

        // Touch to cell inverse coordinate mapping
        fun getCellAt(touchX: Float, touchY: Float): Pair<Int, Int>? {
            val currentCellSize = fitCellSizePx * scale
            if (currentCellSize <= 0f) return null

            val dispC = kotlin.math.floor((touchX - originX) / currentCellSize).toInt()
            val dispR = kotlin.math.floor((touchY - originY) / currentCellSize).toInt()

            if (dispC !in 0 until displayCols || dispR !in 0 until displayRows) {
                return null
            }

            val r = if (isRotated) dispC else dispR
            val c = if (isRotated) dispR else dispC

            if (r !in 0 until numRows || c !in 0 until numCols) {
                return null
            }

            return r to c
        }

        // Pre-create standard digit paints (no allocations during draw loop)
        val textPaints = remember {
            AvailableThemes.standardDigitColors.map { color ->
                android.graphics.Paint().apply {
                    this.color = color.toArgb()
                    isAntiAlias = true
                    typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
                    textAlign = android.graphics.Paint.Align.CENTER
                }
            }
        }

        val infiniteTransition = rememberInfiniteTransition(label = "hint_anim")
        val hintAlpha by infiniteTransition.animateFloat(
            initialValue = 0.3f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(400),
                repeatMode = RepeatMode.Reverse
            ),
            label = "hint_alpha"
        )

        // Single-pass Canvas with central input handling
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .clipToBounds()
                .testTag("minefield_canvas")
                .pointerInput(grid, isZoomLocked, isRotated, displayCols, displayRows, fitCellSizePx, scaleMax) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val downPos = down.position
                        var isDragOrPinch = false
                        var isLongPressFired = false

                        val initialCandidate = getCellAt(downPos.x, downPos.y)
                        if (initialCandidate != null) {
                            val cell = grid[initialCandidate.first][initialCandidate.second]
                            if (!cell.isRevealed && !cell.isFlagged) {
                                pressedCell = initialCandidate
                            }
                        }
                        onPressStateChanged(true)

                        var prevCentroid = downPos
                        var prevDistance = 0f
                        var lastPointerPos = downPos

                        val longPressTimeout = 350L
                        val longPressDeadline = System.currentTimeMillis() + longPressTimeout

                        while (true) {
                            val event = if (!isDragOrPinch && !isLongPressFired) {
                                val remaining = longPressDeadline - System.currentTimeMillis()
                                if (remaining <= 0L) {
                                    isLongPressFired = true
                                    pressedCell = null
                                    onPressStateChanged(false)
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    if (initialCandidate != null) {
                                        onCellLongClick(initialCandidate.first, initialCandidate.second)
                                    }
                                    awaitPointerEvent()
                                } else {
                                    val timedEvent = withTimeoutOrNull(remaining) {
                                        awaitPointerEvent()
                                    }
                                    if (timedEvent == null) {
                                        isLongPressFired = true
                                        pressedCell = null
                                        onPressStateChanged(false)
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        if (initialCandidate != null) {
                                            onCellLongClick(initialCandidate.first, initialCandidate.second)
                                        }
                                        continue
                                    }
                                    timedEvent
                                }
                            } else {
                                awaitPointerEvent()
                            }

                            event.changes.firstOrNull()?.position?.let {
                                lastPointerPos = it
                            }

                            val activePointers = event.changes.filter { it.pressed }
                            if (activePointers.isEmpty()) {
                                break
                            }

                            if (activePointers.size >= 2) {
                                if (!isDragOrPinch) {
                                    isDragOrPinch = true
                                    pressedCell = null
                                    onPressStateChanged(false)
                                }

                                val p1 = activePointers[0]
                                val p2 = activePointers[1]
                                val currentCentroid = (p1.position + p2.position) / 2f
                                val currentDistance = (p1.position - p2.position).getDistance()

                                p1.consume()
                                p2.consume()

                                if (prevDistance > 0f) {
                                    val zoomRatio = currentDistance / prevDistance
                                    val newScale = if (!isZoomLocked) {
                                        (scale * zoomRatio).coerceIn(scaleMin, scaleMax)
                                    } else {
                                        scale
                                    }

                                    // Focal point pinned zoom: keep board point under centroid fixed
                                    val boardPtX = (currentCentroid.x - originX) / scale
                                    val boardPtY = (currentCentroid.y - originY) / scale
                                    val panDeltaX = currentCentroid.x - prevCentroid.x
                                    val panDeltaY = currentCentroid.y - prevCentroid.y

                                    val targetX = currentCentroid.x - boardPtX * newScale + panDeltaX
                                    val targetY = currentCentroid.y - boardPtY * newScale + panDeltaY

                                    val (cx, cy) = clampOrigin(newScale, targetX, targetY)
                                    scale = newScale
                                    originX = cx
                                    originY = cy
                                }

                                prevDistance = currentDistance
                                prevCentroid = currentCentroid
                            } else {
                                val pointer = activePointers[0]
                                val dist = (pointer.position - downPos).getDistance()

                                if (!isDragOrPinch && dist > touchSlop) {
                                    isDragOrPinch = true
                                    pressedCell = null
                                    onPressStateChanged(false)
                                    prevCentroid = pointer.position
                                    prevDistance = 0f
                                }

                                if (isDragOrPinch) {
                                    val pan = pointer.positionChange()
                                    pointer.consume()
                                    val targetX = originX + pan.x
                                    val targetY = originY + pan.y
                                    val (cx, cy) = clampOrigin(scale, targetX, targetY)
                                    originX = cx
                                    originY = cy
                                    prevCentroid = pointer.position
                                    prevDistance = 0f
                                }
                            }
                        }

                        pressedCell = null
                        onPressStateChanged(false)

                        if (!isDragOrPinch && !isLongPressFired && initialCandidate != null) {
                            val upCandidate = getCellAt(lastPointerPos.x, lastPointerPos.y)
                            val dist = (lastPointerPos - downPos).getDistance()
                            if (upCandidate == initialCandidate || dist <= touchSlop) {
                                val now = System.currentTimeMillis()
                                if (chordingTrigger == ChordingTrigger.DOUBLE_TAP &&
                                    lastTapCell == initialCandidate && (now - lastTapTime < 300L)) {
                                    onCellDoubleTap(initialCandidate.first, initialCandidate.second)
                                    lastTapCell = null
                                    lastTapTime = 0L
                                } else {
                                    onCellClick(initialCandidate.first, initialCandidate.second)
                                    lastTapCell = initialCandidate
                                    lastTapTime = now
                                }
                            }
                        }
                    }
                }
        ) {
            val currentCellSize = fitCellSizePx * scale
            val bevel = (currentCellSize * 0.12f).coerceAtLeast(1f)
            val canvasW = size.width
            val canvasH = size.height

            // 1. Draw outer board frame
            val boardW = displayCols * currentCellSize
            val boardH = displayRows * currentCellSize
            drawRect(
                color = theme.cellDark,
                topLeft = Offset(originX - 2f, originY - 2f),
                size = Size(boardW + 4f, boardH + 4f),
                style = Stroke(width = 3.dp.toPx())
            )

            // 2. Viewport culling (draw only visible cells with 1 cell margin)
            val minVisibleCol = (kotlin.math.floor(-originX / currentCellSize).toInt() - 1).coerceIn(0, displayCols - 1)
            val maxVisibleCol = (kotlin.math.ceil((canvasW - originX) / currentCellSize).toInt() + 1).coerceIn(0, displayCols - 1)

            val minVisibleRow = (kotlin.math.floor(-originY / currentCellSize).toInt() - 1).coerceIn(0, displayRows - 1)
            val maxVisibleRow = (kotlin.math.ceil((canvasH - originY) / currentCellSize).toInt() + 1).coerceIn(0, displayRows - 1)

            if (minVisibleRow <= maxVisibleRow && minVisibleCol <= maxVisibleCol) {
                for (dispR in minVisibleRow..maxVisibleRow) {
                    val cellTop = originY + dispR * currentCellSize

                    for (dispC in minVisibleCol..maxVisibleCol) {
                        val cellLeft = originX + dispC * currentCellSize

                    val r = if (isRotated) dispC else dispR
                    val c = if (isRotated) dispR else dispC
                    val cell = grid[r][c]

                    val isCellPressed = (pressedCell?.first == r && pressedCell?.second == c)

                    when {
                        // Exploded mine (hit by player)
                        cell.isRevealed && cell.isExplodedMine -> {
                            drawRect(color = Color(0xFFFF0000), topLeft = Offset(cellLeft, cellTop), size = Size(currentCellSize, currentCellSize))
                            drawGridBorder(theme.pressedEdge, cellLeft, cellTop, currentCellSize, currentCellSize)
                            drawMineAt(theme.mineColor, cellLeft, cellTop, currentCellSize, currentCellSize)
                        }

                        // Revealed regular mine (upon loss)
                        cell.isRevealed && cell.isMine -> {
                            drawRect(color = theme.floor, topLeft = Offset(cellLeft, cellTop), size = Size(currentCellSize, currentCellSize))
                            drawGridBorder(theme.pressedEdge, cellLeft, cellTop, currentCellSize, currentCellSize)
                            drawMineAt(theme.mineColor, cellLeft, cellTop, currentCellSize, currentCellSize)
                        }

                        // Revealed with adjacent numbers
                        cell.isRevealed && cell.adjacentMines > 0 -> {
                            drawRect(color = theme.pressedFace, topLeft = Offset(cellLeft, cellTop), size = Size(currentCellSize, currentCellSize))
                            drawGridBorder(theme.pressedEdge, cellLeft, cellTop, currentCellSize, currentCellSize)

                            val digit = cell.adjacentMines
                            if (digit in 1..8) {
                                val paint = textPaints[digit - 1]
                                paint.textSize = currentCellSize * 0.58f
                                val textY = cellTop + currentCellSize / 2f - (paint.descent() + paint.ascent()) / 2f
                                val textX = cellLeft + currentCellSize / 2f
                                drawContext.canvas.nativeCanvas.drawText(digit.toString(), textX, textY, paint)
                            }
                        }

                        // Revealed empty cell (0 adjacent mines)
                        cell.isRevealed -> {
                            drawRect(color = theme.floor, topLeft = Offset(cellLeft, cellTop), size = Size(currentCellSize, currentCellSize))
                            drawGridBorder(theme.pressedEdge, cellLeft, cellTop, currentCellSize, currentCellSize)
                        }

                        // False flag upon defeat
                        isGameLost && cell.isFlagged && !cell.isMine -> {
                            drawRect(color = theme.floor, topLeft = Offset(cellLeft, cellTop), size = Size(currentCellSize, currentCellSize))
                            drawGridBorder(theme.pressedEdge, cellLeft, cellTop, currentCellSize, currentCellSize)
                            drawFalseFlagAt(theme.mineColor, cellLeft, cellTop, currentCellSize, currentCellSize)
                        }

                        // Flagged cell (over unrevealed beveled tile)
                        cell.isFlagged -> {
                            drawBeveledCellAt(theme, cellLeft, cellTop, currentCellSize, currentCellSize, bevel)
                            drawFlagAt(theme.flagColor, theme.flagStand, cellLeft, cellTop, currentCellSize, currentCellSize)
                        }

                        // Pressed state before reveal
                        isCellPressed -> {
                            drawRect(color = theme.pressedFace, topLeft = Offset(cellLeft, cellTop), size = Size(currentCellSize, currentCellSize))
                            drawGridBorder(theme.pressedEdge, cellLeft, cellTop, currentCellSize, currentCellSize)
                        }

                        // Normal unrevealed tile
                        else -> {
                            drawBeveledCellAt(theme, cellLeft, cellTop, currentCellSize, currentCellSize, bevel)
                        }
                    }

                    // Pulsing hint highlight
                    if (cell.isHinted) {
                        drawRect(
                            color = Color(0xFFFFD700).copy(alpha = hintAlpha),
                            topLeft = Offset(cellLeft, cellTop),
                            size = Size(currentCellSize, currentCellSize),
                            style = Stroke(width = maxOf(2f, currentCellSize * 0.08f))
                        )
                    }
                }
            }
        }
    }
}
}

/**
 * Draws the classic Windows 3D beveled button with 12% bevel thickness at specified offset.
 */
fun DrawScope.drawBeveledCellAt(theme: MinesweeperTheme, x: Float, y: Float, w: Float, h: Float, bevel: Float) {
    val topPath = Path().apply {
        moveTo(x, y)
        lineTo(x + w, y)
        lineTo(x + w - bevel, y + bevel)
        lineTo(x + bevel, y + bevel)
        close()
    }
    drawPath(topPath, color = theme.cellLight)

    val leftPath = Path().apply {
        moveTo(x, y)
        lineTo(x + bevel, y + bevel)
        lineTo(x + bevel, y + h - bevel)
        lineTo(x, y + h)
        close()
    }
    drawPath(leftPath, color = theme.cellLight)

    val bottomPath = Path().apply {
        moveTo(x, y + h)
        lineTo(x + bevel, y + h - bevel)
        lineTo(x + w - bevel, y + h - bevel)
        lineTo(x + w, y + h)
        close()
    }
    drawPath(bottomPath, color = theme.cellDark)

    val rightPath = Path().apply {
        moveTo(x + w, y)
        lineTo(x + w, y + h)
        lineTo(x + w - bevel, y + h - bevel)
        lineTo(x + w - bevel, y + bevel)
        close()
    }
    drawPath(rightPath, color = theme.cellDark)

    drawRect(
        color = theme.cellFace,
        topLeft = Offset(x + bevel, y + bevel),
        size = Size(w - 2 * bevel, h - 2 * bevel)
    )
}

fun DrawScope.drawGridBorder(color: Color, x: Float, y: Float, w: Float, h: Float) {
    drawRect(color = color, topLeft = Offset(x, y), size = Size(w, h), style = Stroke(width = 1f))
}

fun DrawScope.drawMineAt(mineColor: Color, x: Float, y: Float, w: Float, h: Float) {
    val cx = x + w / 2f
    val cy = y + h / 2f
    val r = w * 0.28f
    val spikeLen = r * 1.55f
    val stroke = (r * 0.35f).coerceAtLeast(1.5f)

    drawLine(mineColor, Offset(cx - spikeLen, cy), Offset(cx + spikeLen, cy), strokeWidth = stroke)
    drawLine(mineColor, Offset(cx, cy - spikeLen), Offset(cx, cy + spikeLen), strokeWidth = stroke)
    val diag = spikeLen * 0.7071f
    drawLine(mineColor, Offset(cx - diag, cy - diag), Offset(cx + diag, cy + diag), strokeWidth = stroke)
    drawLine(mineColor, Offset(cx - diag, cy + diag), Offset(cx + diag, cy - diag), strokeWidth = stroke)

    drawCircle(mineColor, radius = r, center = Offset(cx, cy))
    val glintRadius = (r * 0.25f).coerceAtLeast(1f)
    drawCircle(Color.White, radius = glintRadius, center = Offset(cx - r * 0.35f, cy - r * 0.35f))
}

fun DrawScope.drawFlagAt(flagColor: Color, flagStand: Color, x: Float, y: Float, w: Float, h: Float) {
    val cx = x + w / 2f
    val cy = y + h / 2f
    val poleStroke = (w * 0.08f).coerceAtLeast(1.5f)
    val poleX = cx - w * 0.08f
    val topY = cy - h * 0.30f
    val baseY = cy + h * 0.32f

    val baseHalf = w * 0.22f
    drawLine(color = flagStand, start = Offset(poleX - baseHalf, baseY), end = Offset(poleX + baseHalf, baseY), strokeWidth = poleStroke * 1.3f)
    drawLine(color = flagStand, start = Offset(poleX, topY), end = Offset(poleX, baseY), strokeWidth = poleStroke)

    val flagPath = Path().apply {
        moveTo(poleX, topY)
        lineTo(poleX + w * 0.36f, topY + (h * 0.30f) / 2f)
        lineTo(poleX, topY + h * 0.30f)
        close()
    }
    drawPath(flagPath, color = flagColor)
}

fun DrawScope.drawFalseFlagAt(mineColor: Color, x: Float, y: Float, w: Float, h: Float) {
    drawMineAt(mineColor, x, y, w, h)
    val pad = w * 0.16f
    val xStroke = (w * 0.12f).coerceAtLeast(2f)
    drawLine(Color(0xFFFF0000), Offset(x + pad, y + pad), Offset(x + w - pad, y + h - pad), strokeWidth = xStroke)
    drawLine(Color(0xFFFF0000), Offset(x + w - pad, y + pad), Offset(x + pad, y + h - pad), strokeWidth = xStroke)
}

// 0-offset variants for ThemesScreen preview compatibility
fun DrawScope.drawBeveledCell(theme: MinesweeperTheme, w: Float, h: Float, bevel: Float) {
    drawBeveledCellAt(theme, 0f, 0f, w, h, bevel)
}

fun DrawScope.drawGridBorder(color: Color, w: Float, h: Float) {
    drawRect(color = color, topLeft = Offset(0f, 0f), size = Size(w, h), style = Stroke(width = 1f))
}

fun DrawScope.drawMine(mineColor: Color, w: Float, h: Float) {
    drawMineAt(mineColor, 0f, 0f, w, h)
}

fun DrawScope.drawFlag(flagColor: Color, flagStand: Color, w: Float, h: Float) {
    drawFlagAt(flagColor, flagStand, 0f, 0f, w, h)
}

fun DrawScope.drawFalseFlag(mineColor: Color, w: Float, h: Float) {
    drawFalseFlagAt(mineColor, 0f, 0f, w, h)
}

