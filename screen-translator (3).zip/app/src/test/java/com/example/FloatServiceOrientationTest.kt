package com.example

import android.graphics.Point
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FloatServiceOrientationTest {

    @Test
    fun testOrientationPointDetection() {
        // Portrait mode: width < height
        val portraitPoint = Point(1080, 2400)
        val isPortrait = portraitPoint.x < portraitPoint.y
        assertTrue("Point with x < y must be recognized as Portrait", isPortrait)

        // Landscape mode: width > height
        val landscapePoint = Point(2400, 1080)
        val isLandscapePortrait = landscapePoint.x < landscapePoint.y
        assertFalse("Point with x > y must be recognized as Landscape", isLandscapePortrait)
    }

    @Test
    fun testClampingWithinPointBoundaries() {
        val screenPoint = Point(1080, 2400)
        val bubbleSize = 160 // in px

        val maxX = (screenPoint.x - bubbleSize).coerceAtLeast(0)
        val maxY = (screenPoint.y - bubbleSize).coerceAtLeast(0)

        assertEquals(920, maxX)
        assertEquals(2240, maxY)

        // Test coordinates out of bounds clamped to boundaries
        val testXNegative = -50
        val testXTooLarge = 1500
        val clampedX1 = testXNegative.coerceIn(0, maxX)
        val clampedX2 = testXTooLarge.coerceIn(0, maxX)

        assertEquals(0, clampedX1)
        assertEquals(maxX, clampedX2)
    }

    @Test
    fun testCoordinateScalingCalculations() {
        // Test portrait scaling: view width 1080, bitmap width 1080 -> scale 1.0
        val viewW = 1080f
        val viewH = 2400f
        val bmpW = 1080f
        val bmpH = 2400f

        val scaleX = viewW / bmpW
        val scaleY = viewH / bmpH

        assertEquals(1.0f, scaleX, 0.001f)
        assertEquals(1.0f, scaleY, 0.001f)

        // Test scaling when bitmap size differs (e.g. downscaled bitmap or rotation)
        val landscapeViewW = 2400f
        val landscapeViewH = 1080f
        val capturedBmpW = 1200f
        val capturedBmpH = 540f

        val lScaleX = landscapeViewW / capturedBmpW
        val lScaleY = landscapeViewH / capturedBmpH

        assertEquals(2.0f, lScaleX, 0.001f)
        assertEquals(2.0f, lScaleY, 0.001f)

        // Box scaling: (100, 200, 300, 250) -> scaled (200, 400, 600, 500)
        val originalLeft = 100f
        val originalTop = 200f
        val originalRight = 300f
        val originalBottom = 250f

        val scaledLeft = originalLeft * lScaleX
        val scaledTop = originalTop * lScaleY
        val scaledRight = originalRight * lScaleX
        val scaledBottom = originalBottom * lScaleY

        assertEquals(200f, scaledLeft, 0.001f)
        assertEquals(400f, scaledTop, 0.001f)
        assertEquals(600f, scaledRight, 0.001f)
        assertEquals(500f, scaledBottom, 0.001f)
    }
}
