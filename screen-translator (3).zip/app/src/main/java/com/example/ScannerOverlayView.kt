package com.example

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Point
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.AttributeSet
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.animation.AccelerateDecelerateInterpolator

/**
 * Custom View matching AutoCropView architecture from Bubble Translate.
 * Performs in-place text translation directly over detected screen bounding boxes.
 * Features 1:1 pixel coordinate scaling and full screen zero-offset alignment.
 */
class ScannerOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    data class TranslationItem(
        val originalBoundingBox: Rect,
        val originalText: String,
        var translatedText: String = "",
        val clampedRectF: RectF = RectF()
    )

    var onDismissListener: (() -> Unit)? = null

    // 1. Paints matching the original architecture:
    // strokePaint: orange #FFA800, STROKE, width 1.5dp, CornerPathEffect, StrokeCap.ROUND
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFA800")
        style = Paint.Style.STROKE
        strokeWidth = dpToPx(1.5f)
        strokeCap = Paint.Cap.ROUND
        pathEffect = CornerPathEffect(dpToPx(6f))
    }

    // bgPaint: semi-transparent black screen dimming (Alpha 51 / #33000000)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33000000") // 20% alpha
        style = Paint.Style.FILL
    }

    // clearPaint: hole punch over detected text using PorterDuff.Mode.CLEAR
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    // Paint for solid translation card background (covering original foreign text)
    private val textCardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E60F172A") // 90% solid dark slate
        style = Paint.Style.FILL
        pathEffect = CornerPathEffect(dpToPx(6f))
    }

    // TextPaint for translated text
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = spToPx(13f)
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    // Close tip paint
    private val tipPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFA800")
        textSize = spToPx(12f)
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val tipBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC1E293B")
        style = Paint.Style.FILL
        pathEffect = CornerPathEffect(dpToPx(12f))
    }

    private val items = mutableListOf<TranslationItem>()
    private var screenDimensions = Point()

    // 2. Scanning animation: ValueAnimator 0f -> 1f, 300ms, AccelerateDecelerateInterpolator
    private var animProgress = 0f
    private val scanAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 300L
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener { animator ->
            animProgress = animator.animatedValue as Float
            invalidate()
        }
    }

    init {
        // Enable hardware layer for PorterDuff.Mode.CLEAR support
        setLayerType(LAYER_TYPE_HARDWARE, null)
        // Offset fix: Start from absolute screen edge (0,0) without status bar inset
        fitsSystemWindows = false
    }

    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        // Offset fix: Do not add padding/inset so drawing matches absolute (0,0) of MediaProjection
        return insets
    }

    /**
     * Requirement: Coordinate Scaling & Offset Fix.
     * Receives the exact bitmap dimensions and calculates scaleX and scaleY dynamically.
     * Multiplies bounding box coordinates by scale factors so rectangles align 1:1 with screen text.
     */
    fun updateData(
        newItems: List<TranslationItem>,
        realScreenPoint: Point,
        bitmapWidth: Int,
        bitmapHeight: Int
    ) {
        screenDimensions.set(realScreenPoint.x, realScreenPoint.y)

        // Manual orientation comparison
        val isPortrait = screenDimensions.x < screenDimensions.y

        // Determine view target width and height (from view or physical screen point)
        val targetWidth = if (width > 0) width.toFloat() else screenDimensions.x.toFloat()
        val targetHeight = if (height > 0) height.toFloat() else screenDimensions.y.toFloat()

        // Calculate dynamic scaling factors
        val scaleX = if (bitmapWidth > 0) targetWidth / bitmapWidth.toFloat() else 1f
        val scaleY = if (bitmapHeight > 0) targetHeight / bitmapHeight.toFloat() else 1f

        items.clear()
        for (item in newItems) {
            val box = item.originalBoundingBox

            // Apply scaling to bounding box coordinates
            val scaledLeft = (box.left * scaleX).coerceIn(0f, targetWidth)
            val scaledTop = (box.top * scaleY).coerceIn(0f, targetHeight)
            val scaledRight = (box.right * scaleX).coerceIn(0f, targetWidth)
            val scaledBottom = (box.bottom * scaleY).coerceIn(0f, targetHeight)

            if (scaledRight > scaledLeft && scaledBottom > scaledTop) {
                // Add comfortable reading padding around bounding box
                val padX = dpToPx(3f)
                val padY = dpToPx(2f)
                item.clampedRectF.set(
                    (scaledLeft - padX).coerceAtLeast(0f),
                    (scaledTop - padY).coerceAtLeast(0f),
                    (scaledRight + padX).coerceAtMost(targetWidth),
                    (scaledBottom + padY).coerceAtMost(targetHeight)
                )
                items.add(item)
            }
        }

        // Start 300ms expand/scan animation
        scanAnimator.cancel()
        animProgress = 0f
        scanAnimator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Save layer for clearPaint PorterDuff mode
        val layerId = canvas.saveLayer(0f, 0f, w, h, null)

        // Draw semi-transparent dimming background (#33000000)
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // Draw each in-place translation bounding box
        for (item in items) {
            val fullRect = item.clampedRectF
            val cx = fullRect.centerX()
            val cy = fullRect.centerY()

            val currentLeft = cx + (fullRect.left - cx) * animProgress
            val currentTop = cy + (fullRect.top - cy) * animProgress
            val currentRight = cx + (fullRect.right - cx) * animProgress
            val currentBottom = cy + (fullRect.bottom - cy) * animProgress
            val animatedRect = RectF(currentLeft, currentTop, currentRight, currentBottom)

            // 1. Hole punch over original text using clearPaint
            canvas.drawRect(animatedRect, clearPaint)

            // 2. Solid card replacing original text
            canvas.drawRect(animatedRect, textCardBgPaint)

            // 3. Orange boundary (#FFA800, 1.5dp, CornerPathEffect)
            canvas.drawRect(animatedRect, strokePaint)

            // 4. In-place translated text
            val displayTxt = if (item.translatedText.isNotBlank()) item.translatedText else item.originalText
            if (animProgress >= 0.5f && displayTxt.isNotBlank() && animatedRect.width() > dpToPx(20f)) {
                drawWrappedText(canvas, displayTxt, animatedRect)
            }
        }

        canvas.restoreToCount(layerId)

        // Top dismiss hint badge
        drawDismissTip(canvas, w)
    }

    private fun drawWrappedText(canvas: Canvas, text: String, rect: RectF) {
        val availableWidth = (rect.width() - dpToPx(8f)).toInt().coerceAtLeast(10)

        val targetSize = when {
            rect.height() < dpToPx(24f) -> spToPx(10f)
            rect.height() < dpToPx(38f) -> spToPx(12f)
            else -> spToPx(13.5f)
        }
        textPaint.textSize = targetSize

        val staticLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, textPaint, availableWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.05f)
                .setIncludePad(false)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, textPaint, availableWidth, Layout.Alignment.ALIGN_NORMAL, 1.05f, 0f, false)
        }

        canvas.save()
        val textY = rect.top + dpToPx(3f)
        val textX = rect.left + dpToPx(4f)
        canvas.translate(textX, textY)
        staticLayout.draw(canvas)
        canvas.restore()
    }

    private fun drawDismissTip(canvas: Canvas, screenWidth: Float) {
        val tipText = "انقر في أي مكان للإغلاق • Tap anywhere to dismiss"
        val tipWidth = tipPaint.measureText(tipText) + dpToPx(32f)
        val tipHeight = dpToPx(32f)
        val tipLeft = (screenWidth - tipWidth) / 2f
        val tipTop = dpToPx(36f)
        val tipRect = RectF(tipLeft, tipTop, tipLeft + tipWidth, tipTop + tipHeight)

        canvas.drawRect(tipRect, tipBgPaint)
        canvas.drawRect(tipRect, strokePaint)
        canvas.drawText(
            tipText,
            screenWidth / 2f,
            tipTop + tipHeight / 2f + dpToPx(4f),
            tipPaint
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            onDismissListener?.invoke()
            return true
        }
        return true
    }

    private fun dpToPx(dp: Float): Float {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)
    }

    private fun spToPx(sp: Float): Float {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)
    }
}
