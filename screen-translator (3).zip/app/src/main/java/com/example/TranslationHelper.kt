package com.example

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

object TranslationHelper {
    private const val TAG = "TranslationHelper"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    fun initTts(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                isTtsReady = (status == TextToSpeech.SUCCESS)
            }
        }
    }

    fun speak(text: String, langCode: String) {
        if (!isTtsReady || tts == null || text.isBlank()) return
        val locale = when (langCode.lowercase()) {
            "ar" -> Locale("ar")
            "en" -> Locale.ENGLISH
            "fr" -> Locale.FRENCH
            "es" -> Locale("es")
            "de" -> Locale.GERMAN
            "tr" -> Locale("tr")
            else -> Locale.getDefault()
        }
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tts_id_${System.currentTimeMillis()}")
    }

    fun shutdownTts() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isTtsReady = false
    }

    /**
     * Translates text using fast online translation API with offline dictionary fallback.
     */
    suspend fun translateText(
        text: String,
        sourceLang: String = "auto",
        targetLang: String = "ar"
    ): String = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return@withContext ""

        try {
            val encodedQuery = URLEncoder.encode(trimmed, "UTF-8")
            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sourceLang&tl=$targetLang&dt=t&q=$encodedQuery"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0")
                .build()

            val response = httpClient.newCall(request).execute()
            if (response.isSuccessful) {
                val responseBody = response.body?.string()
                if (!responseBody.isNullOrEmpty()) {
                    val jsonArray = JSONArray(responseBody)
                    val sentences = jsonArray.getJSONArray(0)
                    val resultBuilder = StringBuilder()
                    for (i in 0 until sentences.length()) {
                        val part = sentences.getJSONArray(i).getString(0)
                        resultBuilder.append(part)
                    }
                    val translated = resultBuilder.toString().trim()
                    if (translated.isNotEmpty()) {
                        return@withContext translated
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Online translation failed, using fallback: ${e.message}")
        }

        // Offline fallback dictionary for common words and phrases
        return@withContext getOfflineTranslationFallback(trimmed, targetLang)
    }

    private fun getOfflineTranslationFallback(text: String, targetLang: String): String {
        val lower = text.lowercase()
        val isArabicTarget = targetLang.lowercase().startsWith("ar")

        // Offline mapping of popular UI, gaming, and app words
        val dictEnToAr = mapOf(
            "hello" to "مرحباً",
            "welcome" to "أهلاً بك",
            "settings" to "الإعدادات",
            "home" to "الرئيسية",
            "search" to "بحث",
            "profile" to "الملف الشخصي",
            "cancel" to "إلغاء",
            "ok" to "موافق",
            "done" to "تم",
            "save" to "حفظ",
            "delete" to "حذف",
            "edit" to "تعديل",
            "share" to "مشاركة",
            "copy" to "نسخ",
            "close" to "إغلاق",
            "back" to "رجوع",
            "next" to "التالي",
            "start" to "بدء",
            "stop" to "إيقاف",
            "loading" to "جارِ التحميل",
            "error" to "خطأ",
            "success" to "نجاح",
            "language" to "اللغة",
            "game over" to "انتهت اللعبة",
            "level" to "المستوى",
            "score" to "النقاط",
            "play" to "لعب",
            "pause" to "إيقاف مؤقت",
            "resume" to "استئناف",
            "restart" to "إعادة تشغيل",
            "message" to "رسالة",
            "messages" to "الرسائل",
            "notification" to "إشعار",
            "notifications" to "الإشعارات",
            "download" to "تنزيل",
            "upload" to "رفع",
            "update" to "تحديث",
            "translate" to "ترجمة",
            "screen translator" to "مترجم الشاشة"
        )

        val dictArToEn = mapOf(
            "مرحبا" to "Hello",
            "مرحباً" to "Hello",
            "أهلاً" to "Welcome",
            "إعدادات" to "Settings",
            "الإعدادات" to "Settings",
            "الرئيسية" to "Home",
            "بحث" to "Search",
            "إلغاء" to "Cancel",
            "موافق" to "OK",
            "تم" to "Done",
            "حفظ" to "Save",
            "حذف" to "Delete",
            "تعديل" to "Edit",
            "مشاركة" to "Share",
            "نسخ" to "Copy",
            "إغلاق" to "Close",
            "رجوع" to "Back",
            "التالي" to "Next",
            "بدء" to "Start",
            "إيقاف" to "Stop"
        )

        if (isArabicTarget) {
            dictEnToAr[lower]?.let { return it }
            // Try word by word replacement
            val words = text.split(" ")
            val translatedWords = words.map { word ->
                dictEnToAr[word.lowercase().trim('?', '!', '.', ',')] ?: word
            }
            if (translatedWords != words) {
                return translatedWords.joinToString(" ")
            }
            return "[ترجمة أوفلاين]: $text"
        } else {
            dictArToEn[lower]?.let { return it }
            return "[Offline Translation]: $text"
        }
    }
}
