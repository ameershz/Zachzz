package com.example

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed class ModelDownloadStatus {
    object Idle : ModelDownloadStatus()
    object Checking : ModelDownloadStatus()
    data class Downloading(val message: String) : ModelDownloadStatus()
    data class Ready(val message: String = "حزم الترجمة جاهزة للعمل دون اتصال") : ModelDownloadStatus()
    data class Error(val message: String) : ModelDownloadStatus()
}

/**
 * High-performance on-device translation powered by Google ML Kit Translate.
 * All translations run entirely on-device for ultra-low latency and total privacy.
 */
object TranslationHelper {
    private const val TAG = "TranslationHelper"

    private val helperScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val translators = ConcurrentHashMap<String, Translator>()

    private val _downloadStatus = MutableStateFlow<ModelDownloadStatus>(ModelDownloadStatus.Idle)
    val downloadStatus: StateFlow<ModelDownloadStatus> = _downloadStatus.asStateFlow()

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    fun initTts(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext) { status ->
                isTtsReady = (status == TextToSpeech.SUCCESS)
            }
        }
    }

    fun speak(text: String, langCode: String) {
        if (!isTtsReady || tts == null || text.isBlank()) return
        val locale = when (langCode.lowercase()) {
            "ar" -> Locale("ar")
            "en" -> Locale.ENGLISH
            "fr" -> Locale.FRENCH
            "es" -> Locale("es")
            "de" -> Locale.GERMAN
            "tr" -> Locale("tr")
            else -> Locale.getDefault()
        }
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tts_id_${System.currentTimeMillis()}")
    }

    fun shutdownTts() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isTtsReady = false
    }

    /**
     * Maps language codes to ML Kit Translate BCP-47 codes.
     */
    fun mapToMlKitLang(code: String, isSource: Boolean = false): String {
        val clean = code.lowercase().trim()
        if (clean == "auto" || clean.isEmpty()) {
            return TranslateLanguage.ENGLISH
        }
        return when (clean) {
            "ar", "arabic" -> TranslateLanguage.ARABIC
            "en", "english" -> TranslateLanguage.ENGLISH
            "fr", "french" -> TranslateLanguage.FRENCH
            "es", "spanish" -> TranslateLanguage.SPANISH
            "de", "german" -> TranslateLanguage.GERMAN
            "tr", "turkish" -> TranslateLanguage.TURKISH
            else -> TranslateLanguage.fromLanguageTag(clean)
                ?: if (isSource) TranslateLanguage.ENGLISH else TranslateLanguage.ARABIC
        }
    }

    private fun getOrCreateTranslator(srcLang: String, tgtLang: String): Translator {
        val key = "$srcLang-$tgtLang"
        return translators.getOrPut(key) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(srcLang)
                .setTargetLanguage(tgtLang)
                .build()
            Translation.getClient(options)
        }
    }

    suspend fun isModelDownloaded(langCode: String): Boolean {
        return try {
            val model = TranslateRemoteModel.Builder(langCode).build()
            RemoteModelManager.getInstance().isModelDownloaded(model).awaitTask()
        } catch (e: Exception) {
            Log.w(TAG, "isModelDownloaded check failed for $langCode: ${e.message}")
            false
        }
    }

    /**
     * Initializes and downloads English and Arabic language packs upon first launch.
     * Notifies user that downloading is done once and requires internet connection.
     */
    fun initAndDownloadModels(context: Context? = null, force: Boolean = false) {
        helperScope.launch {
            _downloadStatus.value = ModelDownloadStatus.Checking

            val enDownloaded = isModelDownloaded(TranslateLanguage.ENGLISH)
            val arDownloaded = isModelDownloaded(TranslateLanguage.ARABIC)

            if (enDownloaded && arDownloaded && !force) {
                _downloadStatus.value = ModelDownloadStatus.Ready(
                    "حزم الترجمة الأوفلاين جاهزة ومحمّلة بالكامل على جهازك (الإنجليزية والعربية)"
                )
                return@launch
            }

            _downloadStatus.value = ModelDownloadStatus.Downloading(
                "جاري تحميل حزمتي الإنجليزية والعربية... (يتم لمرة واحدة فقط ويحتاج إنترنت)"
            )

            try {
                val translator = getOrCreateTranslator(TranslateLanguage.ENGLISH, TranslateLanguage.ARABIC)
                val conditions = DownloadConditions.Builder().build()
                translator.downloadModelIfNeeded(conditions).awaitTask()

                _downloadStatus.value = ModelDownloadStatus.Ready(
                    "تم تحميل حزم الترجمة بنجاح! أصبحت الترجمة الفورية تعمل بالكامل دون اتصال بالإنترنت"
                )
            } catch (e: Exception) {
                Log.e(TAG, "Failed downloading language models: ${e.message}", e)
                _downloadStatus.value = ModelDownloadStatus.Error(
                    "تعذر تحميل حزمة اللغة: يرجى التحقق من اتصال الإنترنت والمحاولة مجدداً"
                )
            }
        }
    }

    /**
     * Translates text using Google ML Kit On-Device Translator.
     * If the language model is not yet downloaded, initiates download and returns
     * "جاري تحميل حزمة اللغة..." as required.
     */
    suspend fun translateText(
        text: String,
        sourceLang: String = "auto",
        targetLang: String = "ar"
    ): String = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return@withContext ""

        val srcCode = mapToMlKitLang(sourceLang, isSource = true)
        val tgtCode = mapToMlKitLang(targetLang, isSource = false)

        val isSrcDownloaded = isModelDownloaded(srcCode)
        val isTgtDownloaded = isModelDownloaded(tgtCode)

        if (!isSrcDownloaded || !isTgtDownloaded) {
            // Trigger download if not already downloading
            if (_downloadStatus.value !is ModelDownloadStatus.Downloading) {
                initAndDownloadModels()
            }
            return@withContext "جاري تحميل حزمة اللغة..."
        }

        try {
            val translator = getOrCreateTranslator(srcCode, tgtCode)
            val translated = translator.translate(trimmed).awaitTask()
            if (translated.isNotBlank()) {
                translated
            } else {
                trimmed
            }
        } catch (e: Exception) {
            Log.e(TAG, "ML Kit translation failed: ${e.message}", e)
            if (_downloadStatus.value is ModelDownloadStatus.Downloading) {
                "جاري تحميل حزمة اللغة..."
            } else {
                initAndDownloadModels()
                "جاري تحميل حزمة اللغة..."
            }
        }
    }

    fun shutdown() {
        shutdownTts()
        for ((_, translator) in translators) {
            try {
                translator.close()
            } catch (e: Exception) {
                Log.e(TAG, "Error closing translator: ${e.message}")
            }
        }
        translators.clear()
    }
}

/**
 * Extension function to safely await Google Play Services / ML Kit Task in Coroutines
 */
private suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { cont ->
    addOnSuccessListener { result ->
        if (cont.isActive) cont.resume(result)
    }
    addOnFailureListener { exception ->
        if (cont.isActive) cont.resumeWithException(exception)
    }
    addOnCanceledListener {
        if (cont.isActive) cont.cancel()
    }
}
