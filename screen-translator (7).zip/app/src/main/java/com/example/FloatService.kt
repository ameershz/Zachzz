package com.example

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FloatService : Service() {

    companion object {
        private const val TAG = "FloatService"
        const val CHANNEL_ID = "screen_translator_channel"
        const val NOTIFICATION_ID = 1001

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_TARGET_LANG = "extra_target_lang"
        const val EXTRA_SOURCE_LANG = "extra_source_lang"
        const val ACTION_STOP_SERVICE = "com.example.ACTION_STOP_SERVICE"

        var isRunning = false
            private set
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var windowManager: WindowManager
    private lateinit var mediaProjectionManager: MediaProjectionManager

    // Media Projection and screen capture
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var mediaProjectionCallback: MediaProjection.Callback? = null

    // Floating bubble UI
    private var bubbleView: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var isBubbleAttached = false

    // Real in-place TextView translation overlay manager
    private lateinit var translationOverlayManager: TranslationOverlayManager

    // Text recognition & translation
    private val textRecognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var sourceLang = "auto"
    private var targetLang = "ar"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        translationOverlayManager = TranslationOverlayManager(this, windowManager)

        TranslationHelper.initTts(this)
        createNotificationChannel()
        initBubbleLayoutParams()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }

        intent?.getStringExtra(EXTRA_SOURCE_LANG)?.let { sourceLang = it }
        intent?.getStringExtra(EXTRA_TARGET_LANG)?.let { targetLang = it }

        startForegroundServiceNotification()

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData: Intent? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                    ?: @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
            } else {
                @Suppress("DEPRECATION")
                intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error unmarshalling resultData: ${e.message}")
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
        }

        if (resultCode != 0 && resultData != null && mediaProjection == null) {
            setupMediaProjection(resultCode, resultData)
        }

        if (!isBubbleAttached) {
            createFloatingBubble()
        } else {
            updateBubbleLanguageBadge()
        }

        return START_STICKY
    }

    /**
     * Requirement 1: Orientation Fix using Point(x, y).
     */
    fun getRealScreenDimensions(): Point {
        val point = Point()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.maximumWindowMetrics
            val bounds = windowMetrics.bounds
            point.x = bounds.width()
            point.y = bounds.height()
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealSize(point)
        }
        return point
    }

    private fun updateScreenBoundsAndClamping(autoSnapToEdge: Boolean = false) {
        val point = getRealScreenDimensions()

        // Manual comparison: if (x < y)
        val isPortrait = point.x < point.y
        val screenWidth = point.x
        val screenHeight = point.y

        val bubbleW = bubbleView?.width?.takeIf { it > 0 } ?: dpToPx(64)
        val bubbleH = bubbleView?.height?.takeIf { it > 0 } ?: dpToPx(64)

        val maxX = (screenWidth - bubbleW).coerceAtLeast(0)
        val maxY = (screenHeight - bubbleH).coerceAtLeast(0)

        if (autoSnapToEdge) {
            val midX = screenWidth / 2
            bubbleParams.x = if (bubbleParams.x < midX) 0 else maxX
        } else {
            bubbleParams.x = bubbleParams.x.coerceIn(0, maxX)
        }
        bubbleParams.y = bubbleParams.y.coerceIn(0, maxY)

        if (isBubbleAttached && bubbleView != null) {
            try {
                windowManager.updateViewLayout(bubbleView, bubbleParams)
            } catch (e: Exception) {
                Log.e(TAG, "Failed updating bubble layout bounds: ${e.message}")
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        mainHandler.postDelayed({
            updateScreenBoundsAndClamping(autoSnapToEdge = true)
            setupVirtualDisplay()
            if (::translationOverlayManager.isInitialized && translationOverlayManager.isShowing) {
                translationOverlayManager.clear()
            }
        }, 150)
    }

    private fun startForegroundServiceNotification() {
        val stopIntent = Intent(this, FloatService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_bubble_translate)
            .setContentIntent(openAppPendingIntent)
            .addAction(R.drawable.ic_close_vector, getString(R.string.notification_stop), stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun setupMediaProjection(resultCode: Int, resultData: Intent) {
        try {
            mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, resultData)
            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.w(TAG, "MediaProjection stopped by system")
                    cleanUpMediaProjection()
                }
            }
            mediaProjectionCallback = callback
            mediaProjection?.registerCallback(callback, mainHandler)
            setupVirtualDisplay()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize MediaProjection: ${e.message}", e)
        }
    }

    private fun setupVirtualDisplay() {
        if (mediaProjection == null) return

        val point = getRealScreenDimensions()
        val width = point.x
        val height = point.y
        val density = resources.displayMetrics.densityDpi

        try {
            imageReader?.close()
            virtualDisplay?.release()

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "FloatServiceVirtualDisplay",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up VirtualDisplay: ${e.message}")
        }
    }

    private fun initBubbleLayoutParams() {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val point = getRealScreenDimensions()
            x = point.x - dpToPx(72)
            y = (point.y * 0.35f).toInt()
        }
    }

    private fun createFloatingBubble() {
        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.layout_floating_bubble, null)

        val root = bubbleView?.findViewById<View>(R.id.bubble_root)
        updateBubbleLanguageBadge()

        var initialTouchX = 0f
        var initialTouchY = 0f
        var initialWindowX = 0
        var initialWindowY = 0
        var isDragging = false
        var touchDownTime = 0L
        val clickThresholdMs = 260L
        val moveThresholdPx = 14f

        root?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    initialWindowX = bubbleParams.x
                    initialWindowY = bubbleParams.y
                    touchDownTime = System.currentTimeMillis()
                    isDragging = false
                    view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(100).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY

                    if (Math.hypot(dx.toDouble(), dy.toDouble()) > moveThresholdPx) {
                        isDragging = true
                    }

                    val point = getRealScreenDimensions()
                    val bubbleW = view.width.takeIf { it > 0 } ?: dpToPx(64)
                    val bubbleH = view.height.takeIf { it > 0 } ?: dpToPx(64)
                    val maxX = (point.x - bubbleW).coerceAtLeast(0)
                    val maxY = (point.y - bubbleH).coerceAtLeast(0)

                    bubbleParams.x = (initialWindowX + dx).toInt().coerceIn(0, maxX)
                    bubbleParams.y = (initialWindowY + dy).toInt().coerceIn(0, maxY)

                    if (isBubbleAttached) {
                        windowManager.updateViewLayout(bubbleView, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(120).start()
                    val clickDuration = System.currentTimeMillis() - touchDownTime
                    val totalDistance = Math.hypot((event.rawX - initialTouchX).toDouble(), (event.rawY - initialTouchY).toDouble())

                    if (!isDragging && clickDuration < clickThresholdMs && totalDistance < moveThresholdPx) {
                        view.performClick()
                        onBubbleClicked()
                    } else {
                        val point = getRealScreenDimensions()
                        val bubbleW = view.width.takeIf { it > 0 } ?: dpToPx(64)
                        val maxX = (point.x - bubbleW).coerceAtLeast(0)
                        val snapToRight = bubbleParams.x > (point.x / 2)
                        val targetX = if (snapToRight) maxX else 0

                        animateBubbleSnap(bubbleParams.x, targetX)
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(bubbleView, bubbleParams)
            isBubbleAttached = true
            updateScreenBoundsAndClamping(autoSnapToEdge = true)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding bubble view: ${e.message}")
        }
    }

    private fun animateBubbleSnap(startX: Int, endX: Int) {
        val animator = ValueAnimator.ofInt(startX, endX)
        animator.duration = 200
        animator.interpolator = DecelerateInterpolator()
        animator.addUpdateListener { animation ->
            bubbleParams.x = animation.animatedValue as Int
            if (isBubbleAttached && bubbleView != null) {
                try {
                    windowManager.updateViewLayout(bubbleView, bubbleParams)
                } catch (e: Exception) {
                    Log.e(TAG, "Error updating during snap animation: ${e.message}")
                }
            }
        }
        animator.start()
    }

    private fun updateBubbleLanguageBadge() {
        val badge = bubbleView?.findViewById<TextView>(R.id.bubble_lang_badge)
        badge?.text = targetLang.uppercase()
    }

    /**
     * Requirement: Screen Capture & In-place Overlay Toggle
     */
    private fun onBubbleClicked() {
        if (mediaProjection == null) {
            Toast.makeText(this, "يرجى منح إذن التقاط الشاشة من التطبيق أولاً", Toast.LENGTH_LONG).show()
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            return
        }

        // Toggle: If translations are currently showing on screen, tapping the bubble dismisses them!
        if (::translationOverlayManager.isInitialized && translationOverlayManager.isShowing) {
            translationOverlayManager.clear()
            Toast.makeText(this, "تم إخفاء الترجمة", Toast.LENGTH_SHORT).show()
            return
        }

        serviceScope.launch {
            try {
                setBubbleScanningState(true)

                // 1. Temporarily hide bubble so it is not visible in screenshot
                bubbleView?.visibility = View.INVISIBLE
                delay(120) // wait for frame refresh without bubble

                // 2. Capture screenshot safely from ImageReader
                val capturedBitmap = captureCurrentScreen()

                // 3. Restore bubble visibility
                bubbleView?.visibility = View.VISIBLE
                setBubbleScanningState(false)

                if (capturedBitmap != null) {
                    processCapturedBitmap(capturedBitmap)
                } else {
                    Toast.makeText(this@FloatService, "لم يتم التقاط الصورة، جارِ إعادة تهيئة العرض...", Toast.LENGTH_SHORT).show()
                    setupVirtualDisplay()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in bubble click execution: ${e.message}", e)
                bubbleView?.visibility = View.VISIBLE
                setBubbleScanningState(false)
            }
        }
    }

    private fun setBubbleScanningState(isScanning: Boolean) {
        val icon = bubbleView?.findViewById<ImageView>(R.id.bubble_icon)
        val progress = bubbleView?.findViewById<ProgressBar>(R.id.bubble_progress)
        if (isScanning) {
            icon?.visibility = View.INVISIBLE
            progress?.visibility = View.VISIBLE
        } else {
            icon?.visibility = View.VISIBLE
            progress?.visibility = View.GONE
        }
    }

    private suspend fun captureCurrentScreen(): Bitmap? = withContext(Dispatchers.Default) {
        var image: Image? = null
        try {
            image = imageReader?.acquireLatestImage()
            if (image == null) {
                delay(80)
                image = imageReader?.acquireLatestImage()
            }
            if (image == null) return@withContext null

            val planes = image.planes
            if (planes.isNullOrEmpty()) return@withContext null

            val buffer = planes[0].buffer ?: return@withContext null
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val width = image.width
            val height = image.height

            if (width <= 0 || height <= 0) return@withContext null

            val rowPadding = maxOf(0, rowStride - pixelStride * width)
            val bitmapWidth = width + rowPadding / pixelStride

            val bitmap = Bitmap.createBitmap(
                bitmapWidth,
                height,
                Bitmap.Config.ARGB_8888
            )
            val requiredBytes = bitmap.byteCount

            // CRITICAL FIX: Safe buffer allocation to prevent "Buffer not large enough for pixels" crash
            if (buffer.remaining() < requiredBytes) {
                val tempBuffer = java.nio.ByteBuffer.allocateDirect(requiredBytes)
                tempBuffer.put(buffer)
                tempBuffer.rewind()
                bitmap.copyPixelsFromBuffer(tempBuffer)
            } else {
                bitmap.copyPixelsFromBuffer(buffer)
            }

            if (rowPadding == 0 && bitmapWidth == width) {
                bitmap
            } else {
                Bitmap.createBitmap(bitmap, 0, 0, width, height)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Screen capture failed safely: ${e.message}", e)
            null
        } finally {
            try {
                image?.close()
            } catch (e: Exception) {
                Log.e(TAG, "Error closing image: ${e.message}")
            }
        }
    }

    /**
     * OCR via ML Kit Text Recognition and in-place translation layers
     */
    private fun processCapturedBitmap(bitmap: Bitmap) {
        val bmpWidth = bitmap.width
        val bmpHeight = bitmap.height
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        textRecognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                if (visionText.textBlocks.isNotEmpty()) {
                    translateAndDisplayInPlace(visionText, bmpWidth, bmpHeight)
                } else {
                    Toast.makeText(this@FloatService, "لم يتم اكتشاف نصوص في هذه المنطقة من الشاشة", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "OCR Recognition failure: ${e.message}", e)
                Toast.makeText(this@FloatService, "تعذر قراءة نصوص الشاشة", Toast.LENGTH_SHORT).show()
            }
    }

    private data class OcrCandidate(val text: String, val rect: Rect)

    /**
     * Processes OCR blocks by reading order (top-to-bottom, left-to-right) and
     * merges ONLY blocks whose rectangles actually overlap.
     * The 8dp same-line merging rule has been completely removed to prevent merging
     * separate UI elements (e.g. navigation bar buttons).
     */
    private fun translateAndDisplayInPlace(
        visionText: Text,
        bitmapWidth: Int,
        bitmapHeight: Int
    ) {
        serviceScope.launch {
            val point = getRealScreenDimensions()
            val scaleX = if (bitmapWidth > 0) point.x.toFloat() / bitmapWidth.toFloat() else 1f
            val scaleY = if (bitmapHeight > 0) point.y.toFloat() / bitmapHeight.toFloat() else 1f

            val rawCandidates = mutableListOf<OcrCandidate>()
            for (block in visionText.textBlocks) {
                val box = block.boundingBox ?: continue
                val rawText = block.text.replace("\n", " ").trim()
                if (rawText.isBlank()) continue

                val scaledLeft = (box.left * scaleX).toInt().coerceIn(0, point.x)
                val scaledTop = (box.top * scaleY).toInt().coerceIn(0, point.y)
                val scaledRight = (box.right * scaleX).toInt().coerceIn(0, point.x)
                val scaledBottom = (box.bottom * scaleY).toInt().coerceIn(0, point.y)

                if (scaledRight > scaledLeft && scaledBottom > scaledTop) {
                    rawCandidates.add(
                        OcrCandidate(rawText, Rect(scaledLeft, scaledTop, scaledRight, scaledBottom))
                    )
                }
            }

            if (rawCandidates.isEmpty()) {
                Toast.makeText(this@FloatService, "لم يتم العثور على كلمات للترجمة", Toast.LENGTH_SHORT).show()
                return@launch
            }

            // Step 1: Sort blocks in reading order: top-to-bottom, left-to-right
            val sortedBlocks = rawCandidates.sortedWith { a, b ->
                val verticalOverlap = Math.min(a.rect.bottom, b.rect.bottom) - Math.max(a.rect.top, b.rect.top)
                val minHeight = Math.min(a.rect.height(), b.rect.height())
                // If they share vertical space (same row), sort left-to-right
                if (verticalOverlap > minHeight * 0.5f || Math.abs(a.rect.top - b.rect.top) <= dpToPx(6)) {
                    a.rect.left.compareTo(b.rect.left)
                } else {
                    a.rect.top.compareTo(b.rect.top)
                }
            }.toMutableList()

            // Step 2: Merge ONLY if rectangles actually overlap (true geometric overlap)
            var hasOverlapChanges = true
            while (hasOverlapChanges) {
                hasOverlapChanges = false
                var i = 0
                while (i < sortedBlocks.size) {
                    var j = i + 1
                    while (j < sortedBlocks.size) {
                        val a = sortedBlocks[i]
                        val b = sortedBlocks[j]
                        if (Rect.intersects(a.rect, b.rect)) {
                            // Determine natural reading order for text concatenation
                            val (first, second) = if (a.rect.top < b.rect.top ||
                                (a.rect.top == b.rect.top && a.rect.left <= b.rect.left)) {
                                a to b
                            } else {
                                b to a
                            }
                            val mergedText = "${first.text} ${second.text}".trim()
                            val unionRect = Rect(a.rect).apply { union(b.rect) }
                            sortedBlocks[i] = OcrCandidate(mergedText, unionRect)
                            sortedBlocks.removeAt(j)
                            hasOverlapChanges = true
                        } else {
                            j++
                        }
                    }
                    i++
                }
            }

            // Step 3: Build final TranslationBlock list with 2dp padding to ensure complete coverage
            val pad = dpToPx(2)
            val translationBlocks = sortedBlocks.mapIndexed { index, candidate ->
                val screenRect = Rect(
                    (candidate.rect.left - pad).coerceAtLeast(0),
                    (candidate.rect.top - pad).coerceAtLeast(0),
                    (candidate.rect.right + pad).coerceAtMost(point.x),
                    (candidate.rect.bottom + pad).coerceAtMost(point.y)
                )
                TranslationBlock(
                    id = "block_$index",
                    originalText = candidate.text,
                    rect = screenRect
                )
            }

            if (translationBlocks.isEmpty()) {
                Toast.makeText(this@FloatService, "لم يتم العثور على كلمات للترجمة", Toast.LENGTH_SHORT).show()
                return@launch
            }

            // Build initially GONE TextViews positioned at rect.left, rect.top
            mainHandler.post {
                translationOverlayManager.setBlockList(translationBlocks)
            }

            // Translate each block in parallel and update its in-place layer
            for (item in translationBlocks) {
                launch {
                    val translated = TranslationHelper.translateText(
                        text = item.originalText,
                        sourceLang = sourceLang,
                        targetLang = targetLang
                    )
                    item.translatedText = translated
                    mainHandler.post {
                        translationOverlayManager.updateBlockTranslation(item)
                    }
                }
            }
        }
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun cleanUpMediaProjection() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
            mediaProjectionCallback?.let { mediaProjection?.unregisterCallback(it) }
            mediaProjection?.stop()
            mediaProjection = null
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning up projection: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        serviceScope.cancel()

        cleanUpMediaProjection()
        TranslationHelper.shutdownTts()

        if (isBubbleAttached && bubbleView != null) {
            try {
                windowManager.removeView(bubbleView)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing bubble: ${e.message}")
            }
            isBubbleAttached = false
        }

        if (::translationOverlayManager.isInitialized) {
            translationOverlayManager.clear()
        }
    }
}
