package com.example.domain.usecase

import com.example.domain.model.ChatMessage
import com.example.domain.model.MessageSender
import com.example.domain.repository.AIRepository
import com.example.domain.repository.ChatRepository

class SendMessageUseCase(
    private val chatRepository: ChatRepository,
    private val aiRepository: AIRepository
) {
    suspend operator fun invoke(
        content: String,
        conversationId: Long,
        currentHistory: List<ChatMessage>,
        assistantName: String
    ): Result<ChatMessage> {
        val trimmed = content.trim()
        if (trimmed.isEmpty()) {
            return Result.failure(IllegalArgumentException("Message content cannot be empty"))
        }

        // 1. Save user message locally in Room
        val userMessage = ChatMessage(
            conversationId = conversationId,
            sender = MessageSender.USER,
            content = trimmed,
            timestamp = System.currentTimeMillis()
        )
        val userMsgId = chatRepository.insertMessage(userMessage)
        val persistedUserMsg = userMessage.copy(id = userMsgId)

        // 2. Query AI repository for response
        val historyWithNewUserMsg = currentHistory + persistedUserMsg
        val aiResult = aiRepository.generateResponse(
            prompt = trimmed,
            history = historyWithNewUserMsg,
            assistantName = assistantName
        )

        return if (aiResult.isSuccess) {
            val responseContent = aiResult.getOrThrow()
            val assistantMessage = ChatMessage(
                conversationId = conversationId,
                sender = MessageSender.ASSISTANT,
                content = responseContent,
                timestamp = System.currentTimeMillis()
            )
            val assistantMsgId = chatRepository.insertMessage(assistantMessage)
            Result.success(assistantMessage.copy(id = assistantMsgId))
        } else {
            val errorMsg = aiResult.exceptionOrNull()?.message ?: "Failed to generate AI response"
            Result.failure(Exception(errorMsg))
        }
    }
}
