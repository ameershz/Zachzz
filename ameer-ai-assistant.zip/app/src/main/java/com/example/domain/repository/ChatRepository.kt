package com.example.domain.repository

import com.example.domain.model.ChatMessage
import com.example.domain.model.Conversation
import kotlinx.coroutines.flow.Flow

/**
 * Domain interface for conversation and message persistence.
 */
interface ChatRepository {
    fun getMessages(conversationId: Long): Flow<List<ChatMessage>>
    suspend fun insertMessage(message: ChatMessage): Long
    suspend fun deleteMessage(messageId: Long)
    suspend fun clearMessages(conversationId: Long)

    fun getConversations(): Flow<List<Conversation>>
    suspend fun getOrCreateDefaultConversation(): Conversation
}
