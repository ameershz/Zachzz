package com.example.data.repository

import com.example.data.local.dao.ConversationDao
import com.example.data.local.dao.MessageDao
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.MessageEntity
import com.example.domain.model.ChatMessage
import com.example.domain.model.Conversation
import com.example.domain.repository.ChatRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class ChatRepositoryImpl(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao
) : ChatRepository {

    override fun getMessages(conversationId: Long): Flow<List<ChatMessage>> {
        return messageDao.getMessagesForConversation(conversationId).map { entities ->
            entities.map { it.toDomain() }
        }
    }

    override suspend fun insertMessage(message: ChatMessage): Long = withContext(Dispatchers.IO) {
        val entity = MessageEntity.fromDomain(message)
        val id = messageDao.insertMessage(entity)
        conversationDao.updateLastModified(message.conversationId, System.currentTimeMillis())
        id
    }

    override suspend fun deleteMessage(messageId: Long) = withContext(Dispatchers.IO) {
        messageDao.deleteMessageById(messageId)
    }

    override suspend fun clearMessages(conversationId: Long) = withContext(Dispatchers.IO) {
        messageDao.clearMessagesForConversation(conversationId)
    }

    override fun getConversations(): Flow<List<Conversation>> {
        return conversationDao.getAllConversations().map { list ->
            list.map { it.toDomain() }
        }
    }

    override suspend fun getOrCreateDefaultConversation(): Conversation = withContext(Dispatchers.IO) {
        val existing = conversationDao.getConversationById(DEFAULT_CONVERSATION_ID)
        if (existing != null) {
            existing.toDomain()
        } else {
            val defaultEntity = ConversationEntity(
                id = DEFAULT_CONVERSATION_ID,
                title = "Main Conversation",
                createdAt = System.currentTimeMillis(),
                lastModified = System.currentTimeMillis()
            )
            conversationDao.insertConversation(defaultEntity)
            defaultEntity.toDomain()
        }
    }

    companion object {
        const val DEFAULT_CONVERSATION_ID = 1L
    }
}
