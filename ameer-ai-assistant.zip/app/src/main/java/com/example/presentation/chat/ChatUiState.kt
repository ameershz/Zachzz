package com.example.presentation.chat

import com.example.domain.model.ChatMessage
import com.example.utils.Constants

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val isGenerating: Boolean = false,
    val assistantName: String = Constants.DEFAULT_ASSISTANT_NAME,
    val suggestions: List<String> = Constants.QUICK_PROMPTS,
    val errorMessage: String? = null,
    val isClearDialogOpen: Boolean = false
)
