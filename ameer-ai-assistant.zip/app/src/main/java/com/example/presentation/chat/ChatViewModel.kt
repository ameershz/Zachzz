package com.example.presentation.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.usecase.ClearChatUseCase
import com.example.domain.usecase.GetAssistantSettingsUseCase
import com.example.domain.usecase.GetMessagesUseCase
import com.example.domain.usecase.SendMessageUseCase
import com.example.utils.Constants
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ChatViewModel(
    private val sendMessageUseCase: SendMessageUseCase,
    private val getMessagesUseCase: GetMessagesUseCase,
    private val clearChatUseCase: ClearChatUseCase,
    private val getAssistantSettingsUseCase: GetAssistantSettingsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    init {
        observeSettings()
        observeMessages()
    }

    private fun observeSettings() {
        viewModelScope.launch {
            getAssistantSettingsUseCase()
                .catch { /* Fallback to default */ }
                .collect { settings ->
                    _uiState.update { it.copy(assistantName = settings.assistantName) }
                }
        }
    }

    private fun observeMessages() {
        viewModelScope.launch {
            getMessagesUseCase(Constants.DEFAULT_CONVERSATION_ID)
                .catch { error ->
                    _uiState.update { it.copy(errorMessage = error.message) }
                }
                .collect { messageList ->
                    _uiState.update { it.copy(messages = messageList) }
                }
        }
    }

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage(customPrompt: String? = null) {
        val prompt = (customPrompt ?: _uiState.value.inputText).trim()
        if (prompt.isEmpty() || _uiState.value.isGenerating) return

        // Clear input text immediately
        _uiState.update { it.copy(inputText = "", isGenerating = true, errorMessage = null) }

        viewModelScope.launch {
            val result = sendMessageUseCase(
                content = prompt,
                conversationId = Constants.DEFAULT_CONVERSATION_ID,
                currentHistory = _uiState.value.messages,
                assistantName = _uiState.value.assistantName
            )

            _uiState.update { state ->
                state.copy(
                    isGenerating = false,
                    errorMessage = result.exceptionOrNull()?.message
                )
            }
        }
    }

    fun showClearDialog() {
        _uiState.update { it.copy(isClearDialogOpen = true) }
    }

    fun dismissClearDialog() {
        _uiState.update { it.copy(isClearDialogOpen = false) }
    }

    fun confirmClearChat() {
        viewModelScope.launch {
            clearChatUseCase(Constants.DEFAULT_CONVERSATION_ID)
            _uiState.update { it.copy(isClearDialogOpen = false) }
        }
    }

    class Factory(
        private val sendMessageUseCase: SendMessageUseCase,
        private val getMessagesUseCase: GetMessagesUseCase,
        private val clearChatUseCase: ClearChatUseCase,
        private val getAssistantSettingsUseCase: GetAssistantSettingsUseCase
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ChatViewModel(
                sendMessageUseCase = sendMessageUseCase,
                getMessagesUseCase = getMessagesUseCase,
                clearChatUseCase = clearChatUseCase,
                getAssistantSettingsUseCase = getAssistantSettingsUseCase
            ) as T
        }
    }
}
