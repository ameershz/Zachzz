package com.example

import com.example.data.remote.MockAIServiceImpl
import com.example.domain.model.ChatMessage
import com.example.domain.model.Conversation
import com.example.domain.model.MessageSender
import com.example.domain.repository.AIRepository
import com.example.domain.repository.ChatRepository
import com.example.domain.usecase.SendMessageUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AmeerAiUnitTest {

    @Test
    fun testMockAIServiceResponses() = runTest {
        val service = MockAIServiceImpl()
        val arabicReply = service.generateCompletion(
            prompt = "مرحبا",
            history = emptyList(),
            assistantName = "Ameer AI"
        )
        assertNotNull(arabicReply)
        assertTrue(arabicReply.contains("وعليكم السلام") || arabicReply.contains("أهلاً بك"))

        val englishReply = service.generateCompletion(
            prompt = "hello",
            history = emptyList(),
            assistantName = "Ameer AI"
        )
        assertNotNull(englishReply)
        assertTrue(englishReply.contains("Ameer AI"))
    }

    @Test
    fun testSendMessageUseCaseSuccess() = runTest {
        val mockMessages = mutableListOf<ChatMessage>()

        val fakeChatRepository = object : ChatRepository {
            override fun getMessages(conversationId: Long): Flow<List<ChatMessage>> = flowOf(mockMessages)
            override suspend fun insertMessage(message: ChatMessage): Long {
                val newId = (mockMessages.size + 1).toLong()
                mockMessages.add(message.copy(id = newId))
                return newId
            }
            override suspend fun deleteMessage(messageId: Long) {
                mockMessages.removeAll { it.id == messageId }
            }
            override suspend fun clearMessages(conversationId: Long) {
                mockMessages.clear()
            }
            override fun getConversations(): Flow<List<Conversation>> = flowOf(emptyList())
            override suspend fun getOrCreateDefaultConversation(): Conversation {
                return Conversation(id = 1L, title = "Main")
            }
        }

        val fakeAiRepository = object : AIRepository {
            override suspend fun generateResponse(
                prompt: String,
                history: List<ChatMessage>,
                assistantName: String
            ): Result<String> {
                return Result.success("This is a response to $prompt from $assistantName")
            }
        }

        val useCase = SendMessageUseCase(fakeChatRepository, fakeAiRepository)
        val result = useCase(
            content = "How are you?",
            conversationId = 1L,
            currentHistory = emptyList(),
            assistantName = "Ameer AI"
        )

        assertTrue(result.isSuccess)
        val assistantMessage = result.getOrThrow()
        assertEquals(MessageSender.ASSISTANT, assistantMessage.sender)
        assertTrue(assistantMessage.content.contains("How are you?"))
        // Both user message and assistant message are in repository
        assertEquals(2, mockMessages.size)
        assertEquals(MessageSender.USER, mockMessages[0].sender)
        assertEquals(MessageSender.ASSISTANT, mockMessages[1].sender)
    }
}
