package com.example.core.manager

import com.example.core.modules.AiModule
import com.example.core.modules.InferenceRequest
import com.example.core.modules.InferenceResponse
import com.example.core.modules.ModelStats
import com.example.core.modules.ModuleType
import com.example.core.modules.PatternClassifierModule
import com.example.core.modules.ReasoningEngineModule
import com.example.core.modules.SemanticRagModule
import com.example.core.modules.TextTransformerModule
import com.example.core.tensor.Tensor
import com.example.core.tensor.Tokenizer
import com.example.core.training.ContextInjector
import com.example.core.training.LocalFineTuner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlin.math.max

data class EngineBenchmark(
    val tensorOpsPerSec: Long,
    val inferenceLatencyMs: Long,
    val tokensPerSec: Float,
    val memoryAllocatedMb: Float,
    val cpuThreadsUsed: Int
)

/**
 * Central orchestrator for on-device AI modules.
 * Manages active modules, execution pipelines, context injection, and diagnostics.
 */
class AiCoreEngine {

    val tokenizer = Tokenizer()
    val textTransformer = TextTransformerModule(tokenizer = tokenizer)
    val semanticRag = SemanticRagModule(tokenizer = tokenizer)
    val reasoningEngine = ReasoningEngineModule(tokenizer = tokenizer)
    val patternClassifier = PatternClassifierModule(tokenizer = tokenizer)

    val contextInjector = ContextInjector(semanticRag)
    val fineTuner = LocalFineTuner()

    private val _activeModuleType = MutableStateFlow(ModuleType.TEXT_TRANSFORMER)
    val activeModuleType: StateFlow<ModuleType> = _activeModuleType.asStateFlow()

    fun getActiveModule(): AiModule {
        return when (_activeModuleType.value) {
            ModuleType.TEXT_TRANSFORMER -> textTransformer
            ModuleType.SEMANTIC_RAG -> semanticRag
            ModuleType.REASONING_ENGINE -> reasoningEngine
            ModuleType.PATTERN_CLASSIFIER -> patternClassifier
        }
    }

    fun getModule(type: ModuleType): AiModule {
        return when (type) {
            ModuleType.TEXT_TRANSFORMER -> textTransformer
            ModuleType.SEMANTIC_RAG -> semanticRag
            ModuleType.REASONING_ENGINE -> reasoningEngine
            ModuleType.PATTERN_CLASSIFIER -> patternClassifier
        }
    }

    fun switchModule(type: ModuleType) {
        _activeModuleType.value = type
    }

    suspend fun executeInference(
        prompt: String,
        temperature: Float = 0.7f,
        topK: Int = 5,
        contextDocs: List<String> = emptyList()
    ): InferenceResponse = withContext(Dispatchers.Default) {
        val module = getActiveModule()
        val request = InferenceRequest(
            prompt = prompt,
            temperature = temperature,
            topK = topK,
            contextDocs = contextDocs
        )
        module.process(request)
    }

    suspend fun runBenchmark(): EngineBenchmark = withContext(Dispatchers.Default) {
        val runtime = Runtime.getRuntime()
        runtime.gc()
        val memoryBefore = (runtime.totalMemory() - runtime.freeMemory()) / (1024f * 1024f)

        val matSize = 128
        val a = Tensor.xavier(matSize, matSize)
        val b = Tensor.xavier(matSize, matSize)

        val warmUp = a.matmul(b)
        val benchStart = System.currentTimeMillis()
        var opsCount = 0L

        // Execute 15 matrix multiplications
        for (i in 0 until 15) {
            a.matmul(b)
            // 2 * M * N * K operations per matmul
            opsCount += (2L * matSize * matSize * matSize)
        }

        val elapsedMs = max(1L, System.currentTimeMillis() - benchStart)
        val opsPerSec = (opsCount * 1000L) / elapsedMs

        // Benchmark a real inference pass
        val infStart = System.currentTimeMillis()
        val res = textTransformer.process(
            InferenceRequest("Neural benchmark local inference test", temperature = 0.1f, maxTokens = 16)
        )
        val infElapsed = max(1L, System.currentTimeMillis() - infStart)

        val memoryAfter = (runtime.totalMemory() - runtime.freeMemory()) / (1024f * 1024f)

        EngineBenchmark(
            tensorOpsPerSec = opsPerSec,
            inferenceLatencyMs = infElapsed,
            tokensPerSec = res.tokensPerSecond,
            memoryAllocatedMb = max(0.1f, memoryAfter - memoryBefore),
            cpuThreadsUsed = Runtime.getRuntime().availableProcessors()
        )
    }

    fun getStats(): ModelStats = getActiveModule().getStats()
}
