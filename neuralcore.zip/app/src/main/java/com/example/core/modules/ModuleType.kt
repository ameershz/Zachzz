package com.example.core.modules

enum class ModuleType(
    val title: String,
    val subtitle: String,
    val description: String,
    val badge: String,
    val titleAr: String,
    val subtitleAr: String,
    val descriptionAr: String,
    val badgeAr: String,
    val defaultParametersCount: Int
) {
    TEXT_TRANSFORMER(
        title = "Neural Transformer",
        subtitle = "Generative Sequence Model",
        description = "On-device self-attention and feed-forward tensor blocks with temperature & nucleus sampling. Capable of online gradient backprop.",
        badge = "Generative",
        titleAr = "المحول العصبي التوليدي",
        subtitleAr = "نموذج توليد التسلسل",
        descriptionAr = "انتباه ذاتي ومصفوفات تنسور متقدمة مع أخذ عينات حرارية ونواة احتمالية، وقابل للتدريب والضبط الدقيق على الجهاز.",
        badgeAr = "توليدي",
        defaultParametersCount = 42800
    ),
    SEMANTIC_RAG(
        title = "Semantic RAG & Vector Engine",
        subtitle = "Dense Memory & Retrieval",
        description = "Encodes text into multi-dimensional vector embeddings, performs local k-NN cosine distance search, and injects dynamic context.",
        badge = "Memory",
        titleAr = "محرك البحث الدلالي والشعاعي",
        subtitleAr = "الذاكرة الكثيفة والاسترجاع",
        descriptionAr = "تضمين النصوص في متجهات شعاعية وبحث فائق السرعة عبر تشابه جيب التمام k-NN مع حقن السياق المحلي بدون إنترنت.",
        badgeAr = "ذاكرة",
        defaultParametersCount = 24500
    ),
    REASONING_ENGINE(
        title = "Adaptive Reasoning Core",
        subtitle = "Probabilistic State & Logic Graph",
        description = "Evaluates hypotheses using confidence-calibrated graph nodes, multi-step deductive chains, and Bayesian rule weights.",
        badge = "Reasoning",
        titleAr = "نواة الاستنتاج والمنطق التكيفي",
        subtitleAr = "رسم بياني منطقي احتمالي",
        descriptionAr = "تقييم الفرضيات واستنتاج سلاسل التفكير خطوة بخطوة مع معايرة درجات الثقة وأوزان بايز الاحتمالية.",
        badgeAr = "استنتاج",
        defaultParametersCount = 18600
    ),
    PATTERN_CLASSIFIER(
        title = "Neural Pattern Classifier",
        subtitle = "Supervised Multi-Layer Perceptron",
        description = "High-speed intent, sentiment, and query anomaly detection using deep dense layers with real-time on-device training.",
        badge = "Classifier",
        titleAr = "مصنف الأنماط والنوايا العصبية",
        subtitleAr = "بيرسبترون عميق متعدد الطبقات",
        descriptionAr = "كشف النوايا والاستعلامات والشذوذ فائق السرعة عبر طبقات كثيفة مع تدريب إشرافي مباشر على الجهاز.",
        badgeAr = "مصنف",
        defaultParametersCount = 31200
    )
}
