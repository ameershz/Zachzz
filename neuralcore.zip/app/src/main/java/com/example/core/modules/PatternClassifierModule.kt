package com.example.core.modules

import com.example.core.tensor.AdamOptimizer
import com.example.core.tensor.LinearLayer
import com.example.core.tensor.Tensor
import com.example.core.tensor.Tokenizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * On-device Deep Multi-Layer Perceptron (MLP) for high-speed pattern recognition,
 * query intent classification, and anomaly detection.
 */
class PatternClassifierModule(
    val hiddenDim: Int = 48,
    val tokenizer: Tokenizer = Tokenizer()
) : AiModule {

    override val type: ModuleType = ModuleType.PATTERN_CLASSIFIER

    companion object {
        val CLASSES = listOf(
            "QUERY_KNOWLEDGE",    // Information retrieval
            "SYSTEM_COMMAND",     // Control / Execution directive
            "ANALYTIC_REASONING", // Logic / Problem solving
            "TRAINING_REQUEST",   // Model expansion / Data injection
            "SECURITY_ANOMALY"    // Out-of-bounds or suspicious pattern
        )
    }

    private val inputDim = tokenizer.vocabSize + 20
    private var layer1 = LinearLayer(inputDim, hiddenDim, Random(771))
    private var layer2 = LinearLayer(hiddenDim, hiddenDim / 2, Random(772))
    private var outLayer = LinearLayer(hiddenDim / 2, CLASSES.size, Random(773))

    private val optimizer = AdamOptimizer(learningRate = 0.007f)

    private var trainedEpochs: Int = 0
    private var lastLoss: Float = 0.31f

    override suspend fun process(request: InferenceRequest): InferenceResponse = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val inTensor = textToFeatureTensor(request.prompt)
        val reasoning = mutableListOf<String>()

        reasoning.add("Extracted bag-of-tokens feature vector across ${inputDim} dimensions")

        // Forward through 3-layer MLP
        val h1 = layer1.forward(inTensor).relu()
        val h2 = layer2.forward(h1).relu()
        val logits = outLayer.forward(h2)
        val probs = logits.softmax()

        val topClassIdx = probs.argmax()
        val topClassName = CLASSES[topClassIdx]
        val topConfidence = probs[0, topClassIdx]

        reasoning.add("Softmax distribution: ${CLASSES.mapIndexed { idx, name -> "$name=${"%.2f".format(probs[0, idx])}" }.joinToString(", ")}")

        val isArabic = Tokenizer.isArabic(request.prompt)
        val arabicClassNames = mapOf(
            "QUERY_KNOWLEDGE" to "استعلام_المعرفة",
            "SYSTEM_COMMAND" to "أمر_النظام",
            "ANALYTIC_REASONING" to "تفكير_تحليلي",
            "TRAINING_REQUEST" to "طلب_تدريب",
            "SECURITY_ANOMALY" to "تنبيه_أمني"
        )

        val output = buildString {
            if (isArabic) {
                val arName = arabicClassNames[topClassName] ?: topClassName
                append("تصنيف النمط العصبي: [").append(arName).append("]\n")
                append("نسبة الثقة: ").append("%.1f".format(topConfidence * 100)).append("%\n\n")
                append("توزيع الاحتمالات:\n")
                for (i in CLASSES.indices) {
                    val pct = probs[0, i] * 100f
                    val barLen = (pct / 10).toInt().coerceIn(0, 10)
                    val bar = "█".repeat(barLen) + "░".repeat(10 - barLen)
                    val label = arabicClassNames[CLASSES[i]] ?: CLASSES[i]
                    append("• ").append(label.padEnd(20)).append(" ").append(bar).append(" ").append("%.1f".format(pct)).append("%\n")
                }
            } else {
                append("Pattern Classification: [").append(topClassName).append("]\n")
                append("Confidence Score: ").append("%.1f".format(topConfidence * 100)).append("%\n\n")
                append("Class Probabilities:\n")
                for (i in CLASSES.indices) {
                    val pct = probs[0, i] * 100f
                    val barLen = (pct / 10).toInt().coerceIn(0, 10)
                    val bar = "█".repeat(barLen) + "░".repeat(10 - barLen)
                    append("• ").append(CLASSES[i].padEnd(20)).append(" ").append(bar).append(" ").append("%.1f".format(pct)).append("%\n")
                }
            }
        }

        val latency = max(1L, System.currentTimeMillis() - startTime)
        val tokensEst = output.split(" ").size
        val tps = (tokensEst.toFloat() / (latency / 1000f)).coerceAtLeast(1.0f)

        InferenceResponse(
            outputText = output,
            reasoningChain = reasoning,
            tokensGenerated = tokensEst,
            latencyMs = latency,
            tokensPerSecond = tps,
            confidence = topConfidence,
            embeddingVector = null,
            contextUsed = emptyList()
        )
    }

    private fun textToFeatureTensor(text: String): Tensor {
        val tokens = tokenizer.encode(text)
        val arr = FloatArray(inputDim)
        if (tokens.isEmpty()) {
            arr[Tokenizer.PAD_ID] = 1f
        } else {
            val w = 1.0f / sqrt(tokens.size.toFloat())
            for (t in tokens) {
                val safeT = t % inputDim
                arr[safeT] += w
            }
        }
        return Tensor(1, inputDim, arr)
    }

    override suspend fun trainStep(input: String, target: String, learningRate: Float): Float = withContext(Dispatchers.Default) {
        optimizer.learningRate = learningRate
        val inTensor = textToFeatureTensor(input)

        // Find matching class index (English or Arabic)
        val arabicMap = mapOf(
            "استعلام_المعرفة" to "QUERY_KNOWLEDGE",
            "أمر_النظام" to "SYSTEM_COMMAND",
            "تفكير_تحليلي" to "ANALYTIC_REASONING",
            "طلب_تدريب" to "TRAINING_REQUEST",
            "تنبيه_أمني" to "SECURITY_ANOMALY"
        )
        val normalizedTarget = arabicMap[target.trim()] ?: target.trim()
        var targetIdx = CLASSES.indexOfFirst { it.equals(normalizedTarget, ignoreCase = true) }
        if (targetIdx == -1) targetIdx = 0

        // Forward
        val h1 = layer1.forward(inTensor).relu()
        val h2 = layer2.forward(h1).relu()
        val logits = outLayer.forward(h2)
        val probs = logits.softmax()

        // Cross-entropy loss
        val pTarget = max(1e-7f, probs[0, targetIdx])
        val loss = -ln(pTarget.toDouble()).toFloat()

        // Backward
        val gradLogits = probs.copy()
        gradLogits[0, targetIdx] -= 1.0f

        val gradH2 = outLayer.backward(gradLogits)
        val gradH1 = layer2.backward(gradH2)
        layer1.backward(gradH1)

        optimizer.step(listOf(outLayer, layer2, layer1))

        trainedEpochs++
        lastLoss = (lastLoss * 0.85f) + (loss * 0.15f)
        lastLoss
    }

    override fun getStats(): ModelStats {
        val totalParams = (layer1.weights.size + layer1.bias.size) +
                (layer2.weights.size + layer2.bias.size) +
                (outLayer.weights.size + outLayer.bias.size)

        var zeroCount = 0
        var sum = 0.0
        val allWeights = layer1.weights.data + layer2.weights.data + outLayer.weights.data
        for (w in allWeights) {
            if (abs(w) < 1e-4f) zeroCount++
            sum += w
        }
        val mean = (sum / allWeights.size).toFloat()

        var sumSq = 0.0
        for (w in allWeights) {
            val d = w - mean
            sumSq += d * d
        }
        val std = sqrt(sumSq / allWeights.size).toFloat()

        return ModelStats(
            parameterCount = totalParams,
            layerCount = 3,
            memorySizeBytes = totalParams * 4L,
            averageLoss = lastLoss,
            trainedEpochs = trainedEpochs,
            weightSparsityPercent = (zeroCount.toFloat() / allWeights.size) * 100f,
            meanWeightValue = mean,
            stdDevWeightValue = std
        )
    }

    override fun exportWeights(): String {
        val obj = JSONObject()
        obj.put("module", type.name)
        obj.put("epochs", trainedEpochs)
        obj.put("loss", lastLoss.toDouble())
        return obj.toString()
    }

    override fun importWeights(serialized: String): Boolean {
        return try {
            val obj = JSONObject(serialized)
            trainedEpochs = obj.optInt("epochs", 0)
            lastLoss = obj.optDouble("loss", 0.25).toFloat()
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun resetWeights() {
        layer1 = LinearLayer(inputDim, hiddenDim, Random(771))
        layer2 = LinearLayer(hiddenDim, hiddenDim / 2, Random(772))
        outLayer = LinearLayer(hiddenDim / 2, CLASSES.size, Random(773))
        trainedEpochs = 0
        lastLoss = 0.35f
    }
}
