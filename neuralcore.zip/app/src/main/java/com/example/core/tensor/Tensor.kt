package com.example.core.tensor

import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * High-performance, zero-external-dependency on-device Tensor implementation.
 * Supports 1D (vectors) and 2D (matrices) with operations optimized for CPU execution.
 */
class Tensor(
    val rows: Int,
    val cols: Int,
    val data: FloatArray
) {
    init {
        require(data.size == rows * cols) {
            "Data size (${data.size}) does not match dimensions ($rows x $cols = ${rows * cols})"
        }
    }

    constructor(size: Int, init: (Int) -> Float = { 0f }) : this(1, size, FloatArray(size, init))
    constructor(rows: Int, cols: Int, init: (Int, Int) -> Float) : this(
        rows,
        cols,
        FloatArray(rows * cols) { idx -> init(idx / cols, idx % cols) }
    )

    val size: Int get() = rows * cols
    val isVector: Boolean get() = rows == 1 || cols == 1

    inline operator fun get(r: Int, c: Int): Float = data[r * cols + c]
    inline operator fun set(r: Int, c: Int, value: Float) {
        data[r * cols + c] = value
    }

    inline operator fun get(index: Int): Float = data[index]
    inline operator fun set(index: Int, value: Float) {
        data[index] = value
    }

    /**
     * Matrix multiplication: this [M x K] * other [K x N] = [M x N]
     */
    fun matmul(other: Tensor): Tensor {
        require(this.cols == other.rows) {
            "Matrix dimension mismatch: [${this.rows}x${this.cols}] * [${other.rows}x${other.cols}]"
        }
        val m = this.rows
        val kDim = this.cols
        val n = other.cols
        val result = FloatArray(m * n)

        for (i in 0 until m) {
            val iRowOffset = i * kDim
            val resRowOffset = i * n
            for (k in 0 until kDim) {
                val aVal = this.data[iRowOffset + k]
                if (aVal == 0f) continue
                val otherRowOffset = k * n
                for (j in 0 until n) {
                    result[resRowOffset + j] += aVal * other.data[otherRowOffset + j]
                }
            }
        }
        return Tensor(m, n, result)
    }

    /**
     * Vector dot product (both must have same number of elements).
     */
    fun dot(other: Tensor): Float {
        require(this.size == other.size) { "Size mismatch for dot product: ${this.size} vs ${other.size}" }
        var sum = 0f
        for (i in 0 until size) {
            sum += this.data[i] * other.data[i]
        }
        return sum
    }

    /**
     * Element-wise addition with broadcasting for 1D biases.
     */
    operator fun plus(other: Tensor): Tensor {
        if (this.rows == other.rows && this.cols == other.cols) {
            val out = FloatArray(size) { i -> this.data[i] + other.data[i] }
            return Tensor(rows, cols, out)
        }
        // Broadcast 1D vector (1 x cols) across all rows
        if (other.rows == 1 && other.cols == this.cols) {
            val out = FloatArray(size)
            for (r in 0 until rows) {
                val rOffset = r * cols
                for (c in 0 until cols) {
                    out[rOffset + c] = this.data[rOffset + c] + other.data[c]
                }
            }
            return Tensor(rows, cols, out)
        }
        throw IllegalArgumentException("Cannot broadcast [${other.rows}x${other.cols}] to [${this.rows}x${this.cols}]")
    }

    /**
     * Element-wise subtraction
     */
    operator fun minus(other: Tensor): Tensor {
        require(this.rows == other.rows && this.cols == other.cols) { "Dimension mismatch for minus" }
        val out = FloatArray(size) { i -> this.data[i] - other.data[i] }
        return Tensor(rows, cols, out)
    }

    /**
     * Element-wise multiplication
     */
    operator fun times(other: Tensor): Tensor {
        require(this.rows == other.rows && this.cols == other.cols) { "Dimension mismatch for hadamard product" }
        val out = FloatArray(size) { i -> this.data[i] * other.data[i] }
        return Tensor(rows, cols, out)
    }

    /**
     * Scalar multiplication
     */
    operator fun times(scalar: Float): Tensor {
        val out = FloatArray(size) { i -> this.data[i] * scalar }
        return Tensor(rows, cols, out)
    }

    /**
     * Scalar addition
     */
    operator fun plus(scalar: Float): Tensor {
        val out = FloatArray(size) { i -> this.data[i] + scalar }
        return Tensor(rows, cols, out)
    }

    fun transpose(): Tensor {
        val out = FloatArray(size)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                out[c * rows + r] = this.data[r * cols + c]
            }
        }
        return Tensor(cols, rows, out)
    }

    // --- Activations ---

    fun relu(): Tensor {
        val out = FloatArray(size) { i -> max(0f, data[i]) }
        return Tensor(rows, cols, out)
    }

    fun reluDerivative(): Tensor {
        val out = FloatArray(size) { i -> if (data[i] > 0f) 1f else 0f }
        return Tensor(rows, cols, out)
    }

    /**
     * Fast approximation of Gaussian Error Linear Unit (GELU) used in modern Transformers
     */
    fun gelu(): Tensor {
        val out = FloatArray(size) { i ->
            val x = data[i]
            0.5f * x * (1.0f + kotlin.math.tanh(0.7978845608f * (x + 0.044715f * x * x * x)))
        }
        return Tensor(rows, cols, out)
    }

    fun sigmoid(): Tensor {
        val out = FloatArray(size) { i ->
            val x = data[i]
            when {
                x < -45f -> 0f
                x > 45f -> 1f
                else -> (1.0f / (1.0f + exp(-x)))
            }
        }
        return Tensor(rows, cols, out)
    }

    fun tanh(): Tensor {
        val out = FloatArray(size) { i -> kotlin.math.tanh(data[i]) }
        return Tensor(rows, cols, out)
    }

    /**
     * Numerically stable Softmax across columns (per row)
     */
    fun softmax(): Tensor {
        val out = FloatArray(size)
        for (r in 0 until rows) {
            val rOffset = r * cols
            var maxVal = Float.NEGATIVE_INFINITY
            for (c in 0 until cols) {
                val v = data[rOffset + c]
                if (v > maxVal) maxVal = v
            }
            var sumExp = 0f
            for (c in 0 until cols) {
                val expVal = exp((data[rOffset + c] - maxVal).toDouble()).toFloat()
                out[rOffset + c] = expVal
                sumExp += expVal
            }
            val invSum = if (sumExp > 0f) 1f / sumExp else 1f
            for (c in 0 until cols) {
                out[rOffset + c] *= invSum
            }
        }
        return Tensor(rows, cols, out)
    }

    /**
     * Layer Normalization across columns
     */
    fun layerNorm(epsilon: Float = 1e-5f): Tensor {
        val out = FloatArray(size)
        for (r in 0 until rows) {
            val offset = r * cols
            var mean = 0f
            for (c in 0 until cols) mean += data[offset + c]
            mean /= cols

            var variance = 0f
            for (c in 0 until cols) {
                val diff = data[offset + c] - mean
                variance += diff * diff
            }
            variance /= cols
            val std = sqrt(variance + epsilon)

            for (c in 0 until cols) {
                out[offset + c] = (data[offset + c] - mean) / std
            }
        }
        return Tensor(rows, cols, out)
    }

    /**
     * Cosine similarity between two 1D vectors
     */
    fun cosineSimilarity(other: Tensor): Float {
        require(this.size == other.size) { "Tensors must have equal size" }
        var dot = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in 0 until size) {
            val a = this.data[i]
            val b = other.data[i]
            dot += a * b
            normA += a * a
            normB += b * b
        }
        val denom = sqrt(normA) * sqrt(normB)
        return if (denom > 1e-8f) (dot / denom) else 0f
    }

    fun l2Norm(): Float {
        var sum = 0f
        for (v in data) sum += v * v
        return sqrt(sum)
    }

    fun normalized(): Tensor {
        val norm = l2Norm()
        if (norm < 1e-8f) return this.copy()
        val inv = 1f / norm
        return Tensor(rows, cols, FloatArray(size) { i -> data[i] * inv })
    }

    fun argmax(): Int {
        var maxIdx = 0
        var maxVal = data[0]
        for (i in 1 until size) {
            if (data[i] > maxVal) {
                maxVal = data[i]
                maxIdx = i
            }
        }
        return maxIdx
    }

    /**
     * Top-K sampling with temperature for stochastic text generation
     */
    fun sampleTopK(k: Int = 5, temperature: Float = 0.8f, random: Random = Random.Default): Int {
        val effectiveTemp = max(0.01f, temperature)
        val scaled = FloatArray(size) { i -> data[i] / effectiveTemp }

        // Find max for stability
        var maxVal = Float.NEGATIVE_INFINITY
        for (v in scaled) if (v > maxVal) maxVal = v

        val exps = FloatArray(size)
        var sumExp = 0.0
        for (i in 0 until size) {
            val e = exp((scaled[i] - maxVal).toDouble()).toFloat()
            exps[i] = e
            sumExp += e
        }

        // Top K indices
        val indices = Array(size) { it }
        indices.sortWith { a, b -> exps[b].compareTo(exps[a]) }

        val actualK = min(k, size)
        var topKSum = 0.0
        for (i in 0 until actualK) {
            topKSum += exps[indices[i]]
        }

        val r = random.nextDouble() * topKSum
        var accum = 0.0
        for (i in 0 until actualK) {
            val idx = indices[i]
            accum += exps[idx]
            if (r <= accum) return idx
        }
        return indices[0]
    }

    fun copy(): Tensor = Tensor(rows, cols, data.clone())

    companion object {
        fun zeros(rows: Int, cols: Int = 1): Tensor = Tensor(rows, cols, FloatArray(rows * cols))

        fun ones(rows: Int, cols: Int = 1): Tensor = Tensor(rows, cols, FloatArray(rows * cols) { 1f })

        /**
         * Xavier / Glorot uniform weight initialization
         */
        fun xavier(rows: Int, cols: Int, random: Random = Random(42)): Tensor {
            val limit = sqrt(6.0f / (rows + cols))
            val arr = FloatArray(rows * cols) {
                (random.nextFloat() * 2f - 1f) * limit
            }
            return Tensor(rows, cols, arr)
        }

        /**
         * He / Kaiming normal initialization for ReLU networks
         */
        fun kaiming(rows: Int, cols: Int, random: Random = Random(42)): Tensor {
            val std = sqrt(2.0f / rows)
            val arr = FloatArray(rows * cols) {
                (boxMullerGaussian(random) * std)
            }
            return Tensor(rows, cols, arr)
        }

        private fun boxMullerGaussian(random: Random): Float {
            var u1 = random.nextFloat()
            while (u1 <= 1e-7f) u1 = random.nextFloat()
            val u2 = random.nextFloat()
            return (sqrt(-2.0 * ln(u1.toDouble())) * cos(2.0 * Math.PI * u2.toDouble())).toFloat()
        }
    }
}
