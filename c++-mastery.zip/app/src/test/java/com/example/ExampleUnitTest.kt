package com.example

import com.example.data.repository.ContentRepository
import com.example.domain.execution.CppDiagnosticsAnalyzer
import com.example.domain.execution.LocalCppInterpreterEngine
import com.example.domain.model.ExecutionStatus
import com.example.domain.model.UserLevel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testDiagnosticsAnalyzer_missingSemicolon() {
        val codeWithMissingSemi = "#include <iostream>\nint main() {\n    std::cout << \"Hello\"\n    return 0;\n}"
        val diagnostics = CppDiagnosticsAnalyzer.analyze(codeWithMissingSemi)
        assertTrue(diagnostics.any { it.rawMessage.contains("expected ';'") })
    }

    @Test
    fun testDiagnosticsAnalyzer_missingMain() {
        val codeWithoutMain = "#include <iostream>\nvoid start() {}"
        val diagnostics = CppDiagnosticsAnalyzer.analyze(codeWithoutMain)
        assertTrue(diagnostics.any { it.rawMessage.contains("main") })
    }

    @Test
    fun testDiagnosticsAnalyzer_assignmentWithoutValue() {
        val code = "#include <iostream>\nint main() {\n    int age = ;\n    return 0;\n}"
        val diagnostics = CppDiagnosticsAnalyzer.analyze(code)
        assertTrue(diagnostics.any { it.arabicExplanation.contains("بعد علامة التساوي") })
    }

    @Test
    fun testLocalCppInterpreter_runsHelloWorld() = runBlocking {
        val engine = LocalCppInterpreterEngine()
        val code = "#include <iostream>\nusing namespace std;\nint main() {\n    cout << \"Hello, C++!\";\n    return 0;\n}"
        val result = engine.execute(code)
        assertEquals(ExecutionStatus.SUCCESS, result.status)
        assertEquals("Hello, C++!", result.output.trim())
    }

    @Test
    fun testLocalCppInterpreter_variablesAndArithmetic() = runBlocking {
        val engine = LocalCppInterpreterEngine()
        val code = "#include <iostream>\nusing namespace std;\nint main() {\n    int a = 10;\n    int b = 5;\n    cout << (a + b);\n    return 0;\n}"
        val result = engine.execute(code)
        assertEquals(ExecutionStatus.SUCCESS, result.status)
        assertEquals("15", result.output.trim())
    }

    @Test
    fun testUserLevel_progression() {
        assertEquals(1, UserLevel.fromXp(0).levelNumber)
        assertEquals(1, UserLevel.fromXp(150).levelNumber)
        assertEquals(2, UserLevel.fromXp(250).levelNumber)
        assertEquals(4, UserLevel.fromXp(1200).levelNumber)
        assertEquals(7, UserLevel.fromXp(8000).levelNumber)
    }

    @Test
    fun testContentRepository_loadsCurriculum() {
        val repo = ContentRepository()
        val levels = repo.getAllLevels()
        assertEquals(16, levels.size) // Levels 0 through 15

        // Check levels 0, 1, 2, 3 have 10 lessons each
        assertEquals(10, repo.getLevel(0)?.lessons?.size)
        assertEquals(10, repo.getLevel(1)?.lessons?.size)
        assertEquals(10, repo.getLevel(2)?.lessons?.size)
        assertEquals(10, repo.getLevel(3)?.lessons?.size)

        // Check first lesson exists
        val firstLesson = repo.getLesson("l0_1")
        assertNotNull(firstLesson)
        assertEquals("ما هي البرمجة حقاً؟", firstLesson?.titleArabic)
    }
}
