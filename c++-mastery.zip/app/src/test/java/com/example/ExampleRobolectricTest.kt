package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("C++ Mastery", appName)
  }

  @Test
  fun `database creates successfully`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val database = com.example.data.database.CppDatabase.getInstance(context)
    org.junit.Assert.assertNotNull(database)
  }
}
