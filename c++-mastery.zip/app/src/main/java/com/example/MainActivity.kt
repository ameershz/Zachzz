package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.database.CppDatabase
import com.example.data.repository.ContentRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.UserProgressRepository
import com.example.presentation.navigation.AppNavigation
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val database = CppDatabase.getInstance(this)
        val progressRepository = UserProgressRepository(database)
        val contentRepository = ContentRepository()
        val settingsRepository = SettingsRepository(this)

        setContent {
            val isDarkMode by settingsRepository.isDarkMode.collectAsStateWithLifecycle(initialValue = true)

            MyApplicationTheme(darkTheme = isDarkMode) {
                // Force RTL layout direction across the entire app interface
                // Code blocks and console internally use LTR explicitly!
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppNavigation(
                        progressRepository = progressRepository,
                        contentRepository = contentRepository,
                        settingsRepository = settingsRepository,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
