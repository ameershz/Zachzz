package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.database.dao.AchievementDao
import com.example.data.database.dao.BookmarkDao
import com.example.data.database.dao.ChallengeProgressDao
import com.example.data.database.dao.ExerciseResultDao
import com.example.data.database.dao.LessonProgressDao
import com.example.data.database.dao.MistakeConceptDao
import com.example.data.database.dao.NoteDao
import com.example.data.database.dao.ProjectProgressDao
import com.example.data.database.dao.QuizResultDao
import com.example.data.database.dao.UserStatsDao
import com.example.data.database.entity.AchievementEntity
import com.example.data.database.entity.BookmarkEntity
import com.example.data.database.entity.ChallengeProgressEntity
import com.example.data.database.entity.ExerciseResultEntity
import com.example.data.database.entity.LessonProgressEntity
import com.example.data.database.entity.MistakeConceptEntity
import com.example.data.database.entity.NoteEntity
import com.example.data.database.entity.ProjectProgressEntity
import com.example.data.database.entity.QuizResultEntity
import com.example.data.database.entity.UserStatsEntity

@Database(
    entities = [
        LessonProgressEntity::class,
        QuizResultEntity::class,
        ExerciseResultEntity::class,
        AchievementEntity::class,
        UserStatsEntity::class,
        BookmarkEntity::class,
        NoteEntity::class,
        ChallengeProgressEntity::class,
        ProjectProgressEntity::class,
        MistakeConceptEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CppDatabase : RoomDatabase() {

    abstract fun lessonProgressDao(): LessonProgressDao
    abstract fun quizResultDao(): QuizResultDao
    abstract fun exerciseResultDao(): ExerciseResultDao
    abstract fun achievementDao(): AchievementDao
    abstract fun userStatsDao(): UserStatsDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun noteDao(): NoteDao
    abstract fun challengeProgressDao(): ChallengeProgressDao
    abstract fun projectProgressDao(): ProjectProgressDao
    abstract fun mistakeConceptDao(): MistakeConceptDao

    companion object {
        @Volatile
        private var INSTANCE: CppDatabase? = null

        fun getInstance(context: Context): CppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CppDatabase::class.java,
                    "cpp_mastery_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
