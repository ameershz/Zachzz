package com.example.data.repository

import com.example.content.AchievementsData
import com.example.data.database.CppDatabase
import com.example.data.database.entity.AchievementEntity
import com.example.data.database.entity.BookmarkEntity
import com.example.data.database.entity.ChallengeProgressEntity
import com.example.data.database.entity.ExerciseResultEntity
import com.example.data.database.entity.LessonProgressEntity
import com.example.data.database.entity.MistakeConceptEntity
import com.example.data.database.entity.NoteEntity
import com.example.data.database.entity.ProjectProgressEntity
import com.example.data.database.entity.QuizResultEntity
import com.example.data.database.entity.UserStatsEntity
import com.example.domain.model.Achievement
import com.example.domain.model.ReviewConcept
import com.example.domain.model.UserLevel
import com.example.domain.model.UserStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class UserProgressRepository(private val database: CppDatabase) {

    private val lessonDao = database.lessonProgressDao()
    private val quizDao = database.quizResultDao()
    private val exerciseDao = database.exerciseResultDao()
    private val achievementDao = database.achievementDao()
    private val statsDao = database.userStatsDao()
    private val bookmarkDao = database.bookmarkDao()
    private val noteDao = database.noteDao()
    private val challengeDao = database.challengeProgressDao()
    private val projectDao = database.projectProgressDao()
    private val mistakeDao = database.mistakeConceptDao()

    val userStats: Flow<UserStats> = statsDao.getUserStatsFlow().map { entity ->
        if (entity == null) {
            UserStats()
        } else {
            val level = UserLevel.fromXp(entity.totalXp).levelNumber
            UserStats(
                totalXp = entity.totalXp,
                level = level,
                currentStreak = entity.currentStreak,
                lastActiveDateMillis = entity.lastActiveDateMillis,
                completedLessonsCount = entity.completedLessonsCount,
                solvedExercisesCount = entity.solvedExercisesCount,
                solvedChallengesCount = entity.solvedChallengesCount,
                completedProjectsCount = entity.completedProjectsCount
            )
        }
    }

    val completedLessonIds: Flow<Set<String>> = lessonDao.getAllProgress().map { list ->
        list.filter { it.isCompleted }.map { it.lessonId }.toSet()
    }

    val achievements: Flow<List<Achievement>> = achievementDao.getAllAchievements().map { entities ->
        val entityMap = entities.associateBy { it.id }
        AchievementsData.ALL_ACHIEVEMENTS.map { item ->
            val saved = entityMap[item.id]
            if (saved != null && saved.isUnlocked) {
                item.copy(isUnlocked = true, unlockedAtMillis = saved.unlockedAtMillis)
            } else {
                item
            }
        }
    }

    val bookmarks: Flow<List<BookmarkEntity>> = bookmarkDao.getAllBookmarks()

    val mistakeConcepts: Flow<List<ReviewConcept>> = mistakeDao.getAllMistakeConcepts().map { list ->
        list.map { entity ->
            val tip = when (entity.conceptTag) {
                "semicolon" -> "تذكر دائماً: كل أمر في C++ ينتهي بفاصلة منقوطة ; لتنبيه المترجم بأن التعليمة اكتملت."
                "variables" -> "المتغير يحتاج تحديد نوعه أولاً (مثل int) ثم اسمه ثم قيمته قبل استخدامه."
                "cout_cin" -> "cout تستخدم << للإخراج إلى الشاشة، بينما cin تستخدم >> للإدخال من لوحة المفاتيح."
                "if_statements" -> "في الشروط: = تعني تخزين وإسناد، بينما == تعني فحص ومقارنة المساواة."
                "loops" -> "الحلقة تحتاج شرط توقف صحيح حتى لا تدخل في حلقة لا نهائية (Infinite Loop)."
                else -> "راجع أمثلة الدرس وجرّب كتابتها بنفسك في المختبر لترسيخ المفهوم."
            }
            val title = when (entity.conceptTag) {
                "semicolon" -> "الفاصلة المنقوطة (;)"
                "variables" -> "المتغيرات وأنواع البيانات"
                "cout_cin" -> "أوامر الإدخال والإخراج (cin / cout)"
                "if_statements" -> "الشروط والمقارنات (if / else)"
                "loops" -> "الحلقات التكرارية (Loops)"
                else -> "أساسيات لغة C++"
            }
            ReviewConcept(
                conceptTag = entity.conceptTag,
                titleArabic = title,
                mistakeCount = entity.mistakeCount,
                tipArabic = tip
            )
        }
    }

    suspend fun completeLesson(lessonId: String, levelNumber: Int, xpEarned: Int) {
        val existing = lessonDao.getProgressForLesson(lessonId)
        if (existing == null || !existing.isCompleted) {
            lessonDao.insertOrUpdate(
                LessonProgressEntity(
                    lessonId = lessonId,
                    levelNumber = levelNumber,
                    isCompleted = true,
                    earnedXp = xpEarned
                )
            )
            addXp(xpEarned)
            incrementCompletedLessons()

            // Unlock achievements based on progress
            if (lessonId == "l0_10" || lessonId == "l1_1") {
                unlockAchievement("first_code")
            }
            if (levelNumber >= 2) {
                unlockAchievement("variable_wizard")
            }
        }
    }

    suspend fun recordExerciseSolved(exerciseId: String, lessonId: String, xpEarned: Int) {
        val existing = exerciseDao.getResultForExercise(exerciseId)
        if (existing == null || !existing.isSolved) {
            exerciseDao.insertOrUpdate(
                ExerciseResultEntity(
                    exerciseId = exerciseId,
                    lessonId = lessonId,
                    isSolved = true,
                    attemptsCount = (existing?.attemptsCount ?: 0) + 1
                )
            )
            addXp(xpEarned)
            incrementSolvedExercises()
        }
    }

    suspend fun recordMistake(conceptTag: String) {
        if (conceptTag.isEmpty()) return
        val existing = mistakeDao.getMistake(conceptTag)
        val count = (existing?.mistakeCount ?: 0) + 1
        mistakeDao.insertOrUpdate(
            MistakeConceptEntity(
                conceptTag = conceptTag,
                mistakeCount = count,
                lastMistakeMillis = System.currentTimeMillis()
            )
        )
    }

    suspend fun clearMistake(conceptTag: String) {
        mistakeDao.delete(conceptTag)
        unlockAchievement("review_pro")
    }

    suspend fun recordQuizResult(quizId: String, score: Int, totalQuestions: Int, xpEarned: Int) {
        val isPassed = (score.toDouble() / totalQuestions.toDouble()) >= 0.7
        quizDao.insertOrUpdate(
            QuizResultEntity(
                quizId = quizId,
                score = score,
                totalQuestions = totalQuestions,
                isPassed = isPassed
            )
        )
        if (isPassed) {
            addXp(xpEarned)
            if (score == totalQuestions) {
                unlockAchievement("quiz_master")
            }
        }
    }

    suspend fun recordChallengeCompleted(challengeId: String, code: String, xpEarned: Int) {
        val existing = challengeDao.getProgressForChallenge(challengeId)
        if (existing == null || !existing.isCompleted) {
            challengeDao.insertOrUpdate(
                ChallengeProgressEntity(
                    challengeId = challengeId,
                    isCompleted = true,
                    savedCode = code
                )
            )
            addXp(xpEarned)
            incrementSolvedChallenges()
        }
    }

    suspend fun recordProjectCompleted(projectId: String, code: String, xpEarned: Int) {
        val existing = projectDao.getProgressForProject(projectId)
        if (existing == null || !existing.isCompleted) {
            projectDao.insertOrUpdate(
                ProjectProgressEntity(
                    projectId = projectId,
                    isCompleted = true,
                    savedCode = code
                )
            )
            addXp(xpEarned)
            incrementCompletedProjects()
            unlockAchievement("first_project")
        }
    }

    suspend fun toggleBookmark(lessonId: String, titleArabic: String, levelNumber: Int, isCurrentBookmarked: Boolean) {
        if (isCurrentBookmarked) {
            bookmarkDao.delete(lessonId)
        } else {
            bookmarkDao.insert(
                BookmarkEntity(
                    lessonId = lessonId,
                    titleArabic = titleArabic,
                    levelNumber = levelNumber
                )
            )
        }
    }

    fun isBookmarked(lessonId: String): Flow<Boolean> = bookmarkDao.isBookmarked(lessonId)

    suspend fun addNote(lessonId: String, title: String, content: String) {
        noteDao.insert(
            NoteEntity(
                lessonId = lessonId,
                lessonTitleArabic = title,
                noteContent = content
            )
        )
    }

    fun getNotesForLesson(lessonId: String): Flow<List<NoteEntity>> = noteDao.getNotesForLesson(lessonId)

    suspend fun unlockAchievement(id: String) {
        achievementDao.insertOrUpdate(
            AchievementEntity(
                id = id,
                isUnlocked = true,
                unlockedAtMillis = System.currentTimeMillis()
            )
        )
    }

    private suspend fun addXp(xp: Int) {
        val current = statsDao.getUserStats() ?: UserStatsEntity()
        val newXp = current.totalXp + xp
        val newLevel = UserLevel.fromXp(newXp).levelNumber
        statsDao.insertOrUpdate(
            current.copy(
                totalXp = newXp,
                level = newLevel,
                lastActiveDateMillis = System.currentTimeMillis()
            )
        )
    }

    private suspend fun incrementCompletedLessons() {
        val current = statsDao.getUserStats() ?: UserStatsEntity()
        statsDao.insertOrUpdate(current.copy(completedLessonsCount = current.completedLessonsCount + 1))
    }

    private suspend fun incrementSolvedExercises() {
        val current = statsDao.getUserStats() ?: UserStatsEntity()
        statsDao.insertOrUpdate(current.copy(solvedExercisesCount = current.solvedExercisesCount + 1))
    }

    private suspend fun incrementSolvedChallenges() {
        val current = statsDao.getUserStats() ?: UserStatsEntity()
        statsDao.insertOrUpdate(current.copy(solvedChallengesCount = current.solvedChallengesCount + 1))
    }

    private suspend fun incrementCompletedProjects() {
        val current = statsDao.getUserStats() ?: UserStatsEntity()
        statsDao.insertOrUpdate(current.copy(completedProjectsCount = current.completedProjectsCount + 1))
    }

    suspend fun resetAllProgress() {
        database.clearAllTables()
        statsDao.insertOrUpdate(UserStatsEntity())
    }
}
