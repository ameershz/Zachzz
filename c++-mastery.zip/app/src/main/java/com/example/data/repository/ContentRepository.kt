package com.example.data.repository

import com.example.content.ChallengesContent
import com.example.content.CourseCurriculum
import com.example.content.ExercisesData
import com.example.content.ProjectsContent
import com.example.content.QuizzesData
import com.example.domain.model.Challenge
import com.example.domain.model.CourseLevel
import com.example.domain.model.Exercise
import com.example.domain.model.Lesson
import com.example.domain.model.Project
import com.example.domain.model.Quiz

class ContentRepository {

    fun getAllLevels(): List<CourseLevel> = CourseCurriculum.getAllLevels()

    fun getLevel(levelNumber: Int): CourseLevel? = getAllLevels().find { it.levelNumber == levelNumber }

    fun getAllLessons(): List<Lesson> = getAllLevels().flatMap { it.lessons }

    fun getLesson(lessonId: String): Lesson? = getAllLessons().find { it.id == lessonId }

    fun getNextLesson(currentLessonId: String): Lesson? {
        val all = getAllLessons()
        val index = all.indexOfFirst { it.id == currentLessonId }
        return if (index != -1 && index + 1 < all.size) all[index + 1] else null
    }

    fun getExercise(exerciseId: String): Exercise? = ExercisesData.ALL_EXERCISES.find { it.id == exerciseId }

    fun getExercisesForLesson(lessonId: String): List<Exercise> = ExercisesData.ALL_EXERCISES.filter { it.lessonId == lessonId }

    fun getQuiz(quizId: String): Quiz? = QuizzesData.ALL_QUIZZES.find { it.id == quizId }

    fun getAllChallenges(): List<Challenge> = ChallengesContent.ALL_CHALLENGES

    fun getChallenge(challengeId: String): Challenge? = ChallengesContent.ALL_CHALLENGES.find { it.id == challengeId }

    fun getAllProjects(): List<Project> = ProjectsContent.ALL_PROJECTS

    fun getProject(projectId: String): Project? = ProjectsContent.ALL_PROJECTS.find { it.id == projectId }
}
