package com.example.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.database.entity.AchievementEntity
import com.example.data.database.entity.BookmarkEntity
import com.example.data.database.entity.ChallengeProgressEntity
import com.example.data.database.entity.ExerciseResultEntity
import com.example.data.database.entity.LessonProgressEntity
import com.example.data.database.entity.MistakeConceptEntity
import com.example.data.database.entity.NoteEntity
import com.example.data.database.entity.ProjectProgressEntity
import com.example.data.database.entity.QuizResultEntity
import com.example.data.database.entity.UserStatsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LessonProgressDao {
    @Query("SELECT * FROM lesson_progress")
    fun getAllProgress(): Flow<List<LessonProgressEntity>>

    @Query("SELECT * FROM lesson_progress WHERE lessonId = :lessonId")
    suspend fun getProgressForLesson(lessonId: String): LessonProgressEntity?

    @Query("SELECT COUNT(*) FROM lesson_progress WHERE isCompleted = 1")
    fun getCompletedLessonsCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(progress: LessonProgressEntity)

    @Query("DELETE FROM lesson_progress")
    suspend fun clearAll()
}

@Dao
interface QuizResultDao {
    @Query("SELECT * FROM quiz_results")
    fun getAllQuizResults(): Flow<List<QuizResultEntity>>

    @Query("SELECT * FROM quiz_results WHERE quizId = :quizId")
    suspend fun getResultForQuiz(quizId: String): QuizResultEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(result: QuizResultEntity)

    @Query("DELETE FROM quiz_results")
    suspend fun clearAll()
}

@Dao
interface ExerciseResultDao {
    @Query("SELECT * FROM exercise_results")
    fun getAllExerciseResults(): Flow<List<ExerciseResultEntity>>

    @Query("SELECT * FROM exercise_results WHERE exerciseId = :exerciseId")
    suspend fun getResultForExercise(exerciseId: String): ExerciseResultEntity?

    @Query("SELECT COUNT(*) FROM exercise_results WHERE isSolved = 1")
    fun getSolvedExercisesCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(result: ExerciseResultEntity)

    @Query("DELETE FROM exercise_results")
    suspend fun clearAll()
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements")
    fun getAllAchievements(): Flow<List<AchievementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(achievement: AchievementEntity)

    @Query("DELETE FROM achievements")
    suspend fun clearAll()
}

@Dao
interface UserStatsDao {
    @Query("SELECT * FROM user_stats WHERE id = 1")
    fun getUserStatsFlow(): Flow<UserStatsEntity?>

    @Query("SELECT * FROM user_stats WHERE id = 1")
    suspend fun getUserStats(): UserStatsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(stats: UserStatsEntity)

    @Query("DELETE FROM user_stats")
    suspend fun clearAll()
}

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY bookmarkedAtMillis DESC")
    fun getAllBookmarks(): Flow<List<BookmarkEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM bookmarks WHERE lessonId = :lessonId)")
    fun isBookmarked(lessonId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: BookmarkEntity)

    @Query("DELETE FROM bookmarks WHERE lessonId = :lessonId")
    suspend fun delete(lessonId: String)

    @Query("DELETE FROM bookmarks")
    suspend fun clearAll()
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY updatedAtMillis DESC")
    fun getAllNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE lessonId = :lessonId ORDER BY updatedAtMillis DESC")
    fun getNotesForLesson(lessonId: String): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM notes")
    suspend fun clearAll()
}

@Dao
interface ChallengeProgressDao {
    @Query("SELECT * FROM challenge_progress")
    fun getAllChallengesProgress(): Flow<List<ChallengeProgressEntity>>

    @Query("SELECT * FROM challenge_progress WHERE challengeId = :challengeId")
    suspend fun getProgressForChallenge(challengeId: String): ChallengeProgressEntity?

    @Query("SELECT COUNT(*) FROM challenge_progress WHERE isCompleted = 1")
    fun getCompletedChallengesCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(progress: ChallengeProgressEntity)

    @Query("DELETE FROM challenge_progress")
    suspend fun clearAll()
}

@Dao
interface ProjectProgressDao {
    @Query("SELECT * FROM project_progress")
    fun getAllProjectsProgress(): Flow<List<ProjectProgressEntity>>

    @Query("SELECT * FROM project_progress WHERE projectId = :projectId")
    suspend fun getProgressForProject(projectId: String): ProjectProgressEntity?

    @Query("SELECT COUNT(*) FROM project_progress WHERE isCompleted = 1")
    fun getCompletedProjectsCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(progress: ProjectProgressEntity)

    @Query("DELETE FROM project_progress")
    suspend fun clearAll()
}

@Dao
interface MistakeConceptDao {
    @Query("SELECT * FROM mistake_concepts ORDER BY mistakeCount DESC")
    fun getAllMistakeConcepts(): Flow<List<MistakeConceptEntity>>

    @Query("SELECT * FROM mistake_concepts WHERE conceptTag = :conceptTag")
    suspend fun getMistake(conceptTag: String): MistakeConceptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(concept: MistakeConceptEntity)

    @Query("DELETE FROM mistake_concepts WHERE conceptTag = :conceptTag")
    suspend fun delete(conceptTag: String)

    @Query("DELETE FROM mistake_concepts")
    suspend fun clearAll()
}
