package com.example.data.database.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "lesson_progress")
data class LessonProgressEntity(
    @PrimaryKey val lessonId: String,
    val levelNumber: Int,
    val isCompleted: Boolean,
    val completedAtMillis: Long = System.currentTimeMillis(),
    val earnedXp: Int = 0
)

@Entity(tableName = "quiz_results")
data class QuizResultEntity(
    @PrimaryKey val quizId: String,
    val score: Int,
    val totalQuestions: Int,
    val isPassed: Boolean,
    val completedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "exercise_results")
data class ExerciseResultEntity(
    @PrimaryKey val exerciseId: String,
    val lessonId: String,
    val isSolved: Boolean,
    val attemptsCount: Int,
    val completedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: String,
    val isUnlocked: Boolean,
    val unlockedAtMillis: Long? = null
)

@Entity(tableName = "user_stats")
data class UserStatsEntity(
    @PrimaryKey val id: Int = 1,
    val totalXp: Int = 0,
    val level: Int = 1,
    val currentStreak: Int = 1,
    val lastActiveDateMillis: Long = System.currentTimeMillis(),
    val lastOpenedLessonId: String = "l0_1",
    val completedLessonsCount: Int = 0,
    val solvedExercisesCount: Int = 0,
    val solvedChallengesCount: Int = 0,
    val completedProjectsCount: Int = 0
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val lessonId: String,
    val titleArabic: String,
    val levelNumber: Int,
    val bookmarkedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lessonId: String,
    val lessonTitleArabic: String,
    val noteContent: String,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "challenge_progress")
data class ChallengeProgressEntity(
    @PrimaryKey val challengeId: String,
    val isCompleted: Boolean,
    val savedCode: String = "",
    val completedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "project_progress")
data class ProjectProgressEntity(
    @PrimaryKey val projectId: String,
    val isCompleted: Boolean,
    val currentStep: Int = 1,
    val savedCode: String = "",
    val completedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "mistake_concepts")
data class MistakeConceptEntity(
    @PrimaryKey val conceptTag: String,
    val mistakeCount: Int,
    val lastMistakeMillis: Long = System.currentTimeMillis()
)
