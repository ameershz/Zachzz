package com.example.content

import com.example.domain.model.CodeBlock
import com.example.domain.model.CommonMistake
import com.example.domain.model.InteractiveToken
import com.example.domain.model.Lesson
import com.example.domain.model.LessonSummaryPoint
import com.example.domain.model.VisualAnalogy

object Level0Content {

    val lessons = listOf(
        // Lesson 1
        Lesson(
            id = "l0_1",
            levelNumber = 0,
            lessonNumber = 1,
            titleArabic = "ما هي البرمجة حقاً؟",
            titleEnglish = "What is Programming?",
            estimatedMinutes = 5,
            xpReward = 40,
            introduction = "أهلاً بك في أول خطوة في عالم البرمجة! البرمجة ليست سحراً ولا تعقيداً، بل هي ببساطة إعطاء تعليمات دقيقة ومرتبة لجهاز الكمبيوتر ليقوم بمهمة محددة.",
            detailedExplanation = "تخيل أنك طلبت من طفل صغير إعداد شاي. إذا قلت له فقط 'اعمل شاي'، قد لا يعرف من أين يبدأ! لكن إذا قلت له:\n1. ضع الماء في الغلاية.\n2. أشعل النار وانتظر حتى يغلي.\n3. ضع كيس الشاي في الكوب.\n4. اسكب الماء المغلي.\n\nالكمبيوتر تماماً مثل هذا الطفل: جهاز سريع وخارق في الحسابات، لكنه غبي جداً ولا يملك أي ذكاء ذاتي! لا يستطيع التفكير بمفرده، بل ينفذ بالحرف الواحد ما نأمره به. هذا التسلسل من التعليمات هو ما نسميه 'البرنامج'.",
            visualAnalogy = VisualAnalogy(
                title = "تشبيه وصفة الطبخ 🍲",
                analogyArabic = "البرنامج يشبه وصفة الطبخ الدقيقة؛ إذا نسيت خطوة واحدة أو عكست الترتيب، ستفشل الطبخة كلها!",
                realTechExplanation = "الكمبيوتر يقرأ السطور سطراً بسطر من الأعلى إلى الأسفل وينفذ كل تعليمة بالترتيب الدقيق."
            ),
            codeBlocks = emptyList(),
            commonMistakes = listOf(
                CommonMistake(
                    title = "الاعتقاد بأن الكمبيوتر يفهم النوايا",
                    incorrectCode = "// أود طباعة اسمي ولكن نسيت كتابة الأمر البرمجي",
                    correctCode = "std::cout << \"Ahmed\";",
                    whyItHappens = "يظن المبتدئ أن الكمبيوتر يستطيع تخمين ما يريد فعله.",
                    howToFix = "الكمبيوتر لا يفهم إلا التعليمات المكتوبة بدقة متناهية وفق قواعد اللغة."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("💡", "البرمجة هي إعطاء تعليمات دقيقة خطوة بخطوة للكمبيوتر."),
                LessonSummaryPoint("🧠", "الكمبيوتر سريع وخارق لكنه لا يفكر بمفرده."),
                LessonSummaryPoint("🎯", "أنت المبرمج، وأنت من يقود الحاسوب.")
            ),
            exerciseIds = listOf("ex_l0_1"),
            quizId = "quiz_l0_1"
        ),

        // Lesson 2
        Lesson(
            id = "l0_2",
            levelNumber = 0,
            lessonNumber = 2,
            titleArabic = "كيف يفهم الكمبيوتر الأوامر؟ (لغة الآلة)",
            titleEnglish = "How Computers Understand Instructions",
            estimatedMinutes = 6,
            xpReward = 40,
            introduction = "في قلب معالج الكمبيوتر (CPU)، لا توجد كلمات إنجليزية ولا عربية، بل ملايين المفاتيح الكهربائية الصغيرة جداً (Transistors)!",
            detailedExplanation = "هذه المفاتيح الكهربائية لها حالتان فقط:\n- مفتوح (يمر تيار كهربائي) = نرمز له بالرقم 1\n- مغلق (لا يمر تيار) = نرمز له بالرقم 0\n\nهذا هو النظام الثنائي (Binary System)، واللغة الوحيدة التي يفهمها المعالج مباشرة تسمى 'لغة الآلة' (Machine Code)، وهي عبارة عن سلاسل لا نهائية من الأصفار والآحاد مثل:\n10110000 01100001\n\nكتابة البرامج بهذه الطريقة مستحيلة على البشر، ولهذا اخترع العلماء لغات البرمجة الحديثة لنتحدث نحن بلغة مفهومة، ويتولى وسيط تحويلها إلى 0 و 1.",
            visualAnalogy = VisualAnalogy(
                title = "مفتاح مصباح الغرفة 💡",
                analogyArabic = "تماماً مثل مفتاح الإضاءة في غرفتك: إما مشتعل (1) أو منطفئ (0). لا توجد حالة وسطى.",
                realTechExplanation = "الترانزستور في المعالج يعمل كمفتاح، وملايين المفاتيح معاً تشكل العمليات الحسابية والمنطقية."
            ),
            codeBlocks = emptyList(),
            commonMistakes = emptyList(),
            summaryPoints = listOf(
                LessonSummaryPoint("⚡", "المعالج يفهم فقط الإشارات الكهربائية: تشغيل (1) وإيقاف (0)."),
                LessonSummaryPoint("🔢", "لغة الآلة (Machine Code) مكونة من نظام ثنائي Binary."),
                LessonSummaryPoint("🌉", "لغات البرمجة هي الجسر بين عقل الإنسان وعقل الآلة.")
            ),
            exerciseIds = listOf("ex_l0_2")
        ),

        // Lesson 3
        Lesson(
            id = "l0_3",
            levelNumber = 0,
            lessonNumber = 3,
            titleArabic = "ما هو الكود (Code)؟",
            titleEnglish = "What is Code?",
            estimatedMinutes = 5,
            xpReward = 40,
            introduction = "نسمع يومياً كلمة 'كود' أو 'شفرة برمجية'، لكن ما هو في الحقيقة؟",
            detailedExplanation = "الكود (Source Code) هو ببساطة ملف نصي عادي تكتب فيه تعليماتك باستخدام كلمات ورموز متفق عليها في لغة البرمجة.\n\nتماماً مثلما تكتب مقالاً في ملف Word، أنت تكتب كوداً في ملف ينتهي بامتداد خاص، مثلاً في C++ ينتهي بـ .cpp.\n\nالكود هو النص الأصلي القابل للقراءة من قبل المبرمجين، لكنه غير جاهز للتشغيل مباشرة على المعالج حتى تتم ترجمته.",
            visualAnalogy = VisualAnalogy(
                title = "النوتة الموسيقية 🎼",
                analogyArabic = "الكود يشبه النوتة الموسيقية؛ رموز وكلمات مكتوبة على الورق، يعزفها العازف (الكمبيوتر) ليحولها إلى صوت حقيقي.",
                realTechExplanation = "ملف الكود المصدري يحتوي نصاً مقروءاً للبشر (Source Code)."
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("📝", "الكود هو نص مكتوب بلغة برمجية محددة."),
                LessonSummaryPoint("📄", "ملفات كود C++ تحفظ بالامتداد .cpp."),
                LessonSummaryPoint("👀", "الكود يقرأه ويفهمه الإنسان، ويحتاج ترجمة ليفهمه المعالج.")
            ),
            exerciseIds = listOf("ex_l0_3")
        ),

        // Lesson 4
        Lesson(
            id = "l0_4",
            levelNumber = 0,
            lessonNumber = 4,
            titleArabic = "ما هي لغة البرمجة (Programming Language)؟",
            titleEnglish = "What is a Programming Language?",
            estimatedMinutes = 6,
            xpReward = 40,
            introduction = "مثلما يحتاج البشر إلى لغات كالعربية والإنجليزية للتفاهم، نحتاج إلى لغات برمجة للتخاطب مع الحواسيب.",
            detailedExplanation = "لغة البرمجة هي مجموعة من الكلمات المفتاحية (Keywords) والقواعد النحوية (Syntax) التي تمكننا من كتابة أوامر منظمة.\n\nهناك لغات عالية المستوى (High-level) مثل Python قريبة جداً من الإنجليزية وسهلة، وهناك لغات منخفضة المستوى (Low-level) قريبة من العتاد.\n\nأما C++ فتتميز بأنها لغة تجمع القوتين: توفر تعابير عالية المستوى وذكية، وفي نفس الوقت تمنحك سيطرة كاملة ومباشرة على الذاكرة والعتاد!",
            summaryPoints = listOf(
                LessonSummaryPoint("🗣️", "لغة البرمجة توفر قواعد ومفردات للتواصل مع الحاسوب."),
                LessonSummaryPoint("📐", "Syntax هي القواعد النحوية والإملائية الصارمة للغة."),
                LessonSummaryPoint("🚀", "C++ تمنحك قوة عالية المستوى مع سيطرة عتادية مذهلة.")
            ),
            exerciseIds = listOf("ex_l0_4")
        ),

        // Lesson 5
        Lesson(
            id = "l0_5",
            levelNumber = 0,
            lessonNumber = 5,
            titleArabic = "لماذا نتعلم C++ بالذات؟",
            titleEnglish = "Why C++?",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "أنشأ العالم بيارن ستروستروب (Bjarne Stroustrup) لغة C++ عام 1979، واليوم تشغل أقوى الأنظمة في الكوكب!",
            detailedExplanation = "أين تُستخدم C++ اليوم؟\n🎮 محركات الألعاب العملاقة (Unreal Engine).\n🚀 أنظمة الملاحة في وكالة ناسا وصواريخ سبيس إكس.\n🚗 أنظمة السيارات ذاتية القيادة.\n💻 أنظمة التشغيل (Windows, macOS kernel, Linux drivers).\n🌐 محركات متصفحات الويب (Chrome V8 engine).\n\nميزتها الكبرى هي 'السرعة الفائقة والتحكم المطلق': لا توجد طبقات بطيئة بينك وبين المعالج. إذا تعلمت C++، ستفهم الذاكرة والمعالج بعمق، وستكون أي لغة أخرى لاحقاً سهلة جداً بالنسبة لك!",
            summaryPoints = listOf(
                LessonSummaryPoint("⚡", "C++ من أسرع لغات العالم وأكثرها كفاءة في استهلاك الموارد."),
                LessonSummaryPoint("🎮", "اللغة المفضلة لصناعة الألعاب والأنظمة الحساسة للوقت."),
                LessonSummaryPoint("🎓", "تعلم C++ يجعلك مهندس برمجيات حقيقياً يفهم أصل الأشياء.")
            ),
            exerciseIds = listOf("ex_l0_5")
        ),

        // Lesson 6
        Lesson(
            id = "l0_6",
            levelNumber = 0,
            lessonNumber = 6,
            titleArabic = "ما هو المترجم (Compiler)؟",
            titleEnglish = "What is a Compiler?",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "أنت تكتب كوداً باللغة الإنجليزية، والكمبيوتر لا يفهم إلا 0 و 1. كيف يتفاهمان؟ هنا يأتي دور المترجم!",
            detailedExplanation = "المترجم (Compiler) هو برنامج خارق ومساعد يقوم بمهمتين أساسيتين:\n1. فحص الكود والتأكد من خلوه من أي أخطاء قواعدية (Syntax Errors).\n2. ترجمة ملف الكود المصدري بالكامل إلى ملف تنفيذي بلغة الآلة (مثل ملف .exe أو ملف ثنائي binary).\n\nأشهر مترجمات C++ في العالم هي:\n- GCC (Gnu Compiler Collection)\n- Clang\n- MSVC (Microsoft Visual C++).\n\nبفضل المترجم، يتم فحص برنامجك مسبقاً قبل تشغيله لضمان سلامته وسرعته القصوى.",
            visualAnalogy = VisualAnalogy(
                title = "المترجم الفوري في المؤتمرات 🌐",
                analogyArabic = "مثل مترجم يقرأ كتاباً كاملاً بالإنجليزية، يترجمه إلى العربية، ويطبعه ككتاب جاهز للقراءة.",
                realTechExplanation = "الـ Compiler يترجم الكود المصدري C++ دفعة واحدة إلى لغة الآلة، لينتج ملفاً تنفيذياً جاهزاً."
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("⚙️", "المترجم Compiler يترجم كودك المكتوب إلى لغة الآلة 0 و 1."),
                LessonSummaryPoint("🔍", "يفحص القواعد النحوية بدقة قبل السماح بالتشغيل."),
                LessonSummaryPoint("📦", "يخرج ملفاً تنفيذياً نهائياً سريعاً جداً.")
            ),
            exerciseIds = listOf("ex_l0_6")
        ),

        // Lesson 7
        Lesson(
            id = "l0_7",
            levelNumber = 0,
            lessonNumber = 7,
            titleArabic = "ماذا يعني Compile Time؟",
            titleEnglish = "What is Compile Time?",
            estimatedMinutes = 5,
            xpReward = 45,
            introduction = "في حياة أي برنامج، هناك مرحلتان زمنيتان منفصلتان تماماً: وقت الترجمة، ووقت التشغيل.",
            detailedExplanation = "وقت الترجمة (Compile Time) هو اللحظة التي يقوم فيها المترجم بقراءة ملف الكود المكتوب وتحليله.\n\nفي هذه اللحظة، البرنامج لم يبدأ بالعمل بعد على جهاز المستخدم! إذا نسيت فاصلة منقوطة أو كتبت كلمة إنجليزية خاطئة، سيكتشفها المترجم فوراً ويوقف العملية ويقول لك:\n'لا أستطيع المتابعة، يوجد خطأ في السطر رقم كذا!'.\n\nوهذا يسمى خطأ ترجمة (Compile Error).",
            summaryPoints = listOf(
                LessonSummaryPoint("⏳", "Compile Time: مرحلة ترجمة وفحص الكود قبل تشغيله."),
                LessonSummaryPoint("🛑", "إذا وجد المترجم خطأ، فلن يُنشئ الملف التنفيذي إطلاقاً."),
                LessonSummaryPoint("🛡️", "هذه الميزة تحميك من إرسال برامج مكسورة للمستخدمين.")
            ),
            exerciseIds = listOf("ex_l0_7")
        ),

        // Lesson 8
        Lesson(
            id = "l0_8",
            levelNumber = 0,
            lessonNumber = 8,
            titleArabic = "ماذا يعني Runtime؟",
            titleEnglish = "What is Runtime?",
            estimatedMinutes = 5,
            xpReward = 45,
            introduction = "بعد أن ينجح المترجم في بناء الملف، يضغط المستخدم على أيقونة البرنامج لفتحه. هنا يبدأ الـ Runtime!",
            detailedExplanation = "وقت التشغيل (Runtime) هو الوقت الفعلي الذي يكون فيه برنامجك قيد العمل داخل ذاكرة الكمبيوتر (RAM) وينفذه المعالج.\n\nفي هذا الوقت، قد تحدث أمور غير متوقعة أثناء تفاعل المستخدم مع البرنامج، مثل:\n- أن يطلب البرنامج رقماً، فيدخل المستخدم نصاً.\n- أن تحاول القسمة على صفر (وهو مستحيل رياضياً).\n- أن تنفد ذاكرة الجهاز.\n\nهذه الأخطاء تسمى أخطاء وقت التشغيل (Runtime Errors) وتؤدي لتوقف البرنامج المفاجئ (Crash).",
            summaryPoints = listOf(
                LessonSummaryPoint("▶️", "Runtime: الوقت الذي يعمل فيه البرنامج على جهاز المستخدم."),
                LessonSummaryPoint("💥", "أخطاء وقت التشغيل تحدث بعد نجاح الترجمة وأثناء الاستخدام."),
                LessonSummaryPoint("🛡️", "المبرمج المحترف يضع احتياطات لكل السيناريوهات لتجنب الـ Crash.")
            ),
            exerciseIds = listOf("ex_l0_8")
        ),

        // Lesson 9
        Lesson(
            id = "l0_9",
            levelNumber = 0,
            lessonNumber = 9,
            titleArabic = "ما هو الخطأ (Error) وكيف نتعامل معه؟",
            titleEnglish = "What is an Error in Programming?",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "الأخطاء البرمجية ليست عيباً ولا فشلاً، بل هي 90% من عمل أي مبرمج محترف يومياً!",
            detailedExplanation = "الأخطاء تنقسم إلى 3 أنواع رئيسية:\n\n1. خطأ نحوي (Syntax Error): مثل نسيان فاصلة منقوطة ; أو كتابة cout بشكل خاطئ. يكتشفه المترجم فوراً في Compile Time.\n\n2. خطأ تشغيلي (Runtime Error): البرنامج قواعده صحيحة لكنه يقوم بعملية غير قانونية أثناء التشغيل، مثل القسمة على صفر.\n\n3. خطأ منطقي (Logic Error): البرنامج يترجم ويعمل بسلاسة ولا يتوقف، لكن نتيجته خاطئة! مثلاً برنامج لحساب مجموع رقمين يقوم بطرحهما بدلاً من جمعهما.\n\nفي هذا التطبيق، سنعلمك كيف تقرأ رسالة الخطأ وتفهمها كصديق يرشدك إلى الحل.",
            summaryPoints = listOf(
                LessonSummaryPoint("🐞", "الأخطاء البرمجية (Bugs) جزء طبيعي وضروري من رحلة التعلم."),
                LessonSummaryPoint("3️⃣", "هناك ثلاثة أنواع: نحوية (Syntax)، تشغيلية (Runtime)، ومنطقية (Logic)."),
                LessonSummaryPoint("🔎", "رسالة الخطأ ليست عقاباً، بل خريطة تدلك على موضع المشكلة.")
            ),
            exerciseIds = listOf("ex_l0_9")
        ),

        // Lesson 10
        Lesson(
            id = "l0_10",
            levelNumber = 0,
            lessonNumber = 10,
            titleArabic = "أول برنامج لنا في C++ 🚀",
            titleEnglish = "Our First C++ Program",
            estimatedMinutes = 8,
            xpReward = 60,
            introduction = "مبروك وصولك لهذه المحطة التاريخية! الآن سنكتب ونشرح أول برنامج حقيقي في C++.",
            detailedExplanation = "البرنامج التقليدي الأشهر في تاريخ البرمجة هو طباعة عبارة 'Hello, World!' على الشاشة.\n\nلا تنظر إلى الكود ككتلة صماء مخيفة؛ الكود يتكون من قطع صغيرة واضحة جداً سنفككها قطعة قطعة في الدرس القادم، ولكن لاحظ الآن كيف يبدو شكل البرنامج الكامل واضغط على أجزائه لتتعرف عليها!",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n\nint main() {\n    std::cout << \"Hello, World!\";\n    return 0;\n}",
                    explanation = "هذا هو الهيكل القياسي لأي برنامج C++. استدعاء مكتبة iostream، ثم دالة main، ثم أمر الطباعة cout، ثم return 0 لإعلام النظام بنجاح المهمة.",
                    interactiveTokens = listOf(
                        InteractiveToken("#include", "توجيه استدعاء", "أمر يخبر المترجم بإحضار أدوات ومكتبات خارجية قبل البدء في الترجمة.", true),
                        InteractiveToken("<iostream>", "مكتبة الإدخال والإخراج", "اختصار Input Output Stream، وهي المكتبة المسؤولة عن الطباعة في الشاشة وقراءة المفاتيح.", false),
                        InteractiveToken("int", "نوع الإرجاع", "اختصار Integer (رقم صحيح)، يحدد أن الدالة ستُرجع رقماً صحيحاً للنظام عند انتهائها.", true),
                        InteractiveToken("main", "اسم الدالة الرئيسية", "نقطة انطلاق البرنامج الإجبارية. الكمبيوتر يبحث عن main() ليبدأ التنفيذ منها.", false),
                        InteractiveToken("()", "أقواس المعاملات", "مكان يمكن فيه تمرير مدخلات إلى الدالة.", false),
                        InteractiveToken("{ }", "حدود جسم الدالة", "القوسان المجعدان يحددان بداية ونهاية الأوامر التابعة لدالة main.", false),
                        InteractiveToken("std", "فضاء الأسماء القياسي", "اختصار Standard، المستودع الرسمي الذي يحتوي على أدوات لغة C++ القياسية.", false),
                        InteractiveToken("cout", "كائن الإخراج للشاشة", "اختصار Character Output، وهو الأداة المسؤولة عن طباعة الحروف والكلمات على شاشة Console.", false),
                        InteractiveToken("<<", "معامل الإرسال", "سهم يوجّه البيانات من اليمين إلى الشاشة على اليسار.", false),
                        InteractiveToken("\"Hello, World!\"", "النص المراد طباعته", "النص المحصور بين علامتي تنصيص ليطبعه الكمبيوتر حرفياً كما هو.", false),
                        InteractiveToken("return", "إرجاع النتيجة", "أمر ينهي تنفيذ الدالة ويُرجع قيمة إلى نظام التشغيل.", true),
                        InteractiveToken("0", "رمز النجاح", "رقم يُخبر نظام التشغيل (Android/Windows) أن البرنامج انتهى بنجاح بدون أخطاء.", false),
                        InteractiveToken(";", "الفاصلة المنقوطة", "علامة نهاية كل أمر برمجي في C++، مثل النقطة في نهاية الجملة.", false)
                    ),
                    expectedOutput = "Hello, World!"
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "نسيان الفاصلة المنقوطة ;",
                    incorrectCode = "std::cout << \"Hello, World!\"\nreturn 0;",
                    correctCode = "std::cout << \"Hello, World!\";\nreturn 0;",
                    whyItHappens = "ينسى المبتدئ أن المترجم لا يعتمد على الانتقال لسطر جديد لمعرفة نهاية الأمر، بل يحتاج إلى الفاصلة المنقوطة إجبارياً.",
                    howToFix = "ضع دائماً ; في نهاية كل سطر برمجي ينفذ أمراً."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🌟", "برنامجك الأول أصبح حقيقة!"),
                LessonSummaryPoint("🎯", "main() هي البوابة الإلزامية التي يبدأ منها الكمبيوتر."),
                LessonSummaryPoint("💬", "cout مع << يطبع أي نص محصور بين علامتي اقتباس \"\" على الشاشة.")
            ),
            exerciseIds = listOf("ex_l0_10"),
            quizId = "quiz_l0_final"
        )
    )
}
