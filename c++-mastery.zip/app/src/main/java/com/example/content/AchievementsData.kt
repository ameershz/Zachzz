package com.example.content

import com.example.domain.model.Achievement

object AchievementsData {
    val ALL_ACHIEVEMENTS = listOf(
        Achievement(
            id = "first_code",
            titleArabic = "🌱 أول كود C++",
            descriptionArabic = "قمت بتشغيل أول كود وفهمت دالة main",
            iconEmoji = "🌱",
            xpReward = 50
        ),
        Achievement(
            id = "bug_hunter",
            titleArabic = "🐛 صائد الأخطاء",
            descriptionArabic = "اكتشفت وصلّحت 5 أخطاء شائعة بنجاح",
            iconEmoji = "🐛",
            xpReward = 100
        ),
        Achievement(
            id = "streak_3",
            titleArabic = "🔥 شعلة الحماس",
            descriptionArabic = "حافظت على سلسلة تعلم متواصلة لمدة 3 أيام",
            iconEmoji = "🔥",
            xpReward = 150
        ),
        Achievement(
            id = "streak_7",
            titleArabic = "⚡ الانضباط الذهبي",
            descriptionArabic = "سلسلة تعلم متواصلة لمدة 7 أيام",
            iconEmoji = "⚡",
            xpReward = 300
        ),
        Achievement(
            id = "quiz_master",
            titleArabic = "🎯 علامة كاملة",
            descriptionArabic = "اجتزت اختباراً بنتيجة 100% بدون أي خطأ",
            iconEmoji = "🎯",
            xpReward = 150
        ),
        Achievement(
            id = "first_project",
            titleArabic = "💻 أول مشروع عملي",
            descriptionArabic = "أكملت أول مشروع برمجي كامل في C++",
            iconEmoji = "💻",
            xpReward = 200
        ),
        Achievement(
            id = "variable_wizard",
            titleArabic = "📦 سيد المتغيرات",
            descriptionArabic = "أتقنت المتغيرات وأنواع البيانات وحجز الذاكرة",
            iconEmoji = "📦",
            xpReward = 100
        ),
        Achievement(
            id = "loop_master",
            titleArabic = "🔄 فارس الحلقات",
            descriptionArabic = "أتقنت التكرار باستخدام for و while",
            iconEmoji = "🔄",
            xpReward = 150
        ),
        Achievement(
            id = "review_pro",
            titleArabic = "🧠 مراجع بارع",
            descriptionArabic = "أكملت جلسة مراجعة ذكية وعالجت المفاهيم الصعبة",
            iconEmoji = "🧠",
            xpReward = 100
        )
    )
}
