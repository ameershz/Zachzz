package com.example.content

import com.example.domain.model.Quiz
import com.example.domain.model.QuizOption
import com.example.domain.model.QuizQuestion

object QuizzesData {

    val ALL_QUIZZES = listOf(
        // Quiz Level 0
        Quiz(
            id = "quiz_l0_final",
            levelNumber = 0,
            titleArabic = "اختبار شامل: أساسيات ما قبل الكود (المستوى 0)",
            descriptionArabic = "اختبر استيعابك للمفاهيم الأساسية: البرمجة، لغة الآلة، المترجم، والأخطاء.",
            questions = listOf(
                QuizQuestion(
                    id = "q0_1",
                    questionArabic = "ما هي اللغة الوحيدة التي يفهمها معالج الكمبيوتر (CPU) مباشرة؟",
                    options = listOf(
                        QuizOption("لغة الآلة المكونة من النظام الثنائي 0 و 1 (Binary)", true, "المعالج يتكون من ترانزستورات تفهم فقط مرور أو انقطاع التيار (1 و 0)."),
                        QuizOption("اللغة الإنجليزية البسيطة", false, "الكمبيوتر لا يفهم أي لغة بشرية."),
                        QuizOption("لغة HTML", false, "HTML لغة ترميز صفحات وليست لغة المعالج.")
                    ),
                    educationalReason = "المعالج آلة إلكترونية تتعامل مع نبضات كهربائية تمثلها الأصفار والآحاد فقط.",
                    conceptTag = "binary"
                ),
                QuizQuestion(
                    id = "q0_2",
                    questionArabic = "ما الفرق بين وقت الترجمة (Compile Time) ووقت التشغيل (Runtime)؟",
                    options = listOf(
                        QuizOption("Compile Time هو وقت فحص وترجمة الكود، بينما Runtime هو وقت عمل البرنامج الفعلي للمستخدم", true, "بالضبط! الترجمة تسبق التشغيل وتفحص القواعد."),
                        QuizOption("كلاهما يعني نفس الشيء تماماً", false, "مرحلتان منفصلتان تماماً في دورة حياة البرنامج."),
                        QuizOption("Runtime يسبق Compile Time دائماً", false, "لا يمكن تشغيل البرنامج قبل ترجمته أولاً.")
                    ),
                    educationalReason = "المترجم يفحص الكود أولاً في وقت الترجمة، وبعد نجاح البناء يُشغَّل البرنامج في Runtime.",
                    conceptTag = "compiler"
                ),
                QuizQuestion(
                    id = "q0_3",
                    questionArabic = "ما هي الدالة التي يبدأ منها تشغيل أي برنامج C++ إجبارياً؟",
                    options = listOf(
                        QuizOption("main()", true, "الدالة main() هي نقطة الدخول الرسمية لنظام التشغيل."),
                        QuizOption("start()", false, "لا يعترف نظام التشغيل بدالة اسمها start."),
                        QuizOption("begin()", false, "ليست نقطة الدخول في C++.")
                    ),
                    educationalReason = "نظام التشغيل يبحث حصراً عن دالة main لبدء تنفيذ الأوامر من عندها.",
                    conceptTag = "first_program"
                ),
                QuizQuestion(
                    id = "q0_4",
                    questionArabic = "ما نوع الخطأ الذي يحدث عندما ينسى المبرمج فاصلة منقوطة (;)؟",
                    options = listOf(
                        QuizOption("خطأ نحوي (Syntax Error) يكتشفه المترجم في Compile Time", true, "مخالفة لقواعد اللغة الصارمة يمنع المترجم من إكمال البناء."),
                        QuizOption("خطأ تشغيلي (Runtime Error)", false, "البرنامج لم يبدأ بالعمل بعد ليحدث خطأ تشغيلي."),
                        QuizOption("خطأ منطقي (Logic Error)", false, "الخطأ المنطقي يعمل لكن نتيجته غير صحيحة.")
                    ),
                    educationalReason = "الفاصلة المنقوطة قاعدة إملائية أساسية في لغة C++ ومخالفتها تمنع الترجمة.",
                    conceptTag = "semicolon"
                ),
                QuizQuestion(
                    id = "q0_5",
                    questionArabic = "ماذا يعني الرمز 0 المعادة في نهاية برنامج C++: return 0; ؟",
                    options = listOf(
                        QuizOption("البرنامج اكتمل بنجاح تام وبدون أي أخطاء", true, "الرقم 0 متعارف عليه في أنظمة التشغيل كرمز للنجاح الكامل."),
                        QuizOption("يوجد 0 مستخدمين متاحين", false, "لا علاقة له بالمستخدمين."),
                        QuizOption("البرنامج فشل في العمل", false, "أرقام الفشل تكون عادة أرقاماً غير الصفر مثل -1.")
                    ),
                    educationalReason = "نظام التشغيل يستقبل كود الخروج (Exit Code) 0 ليعلم أن المهمة أنجزت بنجاح.",
                    conceptTag = "first_program"
                )
            ),
            xpReward = 80
        ),

        // Quiz Level 1
        Quiz(
            id = "quiz_l1_final",
            levelNumber = 1,
            titleArabic = "اختبار شامل: خطوات C++ الأولى (المستوى 1)",
            descriptionArabic = "قيّم فهمك لأوامر الإخراج cout، الأسهم <<، فواصل الأسطر، والتعليقات.",
            questions = listOf(
                QuizQuestion(
                    id = "q1_1",
                    questionArabic = "أي من التعليمات التالية صحيحة تماماً لطباعة جملة على الشاشة في C++؟",
                    options = listOf(
                        QuizOption("std::cout << \"Hello\";", true, "صحيحة: استخدمت cout والأسهم << والنص بين \"\" والفاصلة المنقوطة ;."),
                        QuizOption("std::cout >> \"Hello\";", false, "خطأ: الأسهم مقلوبة; >> للإدخال."),
                        QuizOption("std::cout << Hello;", false, "خطأ: النص ينقصه علامتي اقتباس \"\"."),
                        QuizOption("cout << \"Hello\"", false, "خطأ: ينقصه فاصلة منقوطة ; في النهاية.")
                    ),
                    educationalReason = "cout تطبع باستخدام أسهم << المتجهة للشاشة مع نص محاط باقتباس مزدوج وفاصلة منقوطة.",
                    conceptTag = "cout_cin"
                ),
                QuizQuestion(
                    id = "q1_2",
                    questionArabic = "كيف تنزل لسطر جديد بعد طباعة نص؟",
                    options = listOf(
                        QuizOption("باستخدام std::endl أو محرف '\\n' داخل النص", true, "كلاهما ينزل لسطر جديد فوراً."),
                        QuizOption("بالضغط على زر مسافة Space في الكيبورد", false, "المسافة لا تنزل سطراً جديداً في الشاشة."),
                        QuizOption("النزول لسطر جديد يحدث تلقائياً دائماً", false, "cout لا تنزل سطراً جديداً بمفردها أبداً.")
                    ),
                    educationalReason = "يجب أن تأمر المترجم صراحة بالنزول لسطر جديد عبر endl أو \\n.",
                    conceptTag = "cout_cin"
                ),
                QuizQuestion(
                    id = "q1_3",
                    questionArabic = "كيف نكتب تعليقاً لسطر واحد في كود C++؟",
                    options = listOf(
                        QuizOption("بكتابة شرطتين مائلتين // في بداية التعليق", true, "المترجم يتجاهل كل ما بعد // حتى نهاية السطر."),
                        QuizOption("بكتابة علامة الشباك #", false, "# مخصصة لتوجيهات المعالج الأولي Preprocessor."),
                        QuizOption("بكتابة علامتي تعجب !!", false, "ليست صيغة تعليق في C++.")
                    ),
                    educationalReason = "// للتعليق الفردي، و /* */ للمتعدد.",
                    conceptTag = "comments"
                ),
                QuizQuestion(
                    id = "q1_4",
                    questionArabic = "ما فائدة السطر using namespace std; في بداية الملف؟",
                    options = listOf(
                        QuizOption("يتيح كتابة cout و endl مباشرة دون تكرار كتابة std:: في كل مرة", true, "يفتح فضاء الأسماء القياسي std للاستخدام المباشر."),
                        QuizOption("يجعل سرعة البرنامج أسرع بعشر مرات", false, "لا يؤثر على سرعة التشغيل."),
                        QuizOption("يقوم بحذف الأخطاء من الكود تلقائياً", false, "لا يحذف الأخطاء.")
                    ),
                    educationalReason = "اختصار برمجي يزيل الحاجة للبادئة std::.",
                    conceptTag = "namespaces"
                )
            ),
            xpReward = 80
        ),

        // Quiz Level 2
        Quiz(
            id = "quiz_l2_final",
            levelNumber = 2,
            titleArabic = "اختبار شامل: المتغيرات وأنواع البيانات (المستوى 2)",
            descriptionArabic = "اختبر معرفتك بأنواع البيانات: int, double, char, string, bool, const وتسمية المتغيرات.",
            questions = listOf(
                QuizQuestion(
                    id = "q2_1",
                    questionArabic = "أي من أنواع البيانات التالية هو الأنسب لتخزين سعر سلعة بدقة (مثلاً 19.99)؟",
                    options = listOf(
                        QuizOption("double", true, "double مخصص للأعداد ذات الكسور العشرية بدقة مضاعفة."),
                        QuizOption("int", false, "int يحذف الجزء العشري نهائياً."),
                        QuizOption("char", false, "char يتسع لحرف واحد فقط."),
                        QuizOption("bool", false, "bool للقيم المنطقية صح أو خطأ فقط.")
                    ),
                    educationalReason = "الأرقام التي تحتوي فواصل عشرية تتطلب double أو float.",
                    conceptTag = "variables"
                ),
                QuizQuestion(
                    id = "q2_2",
                    questionArabic = "ما هي الطريقة الصحيحة لتعريف حرف مفرد وحفظ القيمة 'B' بداخله؟",
                    options = listOf(
                        QuizOption("char grade = 'B';", true, "صحيح: نوع char واقتباس مفرد ' ' وفاصلة منقوطة."),
                        QuizOption("char grade = \"B\";", false, "خطأ: الاقتباس المزدوج \" \" مخصص للنصوص string وليس char."),
                        QuizOption("string grade = 'B';", false, "خطأ: string تتطلب اقتباس مزدوج \" \"."),
                        QuizOption("int grade = 'B';", false, "غير مناسب لتخزين الحروف كرمز.")
                    ),
                    educationalReason = "المحرف الواحد في C++ يحاط دائماً بعلامتي اقتباس مفردتين ' '.",
                    conceptTag = "variables"
                ),
                QuizQuestion(
                    id = "q2_3",
                    questionArabic = "ماذا تفعل الكلمة المفتاحية const عند وضعها قبل نوع المتغير؟",
                    options = listOf(
                        QuizOption("تجعل المتغير ثابتاً غير قابل للتعديل لاحقاً في أي مكان في البرنامج", true, "تضع قفلاً لحماية القيمة من أي تعديل مستقبلي."),
                        QuizOption("تقوم بمسح المتغير من الذاكرة", false, "لا تمسحه."),
                        QuizOption("تضاعف قيمته تلقائياً", false, "لا تضاعف قيمته.")
                    ),
                    educationalReason = "const تحمي الثوابت الرياضية والفيزيائية والحدود القصوى من التغيير بالخطأ.",
                    conceptTag = "constants"
                ),
                QuizQuestion(
                    id = "q2_4",
                    questionArabic = "أي من أسماء المتغيرات التالية يعتبر غير قانوني ويرفضه المترجم؟",
                    options = listOf(
                        QuizOption("2ndPlayer", true, "غير قانوني: اسم المتغير لا يجوز إطلاقاً أن يبدأ برقم."),
                        QuizOption("player2", false, "قانوني وصحيح."),
                        QuizOption("_secretScore", false, "قانوني، يجوز البدء بشرطة سفلية _."),
                        QuizOption("userAge", false, "قانوني ومكتوب بأسلوب camelCase الممتاز.")
                    ),
                    educationalReason = "قاعدة نحوية صارمة: أسماء المتغيرات تبدأ بحرف إنجليزي أو _ ولا تبدأ برقم أبداً.",
                    conceptTag = "naming_rules"
                )
            ),
            xpReward = 80
        ),

        // Quiz Level 3
        Quiz(
            id = "quiz_l3_final",
            levelNumber = 3,
            titleArabic = "اختبار شامل: العمليات والإدخال (المستوى 3)",
            descriptionArabic = "فحص متقدم للعمليات الحسابية، باقي القسمة %، ترتيب الأولويات، وأمر cin.",
            questions = listOf(
                QuizQuestion(
                    id = "q3_1",
                    questionArabic = "ما هو ناتج العملية التالية في C++: 10 / 4 ؟",
                    options = listOf(
                        QuizOption("2", true, "لأن كلا الرقمين صحيحان (int)، فيتم قطع الكسر وتكون النتيجة 2 فقط!"),
                        QuizOption("2.5", false, "لتكون 2.5 يجب كتابة 10.0 / 4."),
                        QuizOption("2.25", false, "خطأ حسابي."),
                        QuizOption("0", false, "غير صحيح.")
                    ),
                    educationalReason = "قسمة الأعداد الصحيحة في C++ تسقط الجزء العشري دائماً.",
                    conceptTag = "operators"
                ),
                QuizQuestion(
                    id = "q3_2",
                    questionArabic = "ما هو ناتج المعادلة: 10 + 2 * 5 ؟",
                    options = listOf(
                        QuizOption("20", true, "أولوية الضرب تسبق الجمع: 2 * 5 = 10، ثم 10 + 10 = 20."),
                        QuizOption("60", false, "الجمع لم يوضع داخل أقواس ليسبق الضرب."),
                        QuizOption("25", false, "خطأ حسابي."),
                        QuizOption("100", false, "خطأ حسابي.")
                    ),
                    educationalReason = "أولويات العمليات: الضرب والقسمة قبل الجمع والطرح ما لم توجد أقواس ().",
                    conceptTag = "operators"
                ),
                QuizQuestion(
                    id = "q3_3",
                    questionArabic = "ما الفرق بين الأسهم مع cout والأسهم مع cin؟",
                    options = listOf(
                        QuizOption("cout تستخدم << المتجهة للشاشة (يسار)، بينما cin تستخدم >> المتجهة للمتغير (يمين)", true, "صحيح تماماً، تمثل اتجاه تدفق البيانات."),
                        QuizOption("كلاهما يستخدمان نفس الأسهم <<", false, "خطأ، cin تستخدم >>."),
                        QuizOption("cin لا تستخدم أي أسهم", false, "cin تستخدم معامل الاستخراج >>.")
                    ),
                    educationalReason = "cout << بيانات للشاشة | cin >> بيانات للمتغير.",
                    conceptTag = "cout_cin"
                )
            ),
            xpReward = 80
        )
    )
}
