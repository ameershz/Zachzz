package com.example.content

import com.example.domain.model.CodeBlock
import com.example.domain.model.CommonMistake
import com.example.domain.model.InteractiveToken
import com.example.domain.model.Lesson
import com.example.domain.model.LessonSummaryPoint
import com.example.domain.model.VisualAnalogy

object Level1Content {

    val lessons = listOf(
        // L1_1
        Lesson(
            id = "l1_1",
            levelNumber = 1,
            lessonNumber = 1,
            titleArabic = "تشريح السطر الأول: #include <iostream>",
            titleEnglish = "Dissecting #include <iostream>",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "في كل برنامج C++ تقريباً ستجد السطر الأول: #include <iostream>. لماذا لا يمكننا الاستغناء عنه؟",
            detailedExplanation = "لغة C++ مصممة لتكون خفيفة وسريعة جداً. لذلك، هي لا تقوم بتحميل جميع الأدوات في الذاكرة افتراضياً.\n\nإذا أردت استخدام الشاشة أو قراءة المفاتيح، يجب أن تخبر المترجم بإحضار 'صندوق الأدوات' الخاص بذلك.\n\nعلامة الشباك # تعني أن هذا أمر للمعالج الأولي (Preprocessor Directive) قبل بدء الترجمة.\nكلمة include تعني 'ضمِّن' أو 'أحضر'.\nوكلمة iostream تعني (Input Output Stream - سيل المدخلات والمخرجات).\nبدون هذا السطر، لن يعرف المترجم ما هو cout أو cin!",
            visualAnalogy = VisualAnalogy(
                title = "حقيبة الأدوات 🧰",
                analogyArabic = "مثل استدعاء فني تصليح؛ قبل أن يبدأ العمل يحتاج إحضار حقيبة مفاتيح الربط المخصصة.",
                realTechExplanation = "#include تُدرج ملف الترويسة Header File الذي يحتوي على تعريفات دوال الطباعة والإدخال."
            ),
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>",
                    explanation = "تضمين مكتبة الإدخال والإخراج الأساسية في C++.",
                    interactiveTokens = listOf(
                        InteractiveToken("#include", "توجيه تضمين", "يأمر المعالج الأولي بضم محتويات ملف خارجي.", true),
                        InteractiveToken("<iostream>", "ملف الترويسة القياسي", "يحوي تعريفات cout و cin و endl.", false)
                    )
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("📦", "C++ نظيفة وخفيفة ولا تُحمل إلا ما تطلبه صراحة."),
                LessonSummaryPoint("#", "علامة # تعني تعليمات للمعالج الأولي Preprocessor."),
                LessonSummaryPoint("📺", "iostream هي بوابة التواصل مع الشاشة ولوحة المفاتيح.")
            ),
            exerciseIds = listOf("ex_l1_1")
        ),

        // L1_2
        Lesson(
            id = "l1_2",
            levelNumber = 1,
            lessonNumber = 2,
            titleArabic = "تشريح الدالة الرئيسية: int main()",
            titleEnglish = "Dissecting the main() Function",
            estimatedMinutes = 7,
            xpReward = 45,
            introduction = "لماذا سميت main؟ ولماذا يسبقها int وماذا تعني الأقواس؟",
            detailedExplanation = "الدالة (Function) في البرمجة هي مصنع أو مهمة مجمعة لها بداية ونهاية.\n\n1. كلمة int: اختصار Integer (عدد صحيح). تعني أن هذه الدالة ستعطي نتيجة رقمية لنظام التشغيل عند انتهائها.\n2. كلمة main: هي الاسم المحجوز الذي يبحث عنه نظام التشغيل كنقطة دخول (Entry Point). لا يمكنك تسميتها start أو begin، يجب أن تكون main!\n3. الأقواس (): مخصصة لاستقبال مدخلات (Parameters)، وهنا فارغة لأننا لا نمرر شيئاً من سطر الأوامر.\n4. القوسان {}: يمثلان سور الحديقة! كل الأوامر التي تريد تنفيذها يجب أن تكون محصورة بين { في البداية و } في النهاية.\n5. return 0;: تعني أن المهمة انتهت بنجاح كامل دون مشاكل، والرقم 0 عالمياً في أنظمة التشغيل يعني (No Errors).",
            codeBlocks = listOf(
                CodeBlock(
                    code = "int main() {\n    // أوامرك هنا\n    return 0;\n}",
                    explanation = "الهيكل الأساسي للدالة الرئيسية في C++.",
                    interactiveTokens = listOf(
                        InteractiveToken("int", "نوع القيمة المعادة", "تحدد أن الدالة تعيد رقماً صحيحاً لنظام التشغيل.", true),
                        InteractiveToken("main", "اسم الدالة", "نقطة البداية الإجبارية للبرنامج.", false),
                        InteractiveToken("()", "أقواس المعاملات", "لتمرير معاملات للدالة.", false),
                        InteractiveToken("{", "بداية الدالة", "يفتح نطاق الأوامر التابعة لـ main.", false),
                        InteractiveToken("return 0;", "إنهاء بنجاح", "يخبر نظام التشغيل بأن البرنامج انتهى بدون أي خطأ.", true),
                        InteractiveToken("}", "نهاية الدالة", "يغلق نطاق الدالة.", false)
                    )
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🚪", "main() هي البوابة الوحيدة التي يدخل منها المعالج لبرنامجك."),
                LessonSummaryPoint("🧱", "الأقواس {} تحصر الأوامر البرمجية بدقة."),
                LessonSummaryPoint("✅", "return 0; هي رسالة طمأنينة لنظام التشغيل.")
            ),
            exerciseIds = listOf("ex_l1_2")
        ),

        // L1_3
        Lesson(
            id = "l1_3",
            levelNumber = 1,
            lessonNumber = 3,
            titleArabic = "سحر الطباعة: std::cout ومعامل الإرسال <<",
            titleEnglish = "std::cout and the Stream Insertion Operator",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "كيف يخرج النص من الكود ويظهر أمام عينيك على الشاشة؟",
            detailedExplanation = "كلمة cout تنطق 'سي-أوت' (See-Out)، وهي اختصار لـ Character Output.\n\nتخيل الشاشة كأنبوب مفتوح؛ ومعامل الإرسال << يشبه سهمين يرميان الكلام داخل هذا الأنبوب!\n\nلاحظ اتجاه الأسهم: << تتجه نحو اليسار باتجاه cout، وكأنها تقول: 'خذ هذا النص وادفعه إلى الشاشة!'.\n\nإذا أردت طباعة نص حرفي، يجب أن تضعه بين علامتي تنصيص مزدوجتين \"نصك هنا\"، وإلا سيعتقد المترجم أنه أمر برمجي ويبحث عنه ويفشل.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n\nint main() {\n    std::cout << \"مرحباً بكم في عالم C++!\";\n    return 0;\n}",
                    explanation = "طباعة جملة ترحيبية على شاشة الكونسول.",
                    interactiveTokens = listOf(
                        InteractiveToken("std::cout", "كائن الإخراج", "الأداة الموجهة للشاشة.", false),
                        InteractiveToken("<<", "معامل الإرسال", "يدفع البيانات باتجاه كائن الإخراج.", false),
                        InteractiveToken("\"مرحباً بكم في عالم C++!\"", "نص حرفي (String)", "النص المطلوب طباعته كما هو.", false)
                    ),
                    expectedOutput = "مرحباً بكم في عالم C++!"
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "عكس اتجاه الأسهم",
                    incorrectCode = "std::cout >> \"Hello\";",
                    correctCode = "std::cout << \"Hello\";",
                    whyItHappens = "يخلط المبتدئ بين أسهم الإخراج << وأسهم الإدخال >>.",
                    howToFix = "تذكر: cout تدفع البيانات للشاشة نحو اليسار <<."
                ),
                CommonMistake(
                    title = "نسيان علامات الاقتباس للنصوص",
                    incorrectCode = "std::cout << Hello;",
                    correctCode = "std::cout << \"Hello\";",
                    whyItHappens = "يحاول المترجم البحث عن متغير اسمه Hello ولا يجده.",
                    howToFix = "أي نص تريده كما هو ضعه دائماً بين \" \"."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("📺", "std::cout هو ممثل الشاشة في C++."),
                LessonSummaryPoint("⬅️", "الأسهم << تدفع البيانات من اليمين إلى الشاشة على اليسار."),
                LessonSummaryPoint("🔤", "النصوص الحرفية توضع دوماً بين علامتي تنصيص \" \".")
            ),
            exerciseIds = listOf("ex_l1_3")
        ),

        // L1_4
        Lesson(
            id = "l1_4",
            levelNumber = 1,
            lessonNumber = 4,
            titleArabic = "الفاصلة المنقوطة (;) حارس القواعد",
            titleEnglish = "The Semicolon (;)",
            estimatedMinutes = 5,
            xpReward = 45,
            introduction = "أكثر خطأ يقع فيه المبتدئ والمحترف في C++ هو نسيان هذه النقطة ذات الذيل الصغير: ;",
            detailedExplanation = "في اللغة العربية نضع نقطة في نهاية الجملة لنفهم أنها اكتملت.\nفي C++، لا يهتم المترجم إذا ضغطت زر Enter ونزلت لسطر جديد؛ يمكنك كتابة البرنامج كله في سطر واحد ولن يعترض المترجم!\n\nالعلامة الوحيدة التي تخبر المترجم 'هذا الأمر انتهى ابدأ بالذي يليه' هي الفاصلة المنقوطة (;).\n\nإذا نسيتها، سيحاول المترجم قراءة السطر التالي كجزء من السطر الحالي، ويتعثر ويظهر خطأ: expected ';' before ...",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n\nint main() {\n    std::cout << \"السطر الأول\";\n    std::cout << \"السطر الثاني\";\n    return 0;\n}",
                    explanation = "كل أمر ينتهي بفاصلة منقوطة مستقلة.",
                    expectedOutput = "السطر الأولالسطر الثاني"
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "وضع فاصلة منقوطة بعد int main() مباشرة",
                    incorrectCode = "int main(); {\n    std::cout << \"خطأ\";\n}",
                    correctCode = "int main() {\n    std::cout << \"صحيح\";\n}",
                    whyItHappens = "يظن المبرمج أن كل سطر يحتاج فاصلة منقوطة.",
                    howToFix = "الفاصلة المنقوطة توضع في نهاية الأوامر التنفيذية، وليس بعد رؤوس الدوال {} أو التوجيهات #include."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🛑", "الفاصلة المنقوطة هي إشارة المرور الحمراء لنهاية التعليمة."),
                LessonSummaryPoint("⚠️", "المترجم أعمى عن السطور الجديدة، يعتمد فقط على ;."),
                LessonSummaryPoint("🚫", "لا تضع ; بعد main() أو بعد #include.")
            ),
            exerciseIds = listOf("ex_l1_4")
        ),

        // L1_5
        Lesson(
            id = "l1_5",
            levelNumber = 1,
            lessonNumber = 5,
            titleArabic = "النزول لسطر جديد: std::endl ومحرف \\n",
            titleEnglish = "New Lines: std::endl and \\n",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "في الدرس السابق لاحظنا أن السطرين طُبعا ملتصقين معاً! كيف ننزل لسطر جديد؟",
            detailedExplanation = "أمر cout لا ينزل لسطر جديد تلقائياً بعد الطباعة. إذا أردت ذلك، لديك طريقتان رائعتا:\n\n1. استخدام std::endl (اختصار End Line):\nstd::cout << \"مرحبا\" << std::endl;\nتقوم بالنزول لسطر جديد وتقوم بتفريغ ذاكرة التخزين المؤقت للشاشة فوراً (Flush).\n\n2. استخدام محرف الهروب (Escape Character) وهو \\n:\nstd::cout << \"مرحبا\\n\";\nيُكتب داخل النص مباشرة، وعندما يراه المعالج ينزل سطر فوري.\n\nكلاهما صحيح، و \\n أسرع قليلاً في الأداء في البرامج الكبيرة.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n\nint main() {\n    std::cout << \"السطر الأول\" << std::endl;\n    std::cout << \"السطر الثاني\\n\";\n    std::cout << \"السطر الثالث\";\n    return 0;\n}",
                    explanation = "استخدام endl و \\n للنزول لسطر جديد.",
                    interactiveTokens = listOf(
                        InteractiveToken("std::endl", "إنهاء السطر", "ينزل لسطر جديد ويفرغ الذاكرة المؤقتة للشاشة.", false),
                        InteractiveToken("\"\\n\"", "محرف سطر جديد", "رمز خاص داخل النص يمثل النزول لسطر جديد.", false)
                    ),
                    expectedOutput = "السطر الأول\nالسطر الثاني\nالسطر الثالث"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("↩️", "cout تطبع في نفس السطر حتى تأمرها بالنزول صراحة."),
                LessonSummaryPoint("1️⃣", "std::endl يضاف عبر أسهم << خارج النص."),
                LessonSummaryPoint("2️⃣", "\\n يكتب داخل النص بين علامتي \" \".")
            ),
            exerciseIds = listOf("ex_l1_5")
        ),

        // L1_6
        Lesson(
            id = "l1_6",
            levelNumber = 1,
            lessonNumber = 6,
            titleArabic = "دمج وسلسلة الطباعة (Chaining)",
            titleEnglish = "Chaining Output Streams",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "بدل أن تكتب std::cout في كل سطر، يمكنك ربط عدة نصوص وأرقام معاً في أمر واحد كقطار سريع!",
            detailedExplanation = "تسمح لغة C++ بربط معاملات << متتالية وراء بعضها، وهذا يسمى (Stream Chaining).\n\nمثال:\nstd::cout << \"الاسم: \" << \"علي\" << \" | العمر: \" << 20 << std::endl;\n\nيقوم المترجم بقراءتها من اليسار إلى اليمين ويطبعها تباعاً بسلاسة تامة دون الحاجة لتكرار std::cout في كل مرة.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n\nint main() {\n    std::cout << \"النتيجة هي: \" << 100 << \" من 100!\" << std::endl;\n    return 0;\n}",
                    explanation = "دمج نصوص وأرقام في أمر طباعة واحد.",
                    expectedOutput = "النتيجة هي: 100 من 100!"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🔗", "يمكنك استخدام << عدة مرات متتالية في نفس الأمر."),
                LessonSummaryPoint("🚂", "تُنفذ البيانات بالترتيب من اليسار إلى اليمين."),
                LessonSummaryPoint("✨", "يجعل الكود أكثر نظافة واحترافية.")
            ),
            exerciseIds = listOf("ex_l1_6")
        ),

        // L1_7
        Lesson(
            id = "l1_7",
            levelNumber = 1,
            lessonNumber = 7,
            titleArabic = "التعليقات (Comments): رسائل للمبرمجين",
            titleEnglish = "Comments in C++",
            estimatedMinutes = 5,
            xpReward = 40,
            introduction = "كيف تترك ملاحظات لنفسك أو لزملائك داخل الكود دون أن يراها أو ينفذها الكمبيوتر؟",
            detailedExplanation = "التعليق (Comment) هو نص يكتبه المبرمج لتوضيح الفكرة أو شرح خطوة معقدة.\nعندما يبدأ المترجم بفحص الملف، فإنه يتجاهل التعليقات تماماً وكأنها غير موجودة!\n\nأنواع التعليقات في C++:\n1. تعليق سطر واحد: يبدأ بشرطتين مائلتين // وكل ما بعدهما في نفس السطر يتجاهله المترجم.\n// هذا تعليق يشرح دالة main\n\n2. تعليق متعدد الأسطر: يبدأ بـ /* وينتهي بـ */\n/* هذا تعليق طويل\nيمتد على أكثر من سطر\nمفيد للملاحظات الكبيرة */",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n\nint main() {\n    // هذا تعليق سطر واحد لا يؤثر على البرنامج\n    std::cout << \"كود حقيقي يعمل!\\n\";\n    \n    /* تعليق\n       متعدد الأسطر */\n    return 0;\n}",
                    explanation = "التعليقات يتجاهلها المترجم تماماً ولا تظهر في المخرجات.",
                    expectedOutput = "كود حقيقي يعمل!"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("💬", "التعليقات لشرح الكود للإنسان ولا ينفذها الكمبيوتر."),
                LessonSummaryPoint("//", "تستخدم لتعليق سطر واحد."),
                LessonSummaryPoint("/* */", "تستخدم لتعليق مجموعة أسطر كاملة.")
            ),
            exerciseIds = listOf("ex_l1_7")
        ),

        // L1_8
        Lesson(
            id = "l1_8",
            levelNumber = 1,
            lessonNumber = 8,
            titleArabic = "فضاء الأسماء: using namespace std;",
            titleEnglish = "using namespace std;",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "هل تعبت من كتابة std:: قبل cout و endl في كل سطر؟ هناك اختصار يريحك!",
            detailedExplanation = "في المشاريع الكبيرة، قد يكتب عدة مبرمجين دوال بنفس الاسم. لتجنب التشويش والتصادم، تقسم C++ الأدوات إلى غرف مغلقة تسمى فضاءات أسماء (Namespaces).\n\nغرفة الأدوات القياسية اسمها std.\nإذا كتبت في بداية البرنامج:\nusing namespace std;\n\nفأنت تقول للمترجم: 'افتح لي غرفة std القياسية واجعل كل ما فيها متاحاً دون الحاجة لكتابة std:: في كل مرة!'.\nبعد هذا السطر، يمكنك كتابة cout و cin و endl مباشرة.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << \"لاحظ: نكتب cout مباشرة بدون std:: !\" << endl;\n    return 0;\n}",
                    explanation = "استخدام using namespace std للاختصار وسهولة القراءة.",
                    interactiveTokens = listOf(
                        InteractiveToken("using namespace std;", "استدعاء فضاء الأسماء", "يجعل جميع عناصر المكتبة القياسية متاحة مباشرة في الملف.", true),
                        InteractiveToken("cout", "كائن الإخراج", "متاح مباشرة بدون std::", false),
                        InteractiveToken("endl", "إنهاء السطر", "متاح مباشرة بدون std::", false)
                    ),
                    expectedOutput = "لاحظ: نكتب cout مباشرة بدون std:: !"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🏷️", "Namespaces تمنع تضارب الأسماء في البرامج الضخمة."),
                LessonSummaryPoint("✂️", "using namespace std تختصر الكود وتزيل الحاجة لـ std::."),
                LessonSummaryPoint("💡", "شائعة وممتازة جداً في مرحلة التعلم والمسابقات البرمجية.")
            ),
            exerciseIds = listOf("ex_l1_8")
        ),

        // L1_9
        Lesson(
            id = "l1_9",
            levelNumber = 1,
            lessonNumber = 9,
            titleArabic = "المسافات والترتيب الجمالي (Code Indentation)",
            titleEnglish = "Clean Code & Indentation",
            estimatedMinutes = 5,
            xpReward = 45,
            introduction = "الفرق بين المبرمج الهاوي والمحترف يظهر في نظافة وترتيب الكود!",
            detailedExplanation = "المترجم لا يهتم بالمسافات؛ يمكنك كتابة الكود كله ملتصقاً، لكن زميلك المبرمج (وأنت بعد شهر!) لن تستطيع قراءته!\n\nالإزاحة البادئة (Indentation) هي ترك 4 مسافات (أو ضغطة Tab واحدة) داخل كل قوسين {}.\n\nقواعد ذهبية لنظافة الكود:\n1. كل ما هو داخل دالة يجب إزاحته 4 مسافات لليمين.\n2. اترك سطراً فارغاً بين الأقسام المنطقية.\n3. ضع مسافة قبل وبعد المعاملات مثل << و = لراحة العين.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    // كود نظيف ومرتب ومقروء بسهولة\n    cout << \"كود احترافي يسهل صيانته!\" << endl;\n    return 0;\n}",
                    explanation = "تنسيق الكود بإزاحة بادئة مريحة للعين.",
                    expectedOutput = "كود احترافي يسهل صيانته!"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("📐", "الكود النظيف يوفر ساعات طويلة من البحث عن الأخطاء."),
                LessonSummaryPoint("⇥", "استخدم 4 مسافات (Tab) داخل كل كتلة برمجية {}."),
                LessonSummaryPoint("👁️", "اجعل كودك مريحاً للعين وسهل الفهم لغيرك.")
            ),
            exerciseIds = listOf("ex_l1_9")
        ),

        // L1_10
        Lesson(
            id = "l1_10",
            levelNumber = 1,
            lessonNumber = 10,
            titleArabic = "مشروع المستوى 1: بطاقة تعريف شخصية كاملة 🪪",
            titleEnglish = "Level 1 Project: Personal Profile Card",
            estimatedMinutes = 10,
            xpReward = 70,
            introduction = "حان وقت التطبيق الشامل! سنقوم بدمج كل ما تعلمناه في المستوى 1 لبناء بطاقة بروفايل مبرمج احترافية تظهر على الشاشة.",
            detailedExplanation = "سنستخدم:\n- #include <iostream>\n- using namespace std;\n- دمج النصوص مع <<\n- فواصل الأسطر endl و \\n\n- إطارات نصية زخرفية باستخدام الرموز.\n\nشاهد الكود وجرّب تشغيله والتعديل عليه!",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << \"=================================\" << endl;\n    cout << \"       بطاقة مبرمج C++           \" << endl;\n    cout << \"=================================\" << endl;\n    cout << \"الاسم: \" << \"أحمد المطوّر\" << endl;\n    cout << \"المستوى: \" << 1 << \" (مستكشف مبتدئ)\" << endl;\n    cout << \"الهدف: \" << \"احتراف C++ وصناعة الألعاب!\" << endl;\n    cout << \"=================================\" << endl;\n    return 0;\n}",
                    explanation = "برنامج متكامل يطبع بطاقة هوية مبرمج منسقة بشكل جميل.",
                    expectedOutput = "=================================\n       بطاقة مبرمج C++           \n=================================\nالاسم: أحمد المطوّر\nالمستوى: 1 (مستكشف مبتدئ)\nالهدف: احتراف C++ وصناعة الألعاب!\n================================="
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🏆", "أكملت المستوى الأول بنجاح باهر!"),
                LessonSummaryPoint("💪", "أصبحت قادراً على كتابة برامج حقيقية والتحكم في مخرجات الشاشة بدقة."),
                LessonSummaryPoint("🔜", "في المستوى القادم: سندخل عالم المتغيرات والذاكرة وحفظ البيانات!")
            ),
            exerciseIds = listOf("ex_l1_10"),
            quizId = "quiz_l1_final"
        )
    )
}
