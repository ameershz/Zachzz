package com.example.content

import com.example.domain.model.CodeBlock
import com.example.domain.model.CommonMistake
import com.example.domain.model.InteractiveToken
import com.example.domain.model.Lesson
import com.example.domain.model.LessonSummaryPoint
import com.example.domain.model.VisualAnalogy

object Level2Content {

    val lessons = listOf(
        // L2_1
        Lesson(
            id = "l2_1",
            levelNumber = 2,
            lessonNumber = 1,
            titleArabic = "ما هو المتغير (Variable) في الذاكرة الحقيقية؟",
            titleEnglish = "What is a Variable in RAM?",
            estimatedMinutes = 7,
            xpReward = 50,
            introduction = "في العالم الحقيقي، إذا أردت الاحتفاظ برقم هاتف أو سعر وجبة، تكتبه في ورقة أو تحفظه في ذاكرتك. كيف يفعل الكمبيوتر ذلك؟",
            detailedExplanation = "ذاكرة الكمبيوتر (RAM) عبارة عن مليارات الخانات الصغيرة المرقمة بعناوين رقمية معقدة في الهيكسادسيمال مثل 0x7ffd5a.\n\nمن المستحيل أن تحفظ هذه العناوين! لذلك اخترعنا (المتغيرات):\nالمتغير هو ببساطة 'اسم رمزي سهل' نطلقه على مساحة محجوزة في الذاكرة، لنضع بداخلها قيمة ونسترجعها متى شئنا!\n\nلكل متغير 3 أشياء أساسية:\n1. نوع البيانات (Data Type): يحدد حجم المساحة المحجوزة ونوع ما يمكن وضعه داخلها.\n2. اسم المتغير (Identifier): الاسم الذي تناديه به في الكود.\n3. القيمة (Value): المحتوى المخزن بداخله حالياً.",
            visualAnalogy = VisualAnalogy(
                title = "صندوق التخزين الملصق عليه اسم 📦",
                analogyArabic = "تخيل صندوقاً مخصصاً للملابس الشتوية ملصق عليه ملصق 'WinterClothes'. الصندوق هو المساحة في الذاكرة، والملصق هو اسم المتغير، والملابس هي القيمة المخزنة.",
                realTechExplanation = "المتغير يحجز بايتات محددة في الـ RAM ويعطيك اسماً سهلاً للوصول إليها بدلاً من العنوان العتادي."
            ),
            codeBlocks = listOf(
                CodeBlock(
                    code = "int age = 20;",
                    explanation = "إنشاء متغير لحفظ العمر بالرقم 20.",
                    interactiveTokens = listOf(
                        InteractiveToken("int", "نوع البيانات (Data Type)", "يحدد أن هذا المتغير مخصص لتخزين أعداد صحيحة ويحجز 4 بايت في الذاكرة.", true),
                        InteractiveToken("age", "اسم المتغير (Variable Name)", "الاسم الذي نختاره لنميز هذه المساحة في الذاكرة ونصل لقيمتها.", false),
                        InteractiveToken("=", "عامل الإسناد (Assignment Operator)", "يأخذ القيمة من جهة اليمين ويخزنها داخل المتغير في اليسار.", false),
                        InteractiveToken("20", "القيمة المخزنة (Value)", "البيانات الفعلية التي يتم حفظها في الذاكرة.", false),
                        InteractiveToken(";", "الفاصلة المنقوطة (Semicolon)", "تعلن للمترجم اكتمال أمر إنشاء المتغير وإسناد القيمة.", false)
                    )
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("💾", "المتغير هو مساحة محجوزة باسم مفهوم داخل ذاكرة RAM."),
                LessonSummaryPoint("3️⃣", "لكل متغير: نوع محدد، اسم فريد، وقيمة مخزنة."),
                LessonSummaryPoint("📦", "النوع يحدد حجم الصندوق، والاسم يحدد العنوان، والقيمة هي ما بداخل الصندوق.")
            ),
            exerciseIds = listOf("ex_l2_1")
        ),

        // L2_2
        Lesson(
            id = "l2_2",
            levelNumber = 2,
            lessonNumber = 2,
            titleArabic = "الأعداد الصحيحة: نوع int وحدوده",
            titleEnglish = "Integers: The int Type",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "عندما تتعامل مع أعمار، درجات، عدد لاعبين، أو عملات دون كسور، نوعك المفضل هو int!",
            detailedExplanation = "كلمة int اختصار لـ Integer.\nفي معظم الأجهزة الحديثة، يحجز int مساحة قدرها 4 بايت (32 بت) في الذاكرة.\n\nبما أن المساحة 32 بت، فهو يستطيع تخزين أرقام موجبة وسالبة تتراوح بين:\n-2,147,483,648 إلى +2,147,483,647 (أكثر من ملياري رقم!).\n\nإذا حاولت تخزين كسر عشري داخل int (مثل 5.9)، فلن يعترض المترجم، لكنه سيقوم بحذف الكسر تماماً وتخزين 5 فقط دون تقريب! وهذا يسمى (Truncation).",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int score = 150;\n    int health = -25;\n    cout << \"النقاط: \" << score << endl;\n    cout << \"الصحة: \" << health << endl;\n    return 0;\n}",
                    explanation = "تعريف متغيرات عددية صحيحة موجبة وسالبة وطباعتها.",
                    expectedOutput = "النقاط: 150\nالصحة: -25"
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "محاولة تخزين كسور في int",
                    incorrectCode = "int price = 19.99;\ncout << price;",
                    correctCode = "double price = 19.99;\ncout << price;",
                    whyItHappens = "المتغير int يحذف الجزء العشري نهائياً وتصبح القيمة 19 بدلاً من 19.99.",
                    howToFix = "استخدم double أو float للأرقام ذات الكسور العشرية."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🔢", "int مخصص للأعداد الصحيحة بدون فواصل عشرية."),
                LessonSummaryPoint("📏", "حجمه غالباً 4 بايت (32 بت)."),
                LessonSummaryPoint("✂️", "إذا أدخلت كسراً لـ int فسيتم قطعه وتجاهله.")
            ),
            exerciseIds = listOf("ex_l2_2")
        ),

        // L2_3
        Lesson(
            id = "l2_3",
            levelNumber = 2,
            lessonNumber = 3,
            titleArabic = "الأعداد العشرية: double و float",
            titleEnglish = "Floating-Point Numbers: double & float",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "الأسعار، درجات الحرارة، ونتائج المعادلات العلمية تحتاج فواصل عشرية دقيقة. هنا نستخدم double!",
            detailedExplanation = "هناك نوعان للأعداد العشرية في C++:\n\n1. float (دقة فردية):\n- يحجز 4 بايت في الذاكرة.\n- دقيق حتى 7 خانات عشرية تقريباً.\n\n2. double (دقة مضاعفة - Double Precision):\n- يحجز 8 بايت في الذاكرة.\n- دقيق جداً حتى 15-16 خانة عشرية!\n\nفي عالم C++ الحديث، يعتبر double هو المعيار الافتراضي الموصى به دائماً لأنه أكثر دقة ويمنع أخطاء التقريب الحسابية.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    double pi = 3.14159;\n    double temperature = 36.6;\n    cout << \"قيمة باي التقريبية: \" << pi << endl;\n    cout << \"درجة الحرارة: \" << temperature << endl;\n    return 0;\n}",
                    explanation = "استخدام double لتخزين أرقام بكسور عشرية بدقة عالية.",
                    expectedOutput = "قيمة باي التقريبية: 3.14159\nدرجة الحرارة: 36.6"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🎯", "double هو الخيار القياسي للأرقام ذات الفواصل العشرية."),
                LessonSummaryPoint("8️⃣", "يحجز 8 بايت ويوفر دقة تصل إلى 15 رقماً عشرياً."),
                LessonSummaryPoint("⚡", "float يحجز 4 بايت ويستخدم في معالجة الرسوميات لتوفير المساحة.")
            ),
            exerciseIds = listOf("ex_l2_3")
        ),

        // L2_4
        Lesson(
            id = "l2_4",
            levelNumber = 2,
            lessonNumber = 4,
            titleArabic = "المحارف: نوع char والأقواس الفردية ''",
            titleEnglish = "Characters: The char Type",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "إذا أردت تخزين حرف واحد فقط مثل 'A' أو علامة '+', نوع char هو الحل.",
            detailedExplanation = "كلمة char اختصار لـ Character.\nيحجز بايت واحد فقط (8 بت) في الذاكرة.\n\nقاعدة صارمة في C++:\n- الحرف الواحد يوضع حصراً بين علامتي اقتباس مفردتين: 'A'\n- لا تخلط بينه وبين النص \"A\" الذي يوضع بين اقتباس مزدوج!\n\nفي الحقيقة، المعالج لا يفهم الحروف بل يخزن رقم كود الرمز (ASCII Code)، مثلاً الحرف 'A' يخزن كالرقم 65 في الذاكرة!",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    char grade = 'A';\n    char symbol = '#';\n    cout << \"تقدير الطالب: \" << grade << endl;\n    cout << \"الرمز المختار: \" << symbol << endl;\n    return 0;\n}",
                    explanation = "تخزين حروف مفردة باستخدام char وعلامات الاقتباس الفردية ''.",
                    expectedOutput = "تقدير الطالب: A\nالرمز المختار: #"
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "استخدام علامات تنصيص مزدوجة مع char",
                    incorrectCode = "char rank = \"A\";",
                    correctCode = "char rank = 'A';",
                    whyItHappens = "المترجم يرى \"A\" كسلسلة نصية متعددة الحروف منتهية بـ null، بينما char يتسع لحرف واحد فقط.",
                    howToFix = "استخدم دائماً ' ' الفردية مع char."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🔤", "char يحفظ حرفاً أو رمزاً واحداً فقط."),
                LessonSummaryPoint("1️⃣", "يحجز بايت واحد فقط في الذاكرة."),
                LessonSummaryPoint("''", "يُحاط دائماً باقتباس مفرد ' ' وليس مزدوج \" \".")
            ),
            exerciseIds = listOf("ex_l2_4")
        ),

        // L2_5
        Lesson(
            id = "l2_5",
            levelNumber = 2,
            lessonNumber = 5,
            titleArabic = "النصوص: string وسلاسل الكلمات",
            titleEnglish = "Strings: Working with Text",
            estimatedMinutes = 7,
            xpReward = 50,
            introduction = "الأسماء والعناوين والجمل لا تكفيها حروف مفردة، بل نحتاج إلى سلاسل نصية كاملة!",
            detailedExplanation = "في C++ نستخدم std::string للتعامل مع النصوص.\nكلمة string تعني 'سلسلة أو خيط' لأنها تشبه خيطاً نظمت فيه حروفاً وراء بعضها!\n\nلإتاحة دوال النصوص كاملة، نستدعي مكتبة الترويسة #include <string>.\n\nتُحاط النصوص بعلامات اقتباس مزدوجة \" \" ويمكنك دمج النصوص بسهولة باستخدام علامة الزائد (+).",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    string firstName = \"سارة\";\n    string message = \" مرحباً بك في C++!\";\n    string fullGreeting = firstName + message;\n    cout << fullGreeting << endl;\n    return 0;\n}",
                    explanation = "إنشاء سلاسل نصية ودمجها وطباعتها.",
                    expectedOutput = "سارة مرحباً بك في C++!"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🧵", "string هو النوع المخصص للكلمات والجمل الكاملة."),
                LessonSummaryPoint("\"\"", "يُحاط بعلامات اقتباس مزدوجة \" \"."),
                LessonSummaryPoint("➕", "يمكن دمج النصوص بسهولة باستخدام علامة +.")
            ),
            exerciseIds = listOf("ex_l2_5")
        ),

        // L2_6
        Lesson(
            id = "l2_6",
            levelNumber = 2,
            lessonNumber = 6,
            titleArabic = "القيم المنطقية: bool (صح أم خطأ؟)",
            titleEnglish = "Booleans: The bool Type",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "هل اللاعب على قيد الحياة؟ هل الباب مفتوح؟ هل كلمة المرور صحيحة؟ هذه أسئلة إجابتها إما نعم أو لا!",
            detailedExplanation = "النوع المنطقي bool مسمى على اسم عالم الرياضيات جورج بول (George Boole).\nله قيمتان محتملتان فقط في الوجود:\n- true (صحيح)\n- false (خاطئ)\n\nداخلياً في المعالج:\n- true تخزن كرقم 1\n- false تخزن كرقم 0\n\nعند طباعة متغير bool باستخدام cout، سيطبع الرقم 1 أو 0 افتراضياً ما لم نطلب منه إظهار الكلمات.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    bool isGameOver = false;\n    bool hasKey = true;\n    cout << \"حالة انتهاء اللعبة: \" << isGameOver << endl;\n    cout << \"هل يملك المفتاح: \" << hasKey << endl;\n    return 0;\n}",
                    explanation = "تعريف متغيرات منطقية وطباعة قيمها (0 أو 1).",
                    expectedOutput = "حالة انتهاء اللعبة: 0\nهل يملك المفتاح: 1"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("⚖️", "bool يتسع لحالتين فقط: true أو false."),
                LessonSummaryPoint("0️⃣/1️⃣", "في الذاكرة: true = 1 و false = 0."),
                LessonSummaryPoint("🚦", "يشكل الأساس الذي تبنى عليه شروط وقرارات البرنامج.")
            ),
            exerciseIds = listOf("ex_l2_6")
        ),

        // L2_7
        Lesson(
            id = "l2_7",
            levelNumber = 2,
            lessonNumber = 7,
            titleArabic = "قواعد تسمية المتغيرات النظيفة",
            titleEnglish = "Variable Naming Rules",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "لا يمكنك تسمية المتغير بأي شيء يخطر في بالك! هناك قواعد يفرضها المترجم، وقواعد يفرضها الذوق البرمجي.",
            detailedExplanation = "قواعد إجبارية يفرضها المترجم (Syntax):\n1. يجب أن يبدأ الاسم بحرف إنجليزي أو بشرطة سفلية (_) فقط. لا يجوز البدء برقم! (خطأ: 2player | صحيح: player2).\n2. لا يجوز استخدام مسافات أو رموز خاصة مثل @, $, %, - داخل الاسم.\n3. لغة C++ حساسة لحالة الأحرف (Case Sensitive): فالمتغير age يختلف تماماً عن Age وعن AGE!\n4. لا يجوز استخدام الكلمات المحجوزة في اللغة (مثل int, main, return, double).\n\nقواعد احترافية (Clean Code):\n- استخدم أسلوب سنام الجمل (camelCase) مثل userScore, playerHealth.\n- اختر أسماء ذات معنى واضح؛ تجنب x, y, a إلا في العدادات البسيطة.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int playerMaxHealth = 100; // اسم واضح ونظيف\n    int currentLevel = 5;      // أسلوب camelCase\n    cout << \"المستوى: \" << currentLevel << endl;\n    return 0;\n}",
                    explanation = "تسمية المتغيرات بأسماء واضحة تتبع أسلوب camelCase.",
                    expectedOutput = "المستوى: 5"
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "بدء اسم المتغير برقم أو وضع مسافة",
                    incorrectCode = "int 1stPlayer = 10;\nint player score = 20;",
                    correctCode = "int firstPlayer = 10;\nint playerScore = 20;",
                    whyItHappens = "المترجم لا يقبل أرقاماً في أول الاسم ولا يقبل المسافات إطلاقاً.",
                    howToFix = "ابدأ بحرف واجمع الكلمات بـ camelCase بدون مسافات."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🔤", "الاسم يبدأ بحرف إنجليزي أو شرطة _ ولا يبدأ برقم."),
                LessonSummaryPoint("🔠", "C++ حساسة لحالة الأحرف: user غير User."),
                LessonSummaryPoint("🐫", "اتبع أسلوب camelCase لجعل كودك احترافياً ومقروءاً.")
            ),
            exerciseIds = listOf("ex_l2_7")
        ),

        // L2_8
        Lesson(
            id = "l2_8",
            levelNumber = 2,
            lessonNumber = 8,
            titleArabic = "الإعلان والإسناد (Declaration vs Initialization)",
            titleEnglish = "Declaration vs Initialization",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "ما الفرق بين حجز الغرفة في الفندق، وسكن النزيل الفعلي بداخلها؟ هذا هو الفرق بين الإعلان والإسناد!",
            detailedExplanation = "1. الإعلان (Declaration):\nأن تخبر المترجم: 'احجز لي متغيراً نوعه int واسمه speed'.\nint speed;\nهنا تم حجز المساحة، لكن ما بداخلها غير معروف وقد يحتوي أرقاماً عشوائية بقيت في الذاكرة من برامج سابقة (Garbage Value)!\n\n2. الإسناد الأولي (Initialization):\nإعطاء المتغير قيمة ابتدائية نظيفة فور ولادته:\nint speed = 0;\n\n3. إعادة التعيين (Reassignment):\nتغيير القيمة لاحقاً في أي مكان في البرنامج:\nspeed = 60;\n(لاحظ: لا نعيد كتابة int عند تغيير القيمة، نكتب فقط اسم المتغير = القيمة الجديدة).",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int energy = 100; // إعلان مع إسناد ابتدائي\n    cout << \"الطاقة في البداية: \" << energy << endl;\n    \n    energy = 75;      // إعادة تعيين قيمة جديدة\n    cout << \"الطاقة بعد الجري: \" << energy << endl;\n    return 0;\n}",
                    explanation = "تغيير قيمة المتغير أثناء عمل البرنامج.",
                    expectedOutput = "الطاقة في البداية: 100\nالطاقة بعد الجري: 75"
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "تكرار نوع البيانات عند تغيير القيمة",
                    incorrectCode = "int health = 100;\nint health = 80; // خطأ: إعادة تعريف!",
                    correctCode = "int health = 100;\nhealth = 80;     // صحيح: تغيير قيمة فقط",
                    whyItHappens = "يظن المبتدئ أنه يجب كتابة int كلما تعامل مع المتغير.",
                    howToFix = "النوع يُكتب مرة واحدة فقط عند ولادة المتغير."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🆕", "الإعلان Declaration: حجز المكان في الذاكرة."),
                LessonSummaryPoint("🌟", "الإسناد Initialization: وضع القيمة الأولى."),
                LessonSummaryPoint("🔄", "لتغيير القيمة: اكتب الاسم فقط = القيمة الجديدة دون إعادة كتابة النوع.")
            ),
            exerciseIds = listOf("ex_l2_8")
        ),

        // L2_9
        Lesson(
            id = "l2_9",
            levelNumber = 2,
            lessonNumber = 9,
            titleArabic = "الثوابت: كلمة const لحماية البيانات",
            titleEnglish = "Constants: The const Keyword",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "هناك قيم في الكون وفي برامجنا لا يجب أن تتغير أبداً، مثل سرعة الضوء أو النسبة التقريبية أو الحد الأقصى للمحاولات.",
            detailedExplanation = "إذا وضعت كلمة const (اختصار Constant) قبل نوع المتغير، فإنك تضع قفلاً حديدياً عليه!\n\nconst double PI = 3.14159;\nconst int MAX_USERS = 50;\n\nإذا حاول أي شخص (أو حتى أنت عن طريق الخطأ) تغيير قيمة المتغير لاحقاً في الكود:\nPI = 3.5; // ❌ سيتوقف المترجم ويرفض البناء فوراً!\n\nهذا يحمي برامجك الضخمة من التعديلات غير المقصودة ويوضح نواياك البرمجية.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    const int MAX_LEVEL = 50;\n    cout << \"الحد الأقصى للمستوى: \" << MAX_LEVEL << endl;\n    // MAX_LEVEL = 51; // لو ألغيت تعليق هذا السطر سيرفض المترجم فوراً!\n    return 0;\n}",
                    explanation = "حماية المتغير من أي تعديل باستخدام const.",
                    expectedOutput = "الحد الأقصى للمستوى: 50"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🔒", "const تجعل المتغير للقراءة فقط (Read-only)."),
                LessonSummaryPoint("🛡️", "تحميك من الأخطاء المنطقية وتغيير القيم الثابتة سهواً."),
                LessonSummaryPoint("🔠", "جرت العادة على كتابة أسماء الثوابت بحروف كبيرة مثل MAX_USERS.")
            ),
            exerciseIds = listOf("ex_l2_9")
        ),

        // L2_10
        Lesson(
            id = "l2_10",
            levelNumber = 2,
            lessonNumber = 10,
            titleArabic = "مشروع المستوى 2: سجل بيانات شخصية المحارب 🛡️",
            titleEnglish = "Level 2 Project: RPG Character Stats Sheet",
            estimatedMinutes = 10,
            xpReward = 80,
            introduction = "سنجمع كل أنواع البيانات التي أتقناها: int, double, char, string, bool, const في برنامج ممتع لسجل بيانات محارب في لعبة!",
            detailedExplanation = "شاهد كيف تتكامل أنواع البيانات معاً لتخزين معلومات مختلفة لكيان واحد متكامل في الذاكرة.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    const string GAME_TITLE = \"أساطير C++\";\n    string heroName = \"فارس النور\";\n    int level = 7;\n    double health = 89.5;\n    char rank = 'S';\n    bool isAlive = true;\n    \n    cout << \"=== \" << GAME_TITLE << \" ===\" << endl;\n    cout << \"البطل: \" << heroName << endl;\n    cout << \"المستوى: \" << level << endl;\n    cout << \"الصحة: \" << health << \" / 100\" << endl;\n    cout << \"الرتبة: \" << rank << endl;\n    cout << \"على قيد الحياة: \" << isAlive << endl;\n    return 0;\n}",
                    explanation = "برنامج متكامل يوظف جميع أنواع البيانات الأساسية في C++.",
                    expectedOutput = "=== أساطير C++ ===\nالبطل: فارس النور\nالمستوى: 7\nالصحة: 89.5 / 100\nالرتبة: S\nعلى قيد الحياة: 1"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🎉", "أنهيت المستوى 2 وأتقنت قلب الذاكرة وأنواع البيانات!"),
                LessonSummaryPoint("🧠", "تعرف متى تختار int أو double أو char أو string أو bool."),
                LessonSummaryPoint("🚀", "المستوى القادم: كيف نأخذ بيانات من المستخدم عبر لوحة المفاتيح ونجري العمليات!")
            ),
            exerciseIds = listOf("ex_l2_10"),
            quizId = "quiz_l2_final"
        )
    )
}
