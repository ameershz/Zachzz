package com.example.content

import com.example.domain.model.Challenge
import com.example.domain.model.ChallengeDifficulty
import com.example.domain.model.TestCase

object ChallengesContent {

    val ALL_CHALLENGES = listOf(
        // Challenge 1 - Easy
        Challenge(
            id = "ch_easy_1",
            titleArabic = "طباعة اسمك ورسالة ترحيبية",
            titleEnglish = "Print Your Name",
            difficulty = ChallengeDifficulty.EASY,
            xpReward = 40,
            requiredLevel = 1,
            descriptionArabic = "اكتب برنامج C++ يقوم بطباعة اسمك متبوعاً بسطر جديد، ثم عبارة 'C++ Developer' على الشاشة.",
            hintsArabic = listOf(
                "استخدم #include <iostream>",
                "استخدم std::cout مع <<",
                "لا تنسَ std::endl أو \\n للنزول لسطر جديد",
                "اختم بـ return 0; والفاصلة المنقوطة ;"
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    // اكتب كود الطباعة هنا\n    \n    return 0;\n}",
            testCases = listOf(
                TestCase(
                    input = "",
                    expectedOutput = "Ahmed\nC++ Developer\n",
                    description = "طباعة الاسم في سطر واللقب في سطر"
                )
            )
        ),

        // Challenge 2 - Easy
        Challenge(
            id = "ch_easy_2",
            titleArabic = "حساب مجموع رقمين",
            titleEnglish = "Sum of Two Numbers",
            difficulty = ChallengeDifficulty.EASY,
            xpReward = 50,
            requiredLevel = 2,
            descriptionArabic = "عرّف متغيرين من نوع int: الأول اسمه a بقيمة 25، والثاني اسمه b بقيمة 75، ثم اطبع مجموعهما على الشاشة.",
            hintsArabic = listOf(
                "عرّف int a = 25; و int b = 75;",
                "اطبع المجموع مباشرة: cout << (a + b) << endl;"
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int a = 25;\n    int b = 75;\n    // اطبع المجموع\n    \n    return 0;\n}",
            testCases = listOf(
                TestCase(
                    input = "",
                    expectedOutput = "100\n",
                    description = "مجموع 25 + 75 = 100"
                )
            )
        ),

        // Challenge 3 - Medium
        Challenge(
            id = "ch_med_1",
            titleArabic = "حاسبة مساحة ومحيط المستطيل",
            titleEnglish = "Rectangle Area & Perimeter",
            difficulty = ChallengeDifficulty.MEDIUM,
            xpReward = 75,
            requiredLevel = 3,
            descriptionArabic = "عرّف الطول length = 12 والعرض width = 5. احسب المساحة (الطول * العرض) والمحيط (2 * (الطول + العرض)) واطبعهما.",
            hintsArabic = listOf(
                "المساحة = length * width",
                "المحيط = 2 * (length + width)",
                "استخدم الأقواس لضمان جمع الطول والعرض قبل الضرب في 2"
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int length = 12;\n    int width = 5;\n    // احسب المساحة والمحيط واطبعهما\n    \n    return 0;\n}",
            testCases = listOf(
                TestCase(
                    input = "",
                    expectedOutput = "Area: 60\nPerimeter: 34\n",
                    description = "المساحة 60 والمحيط 34"
                )
            )
        ),

        // Challenge 4 - Medium
        Challenge(
            id = "ch_med_2",
            titleArabic = "فحص الرقم الزوجي والفردي",
            titleEnglish = "Even or Odd Checker",
            difficulty = ChallengeDifficulty.MEDIUM,
            xpReward = 80,
            requiredLevel = 4,
            descriptionArabic = "اكتب برنامجاً يفحص متغيراً اسمه number بقيمة 18. إذا كان زوجياً يطبع 'Even' وإذا كان فردياً يطبع 'Odd'.",
            hintsArabic = listOf(
                "استخدم باقي القسمة على 2: number % 2",
                "إذا كان الباقي يساوي 0 (number % 2 == 0) فهو زوجي Even"
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int number = 18;\n    // افحص واطبع النتيجة\n    \n    return 0;\n}",
            testCases = listOf(
                TestCase(
                    input = "",
                    expectedOutput = "Even\n",
                    description = "الرقم 18 زوجي"
                )
            )
        ),

        // Challenge 5 - Hard
        Challenge(
            id = "ch_hard_1",
            titleArabic = "طباعة جدول الضرب المصغر",
            titleEnglish = "Mini Multiplication Table",
            difficulty = ChallengeDifficulty.HARD,
            xpReward = 120,
            requiredLevel = 5,
            descriptionArabic = "استخدم حلقة for لطباعة جدول ضرب الرقم 5 من 1 إلى 5 بالصيغة: 5 x 1 = 5 ... إلخ.",
            hintsArabic = listOf(
                "استخدم for (int i = 1; i <= 5; i++)",
                "داخل الحلقة اطبع 5 << \" x \" << i << \" = \" << (5 * i)"
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    // اكتب حلقة التكرار هنا\n    \n    return 0;\n}",
            testCases = listOf(
                TestCase(
                    input = "",
                    expectedOutput = "5 x 1 = 5\n5 x 2 = 10\n5 x 3 = 15\n5 x 4 = 20\n5 x 5 = 25\n",
                    description = "جدول ضرب 5 من 1 إلى 5"
                )
            )
        )
    )
}
