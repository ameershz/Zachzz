package com.example.content

import com.example.domain.model.CodeBlock
import com.example.domain.model.CommonMistake
import com.example.domain.model.InteractiveToken
import com.example.domain.model.Lesson
import com.example.domain.model.LessonSummaryPoint
import com.example.domain.model.VisualAnalogy

object Level3Content {

    val lessons = listOf(
        // L3_1
        Lesson(
            id = "l3_1",
            levelNumber = 3,
            lessonNumber = 1,
            titleArabic = "العمليات الحسابية الأساسية (+, -, *, /)",
            titleEnglish = "Basic Arithmetic Operators",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "الكمبيوتر في جوهره آلة حاسبة خارقة السرعة تستطيع إجراء مليارات العمليات في الثانية!",
            detailedExplanation = "في C++ نستخدم الرموز الحسابية الرياضية:\n- الجمع: +\n- الطرح: -\n- الضرب: * (علامة النجمة، لا نستخدم x)\n- القسمة: / (الشرطة المائلة للأمام)\n\nيمكنك إجراء العمليات مباشرة داخل متغير أو أثناء الطباعة:\nint sum = 10 + 20;\ncout << 5 * 6;",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int a = 20;\n    int b = 4;\n    \n    cout << \"الجمع: \" << (a + b) << endl;\n    cout << \"الطرح: \" << (a - b) << endl;\n    cout << \"الضرب: \" << (a * b) << endl;\n    cout << \"القسمة: \" << (a / b) << endl;\n    return 0;\n}",
                    explanation = "تطبيق العمليات الحسابية الأربع على رقمين.",
                    expectedOutput = "الجمع: 24\nالطرح: 16\nالضرب: 80\nالقسمة: 5"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("➕", "الجمع: + والطرح: -"),
                LessonSummaryPoint("✖️", "الضرب هو * والقسمة هي /"),
                LessonSummaryPoint("⚡", "المعالج ينفذ العمليات الحسابية بسرعة الضوء.")
            ),
            exerciseIds = listOf("ex_l3_1")
        ),

        // L3_2
        Lesson(
            id = "l3_2",
            levelNumber = 3,
            lessonNumber = 2,
            titleArabic = "فخ القسمة الصحيحة (Integer Division Trap)",
            titleEnglish = "The Integer Division Trap",
            estimatedMinutes = 7,
            xpReward = 50,
            introduction = "كم ناتج 5 مقسومة على 2 في الرياضيات؟ 2.5 طبعاً. لكن في C++ قد تكون النتيجة صدمة: 2 فقط!",
            detailedExplanation = "قاعدة ذهبية قاتلة في C++:\nعندما تقسم رقماً صحيحاً (int) على رقم صحيح آخر (int)، فإن النتيجة تكون دائماً رقماً صحيحاً (int)!\nالمعالج يقوم بقطع الكسر العشري فوراً وإلقائه في سلة المهملات!\n\n5 / 2 = 2 وليس 2.5!\n\nكيف نحصل على النتيجة الصحيحة ذات الكسر (2.5)؟\nيجب أن يكون أحد الطرفين على الأقل عدداً عشرياً (double):\n- 5.0 / 2 = 2.5\n- 5 / 2.0 = 2.5\n- double(5) / 2 = 2.5",
            visualAnalogy = VisualAnalogy(
                title = "تقسيم التفاحات 🍎",
                analogyArabic = "إذا كان لديك 5 تفاحات صحيحة وقسمتها على شخصين دون السماح بالسكاكين، كل شخص سيأخذ تفاحتين كاملتين وتبقى تفاحة.",
                realTechExplanation = "الـ CPU ينفذ تعليمة القسمة الصحيحة idiv التي تخرج ناتجاً صحيحاً وتتجاهل الكسر مالم تُطلب قسمة عائمة fdiv."
            ),
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int result1 = 5 / 2;\n    double result2 = 5.0 / 2;\n    \n    cout << \"قسمة صحيحة: \" << result1 << endl;\n    cout << \"قسمة عشرية: \" << result2 << endl;\n    return 0;\n}",
                    explanation = "مقارنة حية بين القسمة الصحيحة والقسمة العشرية.",
                    expectedOutput = "قسمة صحيحة: 2\nقسمة عشرية: 2.5"
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "تخزين قسمة عددين صحيحين في متغير double",
                    incorrectCode = "double avg = 5 / 2;\ncout << avg; // سيطبع 2 وليس 2.5!",
                    correctCode = "double avg = 5.0 / 2;\ncout << avg; // سيطبع 2.5",
                    whyItHappens = "المترجم يحسب 5 / 2 أولاً وينتج 2، ثم يحول 2 إلى double فتصبح 2.0!",
                    howToFix = "اجعل أحد الطرفين كسر عشرياً بإضافة .0 قبل إجراء القسمة."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("⚠️", "int / int ينتج int دائماً ويضيع الجزء العشري."),
                LessonSummaryPoint("🎯", "للحصول على كسر دقيق: اجعل أحد الرقمين double (مثل 5.0)."),
                LessonSummaryPoint("💡", "من أهم الأسئلة في المقابلات البرمجية واختبارات الجامعات!")
            ),
            exerciseIds = listOf("ex_l3_2")
        ),

        // L3_3
        Lesson(
            id = "l3_3",
            levelNumber = 3,
            lessonNumber = 3,
            titleArabic = "باقي القسمة (%) وسحره في البرمجة",
            titleEnglish = "The Modulo Operator (%)",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "علامة النسبة المئوية % في C++ لا تعني نسبة مئوية إطلاقاً، بل تعني باقي القسمة (Modulo)!",
            detailedExplanation = "عندما تقسم 7 على 3:\nالناتج 2، ويتبقى 1.\nإذاً: 7 % 3 = 1.\n\nلماذا يعتبر هذا المعامل عبقرياً في البرمجة؟\n1. معرفة هل الرقم زوجي أم فردي: أي رقم زوجي % 2 = 0، وأي رقم فردي % 2 = 1.\n2. تحويل الثواني إلى دقائق وساعات: 125 ثانية % 60 = 5 ثوانٍ متبقية.\n3. تدوير الدورات في الألعاب: إبقاء الأرقام تدور في نطاق محدد من 0 إلى n.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int totalSeconds = 125;\n    int minutes = totalSeconds / 60;\n    int seconds = totalSeconds % 60;\n    \n    cout << minutes << \" دقيقة و \" << seconds << \" ثانية\" << endl;\n    cout << \"هل 10 رقم زوجي؟ باقي قسمته على 2 هو: \" << (10 % 2) << endl;\n    return 0;\n}",
                    explanation = "استخدام باقي القسمة لتحويل الوقت وفحص الزوجية.",
                    expectedOutput = "2 دقيقة و 5 ثانية\nهل 10 رقم زوجي؟ باقي قسمته على 2 هو: 0"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("%", "معامل % يرجع الباقي فقط بعد إتمام القسمة."),
                LessonSummaryPoint("✌️", "فحص الزوجي والفردي: n % 2."),
                LessonSummaryPoint("🔢", "يعمل حصراً مع الأعداد الصحيحة int.")
            ),
            exerciseIds = listOf("ex_l3_3")
        ),

        // L3_4
        Lesson(
            id = "l3_4",
            levelNumber = 3,
            lessonNumber = 4,
            titleArabic = "ترتيب أولويات العمليات الحسابية والأقواس ()",
            titleEnglish = "Operator Precedence & Parentheses",
            estimatedMinutes = 6,
            xpReward = 45,
            introduction = "إذا كتبت: 2 + 3 * 4، هل النتيجة 20 أم 14؟",
            detailedExplanation = "في C++ تماماً كما في الرياضيات، العمليات ليست متساوية في القوة!\n\nترتيب القوة (من الأقوى إلى الأضعف):\n1. الأقواس (): أقوى شيء في الكون! أي عملية داخل أقواس تنفذ أولاً.\n2. الضرب (*) والقسمة (/) وباقي القسمة (%): متساوية في القوة وتنفذ من اليسار إلى اليمين.\n3. الجمع (+) والطرح (-): أضعف وتنفذ أخيراً.\n\nفي المعادلة: 2 + 3 * 4:\nيتم ضرب 3 * 4 = 12 أولاً، ثم جمع 2 + 12 = 14!\nإذا أردت الجمع أولاً، يجب استخدام الأقواس: (2 + 3) * 4 = 20.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int result1 = 2 + 3 * 4;\n    int result2 = (2 + 3) * 4;\n    \n    cout << \"بدون أقواس: \" << result1 << endl;\n    cout << \"مع الأقواس: \" << result2 << endl;\n    return 0;\n}",
                    explanation = "تأثير الأقواس على تغيير أولويات الحساب.",
                    expectedOutput = "بدون أقواس: 14\nمع الأقواس: 20"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🥇", "الأقواس () هي الأقوى دائماً."),
                LessonSummaryPoint("🥈", "الضرب والقسمة والباقي يسبقون الجمع والطرح."),
                LessonSummaryPoint("💡", "نصيحة ذهبية: استخدم الأقواس دائماً لتجنب أي التباس.")
            ),
            exerciseIds = listOf("ex_l3_4")
        ),

        // L3_5
        Lesson(
            id = "l3_5",
            levelNumber = 3,
            lessonNumber = 5,
            titleArabic = "الزيادة والنقصان: ++ و -- والفرق بينهما",
            titleEnglish = "Increment & Decrement: ++ and --",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "حتى اسم لغتنا C++ مستوحى من هذا المعامل! ماذا يعني رمز ++؟",
            detailedExplanation = "في البرمجة نحتاج باستمرار لزيادة العدادات بمقدار 1 (مثلاً عند عد الخطوات أو قتل وحش في لعبة).\nبدل أن تكتب:\nx = x + 1;\nاخترعت C++ اختصاراً سريعاً:\nx++;\n\nوهناك نوعان:\n1. الزيادة اللاحقة (Post-increment) مثل x++: استخدام القيمة الحالية أولاً، ثم زيادتها بعد ذلك.\n2. الزيادة السابقة (Pre-increment) مثل ++x: زيادة القيمة أولاً، ثم استخدام القيمة الجديدة فوراً.\n\nونفس الشيء مع النقصان بمقدار واحد: x-- و --x.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int score = 10;\n    score++; // تصبح 11\n    cout << \"النقاط بعد الزيادة: \" << score << endl;\n    \n    score--; // تعود 10\n    cout << \"النقاط بعد النقصان: \" << score << endl;\n    return 0;\n}",
                    explanation = "استخدام ++ للزيادة بمقدار 1 و -- للنقصان بمقدار 1.",
                    expectedOutput = "النقاط بعد الزيادة: 11\nالنقاط بعد النقصان: 10"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("➕➕", "x++ تزيد المتغير بمقدار واحد."),
                LessonSummaryPoint("➖➖", "x-- تنقص المتغير بمقدار واحد."),
                LessonSummaryPoint("🚀", "من هنا جاء اسم C++: أي لغة C مطورة ومزادة بدرجة!")
            ),
            exerciseIds = listOf("ex_l3_5")
        ),

        // L3_6
        Lesson(
            id = "l3_6",
            levelNumber = 3,
            lessonNumber = 6,
            titleArabic = "معاملات الإسناد المركبة (+=, -=, *=, /=)",
            titleEnglish = "Compound Assignment Operators",
            estimatedMinutes = 5,
            xpReward = 45,
            introduction = "إذا أردت زيادة نقاط اللاعب بمقدار 50، هل يعقل أن تكتب score = score + 50؟ هناك اختصار أنيق!",
            detailedExplanation = "تسمح لنا C++ بدمج العملية الحسابية مع عامل الإسناد = في رمز واحد:\n\n- score += 50; تعني بالضبط: score = score + 50;\n- health -= 15; تعني بالضبط: health = health - 15;\n- coins *= 2; تعني بالضبط: coins = coins * 2 (مضاعفة);\n- damage /= 2; تعني بالضبط: damage = damage / 2;\n\nهذا يختصر الكود ويجعله مقروءاً ومباشراً.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int gold = 100;\n    gold += 50; // جمع 50 كنز\n    gold -= 20; // شراء درع بـ 20\n    gold *= 2;  // مضاعفة الذهب بمكافأة سحرية\n    \n    cout << \"رصيد الذهب النهائي: \" << gold << endl;\n    return 0;\n}",
                    explanation = "استخدام الإسناد المركب لتعديل قيمة المتغير بسرعة.",
                    expectedOutput = "رصيد الذهب النهائي: 260"
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("⚡", "المعاملات المركبة تختصر كتابة التعديل على المتغير نفسه."),
                LessonSummaryPoint("+= / -=", "شائعة جداً في تعديل النقاط والصحة والأرصدة."),
                LessonSummaryPoint("🧼", "تساعد في كتابة كود نظيف بدون تكرار اسم المتغير.")
            ),
            exerciseIds = listOf("ex_l3_6")
        ),

        // L3_7
        Lesson(
            id = "l3_7",
            levelNumber = 3,
            lessonNumber = 7,
            titleArabic = "الإدخال من المستخدم: std::cin وأسهم >>",
            titleEnglish = "User Input: std::cin and >>",
            estimatedMinutes = 7,
            xpReward = 55,
            introduction = "حتى الآن، برامجنا تعرض بيانات كتبناها نحن مسبقاً. كيف نجعل البرنامج يسأل المستخدم وينتظر إجابته؟",
            detailedExplanation = "الأداة المسؤولة عن قراءة ما يكتبه المستخدم في لوحة المفاتيح هي cin (تنطق 'سي-إن' اختصار لـ Character Input).\n\nلاحظ الفرق بين الإخراج والإدخال:\n- cout << الشاشة (الأسهم متجهة لليسار نحو الشاشة).\n- cin >> المتغير (الأسهم متجهة لليمين نحو المتغير).\n\nكيف يعمل؟\n1. تنشئ متغيراً في الذاكرة (مثلاً int age;).\n2. تأمر البرنامج: cin >> age;\n3. يتوقف البرنامج تماماً وينتظر من المستخدم كتابة رقم والضغط على Enter.\n4. يأخذ cin الرقم ويضعه فوراً داخل الصندوق age في الذاكرة!",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int age;\n    cout << \"كم عمرك؟ \";\n    cin >> age;\n    cout << \"عمرك هو: \" << age << \" سنة!\" << endl;\n    return 0;\n}",
                    explanation = "قراءة عمر المستخدم من لوحة المفاتيح وطباعته.",
                    interactiveTokens = listOf(
                        InteractiveToken("cin", "كائن الإدخال", "الأداة التي تلتقط مدخلات لوحة المفاتيح.", false),
                        InteractiveToken(">>", "معامل الاستخراج", "يسحب البيانات من لوحة المفاتيح ويصبها في المتغير على اليمين.", false),
                        InteractiveToken("age", "المتغير المستقبل", "المكان في الذاكرة الذي ستخزن فيه القيمة المدخلة.", false)
                    )
                )
            ),
            commonMistakes = listOf(
                CommonMistake(
                    title = "عكس الأسهم مع cin",
                    incorrectCode = "cin << age;",
                    correctCode = "cin >> age;",
                    whyItHappens = "يخلط المبرمج بين إخراج cout وإدخال cin.",
                    howToFix = "تذكر: مع cin تدخل البيانات إلى المتغير باتجاه اليمين >>."
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("⌨️", "cin هي بوابة إدخال البيانات التفاعلية من المستخدم."),
                LessonSummaryPoint("➡️", "تستخدم الأسهم >> المتجهة للمتغير."),
                LessonSummaryPoint("⏸️", "البرنامج يتوقف مؤقتاً حتى يدخل المستخدم القيمة ويضغط Enter.")
            ),
            exerciseIds = listOf("ex_l3_7")
        ),

        // L3_8
        Lesson(
            id = "l3_8",
            levelNumber = 3,
            lessonNumber = 8,
            titleArabic = "إدخال عدة قيم متتالية بسلاسة",
            titleEnglish = "Chaining Multiple Inputs",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "هل يمكننا أن نطلب من المستخدم إدخال الطول والعرض معاً في خطوة واحدة؟ بالتأكيد!",
            detailedExplanation = "تماماً مثلما ربطنا cout بسلسلة <<، يمكننا ربط cin بسلسلة >> متتابعة:\n\nint width, height;\ncin >> width >> height;\n\nكيف يدخل المستخدم القيمتين؟\nيمكنه كتابة الرقم الأول ثم مسافة (Space) ثم الرقم الثاني، أو كتابة الرقم الأول ثم Enter ثم الرقم الثاني.\nسيتكفل cin بوضع الرقم الأول في width والرقم الثاني في height بالترتيب التام!",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int width, height;\n    cout << \"أدخل الطول والعرض مفصولين بمسافة: \";\n    cin >> width >> height;\n    int area = width * height;\n    cout << \"مساحة المستطيل = \" << area << endl;\n    return 0;\n}",
                    explanation = "قراءة قيمتين متتاليتين وحساب المساحة فوراً.",
                    expectedOutput = ""
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🔗", "يمكن ربط عدة متغيرات بأمر cin واحد: cin >> a >> b;"),
                LessonSummaryPoint("␣", "يفصل المستخدم بين المدخلات بمسافة أو بسطر جديد."),
                LessonSummaryPoint("📏", "يتم توزيع القيم بالترتيب من اليسار إلى اليمين.")
            ),
            exerciseIds = listOf("ex_l3_8")
        ),

        // L3_9
        Lesson(
            id = "l3_9",
            levelNumber = 3,
            lessonNumber = 9,
            titleArabic = "قراءة النصوص ذات المسافات: std::getline",
            titleEnglish = "Reading Full Lines with getline",
            estimatedMinutes = 6,
            xpReward = 50,
            introduction = "إذا طلبت من المستخدم إدخال اسمه الكامل 'أحمد علي' باستخدام cin، ستفاجأ بأنه قرأ 'أحمد' فقط وتجاهل 'علي'!",
            detailedExplanation = "لماذا يتجاهل cin ما بعد المسافة؟\nلأن cin يعتبر المسافة (Space) علامة انتهاء الكلمة!\n\nإذا أردت قراءة سطر كامل يحتوي مسافات (مثل الاسم الثلاثي أو عنوان المنزل)، نستخدم الدالة الرائعة getline:\n\nstring fullName;\ngetline(cin, fullName);\n\nتقوم getline بقراءة السطر بأكمله مع كل مسافاته حتى يضغط المستخدم على زر Enter، وتخزنه في متغير string بنجاح تام.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    string fullName;\n    cout << \"أدخل اسمك الكامل: \";\n    getline(cin, fullName);\n    cout << \"أهلاً وسهلاً يا \" << fullName << \"!\" << endl;\n    return 0;\n}",
                    explanation = "قراءة سطر نصي كامل يحتوي مسافات باستخدام getline.",
                    expectedOutput = ""
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🛑", "cin العادي يتوقف عند أول مسافة يراها."),
                LessonSummaryPoint("📝", "getline(cin, var) تقرأ السطر بأكمله مع المسافات."),
                LessonSummaryPoint("🔤", "مثالية لقراءة الأسماء الكاملة والعناوين والرسائل.")
            ),
            exerciseIds = listOf("ex_l3_9")
        ),

        // L3_10
        Lesson(
            id = "l3_10",
            levelNumber = 3,
            lessonNumber = 10,
            titleArabic = "مشروع المستوى 3: آلة حاسبة ذكية تفاعلية 🧮",
            titleEnglish = "Level 3 Project: Smart Interactive Calculator",
            estimatedMinutes = 10,
            xpReward = 85,
            introduction = "حان وقت بناء أول أداة برمجية حقيقية مفيدة! آلة حاسبة تستقبل أرقاماً من المستخدم، تحسب العمليات الأربع، وتعرض النتائج بتنسيق رائع.",
            detailedExplanation = "يوظف هذا المشروع:\n- الإدخال cin والإخراج cout\n- العمليات الحسابية +, -, *, /\n- تجنب فخ القسمة الصحيحة باستخدام double\n- باقي القسمة %\n- تنسيق مخرجات أنيق وواضح.",
            codeBlocks = listOf(
                CodeBlock(
                    code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    double num1 = 15;\n    double num2 = 4;\n    \n    cout << \"=== الحاسبة الذكية C++ ===\" << endl;\n    cout << \"الرقم الأول: \" << num1 << endl;\n    cout << \"الرقم الثاني: \" << num2 << endl;\n    cout << \"--------------------------\" << endl;\n    cout << \"المجموع: \" << (num1 + num2) << endl;\n    cout << \"الفرق: \" << (num1 - num2) << endl;\n    cout << \"حاصل الضرب: \" << (num1 * num2) << endl;\n    cout << \"حاصل القسمة الدقيق: \" << (num1 / num2) << endl;\n    cout << \"باقي القسمة: \" << (int(num1) % int(num2)) << endl;\n    cout << \"==========================\" << endl;\n    return 0;\n}",
                    explanation = "مشروع آلة حاسبة متكامل يوظف كافة عمليات المستوى الثالث.",
                    expectedOutput = "=== الحاسبة الذكية C++ ===\nالرقم الأول: 15\nالرقم الثاني: 4\n--------------------------\nالمجموع: 19\nالفرق: 11\nحاصل الضرب: 60\nحاصل القسمة الدقيق: 3.75\nباقي القسمة: 3\n=========================="
                )
            ),
            summaryPoints = listOf(
                LessonSummaryPoint("🎉", "ألف مبروك! أنهيت 40 درساً تأسيسياً بالكامل!"),
                LessonSummaryPoint("🏆", "أصبحت تفهم الكمبيوتر والذاكرة والمتغيرات والعمليات الحسابية والتفاعل."),
                LessonSummaryPoint("🚀", "المستويات القادمة تفتح لك أبواب القرارات الذكية (if-else) والتكرار (loops) والدوال (functions)!")
            ),
            exerciseIds = listOf("ex_l3_10"),
            quizId = "quiz_l3_final"
        )
    )
}
