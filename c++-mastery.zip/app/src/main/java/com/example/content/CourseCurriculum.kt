package com.example.content

import com.example.domain.model.CourseLevel

object CourseCurriculum {

    fun getAllLevels(): List<CourseLevel> {
        val baseLevels = listOf(
            CourseLevel(
                levelNumber = 0,
                titleArabic = "قبل أن نكتب C++",
                titleEnglish = "Before We Write C++",
                subtitle = "الصفر المطلق: ما هي البرمجة، كيف يفهم الكمبيوتر، وما هو المترجم والخطأ؟",
                iconName = "lightbulb",
                requiredXp = 0,
                lessons = Level0Content.lessons
            ),
            CourseLevel(
                levelNumber = 1,
                titleArabic = "أول خطوات C++",
                titleEnglish = "First Steps in C++",
                subtitle = "هيكل البرنامج، دالة main، سحر الطباعة cout، الأسطر الجديدة والتنسيق",
                iconName = "play_arrow",
                requiredXp = 50,
                lessons = Level1Content.lessons
            ),
            CourseLevel(
                levelNumber = 2,
                titleArabic = "المتغيرات وأنواع البيانات",
                titleEnglish = "Variables & Data Types",
                subtitle = "فهم ذاكرة RAM، الأرقام الصحيحة والعشرية، الحروف، النصوص، والثوابت",
                iconName = "inventory_2",
                requiredXp = 100,
                lessons = Level2Content.lessons
            ),
            CourseLevel(
                levelNumber = 3,
                titleArabic = "العمليات والإدخال والإخراج",
                titleEnglish = "Operators & User Input",
                subtitle = "الحسابات، فخ القسمة الصحيحة، باقي القسمة، والتفاعل الحي مع cin",
                iconName = "calculate",
                requiredXp = 150,
                lessons = Level3Content.lessons
            )
        )

        return baseLevels + AdvancedLevelsContent.getAdvancedLevels()
    }
}
