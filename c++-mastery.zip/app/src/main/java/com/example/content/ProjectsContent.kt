package com.example.content

import com.example.domain.model.Project
import com.example.domain.model.ProjectStep

object ProjectsContent {

    val ALL_PROJECTS = listOf(
        // Project 1
        Project(
            id = "proj_1",
            projectNumber = 1,
            titleArabic = "برنامج الترحيب الشامل وبطاقة الهوية",
            titleEnglish = "Hello Program & Developer Card",
            targetGoalArabic = "إنشاء برنامج شاشة طرفية (Console) متكامل يعرض معلومات مبرمج C++ داخل إطار نصي أنيق.",
            requiredConceptsArabic = listOf("cout", "endl", "\\n", "الإطارات النصية", "main function"),
            steps = listOf(
                ProjectStep(1, "تضمين المكتبات وفضاء الأسماء", "أضف #include <iostream> و using namespace std;", "السطر الأول في الملف"),
                ProjectStep(2, "بناء الإطار العلوي", "اطبع إطاراً من علامات النجمة *********", "استخدم cout"),
                ProjectStep(3, "طباعة البيانات الشخصية", "اطبع الاسم واللغة والهدف البرمجي", "استخدم endl للنزول بين السطور"),
                ProjectStep(4, "إغلاق الإطار وإنهاء البرنامج", "اطبع الإطار السفلي واختم بـ return 0;", "لا تنسَ الفاصلة المنقوطة ;")
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    // ابنِ بطاقتك البرمجية هنا\n    \n    return 0;\n}",
            referenceSolution = "#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << \"****************************\" << endl;\n    cout << \"*     مبرمج C++ المعتمد     *\" << endl;\n    cout << \"****************************\" << endl;\n    cout << \"الاسم: أحمد\" << endl;\n    cout << \"المسار: من الصفر إلى الاحتراف\" << endl;\n    cout << \"****************************\" << endl;\n    return 0;\n}",
            xpReward = 100
        ),

        // Project 2
        Project(
            id = "proj_2",
            projectNumber = 2,
            titleArabic = "آلة حاسبة ذكية شاملة",
            titleEnglish = "Smart Interactive Calculator",
            targetGoalArabic = "بناء حاسبة مالية وهندسية تحسب العمليات الأربع مع النسبة المئوية وباقي القسمة بدقة عالية.",
            requiredConceptsArabic = listOf("cin", "cout", "double", "int", "المعاملات الحسابية", "القسمة العشرية"),
            steps = listOf(
                ProjectStep(1, "تعريف المتغيرات", "عرّف رقمين بنوع double لحفظ الأرقام", "double a, b;"),
                ProjectStep(2, "استقبال المدخلات", "اطلب من المستخدم إدخال الرقمين", "cin >> a >> b;"),
                ProjectStep(3, "حساب العمليات", "احسب الجمع، الطرح، الضرب، والقسمة الدقيقة", "تأكد من عدم القسمة على صفر"),
                ProjectStep(4, "عرض فاتورة الحساب", "اطبع جدولاً منسقاً بالنتائج", "استخدم فواصل واضحة")
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    double a = 20, b = 6;\n    // اكتب كود الحاسبة الشاملة\n    \n    return 0;\n}",
            referenceSolution = "#include <iostream>\nusing namespace std;\n\nint main() {\n    double a = 20, b = 6;\n    cout << \"=== الحاسبة الذكية ===\" << endl;\n    cout << \"الجمع: \" << (a + b) << endl;\n    cout << \"الطرح: \" << (a - b) << endl;\n    cout << \"الضرب: \" << (a * b) << endl;\n    cout << \"القسمة الدقيقة: \" << (a / b) << endl;\n    cout << \"باقي القسمة: \" << (int(a) % int(b)) << endl;\n    return 0;\n}",
            xpReward = 150
        ),

        // Project 3
        Project(
            id = "proj_3",
            projectNumber = 3,
            titleArabic = "لعبة تخمين الرقم السري",
            titleEnglish = "Number Guessing Game",
            targetGoalArabic = "محاكاة لعبة ممتعة يفكر فيها الكمبيوتر في رقم سري ويحاول اللاعب تخمينه مع إعطاء تلميحات (أكبر / أصغر).",
            requiredConceptsArabic = listOf("if-else", "cin", "cout", "المقارنات الشرطية"),
            steps = listOf(
                ProjectStep(1, "تحديد الرقم السري", "عرّف الرقم السري كـ const int secret = 42;", "استخدم const"),
                ProjectStep(2, "استقبال تخمين اللاعب", "اقرأ تخمين اللاعب في متغير playerGuess", "cin >> playerGuess;"),
                ProjectStep(3, "مقارنة التخمين", "إذا كان التخمين صحيحاً اطبع رسالة الفوز، وإذا كان أصغر أو أكبر وجّه اللاعب", "استخدم if و else if و else")
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    const int SECRET = 42;\n    int guess = 30;\n    // ابنِ منطق اللعبة هنا\n    \n    return 0;\n}",
            referenceSolution = "#include <iostream>\nusing namespace std;\n\nint main() {\n    const int SECRET = 42;\n    int guess = 42;\n    if (guess == SECRET) {\n        cout << \"🎉 مبروك! تخمينك صحيح مئة بالمئة!\" << endl;\n    } else if (guess < SECRET) {\n        cout << \"⬆️ الرقم السري أكبر من تخمينك!\" << endl;\n    } else {\n        cout << \"⬇️ الرقم السري أصغر من تخمينك!\" << endl;\n    }\n    return 0;\n}",
            xpReward = 180
        ),

        // Project 4
        Project(
            id = "proj_4",
            projectNumber = 4,
            titleArabic = "متتبع المصروفات الشخصية",
            titleEnglish = "Simple Expense Tracker",
            targetGoalArabic = "تتبع الدخل والمصروفات اليومية وحساب الرصيد المتبقي ونسبة التوفير.",
            requiredConceptsArabic = listOf("double", "string", "العمليات الحسابية", "cin/cout"),
            steps = listOf(
                ProjectStep(1, "تحديد الراتب والدخل", "عرّف الراتب الشهري الإجمالي", "double salary = 5000;"),
                ProjectStep(2, "خصم المصروفات", "اخصم الإيجار، الفواتير، والتسوق", "استخدم -= لكل مصروف"),
                ProjectStep(3, "تقرير الميزانية", "اطبع الرصيد المتبقي ومعدل التوفير", "احسب النسبة المئوية")
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    double salary = 5000;\n    // اخصم المصروفات واطبع التقرير\n    \n    return 0;\n}",
            referenceSolution = "#include <iostream>\nusing namespace std;\n\nint main() {\n    double salary = 5000;\n    double rent = 1500;\n    double bills = 500;\n    double food = 1200;\n    double totalExpenses = rent + bills + food;\n    double remaining = salary - totalExpenses;\n    cout << \"الراتب: \" << salary << endl;\n    cout << \"إجمالي المصروفات: \" << totalExpenses << endl;\n    cout << \"الرصيد المتبقي: \" << remaining << endl;\n    return 0;\n}",
            xpReward = 200
        ),

        // Project 5
        Project(
            id = "proj_5",
            projectNumber = 5,
            titleArabic = "نظام درجات وتقديرات الطلاب",
            titleEnglish = "Student Grade Management System",
            targetGoalArabic = "حساب المعدل الفصلي لطالب وتحديد التقدير اللفظي (ممتاز، جيد جداً، راسب).",
            requiredConceptsArabic = listOf("المعدلات", "الشروط المتعددة else-if", "char", "string"),
            steps = listOf(
                ProjectStep(1, "إدخال درجات 3 مواد", "احسب المتوسط الحسابي للدرجات", "average = (m1 + m2 + m3) / 3.0"),
                ProjectStep(2, "تحديد التقدير", "افحص النتيجة: فوق 90 ممتاز، فوق 80 جيد جداً... إلخ", "استخدم سلسلة if-else"),
                ProjectStep(3, "طباعة الشهادة", "اطبع تقريراً بالاسم والمعدل والتقدير", "تنسيق الشاشة")
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    double g1 = 95, g2 = 88, g3 = 92;\n    // احسب المعدل والتقدير\n    \n    return 0;\n}",
            referenceSolution = "#include <iostream>\nusing namespace std;\n\nint main() {\n    double g1 = 95, g2 = 88, g3 = 92;\n    double avg = (g1 + g2 + g3) / 3.0;\n    cout << \"المعدل العام: \" << avg << endl;\n    if (avg >= 90) cout << \"التقدير: ممتاز (A)\" << endl;\n    else if (avg >= 80) cout << \"التقدير: جيد جداً (B)\" << endl;\n    else if (avg >= 50) cout << \"التقدير: مقبول (C)\" << endl;\n    else cout << \"التقدير: راسب (F)\" << endl;\n    return 0;\n}",
            xpReward = 220
        ),

        // Project 6
        Project(
            id = "proj_6",
            projectNumber = 6,
            titleArabic = "نظام إدارة مخزون المستودع",
            titleEnglish = "Inventory System",
            targetGoalArabic = "إدارة كميات المنتجات والتنبيه عند اقتراب نفاد المخزون.",
            requiredConceptsArabic = listOf("المتغيرات", "الشروط", "التعديل المركب += و -="),
            steps = listOf(
                ProjectStep(1, "تعريف السلع والكميات", "عرّف أسماء المنتجات وكمياتها", "int laptops = 15;"),
                ProjectStep(2, "محاكاة عمليات بيع وتوريد", "اخصم المبيعات وأضف التوريدات", "laptops -= 3;"),
                ProjectStep(3, "فحص حد الأمان", "إذا قلت الكمية عن 5 أظهر تنبيه إعادة طلب", "if (qty < 5)")
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int stock = 12;\n    // ابنِ نظام المخزون\n    \n    return 0;\n}",
            referenceSolution = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int stock = 4;\n    cout << \"كمية المخزون الحالية: \" << stock << endl;\n    if (stock < 5) {\n        cout << \"⚠️ تنبيه: المخزون أوشك على النفاد! يرجى طلب شحنة جديدة فوراً.\" << endl;\n    } else {\n        cout << \"✅ المخزون في المستوى الآمن.\" << endl;\n    }\n    return 0;\n}",
            xpReward = 250
        ),

        // Project 7
        Project(
            id = "proj_7",
            projectNumber = 7,
            titleArabic = "لعبة المغامرة النصية التفاعلية",
            titleEnglish = "Text RPG Adventure",
            targetGoalArabic = "لعبة تقمص أدوار نصية يتخذ فيها اللاعب خيارات تغير مسار القصة وطاقته وكنوزه.",
            requiredConceptsArabic = listOf("القصة النصية", "خيارات متعددة", "المتغيرات وصحة البطل"),
            steps = listOf(
                ProjectStep(1, "بداية القصة وعرض الخيارات", "أمامك ممران: كهف مظلم (1) أو بحيرة مسحورة (2)", "cin >> choice;"),
                ProjectStep(2, "تنفيذ تداعيات الاختيار", "تعديل صحة البطل وزيادة الكنز بناءً على القرار", "if-else"),
                ProjectStep(3, "نهاية المغامرة", "إعلان الفوز أو الخسارة", "عرض حصيلة البطل")
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int health = 100;\n    int gold = 50;\n    // ابنِ المغامرة النصية\n    \n    return 0;\n}",
            referenceSolution = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int health = 80;\n    int gold = 150;\n    cout << \"🏰 مرحباً بك في مغامرة قلعة الظلال!\" << endl;\n    cout << \"صحة البطل: \" << health << \" | الذهب: \" << gold << endl;\n    cout << \"لقد هزمت التنين وفتحت الصندوق السحري بنجاح! 🎉\" << endl;\n    return 0;\n}",
            xpReward = 300
        ),

        // Project 8
        Project(
            id = "proj_8",
            projectNumber = 8,
            titleArabic = "المشروع الختامي المتكامل: بنك C++ الذكي",
            titleEnglish = "Final Capstone Project: Smart Bank Console",
            targetGoalArabic = "تطبيق بنكي نصي كامل يتيح إدارة الحسابات، السحب، الإيداع، كشف الحساب، والتحقق من كلمة المرور.",
            requiredConceptsArabic = listOf("المشروع الشامل", "الدوال", "الشروط", "المعاملات", "المتغيرات والثوابت"),
            steps = listOf(
                ProjectStep(1, "شاشة تسجيل الدخول والتحقق", "التحقق من رقم الحساب والرقم السري PIN", "const int PIN = 1234;"),
                ProjectStep(2, "قائمة العمليات الرئيسية", "عرض خيارات: 1. رصيد 2. إيداع 3. سحب 4. خروج", "cout menu"),
                ProjectStep(3, "تنفيذ عمليات السحب والإيداع بأمان", "فحص كفاية الرصيد قبل إتمام السحب", "if (amount <= balance)"),
                ProjectStep(4, "إيصال العملية والوداع", "طباعة إيصال بنكي منسق بأعلى المعايير البرمجية", "formatting")
            ),
            starterCode = "#include <iostream>\nusing namespace std;\n\nint main() {\n    const int CORRECT_PIN = 1234;\n    double balance = 2500;\n    // ابنِ المشروع الختامي\n    \n    return 0;\n}",
            referenceSolution = "#include <iostream>\nusing namespace std;\n\nint main() {\n    const string BANK_NAME = \"بنك C++ الدولي\";\n    double balance = 2500;\n    double withdrawAmount = 500;\n    cout << \"=== \" << BANK_NAME << \" ===\" << endl;\n    cout << \"تم تسجيل الدخول بنجاح.\" << endl;\n    if (withdrawAmount <= balance) {\n        balance -= withdrawAmount;\n        cout << \"✅ تم سحب: \" << withdrawAmount << \" ريال بنجاح.\" << endl;\n        cout << \"الرصيد المتبقي: \" << balance << \" ريال.\" << endl;\n    } else {\n        cout << \"❌ عذراً، الرصيد لا يكفي!\" << endl;\n    }\n    cout << \"شكراً لاستخدامكم خدماتنا!\" << endl;\n    return 0;\n}",
            xpReward = 500
        )
    )
}
