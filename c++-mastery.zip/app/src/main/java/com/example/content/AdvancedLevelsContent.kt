package com.example.content

import com.example.domain.model.CodeBlock
import com.example.domain.model.CourseLevel
import com.example.domain.model.Lesson
import com.example.domain.model.LessonSummaryPoint

object AdvancedLevelsContent {

    fun getAdvancedLevels(): List<CourseLevel> {
        return listOf(
            CourseLevel(
                levelNumber = 4,
                titleArabic = "الشروط والقرارات",
                titleEnglish = "Conditionals & Decision Making",
                subtitle = "كيف نجعل الكود يفكر ويتخذ قرارات بناءً على الظروف",
                iconName = "alt_route",
                requiredXp = 200,
                lessons = listOf(
                    Lesson(
                        id = "l4_1",
                        levelNumber = 4,
                        lessonNumber = 1,
                        titleArabic = "جملة if البسيطة: بوابة اتخاذ القرارات",
                        titleEnglish = "The if Statement",
                        estimatedMinutes = 6,
                        xpReward = 50,
                        introduction = "البرامج الحقيقية تتخذ قرارات ذكية بناءً على إجابات وأرقام المستخدمين.",
                        detailedExplanation = "تسمح جملة if بفحص شرط منطقي، فإذا كان صحيحاً (true) يتم تنفيذ الكود بداخلها، وإذا كان خاطئاً يتم تجاوزه بالكامل.",
                        codeBlocks = listOf(
                            CodeBlock(
                                code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int score = 85;\n    if (score >= 50) {\n        cout << \"مبروك! لقد اجتزت الاختبار بنجاح!\" << endl;\n    }\n    return 0;\n}",
                                explanation = "فحص درجة الطالب وطباعة رسالة النجاح إذا كانت 50 أو أعلى.",
                                expectedOutput = "مبروك! لقد اجتزت الاختبار بنجاح!"
                            )
                        ),
                        summaryPoints = listOf(
                            LessonSummaryPoint("🚦", "if تفحص الشرط بين قوسين ( )."),
                            LessonSummaryPoint("✅", "إذا تحقق الشرط ينفذ ما بين { }.")
                        )
                    ),
                    Lesson(
                        id = "l4_2",
                        levelNumber = 4,
                        lessonNumber = 2,
                        titleArabic = "جملة else: ماذا لو لم يتحقق الشرط؟",
                        titleEnglish = "The else Branch",
                        estimatedMinutes = 6,
                        xpReward = 50,
                        introduction = "ماذا تفعل إذا فشل الشرط الأول؟ هنا يأتي دور البديل الإجباري: else!",
                        detailedExplanation = "عندما يكون لديك مساران متعاكسان، مثل النجاح والرسوب، أو إغلاق الباب وفتحه، تستخدم if مع else.",
                        codeBlocks = listOf(
                            CodeBlock(
                                code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int age = 16;\n    if (age >= 18) {\n        cout << \"مرحباً، يسمح لك بالدخول.\" << endl;\n    } else {\n        cout << \"عذراً، هذا القسم مخصص لمن هم فوق 18 عاماً.\" << endl;\n    }\n    return 0;\n}",
                                explanation = "فحص عمر الزائر وتحديد المسار المناسب.",
                                expectedOutput = "عذراً، هذا القسم مخصص لمن هم فوق 18 عاماً."
                            )
                        ),
                        summaryPoints = listOf(
                            LessonSummaryPoint("🔀", "else تمثل المسار البديل عندما يكون شرط if غير صحيح.")
                        )
                    )
                )
            ),
            CourseLevel(
                levelNumber = 5,
                titleArabic = "الحلقات التكرارية (Loops)",
                titleEnglish = "Loops (for, while, do-while)",
                subtitle = "كيف نكرر تنفيذ الأوامر مئات المرات بذكاء دون تكرار الكود",
                iconName = "sync",
                requiredXp = 350,
                lessons = listOf(
                    Lesson(
                        id = "l5_1",
                        levelNumber = 5,
                        lessonNumber = 1,
                        titleArabic = "حلقة while: كرر ما دام الشرط قائماً",
                        titleEnglish = "The while Loop",
                        estimatedMinutes = 7,
                        xpReward = 55,
                        introduction = "تخيل أنك تريد طباعة الأرقام من 1 إلى 1000. هل تكتب ألف سطر cout؟ بالطبع لا!",
                        detailedExplanation = "حلقة while تفحص الشرط في كل دورة وتكرر تنفيذ الأوامر حتى يصبح الشرط خاطئاً.",
                        codeBlocks = listOf(
                            CodeBlock(
                                code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int counter = 1;\n    while (counter <= 5) {\n        cout << \"العد: \" << counter << endl;\n        counter++;\n    }\n    return 0;\n}",
                                explanation = "طباعة الأرقام من 1 إلى 5 باستخدام حلقة while.",
                                expectedOutput = "العد: 1\nالعد: 2\nالعد: 3\nالعد: 4\nالعد: 5"
                            )
                        )
                    ),
                    Lesson(
                        id = "l5_2",
                        levelNumber = 5,
                        lessonNumber = 2,
                        titleArabic = "حلقة for: البطل الأقوى للتكرار الموزون",
                        titleEnglish = "The for Loop",
                        estimatedMinutes = 7,
                        xpReward = 55,
                        introduction = "حلقة for تجمع العداد وشرط التوقف والزيادة في سطر واحد غاية في الأناقة.",
                        detailedExplanation = "تحتوي for على 3 أجزاء مفصولة بفواصل منقوطة: البداية؛ الشرط؛ خطوة الزيادة.",
                        codeBlocks = listOf(
                            CodeBlock(
                                code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    for (int i = 0; i < 3; i++) {\n        cout << \"دورة رقم: \" << i << endl;\n    }\n    return 0;\n}",
                                explanation = "تكرار منظم لـ 3 دورات باستخدام for.",
                                expectedOutput = "دورة رقم: 0\nدورة رقم: 1\nدورة رقم: 2"
                            )
                        )
                    )
                )
            ),
            CourseLevel(
                levelNumber = 6,
                titleArabic = "الدوال (Functions)",
                titleEnglish = "Functions & Modular Code",
                subtitle = "تقسيم البرنامج الضخم إلى وحدات بناء صغيرة قابلة لإعادة الاستخدام",
                iconName = "code",
                requiredXp = 500,
                lessons = listOf(
                    Lesson(
                        id = "l6_1",
                        levelNumber = 6,
                        lessonNumber = 1,
                        titleArabic = "ما هي الدالة ولماذا نحتاجها؟",
                        titleEnglish = "Introduction to Functions",
                        estimatedMinutes = 7,
                        xpReward = 60,
                        introduction = "بدلاً من تكرار كود حساب الضرائب أو التحقق في 20 مكاناً، نضعه في دالة ونناديها باسمها!",
                        detailedExplanation = "الدالة هي كتلة برمجية مستقلة تأخذ مدخلات، تعالجها، وتُرجع مخرجات محددة.",
                        codeBlocks = listOf(
                            CodeBlock(
                                code = "#include <iostream>\nusing namespace std;\n\nint add(int a, int b) {\n    return a + b;\n}\n\nint main() {\n    int sum = add(15, 25);\n    cout << \"مجموع الرقمين: \" << sum << endl;\n    return 0;\n}",
                                explanation = "تعريف دالة جمع بسيطة واستدعاؤها داخل main.",
                                expectedOutput = "مجموع الرقمين: 40"
                            )
                        )
                    )
                )
            ),
            CourseLevel(
                levelNumber = 7,
                titleArabic = "المصفوفات والنصوص المتقدمة",
                titleEnglish = "Arrays & Strings",
                subtitle = "تخزين وإدارة قوائم طويلة من العناصر المترابطة في الذاكرة",
                iconName = "view_list",
                requiredXp = 700
            ),
            CourseLevel(
                levelNumber = 8,
                titleArabic = "المراجع والمؤشرات (Pointers)",
                titleEnglish = "References & Pointers",
                subtitle = "السر الأكبر لقوة C++: التحكم المباشر في عناوين الذاكرة RAM",
                iconName = "ads_click",
                requiredXp = 900
            ),
            CourseLevel(
                levelNumber = 9,
                titleArabic = "السجلات والتعدادات (Structs & Enums)",
                titleEnglish = "Structs & Enums",
                subtitle = "ابتكار أنواع بيانات خاصة بك تجمع معلومات متنوعة",
                iconName = "category",
                requiredXp = 1100
            ),
            CourseLevel(
                levelNumber = 10,
                titleArabic = "البرمجة كائنية التوجه (OOP)",
                titleEnglish = "Object-Oriented Programming",
                subtitle = "بناء فئات وكائنات تحاكي العالم الحقيقي: Classes & Objects",
                iconName = "widgets",
                requiredXp = 1400
            ),
            CourseLevel(
                levelNumber = 11,
                titleArabic = "مكتبة القوالب القياسية (STL)",
                titleEnglish = "Standard Template Library",
                subtitle = "استخدام هياكل البيانات الجاهزة والسريعة: vector, map, algorithms",
                iconName = "layers",
                requiredXp = 1800
            ),
            CourseLevel(
                levelNumber = 12,
                titleArabic = "إدارة الذاكرة المتقدمة",
                titleEnglish = "Advanced Memory Management",
                subtitle = "فهم Stack و Heap، حجز الذاكرة الديناميكية والمؤشرات الذكية",
                iconName = "memory",
                requiredXp = 2300
            ),
            CourseLevel(
                levelNumber = 13,
                titleArabic = "C++ الحديثة (Modern C++)",
                titleEnglish = "Modern C++ (C++11 to C++20)",
                subtitle = "الميزات الحديثة التي جعلت C++ أكثر أماناً وأناقة: auto, lambda",
                iconName = "auto_awesome",
                requiredXp = 2800
            ),
            CourseLevel(
                levelNumber = 14,
                titleArabic = "الخوارزميات وحل المشكلات",
                titleEnglish = "Algorithms & Problem Solving",
                subtitle = "التفكير البرمجي التنافسي، البحث، الترتيب، والتعقيد الزمني Big-O",
                iconName = "psychology",
                requiredXp = 3400
            ),
            CourseLevel(
                levelNumber = 15,
                titleArabic = "المشاريع الحقيقية المتكاملة",
                titleEnglish = "Capstone Real Projects",
                subtitle = "بناء تطبيقات كاملة من الصفر تثبت احترافك للغة C++",
                iconName = "rocket_launch",
                requiredXp = 4000
            )
        )
    }
}
