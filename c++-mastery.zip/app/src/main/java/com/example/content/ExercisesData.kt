package com.example.content

import com.example.domain.model.Exercise
import com.example.domain.model.ExerciseType

object ExercisesData {

    val ALL_EXERCISES = listOf(
        // L0_1 Exercise
        Exercise(
            id = "ex_l0_1",
            lessonId = "l0_1",
            type = ExerciseType.MULTIPLE_CHOICE,
            titleArabic = "فهم طبيعة البرمجة",
            instructionsArabic = "ما هو التعريف الأدق لمفهوم البرمجة لجهاز الكمبيوتر؟",
            options = listOf(
                "إعطاء تعليمات دقيقة ومرتبة خطوة بخطوة للحاسوب لينفذها",
                "سحر غامض يقوم فيه الكمبيوتر بتخمين ما تفكر فيه",
                "جعل الكمبيوتر يشغل الألعاب بدون أي أوامر"
            ),
            correctOptionIndex = 0,
            educationalFeedback = "أحسنت! الكمبيوتر لا يفهم النوايا؛ البرمجة هي تزويده بتعليمات واضحة ودقيقة ومرتبة منطقياً.",
            conceptTag = "basics",
            xpReward = 25
        ),

        // L0_2 Exercise
        Exercise(
            id = "ex_l0_2",
            lessonId = "l0_2",
            type = ExerciseType.PREDICT_OUTPUT,
            titleArabic = "لغة الآلة والترانزستور",
            instructionsArabic = "ما هما الرقمان اللذان يتكون منهما النظام الثنائي (Binary) الذي يفهمه معالج الكمبيوتر؟",
            options = listOf(
                "الرقم 0 والرقم 1",
                "الأرقام من 1 إلى 9",
                "الحروف الإنجليزية من A إلى Z"
            ),
            correctOptionIndex = 0,
            educationalFeedback = "ممتاز! المعالج يعمل بملايين الترانزستورات، ولكل ترانزستور حالتان: 1 (كهرباء تمر) و 0 (لا تمر).",
            conceptTag = "binary",
            xpReward = 25
        ),

        // L0_6 Exercise
        Exercise(
            id = "ex_l0_6",
            lessonId = "l0_6",
            type = ExerciseType.MULTIPLE_CHOICE,
            titleArabic = "وظيفة المترجم (Compiler)",
            instructionsArabic = "ما هي المهمة الأساسية لمترجم C++ (Compiler)؟",
            options = listOf(
                "تحويل الكود المصدري المكتوب إلى لغة الآلة 0 و 1 وفحص الأخطاء القواعدية",
                "تشغيل مقاطع الفيديو على الإنترنت",
                "كتابة الأكواد نيابة عن المبرمج تلقائياً"
            ),
            correctOptionIndex = 0,
            educationalFeedback = "صحيح تماماً! المترجم هو الوسيط الذي يفحص القواعد ويترجم لغة C++ إلى لغة الآلة لإنتاج ملف تنفيذي.",
            conceptTag = "compiler",
            xpReward = 30
        ),

        // L0_10 Exercise - Arrange Code (Requirement 15)
        Exercise(
            id = "ex_l0_10",
            lessonId = "l0_10",
            type = ExerciseType.ARRANGE_CODE,
            titleArabic = "رتب أسطر أول برنامج C++",
            instructionsArabic = "رتب الأسطر التالية بالتسلسل الصحيح لبناء برنامج يطبع Hello, World!",
            arrangeLines = listOf(
                "    return 0;",
                "#include <iostream>",
                "    std::cout << \"Hello, World!\";",
                "int main() {",
                "}"
            ),
            correctLineOrder = listOf(1, 3, 2, 0, 4), // #include, int main(), cout, return, }
            educationalFeedback = "رائع جداً! يبدأ البرنامج بتضمين الترويسة <iostream>، ثم رأس الدالة int main() {، ثم أمر الطباعة، ثم return 0;، وأخيراً قوس الإغلاق }.",
            conceptTag = "first_program",
            xpReward = 35
        ),

        // L1_3 Exercise - Write Code
        Exercise(
            id = "ex_l1_3",
            lessonId = "l1_3",
            type = ExerciseType.WRITE_CODE,
            titleArabic = "طباعة رسالة ترحيبية",
            instructionsArabic = "اكتب السطر البرمجي لطباعة كلمة C++ على الشاشة باستخدام std::cout:",
            starterCode = "#include <iostream>\nint main() {\n    // اكتب أمر الطباعة هنا\n    return 0;\n}",
            solutionCode = "std::cout << \"C++\";",
            expectedOutput = "C++",
            educationalFeedback = "أحسنت! استخدمت std::cout مع أسهم الإرسال << ووضعت الكلمة بين علامتي اقتباس مزدوجتين ثم ختمت بفاصلة منقوطة ;.",
            conceptTag = "cout_cin",
            xpReward = 35
        ),

        // L1_4 Exercise - Find the Error
        Exercise(
            id = "ex_l1_4",
            lessonId = "l1_4",
            type = ExerciseType.FIND_THE_ERROR,
            titleArabic = "اكتشف الخطأ القواعدي",
            instructionsArabic = "الكود التالي يرفض المترجم تنفيذه. أين يكمن الخطأ؟",
            starterCode = "#include <iostream>\nint main() {\n    std::cout << \"مرحبا يا عالم\"\n    return 0;\n}",
            options = listOf(
                "السطر الثالث ينقصه فاصلة منقوطة (;) في نهايته",
                "الكلمة main مكتوبة بشكل خاطئ",
                "ينقص السطر الأول علامة @"
            ),
            correctOptionIndex = 0,
            educationalFeedback = "إجابة صحيحة! نسي المبرمج الفاصلة المنقوطة ; في نهاية سطر الطباعة، مما منع المترجم من معرفة نهاية التعليمة.",
            conceptTag = "semicolon",
            xpReward = 30
        ),

        // L1_5 Exercise - Fill in the blank
        Exercise(
            id = "ex_l1_5",
            lessonId = "l1_5",
            type = ExerciseType.FILL_IN_THE_BLANK,
            titleArabic = "النزول لسطر جديد",
            instructionsArabic = "أكمل الفراغ بالرمز أو الكلمة المسؤولة عن النزول لسطر جديد بعد الطباعة:",
            blankPrefix = "std::cout << \"سطر أول\" << ",
            blankSuffix = ";",
            acceptedBlankAnswers = listOf("std::endl", "endl", "\"\\n\"", "'\\n'"),
            educationalFeedback = "ممتاز! std::endl (أو محرف الهروب \\n) هو المسؤول عن النزول لسطر جديد.",
            conceptTag = "cout_cin",
            xpReward = 30
        ),

        // L2_1 Exercise - Interactive Token / Write Code
        Exercise(
            id = "ex_l2_1",
            lessonId = "l2_1",
            type = ExerciseType.WRITE_CODE,
            titleArabic = "إنشاء متغير للعمر",
            instructionsArabic = "أنشئ متغيراً من نوع عدد صحيح اسمه age وخزن فيه الرقم 20:",
            starterCode = "#include <iostream>\nusing namespace std;\nint main() {\n    // عرّف المتغير هنا\n    return 0;\n}",
            solutionCode = "int age = 20;",
            expectedOutput = "",
            educationalFeedback = "ممتاز! قمت بتحديد نوع البيانات (int)، ثم اسم المتغير (age)، ثم إسناد القيمة (= 20)، ثم الفاصلة المنقوطة (;).",
            conceptTag = "variables",
            xpReward = 35
        ),

        // L2_2 Exercise - Predict Output
        Exercise(
            id = "ex_l2_2",
            lessonId = "l2_2",
            type = ExerciseType.PREDICT_OUTPUT,
            titleArabic = "توقع ناتج قطع الكسر في int",
            instructionsArabic = "إذا كان لدينا الكود التالي، ماذا سيطبع البرنامج؟\nint x = 7.9;\ncout << x;",
            options = listOf(
                "7",
                "7.9",
                "8",
                "خطأ في الترجمة"
            ),
            correctOptionIndex = 0,
            educationalFeedback = "صحيح! المتغير int يحذف الجزء العشري نهائياً (Truncation) دون تقريب رياضي، فتصبح القيمة 7.",
            conceptTag = "variables",
            xpReward = 30
        ),

        // L3_2 Exercise - Find the Error (Integer Division)
        Exercise(
            id = "ex_l3_2",
            lessonId = "l3_2",
            type = ExerciseType.FIND_THE_ERROR,
            titleArabic = "فخ القسمة الصحيحة",
            instructionsArabic = "كود يريد حساب متوسط رقمين 5 و 2 ويطبع 2.5، لكنه يطبع 2 فقط! ما السبب؟\ndouble avg = 5 / 2;",
            options = listOf(
                "لأن كلا الرقمين 5 و 2 صحيحان int، لذا نتج رقم صحيح 2 قبل حفظه في double",
                "لأن كلمة double لا تدعم الكسور",
                "لأن 5 مقسومة على 2 رياضياً تساوي 2"
            ),
            correctOptionIndex = 0,
            educationalFeedback = "دقيق جداً! عملية int / int تنتج int دائماً. للحل اكتب: 5.0 / 2 ليفهم المترجم أنك تريد قسمة عشرية دقيقة.",
            conceptTag = "operators",
            xpReward = 35
        ),

        // L3_3 Exercise - Modulo
        Exercise(
            id = "ex_l3_3",
            lessonId = "l3_3",
            type = ExerciseType.PREDICT_OUTPUT,
            titleArabic = "حساب باقي القسمة",
            instructionsArabic = "ما هو ناتج العملية التالية: 11 % 3 ؟",
            options = listOf(
                "2",
                "3",
                "3.66",
                "1"
            ),
            correctOptionIndex = 0,
            educationalFeedback = "صحيح! 3 * 3 = 9، ويتبقى من الـ 11 بالضبط 2.",
            conceptTag = "operators",
            xpReward = 30
        ),

        // L3_7 Exercise - User Input cin
        Exercise(
            id = "ex_l3_7",
            lessonId = "l3_7",
            type = ExerciseType.FILL_IN_THE_BLANK,
            titleArabic = "أمر الإدخال cin",
            instructionsArabic = "أكمل الفراغ بالرمز الصحيح للإدخال في المتغير score:",
            blankPrefix = "cin ",
            blankSuffix = " score;",
            acceptedBlankAnswers = listOf(">>"),
            educationalFeedback = "رائع! مع cin نستخدم أسهم الاستخراج >> المتجهة لليمين باتجاه المتغير.",
            conceptTag = "cout_cin",
            xpReward = 30
        )
    )
}
