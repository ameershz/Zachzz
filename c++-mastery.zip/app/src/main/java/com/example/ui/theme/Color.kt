package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Dark Theme Colors
val BackgroundDark = Color(0xFF0A0E17)
val SurfaceDark = Color(0xFF121826)
val SurfaceVariantDark = Color(0xFF1E2638)
val SurfaceCard = Color(0xFF161F30)

val PrimaryCyan = Color(0xFF00B4D8)
val PrimaryCyanLight = Color(0xFF90E0EF)
val PrimaryCyanDark = Color(0xFF0077B6)

val SecondaryEmerald = Color(0xFF10B981)
val SecondaryEmeraldDark = Color(0xFF059669)

val AccentAmber = Color(0xFFF59E0B)
val AccentPurple = Color(0xFF8B5CF6)
val ErrorRed = Color(0xFFEF4444)

val TextPrimaryDark = Color(0xFFF3F4F6)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextMutedDark = Color(0xFF6B7280)

// Code Syntax Highlighting Colors
val CodeBgDark = Color(0xFF0D1117)
val CodeGutterDark = Color(0xFF21262D)
val CodeLineNum = Color(0xFF6E7681)
val CodeKeyword = Color(0xFFFF7B72)
val CodeType = Color(0xFF79C0FF)
val CodeString = Color(0xFFA5D6FF)
val CodeNumber = Color(0xFFD2A8FF)
val CodeComment = Color(0xFF8B949E)
val CodePreprocessor = Color(0xFFFFA657)
val CodeOperator = Color(0xFFF0883E)
val CodeTokenHighlight = Color(0xFF1F6FEB)

// Light Theme Fallback
val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
