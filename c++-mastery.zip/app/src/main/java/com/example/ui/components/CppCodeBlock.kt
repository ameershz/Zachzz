package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.InteractiveToken
import com.example.ui.theme.CodeBgDark
import com.example.ui.theme.CodeComment
import com.example.ui.theme.CodeGutterDark
import com.example.ui.theme.CodeKeyword
import com.example.ui.theme.CodeLineNum
import com.example.ui.theme.CodeNumber
import com.example.ui.theme.CodeOperator
import com.example.ui.theme.CodePreprocessor
import com.example.ui.theme.CodeString
import com.example.ui.theme.CodeTokenHighlight
import com.example.ui.theme.CodeType
import com.example.ui.theme.PrimaryCyan

@Composable
fun CppCodeBlock(
    code: String,
    modifier: Modifier = Modifier,
    title: String? = null,
    interactiveTokens: List<InteractiveToken> = emptyList(),
    onTokenClicked: ((InteractiveToken) -> Unit)? = null,
    onRunClicked: (() -> Unit)? = null
) {
    val clipboardManager = LocalClipboardManager.current
    val lines = code.lines()

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f), RoundedCornerShape(12.dp)),
        color = CodeBgDark
    ) {
        Column {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CodeGutterDark)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // C++ Badge
                    Box(
                        modifier = Modifier
                            .background(PrimaryCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "C++",
                            color = PrimaryCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    if (interactiveTokens.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                tint = PrimaryCyan,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "اضغط على الأجزاء للشرح",
                                color = PrimaryCyan,
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (title != null) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = title,
                            color = Color(0xFFC9D1D9),
                            fontSize = 12.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onRunClicked != null) {
                        IconButton(
                            onClick = onRunClicked,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "تشغيل الكود",
                                tint = PrimaryCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = { clipboardManager.setText(AnnotatedString(code)) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ الكود",
                            tint = Color(0xFF8B949E),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // Interactive Tokens Chips if any
            if (interactiveTokens.isNotEmpty() && onTokenClicked != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CodeBgDark.copy(alpha = 0.95f))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    interactiveTokens.forEach { token ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CodeTokenHighlight.copy(alpha = 0.25f))
                                .border(1.dp, CodeTokenHighlight.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .clickable { onTokenClicked(token) }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = token.token,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "(${token.arabicRole})",
                                    color = PrimaryCyan,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }

            // Code Content with Line Numbers (Strictly LTR for code!)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .horizontalScroll(rememberScrollState())
                ) {
                    // Line numbers column
                    Column(
                        modifier = Modifier
                            .background(CodeBgDark)
                            .padding(start = 12.dp, end = 12.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        lines.indices.forEach { index ->
                            Text(
                                text = "${index + 1}",
                                color = CodeLineNum,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.End
                            )
                        }
                    }

                    // Divider line
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .background(CodeGutterDark)
                    )

                    // Code text column with basic highlighting
                    Column(
                        modifier = Modifier
                            .padding(start = 12.dp, end = 16.dp)
                    ) {
                        lines.forEach { line ->
                            Text(
                                text = highlightCppLine(line),
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun highlightCppLine(line: String): AnnotatedString {
    return buildAnnotatedString {
        val trimmed = line.trimStart()
        if (trimmed.startsWith("//") || trimmed.startsWith("/*")) {
            append(line)
            addStyle(SpanStyle(color = CodeComment), 0, line.length)
            return@buildAnnotatedString
        }

        if (trimmed.startsWith("#")) {
            append(line)
            addStyle(SpanStyle(color = CodePreprocessor, fontWeight = FontWeight.SemiBold), 0, line.length)
            return@buildAnnotatedString
        }

        append(line)

        // Keywords
        val keywords = listOf("return", "int", "double", "float", "char", "bool", "void", "if", "else", "for", "while", "do", "using", "namespace", "const", "class", "struct", "true", "false")
        keywords.forEach { kw ->
            val regex = Regex("""\b$kw\b""")
            regex.findAll(line).forEach { match ->
                val color = when (kw) {
                    "int", "double", "float", "char", "bool", "void", "string" -> CodeType
                    else -> CodeKeyword
                }
                addStyle(SpanStyle(color = color, fontWeight = FontWeight.SemiBold), match.range.first, match.range.last + 1)
            }
        }

        // Strings
        val stringRegex = Regex("""\"[^\"]*\"""")
        stringRegex.findAll(line).forEach { match ->
            addStyle(SpanStyle(color = CodeString), match.range.first, match.range.last + 1)
        }

        // Numbers
        val numRegex = Regex("""\b\d+(\.\d+)?\b""")
        numRegex.findAll(line).forEach { match ->
            addStyle(SpanStyle(color = CodeNumber), match.range.first, match.range.last + 1)
        }

        // Operators
        val opRegex = Regex("""(<<|>>|\+|\-|\*|/|%|=|==|!=|<=|>=|<|>)""")
        opRegex.findAll(line).forEach { match ->
            addStyle(SpanStyle(color = CodeOperator), match.range.first, match.range.last + 1)
        }
    }
}
