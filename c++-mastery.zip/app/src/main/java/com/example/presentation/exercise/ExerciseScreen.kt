package com.example.presentation.exercise

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.ExerciseType
import com.example.ui.components.CppCodeBlock
import com.example.ui.components.XpBadge
import com.example.ui.theme.CodeBgDark
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.SecondaryEmerald

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExerciseScreen(
    viewModel: ExerciseViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val exercise = state.exercise

    if (exercise == null) {
        Box(
            modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            Text("جارٍ تحميل التمرين...")
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "تمرين عملي", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("exercise_back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    XpBadge(xp = exercise.xpReward, modifier = Modifier.padding(end = 12.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Exercise Title & Type
            val typeTitle = when (exercise.type) {
                ExerciseType.WRITE_CODE -> "اكتب الكود"
                ExerciseType.PREDICT_OUTPUT -> "توقع المخرجات"
                ExerciseType.FIND_THE_ERROR -> "اكتشف الخطأ"
                ExerciseType.MULTIPLE_CHOICE -> "اختيار من متعدد"
                ExerciseType.FILL_IN_THE_BLANK -> "أكمل الفراغ"
                ExerciseType.ARRANGE_CODE -> "رتّب أسطر الكود"
                ExerciseType.MODIFY_CODE -> "عدّل الكود"
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .background(PrimaryCyan.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(text = typeTitle, color = PrimaryCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = exercise.titleArabic,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = exercise.instructionsArabic,
                fontSize = 14.sp,
                lineHeight = 22.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Starter Code display if available
            if (exercise.starterCode.isNotEmpty() && exercise.type != ExerciseType.WRITE_CODE && exercise.type != ExerciseType.MODIFY_CODE) {
                Spacer(modifier = Modifier.height(14.dp))
                CppCodeBlock(code = exercise.starterCode)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Dynamic Interaction depending on exercise type
            when (exercise.type) {
                ExerciseType.MULTIPLE_CHOICE,
                ExerciseType.PREDICT_OUTPUT,
                ExerciseType.FIND_THE_ERROR -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        exercise.options.forEachIndexed { index, option ->
                            val isSelected = state.selectedOptionIndex == index
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(
                                        1.dp,
                                        if (isSelected) PrimaryCyan else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { viewModel.selectOption(index) }
                                    .testTag("exercise_option_$index"),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) PrimaryCyan.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { viewModel.selectOption(index) },
                                        colors = RadioButtonDefaults.colors(selectedColor = PrimaryCyan)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = option,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }

                ExerciseType.FILL_IN_THE_BLANK -> {
                    Card(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = CodeBgDark)
                    ) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = exercise.blankPrefix,
                                    color = Color(0xFFC9D1D9),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = state.blankInput,
                                    onValueChange = { viewModel.updateBlankInput(it) },
                                    modifier = Modifier.fillMaxWidth().testTag("exercise_blank_input"),
                                    placeholder = { Text("اكتب إجابتك هنا...", color = Color.Gray) },
                                    textStyle = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 15.sp,
                                        color = PrimaryCyan
                                    ),
                                    singleLine = true
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = exercise.blankSuffix,
                                    color = Color(0xFFC9D1D9),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }

                ExerciseType.ARRANGE_CODE -> {
                    Text(
                        text = "استخدم الأسهم لإعادة ترتيب الأسطر بالتسلسل السليم:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            state.arrangedLines.forEachIndexed { index, line ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = CodeBgDark)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = line,
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 13.sp,
                                            modifier = Modifier.weight(1f)
                                        )

                                        Row {
                                            IconButton(
                                                onClick = { viewModel.moveArrangedLine(index, index - 1) },
                                                enabled = index > 0,
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.ArrowUpward, contentDescription = "أعلى", tint = PrimaryCyan)
                                            }
                                            IconButton(
                                                onClick = { viewModel.moveArrangedLine(index, index + 1) },
                                                enabled = index < state.arrangedLines.size - 1,
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.ArrowDownward, contentDescription = "أسفل", tint = PrimaryCyan)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                ExerciseType.WRITE_CODE,
                ExerciseType.MODIFY_CODE -> {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        OutlinedTextField(
                            value = state.userCode,
                            onValueChange = { viewModel.updateUserCode(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .testTag("exercise_code_editor"),
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                                color = Color(0xFFE6EDF3)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Feedback Banner
            AnimatedVisibility(visible = state.isSubmitted) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            1.dp,
                            if (state.isCorrect) SecondaryEmerald else ErrorRed,
                            RoundedCornerShape(14.dp)
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (state.isCorrect) SecondaryEmerald.copy(alpha = 0.12f) else ErrorRed.copy(alpha = 0.12f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (state.isCorrect) Icons.Default.Check else Icons.Default.Close,
                                contentDescription = null,
                                tint = if (state.isCorrect) SecondaryEmerald else ErrorRed
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (state.isCorrect) "إجابة صحيحة ✓" else "إجابة خاطئة ✕",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isCorrect) SecondaryEmerald else ErrorRed
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = state.feedbackMessage,
                            fontSize = 14.sp,
                            lineHeight = 22.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Submit / Retry Actions
            if (!state.isSubmitted) {
                Button(
                    onClick = { viewModel.submitAnswer() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_exercise_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "تحقق من الحل ✓",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (!state.isCorrect) {
                        OutlinedButton(
                            onClick = { viewModel.retry() },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("retry_exercise_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إعادة المحاولة")
                            }
                        }
                    }

                    Button(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("finish_exercise_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SecondaryEmerald,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "العودة للدرس",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
