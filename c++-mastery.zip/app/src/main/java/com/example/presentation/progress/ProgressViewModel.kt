package com.example.presentation.progress

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.entity.BookmarkEntity
import com.example.data.repository.ContentRepository
import com.example.data.repository.UserProgressRepository
import com.example.domain.model.Achievement
import com.example.domain.model.UserLevel
import com.example.domain.model.UserStats
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class ProgressUiState(
    val stats: UserStats = UserStats(),
    val level: UserLevel = UserLevel.ALL_LEVELS.first(),
    val achievements: List<Achievement> = emptyList(),
    val bookmarks: List<BookmarkEntity> = emptyList(),
    val unlockedAchievementsCount: Int = 0,
    val totalAchievementsCount: Int = 0
)

class ProgressViewModel(
    private val progressRepository: UserProgressRepository,
    private val contentRepository: ContentRepository
) : ViewModel() {

    val uiState: StateFlow<ProgressUiState> = combine(
        progressRepository.userStats,
        progressRepository.achievements,
        progressRepository.bookmarks
    ) { stats, allAchievements, userBookmarks ->
        val userLevel = UserLevel.fromXp(stats.totalXp)
        val unlockedCount = allAchievements.count { it.isUnlocked }

        ProgressUiState(
            stats = stats,
            level = userLevel,
            achievements = allAchievements,
            bookmarks = userBookmarks,
            unlockedAchievementsCount = unlockedCount,
            totalAchievementsCount = allAchievements.size
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = ProgressUiState()
    )
}
