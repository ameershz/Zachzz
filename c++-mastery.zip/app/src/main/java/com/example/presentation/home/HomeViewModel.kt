package com.example.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ContentRepository
import com.example.data.repository.UserProgressRepository
import com.example.domain.model.Lesson
import com.example.domain.model.ReviewConcept
import com.example.domain.model.UserLevel
import com.example.domain.model.UserStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class HomeUiState(
    val userStats: UserStats = UserStats(),
    val userLevel: UserLevel = UserLevel.ALL_LEVELS.first(),
    val totalLessonsCount: Int = 40,
    val completedLessonsCount: Int = 0,
    val progressPercent: Int = 0,
    val currentLesson: Lesson? = null,
    val nextLesson: Lesson? = null,
    val reviewItems: List<ReviewConcept> = emptyList(),
    val isLoading: Boolean = false
)

class HomeViewModel(
    private val progressRepository: UserProgressRepository,
    private val contentRepository: ContentRepository
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = combine(
        progressRepository.userStats,
        progressRepository.completedLessonIds,
        progressRepository.mistakeConcepts
    ) { stats, completedIds, mistakes ->
        val allLessons = contentRepository.getAllLessons()
        val totalCount = allLessons.size
        val completedCount = completedIds.size
        val percent = if (totalCount > 0) ((completedCount.toDouble() / totalCount.toDouble()) * 100).toInt() else 0

        // Find the current lesson to continue (first non-completed lesson or first lesson)
        val current = allLessons.firstOrNull { !completedIds.contains(it.id) } ?: allLessons.firstOrNull()
        val next = if (current != null) contentRepository.getNextLesson(current.id) else null

        HomeUiState(
            userStats = stats,
            userLevel = UserLevel.fromXp(stats.totalXp),
            totalLessonsCount = totalCount,
            completedLessonsCount = completedCount,
            progressPercent = percent,
            currentLesson = current,
            nextLesson = next,
            reviewItems = mistakes,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HomeUiState(isLoading = true)
    )
}
