package com.example.presentation.navigation

sealed class Screen(val route: String) {
    // Bottom Bar tabs
    object Home : Screen("home")
    object Path : Screen("path")
    object Lab : Screen("lab")
    object Challenges : Screen("challenges")
    object Progress : Screen("progress")

    // Sub-screens
    object LessonDetail : Screen("lesson_detail/{lessonId}") {
        fun createRoute(lessonId: String) = "lesson_detail/$lessonId"
    }
    object Exercise : Screen("exercise/{exerciseId}") {
        fun createRoute(exerciseId: String) = "exercise/$exerciseId"
    }
    object Quiz : Screen("quiz/{quizId}") {
        fun createRoute(quizId: String) = "quiz/$quizId"
    }
    object ChallengeDetail : Screen("challenge_detail/{challengeId}") {
        fun createRoute(challengeId: String) = "challenge_detail/$challengeId"
    }
    object ProjectDetail : Screen("project_detail/{projectId}") {
        fun createRoute(projectId: String) = "project_detail/$projectId"
    }
    object SmartReview : Screen("smart_review")
    object Settings : Screen("settings")
    object Notes : Screen("notes")
}
