package com.example.presentation.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryCyan

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Appearance Section
            Text(text = "المظهر والواجهة", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = PrimaryCyan)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Dark Mode Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.DarkMode, contentDescription = null, tint = PrimaryCyan)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "الوضع الداكن (Dark Mode)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                Text(text = "مريح للعين ومناسب لكتابة الكود", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Switch(
                            checked = state.isDarkMode,
                            onCheckedChange = { viewModel.toggleDarkMode(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = PrimaryCyan)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Code Font Size Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.FormatSize, contentDescription = null, tint = PrimaryCyan)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "حجم خط محرر الكود", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                Text(text = "حجم الخط داخل المحرر والكونسول", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = state.codeFontSize == 13,
                            onClick = { viewModel.setCodeFontSize(13) },
                            label = { Text("صغير (13sp)") }
                        )
                        FilterChip(
                            selected = state.codeFontSize == 15,
                            onClick = { viewModel.setCodeFontSize(15) },
                            label = { Text("متوسط (15sp)") }
                        )
                        FilterChip(
                            selected = state.codeFontSize == 17,
                            onClick = { viewModel.setCodeFontSize(17) },
                            label = { Text("كبير (17sp)") }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Sound Effects Section
            Text(text = "المؤثرات", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = PrimaryCyan)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, tint = PrimaryCyan)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "المؤثرات الصوتية والاهتزاز", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                            Text(text = "تفاعل حسي عند إكمال المهام والاختبارات", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Switch(
                        checked = state.isSoundEffectsEnabled,
                        onCheckedChange = { viewModel.toggleSoundEffects(it) },
                        colors = SwitchDefaults.colors(checkedThumbColor = PrimaryCyan)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Danger Zone (Reset Progress)
            Text(text = "منطقة الخطر", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = ErrorRed)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, ErrorRed.copy(alpha = 0.3f), RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = ErrorRed.copy(alpha = 0.06f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = ErrorRed)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "إعادة ضبط التقدم بالكامل", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = ErrorRed)
                            Text(text = "حذف كل بيانات الدروس والـ XP والبدء من الصفر", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedButton(
                        onClick = { viewModel.openResetDialog() },
                        modifier = Modifier.fillMaxWidth().testTag("open_reset_progress_dialog"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(text = "إعادة ضبط تقدمي في التطبيق", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // About Application Section
            Card(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = PrimaryCyan)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(text = "حول التطبيق", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "C++ Mastery — Zero to C++",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryCyan
                    )
                    Text(
                        text = "الإصدار 1.0.0 (Native Offline Edition)\nمنصة تعليمية متكاملة مصممة لشخص يبدأ من الصفر المطلق في البرمجة. يعمل التطبيق بدون إنترنت ويحتوي على محرك كود محلي وتمارين واختبارات وتتبع تقدم في الذاكرة المحلية.",
                        fontSize = 13.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }

    // Confirmation Alert Dialog for Progress Reset
    if (state.isResetDialogOpen) {
        AlertDialog(
            onDismissRequest = { viewModel.closeResetDialog() },
            title = {
                Text(text = "⚠️ تأكيد إعادة ضبط التقدم", fontWeight = FontWeight.Bold, color = ErrorRed)
            },
            text = {
                Text(
                    text = "هل أنت متأكد تماماً من رغبتك في حذف كل تقدمك، نقاط الـ XP، التمارين، والاختبارات المحفوظة؟\n\nهذا الإجراء نهائي ولا يمكن التراجع عنه.",
                    fontSize = 14.sp,
                    lineHeight = 22.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.confirmResetProgress() },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed, contentColor = Color.White),
                    modifier = Modifier.testTag("confirm_reset_progress_button")
                ) {
                    Text("نعم، احذف وأعد من البداية")
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.closeResetDialog() }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
