package com.example.presentation.lab

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.domain.execution.CppExecutionEngine
import com.example.domain.execution.LocalCppInterpreterEngine
import com.example.domain.model.ExecutionResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class CodeSnippet(
    val title: String,
    val code: String,
    val sampleInput: String = ""
)

val DEFAULT_SNIPPETS = listOf(
    CodeSnippet(
        title = "أول برنامج (Hello World)",
        code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << \"مرحباً بكم في لغة C++!\" << endl;\n    cout << \"Hello from Mobile Code Lab!\" << endl;\n    return 0;\n}"
    ),
    CodeSnippet(
        title = "المتغيرات والحسابات",
        code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int a = 15;\n    int b = 4;\n    int sum = a + b;\n    double div = double(a) / b;\n    \n    cout << \"المجموع: \" << sum << endl;\n    cout << \"القسمة الدقيقة: \" << div << endl;\n    cout << \"باقي القسمة: \" << (a % b) << endl;\n    return 0;\n}"
    ),
    CodeSnippet(
        title = "الإدخال التفاعلي (cin)",
        code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int age;\n    cout << \"أدخل عمرك: \";\n    cin >> age;\n    cout << \"عمرك هو: \" << age << \" عاماً!\" << endl;\n    return 0;\n}",
        sampleInput = "22"
    ),
    CodeSnippet(
        title = "الشروط والقرارات (if-else)",
        code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    int score = 85;\n    if (score >= 90) {\n        cout << \"التقدير: ممتاز!\" << endl;\n    } else if (score >= 50) {\n        cout << \"التقدير: ناجح!\" << endl;\n    } else {\n        cout << \"التقدير: راسب!\" << endl;\n    }\n    return 0;\n}"
    ),
    CodeSnippet(
        title = "الحلقات التكرارية (Loops)",
        code = "#include <iostream>\nusing namespace std;\n\nint main() {\n    cout << \"العد التصاعدي: \" << endl;\n    for (int i = 1; i <= 5; i++) {\n        cout << i << \" \";\n    }\n    cout << endl;\n    return 0;\n}"
    )
)

data class CodeLabUiState(
    val currentCode: String = DEFAULT_SNIPPETS.first().code,
    val currentInput: String = "",
    val executionResult: ExecutionResult? = null,
    val isRunning: Boolean = false,
    val availableSnippets: List<CodeSnippet> = DEFAULT_SNIPPETS
)

class CodeLabViewModel(
    private val executionEngine: CppExecutionEngine = LocalCppInterpreterEngine()
) : ViewModel() {

    private val _uiState = MutableStateFlow(CodeLabUiState())
    val uiState: StateFlow<CodeLabUiState> = _uiState.asStateFlow()

    fun updateCode(newCode: String) {
        _uiState.value = _uiState.value.copy(currentCode = newCode)
    }

    fun updateInput(newInput: String) {
        _uiState.value = _uiState.value.copy(currentInput = newInput)
    }

    fun loadSnippet(snippet: CodeSnippet) {
        _uiState.value = _uiState.value.copy(
            currentCode = snippet.code,
            currentInput = snippet.sampleInput,
            executionResult = null
        )
    }

    fun clearCode() {
        _uiState.value = _uiState.value.copy(
            currentCode = "",
            executionResult = null
        )
    }

    fun resetToDefault() {
        loadSnippet(DEFAULT_SNIPPETS.first())
    }

    fun runCode() {
        val code = _uiState.value.currentCode
        val input = _uiState.value.currentInput
        _uiState.value = _uiState.value.copy(isRunning = true)

        viewModelScope.launch {
            val result = executionEngine.execute(code, input)
            _uiState.value = _uiState.value.copy(
                executionResult = result,
                isRunning = false
            )
        }
    }
}
