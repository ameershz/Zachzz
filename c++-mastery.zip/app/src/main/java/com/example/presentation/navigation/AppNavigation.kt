package com.example.presentation.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.repository.ContentRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.UserProgressRepository
import com.example.presentation.challenges.ChallengesScreen
import com.example.presentation.challenges.ChallengesViewModel
import com.example.presentation.exercise.ExerciseScreen
import com.example.presentation.exercise.ExerciseViewModel
import com.example.presentation.home.HomeScreen
import com.example.presentation.home.HomeViewModel
import com.example.presentation.lab.CodeLabScreen
import com.example.presentation.lab.CodeLabViewModel
import com.example.presentation.lesson.LessonScreen
import com.example.presentation.lesson.LessonViewModel
import com.example.presentation.path.PathScreen
import com.example.presentation.path.PathViewModel
import com.example.presentation.progress.ProgressScreen
import com.example.presentation.progress.ProgressViewModel
import com.example.presentation.projects.ProjectsScreen
import com.example.presentation.projects.ProjectsViewModel
import com.example.presentation.quiz.QuizScreen
import com.example.presentation.quiz.QuizViewModel
import com.example.presentation.review.SmartReviewScreen
import com.example.presentation.review.SmartReviewViewModel
import com.example.presentation.settings.SettingsScreen
import com.example.presentation.settings.SettingsViewModel
import com.example.ui.theme.PrimaryCyan

sealed class BottomNavItem(
    val route: String,
    val titleArabic: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    object Home : BottomNavItem(Screen.Home.route, "الرئيسية", Icons.Filled.Home, Icons.Outlined.Home, "nav_home")
    object Path : BottomNavItem(Screen.Path.route, "المسار", Icons.Filled.Map, Icons.Outlined.Map, "nav_path")
    object Lab : BottomNavItem(Screen.Lab.route, "المختبر", Icons.Filled.Code, Icons.Outlined.Code, "nav_lab")
    object Challenges : BottomNavItem(Screen.Challenges.route, "التحديات", Icons.Filled.EmojiEvents, Icons.Outlined.EmojiEvents, "nav_challenges")
    object Progress : BottomNavItem(Screen.Progress.route, "التقدم", Icons.Filled.Person, Icons.Outlined.Person, "nav_progress")
}

val BOTTOM_NAV_ITEMS = listOf(
    BottomNavItem.Home,
    BottomNavItem.Path,
    BottomNavItem.Lab,
    BottomNavItem.Challenges,
    BottomNavItem.Progress
)

@Composable
fun AppNavigation(
    progressRepository: UserProgressRepository,
    contentRepository: ContentRepository,
    settingsRepository: SettingsRepository,
    modifier: Modifier = Modifier
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val showBottomBar = BOTTOM_NAV_ITEMS.any { it.route == currentRoute }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    BOTTOM_NAV_ITEMS.forEach { item ->
                        val selected = currentRoute == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != item.route) {
                                    navController.navigate(item.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.titleArabic
                                )
                            },
                            label = {
                                Text(
                                    text = item.titleArabic,
                                    fontSize = 12.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryCyan,
                                selectedTextColor = PrimaryCyan,
                                indicatorColor = PrimaryCyan.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag(item.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = modifier.padding(innerPadding)
        ) {
            // Tab 1: Home
            composable(Screen.Home.route) {
                val vm = HomeViewModel(progressRepository, contentRepository)
                HomeScreen(
                    viewModel = vm,
                    onNavigateToLesson = { lessonId ->
                        navController.navigate(Screen.LessonDetail.createRoute(lessonId))
                    },
                    onNavigateToLab = {
                        navController.navigate(Screen.Lab.route)
                    },
                    onNavigateToChallenges = {
                        navController.navigate(Screen.Challenges.route)
                    },
                    onNavigateToReview = {
                        navController.navigate(Screen.SmartReview.route)
                    },
                    onNavigateToSettings = {
                        navController.navigate(Screen.Settings.route)
                    }
                )
            }

            // Tab 2: Path
            composable(Screen.Path.route) {
                val vm = PathViewModel(progressRepository, contentRepository)
                PathScreen(
                    viewModel = vm,
                    onNavigateToLesson = { lessonId ->
                        navController.navigate(Screen.LessonDetail.createRoute(lessonId))
                    }
                )
            }

            // Tab 3: Lab
            composable(Screen.Lab.route) {
                val vm = CodeLabViewModel()
                CodeLabScreen(viewModel = vm)
            }

            // Tab 4: Challenges
            composable(Screen.Challenges.route) {
                val vm = ChallengesViewModel(contentRepository, progressRepository)
                ChallengesScreen(viewModel = vm)
            }

            // Tab 5: Progress
            composable(Screen.Progress.route) {
                val vm = ProgressViewModel(progressRepository, contentRepository)
                ProgressScreen(
                    viewModel = vm,
                    onNavigateToLesson = { lessonId ->
                        navController.navigate(Screen.LessonDetail.createRoute(lessonId))
                    },
                    onNavigateToSettings = {
                        navController.navigate(Screen.Settings.route)
                    }
                )
            }

            // Sub-screen: Lesson Detail
            composable(
                route = Screen.LessonDetail.route,
                arguments = listOf(navArgument("lessonId") { type = NavType.StringType })
            ) { backStackEntry ->
                val lessonId = backStackEntry.arguments?.getString("lessonId") ?: "l0_1"
                val vm = LessonViewModel(lessonId, contentRepository, progressRepository)
                LessonScreen(
                    viewModel = vm,
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToExercise = { exId ->
                        navController.navigate(Screen.Exercise.createRoute(exId))
                    },
                    onNavigateToQuiz = { qId ->
                        navController.navigate(Screen.Quiz.createRoute(qId))
                    },
                    onNavigateToNextLesson = { nextId ->
                        navController.navigate(Screen.LessonDetail.createRoute(nextId)) {
                            popUpTo(Screen.LessonDetail.createRoute(lessonId)) { inclusive = true }
                        }
                    }
                )
            }

            // Sub-screen: Exercise
            composable(
                route = Screen.Exercise.route,
                arguments = listOf(navArgument("exerciseId") { type = NavType.StringType })
            ) { backStackEntry ->
                val exId = backStackEntry.arguments?.getString("exerciseId") ?: ""
                val vm = ExerciseViewModel(exId, contentRepository, progressRepository)
                ExerciseScreen(
                    viewModel = vm,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Sub-screen: Quiz
            composable(
                route = Screen.Quiz.route,
                arguments = listOf(navArgument("quizId") { type = NavType.StringType })
            ) { backStackEntry ->
                val qId = backStackEntry.arguments?.getString("quizId") ?: ""
                val vm = QuizViewModel(qId, contentRepository, progressRepository)
                QuizScreen(
                    viewModel = vm,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Sub-screen: Smart Review
            composable(Screen.SmartReview.route) {
                val vm = SmartReviewViewModel(progressRepository)
                SmartReviewScreen(
                    viewModel = vm,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            // Sub-screen: Settings
            composable(Screen.Settings.route) {
                val vm = SettingsViewModel(settingsRepository, progressRepository)
                SettingsScreen(
                    viewModel = vm,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
