package com.example.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.SettingsRepository
import com.example.data.repository.UserProgressRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val isDarkMode: Boolean = true,
    val codeFontSize: Int = 15,
    val isSoundEffectsEnabled: Boolean = true,
    val isResetDialogOpen: Boolean = false
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val progressRepository: UserProgressRepository
) : ViewModel() {

    private val _dialogState = MutableStateFlow(false)

    val uiState: StateFlow<SettingsUiState> = combine(
        settingsRepository.isDarkMode,
        settingsRepository.codeFontSize,
        settingsRepository.isSoundEffectsEnabled,
        _dialogState
    ) { dark, size, sound, dialog ->
        SettingsUiState(
            isDarkMode = dark,
            codeFontSize = size,
            isSoundEffectsEnabled = sound,
            isResetDialogOpen = dialog
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = SettingsUiState()
    )

    fun toggleDarkMode(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setDarkMode(enabled) }
    }

    fun setCodeFontSize(size: Int) {
        viewModelScope.launch { settingsRepository.setCodeFontSize(size) }
    }

    fun toggleSoundEffects(enabled: Boolean) {
        viewModelScope.launch { settingsRepository.setSoundEffects(enabled) }
    }

    fun openResetDialog() {
        _dialogState.value = true
    }

    fun closeResetDialog() {
        _dialogState.value = false
    }

    fun confirmResetProgress() {
        viewModelScope.launch {
            progressRepository.resetAllProgress()
            _dialogState.value = false
        }
    }
}
