package com.example.presentation.challenges

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ContentRepository
import com.example.data.repository.UserProgressRepository
import com.example.domain.execution.CppExecutionEngine
import com.example.domain.execution.LocalCppInterpreterEngine
import com.example.domain.model.Challenge
import com.example.domain.model.ChallengeDifficulty
import com.example.domain.model.ExecutionResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class ChallengeItemState(
    val challenge: Challenge,
    val isSolved: Boolean = false
)

data class ChallengesUiState(
    val selectedDifficulty: ChallengeDifficulty? = null,
    val challenges: List<ChallengeItemState> = emptyList(),
    val activeChallenge: Challenge? = null,
    val activeChallengeCode: String = "",
    val activeChallengeResult: ExecutionResult? = null,
    val isChallengePassed: Boolean = false,
    val isEvaluating: Boolean = false
)

class ChallengesViewModel(
    private val contentRepository: ContentRepository,
    private val progressRepository: UserProgressRepository,
    private val executionEngine: CppExecutionEngine = LocalCppInterpreterEngine()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChallengesUiState())
    val uiState: StateFlow<ChallengesUiState> = _uiState.asStateFlow()

    init {
        loadChallenges()
    }

    private fun loadChallenges() {
        val all = contentRepository.getAllChallenges()
        viewModelScope.launch {
            progressRepository.userStats.collect { stats ->
                val diff = _uiState.value.selectedDifficulty
                val filtered = if (diff == null) all else all.filter { it.difficulty == diff }
                _uiState.value = _uiState.value.copy(
                    challenges = filtered.map { ch ->
                        ChallengeItemState(
                            challenge = ch,
                            isSolved = ch.isCompleted
                        )
                    }
                )
            }
        }
    }

    fun filterDifficulty(difficulty: ChallengeDifficulty?) {
        _uiState.value = _uiState.value.copy(selectedDifficulty = difficulty)
        loadChallenges()
    }

    fun openChallenge(challenge: Challenge) {
        _uiState.value = _uiState.value.copy(
            activeChallenge = challenge,
            activeChallengeCode = challenge.starterCode,
            activeChallengeResult = null,
            isChallengePassed = false
        )
    }

    fun closeActiveChallenge() {
        _uiState.value = _uiState.value.copy(activeChallenge = null)
    }

    fun updateActiveCode(code: String) {
        _uiState.value = _uiState.value.copy(activeChallengeCode = code)
    }

    fun testChallenge() {
        val ch = _uiState.value.activeChallenge ?: return
        val code = _uiState.value.activeChallengeCode
        _uiState.value = _uiState.value.copy(isEvaluating = true)

        viewModelScope.launch {
            val testCase = ch.testCases.firstOrNull()
            val input = testCase?.input ?: ""
            val result = executionEngine.execute(code, input)

            val output = result.output.trim()
            val expected = testCase?.expectedOutput?.trim() ?: ""
            val passed = output.contains(expected) || (expected.isNotEmpty() && output == expected)

            _uiState.value = _uiState.value.copy(
                activeChallengeResult = result,
                isChallengePassed = passed,
                isEvaluating = false
            )

            if (passed) {
                progressRepository.recordChallengeCompleted(ch.id, code, ch.xpReward)
            }
        }
    }
}
