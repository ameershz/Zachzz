package com.example.presentation.lab

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.ExecutionStatus
import com.example.ui.components.ConsoleOutputView
import com.example.ui.theme.CodeBgDark
import com.example.ui.theme.CodeGutterDark
import com.example.ui.theme.CodeLineNum
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PrimaryCyan

@Composable
fun CodeLabScreen(
    viewModel: CodeLabViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Top Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "مختبر الكود (Code Lab)",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "محرر تفاعلي لتجربة وتشغيل أكواد C++ أوفلاين",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Preset Snippets Horizontal Bar
        Text(
            text = "أمثلة جاهزة للبدء:",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            state.availableSnippets.forEach { snippet ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { viewModel.loadSnippet(snippet) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = snippet.title,
                        fontSize = 12.sp,
                        color = PrimaryCyan,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Editor Toolbar (Run, Copy, Reset, Clear)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                .background(CodeGutterDark)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(
                    onClick = { viewModel.runCode() },
                    enabled = !state.isRunning,
                    modifier = Modifier.height(38.dp).testTag("lab_run_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PrimaryCyan,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = if (state.isRunning) "جارٍ التشغيل..." else "تشغيل ▶", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }

            Row {
                IconButton(onClick = { clipboardManager.setText(AnnotatedString(state.currentCode)) }) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "نسخ", tint = Color(0xFF8B949E), modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { viewModel.resetToDefault() }) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "إعادة ضبط", tint = Color(0xFF8B949E), modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = { viewModel.clearCode() }) {
                    Icon(imageVector = Icons.Default.Clear, contentDescription = "مسح", tint = Color(0xFF8B949E), modifier = Modifier.size(18.dp))
                }
            }
        }

        // Code Editor Box with Line Numbers (LTR)
        val lines = state.currentCode.lines()
        val lineCount = lines.size.coerceAtLeast(1)

        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .background(CodeBgDark)
                    .clip(RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    // Line numbers gutter
                    Column(
                        modifier = Modifier
                            .width(36.dp)
                            .background(Color(0xFF161B22))
                            .padding(top = 16.dp, end = 6.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        (1..lineCount).forEach { num ->
                            Text(
                                text = "$num",
                                color = CodeLineNum,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 20.sp
                            )
                        }
                    }

                    // Editable code area
                    OutlinedTextField(
                        value = state.currentCode,
                        onValueChange = { viewModel.updateCode(it) },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("lab_code_editor_input"),
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = Color(0xFFE6EDF3)
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Input stream for cin (std::cin input simulation)
        Card(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "مدخلات المستخدم (إذا كان البرنامج يستخدم cin):",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    OutlinedTextField(
                        value = state.currentInput,
                        onValueChange = { viewModel.updateInput(it) },
                        modifier = Modifier.fillMaxWidth().testTag("lab_input_field"),
                        placeholder = { Text("أدخل القيم هنا مفصولة بمسافات...", fontSize = 12.sp, color = Color.Gray) },
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
                        singleLine = true
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Console Output View
        ConsoleOutputView(result = state.executionResult)

        // Educational Diagnostics Card if errors were detected
        val diagnostics = state.executionResult?.diagnostics ?: emptyList()
        val fatalDiagnostics = diagnostics.filter { it.rawMessage.startsWith("error:") }

        if (fatalDiagnostics.isNotEmpty()) {
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "💡 تحليل الخطأ التعليمي:",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = ErrorRed
            )
            Spacer(modifier = Modifier.height(8.dp))

            fatalDiagnostics.forEach { diag ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, ErrorRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(
                        containerColor = ErrorRed.copy(alpha = 0.1f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "سطر ${diag.lineNumber}: ${diag.arabicExplanation}",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "المقترح للتصحيح:\n${diag.suggestedFix}",
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            color = PrimaryCyan
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
