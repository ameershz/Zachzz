package com.example.presentation.path

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ContentRepository
import com.example.data.repository.UserProgressRepository
import com.example.domain.model.CourseLevel
import com.example.domain.model.LevelStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class LevelWithProgress(
    val level: CourseLevel,
    val status: LevelStatus,
    val completedLessonsCount: Int,
    val totalLessonsCount: Int
)

data class PathUiState(
    val levels: List<LevelWithProgress> = emptyList(),
    val completedLessonIds: Set<String> = emptySet(),
    val totalXp: Int = 0,
    val isLoading: Boolean = false
)

class PathViewModel(
    private val progressRepository: UserProgressRepository,
    private val contentRepository: ContentRepository
) : ViewModel() {

    val uiState: StateFlow<PathUiState> = combine(
        progressRepository.userStats,
        progressRepository.completedLessonIds
    ) { stats, completedIds ->
        val allLevels = contentRepository.getAllLevels()

        var foundCurrent = false
        val levelsWithProgress = allLevels.mapIndexed { index, level ->
            val totalInLevel = level.lessons.size
            val completedInLevel = level.lessons.count { completedIds.contains(it.id) }

            val status = if (totalInLevel > 0 && completedInLevel == totalInLevel) {
                LevelStatus.COMPLETED
            } else if (!foundCurrent && (stats.totalXp >= level.requiredXp || index == 0)) {
                foundCurrent = true
                LevelStatus.CURRENT
            } else if (foundCurrent) {
                LevelStatus.LOCKED
            } else {
                LevelStatus.LOCKED
            }

            LevelWithProgress(
                level = level,
                status = status,
                completedLessonsCount = completedInLevel,
                totalLessonsCount = totalInLevel
            )
        }

        PathUiState(
            levels = levelsWithProgress,
            completedLessonIds = completedIds,
            totalXp = stats.totalXp,
            isLoading = false
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = PathUiState(isLoading = true)
    )
}
