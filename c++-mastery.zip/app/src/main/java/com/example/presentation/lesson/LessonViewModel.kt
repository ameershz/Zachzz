package com.example.presentation.lesson

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ContentRepository
import com.example.data.repository.UserProgressRepository
import com.example.domain.model.InteractiveToken
import com.example.domain.model.Lesson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class LessonUiState(
    val lesson: Lesson? = null,
    val isCompleted: Boolean = false,
    val isBookmarked: Boolean = false,
    val selectedToken: InteractiveToken? = null,
    val isSaving: Boolean = false,
    val nextLessonId: String? = null
)

class LessonViewModel(
    private val lessonId: String,
    private val contentRepository: ContentRepository,
    private val progressRepository: UserProgressRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(LessonUiState())
    val uiState: StateFlow<LessonUiState> = _uiState.asStateFlow()

    init {
        loadLesson()
    }

    private fun loadLesson() {
        val lesson = contentRepository.getLesson(lessonId)
        val next = contentRepository.getNextLesson(lessonId)

        viewModelScope.launch {
            progressRepository.completedLessonIds.collect { completedSet ->
                val isDone = completedSet.contains(lessonId)
                _uiState.value = _uiState.value.copy(
                    lesson = lesson,
                    isCompleted = isDone,
                    nextLessonId = next?.id
                )
            }
        }

        viewModelScope.launch {
            progressRepository.isBookmarked(lessonId).collect { bookmarked ->
                _uiState.value = _uiState.value.copy(isBookmarked = bookmarked)
            }
        }
    }

    fun selectToken(token: InteractiveToken?) {
        _uiState.value = _uiState.value.copy(selectedToken = token)
    }

    fun toggleBookmark() {
        val lesson = _uiState.value.lesson ?: return
        viewModelScope.launch {
            progressRepository.toggleBookmark(
                lessonId = lesson.id,
                titleArabic = lesson.titleArabic,
                levelNumber = lesson.levelNumber,
                isCurrentBookmarked = _uiState.value.isBookmarked
            )
        }
    }

    fun markLessonCompleted(onCompleted: () -> Unit) {
        val lesson = _uiState.value.lesson ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSaving = true)
            progressRepository.completeLesson(
                lessonId = lesson.id,
                levelNumber = lesson.levelNumber,
                xpEarned = lesson.xpReward
            )
            _uiState.value = _uiState.value.copy(isCompleted = true, isSaving = false)
            onCompleted()
        }
    }
}
