package com.example.presentation.projects

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ContentRepository
import com.example.data.repository.UserProgressRepository
import com.example.domain.execution.CppExecutionEngine
import com.example.domain.execution.LocalCppInterpreterEngine
import com.example.domain.model.ExecutionResult
import com.example.domain.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProjectsUiState(
    val projects: List<Project> = emptyList(),
    val activeProject: Project? = null,
    val activeProjectCode: String = "",
    val activeExecutionResult: ExecutionResult? = null,
    val isEvaluating: Boolean = false,
    val isProjectCompleted: Boolean = false
)

class ProjectsViewModel(
    private val contentRepository: ContentRepository,
    private val progressRepository: UserProgressRepository,
    private val executionEngine: CppExecutionEngine = LocalCppInterpreterEngine()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProjectsUiState())
    val uiState: StateFlow<ProjectsUiState> = _uiState.asStateFlow()

    init {
        loadProjects()
    }

    private fun loadProjects() {
        val all = contentRepository.getAllProjects()
        _uiState.value = _uiState.value.copy(projects = all)
    }

    fun openProject(project: Project) {
        _uiState.value = _uiState.value.copy(
            activeProject = project,
            activeProjectCode = project.starterCode,
            activeExecutionResult = null,
            isProjectCompleted = project.isCompleted
        )
    }

    fun closeActiveProject() {
        _uiState.value = _uiState.value.copy(activeProject = null)
    }

    fun updateProjectCode(code: String) {
        _uiState.value = _uiState.value.copy(activeProjectCode = code)
    }

    fun runAndVerifyProject() {
        val proj = _uiState.value.activeProject ?: return
        val code = _uiState.value.activeProjectCode
        _uiState.value = _uiState.value.copy(isEvaluating = true)

        viewModelScope.launch {
            val result = executionEngine.execute(code)
            val success = result.status == com.example.domain.model.ExecutionStatus.SUCCESS && result.output.isNotEmpty()

            _uiState.value = _uiState.value.copy(
                activeExecutionResult = result,
                isProjectCompleted = success,
                isEvaluating = false
            )

            if (success) {
                progressRepository.recordProjectCompleted(proj.id, code, proj.xpReward)
            }
        }
    }
}
