package com.example.presentation.review

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.UserProgressRepository
import com.example.domain.model.ReviewConcept
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SmartReviewUiState(
    val reviewConcepts: List<ReviewConcept> = emptyList(),
    val isLoading: Boolean = false
)

class SmartReviewViewModel(
    private val progressRepository: UserProgressRepository
) : ViewModel() {

    val uiState: StateFlow<SmartReviewUiState> = progressRepository.mistakeConcepts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        ).let { flow ->
            kotlinx.coroutines.flow.MutableStateFlow(SmartReviewUiState()).apply {
                viewModelScope.launch {
                    progressRepository.mistakeConcepts.collect { list ->
                        value = SmartReviewUiState(reviewConcepts = list)
                    }
                }
            }
        }

    fun markConceptReviewed(conceptTag: String) {
        viewModelScope.launch {
            progressRepository.clearMistake(conceptTag)
        }
    }
}
