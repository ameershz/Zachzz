package com.example.presentation.lesson

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CommonMistakeCard
import com.example.ui.components.CppCodeBlock
import com.example.ui.components.TokenExplainerDialog
import com.example.ui.components.XpBadge
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.SecondaryEmerald

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonScreen(
    viewModel: LessonViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToExercise: (String) -> Unit,
    onNavigateToQuiz: (String) -> Unit,
    onNavigateToNextLesson: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val lesson = state.lesson

    if (lesson == null) {
        Box(
            modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "جارٍ تحميل محتوى الدرس...", color = MaterialTheme.colorScheme.onSurface)
        }
        return
    }

    // Token Explainer Dialog if active
    if (state.selectedToken != null) {
        TokenExplainerDialog(
            token = state.selectedToken!!,
            onDismiss = { viewModel.selectToken(null) }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "المستوى ${lesson.levelNumber} • درس ${lesson.lessonNumber}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("lesson_back_button")
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.toggleBookmark() },
                        modifier = Modifier.testTag("lesson_bookmark_button")
                    ) {
                        Icon(
                            imageVector = if (state.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "حفظ الدرس",
                            tint = if (state.isBookmarked) AccentAmber else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Lesson Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                XpBadge(xp = lesson.xpReward)
                Text(
                    text = "${lesson.estimatedMinutes} دقائق قراءة",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = lesson.titleArabic,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                lineHeight = 32.sp
            )

            Text(
                text = lesson.titleEnglish,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Introduction Box
            Card(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Text(
                    text = lesson.introduction,
                    modifier = Modifier.padding(16.dp),
                    fontSize = 15.sp,
                    lineHeight = 24.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Detailed Explanation
            Text(
                text = "الشرح والتفصيل",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = PrimaryCyan
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = lesson.detailedExplanation,
                fontSize = 15.sp,
                lineHeight = 26.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Visual Analogy if available
            if (lesson.visualAnalogy != null) {
                Spacer(modifier = Modifier.height(20.dp))
                val analogy = lesson.visualAnalogy!!
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, PrimaryCyan.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(
                        containerColor = PrimaryCyan.copy(alpha = 0.08f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = analogy.title,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryCyan
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = analogy.analogyArabic,
                            fontSize = 14.sp,
                            lineHeight = 22.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "🔬 في الواقع التقني:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = SecondaryEmerald
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = analogy.realTechExplanation,
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Code Blocks
            if (lesson.codeBlocks.isNotEmpty()) {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "مثال الكود التفاعلي",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryCyan
                )
                Spacer(modifier = Modifier.height(10.dp))

                lesson.codeBlocks.forEach { codeBlock ->
                    CppCodeBlock(
                        code = codeBlock.code,
                        interactiveTokens = codeBlock.interactiveTokens,
                        onTokenClicked = { token -> viewModel.selectToken(token) }
                    )
                    if (codeBlock.explanation.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = codeBlock.explanation,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                }
            }

            // Common Mistakes
            if (lesson.commonMistakes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "أخطاء شائعة يقع فيها المبتدئون",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error
                )
                Spacer(modifier = Modifier.height(10.dp))

                lesson.commonMistakes.forEach { mistake ->
                    CommonMistakeCard(mistake = mistake)
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Summary Points
            if (lesson.summaryPoints.isNotEmpty()) {
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "ملخص النقاط الذهبية",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = AccentAmber
                )
                Spacer(modifier = Modifier.height(10.dp))

                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        lesson.summaryPoints.forEach { point ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = point.icon, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = point.pointArabic,
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Action Buttons Section
            // 1. Solve Exercises Button if exercises exist
            if (lesson.exerciseIds.isNotEmpty()) {
                Button(
                    onClick = { onNavigateToExercise(lesson.exerciseIds.first()) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("lesson_exercises_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SecondaryEmerald,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.FitnessCenter, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "حل تمارين الدرس (${lesson.exerciseIds.size} تمارين)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // 2. Take Quiz Button if quiz exists
            if (lesson.quizId != null) {
                OutlinedButton(
                    onClick = { onNavigateToQuiz(lesson.quizId!!) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("lesson_quiz_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Quiz, contentDescription = null, tint = AccentAmber)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اختبر فهمك في هذا المستوى",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentAmber
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // 3. Complete lesson & next lesson CTA
            Button(
                onClick = {
                    viewModel.markLessonCompleted {
                        if (state.nextLessonId != null) {
                            onNavigateToNextLesson(state.nextLessonId!!)
                        } else {
                            onNavigateBack()
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("complete_lesson_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.isCompleted) MaterialTheme.colorScheme.surfaceVariant else PrimaryCyan,
                    contentColor = if (state.isCompleted) MaterialTheme.colorScheme.onSurface else Color.Black
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (state.isCompleted) Icons.Default.Check else Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isCompleted) "الدرس مكتمل ✓ الانتقال للتالي" else "إكمال الدرس وجمع +${lesson.xpReward} XP",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}
