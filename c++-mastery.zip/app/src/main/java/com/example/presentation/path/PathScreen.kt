package com.example.presentation.path

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Lesson
import com.example.domain.model.LevelStatus
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.PrimaryCyan
import com.example.ui.theme.SecondaryEmerald

@Composable
fun PathScreen(
    viewModel: PathViewModel,
    onNavigateToLesson: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Screen Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "خريطة التعلم الكاملة",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "16 مرحلة مصممة بعناية لتأخذك من الصفر المطلق إلى الاحتراف",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(state.levels, key = { it.level.levelNumber }) { levelItem ->
                LevelCard(
                    levelWithProgress = levelItem,
                    completedLessonIds = state.completedLessonIds,
                    onLessonClick = { lessonId ->
                        if (levelItem.status != LevelStatus.LOCKED) {
                            onNavigateToLesson(lessonId)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun LevelCard(
    levelWithProgress: LevelWithProgress,
    completedLessonIds: Set<String>,
    onLessonClick: (String) -> Unit
) {
    val level = levelWithProgress.level
    val status = levelWithProgress.status
    var isExpanded by remember { mutableStateOf(status == LevelStatus.CURRENT) }

    val (cardBorderColor, statusText, statusColor) = when (status) {
        LevelStatus.COMPLETED -> Triple(SecondaryEmerald.copy(alpha = 0.5f), "مكتمل ✓", SecondaryEmerald)
        LevelStatus.CURRENT -> Triple(PrimaryCyan.copy(alpha = 0.7f), "جاري التعلم ▶", PrimaryCyan)
        LevelStatus.LOCKED -> Triple(Color.Transparent, "مقفل 🔒", MaterialTheme.colorScheme.onSurfaceVariant)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, cardBorderColor, RoundedCornerShape(18.dp))
            .testTag("level_card_${level.levelNumber}"),
        colors = CardDefaults.cardColors(
            containerColor = if (status == LevelStatus.LOCKED) {
                MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Level header row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        if (status != LevelStatus.LOCKED && level.lessons.isNotEmpty()) {
                            isExpanded = !isExpanded
                        }
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Level Number Circle
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .background(
                                when (status) {
                                    LevelStatus.COMPLETED -> SecondaryEmerald.copy(alpha = 0.2f)
                                    LevelStatus.CURRENT -> PrimaryCyan.copy(alpha = 0.2f)
                                    LevelStatus.LOCKED -> MaterialTheme.colorScheme.surfaceVariant
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (status == LevelStatus.COMPLETED) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = SecondaryEmerald)
                        } else if (status == LevelStatus.LOCKED) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        } else {
                            Text(
                                text = "${level.levelNumber}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "المستوى ${level.levelNumber}",
                                fontSize = 12.sp,
                                color = statusColor,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = statusText,
                                fontSize = 11.sp,
                                color = statusColor
                            )
                        }

                        Text(
                            text = level.titleArabic,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (status == LevelStatus.LOCKED) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = level.titleEnglish,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (level.lessons.isNotEmpty() && status != LevelStatus.LOCKED) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "عرض الدروس",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = level.subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )

            if (level.lessons.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "${levelWithProgress.completedLessonsCount} / ${levelWithProgress.totalLessonsCount} درساً",
                    fontSize = 11.sp,
                    color = AccentAmber,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Expanded lessons list
            AnimatedVisibility(visible = isExpanded && level.lessons.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    level.lessons.forEach { lesson ->
                        LessonRowItem(
                            lesson = lesson,
                            isCompleted = completedLessonIds.contains(lesson.id),
                            onClick = { onLessonClick(lesson.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonRowItem(
    lesson: Lesson,
    isCompleted: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .testTag("lesson_item_${lesson.id}"),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .background(
                            if (isCompleted) SecondaryEmerald.copy(alpha = 0.2f) else MaterialTheme.colorScheme.background,
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "مكتمل",
                            tint = SecondaryEmerald,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Text(
                            text = "${lesson.lessonNumber}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = lesson.titleArabic,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${lesson.estimatedMinutes} دقائق • +${lesson.xpReward} XP",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "فتح الدرس",
                tint = if (isCompleted) SecondaryEmerald else PrimaryCyan,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
