package com.example.presentation.quiz

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ContentRepository
import com.example.data.repository.UserProgressRepository
import com.example.domain.model.Quiz
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class QuizUiState(
    val quiz: Quiz? = null,
    val currentQuestionIndex: Int = 0,
    val selectedOptionIndices: Map<Int, Int> = emptyMap(), // questionIndex -> optionIndex
    val isFinished: Boolean = false,
    val finalScore: Int = 0,
    val isPassed: Boolean = false
)

class QuizViewModel(
    private val quizId: String,
    private val contentRepository: ContentRepository,
    private val progressRepository: UserProgressRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(QuizUiState())
    val uiState: StateFlow<QuizUiState> = _uiState.asStateFlow()

    init {
        loadQuiz()
    }

    private fun loadQuiz() {
        val q = contentRepository.getQuiz(quizId)
        if (q != null) {
            _uiState.value = QuizUiState(quiz = q)
        }
    }

    fun selectOptionForCurrentQuestion(optionIndex: Int) {
        if (!_uiState.value.isFinished) {
            val currentIdx = _uiState.value.currentQuestionIndex
            val updated = _uiState.value.selectedOptionIndices.toMutableMap()
            updated[currentIdx] = optionIndex
            _uiState.value = _uiState.value.copy(selectedOptionIndices = updated)
        }
    }

    fun nextQuestion() {
        val q = _uiState.value.quiz ?: return
        val currentIdx = _uiState.value.currentQuestionIndex
        if (currentIdx < q.questions.size - 1) {
            _uiState.value = _uiState.value.copy(currentQuestionIndex = currentIdx + 1)
        } else {
            finishQuiz()
        }
    }

    fun previousQuestion() {
        val currentIdx = _uiState.value.currentQuestionIndex
        if (currentIdx > 0) {
            _uiState.value = _uiState.value.copy(currentQuestionIndex = currentIdx - 1)
        }
    }

    private fun finishQuiz() {
        val q = _uiState.value.quiz ?: return
        var score = 0

        q.questions.forEachIndexed { index, question ->
            val userOptionIdx = _uiState.value.selectedOptionIndices[index]
            if (userOptionIdx != null && userOptionIdx in question.options.indices && question.options[userOptionIdx].isCorrect) {
                score++
            } else {
                // Record mistake concept
                viewModelScope.launch {
                    progressRepository.recordMistake(question.conceptTag)
                }
            }
        }

        val passed = (score.toDouble() / q.questions.size.toDouble()) >= 0.7

        _uiState.value = _uiState.value.copy(
            isFinished = true,
            finalScore = score,
            isPassed = passed
        )

        viewModelScope.launch {
            progressRepository.recordQuizResult(
                quizId = q.id,
                score = score,
                totalQuestions = q.questions.size,
                xpEarned = if (passed) q.xpReward else 20
            )
        }
    }

    fun restartQuiz() {
        _uiState.value = _uiState.value.copy(
            currentQuestionIndex = 0,
            selectedOptionIndices = emptyMap(),
            isFinished = false,
            finalScore = 0
        )
    }
}
