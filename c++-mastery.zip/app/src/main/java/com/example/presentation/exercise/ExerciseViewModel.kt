package com.example.presentation.exercise

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.ContentRepository
import com.example.data.repository.UserProgressRepository
import com.example.domain.model.Exercise
import com.example.domain.model.ExerciseType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ExerciseUiState(
    val exercise: Exercise? = null,
    val selectedOptionIndex: Int = -1,
    val blankInput: String = "",
    val userCode: String = "",
    val arrangedLines: List<String> = emptyList(),
    val isSubmitted: Boolean = false,
    val isCorrect: Boolean = false,
    val feedbackMessage: String = "",
    val isSolvedPreviously: Boolean = false
)

class ExerciseViewModel(
    private val exerciseId: String,
    private val contentRepository: ContentRepository,
    private val progressRepository: UserProgressRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExerciseUiState())
    val uiState: StateFlow<ExerciseUiState> = _uiState.asStateFlow()

    init {
        loadExercise()
    }

    private fun loadExercise() {
        val ex = contentRepository.getExercise(exerciseId)
        if (ex != null) {
            _uiState.value = ExerciseUiState(
                exercise = ex,
                userCode = ex.starterCode,
                arrangedLines = ex.arrangeLines
            )
        }
    }

    fun selectOption(index: Int) {
        if (!_uiState.value.isSubmitted) {
            _uiState.value = _uiState.value.copy(selectedOptionIndex = index)
        }
    }

    fun updateBlankInput(input: String) {
        _uiState.value = _uiState.value.copy(blankInput = input)
    }

    fun updateUserCode(code: String) {
        _uiState.value = _uiState.value.copy(userCode = code)
    }

    fun moveArrangedLine(fromIndex: Int, toIndex: Int) {
        val currentList = _uiState.value.arrangedLines.toMutableList()
        if (fromIndex in currentList.indices && toIndex in currentList.indices) {
            val item = currentList.removeAt(fromIndex)
            currentList.add(toIndex, item)
            _uiState.value = _uiState.value.copy(arrangedLines = currentList)
        }
    }

    fun submitAnswer() {
        val ex = _uiState.value.exercise ?: return
        var correct = false

        when (ex.type) {
            ExerciseType.MULTIPLE_CHOICE,
            ExerciseType.PREDICT_OUTPUT,
            ExerciseType.FIND_THE_ERROR -> {
                correct = _uiState.value.selectedOptionIndex == ex.correctOptionIndex
            }
            ExerciseType.FILL_IN_THE_BLANK -> {
                val input = _uiState.value.blankInput.trim()
                correct = ex.acceptedBlankAnswers.any { it.trim().equals(input, ignoreCase = true) }
            }
            ExerciseType.ARRANGE_CODE -> {
                // Check if current arranged lines match the correctLineOrder
                val current = _uiState.value.arrangedLines
                val targetLines = ex.correctLineOrder.map { ex.arrangeLines[it] }
                correct = current == targetLines
            }
            ExerciseType.WRITE_CODE,
            ExerciseType.MODIFY_CODE -> {
                val user = _uiState.value.userCode.replace("\\s+".toRegex(), " ").trim()
                val sol = ex.solutionCode.replace("\\s+".toRegex(), " ").trim()
                correct = user.contains(sol) || user.contains(ex.expectedOutput) || (ex.solutionCode.isNotEmpty() && user.contains(ex.solutionCode.trim()))
            }
        }

        val feedback = if (correct) {
            "إجابة ممتازة وصحيحة! 🎉 +${ex.xpReward} XP\n" + ex.educationalFeedback
        } else {
            "إجابة غير دقيقة هذه المرة. ❌ حاول مجدداً وتذكر المفهوم التعليمي:\n" + ex.educationalFeedback
        }

        _uiState.value = _uiState.value.copy(
            isSubmitted = true,
            isCorrect = correct,
            feedbackMessage = feedback
        )

        viewModelScope.launch {
            if (correct) {
                progressRepository.recordExerciseSolved(ex.id, ex.lessonId, ex.xpReward)
            } else {
                progressRepository.recordMistake(ex.conceptTag)
            }
        }
    }

    fun retry() {
        val ex = _uiState.value.exercise ?: return
        _uiState.value = _uiState.value.copy(
            isSubmitted = false,
            isCorrect = false,
            selectedOptionIndex = -1,
            blankInput = "",
            feedbackMessage = ""
        )
    }
}
