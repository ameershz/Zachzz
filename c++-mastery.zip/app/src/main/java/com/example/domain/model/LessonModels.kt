package com.example.domain.model

enum class LevelStatus {
    LOCKED,
    CURRENT,
    COMPLETED
}

enum class LessonStatus {
    LOCKED,
    AVAILABLE,
    COMPLETED
}

data class InteractiveToken(
    val token: String,
    val arabicRole: String,
    val explanation: String,
    val isKeyword: Boolean = false
)

data class CodeBlock(
    val code: String,
    val explanation: String = "",
    val interactiveTokens: List<InteractiveToken> = emptyList(),
    val expectedOutput: String = ""
)

data class CommonMistake(
    val title: String,
    val incorrectCode: String,
    val correctCode: String,
    val whyItHappens: String,
    val howToFix: String
)

data class LessonSummaryPoint(
    val icon: String,
    val pointArabic: String
)

data class VisualAnalogy(
    val title: String,
    val analogyArabic: String,
    val realTechExplanation: String
)

data class Lesson(
    val id: String,
    val levelNumber: Int,
    val lessonNumber: Int,
    val titleArabic: String,
    val titleEnglish: String,
    val estimatedMinutes: Int,
    val xpReward: Int = 50,
    val introduction: String,
    val detailedExplanation: String,
    val visualAnalogy: VisualAnalogy? = null,
    val codeBlocks: List<CodeBlock> = emptyList(),
    val commonMistakes: List<CommonMistake> = emptyList(),
    val summaryPoints: List<LessonSummaryPoint> = emptyList(),
    val exerciseIds: List<String> = emptyList(),
    val quizId: String? = null
)

data class CourseLevel(
    val levelNumber: Int,
    val titleArabic: String,
    val titleEnglish: String,
    val subtitle: String,
    val iconName: String,
    val requiredXp: Int,
    val lessons: List<Lesson> = emptyList()
)
