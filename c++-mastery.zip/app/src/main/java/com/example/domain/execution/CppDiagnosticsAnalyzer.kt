package com.example.domain.execution

import com.example.domain.model.DiagnosticError

object CppDiagnosticsAnalyzer {

    fun analyze(code: String): List<DiagnosticError> {
        val diagnostics = mutableListOf<DiagnosticError>()
        val lines = code.lines()

        // 1. Check for missing main function
        if (!code.contains("main") || !code.contains("main(")) {
            diagnostics.add(
                DiagnosticError(
                    lineNumber = 1,
                    rawMessage = "error: 'main' function was not found in the program",
                    arabicExplanation = "نقطة البداية مفقودة! كل برنامج C++ يجب أن يحتوي على دالة رئيسية اسمها main() يبدأ الكمبيوتر بتنفيذ الأوامر منها.",
                    suggestedFix = "أضف دالة main:\nint main() {\n    // أكتب أوامرك هنا\n    return 0;\n}",
                    snippetBefore = code.take(50),
                    snippetAfter = "int main() {\n    return 0;\n}"
                )
            )
        }

        // 2. Check for missing iostream when using cout or cin
        if ((code.contains("cout") || code.contains("cin")) && !code.contains("iostream")) {
            diagnostics.add(
                DiagnosticError(
                    lineNumber = 1,
                    rawMessage = "error: 'cout' was not declared in this scope",
                    arabicExplanation = "استخدمت cout أو cin للطباعة أو الإدخال لكنك نسيت استدعاء مكتبة الإدخال والإخراج القياسية <iostream> في بداية الملف.",
                    suggestedFix = "أضف هذا السطر في أعلى البرنامج:\n#include <iostream>",
                    snippetBefore = "",
                    snippetAfter = "#include <iostream>"
                )
            )
        }

        // Line by line analysis
        lines.forEachIndexed { index, rawLine ->
            val lineNum = index + 1
            val trimmed = rawLine.trim()

            // Skip comments and preprocessors and empty lines
            if (trimmed.isEmpty() || trimmed.startsWith("//") || trimmed.startsWith("/*") || trimmed.startsWith("#")) {
                return@forEachIndexed
            }

            // Check for assignment with missing value: e.g. "int age = ;" or "x = ;"
            val assignmentNoValPattern = Regex("""=\s*;""")
            if (assignmentNoValPattern.containsMatchIn(trimmed)) {
                diagnostics.add(
                    DiagnosticError(
                        lineNumber = lineNum,
                        rawMessage = "error: expected primary-expression before ';' token",
                        arabicExplanation = "❌ يوجد خطأ: بعد علامة التساوي (=) يجب أن توجد قيمة يتم إسنادها للمتغير، لا يمكن وضع الفاصلة المنقوطة مباشرة بعد علامة =.",
                        suggestedFix = "ضع قيمة بعد علامة التساوي، مثل:\nint age = 20;",
                        snippetBefore = trimmed,
                        snippetAfter = trimmed.replace("= ;", "= 20;").replace("=;", "= 20;")
                    )
                )
            }

            // Check for missing semicolon
            // A statement that does not end with ; or { or } or : and is not a control statement like if, for, while, else
            val needsSemicolon = trimmed.isNotEmpty() &&
                    !trimmed.endsWith(";") &&
                    !trimmed.endsWith("{") &&
                    !trimmed.endsWith("}") &&
                    !trimmed.endsWith(":") &&
                    !trimmed.startsWith("if") &&
                    !trimmed.startsWith("for") &&
                    !trimmed.startsWith("while") &&
                    !trimmed.startsWith("else") &&
                    !trimmed.startsWith("switch") &&
                    !trimmed.startsWith("case") &&
                    !trimmed.startsWith("default") &&
                    !trimmed.startsWith("try") &&
                    !trimmed.startsWith("catch") &&
                    !trimmed.startsWith("class") &&
                    !trimmed.startsWith("struct") &&
                    !trimmed.startsWith("public") &&
                    !trimmed.startsWith("private") &&
                    !trimmed.startsWith("protected")

            if (needsSemicolon && (trimmed.contains("cout") || trimmed.contains("cin") || trimmed.contains("return") || trimmed.contains("="))) {
                diagnostics.add(
                    DiagnosticError(
                        lineNumber = lineNum,
                        rawMessage = "error: expected ';' before end of line",
                        arabicExplanation = "نسيت الفاصلة المنقوطة (;) في نهاية السطر. في لغة C++، تدل الفاصلة المنقوطة على انتهاء الأمر للكمبيوتر تماماً مثل النقطة في نهاية الجملة.",
                        suggestedFix = "أضف فاصلة منقوطة ; في نهاية السطر:\n$trimmed;",
                        snippetBefore = trimmed,
                        snippetAfter = "$trimmed;"
                    )
                )
            }

            // Check for inverted stream operators: cout >> or cin <<
            if (trimmed.contains(Regex("""cout\s*>>"""))) {
                diagnostics.add(
                    DiagnosticError(
                        lineNumber = lineNum,
                        rawMessage = "error: no match for 'operator>>' with 'std::cout'",
                        arabicExplanation = "مع cout نستخدم أسهم الإخراج المتجهة لليسار (<<) لأن البيانات تخرج للشاشة، بينما استخدمت أسهم الإدخال (>>).",
                        suggestedFix = "استبدل >> بـ << مع cout، هكذا:\ncout << \"Hello\";",
                        snippetBefore = trimmed,
                        snippetAfter = trimmed.replace(">>", "<<")
                    )
                )
            }
            if (trimmed.contains(Regex("""cin\s*<<"""))) {
                diagnostics.add(
                    DiagnosticError(
                        lineNumber = lineNum,
                        rawMessage = "error: no match for 'operator<<' with 'std::cin'",
                        arabicExplanation = "مع cin نستخدم أسهم الإدخال المتجهة لليمين (>>) لأن البيانات تأتي من لوحة المفاتيح وتدخل للمتغير، بينما استخدمت أسهم الإخراج (<<).",
                        suggestedFix = "استبدل << بـ >> مع cin، هكذا:\ncin >> variableName;",
                        snippetBefore = trimmed,
                        snippetAfter = trimmed.replace("<<", ">>")
                    )
                )
            }

            // Check for assignment in if condition: e.g. "if (x = 5)"
            val ifAssignPattern = Regex("""if\s*\(\s*[a-zA-Z_]\w*\s*=\s*[^=].*\)""")
            if (ifAssignPattern.containsMatchIn(trimmed) && !trimmed.contains("==") && !trimmed.contains("<=") && !trimmed.contains(">=")) {
                diagnostics.add(
                    DiagnosticError(
                        lineNumber = lineNum,
                        rawMessage = "warning/error: suggest parentheses around assignment used as truth value or '=='",
                        arabicExplanation = "تنبيه هام: استخدمت علامة تساوي واحدة (=) داخل جملة if. علامة = واحدة تعني إسناد وتغيير قيمة، بينما المقارنة والتحقق تتطلب علامتي تساوي (==).",
                        suggestedFix = "استخدم == للمقارنة الشرطية:\nif (x == 5)",
                        snippetBefore = trimmed,
                        snippetAfter = trimmed.replace("=", "==")
                    )
                )
            }

            // Check for unclosed string quote on single line
            val quoteCount = trimmed.count { it == '"' }
            if (quoteCount % 2 != 0 && !trimmed.contains("\\\"")) {
                diagnostics.add(
                    DiagnosticError(
                        lineNumber = lineNum,
                        rawMessage = "error: missing terminating '\"' character",
                        arabicExplanation = "نسيت إغلاق علامة التنصيص المزدوجة (\") للنص. كل نص يبدأ بـ \" يجب أن ينتهي بـ \".",
                        suggestedFix = "أغلق النص بـ \":\n$trimmed\"",
                        snippetBefore = trimmed,
                        snippetAfter = "$trimmed\""
                    )
                )
            }

            // Check for division by zero literal: / 0
            if (trimmed.contains(Regex("""/\s*0\b"""))) {
                diagnostics.add(
                    DiagnosticError(
                        lineNumber = lineNum,
                        rawMessage = "warning: division by zero is undefined behavior",
                        arabicExplanation = "القسمة على الصفر غير ممكنة في الرياضيات وتسبب انهيار البرنامج (Crash) في وقت التشغيل.",
                        suggestedFix = "تأكد من أن المقام رقم غير الصفر.",
                        snippetBefore = trimmed,
                        snippetAfter = trimmed
                    )
                )
            }
        }

        // Check brace matching
        val openBraces = code.count { it == '{' }
        val closeBraces = code.count { it == '}' }
        if (openBraces > closeBraces) {
            diagnostics.add(
                DiagnosticError(
                    lineNumber = lines.size,
                    rawMessage = "error: expected '}' at end of input",
                    arabicExplanation = "نسيت إغلاق قوس مجعد {}. عدد الأقواس المفتوحة ($openBraces) أكبر من المغلقة ($closeBraces).",
                    suggestedFix = "أضف قوس الإغلاق } في نهاية الدالة.",
                    snippetBefore = "",
                    snippetAfter = "}"
                )
            )
        } else if (closeBraces > openBraces) {
            diagnostics.add(
                DiagnosticError(
                    lineNumber = lines.size,
                    rawMessage = "error: extraneous closing brace '}'",
                    arabicExplanation = "يوجد قوس إغلاق زائد } ليس له قوس فتح مطابق.",
                    suggestedFix = "احذف القوس الزائد.",
                    snippetBefore = "",
                    snippetAfter = ""
                )
            )
        }

        return diagnostics
    }
}
