package com.example.domain.model

enum class ChallengeDifficulty {
    EASY,
    MEDIUM,
    HARD
}

data class TestCase(
    val input: String = "",
    val expectedOutput: String,
    val description: String = ""
)

data class Challenge(
    val id: String,
    val titleArabic: String,
    val titleEnglish: String,
    val difficulty: ChallengeDifficulty,
    val xpReward: Int,
    val requiredLevel: Int,
    val descriptionArabic: String,
    val hintsArabic: List<String>,
    val starterCode: String,
    val testCases: List<TestCase>,
    val isCompleted: Boolean = false
)
