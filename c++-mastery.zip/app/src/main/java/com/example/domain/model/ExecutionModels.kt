package com.example.domain.model

enum class ExecutionStatus {
    SUCCESS,
    SYNTAX_ERROR,
    RUNTIME_ERROR,
    TIMEOUT
}

data class DiagnosticError(
    val lineNumber: Int,
    val columnNumber: Int = 0,
    val rawMessage: String,
    val arabicExplanation: String,
    val suggestedFix: String,
    val snippetBefore: String = "",
    val snippetAfter: String = ""
)

data class ExecutionResult(
    val status: ExecutionStatus,
    val output: String,
    val errorOutput: String = "",
    val diagnostics: List<DiagnosticError> = emptyList(),
    val executionTimeMs: Long = 0,
    val engineName: String = "محرك C++ المحلي (Offline Interpreter)"
)
