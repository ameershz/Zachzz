package com.example.domain.execution

import com.example.domain.model.ExecutionResult

interface CppExecutionEngine {
    val engineName: String
    suspend fun execute(code: String, input: String = ""): ExecutionResult
}
