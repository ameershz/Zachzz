package com.example.domain.model

data class UserLevel(
    val levelNumber: Int,
    val titleArabic: String,
    val titleEnglish: String,
    val minXp: Int,
    val maxXp: Int
) {
    companion object {
        val ALL_LEVELS = listOf(
            UserLevel(1, "مبتدئ", "Beginner", 0, 200),
            UserLevel(2, "مستكشف", "Explorer", 200, 500),
            UserLevel(3, "متعلم C++", "C++ Learner", 500, 1000),
            UserLevel(4, "مبرمج واعد", "Junior Coder", 1000, 2000),
            UserLevel(5, "مطور C++", "C++ Developer", 2000, 3500),
            UserLevel(6, "محترف", "Advanced", 3500, 6000),
            UserLevel(7, "خبير C++", "C++ Master", 6000, 10000)
        )

        fun fromXp(xp: Int): UserLevel {
            return ALL_LEVELS.lastOrNull { xp >= it.minXp } ?: ALL_LEVELS.first()
        }
    }
}

data class Achievement(
    val id: String,
    val titleArabic: String,
    val descriptionArabic: String,
    val iconEmoji: String,
    val xpReward: Int,
    val isUnlocked: Boolean = false,
    val unlockedAtMillis: Long? = null
)

data class UserStats(
    val totalXp: Int = 0,
    val level: Int = 1,
    val currentStreak: Int = 1,
    val lastActiveDateMillis: Long = System.currentTimeMillis(),
    val completedLessonsCount: Int = 0,
    val solvedExercisesCount: Int = 0,
    val solvedChallengesCount: Int = 0,
    val completedProjectsCount: Int = 0,
    val reviewItemsCount: Int = 0
)

data class ReviewConcept(
    val conceptTag: String,
    val titleArabic: String,
    val mistakeCount: Int,
    val tipArabic: String
)
