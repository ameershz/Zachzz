package com.example.domain.execution

import com.example.domain.model.ExecutionResult
import com.example.domain.model.ExecutionStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LocalCppInterpreterEngine : CppExecutionEngine {

    override val engineName: String = "محرك C++ المحلي (Offline Interpreter)"

    override suspend fun execute(code: String, input: String): ExecutionResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        // 1. Run diagnostic analyzer first
        val diagnostics = CppDiagnosticsAnalyzer.analyze(code)
        val fatalDiagnostics = diagnostics.filter { it.rawMessage.startsWith("error:") }

        if (fatalDiagnostics.isNotEmpty()) {
            val errorText = fatalDiagnostics.joinToString("\n") { diag ->
                "سطر ${diag.lineNumber}: ${diag.arabicExplanation}\n→ المقترح: ${diag.suggestedFix}"
            }
            return@withContext ExecutionResult(
                status = ExecutionStatus.SYNTAX_ERROR,
                output = "",
                errorOutput = errorText,
                diagnostics = diagnostics,
                executionTimeMs = System.currentTimeMillis() - startTime,
                engineName = engineName
            )
        }

        // 2. Execute code in simulated runtime
        try {
            val interpreter = CppInterpreterRuntime(code, input)
            val output = interpreter.run()

            ExecutionResult(
                status = ExecutionStatus.SUCCESS,
                output = output,
                errorOutput = "",
                diagnostics = diagnostics,
                executionTimeMs = System.currentTimeMillis() - startTime,
                engineName = engineName
            )
        } catch (e: Exception) {
            ExecutionResult(
                status = ExecutionStatus.RUNTIME_ERROR,
                output = "",
                errorOutput = "خطأ في وقت التشغيل (Runtime Error): ${e.message ?: "حدث خطأ غير متوقع"}",
                diagnostics = diagnostics,
                executionTimeMs = System.currentTimeMillis() - startTime,
                engineName = engineName
            )
        }
    }
}

private class CppInterpreterRuntime(
    private val rawCode: String,
    inputString: String
) {
    private val inputTokens = inputString.split("\\s+".toRegex()).filter { it.isNotEmpty() }.toMutableList()
    private val variables = mutableMapOf<String, Any>()
    private val outputBuffer = StringBuilder()

    fun run(): String {
        // Extract body of main() function
        val mainBody = extractMainBody(rawCode)
        val statements = splitIntoStatements(mainBody)

        executeBlock(statements)

        val result = outputBuffer.toString()
        return if (result.isEmpty()) "[تم تنفيذ البرنامج بنجاح دون طباعة أي مخرجات]" else result
    }

    private fun extractMainBody(code: String): String {
        val mainIndex = code.indexOf("main(")
        if (mainIndex == -1) return code

        val braceOpen = code.indexOf('{', mainIndex)
        if (braceOpen == -1) return code

        var depth = 1
        var curr = braceOpen + 1
        while (curr < code.length && depth > 0) {
            if (code[curr] == '{') depth++
            else if (code[curr] == '}') depth--
            curr++
        }

        return if (depth == 0) code.substring(braceOpen + 1, curr - 1) else code.substring(braceOpen + 1)
    }

    private fun splitIntoStatements(block: String): List<String> {
        val statements = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuote = false
        var braceDepth = 0

        for (ch in block) {
            if (ch == '"') inQuote = !inQuote

            if (!inQuote) {
                if (ch == '{') braceDepth++
                else if (ch == '}') braceDepth--
            }

            sb.append(ch)

            if (!inQuote && braceDepth == 0 && (ch == ';' || ch == '}')) {
                val stmt = sb.toString().trim()
                if (stmt.isNotEmpty()) {
                    statements.add(stmt)
                }
                sb.clear()
            }
        }

        val remaining = sb.toString().trim()
        if (remaining.isNotEmpty()) statements.add(remaining)
        return statements
    }

    private fun executeBlock(statements: List<String>) {
        var i = 0
        while (i < statements.size) {
            val stmt = statements[i].trim()
            if (stmt.startsWith("//") || stmt.isEmpty()) {
                i++
                continue
            }

            if (stmt.startsWith("return")) {
                break
            }

            if (stmt.startsWith("for") || stmt.startsWith("while") || stmt.startsWith("if")) {
                i = executeControlStructure(statements, i)
            } else {
                executeSimpleStatement(stmt)
                i++
            }
        }
    }

    private fun executeControlStructure(statements: List<String>, index: Int): Int {
        val stmt = statements[index].trim()

        // Handle IF statements
        if (stmt.startsWith("if")) {
            val condStart = stmt.indexOf('(')
            val condEnd = stmt.indexOf(')', condStart)
            if (condStart != -1 && condEnd != -1) {
                val conditionStr = stmt.substring(condStart + 1, condEnd).trim()
                val isTrue = evaluateCondition(conditionStr)

                val body = extractInnerBlock(stmt)
                if (isTrue) {
                    val innerStatements = splitIntoStatements(body)
                    executeBlock(innerStatements)
                } else {
                    // Check if there is an else clause in same statement or next
                    if (stmt.contains("else")) {
                        val elseIndex = stmt.indexOf("else")
                        val elsePart = stmt.substring(elseIndex + 4).trim()
                        val elseBody = extractInnerBlock(elsePart)
                        val innerStatements = splitIntoStatements(elseBody)
                        executeBlock(innerStatements)
                    }
                }
            }
            return index + 1
        }

        // Handle WHILE loops
        if (stmt.startsWith("while")) {
            val condStart = stmt.indexOf('(')
            val condEnd = stmt.indexOf(')', condStart)
            if (condStart != -1 && condEnd != -1) {
                val conditionStr = stmt.substring(condStart + 1, condEnd).trim()
                val body = extractInnerBlock(stmt)
                val innerStatements = splitIntoStatements(body)

                var iterations = 0
                while (evaluateCondition(conditionStr) && iterations < 1000) {
                    executeBlock(innerStatements)
                    iterations++
                }
            }
            return index + 1
        }

        // Handle FOR loops: for (int i = 0; i < 5; i++) { ... }
        if (stmt.startsWith("for")) {
            val parenStart = stmt.indexOf('(')
            val parenEnd = stmt.indexOf(')', parenStart)
            if (parenStart != -1 && parenEnd != -1) {
                val loopHeader = stmt.substring(parenStart + 1, parenEnd)
                val parts = loopHeader.split(';')
                if (parts.size == 3) {
                    executeSimpleStatement(parts[0].trim() + ";")
                    val conditionStr = parts[1].trim()
                    val incrementStr = parts[2].trim()

                    val body = extractInnerBlock(stmt)
                    val innerStatements = splitIntoStatements(body)

                    var iterations = 0
                    while (evaluateCondition(conditionStr) && iterations < 1000) {
                        executeBlock(innerStatements)
                        executeSimpleStatement(incrementStr + if (incrementStr.endsWith(";")) "" else ";")
                        iterations++
                    }
                }
            }
            return index + 1
        }

        return index + 1
    }

    private fun extractInnerBlock(stmt: String): String {
        val braceOpen = stmt.indexOf('{')
        val braceClose = stmt.lastIndexOf('}')
        return if (braceOpen != -1 && braceClose != -1 && braceClose > braceOpen) {
            stmt.substring(braceOpen + 1, braceClose).trim()
        } else {
            // Single line without braces
            val parenClose = stmt.indexOf(')')
            if (parenClose != -1) stmt.substring(parenClose + 1).trim() else stmt
        }
    }

    private fun executeSimpleStatement(statement: String) {
        var s = statement.removeSuffix(";").trim()
        if (s.isEmpty()) return

        // Check for cout
        if (s.contains("cout")) {
            executeCout(s)
            return
        }

        // Check for cin
        if (s.contains("cin")) {
            executeCin(s)
            return
        }

        // Check for variable declaration and assignment
        // e.g. int age = 20; or double price = 15.5; or string name = "Ali";
        val types = listOf("int", "double", "float", "char", "bool", "string", "std::string")
        for (type in types) {
            if (s.startsWith("$type ")) {
                val decl = s.substring(type.length + 1).trim()
                if (decl.contains("=")) {
                    val parts = decl.split("=", limit = 2)
                    val varName = parts[0].trim()
                    val expr = parts[1].trim()
                    variables[varName] = evaluateExpression(expr)
                } else {
                    // Default values
                    val varName = decl.trim()
                    variables[varName] = when (type) {
                        "int" -> 0
                        "double", "float" -> 0.0
                        "bool" -> false
                        "char" -> ' '
                        else -> ""
                    }
                }
                return
            }
        }

        // Check for increment / decrement: x++ or ++x or x-- or --x
        if (s.endsWith("++")) {
            val varName = s.removeSuffix("++").trim()
            val curr = (variables[varName] as? Number)?.toLong() ?: 0L
            variables[varName] = curr + 1
            return
        }
        if (s.startsWith("++")) {
            val varName = s.removePrefix("++").trim()
            val curr = (variables[varName] as? Number)?.toLong() ?: 0L
            variables[varName] = curr + 1
            return
        }
        if (s.endsWith("--")) {
            val varName = s.removeSuffix("--").trim()
            val curr = (variables[varName] as? Number)?.toLong() ?: 0L
            variables[varName] = curr - 1
            return
        }

        // Check for reassignment: x = expr or x += expr
        if (s.contains("+=")) {
            val parts = s.split("+=", limit = 2)
            val varName = parts[0].trim()
            val current = (variables[varName] as? Number)?.toDouble() ?: 0.0
            val add = (evaluateExpression(parts[1].trim()) as? Number)?.toDouble() ?: 0.0
            variables[varName] = if (variables[varName] is Long || variables[varName] is Int) (current + add).toLong() else current + add
            return
        }

        if (s.contains("=")) {
            val parts = s.split("=", limit = 2)
            val varName = parts[0].trim()
            variables[varName] = evaluateExpression(parts[1].trim())
            return
        }
    }

    private fun executeCout(s: String) {
        // e.g. std::cout << "Hello" << " " << age << std::endl;
        val withoutCout = s.replace("std::cout", "").replace("cout", "").trim()
        val tokens = splitStream(withoutCout, "<<")

        for (token in tokens) {
            val t = token.trim()
            if (t == "endl" || t == "std::endl" || t == "'\\n'") {
                outputBuffer.append("\n")
            } else if (t.startsWith("\"") && t.endsWith("\"")) {
                // String literal
                outputBuffer.append(t.substring(1, t.length - 1).replace("\\n", "\n").replace("\\t", "\t"))
            } else if (t.startsWith("'") && t.endsWith("'") && t.length == 3) {
                outputBuffer.append(t[1])
            } else {
                val value = evaluateExpression(t)
                outputBuffer.append(value.toString())
            }
        }
    }

    private fun executeCin(s: String) {
        val withoutCin = s.replace("std::cin", "").replace("cin", "").trim()
        val tokens = splitStream(withoutCin, ">>")

        for (token in tokens) {
            val varName = token.trim()
            val inputVal = if (inputTokens.isNotEmpty()) inputTokens.removeAt(0) else "0"
            // Assign based on variable type if exists
            val existing = variables[varName]
            if (existing is Long || existing is Int) {
                variables[varName] = inputVal.toLongOrNull() ?: 0L
            } else if (existing is Double || existing is Float) {
                variables[varName] = inputVal.toDoubleOrNull() ?: 0.0
            } else {
                variables[varName] = inputVal
            }
        }
    }

    private fun splitStream(str: String, op: String): List<String> {
        val result = mutableListOf<String>()
        val sb = StringBuilder()
        var inQuote = false
        var i = 0
        while (i < str.length) {
            val ch = str[i]
            if (ch == '"') inQuote = !inQuote

            if (!inQuote && str.startsWith(op, i)) {
                val item = sb.toString().trim()
                if (item.isNotEmpty()) result.add(item)
                sb.clear()
                i += op.length
                continue
            }
            sb.append(ch)
            i++
        }
        val remaining = sb.toString().trim()
        if (remaining.isNotEmpty()) result.add(remaining)
        return result
    }

    private fun evaluateCondition(conditionStr: String): Boolean {
        val c = conditionStr.trim()
        if (c == "true" || c == "1") return true
        if (c == "false" || c == "0") return false

        // Check relational ops
        val ops = listOf("==", "!=", "<=", ">=", "<", ">")
        for (op in ops) {
            if (c.contains(op)) {
                val parts = c.split(op, limit = 2)
                val left = (evaluateExpression(parts[0].trim()) as? Number)?.toDouble()
                val right = (evaluateExpression(parts[1].trim()) as? Number)?.toDouble()

                if (left != null && right != null) {
                    return when (op) {
                        "==" -> left == right
                        "!=" -> left != right
                        "<=" -> left <= right
                        ">=" -> left >= right
                        "<" -> left < right
                        ">" -> left > right
                        else -> false
                    }
                }
            }
        }
        return false
    }

    private fun evaluateExpression(exprStr: String): Any {
        var expr = exprStr.trim()

        // Strip outer parentheses if any
        while (expr.startsWith("(") && expr.endsWith(")")) {
            expr = expr.substring(1, expr.length - 1).trim()
        }

        // String literal
        if (expr.startsWith("\"") && expr.endsWith("\"")) {
            return expr.substring(1, expr.length - 1)
        }

        // Char literal
        if (expr.startsWith("'") && expr.endsWith("'") && expr.length == 3) {
            return expr[1]
        }

        // Boolean
        if (expr == "true") return true
        if (expr == "false") return false

        // Variable lookup
        if (variables.containsKey(expr)) {
            return variables[expr]!!
        }

        // Simple arithmetic: numbers or variables combined with +, -, *, /
        return try {
            evaluateArithmetic(expr)
        } catch (_: Exception) {
            expr
        }
    }

    private fun evaluateArithmetic(expr: String): Any {
        // Strip outer parentheses
        var sanitized = expr.trim()
        while (sanitized.startsWith("(") && sanitized.endsWith(")")) {
            sanitized = sanitized.substring(1, sanitized.length - 1).trim()
        }

        variables.forEach { (name, value) ->
            if (value is Number) {
                sanitized = sanitized.replace(Regex("""\b$name\b"""), value.toString())
            }
        }

        // Check for simple binary operations
        val ops = listOf("+", "-", "*", "/", "%")
        for (op in ops) {
            if (sanitized.contains(op)) {
                val idx = sanitized.lastIndexOf(op)
                val leftStr = sanitized.substring(0, idx).trim()
                val rightStr = sanitized.substring(idx + 1).trim()

                val leftVal = leftStr.toDoubleOrNull()
                val rightVal = rightStr.toDoubleOrNull()

                if (leftVal != null && rightVal != null) {
                    val res = when (op) {
                        "+" -> leftVal + rightVal
                        "-" -> leftVal - rightVal
                        "*" -> leftVal * rightVal
                        "/" -> if (rightVal != 0.0) leftVal / rightVal else 0.0
                        "%" -> (leftVal.toLong() % rightVal.toLong()).toDouble()
                        else -> 0.0
                    }
                    return if (res % 1 == 0.0) res.toLong() else res
                }
            }
        }

        return sanitized.toLongOrNull() ?: sanitized.toDoubleOrNull() ?: sanitized
    }
}
