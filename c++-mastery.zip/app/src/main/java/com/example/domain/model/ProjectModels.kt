package com.example.domain.model

data class ProjectStep(
    val stepNumber: Int,
    val titleArabic: String,
    val instructionsArabic: String,
    val hintArabic: String
)

data class Project(
    val id: String,
    val projectNumber: Int,
    val titleArabic: String,
    val titleEnglish: String,
    val targetGoalArabic: String,
    val requiredConceptsArabic: List<String>,
    val steps: List<ProjectStep>,
    val starterCode: String,
    val referenceSolution: String,
    val xpReward: Int,
    val isCompleted: Boolean = false
)
