package com.example.domain.model

enum class ExerciseType {
    WRITE_CODE,       // كتابة كود والتحقق منه
    PREDICT_OUTPUT,   // توقع المخرجات
    FIND_THE_ERROR,   // اكتشاف الخطأ وتصحيحه
    MULTIPLE_CHOICE,  // اختيار من متعدد
    FILL_IN_THE_BLANK,// أكمل الفراغ في الكود
    ARRANGE_CODE,     // ترتيب أسطر الكود
    MODIFY_CODE       // تعديل الكود لتحقيق هدف معين
}

data class Exercise(
    val id: String,
    val lessonId: String,
    val type: ExerciseType,
    val titleArabic: String,
    val instructionsArabic: String,
    val starterCode: String = "",
    val solutionCode: String = "",
    val expectedOutput: String = "",
    val options: List<String> = emptyList(),
    val correctOptionIndex: Int = -1,
    val arrangeLines: List<String> = emptyList(), // unordered lines
    val correctLineOrder: List<Int> = emptyList(), // 0-based indices in correct order
    val blankPrefix: String = "",
    val blankSuffix: String = "",
    val acceptedBlankAnswers: List<String> = emptyList(),
    val educationalFeedback: String = "",
    val conceptTag: String = "", // e.g. "variables", "semicolon", "if_statements"
    val xpReward: Int = 25
)
