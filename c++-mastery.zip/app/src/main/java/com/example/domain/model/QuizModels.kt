package com.example.domain.model

data class QuizOption(
    val textArabic: String,
    val isCorrect: Boolean,
    val explanationArabic: String
)

data class QuizQuestion(
    val id: String,
    val questionArabic: String,
    val codeSnippet: String = "",
    val options: List<QuizOption>,
    val educationalReason: String,
    val conceptTag: String = ""
)

data class Quiz(
    val id: String,
    val lessonId: String? = null,
    val levelNumber: Int,
    val titleArabic: String,
    val descriptionArabic: String,
    val questions: List<QuizQuestion>,
    val passingScorePercent: Int = 70,
    val xpReward: Int = 50
)
