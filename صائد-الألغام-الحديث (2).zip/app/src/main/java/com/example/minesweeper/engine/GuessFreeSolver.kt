package com.example.minesweeper.engine

import com.example.minesweeper.model.Cell

object GuessFreeSolver {

    /**
     * Checks if the given board can be solved 100% purely with logical deduction
     * starting from (startR, startC) without requiring any blind guesses.
     */
    fun isSolvable(grid: List<List<Cell>>, rows: Int, cols: Int, startR: Int, startC: Int): Boolean {
        val isRevealed = Array(rows) { BooleanArray(cols) { false } }
        val isFlagged = Array(rows) { BooleanArray(cols) { false } }

        fun getNeighbors(r: Int, c: Int): List<Pair<Int, Int>> {
            val list = mutableListOf<Pair<Int, Int>>()
            for (dr in -1..1) {
                for (dc in -1..1) {
                    if (dr == 0 && dc == 0) continue
                    val nr = r + dr
                    val nc = c + dc
                    if (nr in 0 until rows && nc in 0 until cols) {
                        list.add(nr to nc)
                    }
                }
            }
            return list
        }

        fun revealFlood(r: Int, c: Int) {
            val queue = ArrayDeque<Pair<Int, Int>>()
            if (!isRevealed[r][c] && !isFlagged[r][c]) {
                isRevealed[r][c] = true
                if (grid[r][c].adjacentMines == 0) {
                    queue.add(r to c)
                }
            }
            while (queue.isNotEmpty()) {
                val (currR, currC) = queue.removeFirst()
                for ((nr, nc) in getNeighbors(currR, currC)) {
                    if (!isRevealed[nr][nc] && !isFlagged[nr][nc]) {
                        isRevealed[nr][nc] = true
                        if (grid[nr][nc].adjacentMines == 0) {
                            queue.add(nr to nc)
                        }
                    }
                }
            }
        }

        // Start with initial click
        revealFlood(startR, startC)

        var totalNonMines = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (!grid[r][c].isMine) totalNonMines++
            }
        }

        // Iterative logical deduction loop
        var progress = true
        while (progress) {
            progress = false

            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (!isRevealed[r][c]) continue
                    val cell = grid[r][c]
                    if (cell.adjacentMines == 0) continue

                    val neighbors = getNeighbors(r, c)
                    val unrevealedUnflagged = neighbors.filter { (nr, nc) -> !isRevealed[nr][nc] && !isFlagged[nr][nc] }
                    val flaggedCount = neighbors.count { (nr, nc) -> isFlagged[nr][nc] }

                    val neededMines = cell.adjacentMines - flaggedCount

                    // Rule 1: All remaining unrevealed neighbors are mines
                    if (neededMines > 0 && neededMines == unrevealedUnflagged.size) {
                        for ((mr, mc) in unrevealedUnflagged) {
                            isFlagged[mr][mc] = true
                            progress = true
                        }
                    }

                    // Rule 2: All remaining unrevealed neighbors are safe
                    if (neededMines == 0 && unrevealedUnflagged.isNotEmpty()) {
                        for ((sr, sc) in unrevealedUnflagged) {
                            revealFlood(sr, sc)
                            progress = true
                        }
                    }
                }
            }

            // Check if all non-mines are revealed
            var currentRevealed = 0
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (isRevealed[r][c] && !grid[r][c].isMine) currentRevealed++
                }
            }
            if (currentRevealed == totalNonMines) {
                return true
            }
        }

        var revealedCount = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (isRevealed[r][c] && !grid[r][c].isMine) revealedCount++
            }
        }
        return revealedCount == totalNonMines
    }
}
