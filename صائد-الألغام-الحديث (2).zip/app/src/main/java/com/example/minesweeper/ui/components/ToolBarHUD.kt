package com.example.minesweeper.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.GameStatus
import com.example.minesweeper.model.MinesweeperTheme

@Composable
fun TopGameHUD(
    remainingMines: Int,
    timerSeconds: Int,
    gameStatus: GameStatus,
    isInteracting: Boolean,
    theme: MinesweeperTheme,
    hintsCount: Int,
    wandsCount: Int,
    isZoomLocked: Boolean,
    onResetClick: () -> Unit,
    onHintClick: () -> Unit,
    onWandClick: () -> Unit,
    onToggleZoomLock: () -> Unit,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = if (theme.isRetroBeveled) Color(0xFFC0C0C0) else theme.boardBackground,
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            // Upper Row: Back button, Title or boost chips, and zoom lock
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.size(36.dp).testTag("hud_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = if (theme.isRetroBeveled) Color.Black else Color.White
                    )
                }

                // Boost buttons row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Smart Hint Boost
                    BoostIconButton(
                        icon = "💡",
                        count = hintsCount,
                        label = "تلميح",
                        onClick = onHintClick,
                        tag = "boost_hint"
                    )

                    // Magic Wand Boost
                    BoostIconButton(
                        icon = "🪄",
                        count = wandsCount,
                        label = "عصا",
                        onClick = onWandClick,
                        tag = "boost_wand"
                    )

                    // Zoom Lock toggle
                    IconButton(
                        onClick = onToggleZoomLock,
                        modifier = Modifier
                            .size(36.dp)
                            .background(
                                if (isZoomLocked) Color(0xFFFFB300) else Color(0x33000000),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .testTag("zoom_lock_toggle")
                    ) {
                        Icon(
                            imageVector = if (isZoomLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = if (isZoomLocked) "إلغاء قفل التكبير" else "قفل التكبير",
                            tint = if (isZoomLocked) Color.Black else (if (theme.isRetroBeveled) Color.Black else Color.White),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Main Retro HUD Row: [Mines LED] - [Face Button] - [Timer LED]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (theme.isRetroBeveled) Color(0xFFB0B0B0) else Color(0x22FFFFFF),
                        shape = RoundedCornerShape(6.dp)
                    )
                    .border(
                        2.dp,
                        if (theme.isRetroBeveled) Color(0xFF707070) else Color.Transparent,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Remaining Mines Digital Display
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "الألغام",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (theme.isRetroBeveled) Color.DarkGray else Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    DigitalLedDisplay(value = remainingMines)
                }

                // Smiley Reset Face Button
                RetroFaceButton(
                    status = gameStatus,
                    isInteractingWithBoard = isInteracting,
                    onClick = onResetClick
                )

                // Timer Digital Display
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "الوقت",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (theme.isRetroBeveled) Color.DarkGray else Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    DigitalLedDisplay(value = timerSeconds)
                }
            }
        }
    }
}

@Composable
private fun BoostIconButton(
    icon: String,
    count: Int,
    label: String,
    onClick: () -> Unit,
    tag: String
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x26000000))
            .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = icon, fontSize = 16.sp)
            Text(
                text = "×$count",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        }
    }
}

@Composable
fun BottomControlsHUD(
    isFlagMode: Boolean,
    onToggleFlagMode: () -> Unit,
    threeBV: Int,
    clicksCount: Int,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = Color(0xFF1E293B),
        tonalElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 3BV & Clicks info
            Column {
                Text(
                    text = "3BV: ${if (threeBV > 0) threeBV else "--"}",
                    color = Color(0xFF94A3B8),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "النقرات: $clicksCount",
                    color = Color(0xFF64748B),
                    fontSize = 12.sp
                )
            }

            // Big Flag / Reveal Switch Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .background(if (isFlagMode) Color(0xFFEF4444) else Color(0xFF3B82F6))
                    .clickable(onClick = onToggleFlagMode)
                    .padding(horizontal = 24.dp, vertical = 10.dp)
                    .testTag("mode_toggle_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (isFlagMode) "🚩" else "⛏️",
                        fontSize = 20.sp
                    )
                    Text(
                        text = if (isFlagMode) "وضع العلم (مفعّل)" else "وضع الكشف (مفعّل)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
