package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.AvailableThemes
import com.example.minesweeper.model.MinesweeperTheme
import com.example.minesweeper.ui.components.drawBeveledCell
import com.example.minesweeper.ui.components.drawFlag
import com.example.minesweeper.ui.components.drawGridBorder
import com.example.minesweeper.ui.components.drawMine
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

@Composable
fun ThemesScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    val currentSelectedTheme = uiState.currentTheme

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("themes_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = Color.White
                    )
                }

                Column {
                    Text(
                        text = "ثيمات ومظهر اللوحة 🎨",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "12 ثيم بألوان كلاسيكية مقاسة — جميعها مفتوحة مجاناً",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp
                    )
                }
            }

            // Hero Active Theme Preview Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF38BDF8))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الثيم الحالي: ${currentSelectedTheme.name}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF065F46), RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("نشط ومطبق ✔", color = Color(0xFFA7F3D0), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 4-cell live preview row of active theme
                    Row(
                        modifier = Modifier
                            .background(currentSelectedTheme.floor, RoundedCornerShape(8.dp))
                            .border(3.dp, currentSelectedTheme.cellDark, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeSampleCell(theme = currentSelectedTheme, type = SampleType.UNREVEALED, size = 42.dp)
                        ThemeSampleCell(theme = currentSelectedTheme, type = SampleType.FLAG, size = 42.dp)
                        ThemeSampleCell(theme = currentSelectedTheme, type = SampleType.NUMBER, size = 42.dp, number = 2)
                        ThemeSampleCell(theme = currentSelectedTheme, type = SampleType.MINE, size = 42.dp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 12 Themes List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(AvailableThemes.allThemes) { theme ->
                    val isSelected = theme.id == currentSelectedTheme.id

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("theme_card_${theme.index}")
                            .clickable { viewModel.selectTheme(theme) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF26354A) else Color(0xFF1E293B)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Left Column: Index & Name
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(
                                            if (isSelected) Color(0xFF38BDF8) else Color(0xFF334155),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${theme.index}",
                                        color = if (isSelected) Color(0xFF0F172A) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                Column {
                                    Text(
                                        text = theme.name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    if (isSelected) {
                                        Text(
                                            text = "مطبق حالياً",
                                            color = Color(0xFF38BDF8),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            // Right: 4 mini sample squares (unrevealed, flag, number, mine)
                            Row(
                                modifier = Modifier
                                    .background(theme.floor, RoundedCornerShape(6.dp))
                                    .border(1.5.dp, theme.cellDark, RoundedCornerShape(6.dp))
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ThemeSampleCell(theme = theme, type = SampleType.UNREVEALED, size = 28.dp)
                                ThemeSampleCell(theme = theme, type = SampleType.FLAG, size = 28.dp)
                                ThemeSampleCell(theme = theme, type = SampleType.NUMBER, size = 28.dp, number = 1)
                                ThemeSampleCell(theme = theme, type = SampleType.MINE, size = 28.dp)
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

enum class SampleType {
    UNREVEALED,
    FLAG,
    NUMBER,
    MINE
}

@Composable
private fun ThemeSampleCell(
    theme: MinesweeperTheme,
    type: SampleType,
    size: Dp,
    number: Int = 1
) {
    Box(
        modifier = Modifier
            .size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val bevel = (w * 0.12f).coerceAtLeast(1f)

            when (type) {
                SampleType.UNREVEALED -> {
                    drawBeveledCell(theme, w, h, bevel)
                }
                SampleType.FLAG -> {
                    drawBeveledCell(theme, w, h, bevel)
                    drawFlag(theme.flagColor, theme.flagStand, w, h)
                }
                SampleType.NUMBER -> {
                    drawRect(color = theme.pressedFace)
                    drawGridBorder(theme.pressedEdge, w, h)
                }
                SampleType.MINE -> {
                    drawRect(color = theme.floor)
                    drawGridBorder(theme.pressedEdge, w, h)
                    drawMine(theme.mineColor, w, h)
                }
            }
        }

        if (type == SampleType.NUMBER) {
            val digitColor = AvailableThemes.standardDigitColors.getOrElse(number - 1) { Color.Blue }
            Text(
                text = number.toString(),
                color = digitColor,
                fontSize = (size.value * 0.58f).sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
        }
    }
}
