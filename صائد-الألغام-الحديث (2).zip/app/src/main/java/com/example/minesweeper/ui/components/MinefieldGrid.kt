package com.example.minesweeper.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.AvailableThemes
import com.example.minesweeper.model.Cell
import com.example.minesweeper.model.ChordingTrigger
import com.example.minesweeper.model.MinesweeperTheme

@Composable
fun MinefieldGrid(
    grid: List<List<Cell>>,
    theme: MinesweeperTheme,
    isFlagMode: Boolean,
    chordingTrigger: ChordingTrigger,
    isZoomLocked: Boolean,
    isGameLost: Boolean = false,
    onCellClick: (Int, Int) -> Unit,
    onCellLongClick: (Int, Int) -> Unit,
    onCellDoubleTap: (Int, Int) -> Unit,
    onPressStateChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .background(theme.floor)
    ) {
        val density = LocalDensity.current
        val containerWidthPx = constraints.maxWidth.toFloat()
        val containerHeightPx = constraints.maxHeight.toFloat()

        val numRows = maxOf(1, grid.size)
        val numCols = maxOf(1, grid.firstOrNull()?.size ?: 1)

        val boardExtraSpaceDp = 24.dp
        val boardExtraSpacePx = with(density) { boardExtraSpaceDp.toPx() }

        val availWidthPx = maxOf(0f, containerWidthPx - boardExtraSpacePx)
        val availHeightPx = maxOf(0f, containerHeightPx - boardExtraSpacePx)

        // Fit cell size: min(available width / cols, available height / rows)
        val cellWidthPx = availWidthPx / numCols
        val cellHeightPx = availHeightPx / numRows
        val fitCellSizePx = minOf(cellWidthPx, cellHeightPx)

        val cellSizeDp: Dp = with(density) {
            fitCellSizePx.toDp().coerceIn(10.dp, 48.dp)
        }
        val actualCellSizePx = with(density) { cellSizeDp.toPx() }

        val baseBoardWidthPx = actualCellSizePx * numCols + boardExtraSpacePx
        val baseBoardHeightPx = actualCellSizePx * numRows + boardExtraSpacePx

        var scale by remember { mutableFloatStateOf(1f) }
        var offsetX by remember { mutableFloatStateOf(0f) }
        var offsetY by remember { mutableFloatStateOf(0f) }

        // Reset scale and pan whenever grid changes
        LaunchedEffect(grid) {
            scale = 1f
            offsetX = 0f
            offsetY = 0f
        }

        fun clampOffsets(s: Float, targetX: Float, targetY: Float): Pair<Float, Float> {
            val scaledW = baseBoardWidthPx * s
            val scaledH = baseBoardHeightPx * s

            val clampedX = if (scaledW <= containerWidthPx) {
                0f
            } else {
                val maxOx = (scaledW - containerWidthPx) / 2f
                targetX.coerceIn(-maxOx, maxOx)
            }

            val clampedY = if (scaledH <= containerHeightPx) {
                0f
            } else {
                val maxOy = (scaledH - containerHeightPx) / 2f
                targetY.coerceIn(-maxOy, maxOy)
            }

            return clampedX to clampedY
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(isZoomLocked, baseBoardWidthPx, baseBoardHeightPx, containerWidthPx, containerHeightPx) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = if (!isZoomLocked) {
                            (scale * zoom).coerceIn(1f, 3f)
                        } else {
                            scale
                        }
                        scale = newScale

                        val targetX = offsetX + pan.x
                        val targetY = offsetY + pan.y
                        val (cx, cy) = clampOffsets(newScale, targetX, targetY)
                        offsetX = cx
                        offsetY = cy
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
                    .background(theme.floor)
                    .border(
                        width = 4.dp,
                        color = theme.cellDark,
                        shape = RoundedCornerShape(2.dp)
                    )
                    .padding(4.dp)
            ) {
                Column {
                    grid.forEachIndexed { r, row ->
                        Row {
                            row.forEachIndexed { c, cell ->
                                CellItem(
                                    cell = cell,
                                    theme = theme,
                                    size = cellSizeDp,
                                    isFlagMode = isFlagMode,
                                    chordingTrigger = chordingTrigger,
                                    isGameLost = isGameLost,
                                    onClick = { onCellClick(r, c) },
                                    onLongClick = { onCellLongClick(r, c) },
                                    onDoubleTap = { onCellDoubleTap(r, c) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun CellItem(
    cell: Cell,
    theme: MinesweeperTheme,
    size: Dp,
    isFlagMode: Boolean,
    chordingTrigger: ChordingTrigger,
    isGameLost: Boolean = false,
    onClick: () -> Unit = {},
    onLongClick: () -> Unit = {},
    onDoubleTap: () -> Unit = {}
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "hint_anim")
    val hintAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hint_alpha"
    )

    Box(
        modifier = Modifier
            .size(size)
            .testTag("cell_${cell.row}_${cell.col}")
            .drawBehind {
                val w = this.size.width
                val h = this.size.height
                val bevel = (w * 0.12f).coerceAtLeast(1f)

                when {
                    // Exploded mine (hit by player)
                    cell.isRevealed && cell.isExplodedMine -> {
                        drawRect(color = Color(0xFFFF0000))
                        drawGridBorder(theme.pressedEdge, w, h)
                        drawMine(theme.mineColor, w, h)
                    }

                    // Revealed regular mine (revealed upon loss)
                    cell.isRevealed && cell.isMine -> {
                        drawRect(color = theme.floor)
                        drawGridBorder(theme.pressedEdge, w, h)
                        drawMine(theme.mineColor, w, h)
                    }

                    // Revealed with adjacent numbers
                    cell.isRevealed && cell.adjacentMines > 0 -> {
                        drawRect(color = theme.pressedFace)
                        drawGridBorder(theme.pressedEdge, w, h)
                    }

                    // Revealed empty cell (0 adjacent mines)
                    cell.isRevealed -> {
                        drawRect(color = theme.floor)
                        drawGridBorder(theme.pressedEdge, w, h)
                    }

                    // False flag: flagged on non-mine when game is lost
                    isGameLost && cell.isFlagged && !cell.isMine -> {
                        drawRect(color = theme.floor)
                        drawGridBorder(theme.pressedEdge, w, h)
                        drawFalseFlag(theme.mineColor, w, h)
                    }

                    // Flagged cell (over unrevealed beveled cell)
                    cell.isFlagged -> {
                        drawBeveledCell(theme, w, h, bevel)
                        drawFlag(theme.flagColor, theme.flagStand, w, h)
                    }

                    // Pressed state before reveal
                    isPressed -> {
                        drawRect(color = theme.pressedFace)
                        drawGridBorder(theme.pressedEdge, w, h)
                    }

                    // Normal unrevealed cell
                    else -> {
                        drawBeveledCell(theme, w, h, bevel)
                    }
                }
            }
            .then(
                if (cell.isHinted) {
                    Modifier.border(2.dp, Color(0xFFFFD700).copy(alpha = hintAlpha))
                } else {
                    Modifier
                }
            )
            .combinedClickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = {
                    if (cell.isRevealed) {
                        if (chordingTrigger == ChordingTrigger.SINGLE_TAP) {
                            onClick()
                        }
                    } else {
                        onClick()
                    }
                },
                onLongClick = {
                    if (cell.isRevealed) {
                        if (chordingTrigger == ChordingTrigger.LONG_PRESS) {
                            onLongClick()
                        }
                    } else {
                        onLongClick()
                    }
                },
                onDoubleClick = {
                    if (cell.isRevealed && chordingTrigger == ChordingTrigger.DOUBLE_TAP) {
                        onDoubleTap()
                    }
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        // Draw standard colored digit if cell is revealed with adjacent numbers
        if (cell.isRevealed && cell.adjacentMines > 0 && !cell.isMine) {
            val digit = cell.adjacentMines
            val digitColor = AvailableThemes.standardDigitColors.getOrElse(digit - 1) { Color.Black }
            val fontSize = maxOf(7f, size.value * 0.55f).sp

            Text(
                text = digit.toString(),
                color = digitColor,
                fontSize = fontSize,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                textAlign = TextAlign.Center
            )
        }
    }
}

/**
 * Draws the classic Windows 3D beveled button with 12% bevel thickness:
 * cellLight on top & left, cellFace in center, cellDark on bottom & right.
 */
fun DrawScope.drawBeveledCell(theme: MinesweeperTheme, w: Float, h: Float, bevel: Float) {
    // Top light trapezoid
    val topPath = Path().apply {
        moveTo(0f, 0f)
        lineTo(w, 0f)
        lineTo(w - bevel, bevel)
        lineTo(bevel, bevel)
        close()
    }
    drawPath(topPath, color = theme.cellLight)

    // Left light trapezoid
    val leftPath = Path().apply {
        moveTo(0f, 0f)
        lineTo(bevel, bevel)
        lineTo(bevel, h - bevel)
        lineTo(0f, h)
        close()
    }
    drawPath(leftPath, color = theme.cellLight)

    // Bottom dark trapezoid
    val bottomPath = Path().apply {
        moveTo(0f, h)
        lineTo(bevel, h - bevel)
        lineTo(w - bevel, h - bevel)
        lineTo(w, h)
        close()
    }
    drawPath(bottomPath, color = theme.cellDark)

    // Right dark trapezoid
    val rightPath = Path().apply {
        moveTo(w, 0f)
        lineTo(w, h)
        lineTo(w - bevel, h - bevel)
        lineTo(w - bevel, bevel)
        close()
    }
    drawPath(rightPath, color = theme.cellDark)

    // Center face
    drawRect(
        color = theme.cellFace,
        topLeft = Offset(bevel, bevel),
        size = Size(w - 2 * bevel, h - 2 * bevel)
    )
}

/**
 * Draws a 1px border around pressed/revealed cells.
 */
fun DrawScope.drawGridBorder(color: Color, w: Float, h: Float) {
    val stroke = 1f
    drawRect(color = color, style = Stroke(width = stroke))
}

/**
 * Draws a programmatic spiked naval mine with white glint highlight.
 */
fun DrawScope.drawMine(mineColor: Color, w: Float, h: Float) {
    val cx = w / 2f
    val cy = h / 2f
    val r = w * 0.28f
    val spikeLen = r * 1.55f
    val stroke = (r * 0.35f).coerceAtLeast(1.5f)

    // Spikes (horizontal, vertical, diagonals)
    drawLine(mineColor, Offset(cx - spikeLen, cy), Offset(cx + spikeLen, cy), strokeWidth = stroke)
    drawLine(mineColor, Offset(cx, cy - spikeLen), Offset(cx, cy + spikeLen), strokeWidth = stroke)
    val diag = spikeLen * 0.7071f
    drawLine(mineColor, Offset(cx - diag, cy - diag), Offset(cx + diag, cy + diag), strokeWidth = stroke)
    drawLine(mineColor, Offset(cx - diag, cy + diag), Offset(cx + diag, cy - diag), strokeWidth = stroke)

    // Center circular mine body
    drawCircle(mineColor, radius = r, center = Offset(cx, cy))

    // Small white glint highlight
    val glintRadius = (r * 0.25f).coerceAtLeast(1f)
    drawCircle(Color.White, radius = glintRadius, center = Offset(cx - r * 0.35f, cy - r * 0.35f))
}

/**
 * Draws a programmatic triangular flag on pole and stand.
 */
fun DrawScope.drawFlag(flagColor: Color, flagStand: Color, w: Float, h: Float) {
    val cx = w / 2f
    val cy = h / 2f
    val poleStroke = (w * 0.08f).coerceAtLeast(1.5f)
    val poleX = cx - w * 0.08f
    val topY = cy - h * 0.30f
    val baseY = cy + h * 0.32f

    // Base stand
    val baseHalf = w * 0.22f
    drawLine(
        color = flagStand,
        start = Offset(poleX - baseHalf, baseY),
        end = Offset(poleX + baseHalf, baseY),
        strokeWidth = poleStroke * 1.3f
    )

    // Pole
    drawLine(
        color = flagStand,
        start = Offset(poleX, topY),
        end = Offset(poleX, baseY),
        strokeWidth = poleStroke
    )

    // Triangle Flag
    val flagPath = Path().apply {
        moveTo(poleX, topY)
        lineTo(poleX + w * 0.36f, topY + (h * 0.30f) / 2f)
        lineTo(poleX, topY + h * 0.30f)
        close()
    }
    drawPath(flagPath, color = flagColor)
}

/**
 * Draws a mine with a bold red X over it for false flags upon defeat.
 */
fun DrawScope.drawFalseFlag(mineColor: Color, w: Float, h: Float) {
    drawMine(mineColor, w, h)
    val pad = w * 0.16f
    val xStroke = (w * 0.12f).coerceAtLeast(2f)
    drawLine(Color(0xFFFF0000), Offset(pad, pad), Offset(w - pad, h - pad), strokeWidth = xStroke)
    drawLine(Color(0xFFFF0000), Offset(w - pad, pad), Offset(pad, h - pad), strokeWidth = xStroke)
}
