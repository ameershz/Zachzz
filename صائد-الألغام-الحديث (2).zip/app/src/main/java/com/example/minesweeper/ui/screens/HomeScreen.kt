package com.example.minesweeper.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.model.BoardDifficulty
import com.example.minesweeper.model.GameMode
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

@Composable
fun HomeScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    var showDifficultyDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Game Logo & Title
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(Color(0xFF1F2937), CircleShape)
                    .border(2.dp, Color(0xFF38BDF8), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("💣", fontSize = 42.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "صائد الألغام",
                fontSize = 32.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 1.sp
            )

            Text(
                text = "كاسحة ألغام كلاسيكية احترافية بدون تخمين",
                fontSize = 13.sp,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Daily Streak & Reward Card
            DailyStreakCard(
                streak = uiState.dailyStreak.currentStreak,
                longest = uiState.dailyStreak.longestStreak,
                isClaimedToday = uiState.dailyStreak.isClaimedToday,
                onClaim = { viewModel.claimDailyReward() }
            )

            // Claim message toast banner
            AnimatedVisibility(visible = uiState.dailyClaimRewardMessage != null) {
                uiState.dailyClaimRewardMessage?.let { msg ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF065F46)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .clickable { viewModel.clearDailyMessage() }
                    ) {
                        Text(
                            text = "🎁 $msg",
                            color = Color(0xFFA7F3D0),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Primary Navigation Grid
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Play Button (Primary Large)
                MenuActionButton(
                    title = "العب الآن",
                    subtitle = "كلاسيك، مؤقت، وتحدي بدون تخمين",
                    icon = Icons.Default.PlayArrow,
                    containerColor = Color(0xFF3B82F6),
                    iconBg = Color(0xFF1D4ED8),
                    tag = "play_menu_button",
                    onClick = { showDifficultyDialog = true }
                )

                // Campaign Button
                MenuActionButton(
                    title = "الحملة (المراحل)",
                    subtitle = "15 مرحلة متدرجة بأهداف وتحديات متنوعة",
                    icon = Icons.Default.Map,
                    containerColor = Color(0xFF8B5CF6),
                    iconBg = Color(0xFF6D28D9),
                    tag = "campaign_menu_button",
                    onClick = { viewModel.navigateTo(ScreenState.CAMPAIGN) }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Tournaments UI
                    SubMenuButton(
                        title = "البطولات",
                        icon = Icons.Default.EmojiEvents,
                        color = Color(0xFFF59E0B),
                        modifier = Modifier.weight(1f),
                        tag = "tournaments_menu_button",
                        onClick = { viewModel.navigateTo(ScreenState.TOURNAMENTS) }
                    )

                    // Themes
                    SubMenuButton(
                        title = "الثيمات",
                        icon = Icons.Default.Palette,
                        color = Color(0xFFEC4899),
                        modifier = Modifier.weight(1f),
                        tag = "themes_menu_button",
                        onClick = { viewModel.navigateTo(ScreenState.THEMES) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Stats
                    SubMenuButton(
                        title = "الإحصائيات",
                        icon = Icons.Default.BarChart,
                        color = Color(0xFF10B981),
                        modifier = Modifier.weight(1f),
                        tag = "stats_menu_button",
                        onClick = { viewModel.navigateTo(ScreenState.STATS) }
                    )

                    // Settings
                    SubMenuButton(
                        title = "الإعدادات",
                        icon = Icons.Default.Settings,
                        color = Color(0xFF64748B),
                        modifier = Modifier.weight(1f),
                        tag = "settings_menu_button",
                        onClick = { viewModel.navigateTo(ScreenState.SETTINGS) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Difficulty / Game Launch Dialog
        if (showDifficultyDialog) {
            DifficultySelectionDialog(
                currentGuessFree = uiState.isGuessFree,
                onDismiss = { showDifficultyDialog = false },
                onStartGame = { diff, mode, guessFree, r, c, m ->
                    showDifficultyDialog = false
                    viewModel.startNewGame(
                        difficulty = diff,
                        mode = mode,
                        customRows = r,
                        customCols = c,
                        customMines = m,
                        guessFree = guessFree
                    )
                }
            )
        }

        // Onboarding Tutorial Dialog
        if (uiState.showTutorial) {
            TutorialDialog(onDismiss = { viewModel.completeTutorial() })
        }
    }
}

@Composable
private fun DailyStreakCard(
    streak: Int,
    longest: Int,
    isClaimedToday: Boolean,
    onClaim: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0xFF334155), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🔥", fontSize = 22.sp)
                }

                Column {
                    Text(
                        text = "سلسلة الأيام: $streak أيام متتالية",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "أطول سلسلة سابقة: $longest يوم",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                }
            }

            Button(
                onClick = onClaim,
                enabled = !isClaimedToday,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFF59E0B),
                    disabledContainerColor = Color(0xFF334155)
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.testTag("claim_daily_button")
            ) {
                Text(
                    text = if (isClaimedToday) "تم اليوم ✔" else "استلام 🎁",
                    color = if (isClaimedToday) Color(0xFF64748B) else Color(0xFF0F172A),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun MenuActionButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    containerColor: Color,
    iconBg: Color,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(iconBg, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp
                )
            }

            Text("⬅", color = Color.White, fontSize = 20.sp)
        }
    }
}

@Composable
private fun SubMenuButton(
    title: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    tag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .testTag(tag)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(color.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(22.dp)
                )
            }
            Text(
                text = title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DifficultySelectionDialog(
    currentGuessFree: Boolean,
    onDismiss: () -> Unit,
    onStartGame: (BoardDifficulty, GameMode, Boolean, Int, Int, Int) -> Unit
) {
    var selectedDifficulty by remember { mutableStateOf(BoardDifficulty.BEGINNER) }
    var selectedMode by remember { mutableStateOf(GameMode.CLASSIC) }
    var guessFree by remember { mutableStateOf(currentGuessFree) }

    var customR by remember { mutableIntStateOf(10) }
    var customC by remember { mutableIntStateOf(10) }
    var customM by remember { mutableIntStateOf(15) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF475569)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("difficulty_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "اختر الصعوبة والطور 🎮",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Mode toggle: Classic vs Timer
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedMode == GameMode.CLASSIC) Color(0xFF3B82F6) else Color.Transparent)
                            .clickable { selectedMode = GameMode.CLASSIC }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "حر كلاسيك",
                            color = if (selectedMode == GameMode.CLASSIC) Color.White else Color(0xFF94A3B8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedMode == GameMode.TIMER) Color(0xFFEF4444) else Color.Transparent)
                            .clickable { selectedMode = GameMode.TIMER }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "تحدي المؤقت ⏱️",
                            color = if (selectedMode == GameMode.TIMER) Color.White else Color(0xFF94A3B8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Difficulties List
                listOf(
                    BoardDifficulty.BEGINNER,
                    BoardDifficulty.INTERMEDIATE,
                    BoardDifficulty.EXPERT,
                    BoardDifficulty.CUSTOM
                ).forEach { diff ->
                    val isSelected = selectedDifficulty == diff
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { selectedDifficulty = diff },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF334155) else Color(0xFF0F172A)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) Color(0xFF38BDF8) else Color(0xFF1E293B)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = diff.titleAr,
                                    color = if (isSelected) Color(0xFF38BDF8) else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = diff.description,
                                    color = Color(0xFF94A3B8),
                                    fontSize = 12.sp
                                )
                            }
                            if (isSelected) {
                                Text("✔", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // If Custom selected, show dimension adjusters
                if (selectedDifficulty == BoardDifficulty.CUSTOM) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "الصفوف: $customR  |  الأعمدة: $customC  |  الألغام: $customM",
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            OutlinedButton(onClick = { if (customR > 6) customR-- }) { Text("- صف") }
                            OutlinedButton(onClick = { if (customR < 24) customR++ }) { Text("+ صف") }
                            OutlinedButton(onClick = { if (customM > 3) customM-- }) { Text("- لغم") }
                            OutlinedButton(onClick = { if (customM < (customR * customC) / 3) customM++ }) { Text("+ لغم") }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Guess-Free switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "خيار «بدون تخمين» 🧠",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "لوحات قابلة للحل 100% بالمنطق فقط",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = guessFree,
                        onCheckedChange = { guessFree = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF10B981)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إلغاء", color = Color(0xFFCBD5E1))
                    }

                    Button(
                        onClick = {
                            onStartGame(selectedDifficulty, selectedMode, guessFree, customR, customC, customM)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                        modifier = Modifier.weight(1f).testTag("start_game_confirm_button")
                    ) {
                        Text("ابدأ اللعب 🚀", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
