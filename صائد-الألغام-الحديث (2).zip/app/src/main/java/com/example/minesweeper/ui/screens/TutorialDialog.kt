package com.example.minesweeper.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.model.Cell
import com.example.minesweeper.ui.components.DigitalLedDisplay

@Composable
fun TutorialDialog(
    onDismiss: () -> Unit
) {
    var step by remember { mutableIntStateOf(1) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF38BDF8)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("tutorial_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header: Step Indicator & Skip button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "جولة تعليمية ($step من 4)",
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("tutorial_skip_button")
                    ) {
                        Text("تخطي ✕", color = Color(0xFF94A3B8), fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (step) {
                    1 -> TutorialStepOne()
                    2 -> TutorialStepTwo()
                    3 -> TutorialStepThreePractice()
                    4 -> TutorialStepFourBoosts()
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Navigation buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (step > 1) {
                        OutlinedButton(
                            onClick = { step-- },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("السابق", color = Color(0xFFCBD5E1))
                        }
                    }

                    Button(
                        onClick = {
                            if (step < 4) {
                                step++
                            } else {
                                onDismiss()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38BDF8)),
                        modifier = Modifier.weight(1f).testTag("tutorial_next_button")
                    ) {
                        Text(
                            text = if (step < 4) "التالي ⬅" else "ابدأ اللعب الآن 🚀",
                            color = Color(0xFF0F172A),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TutorialStepOne() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "شريط اللعبة العلوي ⏱️",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("الألغام المتبقية", color = Color(0xFF94A3B8), fontSize = 11.sp)
                DigitalLedDisplay(value = 10)
            }
            Text("🙂", fontSize = 28.sp)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("المؤقت", color = Color(0xFF94A3B8), fontSize = 11.sp)
                DigitalLedDisplay(value = 42)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "• عداد الألغام يحسب عدد الألغام المتبقية بناءً على الأعلام التي تضعها.\n• الوجه في المنتصف يتفاعل معك، وبالنقر عليه يمكنك إعادة بدء الجولة فوراً.\n• المؤقت يحسب ثواني اللعب لقياس سرعتك ومؤشر 3BV.",
            color = Color(0xFFCBD5E1),
            fontSize = 13.sp,
            lineHeight = 20.sp,
            textAlign = TextAlign.Start,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun TutorialStepTwo() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "وضع الكشف ووضع الأعلام 🚩",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFF3B82F6), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("⛏️", fontSize = 28.sp)
                    Text("وضع الكشف", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("نقر للكشف عن الخلية", color = Color(0xFFE2E8F0), fontSize = 11.sp)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(Color(0xFFEF4444), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🚩", fontSize = 28.sp)
                    Text("وضع العلم", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("نقر لتعليم الألغام", color = Color(0xFFE2E8F0), fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "• استخدم الزر السفلي للتبديل بين وضعي الكشف والأعلام.\n• يمكنك أيضاً الضغط مطولاً على أي مربع مغلق لتبديل علمه مباشرة دون تغيير الوضع!\n• أول نقرة في كل جولة آمنة دائماً 100%.",
            color = Color(0xFFCBD5E1),
            fontSize = 13.sp,
            lineHeight = 20.sp,
            textAlign = TextAlign.Start,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun TutorialStepThreePractice() {
    // Mini 3x3 interactive practice board with 1 known mine at (1, 1)
    var practiceGrid by remember {
        mutableStateOf(
            listOf(
                listOf(Cell(0, 0, isRevealed = true, adjacentMines = 1), Cell(0, 1, isRevealed = true, adjacentMines = 1), Cell(0, 2, isRevealed = true, adjacentMines = 1)),
                listOf(Cell(1, 0, isRevealed = true, adjacentMines = 1), Cell(1, 1, isMine = true, isFlagged = false), Cell(1, 2, isRevealed = true, adjacentMines = 1)),
                listOf(Cell(2, 0, isRevealed = true, adjacentMines = 1), Cell(2, 1, isRevealed = true, adjacentMines = 1), Cell(2, 2, isRevealed = true, adjacentMines = 1))
            )
        )
    }
    var feedback by remember { mutableStateOf("جرب وضع علم 🚩 على الخلية المركزية المغلقة!") }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "لوحة تدريبية تجريبية 🎯",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = feedback,
            color = Color(0xFF38BDF8),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(10.dp))

        // 3x3 Grid
        Column(
            modifier = Modifier
                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(8.dp))
                .padding(8.dp)
        ) {
            practiceGrid.forEachIndexed { r, row ->
                Row {
                    row.forEachIndexed { c, cell ->
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .padding(2.dp)
                                .background(
                                    when {
                                        cell.isFlagged -> Color(0xFFEF4444).copy(alpha = 0.3f)
                                        cell.isRevealed -> Color(0xFFCBD5E1)
                                        else -> Color(0xFF64748B)
                                    },
                                    RoundedCornerShape(4.dp)
                                )
                                .clickable {
                                    if (r == 1 && c == 1) {
                                        val newFlag = !cell.isFlagged
                                        val updatedRow = row.toMutableList()
                                        updatedRow[c] = cell.copy(isFlagged = newFlag)
                                        val newGrid = practiceGrid.toMutableList()
                                        newGrid[r] = updatedRow
                                        practiceGrid = newGrid
                                        feedback = if (newFlag) "أحسنت! وضعت العلم بنجاح 👏" else "تمت إزالة العلم"
                                    } else {
                                        feedback = "هذا الرقم محاط بعلم صحيح! يمكنك استخدام Chording."
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            when {
                                cell.isFlagged -> Text("🚩", fontSize = 20.sp)
                                cell.isRevealed && cell.adjacentMines > 0 -> Text(
                                    cell.adjacentMines.toString(),
                                    color = Color(0xFF0000FF),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                !cell.isRevealed -> Text("❓", fontSize = 16.sp, color = Color(0xFF94A3B8))
                            }
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "خاصية Chording: عند وضع الأعلام بعدد الرقم، اضغط مطولاً على الرقم لكشف باقي المربعات المحيطة الآمنة تلقائياً!",
            color = Color(0xFF94A3B8),
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun TutorialStepFourBoosts() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "المساعدات الذكية (Boosts) 🚀",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(modifier = Modifier.height(14.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("💡", fontSize = 32.sp)
                Spacer(modifier = Modifier.padding(6.dp))
                Column {
                    Text("التلميح الذكي", color = Color(0xFFFDE047), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("يكشف لك مربعاً آمناً مؤكداً ومضموناً دون أي مخاطرة.", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🪄", fontSize = 32.sp)
                Spacer(modifier = Modifier.padding(6.dp))
                Column {
                    Text("العصا السحرية", color = Color(0xFFE879F9), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("تكشف وتفتح لك منطقة كاملة آمنة من اللوحة دفعة واحدة!", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "💡 نصيحة: يمكنك الحصول على المزيد من التلميحات والعصي السحرية يومياً عبر المكافأة اليومية وسلسلة الأيام (Streak) ومن مراحل الحملة!",
            color = Color(0xFF38BDF8),
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}
