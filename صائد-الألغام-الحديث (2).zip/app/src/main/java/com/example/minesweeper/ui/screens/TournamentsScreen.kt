package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

data class TournamentItem(
    val id: String,
    val titleAr: String,
    val subtitleAr: String,
    val timeRemaining: String,
    val participants: Int,
    val prizePool: String,
    val difficultyAr: String,
    val topPlayers: List<Pair<String, String>>
)

@Composable
fun TournamentsScreen(
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    var selectedTournament by remember { mutableStateOf<TournamentItem?>(null) }
    var showJoinSuccessDialog by remember { mutableStateOf(false) }

    val tournaments = remember {
        listOf(
            TournamentItem(
                id = "t1",
                titleAr = "كأس المبتدئين الأسبوعي 🏆",
                subtitleAr = "تنافس على أسرع حل للوحة 9×9 وحقق أعلى 3BV/s",
                timeRemaining = "متبقي 3 أيام",
                participants = 1420,
                prizePool = "50 تلميح + 20 عصا سحرية",
                difficultyAr = "مبتدئ (9×9)",
                topPlayers = listOf(
                    "صقر الصحراء" to "00:08",
                    "نجم الألغام" to "00:11",
                    "كاسح الميدان" to "00:14",
                    "الفارس الأزرق" to "00:16"
                )
            ),
            TournamentItem(
                id = "t2",
                titleAr = "بطولة الخبراء الكبرى 👑",
                subtitleAr = "تحدي اللوحة العملاقة 30×16 مع 99 لغم لمحترفي المنطق",
                timeRemaining = "متبقي 5 أيام",
                participants = 860,
                prizePool = "وسام الأسطورة الذهبي + 100 تلميح",
                difficultyAr = "خبير (30×16)",
                topPlayers = listOf(
                    "البروفيسور" to "01:24",
                    "العاصفة الرقمية" to "01:42",
                    "صياد المحيط" to "01:58",
                    "الشبح الأسود" to "02:15"
                )
            ),
            TournamentItem(
                id = "t3",
                titleAr = "تحدي الـ 3BV الخاطف ⚡",
                subtitleAr = "جولات سريعة تقيس معدل النقرات الفعالة والدقة المطلقة",
                timeRemaining = "متبقي 18 ساعة",
                participants = 2100,
                prizePool = "شحنات طاقة لا نهائية + حزمة ثيمات",
                difficultyAr = "متوسط (16×16)",
                topPlayers = listOf(
                    "الرعد الخاطف" to "3.42 3BV/s",
                    "الموج الأزرق" to "3.10 3BV/s",
                    "الصقر العربي" to "2.85 3BV/s",
                    "محارب الألغاز" to "2.60 3BV/s"
                )
            )
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("tournaments_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = Color.White
                    )
                }

                Column {
                    Text(
                        text = "البطولات والمنافسات 🏆",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "تنافس على الصدارة وسجل أرقامك القياسية",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp
                    )
                }
            }

            // Info Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E3A8A).copy(alpha = 0.5f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3B82F6))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("ℹ️", fontSize = 18.sp)
                    Text(
                        text = "في هذه المرحلة، يمكنك تصفح البطولات والمشاركة محلياً. ستتوفر المزامنة السحابية المباشرة مع سيرفر البطولات في التحديث القادم!",
                        color = Color(0xFFBFDBFE),
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tournaments List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tournaments) { tourney ->
                    TournamentCard(
                        tournament = tourney,
                        onDetailsClick = { selectedTournament = tourney }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }

        // Details Modal Dialog
        selectedTournament?.let { t ->
            TournamentDetailsDialog(
                tournament = t,
                onDismiss = { selectedTournament = null },
                onJoin = {
                    selectedTournament = null
                    showJoinSuccessDialog = true
                }
            )
        }

        if (showJoinSuccessDialog) {
            Dialog(onDismissRequest = { showJoinSuccessDialog = false }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🎉", fontSize = 48.sp)
                        Text(
                            text = "تم الانضمام للبطولة بنجاح!",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "سجل أفضل وقت لديك في هذا المستوى وسيحسب تلقائياً في رصيدك التنافسي.",
                            color = Color(0xFF94A3B8),
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showJoinSuccessDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                        ) {
                            Text("ممتاز!", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TournamentCard(
    tournament: TournamentItem,
    onDetailsClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tournament.titleAr,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Box(
                    modifier = Modifier
                        .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = tournament.timeRemaining,
                        color = Color(0xFFF59E0B),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = tournament.subtitleAr,
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "👥 ${tournament.participants} مشترك",
                    color = Color(0xFF64748B),
                    fontSize = 12.sp
                )
                Text(
                    text = "🎁 الجائزة: ${tournament.prizePool}",
                    color = Color(0xFFA78BFA),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Button(
                onClick = onDetailsClick,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("تفاصيل البطولة والمتصدرين 🏆", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun TournamentDetailsDialog(
    tournament: TournamentItem,
    onDismiss: () -> Unit,
    onJoin: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF38BDF8)),
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = tournament.titleAr,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = tournament.subtitleAr,
                    color = Color(0xFF94A3B8),
                    fontSize = 12.sp
                )

                Text(
                    text = "لوحة المتصدرين الحالية 🥇",
                    color = Color(0xFF38BDF8),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    tournament.topPlayers.forEachIndexed { idx, player ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${idx + 1}. ${player.first}",
                                color = if (idx == 0) Color(0xFFFBBF24) else Color.White,
                                fontSize = 13.sp,
                                fontWeight = if (idx == 0) FontWeight.Bold else FontWeight.Normal
                            )
                            Text(
                                text = player.second,
                                color = Color(0xFF38BDF8),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("إغلاق", color = Color(0xFF94A3B8))
                    }
                    Button(
                        onClick = onJoin,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("انضمام للبطولة", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
