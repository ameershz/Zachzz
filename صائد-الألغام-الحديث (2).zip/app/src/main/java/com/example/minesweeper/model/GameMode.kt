package com.example.minesweeper.model

enum class GameMode(val titleAr: String, val description: String) {
    CLASSIC("كلاسيك", "اللعب الحر التقليدي بلا قيود"),
    TIMER("المؤقت", "تحدي إكمال اللوحة ضد الوقت"),
    CAMPAIGN("الحملة", "مراحل متدرجة الصعوبة بأهداف خاصة")
}

enum class GameStatus {
    NOT_STARTED,
    IN_PROGRESS,
    WON,
    LOST
}
