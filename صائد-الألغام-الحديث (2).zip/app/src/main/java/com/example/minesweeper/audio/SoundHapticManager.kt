package com.example.minesweeper.audio

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

class SoundHapticManager(private val context: Context) {

    private var toneGenerator: ToneGenerator? = null
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    var soundEnabled: Boolean = true
    var hapticEnabled: Boolean = true

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (e: Exception) {
            Log.e("SoundHapticManager", "ToneGenerator init failed", e)
        }
    }

    fun playRevealSound() {
        if (soundEnabled) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 35)
            } catch (e: Exception) {
                // Ignore audio failure
            }
        }
        performHaptic(20)
    }

    fun playFlagSound() {
        if (soundEnabled) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 50)
            } catch (e: Exception) {
                // Ignore audio failure
            }
        }
        performHaptic(35)
    }

    fun playChordSound() {
        if (soundEnabled) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 60)
            } catch (e: Exception) {
                // Ignore audio failure
            }
        }
        performHaptic(40)
    }

    fun playWinSound() {
        if (soundEnabled) {
            try {
                Thread {
                    try {
                        toneGenerator?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 100)
                        Thread.sleep(120)
                        toneGenerator?.startTone(ToneGenerator.TONE_CDMA_MED_L, 100)
                        Thread.sleep(120)
                        toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 250)
                    } catch (ignored: Exception) {}
                }.start()
            } catch (e: Exception) {
                // Ignore
            }
        }
        performHaptic(100)
    }

    fun playExplosionSound() {
        if (soundEnabled) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, 300)
            } catch (e: Exception) {
                // Ignore audio failure
            }
        }
        performHaptic(150)
    }

    fun playBoostSound() {
        if (soundEnabled) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 80)
            } catch (e: Exception) {
                // Ignore audio failure
            }
        }
        performHaptic(45)
    }

    private fun performHaptic(durationMs: Long) {
        if (!hapticEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(durationMs)
            }
        } catch (e: Exception) {
            // Ignore haptic failure
        }
    }

    fun release() {
        toneGenerator?.release()
        toneGenerator = null
    }
}
