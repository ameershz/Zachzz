package com.example.minesweeper.model

enum class BoardDifficulty(
    val titleAr: String,
    val rows: Int,
    val cols: Int,
    val defaultMines: Int,
    val description: String
) {
    BEGINNER("مبتدئ", 9, 9, 10, "لوحة 9×9 مع 10 ألغام"),
    INTERMEDIATE("متوسط", 16, 16, 40, "لوحة 16×16 مع 40 لغم"),
    EXPERT("خبير", 16, 30, 99, "لوحة 30×16 مع 99 لغم"),
    CUSTOM("مخصص", 10, 10, 15, "أبعاد وألغام يحددها اللاعب");

    fun getMinesCount(customMines: Int = defaultMines): Int {
        return if (this == CUSTOM) customMines else defaultMines
    }
}
