package com.example.minesweeper.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DigitalLedDisplay(
    value: Int,
    digits: Int = 3,
    modifier: Modifier = Modifier
) {
    val clamped = when {
        value > 999 -> 999
        value < -99 -> -99
        else -> value
    }
    val formatted = if (clamped < 0) {
        "-" + kotlin.math.abs(clamped).toString().padStart(digits - 1, '0')
    } else {
        clamped.toString().padStart(digits, '0')
    }

    Box(
        modifier = modifier
            .background(Color(0xFF101010), shape = RoundedCornerShape(4.dp))
            .border(2.dp, Color(0xFF404040), shape = RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .widthIn(min = 60.dp),
        contentAlignment = Alignment.Center
    ) {
        // Dim background digits "888" for retro LCD effect
        Text(
            text = "8".repeat(digits),
            color = Color(0x22FF0000),
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center
        )
        // Active bright red LED digits
        Text(
            text = formatted,
            color = Color(0xFFFF1E1E),
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center
        )
    }
}
