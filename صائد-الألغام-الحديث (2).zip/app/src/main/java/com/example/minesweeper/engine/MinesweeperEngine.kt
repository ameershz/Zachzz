package com.example.minesweeper.engine

import com.example.minesweeper.model.Cell
import com.example.minesweeper.model.GameStatus
import kotlin.random.Random

class MinesweeperEngine(
    val rows: Int,
    val cols: Int,
    val totalMines: Int,
    val isGuessFreeRequested: Boolean = false
) {
    var grid: List<MutableList<Cell>> = List(rows) { r ->
        MutableList(cols) { c -> Cell(row = r, col = c) }
    }
        private set

    var status: GameStatus = GameStatus.NOT_STARTED
        private set

    var isFirstClick: Boolean = true
        private set

    var threeBV: Int = 0
        private set

    var clicksCount: Int = 0
        private set

    var effectiveClicksCount: Int = 0
        private set

    val totalCells: Int = rows * cols
    val safeCellsCount: Int = totalCells - totalMines

    val revealedCount: Int
        get() = grid.sumOf { row -> row.count { it.isRevealed && !it.isMine } }

    val flaggedCount: Int
        get() = grid.sumOf { row -> row.count { it.isFlagged } }

    val remainingMines: Int
        get() = totalMines - flaggedCount

    fun getNeighbors(r: Int, c: Int): List<Pair<Int, Int>> {
        val list = mutableListOf<Pair<Int, Int>>()
        for (dr in -1..1) {
            for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                val nr = r + dr
                val nc = c + dc
                if (nr in 0 until rows && nc in 0 until cols) {
                    list.add(nr to nc)
                }
            }
        }
        return list
    }

    private fun generateBoard(firstR: Int, firstC: Int) {
        val maxAttempts = if (isGuessFreeRequested) 30 else 1
        var chosenGrid: List<MutableList<Cell>>? = null

        for (attempt in 0 until maxAttempts) {
            val candidateGrid = List(rows) { r ->
                MutableList(cols) { c -> Cell(row = r, col = c) }
            }

            // Exclude first click and its immediate 8 neighbors for an opening if possible
            val forbidden = mutableSetOf<Pair<Int, Int>>()
            forbidden.add(firstR to firstC)
            if (totalCells - 9 >= totalMines) {
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        val nr = firstR + dr
                        val nc = firstC + dc
                        if (nr in 0 until rows && nc in 0 until cols) {
                            forbidden.add(nr to nc)
                        }
                    }
                }
            }

            val allCoords = mutableListOf<Pair<Int, Int>>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if ((r to c) !in forbidden) {
                        allCoords.add(r to c)
                    }
                }
            }
            allCoords.shuffle(Random)

            val minePositions = allCoords.take(totalMines).toSet()

            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val isMine = (r to c) in minePositions
                    candidateGrid[r][c] = candidateGrid[r][c].copy(isMine = isMine)
                }
            }

            // Calculate adjacent mines
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (!candidateGrid[r][c].isMine) {
                        val count = getNeighbors(r, c).count { (nr, nc) -> candidateGrid[nr][nc].isMine }
                        candidateGrid[r][c] = candidateGrid[r][c].copy(adjacentMines = count)
                    }
                }
            }

            if (!isGuessFreeRequested || GuessFreeSolver.isSolvable(candidateGrid, rows, cols, firstR, firstC)) {
                chosenGrid = candidateGrid
                break
            } else if (chosenGrid == null) {
                chosenGrid = candidateGrid // Fallback to best effort
            }
        }

        grid = chosenGrid ?: grid
        threeBV = ThreeBVCalculator.calculate(grid, rows, cols)
    }

    fun revealCell(r: Int, c: Int): RevealResult {
        if (status == GameStatus.WON || status == GameStatus.LOST) return RevealResult.NoOp
        val cell = grid[r][c]
        if (cell.isRevealed || cell.isFlagged) return RevealResult.NoOp

        clicksCount++

        if (isFirstClick) {
            generateBoard(r, c)
            isFirstClick = false
            status = GameStatus.IN_PROGRESS
        }

        val target = grid[r][c]
        if (target.isMine) {
            // Hit a mine
            grid[r][c] = target.copy(isRevealed = true, isExplodedMine = true)
            // Reveal all mines
            for (row in 0 until rows) {
                for (col in 0 until cols) {
                    val curr = grid[row][col]
                    if (curr.isMine) {
                        grid[row][col] = curr.copy(isRevealed = true)
                    }
                }
            }
            status = GameStatus.LOST
            return RevealResult.HitMine(r, c)
        }

        effectiveClicksCount++
        revealFloodFill(r, c)

        if (checkWin()) {
            status = GameStatus.WON
            // Flag all remaining mines automatically on win
            for (row in 0 until rows) {
                for (col in 0 until cols) {
                    val curr = grid[row][col]
                    if (curr.isMine && !curr.isFlagged) {
                        grid[row][col] = curr.copy(isFlagged = true)
                    }
                }
            }
            return RevealResult.Win
        }

        return RevealResult.Success
    }

    private fun revealFloodFill(startR: Int, startC: Int) {
        val queue = ArrayDeque<Pair<Int, Int>>()
        if (!grid[startR][startC].isRevealed && !grid[startR][startC].isFlagged) {
            grid[startR][startC] = grid[startR][startC].copy(isRevealed = true, isHinted = false)
            if (grid[startR][startC].adjacentMines == 0) {
                queue.add(startR to startC)
            }
        }

        while (queue.isNotEmpty()) {
            val (currR, currC) = queue.removeFirst()
            for ((nr, nc) in getNeighbors(currR, currC)) {
                val neighbor = grid[nr][nc]
                if (!neighbor.isRevealed && !neighbor.isFlagged && !neighbor.isMine) {
                    grid[nr][nc] = neighbor.copy(isRevealed = true, isHinted = false)
                    if (neighbor.adjacentMines == 0) {
                        queue.add(nr to nc)
                    }
                }
            }
        }
    }

    fun toggleFlag(r: Int, c: Int): Boolean {
        if (status == GameStatus.WON || status == GameStatus.LOST) return false
        val cell = grid[r][c]
        if (cell.isRevealed) return false

        clicksCount++
        val newFlag = !cell.isFlagged
        grid[r][c] = cell.copy(isFlagged = newFlag)
        return newFlag
    }

    fun chordCell(r: Int, c: Int): RevealResult {
        if (status != GameStatus.IN_PROGRESS) return RevealResult.NoOp
        val cell = grid[r][c]
        if (!cell.isRevealed || cell.adjacentMines == 0) return RevealResult.NoOp

        val neighbors = getNeighbors(r, c)
        val flaggedCount = neighbors.count { (nr, nc) -> grid[nr][nc].isFlagged }

        if (flaggedCount == cell.adjacentMines) {
            clicksCount++
            effectiveClicksCount++
            var hitMine = false
            var mineCoords: Pair<Int, Int>? = null

            for ((nr, nc) in neighbors) {
                val neighbor = grid[nr][nc]
                if (!neighbor.isRevealed && !neighbor.isFlagged) {
                    if (neighbor.isMine) {
                        hitMine = true
                        mineCoords = nr to nc
                        grid[nr][nc] = neighbor.copy(isRevealed = true, isExplodedMine = true)
                    } else {
                        revealFloodFill(nr, nc)
                    }
                }
            }

            if (hitMine) {
                // Reveal all mines
                for (row in 0 until rows) {
                    for (col in 0 until cols) {
                        val curr = grid[row][col]
                        if (curr.isMine) {
                            grid[row][col] = curr.copy(isRevealed = true)
                        }
                    }
                }
                status = GameStatus.LOST
                return RevealResult.HitMine(mineCoords?.first ?: r, mineCoords?.second ?: c)
            }

            if (checkWin()) {
                status = GameStatus.WON
                for (row in 0 until rows) {
                    for (col in 0 until cols) {
                        val curr = grid[row][col]
                        if (curr.isMine && !curr.isFlagged) {
                            grid[row][col] = curr.copy(isFlagged = true)
                        }
                    }
                }
                return RevealResult.Win
            }
            return RevealResult.Success
        }

        return RevealResult.NoOp
    }

    fun useSmartHint(): Pair<Int, Int>? {
        if (status != GameStatus.IN_PROGRESS && !isFirstClick) return null

        // If board hasn't started, first click can be anywhere safe
        if (isFirstClick) {
            return Pair(rows / 2, cols / 2)
        }

        // Find an unrevealed, non-mine, unflagged cell bordering a revealed number if possible
        var candidate: Pair<Int, Int>? = null

        // Try to find a logically safe cell first
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (cell.isRevealed && cell.adjacentMines > 0) {
                    val neighbors = getNeighbors(r, c)
                    val flagged = neighbors.count { (nr, nc) -> grid[nr][nc].isFlagged }
                    if (flagged == cell.adjacentMines) {
                        val safe = neighbors.firstOrNull { (nr, nc) -> !grid[nr][nc].isRevealed && !grid[nr][nc].isFlagged }
                        if (safe != null) {
                            candidate = safe
                            break
                        }
                    }
                }
            }
            if (candidate != null) break
        }

        // Otherwise pick any unrevealed non-mine cell
        if (candidate == null) {
            val safeCells = mutableListOf<Pair<Int, Int>>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val cell = grid[r][c]
                    if (!cell.isMine && !cell.isRevealed && !cell.isFlagged) {
                        safeCells.add(r to c)
                    }
                }
            }
            if (safeCells.isNotEmpty()) {
                candidate = safeCells.random()
            }
        }

        candidate?.let { (cr, cc) ->
            grid[cr][cc] = grid[cr][cc].copy(isHinted = true)
        }
        return candidate
    }

    fun useMagicWand(): List<Pair<Int, Int>> {
        if (status != GameStatus.IN_PROGRESS && !isFirstClick) return emptyList()

        if (isFirstClick) {
            revealCell(rows / 2, cols / 2)
            return listOf(rows / 2 to cols / 2)
        }

        // Find a safe unrevealed area (cluster of up to 4-9 cells)
        val safeCells = mutableListOf<Pair<Int, Int>>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (!cell.isMine && !cell.isRevealed && !cell.isFlagged) {
                    safeCells.add(r to c)
                }
            }
        }

        if (safeCells.isEmpty()) return emptyList()

        // Pick one center safe cell and reveal all safe neighbors
        val center = safeCells.random()
        val revealedList = mutableListOf<Pair<Int, Int>>()

        revealFloodFill(center.first, center.second)
        revealedList.add(center)

        if (checkWin()) {
            status = GameStatus.WON
        }
        return revealedList
    }

    fun revive(explodedR: Int, explodedC: Int): Boolean {
        if (status != GameStatus.LOST) return false
        // Re-hide mines that were uncovered except the exploded one which gets flagged
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (cell.isMine) {
                    if (r == explodedR && c == explodedC) {
                        grid[r][c] = cell.copy(isRevealed = false, isExplodedMine = false, isFlagged = true)
                    } else if (cell.isRevealed && !cell.isFlagged) {
                        grid[r][c] = cell.copy(isRevealed = false)
                    }
                }
            }
        }
        status = GameStatus.IN_PROGRESS
        return true
    }

    private fun checkWin(): Boolean {
        return revealedCount >= safeCellsCount
    }

    sealed class RevealResult {
        object NoOp : RevealResult()
        object Success : RevealResult()
        object Win : RevealResult()
        data class HitMine(val r: Int, val c: Int) : RevealResult()
    }
}
