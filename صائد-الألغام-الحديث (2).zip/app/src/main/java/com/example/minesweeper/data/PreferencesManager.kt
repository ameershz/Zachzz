package com.example.minesweeper.data

import android.content.Context
import android.content.SharedPreferences
import com.example.minesweeper.model.BoardDifficulty
import com.example.minesweeper.model.CampaignProgress
import com.example.minesweeper.model.ChordingTrigger
import com.example.minesweeper.model.DailyStreakState
import com.example.minesweeper.model.DifficultyStats
import com.example.minesweeper.model.MatchRecord
import com.example.minesweeper.model.SettingsState
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("minesweeper_prefs", Context.MODE_PRIVATE)

    // Settings
    fun loadSettings(): SettingsState {
        val chordingName = prefs.getString("chording_trigger", ChordingTrigger.LONG_PRESS.name) ?: ChordingTrigger.LONG_PRESS.name
        val chordingTrigger = try {
            ChordingTrigger.valueOf(chordingName)
        } catch (e: Exception) {
            ChordingTrigger.LONG_PRESS
        }

        return SettingsState(
            chordingTrigger = chordingTrigger,
            volumeKeyToggleEnabled = prefs.getBoolean("volume_key_toggle", true),
            hapticFeedbackEnabled = prefs.getBoolean("haptic_feedback", true),
            soundEffectsEnabled = prefs.getBoolean("sound_effects", true),
            lockZoomByDefault = prefs.getBoolean("lock_zoom", false),
            guessFreeOptionEnabled = prefs.getBoolean("guess_free_mode", false),
            selectedThemeId = prefs.getString("selected_theme", "classic_retro") ?: "classic_retro"
        )
    }

    fun saveSettings(settings: SettingsState) {
        prefs.edit()
            .putString("chording_trigger", settings.chordingTrigger.name)
            .putBoolean("volume_key_toggle", settings.volumeKeyToggleEnabled)
            .putBoolean("haptic_feedback", settings.hapticFeedbackEnabled)
            .putBoolean("sound_effects", settings.soundEffectsEnabled)
            .putBoolean("lock_zoom", settings.lockZoomByDefault)
            .putBoolean("guess_free_mode", settings.guessFreeOptionEnabled)
            .putString("selected_theme", settings.selectedThemeId)
            .apply()
    }

    // Stats
    fun loadStats(difficulty: BoardDifficulty): DifficultyStats {
        val prefix = "stats_${difficulty.name}_"
        return DifficultyStats(
            gamesPlayed = prefs.getInt("${prefix}played", 0),
            gamesWon = prefs.getInt("${prefix}won", 0),
            bestTimeSeconds = prefs.getInt("${prefix}best_time", 0),
            totalTimeSeconds = prefs.getLong("${prefix}total_time", 0L),
            best3BV = prefs.getInt("${prefix}best_3bv", 0),
            best3BVs = prefs.getFloat("${prefix}best_3bvs", 0f),
            bestEfficiencyPct = prefs.getFloat("${prefix}best_eff", 0f)
        )
    }

    fun recordGameResult(
        difficulty: BoardDifficulty,
        won: Boolean,
        timeSeconds: Int,
        threeBV: Int,
        threeBVs: Float,
        clicks: Int,
        efficiencyPct: Float
    ) {
        val current = loadStats(difficulty)
        val prefix = "stats_${difficulty.name}_"
        val newPlayed = current.gamesPlayed + 1
        val newWon = if (won) current.gamesWon + 1 else current.gamesWon
        val newTotalTime = if (won) current.totalTimeSeconds + timeSeconds else current.totalTimeSeconds
        val newBestTime = if (won) {
            if (current.bestTimeSeconds == 0 || timeSeconds < current.bestTimeSeconds) timeSeconds else current.bestTimeSeconds
        } else current.bestTimeSeconds

        val newBest3BV = maxOf(current.best3BV, threeBV)
        val newBest3BVs = if (won) maxOf(current.best3BVs, threeBVs) else current.best3BVs
        val newBestEff = if (won) maxOf(current.bestEfficiencyPct, efficiencyPct) else current.bestEfficiencyPct

        prefs.edit()
            .putInt("${prefix}played", newPlayed)
            .putInt("${prefix}won", newWon)
            .putInt("${prefix}best_time", newBestTime)
            .putLong("${prefix}total_time", newTotalTime)
            .putInt("${prefix}best_3bv", newBest3BV)
            .putFloat("${prefix}best_3bvs", newBest3BVs)
            .putFloat("${prefix}best_eff", newBestEff)
            .apply()

        // Append to match history
        addMatchRecord(
            MatchRecord(
                timestamp = System.currentTimeMillis(),
                difficulty = difficulty,
                won = won,
                timeSeconds = timeSeconds,
                threeBV = threeBV,
                threeBVs = threeBVs,
                clicks = clicks,
                efficiencyPct = efficiencyPct
            )
        )
    }

    private fun addMatchRecord(record: MatchRecord) {
        val records = loadMatchHistory().toMutableList()
        records.add(0, record)
        if (records.size > 20) {
            records.removeAt(records.size - 1)
        }
        val array = JSONArray()
        for (r in records) {
            val obj = JSONObject().apply {
                put("ts", r.timestamp)
                put("diff", r.difficulty.name)
                put("won", r.won)
                put("time", r.timeSeconds)
                put("3bv", r.threeBV)
                put("3bvs", r.threeBVs.toDouble())
                put("clicks", r.clicks)
                put("eff", r.efficiencyPct.toDouble())
            }
            array.put(obj)
        }
        prefs.edit().putString("match_history", array.toString()).apply()
    }

    fun loadMatchHistory(): List<MatchRecord> {
        val jsonStr = prefs.getString("match_history", null) ?: return emptyList()
        val list = mutableListOf<MatchRecord>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val diff = try {
                    BoardDifficulty.valueOf(obj.getString("diff"))
                } catch (e: Exception) {
                    BoardDifficulty.BEGINNER
                }
                list.add(
                    MatchRecord(
                        timestamp = obj.getLong("ts"),
                        difficulty = diff,
                        won = obj.getBoolean("won"),
                        timeSeconds = obj.getInt("time"),
                        threeBV = obj.getInt("3bv"),
                        threeBVs = obj.getDouble("3bvs").toFloat(),
                        clicks = obj.getInt("clicks"),
                        efficiencyPct = obj.getDouble("eff").toFloat()
                    )
                )
            }
        } catch (e: Exception) {
            // Parse error fallback
        }
        return list
    }

    // Campaign Progress
    fun loadCampaignProgress(): CampaignProgress {
        val unlocked = prefs.getInt("campaign_unlocked", 1)
        val hints = prefs.getInt("inventory_hints", 3)
        val wands = prefs.getInt("inventory_wands", 1)
        val starsStr = prefs.getString("campaign_stars", "") ?: ""
        val starsMap = mutableMapOf<Int, Int>()
        if (starsStr.isNotEmpty()) {
            starsStr.split(",").forEach {
                val parts = it.split(":")
                if (parts.size == 2) {
                    parts[0].toIntOrNull()?.let { lvl ->
                        parts[1].toIntOrNull()?.let { st -> starsMap[lvl] = st }
                    }
                }
            }
        }
        return CampaignProgress(
            unlockedLevel = unlocked,
            starsPerLevel = starsMap,
            hintsInventory = hints,
            magicWandsInventory = wands
        )
    }

    fun saveCampaignProgress(progress: CampaignProgress) {
        val starsStr = progress.starsPerLevel.entries.joinToString(",") { "${it.key}:${it.value}" }
        prefs.edit()
            .putInt("campaign_unlocked", progress.unlockedLevel)
            .putInt("inventory_hints", progress.hintsInventory)
            .putInt("inventory_wands", progress.magicWandsInventory)
            .putString("campaign_stars", starsStr)
            .apply()
    }

    // Daily Streak
    fun loadDailyStreak(): DailyStreakState {
        val currentStreak = prefs.getInt("daily_streak_current", 0)
        val longestStreak = prefs.getInt("daily_streak_longest", 0)
        val lastClaimMillis = prefs.getLong("daily_streak_last_claim", 0L)

        val isClaimedToday = isSameDay(lastClaimMillis, System.currentTimeMillis())

        return DailyStreakState(
            currentStreak = currentStreak,
            longestStreak = longestStreak,
            lastClaimDateMillis = lastClaimMillis,
            isClaimedToday = isClaimedToday
        )
    }

    fun claimDailyReward(): Pair<DailyStreakState, Pair<Int, Int>> {
        val current = loadDailyStreak()
        val now = System.currentTimeMillis()
        if (current.isClaimedToday) {
            return current to (0 to 0)
        }

        val wasYesterday = isYesterday(current.lastClaimDateMillis, now)
        val newStreak = if (wasYesterday || current.currentStreak == 0) {
            current.currentStreak + 1
        } else {
            1 // Streak broke because user missed a day
        }

        val newLongest = maxOf(current.longestStreak, newStreak)
        val reward = current.getRewardForDay(((newStreak - 1) % 7) + 1)

        prefs.edit()
            .putInt("daily_streak_current", newStreak)
            .putInt("daily_streak_longest", newLongest)
            .putLong("daily_streak_last_claim", now)
            .apply()

        // Also add reward to inventory
        val campProgress = loadCampaignProgress()
        saveCampaignProgress(
            campProgress.copy(
                hintsInventory = campProgress.hintsInventory + reward.hints,
                magicWandsInventory = campProgress.magicWandsInventory + reward.magicWands
            )
        )

        val newState = DailyStreakState(
            currentStreak = newStreak,
            longestStreak = newLongest,
            lastClaimDateMillis = now,
            isClaimedToday = true
        )
        return newState to (reward.hints to reward.magicWands)
    }

    // Tutorial completed flag
    fun hasCompletedTutorial(): Boolean {
        return prefs.getBoolean("has_completed_tutorial", false)
    }

    fun setTutorialCompleted(completed: Boolean) {
        prefs.edit().putBoolean("has_completed_tutorial", completed).apply()
    }

    private fun isSameDay(timeA: Long, timeB: Long): Boolean {
        if (timeA == 0L || timeB == 0L) return false
        val calA = Calendar.getInstance().apply { timeInMillis = timeA }
        val calB = Calendar.getInstance().apply { timeInMillis = timeB }
        return calA.get(Calendar.YEAR) == calB.get(Calendar.YEAR) &&
                calA.get(Calendar.DAY_OF_YEAR) == calB.get(Calendar.DAY_OF_YEAR)
    }

    private fun isYesterday(timeA: Long, timeB: Long): Boolean {
        if (timeA == 0L || timeB == 0L) return false
        val calA = Calendar.getInstance().apply { timeInMillis = timeA }
        val calB = Calendar.getInstance().apply { timeInMillis = timeB }
        calA.add(Calendar.DAY_OF_YEAR, 1)
        return calA.get(Calendar.YEAR) == calB.get(Calendar.YEAR) &&
                calA.get(Calendar.DAY_OF_YEAR) == calB.get(Calendar.DAY_OF_YEAR)
    }
}
