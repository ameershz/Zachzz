package com.example.minesweeper.model

data class DifficultyStats(
    val gamesPlayed: Int = 0,
    val gamesWon: Int = 0,
    val bestTimeSeconds: Int = 0,
    val totalTimeSeconds: Long = 0,
    val best3BV: Int = 0,
    val best3BVs: Float = 0f,
    val bestEfficiencyPct: Float = 0f
) {
    val winRatePct: Int
        get() = if (gamesPlayed > 0) ((gamesWon.toFloat() / gamesPlayed) * 100).toInt() else 0

    val averageTimeSeconds: Int
        get() = if (gamesWon > 0) (totalTimeSeconds / gamesWon).toInt() else 0
}

data class MatchRecord(
    val timestamp: Long,
    val difficulty: BoardDifficulty,
    val won: Boolean,
    val timeSeconds: Int,
    val threeBV: Int,
    val threeBVs: Float,
    val clicks: Int,
    val efficiencyPct: Float
)
