package com.example.minesweeper.engine

import com.example.minesweeper.model.Cell

object ThreeBVCalculator {

    /**
     * Calculates the 3BV (Bechtel's Board Benchmark Value) for a Minesweeper board.
     * 3BV is the minimum number of clicks required to solve the board without flagging.
     */
    fun calculate(grid: List<List<Cell>>, rows: Int, cols: Int): Int {
        val visited = Array(rows) { BooleanArray(cols) { false } }
        var threeBV = 0

        // Helper to get neighbors
        fun getNeighbors(r: Int, c: Int): List<Pair<Int, Int>> {
            val list = mutableListOf<Pair<Int, Int>>()
            for (dr in -1..1) {
                for (dc in -1..1) {
                    if (dr == 0 && dc == 0) continue
                    val nr = r + dr
                    val nc = c + dc
                    if (nr in 0 until rows && nc in 0 until cols) {
                        list.add(nr to nc)
                    }
                }
            }
            return list
        }

        // Step 1: Find all 0-cells and group into connected components
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (!cell.isMine && cell.adjacentMines == 0 && !visited[r][c]) {
                    // Start of a new opening component (1 click)
                    threeBV++
                    val queue = ArrayDeque<Pair<Int, Int>>()
                    queue.add(r to c)
                    visited[r][c] = true

                    while (queue.isNotEmpty()) {
                        val (currR, currC) = queue.removeFirst()
                        val neighbors = getNeighbors(currR, currC)
                        for ((nr, nc) in neighbors) {
                            val neighbor = grid[nr][nc]
                            if (!neighbor.isMine) {
                                if (neighbor.adjacentMines == 0 && !visited[nr][nc]) {
                                    visited[nr][nc] = true
                                    queue.add(nr to nc)
                                } else {
                                    // Numbered cell adjacent to zero - will be revealed by opening
                                    visited[nr][nc] = true
                                }
                            }
                        }
                    }
                }
            }
        }

        // Step 2: Any non-mine cell not visited by an opening requires an independent click
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (!cell.isMine && !visited[r][c]) {
                    threeBV++
                }
            }
        }

        return maxOf(1, threeBV)
    }
}
