package com.example.minesweeper.model

data class Cell(
    val row: Int,
    val col: Int,
    val isMine: Boolean = false,
    val isRevealed: Boolean = false,
    val isFlagged: Boolean = false,
    val adjacentMines: Int = 0,
    val isExplodedMine: Boolean = false,
    val isHinted: Boolean = false
)
