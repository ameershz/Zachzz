package com.example.minesweeper.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.model.GameMode
import com.example.minesweeper.model.GameStatus

@Composable
fun ResultDialog(
    status: GameStatus,
    gameMode: GameMode,
    timeSeconds: Int,
    threeBV: Int,
    threeBVs: Float,
    clicksCount: Int,
    efficiencyPct: Float,
    canReviveInCampaign: Boolean,
    onRestart: () -> Unit,
    onHome: () -> Unit,
    onRevive: () -> Unit
) {
    val isWin = status == GameStatus.WON

    Dialog(onDismissRequest = {}) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
            border = androidx.compose.foundation.BorderStroke(2.dp, if (isWin) Color(0xFF10B981) else Color(0xFFEF4444)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("result_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isWin) "🎉" else "💥",
                    fontSize = 52.sp
                )

                Text(
                    text = if (isWin) "مبروك! فوز ساحق" else "انفجر اللغم! حظ أوفر",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isWin) Color(0xFF34D399) else Color(0xFFF87171),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Stats breakdown box
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatRow(label = "الوقت المستغرق:", value = "$timeSeconds ثانية")
                    StatRow(label = "مؤشر 3BV للوحة:", value = threeBV.toString())
                    if (isWin) {
                        StatRow(label = "سرعة 3BV/ثانية:", value = String.format("%.2f", threeBVs))
                        StatRow(label = "كفاءة النقرات:", value = "${efficiencyPct.toInt()}%")
                    }
                    StatRow(label = "إجمالي النقرات:", value = clicksCount.toString())
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Revive button in Campaign mode if eligible
                if (!isWin && gameMode == GameMode.CAMPAIGN && canReviveInCampaign) {
                    Button(
                        onClick = onRevive,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEC4899)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("campaign_revive_button")
                    ) {
                        Text("💖 إحياء فرصة ثانية (مرة واحدة)", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onHome,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_home_button")
                    ) {
                        Text("القائمة 🏠", color = Color(0xFF94A3B8))
                    }

                    Button(
                        onClick = onRestart,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isWin) Color(0xFF10B981) else Color(0xFF3B82F6)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dialog_restart_button")
                    ) {
                        Text("إعادة 🔄", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color(0xFF94A3B8), fontSize = 13.sp)
        Text(text = value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
