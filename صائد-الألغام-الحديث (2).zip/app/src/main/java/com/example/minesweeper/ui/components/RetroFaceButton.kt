package com.example.minesweeper.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.GameStatus

@Composable
fun RetroFaceButton(
    status: GameStatus,
    isInteractingWithBoard: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val faceEmoji = when {
        status == GameStatus.WON -> "😎"
        status == GameStatus.LOST -> "😵"
        isInteractingWithBoard -> "😮"
        else -> "🙂"
    }

    Box(
        modifier = modifier
            .size(48.dp)
            .testTag("reset_face_button")
            .drawBehind {
                // Retro 3D beveled square
                val stroke = 3.dp.toPx()
                // Top & Left: White highlight
                drawLine(Color.White, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(Color.White, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                // Bottom & Right: Dark gray shadow
                drawLine(Color(0xFF707070), Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(Color(0xFF707070), Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(Color(0xFFC6C6C6), shape = RoundedCornerShape(2.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = faceEmoji,
            fontSize = 24.sp
        )
    }
}
