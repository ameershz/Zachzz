package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import com.example.minesweeper.model.GameStatus
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState
import com.example.minesweeper.ui.components.BottomControlsHUD
import com.example.minesweeper.ui.components.MinefieldGrid
import com.example.minesweeper.ui.components.TopGameHUD

@Composable
fun GameScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(uiState.currentTheme.boardBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top HUD
            TopGameHUD(
                remainingMines = uiState.remainingMines,
                timerSeconds = uiState.timerSeconds,
                gameStatus = uiState.gameStatus,
                isInteracting = uiState.isInteractingWithBoard,
                theme = uiState.currentTheme,
                hintsCount = uiState.campaignProgress.hintsInventory,
                wandsCount = uiState.campaignProgress.magicWandsInventory,
                isZoomLocked = uiState.isZoomLocked,
                onResetClick = {
                    viewModel.startNewGame(
                        difficulty = uiState.difficulty,
                        mode = uiState.gameMode,
                        campaignLevel = uiState.currentCampaignLevel
                    )
                },
                onHintClick = { viewModel.useSmartHint() },
                onWandClick = { viewModel.useMagicWand() },
                onToggleZoomLock = { viewModel.toggleZoomLock() },
                onBackClick = { viewModel.navigateTo(ScreenState.HOME) }
            )

            // Center Interactive Minefield
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clipToBounds()
            ) {
                MinefieldGrid(
                    grid = uiState.grid,
                    theme = uiState.currentTheme,
                    isFlagMode = uiState.isFlagMode,
                    chordingTrigger = uiState.settings.chordingTrigger,
                    isZoomLocked = uiState.isZoomLocked,
                    isGameLost = uiState.gameStatus == GameStatus.LOST,
                    onCellClick = { r, c -> viewModel.onCellClick(r, c) },
                    onCellLongClick = { r, c ->
                        val cell = uiState.grid.getOrNull(r)?.getOrNull(c)
                        if (cell != null && cell.isRevealed) {
                            viewModel.onCellChord(r, c)
                        } else {
                            viewModel.onCellFlag(r, c)
                        }
                    },
                    onCellDoubleTap = { r, c -> viewModel.onCellChord(r, c) },
                    onPressStateChanged = {}
                )
            }

            // Bottom Control Bar
            BottomControlsHUD(
                isFlagMode = uiState.isFlagMode,
                onToggleFlagMode = { viewModel.toggleFlagMode() },
                threeBV = uiState.threeBV,
                clicksCount = uiState.clicksCount
            )
        }

        // Result Dialog (Won / Lost)
        if (uiState.showResultDialog) {
            ResultDialog(
                status = uiState.gameStatus,
                gameMode = uiState.gameMode,
                timeSeconds = uiState.timerSeconds,
                threeBV = uiState.threeBV,
                threeBVs = uiState.threeBVs,
                clicksCount = uiState.clicksCount,
                efficiencyPct = uiState.efficiencyPct,
                canReviveInCampaign = !uiState.hasUsedReviveInCurrentGame,
                onRestart = {
                    viewModel.startNewGame(
                        difficulty = uiState.difficulty,
                        mode = uiState.gameMode,
                        campaignLevel = uiState.currentCampaignLevel
                    )
                },
                onHome = {
                    viewModel.dismissResultDialog()
                    viewModel.navigateTo(ScreenState.HOME)
                },
                onRevive = { viewModel.reviveInCampaign() }
            )
        }
    }
}
