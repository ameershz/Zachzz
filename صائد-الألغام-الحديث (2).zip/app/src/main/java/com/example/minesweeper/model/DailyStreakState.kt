package com.example.minesweeper.model

data class DailyStreakState(
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val lastClaimDateMillis: Long = 0L,
    val isClaimedToday: Boolean = false
) {
    fun getRewardForDay(day: Int): DailyReward {
        return when (day) {
            1 -> DailyReward(day = 1, hints = 1, magicWands = 0, labelAr = "1 تلميح ذكي")
            2 -> DailyReward(day = 2, hints = 2, magicWands = 0, labelAr = "2 تلميح ذكي")
            3 -> DailyReward(day = 3, hints = 1, magicWands = 1, labelAr = "1 تلميح + 1 عصا سحرية")
            4 -> DailyReward(day = 4, hints = 2, magicWands = 1, labelAr = "2 تلميح + 1 عصا سحرية")
            5 -> DailyReward(day = 5, hints = 3, magicWands = 1, labelAr = "3 تلميحات + 1 عصا سحرية")
            6 -> DailyReward(day = 6, hints = 3, magicWands = 2, labelAr = "3 تلميحات + 2 عصا سحرية")
            7 -> DailyReward(day = 7, hints = 5, magicWands = 3, labelAr = "الجائزة الكبرى: 5 تلميحات + 3 عصا سحرية")
            else -> DailyReward(day = ((day - 1) % 7) + 1, hints = 2, magicWands = 1, labelAr = "مكافأة ممتازة")
        }
    }
}

data class DailyReward(
    val day: Int,
    val hints: Int,
    val magicWands: Int,
    val labelAr: String
)
