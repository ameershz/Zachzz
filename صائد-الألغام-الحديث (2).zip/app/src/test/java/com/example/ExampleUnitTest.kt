package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testFitCellSizeCalculation_ExpertFitsCompletely() {
        // Standard phone width in dp: 360dp, height: 520dp
        val containerWidth = 360f
        val containerHeight = 520f
        val boardExtraSpace = 24f

        val availWidth = containerWidth - boardExtraSpace
        val availHeight = containerHeight - boardExtraSpace

        // Expert: 16 rows, 30 columns
        val rows = 16
        val cols = 30

        val cellWidth = availWidth / cols
        val cellHeight = availHeight / rows
        val fitCellSize = minOf(cellWidth, cellHeight)

        val totalBoardWidth = fitCellSize * cols + boardExtraSpace
        val totalBoardHeight = fitCellSize * rows + boardExtraSpace

        assertTrue("Expert board width ($totalBoardWidth) must fit in container width ($containerWidth)", totalBoardWidth <= containerWidth + 0.01f)
        assertTrue("Expert board height ($totalBoardHeight) must fit in container height ($containerHeight)", totalBoardHeight <= containerHeight + 0.01f)
    }

    @Test
    fun testFitCellSizeCalculation_IntermediateFitsCompletely() {
        val containerWidth = 360f
        val containerHeight = 520f
        val boardExtraSpace = 24f

        val availWidth = containerWidth - boardExtraSpace
        val availHeight = containerHeight - boardExtraSpace

        // Intermediate: 16 rows, 16 columns
        val rows = 16
        val cols = 16

        val cellWidth = availWidth / cols
        val cellHeight = availHeight / rows
        val fitCellSize = minOf(cellWidth, cellHeight)

        val totalBoardWidth = fitCellSize * cols + boardExtraSpace
        val totalBoardHeight = fitCellSize * rows + boardExtraSpace

        assertTrue("Intermediate board width ($totalBoardWidth) must fit in container width ($containerWidth)", totalBoardWidth <= containerWidth + 0.01f)
        assertTrue("Intermediate board height ($totalBoardHeight) must fit in container height ($containerHeight)", totalBoardHeight <= containerHeight + 0.01f)
    }

    @Test
    fun testFitCellSizeCalculation_BeginnerFitsCompletely() {
        val containerWidth = 360f
        val containerHeight = 520f
        val boardExtraSpace = 24f

        val availWidth = containerWidth - boardExtraSpace
        val availHeight = containerHeight - boardExtraSpace

        // Beginner: 9 rows, 9 columns
        val rows = 9
        val cols = 9

        val cellWidth = availWidth / cols
        val cellHeight = availHeight / rows
        val fitCellSize = minOf(cellWidth, cellHeight)

        val totalBoardWidth = fitCellSize * cols + boardExtraSpace
        val totalBoardHeight = fitCellSize * rows + boardExtraSpace

        assertTrue("Beginner board width ($totalBoardWidth) must fit in container width ($containerWidth)", totalBoardWidth <= containerWidth + 0.01f)
        assertTrue("Beginner board height ($totalBoardHeight) must fit in container height ($containerHeight)", totalBoardHeight <= containerHeight + 0.01f)
    }

    @Test
    fun testClampOffsets_KeepsCenteredWhenNotOverflowing() {
        val containerWidth = 360f
        val baseBoardWidth = 340f

        // At scale 1.0, scaledW = 340 <= 360
        val scale = 1.0f
        val scaledW = baseBoardWidth * scale

        val targetX = 50f
        val clampedX = if (scaledW <= containerWidth) 0f else {
            val maxOx = (scaledW - containerWidth) / 2f
            targetX.coerceIn(-maxOx, maxOx)
        }

        assertEquals(0f, clampedX, 0.001f)
    }

    @Test
    fun testClampOffsets_RestrictsPanWhenZoomedIn() {
        val containerWidth = 360f
        val baseBoardWidth = 360f

        // At scale 2.0, scaledW = 720 > 360
        val scale = 2.0f
        val scaledW = baseBoardWidth * scale
        val maxOx = (scaledW - containerWidth) / 2f // (720 - 360) / 2 = 180f

        // Excessive pan to the right
        val targetXRight = 500f
        val clampedXRight = targetXRight.coerceIn(-maxOx, maxOx)
        assertEquals(180f, clampedXRight, 0.001f)

        // Excessive pan to the left
        val targetXLeft = -500f
        val clampedXLeft = targetXLeft.coerceIn(-maxOx, maxOx)
        assertEquals(-180f, clampedXLeft, 0.001f)
    }

    @Test
    fun testAllTwelveThemesExistWithExactNames() {
        val themes = com.example.minesweeper.model.AvailableThemes.allThemes
        assertEquals(12, themes.size)

        val expectedNames = listOf(
            "رمادي كلاسيكي", "فحمي", "نحاسي", "وردي غامق",
            "نعناعي", "ذهبي", "أزرق ملكي", "ضبابي",
            "أخضر هادئ", "ليلي", "جليدي", "بنفسجي"
        )

        themes.forEachIndexed { index, theme ->
            assertEquals(index, theme.index)
            assertEquals("theme_$index", theme.id)
            assertEquals(expectedNames[index], theme.name)
        }
    }

    @Test
    fun testClassicGrayThemeExactColors() {
        val theme0 = com.example.minesweeper.model.AvailableThemes.ClassicGray
        assertEquals(0, theme0.index)
        assertEquals("رمادي كلاسيكي", theme0.name)
        assertEquals(androidx.compose.ui.graphics.Color(0xFFBDBDBD), theme0.cellFace)
        assertEquals(androidx.compose.ui.graphics.Color(0xFFFFFFFF), theme0.cellLight)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF7B7B7B), theme0.cellDark)
        assertEquals(androidx.compose.ui.graphics.Color(0xFFDEDEDE), theme0.pressedFace)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF7B7B7B), theme0.pressedEdge)
        assertEquals(androidx.compose.ui.graphics.Color(0xFFBDBDBD), theme0.floor)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF000000), theme0.mineColor)
        assertEquals(androidx.compose.ui.graphics.Color(0xFFFF0000), theme0.flagColor)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF000000), theme0.flagStand)
    }

    @Test
    fun testStandardDigitColors() {
        val colors = com.example.minesweeper.model.AvailableThemes.standardDigitColors
        assertEquals(8, colors.size)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF0000FF), colors[0]) // 1 Blue
        assertEquals(androidx.compose.ui.graphics.Color(0xFF008000), colors[1]) // 2 Green
        assertEquals(androidx.compose.ui.graphics.Color(0xFFF40000), colors[2]) // 3 Red
        assertEquals(androidx.compose.ui.graphics.Color(0xFF000080), colors[3]) // 4 Navy
        assertEquals(androidx.compose.ui.graphics.Color(0xFF800000), colors[4]) // 5 Maroon
        assertEquals(androidx.compose.ui.graphics.Color(0xFF008080), colors[5]) // 6 Teal
        assertEquals(androidx.compose.ui.graphics.Color(0xFF000000), colors[6]) // 7 Black
        assertEquals(androidx.compose.ui.graphics.Color(0xFF808080), colors[7]) // 8 Gray
    }
}
