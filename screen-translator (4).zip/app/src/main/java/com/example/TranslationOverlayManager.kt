package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.TextViewCompat

/**
 * Data model for each text block extracted from OCR + Translation.
 * Real screen coordinates (left, top, width, height) in pixels.
 */
data class TranslationBlock(
    val id: String,
    val originalText: String,
    var translatedText: String = "",
    val rect: Rect
)

/**
 * Manages the single full-screen Floating Window containing translated TextView layers
 * directly overlaid on top of original screen text in their exact coordinates.
 *
 * Implements:
 * 1. Single Floating Window with TYPE_APPLICATION_OVERLAY, TRANSLUCENT format,
 *    and flags: FLAG_NOT_FOCUSABLE | FLAG_LAYOUT_IN_SCREEN | FLAG_LAYOUT_NO_LIMITS.
 * 2. TranslationBlock model with precise pixel-scale coordinates.
 * 3. setBlockList to build initially GONE TextViews with exact FrameLayout.LayoutParams margins.
 * 4. updateBlockTranslation to display in-place translated text with auto-sizing and solid masking.
 * 5. Dismissal methods: tapping any block, tapping empty screen space, dedicated dismiss pill,
 *    or tapping the floating bubble.
 */
class TranslationOverlayManager(
    private val context: Context,
    private val windowManager: WindowManager
) {
    companion object {
        private const val TAG = "TranslationOverlay"
    }

    // Full screen container holding all translation layers
    private val container: FrameLayout = FrameLayout(context).apply {
        clipChildren = false
        clipToPadding = false
        fitsSystemWindows = false
    }

    private var isAttached = false
    private val currentBlocks = mutableListOf<TranslationBlock>()
    private var dismissPillView: View? = null

    // WindowManager parameters: covers screen, no focus stealing, accurate coordinate placement
    private val windowParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        },
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 0
        y = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    val isShowing: Boolean
        get() = isAttached && container.childCount > 0

    init {
        // Tapping anywhere on the empty screen dismisses the translation overlay
        container.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                clear()
                true
            } else {
                false
            }
        }
    }

    /**
     * Requirement 3: setBlockList
     * Builds initially hidden (GONE) TextViews for each block positioned at rect.left, rect.top.
     * Skips rebuilding if new block list matches the previous one.
     */
    fun setBlockList(newBlocks: List<TranslationBlock>) {
        if (isIdenticalBlocks(newBlocks)) {
            Log.d(TAG, "Block list identical to previous, skipping view rebuild")
            return
        }

        clearViews()
        currentBlocks.clear()
        currentBlocks.addAll(newBlocks)

        ensureAttached()

        // Create the dedicated top dismiss button [ ✕ إغلاق الترجمة ]
        createDismissPill()

        for (block in newBlocks) {
            val tv = TextView(context).apply {
                tag = block.id
                visibility = View.GONE
                includeFontPadding = false
                isClickable = true
                isFocusable = false

                val lp = FrameLayout.LayoutParams(
                    block.rect.width(),
                    block.rect.height()
                ).apply {
                    marginStart = block.rect.left
                    leftMargin = block.rect.left
                    topMargin = block.rect.top
                    gravity = Gravity.TOP or Gravity.START
                }
                layoutParams = lp

                // Tapping on a translation block: speaks text, copies it, and allows dismissing
                setOnClickListener {
                    TranslationHelper.speak(block.translatedText, "ar")
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Translated Text", block.translatedText))
                    Toast.makeText(context, "تم نسخ النص ونطقه", Toast.LENGTH_SHORT).show()

                    // Smooth dismiss animation for this block
                    animate().alpha(0f).setDuration(180).withEndAction {
                        visibility = View.GONE
                    }.start()
                }
            }
            container.addView(tv)
        }
    }

    /**
     * Requirement 4: Update layers after translation arrives.
     * Sets translated text, calculates adaptive font size, adds ~90% opaque dark background,
     * adjusts layout params, and makes the TextView VISIBLE directly over original text.
     */
    fun updateBlockTranslation(block: TranslationBlock) {
        val tv = container.findViewWithTag<TextView>(block.id) ?: return

        tv.text = block.translatedText

        val density = context.resources.displayMetrics.density
        val rawHeightSp = if (density > 0f) block.rect.height() / density else 14f
        val calculatedSp = (rawHeightSp * 0.72f).coerceIn(9f, 22f)

        try {
            TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(
                tv,
                9,
                22,
                1,
                TypedValue.COMPLEX_UNIT_SP
            )
        } catch (_: Exception) {
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, calculatedSp)
        }

        tv.ellipsize = TextUtils.TruncateAt.END

        // Solid background completely masking the original text underneath
        val bgDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.parseColor("#F20F172A")) // ~95% solid dark slate
            cornerRadius = dpToPx(4f)
            setStroke(dpToPx(1f).toInt(), Color.parseColor("#FFA800")) // Orange accent matching original style
        }
        tv.background = bgDrawable
        tv.setTextColor(Color.parseColor("#FFFFFF"))
        tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        tv.gravity = Gravity.CENTER

        val padH = dpToPx(3f).toInt()
        val padV = dpToPx(1f).toInt()
        tv.setPadding(padH, padV, padH, padV)

        val lp = tv.layoutParams as? FrameLayout.LayoutParams ?: FrameLayout.LayoutParams(
            block.rect.width(),
            block.rect.height()
        )
        lp.width = block.rect.width()
        lp.height = block.rect.height()
        lp.marginStart = block.rect.left
        lp.leftMargin = block.rect.left
        lp.topMargin = block.rect.top
        lp.gravity = Gravity.TOP or Gravity.START
        tv.layoutParams = lp

        tv.alpha = 0f
        tv.visibility = View.VISIBLE
        tv.animate().alpha(1f).setDuration(160).start()
    }

    /**
     * Dedicated floating dismiss pill [ ✕ إغلاق الترجمة ] at top center of screen
     */
    private fun createDismissPill() {
        val pill = TextView(context).apply {
            text = "✕  إغلاق الترجمة"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER

            val bg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(Color.parseColor("#CC1E293B"))
                cornerRadius = dpToPx(16f)
                setStroke(dpToPx(1f).toInt(), Color.parseColor("#475569"))
            }
            background = bg

            val padH = dpToPx(14f).toInt()
            val padV = dpToPx(6f).toInt()
            setPadding(padH, padV, padH, padV)

            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = dpToPx(42f).toInt()
            }
            layoutParams = lp

            setOnClickListener {
                clear()
            }
        }

        dismissPillView = pill
        container.addView(pill)
    }

    private fun isIdenticalBlocks(newBlocks: List<TranslationBlock>): Boolean {
        if (currentBlocks.size != newBlocks.size) return false
        for (i in currentBlocks.indices) {
            val oldB = currentBlocks[i]
            val newB = newBlocks[i]
            if (oldB.id != newB.id || oldB.rect != newB.rect || oldB.originalText != newB.originalText) {
                return false
            }
        }
        return true
    }

    private fun ensureAttached() {
        if (!isAttached) {
            try {
                windowManager.addView(container, windowParams)
                isAttached = true
            } catch (e: Exception) {
                Log.e(TAG, "Error attaching translation overlay window: ${e.message}", e)
            }
        }
    }

    /**
     * Requirement 5: Cleanup. Removes all previous views and detaches window from WindowManager.
     */
    fun clear() {
        clearViews()
        currentBlocks.clear()
        detach()
    }

    private fun clearViews() {
        container.removeAllViews()
        dismissPillView = null
    }

    private fun detach() {
        if (isAttached) {
            try {
                windowManager.removeView(container)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing translation overlay window: ${e.message}", e)
            }
            isAttached = false
        }
    }

    private fun dpToPx(dp: Float): Float {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp,
            context.resources.displayMetrics
        )
    }
}
