package com.example

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Point
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FloatService : Service() {

    companion object {
        private const val TAG = "FloatService"
        const val CHANNEL_ID = "screen_translator_channel"
        const val NOTIFICATION_ID = 1001

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_TARGET_LANG = "extra_target_lang"
        const val EXTRA_SOURCE_LANG = "extra_source_lang"
        const val ACTION_STOP_SERVICE = "com.example.ACTION_STOP_SERVICE"

        var isRunning = false
            private set
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var windowManager: WindowManager
    private lateinit var mediaProjectionManager: MediaProjectionManager

    // Media Projection and screen capture
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var mediaProjectionCallback: MediaProjection.Callback? = null

    // Floating bubble UI
    private var bubbleView: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var isBubbleAttached = false

    // Floating translation result dialog UI
    private var dialogView: View? = null
    private lateinit var dialogParams: WindowManager.LayoutParams
    private var isDialogAttached = false

    // Text recognition & translation
    private val textRecognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var sourceLang = "auto"
    private var targetLang = "ar"

    // Last captured texts for re-translation / swap
    private var lastOriginalText: String = ""
    private var lastTranslatedText: String = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        TranslationHelper.initTts(this)
        createNotificationChannel()
        initBubbleLayoutParams()
        initDialogLayoutParams()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Read language configurations
        intent?.getStringExtra(EXTRA_SOURCE_LANG)?.let { sourceLang = it }
        intent?.getStringExtra(EXTRA_TARGET_LANG)?.let { targetLang = it }

        // Start Foreground Service with MEDIA_PROJECTION type
        startForegroundServiceNotification()

        // Extract MediaProjection token if provided
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData: Intent? = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                    ?: @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
            } else {
                @Suppress("DEPRECATION")
                intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error unmarshalling resultData: ${e.message}")
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
        }

        if (resultCode != 0 && resultData != null && mediaProjection == null) {
            setupMediaProjection(resultCode, resultData)
        }

        // Initialize and display the floating bubble
        if (!isBubbleAttached) {
            createFloatingBubble()
        } else {
            updateBubbleLanguageBadge()
        }

        return START_STICKY
    }

    /**
     * Requirement 1: Mandatory Orientation Fix using Point(x, y).
     * Retrieves real physical screen dimensions dynamically from WindowManager.
     */
    fun getRealScreenDimensions(): Point {
        val point = Point()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.maximumWindowMetrics
            val bounds = windowMetrics.bounds
            point.x = bounds.width()
            point.y = bounds.height()
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealSize(point)
        }
        return point
    }

    /**
     * Dynamically updates drag boundaries and layout params based on Point(x,y)
     * and explicit orientation check: `if (x < y)`.
     */
    private fun updateScreenBoundsAndClamping(autoSnapToEdge: Boolean = false) {
        val point = getRealScreenDimensions()

        // MANDATORY MANUAL ORIENTATION COMPARISON:
        val isPortrait = point.x < point.y
        val screenWidth = point.x
        val screenHeight = point.y

        val bubbleW = bubbleView?.width?.takeIf { it > 0 } ?: dpToPx(64)
        val bubbleH = bubbleView?.height?.takeIf { it > 0 } ?: dpToPx(64)

        val maxX = (screenWidth - bubbleW).coerceAtLeast(0)
        val maxY = (screenHeight - bubbleH).coerceAtLeast(0)

        if (autoSnapToEdge) {
            val midX = screenWidth / 2
            bubbleParams.x = if (bubbleParams.x < midX) 0 else maxX
        } else {
            bubbleParams.x = bubbleParams.x.coerceIn(0, maxX)
        }
        bubbleParams.y = bubbleParams.y.coerceIn(0, maxY)

        if (isBubbleAttached && bubbleView != null) {
            try {
                windowManager.updateViewLayout(bubbleView, bubbleParams)
            } catch (e: Exception) {
                Log.e(TAG, "Failed updating bubble layout bounds: ${e.message}")
            }
        }

        // Also update dialog boundaries if visible
        if (isDialogAttached && dialogView != null) {
            val targetDialogWidth = (screenWidth * 0.92f).toInt().coerceIn(dpToPx(300), dpToPx(520))
            dialogParams.width = targetDialogWidth
            try {
                windowManager.updateViewLayout(dialogView, dialogParams)
            } catch (e: Exception) {
                Log.e(TAG, "Failed updating dialog layout bounds: ${e.message}")
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Screen orientation rotated: recalculate Point(x,y), check if (x < y), and snap within bounds
        mainHandler.postDelayed({
            updateScreenBoundsAndClamping(autoSnapToEdge = true)
            setupVirtualDisplay()
        }, 150)
    }

    /**
     * Requirement 2: Start Foreground Service with FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
     */
    private fun startForegroundServiceNotification() {
        val stopIntent = Intent(this, FloatService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(R.drawable.ic_bubble_translate)
            .setContentIntent(openAppPendingIntent)
            .addAction(R.drawable.ic_close_vector, getString(R.string.notification_stop), stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    /**
     * Requirement 4: Set up MediaProjection and ImageReader
     */
    private fun setupMediaProjection(resultCode: Int, resultData: Intent) {
        try {
            mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, resultData)
            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    Log.w(TAG, "MediaProjection stopped by system")
                    cleanUpMediaProjection()
                }
            }
            mediaProjectionCallback = callback
            mediaProjection?.registerCallback(callback, mainHandler)
            setupVirtualDisplay()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize MediaProjection: ${e.message}", e)
        }
    }

    private fun setupVirtualDisplay() {
        if (mediaProjection == null) return

        val point = getRealScreenDimensions()
        val isPortrait = point.x < point.y
        val width = point.x
        val height = point.y
        val density = resources.displayMetrics.densityDpi

        try {
            imageReader?.close()
            virtualDisplay?.release()

            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "FloatServiceVirtualDisplay",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                mainHandler
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up VirtualDisplay: ${e.message}")
        }
    }

    /**
     * Requirement 3: Floating Bubble View & Touch & Drag using Point(x,y)
     */
    private fun initBubbleLayoutParams() {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Default initial position
            val point = getRealScreenDimensions()
            val isPortrait = point.x < point.y
            x = point.x - dpToPx(72)
            y = (point.y * 0.35f).toInt()
        }
    }

    private fun initDialogLayoutParams() {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val point = getRealScreenDimensions()
        val dialogWidth = (point.x * 0.92f).toInt().coerceIn(dpToPx(300), dpToPx(520))

        dialogParams = WindowManager.LayoutParams(
            dialogWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = 0
            y = 0
        }
    }

    private fun createFloatingBubble() {
        val inflater = LayoutInflater.from(this)
        bubbleView = inflater.inflate(R.layout.layout_floating_bubble, null)

        val root = bubbleView?.findViewById<View>(R.id.bubble_root)
        updateBubbleLanguageBadge()

        // Touch & Drag listener with Point(x, y) orientation clamping
        var initialTouchX = 0f
        var initialTouchY = 0f
        var initialWindowX = 0
        var initialWindowY = 0
        var isDragging = false
        var touchDownTime = 0L
        val clickThresholdMs = 260L
        val moveThresholdPx = 14f

        root?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    initialWindowX = bubbleParams.x
                    initialWindowY = bubbleParams.y
                    touchDownTime = System.currentTimeMillis()
                    isDragging = false
                    view.animate().scaleX(0.92f).scaleY(0.92f).setDuration(100).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY

                    if (Math.hypot(dx.toDouble(), dy.toDouble()) > moveThresholdPx) {
                        isDragging = true
                    }

                    // Requirement 1 & 3: Query Point(x, y) dynamically and check (x < y)
                    val point = getRealScreenDimensions()
                    val isPortrait = point.x < point.y
                    val bubbleW = view.width.takeIf { it > 0 } ?: dpToPx(64)
                    val bubbleH = view.height.takeIf { it > 0 } ?: dpToPx(64)
                    val maxX = (point.x - bubbleW).coerceAtLeast(0)
                    val maxY = (point.y - bubbleH).coerceAtLeast(0)

                    // Dynamically clamp coordinates within Point(x, y) boundaries
                    bubbleParams.x = (initialWindowX + dx).toInt().coerceIn(0, maxX)
                    bubbleParams.y = (initialWindowY + dy).toInt().coerceIn(0, maxY)

                    if (isBubbleAttached) {
                        windowManager.updateViewLayout(bubbleView, bubbleParams)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.animate().scaleX(1.0f).scaleY(1.0f).setDuration(120).start()
                    val clickDuration = System.currentTimeMillis() - touchDownTime
                    val totalDistance = Math.hypot((event.rawX - initialTouchX).toDouble(), (event.rawY - initialTouchY).toDouble())

                    if (!isDragging && clickDuration < clickThresholdMs && totalDistance < moveThresholdPx) {
                        // Single Tap: Trigger Screen Capture and Translation!
                        view.performClick()
                        onBubbleClicked()
                    } else {
                        // Drag released: snap smoothly to left or right screen edge using Point(x, y)
                        val point = getRealScreenDimensions()
                        val isPortrait = point.x < point.y
                        val bubbleW = view.width.takeIf { it > 0 } ?: dpToPx(64)
                        val maxX = (point.x - bubbleW).coerceAtLeast(0)
                        val snapToRight = bubbleParams.x > (point.x / 2)
                        val targetX = if (snapToRight) maxX else 0

                        animateBubbleSnap(bubbleParams.x, targetX)
                    }
                    true
                }
                else -> false
            }
        }

        try {
            windowManager.addView(bubbleView, bubbleParams)
            isBubbleAttached = true
            updateScreenBoundsAndClamping(autoSnapToEdge = true)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding bubble view: ${e.message}")
        }
    }

    private fun animateBubbleSnap(startX: Int, endX: Int) {
        val animator = ValueAnimator.ofInt(startX, endX)
        animator.duration = 200
        animator.interpolator = DecelerateInterpolator()
        animator.addUpdateListener { animation ->
            bubbleParams.x = animation.animatedValue as Int
            if (isBubbleAttached && bubbleView != null) {
                try {
                    windowManager.updateViewLayout(bubbleView, bubbleParams)
                } catch (e: Exception) {
                    Log.e(TAG, "Error updating during snap animation: ${e.message}")
                }
            }
        }
        animator.start()
    }

    private fun updateBubbleLanguageBadge() {
        val badge = bubbleView?.findViewById<TextView>(R.id.bubble_lang_badge)
        badge?.text = targetLang.uppercase()
    }

    /**
     * Requirement 4: Screen Capture when tapping the bubble
     */
    private fun onBubbleClicked() {
        if (mediaProjection == null) {
            Toast.makeText(this, "يرجى منح إذن التقاط الشاشة من التطبيق أولاً", Toast.LENGTH_LONG).show()
            // Launch MainActivity to request permission
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            startActivity(intent)
            return
        }

        serviceScope.launch {
            try {
                // Show scanning state in bubble
                setBubbleScanningState(true)

                // 1. Temporarily hide bubble so it is not visible in screenshot
                bubbleView?.visibility = View.INVISIBLE
                delay(120) // wait for frame refresh without bubble

                // 2. Capture screenshot from ImageReader
                val capturedBitmap = captureCurrentScreen()

                // 3. Restore bubble visibility
                bubbleView?.visibility = View.VISIBLE
                setBubbleScanningState(false)

                if (capturedBitmap != null) {
                    processCapturedBitmap(capturedBitmap)
                } else {
                    Toast.makeText(this@FloatService, "لم يتم التقاط الصورة، جارِ إعادة تهيئة العرض...", Toast.LENGTH_SHORT).show()
                    setupVirtualDisplay()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in bubble click execution: ${e.message}", e)
                bubbleView?.visibility = View.VISIBLE
                setBubbleScanningState(false)
            }
        }
    }

    private fun setBubbleScanningState(isScanning: Boolean) {
        val icon = bubbleView?.findViewById<ImageView>(R.id.bubble_icon)
        val progress = bubbleView?.findViewById<ProgressBar>(R.id.bubble_progress)
        if (isScanning) {
            icon?.visibility = View.INVISIBLE
            progress?.visibility = View.VISIBLE
        } else {
            icon?.visibility = View.VISIBLE
            progress?.visibility = View.GONE
        }
    }

    private suspend fun captureCurrentScreen(): Bitmap? = withContext(Dispatchers.Default) {
        var image: Image? = null
        try {
            image = imageReader?.acquireLatestImage()
            if (image == null) {
                // Retry once with small delay
                delay(80)
                image = imageReader?.acquireLatestImage()
            }
            if (image == null) return@withContext null

            val planes = image.planes
            if (planes.isNullOrEmpty()) return@withContext null

            val buffer = planes[0].buffer ?: return@withContext null
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val width = image.width
            val height = image.height

            if (width <= 0 || height <= 0) return@withContext null

            val rowPadding = maxOf(0, rowStride - pixelStride * width)
            val bitmapWidth = width + rowPadding / pixelStride

            val bitmap = Bitmap.createBitmap(
                bitmapWidth,
                height,
                Bitmap.Config.ARGB_8888
            )
            val requiredBytes = bitmap.byteCount

            // CRITICAL FIX: The buffer of Image from ImageReader in MediaProjection might not include
            // row padding on the final row (buffer.remaining() < requiredBytes).
            // Passing buffer directly to copyPixelsFromBuffer causes:
            // "java.lang.RuntimeException: Buffer not large enough for pixels" and crashes the app!
            if (buffer.remaining() < requiredBytes) {
                val tempBuffer = java.nio.ByteBuffer.allocateDirect(requiredBytes)
                tempBuffer.put(buffer)
                tempBuffer.rewind()
                bitmap.copyPixelsFromBuffer(tempBuffer)
            } else {
                bitmap.copyPixelsFromBuffer(buffer)
            }

            // Crop out excess padding if any
            if (rowPadding == 0 && bitmapWidth == width) {
                bitmap
            } else {
                Bitmap.createBitmap(bitmap, 0, 0, width, height)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Screen capture failed safely: ${e.message}", e)
            null
        } finally {
            try {
                image?.close()
            } catch (e: Exception) {
                Log.e(TAG, "Error closing image: ${e.message}")
            }
        }
    }

    /**
     * OCR via ML Kit Text Recognition and Translation
     */
    private fun processCapturedBitmap(bitmap: Bitmap) {
        showTranslationLoadingDialog()

        val inputImage = InputImage.fromBitmap(bitmap, 0)
        textRecognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val detectedText = visionText.text.trim()
                if (detectedText.isNotEmpty()) {
                    translateAndPresent(detectedText)
                } else {
                    showTranslationResultDialog(
                        original = "لم يتم اكتشاف نصوص في هذه المنطقة من الشاشة",
                        translated = "تأكد من فتح تطبيق أو لعبة تحتوي على نصوص، ثم انقر على الفقاعة مجدداً للترجمة الفورية."
                    )
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "OCR Recognition failure: ${e.message}", e)
                showTranslationResultDialog(
                    original = "تعذر التعرف على النص: ${e.localizedMessage}",
                    translated = "يرجى المحاولة مجدداً أو التحقق من إعدادات الشاشة."
                )
            }
    }

    private fun translateAndPresent(text: String) {
        serviceScope.launch {
            val translated = TranslationHelper.translateText(
                text = text,
                sourceLang = sourceLang,
                targetLang = targetLang
            )
            showTranslationResultDialog(original = text, translated = translated)
        }
    }

    /**
     * Floating Translation Card Dialog
     */
    private fun showTranslationLoadingDialog() {
        mainHandler.post {
            ensureDialogCreated()
            val layoutLoading = dialogView?.findViewById<LinearLayout>(R.id.layout_loading)
            val layoutContent = dialogView?.findViewById<LinearLayout>(R.id.layout_content)
            val tvPair = dialogView?.findViewById<TextView>(R.id.tv_lang_pair_badge)

            tvPair?.text = "${sourceLang.uppercase()} ➔ ${targetLang.uppercase()}"
            layoutLoading?.visibility = View.VISIBLE
            layoutContent?.visibility = View.GONE

            showDialogView()
        }
    }

    private fun showTranslationResultDialog(original: String, translated: String) {
        lastOriginalText = original
        lastTranslatedText = translated

        mainHandler.post {
            ensureDialogCreated()
            val layoutLoading = dialogView?.findViewById<LinearLayout>(R.id.layout_loading)
            val layoutContent = dialogView?.findViewById<LinearLayout>(R.id.layout_content)
            val tvOriginal = dialogView?.findViewById<TextView>(R.id.tv_original_text)
            val tvTranslated = dialogView?.findViewById<TextView>(R.id.tv_translated_text)
            val tvPair = dialogView?.findViewById<TextView>(R.id.tv_lang_pair_badge)

            tvPair?.text = "${sourceLang.uppercase()} ➔ ${targetLang.uppercase()}"
            tvOriginal?.text = original
            tvTranslated?.text = translated

            layoutLoading?.visibility = View.GONE
            layoutContent?.visibility = View.VISIBLE

            showDialogView()
        }
    }

    private fun ensureDialogCreated() {
        if (dialogView != null) return

        try {
            val themedContext = android.view.ContextThemeWrapper(this, R.style.Theme_MyApplication)
            val inflater = LayoutInflater.from(themedContext)
            dialogView = inflater.inflate(R.layout.layout_translation_result, null)

            val btnClose = dialogView?.findViewById<ImageButton>(R.id.btn_close_dialog)
            val btnDismiss = dialogView?.findViewById<Button>(R.id.btn_dismiss_result)
            val btnCopyOriginal = dialogView?.findViewById<ImageButton>(R.id.btn_copy_original)
            val btnCopyTranslated = dialogView?.findViewById<ImageButton>(R.id.btn_copy_translated)
            val btnSpeakOriginal = dialogView?.findViewById<ImageButton>(R.id.btn_speak_original)
            val btnSpeakTranslated = dialogView?.findViewById<ImageButton>(R.id.btn_speak_translated)
            val btnRescan = dialogView?.findViewById<Button>(R.id.btn_rescan_screen)
            val btnSwap = dialogView?.findViewById<Button>(R.id.btn_swap_languages)
            val dragHandle = dialogView?.findViewById<ImageView>(R.id.iv_drag_handle)

            btnClose?.setOnClickListener { hideDialogView() }
            btnDismiss?.setOnClickListener { hideDialogView() }

            btnCopyOriginal?.setOnClickListener {
                copyToClipboard("Original Text", lastOriginalText)
                Toast.makeText(this, "تم نسخ النص الأصلي", Toast.LENGTH_SHORT).show()
            }

            btnCopyTranslated?.setOnClickListener {
                copyToClipboard("Translation", lastTranslatedText)
                Toast.makeText(this, "تم نسخ الترجمة", Toast.LENGTH_SHORT).show()
            }

            btnSpeakOriginal?.setOnClickListener {
                TranslationHelper.speak(lastOriginalText, sourceLang)
            }

            btnSpeakTranslated?.setOnClickListener {
                TranslationHelper.speak(lastTranslatedText, targetLang)
            }

            btnRescan?.setOnClickListener {
                hideDialogView()
                mainHandler.postDelayed({ onBubbleClicked() }, 150)
            }

            btnSwap?.setOnClickListener {
                val temp = if (sourceLang == "auto") "en" else sourceLang
                sourceLang = targetLang
                targetLang = temp
                updateBubbleLanguageBadge()
                translateAndPresent(lastOriginalText)
            }

            var dTouchX = 0f
            var dTouchY = 0f
            var dWinX = 0
            var dWinY = 0
            dragHandle?.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        dTouchX = event.rawX
                        dTouchY = event.rawY
                        dWinX = dialogParams.x
                        dWinY = dialogParams.y
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        dialogParams.x = (dWinX + (event.rawX - dTouchX)).toInt()
                        dialogParams.y = (dWinY + (event.rawY - dTouchY)).toInt()
                        if (isDialogAttached && dialogView != null) {
                            try {
                                windowManager.updateViewLayout(dialogView, dialogParams)
                            } catch (e: Exception) {
                                Log.e(TAG, "Error updating dialog drag: ${e.message}")
                            }
                        }
                        true
                    }
                    else -> false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed creating dialogView: ${e.message}", e)
        }
    }

    private fun showDialogView() {
        if (dialogView == null) return
        try {
            val point = getRealScreenDimensions()
            dialogParams.width = (point.x * 0.92f).toInt().coerceIn(dpToPx(300), dpToPx(520))

            if (!isDialogAttached) {
                windowManager.addView(dialogView, dialogParams)
                isDialogAttached = true
            } else {
                windowManager.updateViewLayout(dialogView, dialogParams)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error adding or updating dialog view: ${e.message}")
        }
    }

    private fun hideDialogView() {
        if (isDialogAttached && dialogView != null) {
            try {
                windowManager.removeView(dialogView)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing dialog view: ${e.message}")
            }
            isDialogAttached = false
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun cleanUpMediaProjection() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
            mediaProjectionCallback?.let { mediaProjection?.unregisterCallback(it) }
            mediaProjection?.stop()
            mediaProjection = null
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning up projection: ${e.message}")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        serviceScope.cancel()

        cleanUpMediaProjection()
        TranslationHelper.shutdownTts()

        if (isBubbleAttached && bubbleView != null) {
            try {
                windowManager.removeView(bubbleView)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing bubble: ${e.message}")
            }
            isBubbleAttached = false
        }

        if (isDialogAttached && dialogView != null) {
            try {
                windowManager.removeView(dialogView)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing dialog: ${e.message}")
            }
            isDialogAttached = false
        }
    }
}
