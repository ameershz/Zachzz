package com.example.core.importer

import com.example.core.modules.AiModule
import com.example.core.modules.SemanticRagModule
import com.example.core.training.ContextInjector
import com.example.data.entity.KnowledgeDocEntity
import com.example.data.entity.TrainingSampleEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

data class BulkImportProgress(
    val isRunning: Boolean = false,
    val operation: String = "Idle",
    val processed: Int = 0,
    val total: Int = 0,
    val percentage: Float = 0f,
    val currentLoss: Float = 0f,
    val throughputPerSec: Float = 0f,
    val statusMessage: String = "Ready",
    val detailLog: List<String> = emptyList()
)

/**
 * High-performance Bulk Dataset & Document Ingestion Engine for NeuralCore.
 * Features:
 * - Streaming JSONL parser (supports prompt/target, input/output, instruction/response)
 * - Robust CSV dataset parser
 * - RAG TXT/MD document ingestion with automated context window chunking and 48D vector embedding
 * - Unsupervised Raw Text Pre-Training Engine for causal next-token optimization
 * - 100% On-device, asynchronous coroutine processing with real-time telemetry
 */
class BulkDatasetImporter(
    private val semanticRagModule: SemanticRagModule,
    private val contextInjector: ContextInjector
) {

    private val _progress = MutableStateFlow(BulkImportProgress())
    val progress: StateFlow<BulkImportProgress> = _progress.asStateFlow()

    @Volatile
    private var isCancelled = false

    fun stop() {
        isCancelled = true
    }

    /**
     * Parses JSONL text lines into supervised (prompt, target) training pairs.
     * Uses resilient regex extraction with JSON fallback to work in all JVM/Android environments.
     */
    fun parseJsonl(content: String): List<Pair<String, String>> {
        val pairs = mutableListOf<Pair<String, String>>()
        val lines = content.lines()

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isEmpty() || !trimmed.startsWith("{")) continue

            var prompt = extractJsonField(trimmed, "prompt")
                .ifEmpty { extractJsonField(trimmed, "input") }
                .ifEmpty { extractJsonField(trimmed, "instruction") }
                .ifEmpty { extractJsonField(trimmed, "query") }
                .ifEmpty { extractJsonField(trimmed, "q") }

            var target = extractJsonField(trimmed, "target")
                .ifEmpty { extractJsonField(trimmed, "output") }
                .ifEmpty { extractJsonField(trimmed, "response") }
                .ifEmpty { extractJsonField(trimmed, "answer") }
                .ifEmpty { extractJsonField(trimmed, "a") }

            if (prompt.isEmpty() || target.isEmpty()) {
                try {
                    val json = JSONObject(trimmed)
                    if (prompt.isEmpty()) {
                        prompt = json.optString("prompt", "").ifEmpty {
                            json.optString("input", "").ifEmpty {
                                json.optString("instruction", "")
                            }
                        }
                    }
                    if (target.isEmpty()) {
                        target = json.optString("target", "").ifEmpty {
                            json.optString("output", "").ifEmpty {
                                json.optString("response", "")
                            }
                        }
                    }
                } catch (_: Throwable) {
                    // Ignore on non-Android test environments
                }
            }

            if (prompt.isNotBlank() && target.isNotBlank()) {
                pairs.add(prompt.trim() to target.trim())
            }
        }
        return pairs
    }

    private fun extractJsonField(jsonStr: String, key: String): String {
        val regex = Regex("\"$key\"\\s*:\\s*\"((?:\\\\.|[^\"\\\\])*)\"")
        val match = regex.find(jsonStr) ?: return ""
        return match.groupValues[1]
            .replace("\\\"", "\"")
            .replace("\\\\", "\\")
            .replace("\\n", "\n")
            .replace("\\t", "\t")
    }

    /**
     * Parses CSV text into (prompt, target) training pairs.
     */
    fun parseCsv(content: String): List<Pair<String, String>> {
        val pairs = mutableListOf<Pair<String, String>>()
        val lines = content.lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return emptyList()

        // Detect header
        var promptCol = 0
        var targetCol = 1
        var startIndex = 0

        val firstLine = lines[0].lowercase()
        if (firstLine.contains("prompt") || firstLine.contains("input") || firstLine.contains("instruction")) {
            startIndex = 1
            val cols = splitCsvLine(firstLine)
            for (i in cols.indices) {
                val c = cols[i].trim()
                if (c == "prompt" || c == "input" || c == "instruction" || c == "q" || c == "query") promptCol = i
                if (c == "target" || c == "output" || c == "response" || c == "a" || c == "answer") targetCol = i
            }
        }

        for (i in startIndex until lines.size) {
            val cols = splitCsvLine(lines[i])
            if (cols.size > max(promptCol, targetCol)) {
                val p = cols[promptCol].trim()
                val t = cols[targetCol].trim()
                if (p.isNotBlank() && t.isNotBlank()) {
                    pairs.add(p to t)
                }
            }
        }
        return pairs
    }

    private fun splitCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = java.lang.StringBuilder()
        var inQuotes = false

        for (ch in line) {
            if (ch == '\"') {
                inQuotes = !inQuotes
            } else if (ch == ',' && !inQuotes) {
                result.add(current.toString().trim('\"', ' '))
                current.clear()
            } else {
                current.append(ch)
            }
        }
        result.add(current.toString().trim('\"', ' '))
        return result
    }

    /**
     * Splits a raw Markdown or Plain-text document into semantically chunked records with embeddings.
     */
    suspend fun ingestDocumentChunks(
        rawTitle: String,
        rawText: String,
        chunkSize: Int = 160,
        overlap: Int = 30,
        onProgressUpdate: (processed: Int, total: Int) -> Unit = { _, _ -> }
    ): List<KnowledgeDocEntity> = withContext(Dispatchers.Default) {
        val chunks = contextInjector.chunkDocument(rawText, chunkSize, overlap)
        val entities = mutableListOf<KnowledgeDocEntity>()
        val total = chunks.size

        for ((idx, chunk) in chunks.withIndex()) {
            if (isCancelled) break
            val embedding = semanticRagModule.computeEmbedding(chunk)
            val chunkTitle = if (chunks.size == 1) rawTitle else "$rawTitle (Part ${idx + 1}/$total)"

            entities.add(
                KnowledgeDocEntity(
                    title = chunkTitle,
                    rawContent = chunk,
                    embeddingVectorStr = embedding.data.joinToString(","),
                    category = if (rawTitle.endsWith(".md", true)) "Markdown" else "Document"
                )
            )
            onProgressUpdate(idx + 1, total)
        }
        entities
    }

    /**
     * Generates unsupervised next-token prediction pairs from raw unstructured text.
     * Takes sliding windows of tokens to train causal sequence prediction.
     */
    fun extractRawTextPretrainPairs(
        rawText: String,
        windowSize: Int = 6,
        stride: Int = 2
    ): List<Pair<String, String>> {
        val pairs = mutableListOf<Pair<String, String>>()
        val paragraphs = rawText.split(Regex("\\n{2,}"))

        for (para in paragraphs) {
            val words = para.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
            if (words.size < 2) continue

            var i = 0
            while (i + 1 < words.size) {
                val inputWords = words.subList(max(0, i - windowSize), i + 1).joinToString(" ")
                val targetEnd = min(words.size, i + 1 + stride)
                val targetWords = words.subList(i + 1, targetEnd).joinToString(" ")

                if (inputWords.isNotBlank() && targetWords.isNotBlank()) {
                    pairs.add(inputWords to targetWords)
                }
                i += stride
            }
        }
        return pairs
    }

    /**
     * Streams fine-tuning pairs into an AI module with live background telemetry.
     */
    suspend fun executeStreamingTraining(
        module: AiModule,
        dataset: List<Pair<String, String>>,
        epochs: Int = 3,
        learningRate: Float = 0.005f,
        batchSize: Int = 16,
        onEpochLoss: (Float) -> Unit = {}
    ): Float = withContext(Dispatchers.Default) {
        if (dataset.isEmpty()) return@withContext 0f
        isCancelled = false

        val startTime = System.currentTimeMillis()
        val totalSteps = epochs * dataset.size
        var stepsCompleted = 0
        var runningLoss = 0.5f

        _progress.value = BulkImportProgress(
            isRunning = true,
            operation = "Supervised Batch Fine-Tuning",
            processed = 0,
            total = totalSteps,
            percentage = 0f,
            currentLoss = runningLoss,
            statusMessage = "Streaming ${dataset.size} pairs across $epochs epochs..."
        )

        for (epoch in 1..epochs) {
            if (isCancelled) break
            var epochLoss = 0f

            for ((prompt, target) in dataset) {
                if (isCancelled) break
                val loss = module.trainStep(prompt, target, learningRate)
                epochLoss += loss
                stepsCompleted++

                if (stepsCompleted % 5 == 0 || stepsCompleted == totalSteps) {
                    val elapsedSec = max(0.1f, (System.currentTimeMillis() - startTime) / 1000f)
                    val tps = stepsCompleted / elapsedSec
                    val pct = (stepsCompleted.toFloat() / totalSteps) * 100f
                    runningLoss = (runningLoss * 0.8f) + (loss * 0.2f)

                    _progress.value = BulkImportProgress(
                        isRunning = true,
                        operation = "Supervised Batch Fine-Tuning",
                        processed = stepsCompleted,
                        total = totalSteps,
                        percentage = pct,
                        currentLoss = runningLoss,
                        throughputPerSec = tps,
                        statusMessage = "Epoch $epoch/$epochs • Step $stepsCompleted/$totalSteps (Loss: ${"%.4f".format(runningLoss)})",
                        detailLog = listOf(
                            "Throughput: ${"%.1f".format(tps)} pairs/sec",
                            "Current sample: \"${prompt.take(30)}...\"",
                            "Learning Rate: $learningRate"
                        )
                    )
                }
            }
            val avg = epochLoss / dataset.size
            onEpochLoss(avg)
        }

        _progress.value = _progress.value.copy(
            isRunning = false,
            statusMessage = if (isCancelled) "Training paused by user" else "Fine-tuning successfully completed! Weights updated."
        )
        runningLoss
    }

    /**
     * Executes unsupervised raw text pre-training on entire document.
     */
    suspend fun executeRawTextPretraining(
        module: AiModule,
        rawText: String,
        epochs: Int = 2,
        learningRate: Float = 0.003f
    ): Float = withContext(Dispatchers.Default) {
        val pairs = extractRawTextPretrainPairs(rawText)
        if (pairs.isEmpty()) return@withContext 0f

        _progress.value = BulkImportProgress(
            isRunning = true,
            operation = "Unsupervised Raw Text Pre-Training",
            processed = 0,
            total = pairs.size * epochs,
            percentage = 0f,
            statusMessage = "Generated ${pairs.size} causal prediction pairs from document..."
        )

        executeStreamingTraining(
            module = module,
            dataset = pairs,
            epochs = epochs,
            learningRate = learningRate
        )
    }

    companion object {
        // Built-in presets for instant testing without external files
        val SAMPLE_JSONL_ARABIC_CONVERSATION = """
{"prompt": "ما هي نواة الذكاء الاصطناعي؟", "target": "نواة الذكاء الاصطناعي هي محرك عصبي محلي يعمل على معالج الهاتف بدون إنترنت."}
{"prompt": "كيف تحافظ على الخصوصية؟", "target": "تبقى جميع المحادثات والبيانات والأوزان مشفرة داخل قاعدة البيانات المحلية ولا تخرج من الجهاز."}
{"prompt": "ما هي ميزة تسريع ARM NEON؟", "target": "تسريع NEON يضاعف سرعة ضرب مصفوفات التنسور باستخدام تعليمات SIMD الموجهة لمعالجات ARM."}
{"prompt": "هل تدعم اللغة العربية وقواعدها؟", "target": "نعم، تم تزويد النظام بمحلل BPE صرفي يحلل السوابق واللواحق وجذور الكلمات بدقة فائقة."}
{"prompt": "كيف يعمل البحث الدلالي الشعاعي؟", "target": "يقوم المحرك بإسقاط النصوص في فضاء شعاعي وحساب تشابه جيب التمام مع عتبة 55% لمنع الهلوسة."}
        """.trimIndent()

        val SAMPLE_CSV_TECHNICAL_PAIRS = """
prompt,target
"what is local inference","Executing neural network tensor graphs directly on client device CPU without network latency"
"how does repetition penalty work","Applies exponential logit scaling to suppress duplicate n-grams and infinite generation loops"
"what is vector similarity threshold","A strict mathematical filter requiring at least 0.55 cosine similarity before context injection"
"explain SIMD matrix multiplication","Processing multiple 32-bit floating point calculations in parallel using ARM NEON vector lanes"
        """.trimIndent()

        val SAMPLE_RAG_MARKDOWN_GUIDE = """
# NeuralCore On-Device Architecture Manual

## Overview
NeuralCore is an autonomous on-device neural intelligence platform designed for Android devices. It requires zero cloud APIs, zero remote servers, and zero internet connection to execute inference, train weights, and retrieve semantic memories.

## Morphological BPE Tokenizer
The system integrates an advanced Arabic and Multilingual Byte-Pair Encoding (BPE) subword tokenizer. It segments clitics, affixes, and morphological roots, preventing out-of-vocabulary anomalies and preserving grammatical integrity.

## Strict RAG Cosine Threshold (55%)
Unlike generic retrieval architectures that pollute context with low-confidence documents, NeuralCore enforces a strict 0.55 (55%) Cosine Similarity cutoff. If a document does not exceed this similarity threshold, it is automatically blocked from injection to maintain factual reliability.

## ARM NEON SIMD Matrix Acceleration
Tensor dot-products and dense linear projections are accelerated via 128-bit ARM NEON vector registers. The inner loop unrolls 8 floats per iteration, yielding exceptional throughput on modern mobile silicon.
        """.trimIndent()

        val SAMPLE_RAW_TEXT_CORPUS = """
تعمل الشبكات العصبية على معالجة البيانات المعقدة من خلال محاكاة الاتصالات المشبكية في الدماغ البشري. في الأجهزة الذكية الحديثة، يمثل تشغيل الذكاء الاصطناعي محلياً بالكامل خطوة ثورية نحو الخصوصية المطلقة وكفاءة استهلاك الطاقة وسرعة الاستجابة اللحظية. بفضل تسريع التعليمات الموجهة ومعالجات التنسور، بات بإمكان الهواتف الذكية تدريب النماذج اللغوية وإجراء التضمين الشعاعي بدون الحاجة إلى خوادم سحابية.
        """.trimIndent()
    }
}
