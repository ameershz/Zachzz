package com.example.core.tensor

import java.util.Locale

/**
 * On-device Tokenizer with dynamic vocabulary growth, full Unicode and Arabic support,
 * Tashkeel normalization, and bidirectional language handling.
 */
class Tokenizer(initialVocabSize: Int = 1000) {

    companion object {
        const val PAD_TOKEN = "<pad>"
        const val UNK_TOKEN = "<unk>"
        const val BOS_TOKEN = "<bos>"
        const val EOS_TOKEN = "<eos>"
        const val SYS_TOKEN = "<sys>"
        const val CTX_TOKEN = "<ctx>"
        const val USER_TOKEN = "<user>"
        const val BOT_TOKEN = "<assistant>"

        const val PAD_ID = 0
        const val UNK_ID = 1
        const val BOS_ID = 2
        const val EOS_ID = 3
        const val SYS_ID = 4
        const val CTX_ID = 5
        const val USER_ID = 6
        const val BOT_ID = 7

        /**
         * Checks if a string contains Arabic characters.
         */
        fun isArabic(text: String): Boolean {
            return text.any {
                it in '\u0600'..'\u06FF' || // Arabic
                it in '\u0750'..'\u077F' || // Arabic Supplement
                it in '\u08A0'..'\u08FF' || // Arabic Extended-A
                it in '\uFB50'..'\uFDFF' || // Arabic Presentation Forms-A
                it in '\uFE70'..'\uFEFF'    // Arabic Presentation Forms-B
            }
        }

        /**
         * Normalizes Arabic text by stripping diacritics (Tashkeel) and Tatweel while preserving character forms.
         */
        fun normalizeArabic(text: String): String {
            return text
                // Remove Tashkeel (harakat: fatha, damma, kasra, sukun, shadda, tanween) and Tatweel
                .replace(Regex("[\u064B-\u0652\u0670\u0640]"), "")
                .trim()
        }
    }

    private val tokenToId = mutableMapOf<String, Int>()
    private val idToToken = mutableMapOf<Int, String>()
    private var nextId = 0

    init {
        // Register special tokens
        registerToken(PAD_TOKEN, PAD_ID)
        registerToken(UNK_TOKEN, UNK_ID)
        registerToken(BOS_TOKEN, BOS_ID)
        registerToken(EOS_TOKEN, EOS_ID)
        registerToken(SYS_TOKEN, SYS_ID)
        registerToken(CTX_TOKEN, CTX_ID)
        registerToken(USER_TOKEN, USER_ID)
        registerToken(BOT_TOKEN, BOT_ID)
        nextId = 8

        // Seed core English vocabulary
        val coreEnglishWords = listOf(
            "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not", "on", "with",
            "he", "as", "you", "do", "at", "this", "but", "his", "by", "from", "they", "we", "say", "her", "she",
            "or", "an", "will", "my", "one", "all", "would", "there", "their", "what", "so", "up", "out", "if",
            "about", "who", "get", "which", "go", "me", "when", "make", "can", "like", "time", "no", "just",
            "him", "know", "take", "people", "into", "year", "your", "good", "some", "could", "them", "see",
            "other", "than", "then", "now", "look", "only", "come", "its", "over", "think", "also", "back",
            "after", "use", "two", "how", "our", "work", "first", "well", "way", "even", "new", "want", "because",
            "any", "these", "give", "day", "most", "us", "ai", "core", "neural", "tensor", "model", "network",
            "local", "offline", "data", "train", "weights", "inference", "memory", "learning", "compute", "system",
            "device", "android", "vector", "layer", "attention", "transformer", "reasoning", "knowledge", "status",
            "activate", "process", "analysis", "query", "response", "latency", "accuracy", "loss", "optimizer",
            "gradient", "checkpoint", "engine", "scale", "performance", "cpu", "gpu", "token", "context", "history",
            "save", "load", "execute", "hello", "hi", "help", "explain", "why", "how", "is", "are", "code", "logic",
            "yes", "no", "true", "false", "verified", "optimal", "fast", "secure", "private", "architecture",
            "fine-tuning", "parameter", "embedding", "dot", "matmul", "backprop", "linear", "relu", "softmax", "epoch"
        )
        for (w in coreEnglishWords) {
            addWordIfAbsent(w)
        }

        // Seed foundational Arabic vocabulary for on-device NLP
        val coreArabicWords = listOf(
            "الذكاء", "الاصطناعي", "النواة", "المحلي", "البيانات", "التدريب", "النموذج", "الشبكة", "العصبية",
            "النظام", "الجهاز", "الذاكرة", "الحالة", "السرعة", "الأداء", "الاستعلام", "النتيجة", "مرحبا",
            "أهلا", "نعم", "لا", "صحيح", "خطأ", "آمن", "خاص", "معالجة", "تنسور", "أوزان", "تحليل", "استنتاج",
            "تعلم", "تحديث", "ملف", "حفظ", "محليا", "بدون", "إنترنت", "كفاءة", "طاقة", "بطارية", "مشفر",
            "تضمين", "شعاعي", "مصفوفة", "طبقة", "انتباه", "تحسين", "عالي", "ممتاز", "يعمل", "بشكل", "مثالي",
            "كيف", "ماذا", "هل", "لماذا", "أين", "من", "هذا", "هذه", "في", "على", "من", "إلى", "عن", "مع",
            "كل", "بعض", "هو", "هي", "نحن", "أنت", "كان", "يكون", "تطوير", "سرعة", "دقة", "استجابة", "زمن",
            "أمان", "خصوصية", "هاتف", "أندرويد", "معالج", "تدرج", "خسارة", "تحسينات", "خطوات", "مستوى"
        )
        for (w in coreArabicWords) {
            addWordIfAbsent(w)
        }
    }

    val vocabSize: Int get() = nextId

    private fun registerToken(token: String, id: Int) {
        tokenToId[token] = id
        idToToken[id] = token
    }

    @Synchronized
    fun addWordIfAbsent(word: String): Int {
        val clean = cleanWord(word)
        if (clean.isEmpty()) return PAD_ID
        return tokenToId.getOrPut(clean) {
            val assigned = nextId++
            idToToken[assigned] = clean
            assigned
        }
    }

    private fun cleanWord(word: String): String {
        return if (isArabic(word)) {
            normalizeArabic(word).trim()
        } else {
            word.lowercase(Locale.ROOT).trim()
        }
    }

    /**
     * Tokenizes an input string into token IDs.
     * Supports full Unicode characters (Arabic, Latin, digits) without discarding Arabic words.
     * Unseen words are automatically dynamically added to the vocabulary to prevent <unk> loss.
     */
    fun encode(text: String, addBos: Boolean = false, addEos: Boolean = false, autoLearn: Boolean = true): IntArray {
        // Regex preserves any Unicode letter (\p{L}), Unicode digit (\p{N}), plus special token symbols
        val rawWords = text
            .replace(Regex("[^\\p{L}\\p{N}<>/_\\-]"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }

        val list = mutableListOf<Int>()
        if (addBos) list.add(BOS_ID)

        for (w in rawWords) {
            val clean = cleanWord(w)
            if (clean.isEmpty()) continue

            val id = if (autoLearn) {
                addWordIfAbsent(clean)
            } else {
                tokenToId[clean] ?: UNK_ID
            }
            list.add(id)
        }

        if (addEos) list.add(EOS_ID)
        return list.toIntArray()
    }

    /**
     * Decodes token IDs back into readable natural text with proper Arabic spacing.
     */
    fun decode(tokenIds: IntArray): String {
        val sb = StringBuilder()
        for (id in tokenIds) {
            if (id == PAD_ID || id == BOS_ID || id == EOS_ID) continue
            val token = idToToken[id] ?: "[tok_$id]"
            if (sb.isNotEmpty()) sb.append(" ")
            sb.append(token)
        }
        return sb.toString()
    }

    fun getTokenName(id: Int): String = idToToken[id] ?: "<unk>"

    fun getVocabularySnapshot(): Map<Int, String> = idToToken.toMap()
}
