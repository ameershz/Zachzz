package com.example.core.training

import com.example.core.modules.AiModule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class TrainingProgress(
    val isRunning: Boolean = false,
    val currentEpoch: Int = 0,
    val totalEpochs: Int = 0,
    val currentLoss: Float = 0f,
    val lossHistory: List<Float> = emptyList(),
    val statusMessage: String = "Idle",
    val deltaWeights: Float = 0f
)

/**
 * On-device Trainer & Fine-Tuner running purely in Kotlin coroutines.
 * Enables live supervised gradient updates, loss tracking, and parameter adaptation without cloud.
 */
class LocalFineTuner {

    private val _progress = MutableStateFlow(TrainingProgress())
    val progress: StateFlow<TrainingProgress> = _progress.asStateFlow()

    @Volatile
    private var isCancelled: Boolean = false

    suspend fun train(
        module: AiModule,
        dataset: List<Pair<String, String>>,
        epochs: Int = 5,
        learningRate: Float = 0.01f,
        onEpochEnd: (epoch: Int, loss: Float) -> Unit = { _, _ -> }
    ): List<Float> = withContext(Dispatchers.Default) {
        if (dataset.isEmpty()) return@withContext emptyList()

        isCancelled = false
        val lossHistory = mutableListOf<Float>()

        _progress.value = TrainingProgress(
            isRunning = true,
            currentEpoch = 0,
            totalEpochs = epochs,
            currentLoss = 0.5f,
            lossHistory = emptyList(),
            statusMessage = "Initializing on-device gradient descent for ${module.type.title}..."
        )

        val statsBefore = module.getStats()

        for (epoch in 1..epochs) {
            if (isCancelled) {
                _progress.value = _progress.value.copy(
                    isRunning = false,
                    statusMessage = "Training interrupted by user."
                )
                break
            }

            var epochLossSum = 0f
            for ((input, target) in dataset) {
                if (isCancelled) break
                val stepLoss = module.trainStep(input, target, learningRate)
                epochLossSum += stepLoss
            }

            val avgEpochLoss = epochLossSum / dataset.size
            lossHistory.add(avgEpochLoss)

            val statsNow = module.getStats()
            val weightDelta = kotlin.math.abs(statsNow.meanWeightValue - statsBefore.meanWeightValue)

            _progress.value = TrainingProgress(
                isRunning = true,
                currentEpoch = epoch,
                totalEpochs = epochs,
                currentLoss = avgEpochLoss,
                lossHistory = lossHistory.toList(),
                statusMessage = "Epoch $epoch/$epochs completed (Loss: ${"%.4f".format(avgEpochLoss)})",
                deltaWeights = weightDelta
            )

            onEpochEnd(epoch, avgEpochLoss)
        }

        _progress.value = _progress.value.copy(
            isRunning = false,
            statusMessage = "Training completed! Model weights updated on device."
        )

        lossHistory
    }

    fun stop() {
        isCancelled = true
    }
}
