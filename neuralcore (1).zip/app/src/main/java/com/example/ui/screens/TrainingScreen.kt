package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.modules.ModuleType
import com.example.core.tensor.Tokenizer
import com.example.core.training.TrainingProgress
import com.example.data.entity.TrainingSampleEntity
import com.example.ui.NeuralCoreViewModel
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.AutoStories
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BulkImportProgressBar
import com.example.ui.components.BulkImporterModalDialog
import com.example.ui.components.BulkImportTargetMode
import com.example.ui.components.LossChart
import com.example.ui.components.NeuralHeader
import com.example.ui.components.StatChip
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeuralViolet
import com.example.ui.theme.PulseAmber
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun TrainingScreen(
    viewModel: NeuralCoreViewModel,
    activeType: ModuleType,
    progress: TrainingProgress,
    samples: List<TrainingSampleEntity>,
    modifier: Modifier = Modifier
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var inputPrompt by remember { mutableStateOf("") }
    var targetOutput by remember { mutableStateOf("") }
    var targetEpochsSlider by remember { mutableFloatStateOf(viewModel.targetEpochs.toFloat()) }

    val bulkProgress by viewModel.bulkImportProgress.collectAsStateWithLifecycle()
    var showBulkDialog by remember { mutableStateOf(false) }
    var bulkTargetMode by remember { mutableStateOf(BulkImportTargetMode.TRAINING_DATASET) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
    ) {
        NeuralHeader(activeModuleName = "Local Fine-Tuning & Gradient Core")

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (bulkProgress.isRunning) {
                item {
                    BulkImportProgressBar(
                        progress = bulkProgress,
                        onStopClick = { viewModel.stopBulkOperation() }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Training Console Panel
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SurfaceCard)
                        .border(1.dp, if (progress.isRunning) CyberCyan else SurfaceBorder, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(if (progress.isRunning) CyberCyan.copy(alpha = 0.2f) else SurfaceElevated),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FitnessCenter,
                                        contentDescription = null,
                                        tint = if (progress.isRunning) CyberCyan else TextTertiary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (progress.isRunning) "TRAINING IN PROGRESS" else "TRAINING ENGINE IDLE",
                                        color = if (progress.isRunning) CyberCyan else TextPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = "${activeType.title} • Adam Optimizer",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            if (progress.isRunning) {
                                CircularProgressIndicator(
                                    color = CyberCyan,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Progress bar if running
                        if (progress.isRunning && progress.totalEpochs > 0) {
                            val progressFloat = progress.currentEpoch.toFloat() / progress.totalEpochs
                            LinearProgressIndicator(
                                progress = { progressFloat },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = CyberCyan,
                                trackColor = SurfaceElevated
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        Text(
                            text = progress.statusMessage,
                            color = if (progress.isRunning) TextPrimary else TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatChip(label = "EPOCH", value = "${progress.currentEpoch}/${progress.totalEpochs.coerceAtLeast(viewModel.targetEpochs)}")
                            StatChip(label = "LOSS", value = "%.4f".format(progress.currentLoss), color = NeonEmerald)
                            StatChip(label = "Δ WEIGHTS", value = "%.5f".format(progress.deltaWeights), color = NeuralViolet)
                        }
                    }
                }
            }

            // Real-Time Loss Canvas Chart
            item {
                Text(
                    text = "ON-DEVICE LOSS CURVE (REAL-TIME CONVERGENCE)",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                LossChart(lossHistory = progress.lossHistory)
            }

            // Training Epochs & Action Controls
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Target Training Epochs", color = TextSecondary, fontSize = 11.sp)
                            Text(text = "${targetEpochsSlider.toInt()}", color = CyberCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        Slider(
                            value = targetEpochsSlider,
                            onValueChange = {
                                targetEpochsSlider = it
                                viewModel.targetEpochs = it.toInt()
                            },
                            valueRange = 1f..20f,
                            steps = 19,
                            colors = SliderDefaults.colors(
                                thumbColor = CyberCyan,
                                activeTrackColor = CyberCyan,
                                inactiveTrackColor = SurfaceElevated
                            ),
                            enabled = !progress.isRunning
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.startTraining() },
                                enabled = !progress.isRunning && samples.isNotEmpty(),
                                modifier = Modifier.weight(1f).testTag("start_training_button"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = SurfaceDark)
                            ) {
                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Start Training", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            if (progress.isRunning) {
                                Button(
                                    onClick = { viewModel.stopTraining() },
                                    modifier = Modifier.weight(1f).testTag("stop_training_button"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = ErrorCrimson)
                                ) {
                                    Icon(imageVector = Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "Stop", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Training Dataset Manager
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "TRAINING SAMPLES (${samples.size})",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = {
                                bulkTargetMode = BulkImportTargetMode.TRAINING_DATASET
                                showBulkDialog = true
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.15f), contentColor = CyberCyan),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("bulk_import_dataset_button")
                        ) {
                            Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "Import (JSONL/CSV)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                bulkTargetMode = BulkImportTargetMode.RAW_PRETRAIN
                                showBulkDialog = true
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NeuralViolet.copy(alpha = 0.15f), contentColor = NeuralViolet),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("raw_text_pretrain_button")
                        ) {
                            Icon(imageVector = Icons.Default.AutoStories, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "Pre-Train Raw", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showAddDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated, contentColor = CyberCyan),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("add_sample_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "Add", fontSize = 10.sp)
                        }
                    }
                }
            }

            if (samples.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(SurfaceCard)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No training samples for ${activeType.badge}. Click 'Add Sample' above.",
                            color = TextTertiary,
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                items(samples, key = { it.id }) { sample ->
                    val isInputAr = Tokenizer.isArabic(sample.inputPrompt)
                    val isOutputAr = Tokenizer.isArabic(sample.targetOutput)
                    val isSampleAr = isInputAr || isOutputAr

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        CompositionLocalProvider(
                            LocalLayoutDirection provides if (isSampleAr) LayoutDirection.Rtl else LayoutDirection.Ltr
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isInputAr) "الدخل: \"${sample.inputPrompt}\"" else "IN:  \"${sample.inputPrompt}\"",
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        fontFamily = if (isInputAr) FontFamily.Default else FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = if (isInputAr) TextAlign.Right else TextAlign.Left
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (isOutputAr) "الهدف: \"${sample.targetOutput}\"" else "OUT: \"${sample.targetOutput}\"",
                                        color = CyberCyan,
                                        fontSize = 11.sp,
                                        fontFamily = if (isOutputAr) FontFamily.Default else FontFamily.Monospace,
                                        textAlign = if (isOutputAr) TextAlign.Right else TextAlign.Left
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.deleteTrainingSample(sample.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete sample",
                                        tint = TextTertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Add Training Sample Dialog (Bilingual RTL Support)
    if (showAddDialog) {
        val isInputAr = Tokenizer.isArabic(inputPrompt)
        val isTargetAr = Tokenizer.isArabic(targetOutput)

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = {
                Text(
                    text = "Add Fine-Tuning Pair / إضافة عينة تدريب",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = "Enter input prompt and target completion for supervised on-device learning (English or Arabic).\nأدخل الاستعلام والناتج المستهدف للتدريب الإشرافي.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    CompositionLocalProvider(
                        LocalLayoutDirection provides if (isInputAr) LayoutDirection.Rtl else LayoutDirection.Ltr
                    ) {
                        OutlinedTextField(
                            value = inputPrompt,
                            onValueChange = { inputPrompt = it },
                            placeholder = { Text("Input prompt / استعلام الدخل", color = TextTertiary, fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = SurfaceBorder
                            ),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                textAlign = if (isInputAr) TextAlign.Right else TextAlign.Left
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    CompositionLocalProvider(
                        LocalLayoutDirection provides if (isTargetAr) LayoutDirection.Rtl else LayoutDirection.Ltr
                    ) {
                        OutlinedTextField(
                            value = targetOutput,
                            onValueChange = { targetOutput = it },
                            placeholder = { Text("Target output / الناتج المستهدف", color = TextTertiary, fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = SurfaceBorder
                            ),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                textAlign = if (isTargetAr) TextAlign.Right else TextAlign.Left
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addTrainingSample(inputPrompt, targetOutput)
                        inputPrompt = ""
                        targetOutput = ""
                        showAddDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = SurfaceDark)
                ) {
                    Text("Save Pair / حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel / إلغاء", color = TextSecondary)
                }
            },
            containerColor = SurfaceElevated
        )
    }

    BulkImporterModalDialog(
        isOpen = showBulkDialog,
        onDismiss = { showBulkDialog = false },
        targetMode = bulkTargetMode,
        onImportFile = { uri ->
            if (bulkTargetMode == BulkImportTargetMode.RAW_PRETRAIN) {
                viewModel.startRawTextPretraining(uri)
            } else {
                viewModel.importFineTuningDataset(uri)
            }
        },
        onImportContent = { _, content, format ->
            viewModel.importFineTuningContent(content, format)
        },
        onPretrainRawText = { text ->
            viewModel.startRawTextPretrainingContent(text)
        }
    )
}
