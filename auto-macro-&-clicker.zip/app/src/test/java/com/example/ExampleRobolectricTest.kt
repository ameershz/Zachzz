package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.GestureType
import com.example.model.Macro
import com.example.model.MacroAction
import com.example.model.TouchPoint
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Auto Macro & Clicker", appName)
    }

    @Test
    fun `macro serialization and deserialization works correctly`() {
        val actions = listOf(
            MacroAction.createTap(x = 100f, y = 200f, delayBeforeMs = 150L, durationMs = 50L),
            MacroAction.createSwipe(
                points = listOf(TouchPoint(100f, 200f), TouchPoint(100f, 600f)),
                durationMs = 350L,
                delayBeforeMs = 100L
            )
        )
        val macro = Macro(
            name = "Test Macro",
            actions = actions,
            repeatCount = 3,
            playbackSpeed = 1.5f
        )

        val serialized = macro.serializeActions()
        val deserialized = Macro.deserializeActions(serialized)

        assertEquals(2, deserialized.size)
        assertEquals(GestureType.TAP, deserialized[0].type)
        assertEquals(100f, deserialized[0].startX, 0.01f)
        assertEquals(200f, deserialized[0].startY, 0.01f)
        assertEquals(GestureType.SWIPE, deserialized[1].type)
        assertEquals(600f, deserialized[1].endY, 0.01f)
    }
}
