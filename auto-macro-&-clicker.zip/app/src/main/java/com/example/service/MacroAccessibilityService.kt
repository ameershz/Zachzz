package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.os.Build
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.example.model.GestureType
import com.example.model.Macro
import com.example.model.MacroAction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

sealed interface PlaybackState {
    object Idle : PlaybackState
    data class Playing(
        val macroName: String,
        val currentActionIndex: Int,
        val totalActions: Int,
        val currentLoop: Int,
        val totalLoops: Int
    ) : PlaybackState
    data class Completed(val macroName: String) : PlaybackState
    data class Error(val message: String) : PlaybackState
}

class MacroAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var currentPlaybackJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceActive.value = true
        Log.d(TAG, "MacroAccessibilityService connected successfully")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used for pure gesture dispatching
    }

    override fun onInterrupt() {
        Log.w(TAG, "MacroAccessibilityService interrupted")
        stopPlayback()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPlayback()
        serviceScope.cancel()
        instance = null
        _isServiceActive.value = false
        Log.d(TAG, "MacroAccessibilityService destroyed")
    }

    /**
     * Executes the macro actions using GestureDescription.
     * Supports speed multiplier and loops.
     */
    fun playMacro(
        macro: Macro,
        onLoopFinished: ((loop: Int) -> Unit)? = null,
        onFinished: (() -> Unit)? = null
    ) {
        stopPlayback()

        if (macro.actions.isEmpty()) {
            _playbackState.value = PlaybackState.Error("Macro has no actions to replay")
            return
        }

        currentPlaybackJob = serviceScope.launch {
            try {
                val speed = if (macro.playbackSpeed > 0f) macro.playbackSpeed else 1.0f
                val totalLoops = macro.repeatCount // 0 means infinite
                var currentLoop = 1

                while (totalLoops == 0 || currentLoop <= totalLoops) {
                    val totalActions = macro.actions.size

                    for (index in macro.actions.indices) {
                        val action = macro.actions[index]

                        _playbackState.value = PlaybackState.Playing(
                            macroName = macro.name,
                            currentActionIndex = index + 1,
                            totalActions = totalActions,
                            currentLoop = currentLoop,
                            totalLoops = totalLoops
                        )

                        // Wait for pre-action delay adjusted by speed
                        val preDelay = (action.delayBeforeMs / speed).toLong()
                        if (preDelay > 0) {
                            delay(preDelay)
                        }

                        // Dispatch the gesture
                        val gesture = buildGesture(action, speed)
                        if (gesture != null) {
                            val success = dispatchGestureAsync(gesture)
                            if (!success) {
                                Log.w(TAG, "Gesture at index $index could not be completed")
                            }
                        }
                    }

                    onLoopFinished?.invoke(currentLoop)

                    if (totalLoops != 0 && currentLoop >= totalLoops) {
                        break
                    }

                    currentLoop++

                    // Wait between loops
                    val loopInterval = (macro.loopIntervalMs / speed).toLong()
                    if (loopInterval > 0) {
                        delay(loopInterval)
                    }
                }

                _playbackState.value = PlaybackState.Completed(macro.name)
                onFinished?.invoke()
            } catch (e: Exception) {
                Log.e(TAG, "Error during macro playback", e)
                _playbackState.value = PlaybackState.Error("Playback error: ${e.message}")
            } finally {
                delay(1200)
                if (_playbackState.value is PlaybackState.Completed || _playbackState.value is PlaybackState.Error) {
                    _playbackState.value = PlaybackState.Idle
                }
            }
        }
    }

    /**
     * Instantly triggers a single tap at (x, y)
     */
    fun performSingleTap(x: Float, y: Float, durationMs: Long = 50L, callback: ((Boolean) -> Unit)? = null) {
        serviceScope.launch {
            val path = Path().apply {
                moveTo(x, y)
                lineTo(x + 0.5f, y + 0.5f)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(10L))
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val result = dispatchGestureAsync(gesture)
            callback?.invoke(result)
        }
    }

    fun stopPlayback() {
        currentPlaybackJob?.cancel()
        currentPlaybackJob = null
        if (_playbackState.value !is PlaybackState.Idle) {
            _playbackState.value = PlaybackState.Idle
        }
    }

    private fun buildGesture(action: MacroAction, speed: Float): GestureDescription? {
        val duration = (action.durationMs / speed).toLong().coerceAtLeast(15L)
        val path = Path()

        when (action.type) {
            GestureType.TAP, GestureType.TARGET_PIN -> {
                path.moveTo(action.startX, action.startY)
                path.lineTo(action.startX + 0.5f, action.startY + 0.5f)
            }
            GestureType.LONG_PRESS -> {
                path.moveTo(action.startX, action.startY)
                path.lineTo(action.startX + 0.5f, action.startY + 0.5f)
            }
            GestureType.SWIPE -> {
                val pts = action.points
                if (pts.isEmpty()) return null
                path.moveTo(pts[0].x, pts[0].y)
                if (pts.size == 1) {
                    path.lineTo(pts[0].x + 0.5f, pts[0].y + 0.5f)
                } else {
                    for (i in 1 until pts.size) {
                        path.lineTo(pts[i].x, pts[i].y)
                    }
                }
            }
        }

        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        return GestureDescription.Builder().addStroke(stroke).build()
    }

    private suspend fun dispatchGestureAsync(gesture: GestureDescription): Boolean {
        return suspendCancellableCoroutine { continuation ->
            val callback = object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (continuation.isActive) continuation.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (continuation.isActive) continuation.resume(false)
                }
            }
            val dispatched = dispatchGesture(gesture, callback, null)
            if (!dispatched && continuation.isActive) {
                continuation.resume(false)
            }
        }
    }

    companion object {
        private const val TAG = "MacroAccessibility"

        @Volatile
        var instance: MacroAccessibilityService? = null
            private set

        private val _isServiceActive = MutableStateFlow(false)
        val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

        private val _playbackState = MutableStateFlow<PlaybackState>(PlaybackState.Idle)
        val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

        fun isAccessibilitySettingsEnabled(context: Context): Boolean {
            val expectedServiceName = "${context.packageName}/${MacroAccessibilityService::class.java.canonicalName}"
            val enabledServicesSetting = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val colonSplitter = TextUtils.SimpleStringSplitter(':')
            colonSplitter.setString(enabledServicesSetting)

            while (colonSplitter.hasNext()) {
                val componentNameString = colonSplitter.next()
                if (componentNameString.equals(expectedServiceName, ignoreCase = true) ||
                    componentNameString.contains(MacroAccessibilityService::class.java.simpleName)
                ) {
                    return true
                }
            }
            return false
        }
    }
}
