package com.example.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.MacroApp
import com.example.R
import com.example.model.GestureType
import com.example.model.Macro
import com.example.model.MacroAction
import com.example.model.TouchPoint
import com.example.overlay.FloatingControlView
import com.example.overlay.RecordingCanvasView
import com.example.overlay.TargetPinView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FloatingControlService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var windowManager: WindowManager

    private var floatingControlView: FloatingControlView? = null
    private var recordingCanvasView: RecordingCanvasView? = null
    private val activeTargetPins = mutableListOf<TargetPinView>()

    private val recordedActions = mutableListOf<MacroAction>()
    private var isRecording = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startInForeground()
        setupFloatingPanel()
        observePlaybackState()
        _isOverlayRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            if (it.hasExtra(EXTRA_LOAD_MACRO_ID)) {
                val macroId = it.getLongExtra(EXTRA_LOAD_MACRO_ID, -1L)
                if (macroId > 0) {
                    loadMacroForPlayback(macroId)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val notificationIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            notificationIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, MacroApp.CHANNEL_ID)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun setupFloatingPanel() {
        if (!Settings.canDrawOverlays(this)) {
            Log.e(TAG, "Cannot draw overlays! Permission missing.")
            stopSelf()
            return
        }

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 220
        }

        floatingControlView = FloatingControlView(
            context = this,
            windowManager = windowManager,
            layoutParams = layoutParams,
            onRecordClicked = { startRecording() },
            onStopClicked = { stopRecordingOrPlayback() },
            onPlayClicked = { startPlayback() },
            onAddPinClicked = { addTargetPin() },
            onClearClicked = { clearRecordedActions() },
            onCloseClicked = { stopSelf() }
        )

        windowManager.addView(floatingControlView, layoutParams)
    }

    /**
     * Mounts the full-screen transparent recording canvas overlay
     */
    private fun startRecording() {
        if (isRecording) return

        if (recordingCanvasView == null) {
            val canvasParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )

            recordingCanvasView = RecordingCanvasView(this) { action ->
                recordedActions.add(action)
                _activeRecordedActions.value = recordedActions.toList()
                floatingControlView?.setRecordingState(true, recordedActions.size)
            }

            try {
                windowManager.addView(recordingCanvasView, canvasParams)
                // Bring floating control to front so user can easily tap Stop
                floatingControlView?.let { panel ->
                    windowManager.removeView(panel)
                    windowManager.addView(panel, panel.layoutParams)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error adding recording canvas overlay", e)
            }
        }

        isRecording = true
        recordedActions.clear()
        _activeRecordedActions.value = emptyList()
        recordingCanvasView?.resetTimeline()
        floatingControlView?.setRecordingState(true, 0)
        Toast.makeText(this, "Recording started! Tap or swipe anywhere on screen.", Toast.LENGTH_SHORT).show()
    }

    /**
     * Stops active recording or active playback
     */
    private fun stopRecordingOrPlayback() {
        if (isRecording) {
            isRecording = false
            recordingCanvasView?.let {
                try {
                    windowManager.removeView(it)
                } catch (e: Exception) {
                    Log.w(TAG, "Error removing recording canvas", e)
                }
            }
            recordingCanvasView = null
            floatingControlView?.setRecordingState(false, recordedActions.size)
            _activeRecordedActions.value = recordedActions.toList()

            Toast.makeText(
                this,
                "Recording stopped! ${recordedActions.size} actions recorded. Tap Play to replay.",
                Toast.LENGTH_LONG
            ).show()

            // If actions were recorded, save temporary session so MainActivity can import
            if (recordedActions.isNotEmpty()) {
                val tempMacro = Macro(
                    name = "Recorded Macro #${System.currentTimeMillis() % 10000}",
                    actions = recordedActions.toList(),
                    repeatCount = floatingControlView?.repeatCount ?: 1,
                    playbackSpeed = floatingControlView?.playbackSpeed ?: 1.0f
                )
                _lastRecordedMacro.value = tempMacro
            }
            return
        }

        // If not recording, stop playback
        MacroAccessibilityService.instance?.stopPlayback()
        floatingControlView?.setPlayingState(false)
    }

    /**
     * Dispatches playback of recorded actions or target pins via AccessibilityService
     */
    private fun startPlayback() {
        val service = MacroAccessibilityService.instance
        if (service == null) {
            Toast.makeText(
                this,
                "Accessibility Service is not enabled! Enable it in Settings to allow auto-clicks.",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)
            return
        }

        val macroToPlay: Macro = when {
            // Case 1: Active target pins placed on screen
            activeTargetPins.isNotEmpty() -> {
                val pinActions = activeTargetPins.mapIndexed { idx, pin ->
                    MacroAction.createTap(
                        x = pin.targetCenterScreenX,
                        y = pin.targetCenterScreenY,
                        delayBeforeMs = if (idx == 0) 100L else 250L,
                        durationMs = 50L
                    )
                }
                Macro(
                    name = "Target Pins Auto-Click",
                    actions = pinActions,
                    repeatCount = floatingControlView?.repeatCount ?: 1,
                    playbackSpeed = floatingControlView?.playbackSpeed ?: 1.0f
                )
            }
            // Case 2: Actions recorded in this session
            recordedActions.isNotEmpty() -> {
                Macro(
                    name = "Recorded Macro",
                    actions = recordedActions.toList(),
                    repeatCount = floatingControlView?.repeatCount ?: 1,
                    playbackSpeed = floatingControlView?.playbackSpeed ?: 1.0f
                )
            }
            // Case 3: Last saved/loaded macro
            _lastRecordedMacro.value != null -> {
                _lastRecordedMacro.value!!.copy(
                    repeatCount = floatingControlView?.repeatCount ?: 1,
                    playbackSpeed = floatingControlView?.playbackSpeed ?: 1.0f
                )
            }
            else -> {
                Toast.makeText(
                    this,
                    "No actions recorded! Press '● Record' or '+Pin' to create actions first.",
                    Toast.LENGTH_SHORT
                ).show()
                return
            }
        }

        floatingControlView?.setPlayingState(true, "Starting...")
        service.playMacro(
            macro = macroToPlay,
            onFinished = {
                serviceScope.launch {
                    floatingControlView?.setPlayingState(false)
                }
            }
        )
    }

    private fun addTargetPin() {
        val newIndex = activeTargetPins.size + 1
        val pinParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 200 + (newIndex * 80) % 500
            y = 400 + (newIndex * 80) % 600
        }

        val pinView = TargetPinView(
            context = this,
            index = newIndex,
            windowManager = windowManager,
            layoutParams = pinParams,
            onPinRemoved = { removedPin ->
                removeTargetPin(removedPin)
            }
        )

        try {
            windowManager.addView(pinView, pinParams)
            activeTargetPins.add(pinView)
            floatingControlView?.setStatusText("${activeTargetPins.size} pins active")
        } catch (e: Exception) {
            Log.e(TAG, "Error adding target pin", e)
        }
    }

    private fun removeTargetPin(pin: TargetPinView) {
        try {
            windowManager.removeView(pin)
            activeTargetPins.remove(pin)
            floatingControlView?.setStatusText(
                if (activeTargetPins.isEmpty()) "Ready" else "${activeTargetPins.size} pins active"
            )
        } catch (e: Exception) {
            Log.w(TAG, "Error removing target pin", e)
        }
    }

    private fun clearRecordedActions() {
        recordedActions.clear()
        _activeRecordedActions.value = emptyList()

        activeTargetPins.forEach { pin ->
            try {
                windowManager.removeView(pin)
            } catch (e: Exception) {
                // Ignore
            }
        }
        activeTargetPins.clear()

        floatingControlView?.setRecordingState(false, 0)
        floatingControlView?.setStatusText("Cleared")
        Toast.makeText(this, "Actions and pins cleared", Toast.LENGTH_SHORT).show()
    }

    private fun loadMacroForPlayback(macroId: Long) {
        serviceScope.launch {
            val macro = MacroApp.instance.repository.getMacroById(macroId)
            if (macro != null) {
                recordedActions.clear()
                recordedActions.addAll(macro.actions)
                _activeRecordedActions.value = recordedActions.toList()
                _lastRecordedMacro.value = macro
                floatingControlView?.setStatusText("Loaded: ${macro.name}")
                Toast.makeText(this@FloatingControlService, "Loaded macro: ${macro.name}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun observePlaybackState() {
        serviceScope.launch {
            MacroAccessibilityService.playbackState.collect { state ->
                when (state) {
                    is PlaybackState.Idle -> {
                        floatingControlView?.setPlayingState(false)
                    }
                    is PlaybackState.Playing -> {
                        val loopStr = if (state.totalLoops == 0) "Loop ∞" else "Loop ${state.currentLoop}/${state.totalLoops}"
                        val status = "Play ${state.currentActionIndex}/${state.totalActions} ($loopStr)"
                        floatingControlView?.setPlayingState(true, status)
                    }
                    is PlaybackState.Completed -> {
                        floatingControlView?.setPlayingState(false)
                        floatingControlView?.setStatusText("Done!")
                    }
                    is PlaybackState.Error -> {
                        floatingControlView?.setPlayingState(false)
                        floatingControlView?.setStatusText("Error")
                        Toast.makeText(this@FloatingControlService, state.message, Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()

        // Remove all views
        floatingControlView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing floating control view", e)
            }
        }
        recordingCanvasView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing recording canvas view", e)
            }
        }
        activeTargetPins.forEach { pin ->
            try {
                windowManager.removeView(pin)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing pin", e)
            }
        }
        activeTargetPins.clear()

        _isOverlayRunning.value = false
        Log.d(TAG, "FloatingControlService destroyed")
    }

    companion object {
        private const val TAG = "FloatingControlService"
        private const val NOTIFICATION_ID = 2001
        const val EXTRA_LOAD_MACRO_ID = "extra_load_macro_id"

        private val _isOverlayRunning = MutableStateFlow(false)
        val isOverlayRunning: StateFlow<Boolean> = _isOverlayRunning.asStateFlow()

        private val _activeRecordedActions = MutableStateFlow<List<MacroAction>>(emptyList())
        val activeRecordedActions: StateFlow<List<MacroAction>> = _activeRecordedActions.asStateFlow()

        private val _lastRecordedMacro = MutableStateFlow<Macro?>(null)
        val lastRecordedMacro: StateFlow<Macro?> = _lastRecordedMacro.asStateFlow()

        fun startService(context: Context, macroId: Long? = null) {
            val intent = Intent(context, FloatingControlService::class.java).apply {
                if (macroId != null) {
                    putExtra(EXTRA_LOAD_MACRO_ID, macroId)
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, FloatingControlService::class.java)
            context.stopService(intent)
        }
    }
}
