package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.example.data.MacroDatabase
import com.example.data.MacroRepository

class MacroApp : Application() {

    companion object {
        const val CHANNEL_ID = "macro_overlay_service_channel"
        lateinit var instance: MacroApp
            private set
    }

    val database: MacroDatabase by lazy {
        MacroDatabase.getDatabase(this)
    }

    val repository: MacroRepository by lazy {
        MacroRepository(database.macroDao())
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.overlay_notification_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground service notification for macro recorder floating controls"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
