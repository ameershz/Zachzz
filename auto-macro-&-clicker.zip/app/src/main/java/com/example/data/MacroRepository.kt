package com.example.data

import com.example.model.GestureType
import com.example.model.Macro
import com.example.model.MacroAction
import com.example.model.TouchPoint
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MacroRepository(private val macroDao: MacroDao) {

    val allMacros: Flow<List<Macro>> = macroDao.getAllMacros().map { entities ->
        entities.map { it.toDomain() }
    }

    suspend fun getMacroById(id: Long): Macro? {
        return macroDao.getMacroById(id)?.toDomain()
    }

    suspend fun saveMacro(macro: Macro): Long {
        val entity = MacroEntity.fromDomain(macro)
        return macroDao.insertMacro(entity)
    }

    suspend fun updateMacro(macro: Macro) {
        val entity = MacroEntity.fromDomain(macro)
        macroDao.updateMacro(entity)
    }

    suspend fun deleteMacroById(id: Long) {
        macroDao.deleteMacroById(id)
    }

    suspend fun seedSampleMacrosIfEmpty() {
        if (macroDao.getMacroCount() == 0) {
            val sample1 = Macro(
                name = "Rapid 5x Auto-Tap",
                repeatCount = 1,
                playbackSpeed = 1.0f,
                loopIntervalMs = 300L,
                actions = listOf(
                    MacroAction.createTap(x = 540f, y = 1100f, delayBeforeMs = 150L, durationMs = 45L),
                    MacroAction.createTap(x = 540f, y = 1100f, delayBeforeMs = 120L, durationMs = 45L),
                    MacroAction.createTap(x = 540f, y = 1100f, delayBeforeMs = 120L, durationMs = 45L),
                    MacroAction.createTap(x = 540f, y = 1100f, delayBeforeMs = 120L, durationMs = 45L),
                    MacroAction.createTap(x = 540f, y = 1100f, delayBeforeMs = 120L, durationMs = 45L)
                )
            )

            val sample2 = Macro(
                name = "Auto Scroll Down (Swipe Up)",
                repeatCount = 3,
                playbackSpeed = 1.0f,
                loopIntervalMs = 600L,
                actions = listOf(
                    MacroAction.createSwipe(
                        points = listOf(
                            TouchPoint(x = 540f, y = 1600f),
                            TouchPoint(x = 540f, y = 1200f),
                            TouchPoint(x = 540f, y = 800f),
                            TouchPoint(x = 540f, y = 450f)
                        ),
                        durationMs = 400L,
                        delayBeforeMs = 200L
                    )
                )
            )

            val sample3 = Macro(
                name = "Target Combo: Tap + Hold",
                repeatCount = 1,
                playbackSpeed = 1.0f,
                loopIntervalMs = 400L,
                actions = listOf(
                    MacroAction.createTap(x = 350f, y = 900f, delayBeforeMs = 150L, durationMs = 50L),
                    MacroAction.createLongPress(x = 720f, y = 1300f, delayBeforeMs = 300L, durationMs = 650L)
                )
            )

            saveMacro(sample1)
            saveMacro(sample2)
            saveMacro(sample3)
        }
    }
}
