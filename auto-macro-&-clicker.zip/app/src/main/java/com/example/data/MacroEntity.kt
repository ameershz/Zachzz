package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.Macro

@Entity(tableName = "macros")
data class MacroEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val actionsJson: String,
    val repeatCount: Int = 1,
    val playbackSpeed: Float = 1.0f,
    val loopIntervalMs: Long = 500L
) {
    fun toDomain(): Macro {
        return Macro(
            id = id,
            name = name,
            createdAt = createdAt,
            actions = Macro.deserializeActions(actionsJson),
            repeatCount = repeatCount,
            playbackSpeed = playbackSpeed,
            loopIntervalMs = loopIntervalMs
        )
    }

    companion object {
        fun fromDomain(macro: Macro): MacroEntity {
            return MacroEntity(
                id = macro.id,
                name = macro.name,
                createdAt = macro.createdAt,
                actionsJson = macro.serializeActions(),
                repeatCount = macro.repeatCount,
                playbackSpeed = macro.playbackSpeed,
                loopIntervalMs = macro.loopIntervalMs
            )
        }
    }
}
