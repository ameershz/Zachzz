package com.example.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.MainActivity
import com.example.R
import com.example.model.MacroAction

@SuppressLint("ViewConstructor")
class FloatingControlView(
    context: Context,
    private val windowManager: WindowManager,
    val layoutParams: WindowManager.LayoutParams,
    private val onRecordClicked: () -> Unit,
    private val onStopClicked: () -> Unit,
    private val onPlayClicked: () -> Unit,
    private val onAddPinClicked: () -> Unit,
    private val onClearClicked: () -> Unit,
    private val onCloseClicked: () -> Unit
) : FrameLayout(context) {

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private var isExpanded = true
    private var isRecording = false
    private var isPlaying = false

    private val expandedLayout: LinearLayout
    private val collapsedLayout: LinearLayout
    private val statusTextView: TextView
    private val recordButton: Button
    private val stopButton: Button
    private val playButton: Button
    private val speedButton: Button

    var playbackSpeed = 1.0f
        private set
    var repeatCount = 1 // 0 for infinite
        private set

    init {
        // Base styling
        val dp = resources.displayMetrics.density

        // --- Expanded Layout ---
        expandedLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EE181824"))
                cornerRadius = 24f * dp
                setStroke((1.5f * dp).toInt(), Color.parseColor("#44383854"))
            }
            background = bg
            setPadding((12 * dp).toInt(), (10 * dp).toInt(), (12 * dp).toInt(), (10 * dp).toInt())
            elevation = 16f * dp
        }

        // Header Row: Drag Handle + Title + Status + Minimize + Close
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Drag icon / title
        val dragHandle = TextView(context).apply {
            text = "⋮⋮ Macro Clicker"
            setTextColor(Color.parseColor("#E0E0FF"))
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding((4 * dp).toInt(), 0, (10 * dp).toInt(), 0)
        }

        // Setup dragging on header
        headerRow.setOnTouchListener { _, event ->
            handleDragTouch(event)
        }
        dragHandle.setOnTouchListener { _, event ->
            handleDragTouch(event)
        }

        // Status badge
        statusTextView = TextView(context).apply {
            text = "Ready"
            setTextColor(Color.parseColor("#9E9EBF"))
            textSize = 12f
            setPadding((6 * dp).toInt(), (2 * dp).toInt(), (6 * dp).toInt(), (2 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33FFFFFF"))
                cornerRadius = 12f * dp
            }
        }

        val spacer = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, 0, 1.0f)
        }

        // Minimize button
        val minimizeBtn = createIconButton("—", Color.parseColor("#9E9EBF")) {
            toggleCollapsed()
        }

        // Close button
        val closeBtn = createIconButton("✕", Color.parseColor("#FF6B6B")) {
            onCloseClicked()
        }

        headerRow.addView(dragHandle)
        headerRow.addView(statusTextView)
        headerRow.addView(spacer)
        headerRow.addView(minimizeBtn)
        headerRow.addView(closeBtn)
        expandedLayout.addView(headerRow)

        // Control Buttons Row: Record, Stop, Play, Add Pin, Speed/Loop, Clear, App
        val buttonScrollView = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = (8 * dp).toInt()
            }
        }

        val buttonRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        // Record Button
        recordButton = createActionButton("● Record", Color.parseColor("#EF4444")) {
            onRecordClicked()
        }

        // Stop Button
        stopButton = createActionButton("■ Stop", Color.parseColor("#64748B")) {
            onStopClicked()
        }

        // Play Button
        playButton = createActionButton("▶ Play", Color.parseColor("#10B981")) {
            onPlayClicked()
        }

        // Add Target Pin Button
        val addPinButton = createActionButton("🎯 +Pin", Color.parseColor("#3B82F6")) {
            onAddPinClicked()
        }

        // Speed Multiplier Button
        speedButton = createActionButton("1.0x", Color.parseColor("#8B5CF6")) {
            cycleSpeed()
        }

        // Repeat Count Button
        val repeatButton = createActionButton("Loop: 1", Color.parseColor("#EC4899")) { btn ->
            cycleRepeat(btn)
        }

        // Clear Button
        val clearButton = createActionButton("Clear", Color.parseColor("#6B7280")) {
            onClearClicked()
        }

        // Open App Button
        val openAppButton = createActionButton("App ↗", Color.parseColor("#06B6D4")) {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            }
            context.startActivity(intent)
        }

        buttonRow.addView(recordButton)
        buttonRow.addView(stopButton)
        buttonRow.addView(playButton)
        buttonRow.addView(addPinButton)
        buttonRow.addView(speedButton)
        buttonRow.addView(repeatButton)
        buttonRow.addView(clearButton)
        buttonRow.addView(openAppButton)
        buttonScrollView.addView(buttonRow)
        expandedLayout.addView(buttonScrollView)

        // --- Collapsed Layout (Compact Pill) ---
        collapsedLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#EE181824"))
                cornerRadius = 20f * dp
                setStroke((1.5f * dp).toInt(), Color.parseColor("#55383854"))
            }
            background = bg
            setPadding((10 * dp).toInt(), (6 * dp).toInt(), (10 * dp).toInt(), (6 * dp).toInt())
            elevation = 16f * dp
            visibility = View.GONE
        }

        val pillDrag = TextView(context).apply {
            text = "⏺ Macro"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, 0, (8 * dp).toInt(), 0)
        }
        pillDrag.setOnTouchListener { _, event -> handleDragTouch(event) }
        collapsedLayout.setOnTouchListener { _, event -> handleDragTouch(event) }

        val pillPlay = createIconButton("▶", Color.parseColor("#10B981")) { onPlayClicked() }
        val pillExpand = createIconButton("⤢", Color.parseColor("#9E9EBF")) { toggleCollapsed() }

        collapsedLayout.addView(pillDrag)
        collapsedLayout.addView(pillPlay)
        collapsedLayout.addView(pillExpand)

        addView(expandedLayout)
        addView(collapsedLayout)
    }

    private fun handleDragTouch(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = layoutParams.x
                initialY = layoutParams.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - initialTouchX).toInt()
                val dy = (event.rawY - initialTouchY).toInt()
                layoutParams.x = initialX + dx
                layoutParams.y = initialY + dy
                try {
                    windowManager.updateViewLayout(this, layoutParams)
                } catch (e: Exception) {
                    // Ignore layout update failure on detach
                }
                return true
            }
        }
        return false
    }

    private fun toggleCollapsed() {
        isExpanded = !isExpanded
        if (isExpanded) {
            expandedLayout.visibility = View.VISIBLE
            collapsedLayout.visibility = View.GONE
        } else {
            expandedLayout.visibility = View.GONE
            collapsedLayout.visibility = View.VISIBLE
        }
    }

    fun setRecordingState(recording: Boolean, count: Int = 0) {
        isRecording = recording
        if (recording) {
            recordButton.text = "● Rec..."
            recordButton.isEnabled = false
            statusTextView.text = "Recording ($count)"
            statusTextView.setTextColor(Color.parseColor("#FF5252"))
        } else {
            recordButton.text = "● Record"
            recordButton.isEnabled = true
            statusTextView.text = if (count > 0) "Recorded $count" else "Ready"
            statusTextView.setTextColor(Color.parseColor("#9E9EBF"))
        }
    }

    fun setPlayingState(playing: Boolean, status: String = "Playing") {
        isPlaying = playing
        if (playing) {
            playButton.text = "▶ Playing"
            playButton.isEnabled = false
            statusTextView.text = status
            statusTextView.setTextColor(Color.parseColor("#10B981"))
        } else {
            playButton.text = "▶ Play"
            playButton.isEnabled = true
            statusTextView.text = "Ready"
            statusTextView.setTextColor(Color.parseColor("#9E9EBF"))
        }
    }

    fun setStatusText(text: String) {
        statusTextView.text = text
    }

    private fun cycleSpeed() {
        playbackSpeed = when (playbackSpeed) {
            0.5f -> 1.0f
            1.0f -> 1.5f
            1.5f -> 2.0f
            2.0f -> 3.0f
            3.0f -> 5.0f
            else -> 0.5f
        }
        speedButton.text = "${playbackSpeed}x"
    }

    private fun cycleRepeat(btn: Button) {
        repeatCount = when (repeatCount) {
            1 -> 3
            3 -> 5
            5 -> 10
            10 -> 0 // 0 = infinite
            else -> 1
        }
        btn.text = if (repeatCount == 0) "Loop: ∞" else "Loop: $repeatCount"
    }

    private fun createActionButton(label: String, color: Int, onClick: (Button) -> Unit): Button {
        val dp = resources.displayMetrics.density
        return Button(context).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setTextColor(Color.WHITE)
            minWidth = (54 * dp).toInt()
            minHeight = (36 * dp).toInt()
            val bg = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 14f * dp
            }
            background = bg
            setPadding((10 * dp).toInt(), (4 * dp).toInt(), (10 * dp).toInt(), (4 * dp).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                (36 * dp).toInt()
            ).apply {
                rightMargin = (6 * dp).toInt()
            }
            setOnClickListener { onClick(this) }
        }
    }

    private fun createIconButton(label: String, color: Int, onClick: () -> Unit): TextView {
        val dp = resources.displayMetrics.density
        return TextView(context).apply {
            text = label
            setTextColor(color)
            textSize = 16f
            gravity = Gravity.CENTER
            minWidth = (28 * dp).toInt()
            minHeight = (28 * dp).toInt()
            setPadding((4 * dp).toInt(), (2 * dp).toInt(), (4 * dp).toInt(), (2 * dp).toInt())
            setOnClickListener { onClick() }
        }
    }
}
