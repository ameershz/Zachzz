package com.example.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import com.example.model.GestureType
import com.example.model.MacroAction
import com.example.model.TouchPoint
import kotlin.math.hypot

class RecordingCanvasView(
    context: Context,
    private val onActionRecorded: (MacroAction) -> Unit
) : View(context) {

    private val touchPoints = mutableListOf<TouchPoint>()
    private var downTimeMs: Long = 0L
    private var lastGestureEndTimeMs: Long = 0L

    private val currentPath = Path()
    private val activeRippleCenter = PointF()
    private var isTouching = false

    // Visual feedback paints
    private val pathPaint = Paint().apply {
        color = Color.parseColor("#4DEEAA") // Neon Cyan-Green
        strokeWidth = 14f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = true
    }

    private val pathShadowPaint = Paint().apply {
        color = Color.parseColor("#4400E5FF")
        strokeWidth = 26f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        isAntiAlias = true
    }

    private val pointPaint = Paint().apply {
        color = Color.parseColor("#FF5252") // Coral Red
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val pointHaloPaint = Paint().apply {
        color = Color.parseColor("#55FF5252")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val hintTextPaint = Paint().apply {
        color = Color.parseColor("#EEFFFFFF")
        textSize = 38f
        isAntiAlias = true
        textAlign = Paint.Align.CENTER
        setShadowLayer(8f, 0f, 4f, Color.BLACK)
    }

    private val hintBgPaint = Paint().apply {
        color = Color.parseColor("#CC1E1E24")
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    fun resetTimeline() {
        lastGestureEndTimeMs = 0L
        touchPoints.clear()
        currentPath.reset()
        isTouching = false
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val x = event.x
        val y = event.y
        val now = SystemClock.uptimeMillis()

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                isTouching = true
                downTimeMs = now
                touchPoints.clear()
                touchPoints.add(TouchPoint(x, y, now))

                currentPath.reset()
                currentPath.moveTo(x, y)
                activeRippleCenter.set(x, y)
                invalidate()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (isTouching) {
                    touchPoints.add(TouchPoint(x, y, now))
                    currentPath.lineTo(x, y)
                    invalidate()
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (isTouching) {
                    isTouching = false
                    touchPoints.add(TouchPoint(x, y, now))
                    currentPath.lineTo(x, y)

                    val duration = now - downTimeMs
                    val delayBefore = if (lastGestureEndTimeMs > 0) {
                        (downTimeMs - lastGestureEndTimeMs).coerceIn(50L, 5000L)
                    } else {
                        150L
                    }
                    lastGestureEndTimeMs = now

                    val startPoint = touchPoints.firstOrNull() ?: TouchPoint(x, y, downTimeMs)
                    val endPoint = touchPoints.lastOrNull() ?: startPoint
                    val distance = hypot((endPoint.x - startPoint.x).toDouble(), (endPoint.y - startPoint.y).toDouble()).toFloat()

                    val action = when {
                        distance < 30f && duration >= 450L -> {
                            MacroAction.createLongPress(
                                x = startPoint.x,
                                y = startPoint.y,
                                delayBeforeMs = delayBefore,
                                durationMs = duration
                            )
                        }
                        distance < 30f -> {
                            MacroAction.createTap(
                                x = startPoint.x,
                                y = startPoint.y,
                                delayBeforeMs = delayBefore,
                                durationMs = duration.coerceIn(30L, 100L)
                            )
                        }
                        else -> {
                            MacroAction.createSwipe(
                                points = touchPoints.toList(),
                                durationMs = duration.coerceAtLeast(80L),
                                delayBeforeMs = delayBefore
                            )
                        }
                    }

                    onActionRecorded(action)

                    // Clear the visual path after brief delay
                    postDelayed({
                        currentPath.reset()
                        invalidate()
                    }, 250)
                }
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                isTouching = false
                currentPath.reset()
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Semi-transparent border / banner indicating recording canvas is active
        val bannerTop = 80f
        val bannerHeight = 80f
        val bannerWidth = 620f
        val bannerLeft = (width - bannerWidth) / 2f
        canvas.drawRoundRect(bannerLeft, bannerTop, bannerLeft + bannerWidth, bannerTop + bannerHeight, 40f, 40f, hintBgPaint)
        canvas.drawText("● Touch canvas active - Draw or Tap", width / 2f, bannerTop + 54f, hintTextPaint)

        // Draw swipe path trail
        if (!currentPath.isEmpty) {
            canvas.drawPath(currentPath, pathShadowPaint)
            canvas.drawPath(currentPath, pathPaint)
        }

        // Draw touch ripple/point
        if (isTouching) {
            canvas.drawCircle(activeRippleCenter.x, activeRippleCenter.y, 45f, pointHaloPaint)
            canvas.drawCircle(activeRippleCenter.x, activeRippleCenter.y, 20f, pointPaint)
        }
    }
}
