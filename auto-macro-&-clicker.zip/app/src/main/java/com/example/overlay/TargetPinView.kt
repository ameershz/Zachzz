package com.example.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.example.R

@SuppressLint("ViewConstructor")
class TargetPinView(
    context: Context,
    val index: Int,
    private val windowManager: WindowManager,
    val layoutParams: WindowManager.LayoutParams,
    private val onPinRemoved: (TargetPinView) -> Unit
) : FrameLayout(context) {

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    val targetCenterScreenX: Float
        get() = layoutParams.x + width / 2f

    val targetCenterScreenY: Float
        get() = layoutParams.y + height / 2f

    init {
        val sizePx = (56 * resources.displayMetrics.density).toInt()
        val bgDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E62563EB")) // Vibrant Royal Blue
            setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
        }
        background = bgDrawable
        elevation = 12f * resources.displayMetrics.density

        // Center number label
        val label = TextView(context).apply {
            text = index.toString()
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val labelParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT).apply {
            gravity = Gravity.CENTER
        }
        addView(label, labelParams)

        // Close badge
        val closeBadge = TextView(context).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#EEEF4444")) // Red
            }
            setOnClickListener {
                onPinRemoved(this@TargetPinView)
            }
        }
        val closeSize = (18 * resources.displayMetrics.density).toInt()
        val closeParams = LayoutParams(closeSize, closeSize).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = (2 * resources.displayMetrics.density).toInt()
            rightMargin = (2 * resources.displayMetrics.density).toInt()
        }
        addView(closeBadge, closeParams)

        // Drag listener
        setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    layoutParams.x = initialX + dx
                    layoutParams.y = initialY + dy
                    try {
                        windowManager.updateViewLayout(this, layoutParams)
                    } catch (e: Exception) {
                        // ignore layout update errors if detached
                    }
                    true
                }
                else -> false
            }
        }
    }
}
