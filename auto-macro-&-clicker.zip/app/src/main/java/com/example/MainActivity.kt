package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.service.PlaybackState
import com.example.ui.MainViewModel
import com.example.ui.components.FloatingLauncherCard
import com.example.ui.components.MacroListSection
import com.example.ui.components.PermissionsSection
import com.example.ui.components.PlaygroundCard
import com.example.ui.components.SecurityExplainerCard
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainScreen(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh permission states whenever returning to the app
        viewModel.refreshPermissionStates()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val isOverlayGranted by viewModel.isOverlayGranted.collectAsStateWithLifecycle()
    val isAccessibilityEnabled by viewModel.isAccessibilityEnabled.collectAsStateWithLifecycle()
    val isAccessibilityConnected by viewModel.isAccessibilityConnected.collectAsStateWithLifecycle()
    val isOverlayServiceRunning by viewModel.isOverlayServiceRunning.collectAsStateWithLifecycle()
    val macros by viewModel.macros.collectAsStateWithLifecycle()
    val activeRecordedActions by viewModel.activeRecordedActions.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val playgroundState by viewModel.playgroundState.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    // Show feedback snackbar on playback events
    LaunchedEffect(playbackState) {
        when (val state = playbackState) {
            is PlaybackState.Completed -> {
                scope.launch {
                    snackbarHostState.showSnackbar("Macro '${state.macroName}' completed successfully!")
                }
            }
            is PlaybackState.Error -> {
                scope.launch {
                    snackbarHostState.showSnackbar("Playback error: ${state.message}")
                }
            }
            else -> {}
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Auto Macro & Clicker",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refreshPermissionStates() }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh permissions",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Playback Banner if currently playing
                AnimatedVisibility(visible = playbackState is PlaybackState.Playing) {
                    val playing = playbackState as? PlaybackState.Playing
                    if (playing != null) {
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = androidx.compose.material3.CardDefaults.cardColors(
                                containerColor = EmeraldSuccess.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "▶ Replaying: ${playing.macroName}",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSuccess
                                    )
                                    Text(
                                        text = "Action ${playing.currentActionIndex} of ${playing.totalActions} • Loop ${playing.currentLoop}/${if (playing.totalLoops == 0) "∞" else playing.totalLoops.toString()}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                                Button(
                                    onClick = { viewModel.stopPlayback() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Stop")
                                }
                            }
                        }
                    }
                }

                // 1. Permissions Check Section (SYSTEM_ALERT_WINDOW + BIND_ACCESSIBILITY_SERVICE)
                PermissionsSection(
                    isOverlayGranted = isOverlayGranted,
                    isAccessibilityEnabled = isAccessibilityEnabled,
                    isAccessibilityConnected = isAccessibilityConnected
                )

                // 2. Floating Controller Panel Launcher
                FloatingLauncherCard(
                    isOverlayRunning = isOverlayServiceRunning,
                    isOverlayGranted = isOverlayGranted,
                    onToggleService = { viewModel.toggleFloatingService() }
                )

                // 3. In-App Clicker & Gesture Playground (Live testing sandbox)
                PlaygroundCard(
                    playgroundState = playgroundState,
                    onClickTarget = { viewModel.registerPlaygroundClick() },
                    onResetPlayground = { viewModel.resetPlayground() }
                )

                // 4. Saved Macros Manager
                MacroListSection(
                    macros = macros,
                    activeRecordedActions = activeRecordedActions,
                    onPlayMacro = { macro -> viewModel.playMacroDirectly(macro) },
                    onLoadIntoOverlay = { id -> viewModel.loadMacroIntoOverlay(id) },
                    onDeleteMacro = { id -> viewModel.deleteMacro(id) },
                    onSaveMacro = { name, actions -> viewModel.saveMacro(name, actions) }
                )

                // 5. How it Works & Android Security Architecture Explainer
                SecurityExplainerCard()

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}
