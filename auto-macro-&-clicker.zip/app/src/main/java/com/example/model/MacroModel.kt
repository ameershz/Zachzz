package com.example.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class GestureType {
    TAP,
    LONG_PRESS,
    SWIPE,
    TARGET_PIN
}

data class TouchPoint(
    val x: Float,
    val y: Float,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("x", x.toDouble())
        put("y", y.toDouble())
        put("timestamp", timestamp)
    }

    companion object {
        fun fromJson(json: JSONObject): TouchPoint {
            return TouchPoint(
                x = json.optDouble("x", 0.0).toFloat(),
                y = json.optDouble("y", 0.0).toFloat(),
                timestamp = json.optLong("timestamp", 0L)
            )
        }
    }
}

data class MacroAction(
    val id: String = UUID.randomUUID().toString(),
    val type: GestureType,
    val points: List<TouchPoint>,
    val durationMs: Long,
    val delayBeforeMs: Long = 100L,
    val description: String = ""
) {
    val startX: Float get() = points.firstOrNull()?.x ?: 0f
    val startY: Float get() = points.firstOrNull()?.y ?: 0f
    val endX: Float get() = points.lastOrNull()?.x ?: startX
    val endY: Float get() = points.lastOrNull()?.y ?: startY

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type.name)
        put("durationMs", durationMs)
        put("delayBeforeMs", delayBeforeMs)
        put("description", description)
        val pointsArray = JSONArray()
        points.forEach { pointsArray.put(it.toJson()) }
        put("points", pointsArray)
    }

    companion object {
        fun fromJson(json: JSONObject): MacroAction {
            val pointsList = mutableListOf<TouchPoint>()
            val pointsArray = json.optJSONArray("points")
            if (pointsArray != null) {
                for (i in 0 until pointsArray.length()) {
                    val pJson = pointsArray.optJSONObject(i)
                    if (pJson != null) {
                        pointsList.add(TouchPoint.fromJson(pJson))
                    }
                }
            }
            return MacroAction(
                id = json.optString("id", UUID.randomUUID().toString()),
                type = runCatching { GestureType.valueOf(json.optString("type", GestureType.TAP.name)) }
                    .getOrDefault(GestureType.TAP),
                points = pointsList,
                durationMs = json.optLong("durationMs", 50L),
                delayBeforeMs = json.optLong("delayBeforeMs", 100L),
                description = json.optString("description", "")
            )
        }

        fun createTap(x: Float, y: Float, delayBeforeMs: Long = 100L, durationMs: Long = 50L): MacroAction {
            return MacroAction(
                type = GestureType.TAP,
                points = listOf(TouchPoint(x, y)),
                durationMs = durationMs,
                delayBeforeMs = delayBeforeMs,
                description = "Tap at (${x.toInt()}, ${y.toInt()})"
            )
        }

        fun createLongPress(x: Float, y: Float, delayBeforeMs: Long = 100L, durationMs: Long = 600L): MacroAction {
            return MacroAction(
                type = GestureType.LONG_PRESS,
                points = listOf(TouchPoint(x, y)),
                durationMs = durationMs,
                delayBeforeMs = delayBeforeMs,
                description = "Long press at (${x.toInt()}, ${y.toInt()}) for ${durationMs}ms"
            )
        }

        fun createSwipe(
            points: List<TouchPoint>,
            durationMs: Long = 300L,
            delayBeforeMs: Long = 100L
        ): MacroAction {
            val start = points.firstOrNull() ?: TouchPoint(0f, 0f)
            val end = points.lastOrNull() ?: start
            return MacroAction(
                type = GestureType.SWIPE,
                points = points,
                durationMs = durationMs.coerceAtLeast(50L),
                delayBeforeMs = delayBeforeMs,
                description = "Swipe from (${start.x.toInt()}, ${start.y.toInt()}) to (${end.x.toInt()}, ${end.y.toInt()})"
            )
        }
    }
}

data class Macro(
    val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    val actions: List<MacroAction> = emptyList(),
    val repeatCount: Int = 1, // 0 = infinite loop
    val playbackSpeed: Float = 1.0f,
    val loopIntervalMs: Long = 500L
) {
    val totalDurationMs: Long get() {
        val actionsTime = actions.sumOf { it.delayBeforeMs + it.durationMs }
        return (actionsTime / playbackSpeed).toLong()
    }

    fun serializeActions(): String {
        val array = JSONArray()
        actions.forEach { array.put(it.toJson()) }
        return array.toString()
    }

    companion object {
        fun deserializeActions(jsonString: String): List<MacroAction> {
            val list = mutableListOf<MacroAction>()
            if (jsonString.isBlank()) return list
            runCatching {
                val array = JSONArray(jsonString)
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i)
                    if (obj != null) {
                        list.add(MacroAction.fromJson(obj))
                    }
                }
            }
            return list
        }
    }
}

data class TargetPin(
    val id: Int,
    val x: Int,
    val y: Int,
    val delayBeforeMs: Long = 200L,
    val clickDurationMs: Long = 50L
)
