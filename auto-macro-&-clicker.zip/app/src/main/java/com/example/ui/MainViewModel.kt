package com.example.ui

import android.app.Application
import android.content.Context
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.MacroApp
import com.example.model.GestureType
import com.example.model.Macro
import com.example.model.MacroAction
import com.example.service.FloatingControlService
import com.example.service.MacroAccessibilityService
import com.example.service.PlaybackState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class PlaygroundState(
    val clickCount: Int = 0,
    val firstClickTime: Long = 0L,
    val clicksPerSecond: Float = 0f,
    val lastGestureDetected: String = "No gestures detected yet"
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as MacroApp).repository

    val macros: StateFlow<List<Macro>> = repository.allMacros
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _isOverlayGranted = MutableStateFlow(false)
    val isOverlayGranted: StateFlow<Boolean> = _isOverlayGranted.asStateFlow()

    private val _isAccessibilityEnabled = MutableStateFlow(false)
    val isAccessibilityEnabled: StateFlow<Boolean> = _isAccessibilityEnabled.asStateFlow()

    val isAccessibilityConnected: StateFlow<Boolean> = MacroAccessibilityService.isServiceActive

    val isOverlayServiceRunning: StateFlow<Boolean> = FloatingControlService.isOverlayRunning

    val activeRecordedActions: StateFlow<List<MacroAction>> = FloatingControlService.activeRecordedActions

    val playbackState: StateFlow<PlaybackState> = MacroAccessibilityService.playbackState

    private val _playgroundState = MutableStateFlow(PlaygroundState())
    val playgroundState: StateFlow<PlaygroundState> = _playgroundState.asStateFlow()

    init {
        refreshPermissionStates()
        viewModelScope.launch {
            repository.seedSampleMacrosIfEmpty()
        }
    }

    fun refreshPermissionStates() {
        val context = getApplication<Application>()
        _isOverlayGranted.value = Settings.canDrawOverlays(context)
        _isAccessibilityEnabled.value = MacroAccessibilityService.isAccessibilitySettingsEnabled(context)
    }

    fun toggleFloatingService() {
        val context = getApplication<Application>()
        if (isOverlayServiceRunning.value) {
            FloatingControlService.stopService(context)
        } else {
            FloatingControlService.startService(context)
        }
    }

    fun playMacroDirectly(macro: Macro) {
        val service = MacroAccessibilityService.instance
        if (service != null) {
            service.playMacro(macro)
        }
    }

    fun stopPlayback() {
        MacroAccessibilityService.instance?.stopPlayback()
    }

    fun saveMacro(name: String, actions: List<MacroAction>, repeatCount: Int = 1, speed: Float = 1.0f) {
        viewModelScope.launch {
            val newMacro = Macro(
                name = name.ifBlank { "Macro #${System.currentTimeMillis() % 10000}" },
                actions = actions,
                repeatCount = repeatCount,
                playbackSpeed = speed
            )
            repository.saveMacro(newMacro)
        }
    }

    fun deleteMacro(macroId: Long) {
        viewModelScope.launch {
            repository.deleteMacroById(macroId)
        }
    }

    fun updateMacroSettings(macro: Macro, repeatCount: Int, speed: Float) {
        viewModelScope.launch {
            repository.updateMacro(macro.copy(repeatCount = repeatCount, playbackSpeed = speed))
        }
    }

    fun loadMacroIntoOverlay(macroId: Long) {
        val context = getApplication<Application>()
        FloatingControlService.startService(context, macroId)
    }

    // --- Playground Testing Methods ---
    fun registerPlaygroundClick() {
        val now = System.currentTimeMillis()
        val current = _playgroundState.value
        val firstTime = if (current.firstClickTime == 0L) now else current.firstClickTime
        val newCount = current.clickCount + 1
        val elapsedSec = (now - firstTime) / 1000f
        val cps = if (elapsedSec > 0.1f) newCount / elapsedSec else newCount.toFloat()

        _playgroundState.value = current.copy(
            clickCount = newCount,
            firstClickTime = firstTime,
            clicksPerSecond = cps,
            lastGestureDetected = "Single Tap at ${now % 100000}ms"
        )
    }

    fun registerPlaygroundGesture(description: String) {
        _playgroundState.value = _playgroundState.value.copy(
            lastGestureDetected = description
        )
    }

    fun resetPlayground() {
        _playgroundState.value = PlaygroundState()
    }
}
