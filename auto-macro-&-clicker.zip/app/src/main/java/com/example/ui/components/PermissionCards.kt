package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Accessibility
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldSuccess

@Composable
fun PermissionsSection(
    isOverlayGranted: Boolean,
    isAccessibilityEnabled: Boolean,
    isAccessibilityConnected: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showAccessibilityHelp by remember { mutableStateOf(false) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Required Permissions",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        // 1. SYSTEM_ALERT_WINDOW (Display over other apps)
        PermissionCard(
            title = "Draw Over Other Apps",
            subtitle = "SYSTEM_ALERT_WINDOW — Allows the floating control panel and touch recorder to display over any app.",
            isGranted = isOverlayGranted,
            icon = Icons.Default.Layers,
            actionButtonText = if (isOverlayGranted) "Active" else "Grant Overlay Permission",
            testTag = "overlay_permission_button",
            onAction = {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        )

        // 2. BIND_ACCESSIBILITY_SERVICE
        PermissionCard(
            title = "Accessibility Gesture Service",
            subtitle = "BIND_ACCESSIBILITY_SERVICE — Needed to simulate and dispatch taps, long-presses, and swipes without root.",
            isGranted = isAccessibilityEnabled && isAccessibilityConnected,
            icon = Icons.Default.Accessibility,
            actionButtonText = if (isAccessibilityEnabled) "Service Enabled" else "Enable Accessibility",
            testTag = "accessibility_permission_button",
            secondaryButtonText = if (!isAccessibilityEnabled) "How to enable?" else null,
            onSecondaryAction = { showAccessibilityHelp = !showAccessibilityHelp },
            onAction = {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        )

        // Step-by-step helper if user needs guidance
        AnimatedVisibility(visible = showAccessibilityHelp) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "3-Step Setup for Accessibility:",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "1. Tap 'Enable Accessibility' above to open Settings\n" +
                                "2. Locate 'Auto Macro & Clicker Service' in Installed Apps\n" +
                                "3. Turn the switch ON and tap Allow to grant gesture permission.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PermissionCard(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    actionButtonText: String,
    testTag: String,
    onAction: () -> Unit,
    secondaryButtonText: String? = null,
    onSecondaryAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (isGranted) EmeraldSuccess.copy(alpha = 0.15f)
                            else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isGranted) EmeraldSuccess else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                            contentDescription = if (isGranted) "Granted" else "Requires setup",
                            tint = if (isGranted) EmeraldSuccess else Color(0xFFF59E0B),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Text(
                        text = if (isGranted) "Permission active and ready" else "Setup required",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isGranted) EmeraldSuccess else Color(0xFFF59E0B),
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!isGranted) {
                    Button(
                        onClick = onAction,
                        modifier = Modifier
                            .weight(1f)
                            .testTag(testTag),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(actionButtonText, style = MaterialTheme.typography.labelLarge)
                    }
                } else {
                    OutlinedButton(
                        onClick = onAction,
                        modifier = Modifier
                            .weight(1f)
                            .testTag(testTag),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Configure / Settings", style = MaterialTheme.typography.labelMedium)
                    }
                }

                if (secondaryButtonText != null && onSecondaryAction != null) {
                    OutlinedButton(
                        onClick = onSecondaryAction,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(secondaryButtonText, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}
