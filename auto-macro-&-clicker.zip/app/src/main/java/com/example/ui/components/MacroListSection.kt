package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GestureType
import com.example.model.Macro
import com.example.model.MacroAction
import com.example.ui.theme.EmeraldSuccess
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MacroListSection(
    macros: List<Macro>,
    activeRecordedActions: List<MacroAction>,
    onPlayMacro: (Macro) -> Unit,
    onLoadIntoOverlay: (Long) -> Unit,
    onDeleteMacro: (Long) -> Unit,
    onSaveMacro: (name: String, actions: List<MacroAction>) -> Unit,
    modifier: Modifier = Modifier
) {
    var macroToInspect by remember { mutableStateOf<Macro?>(null) }
    var showSaveDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Saved Macros (${macros.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )

            // If there's an active recorded macro from overlay, provide quick Save button
            if (activeRecordedActions.isNotEmpty()) {
                Button(
                    onClick = { showSaveDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save Recording (${activeRecordedActions.size})", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        if (macros.isEmpty()) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No saved macros yet",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Start the Floating Controller and tap '● Record' to capture gestures, or use target pins.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            macros.forEach { macro ->
                MacroCardItem(
                    macro = macro,
                    onPlay = { onPlayMacro(macro) },
                    onLoadIntoOverlay = { onLoadIntoOverlay(macro.id) },
                    onInspect = { macroToInspect = macro },
                    onDelete = { onDeleteMacro(macro.id) }
                )
            }
        }
    }

    // Detail / Coordinates Inspection Dialog
    macroToInspect?.let { macro ->
        MacroDetailDialog(
            macro = macro,
            onDismiss = { macroToInspect = null }
        )
    }

    // Save Recording Dialog
    if (showSaveDialog) {
        SaveMacroDialog(
            actionCount = activeRecordedActions.size,
            onDismiss = { showSaveDialog = false },
            onConfirm = { name ->
                onSaveMacro(name, activeRecordedActions)
                showSaveDialog = false
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MacroCardItem(
    macro: Macro,
    onPlay: () -> Unit,
    onLoadIntoOverlay: () -> Unit,
    onInspect: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }
    val formattedDate = remember(macro.createdAt) { dateFormat.format(Date(macro.createdAt)) }

    val tapCount = remember(macro.actions) {
        macro.actions.count { it.type == GestureType.TAP || it.type == GestureType.TARGET_PIN }
    }
    val swipeCount = remember(macro.actions) {
        macro.actions.count { it.type == GestureType.SWIPE }
    }
    val longPressCount = remember(macro.actions) {
        macro.actions.count { it.type == GestureType.LONG_PRESS }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("macro_item_${macro.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = macro.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "$formattedDate • ${macro.actions.size} actions",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(onClick = onInspect) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Details",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete",
                        tint = Color(0xFFEF4444)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action breakdown tags
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (tapCount > 0) {
                    SuggestionChip(onClick = {}, label = { Text("$tapCount Taps", fontSize = 11.sp) })
                }
                if (swipeCount > 0) {
                    SuggestionChip(onClick = {}, label = { Text("$swipeCount Swipes", fontSize = 11.sp) })
                }
                if (longPressCount > 0) {
                    SuggestionChip(onClick = {}, label = { Text("$longPressCount Holds", fontSize = 11.sp) })
                }
                SuggestionChip(
                    onClick = {},
                    label = { Text(if (macro.repeatCount == 0) "Loop: ∞" else "Loop: ${macro.repeatCount}x", fontSize = 11.sp) }
                )
                SuggestionChip(
                    onClick = {},
                    label = { Text("${macro.playbackSpeed}x Speed", fontSize = 11.sp) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onPlay,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess)
                ) {
                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Play Now", style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = onLoadIntoOverlay,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Widgets, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Load in Overlay", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
fun MacroDetailDialog(
    macro: Macro,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = macro.name, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Total Actions: ${macro.actions.size}  •  Estimated duration: ${macro.totalDurationMs}ms",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(macro.actions.withIndex().toList()) { (index, action) ->
                        Card(
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "#${index + 1} ${action.type.name}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text(
                                        text = "Duration: ${action.durationMs}ms (Pre: ${action.delayBeforeMs}ms)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                when (action.type) {
                                    GestureType.TAP, GestureType.TARGET_PIN, GestureType.LONG_PRESS -> {
                                        Text(
                                            text = "Coordinates: (${action.startX.toInt()}, ${action.startY.toInt()})",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    GestureType.SWIPE -> {
                                        Text(
                                            text = "From: (${action.startX.toInt()}, ${action.startY.toInt()}) ➔ To: (${action.endX.toInt()}, ${action.endY.toInt()}) [${action.points.size} pts]",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun SaveMacroDialog(
    actionCount: Int,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf("Macro #${System.currentTimeMillis() % 1000}") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Save Recorded Macro") },
        text = {
            Column {
                Text(
                    text = "Save the $actionCount actions recorded during your floating overlay session to your database for future playback.",
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Macro Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(name) }) {
                Text("Save to Database")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
