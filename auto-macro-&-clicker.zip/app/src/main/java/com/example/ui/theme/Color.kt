package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand: Deep Cobalt & Electric Blue
val BluePrimary = Color(0xFF2563EB)
val BluePrimaryDark = Color(0xFF3B82F6)
val BlueContainerDark = Color(0xFF1E3A8A)

// Secondary: Vibrant Cyan
val CyanAccent = Color(0xFF06B6D4)
val CyanAccentDark = Color(0xFF22D3EE)

// Tertiary: Emerald Green (Play / Success)
val EmeraldSuccess = Color(0xFF10B981)
val EmeraldContainerDark = Color(0xFF064E3B)

// Destructive / Recording: Coral Crimson
val CrimsonRecord = Color(0xFFEF4444)
val CrimsonContainerDark = Color(0xFF7F1D1D)

// Neutral Dark Surfaces
val DarkBackground = Color(0xFF0F1117)
val DarkSurface = Color(0xFF181B26)
val DarkSurfaceVariant = Color(0xFF222638)
val DarkOutline = Color(0xFF363C52)

val TextPrimaryDark = Color(0xFFF3F4F6)
val TextSecondaryDark = Color(0xFF9CA3AF)
val TextTertiaryDark = Color(0xFF6B7280)
