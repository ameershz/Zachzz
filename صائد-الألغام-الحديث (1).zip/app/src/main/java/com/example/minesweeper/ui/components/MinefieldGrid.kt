package com.example.minesweeper.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.Cell
import com.example.minesweeper.model.ChordingTrigger
import com.example.minesweeper.model.MinesweeperTheme

@Composable
fun MinefieldGrid(
    grid: List<List<Cell>>,
    theme: MinesweeperTheme,
    isFlagMode: Boolean,
    chordingTrigger: ChordingTrigger,
    isZoomLocked: Boolean,
    onCellClick: (Int, Int) -> Unit,
    onCellLongClick: (Int, Int) -> Unit,
    onCellDoubleTap: (Int, Int) -> Unit,
    onPressStateChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .background(theme.boardBackground)
    ) {
        val density = LocalDensity.current
        val containerWidthPx = constraints.maxWidth.toFloat()
        val containerHeightPx = constraints.maxHeight.toFloat()

        val numRows = maxOf(1, grid.size)
        val numCols = maxOf(1, grid.firstOrNull()?.size ?: 1)

        // Board border (4dp) + inner padding (4dp) on each side = 16dp total
        // Plus a 4dp margin on each side for breathing room = 24dp
        val boardExtraSpaceDp = 24.dp
        val boardExtraSpacePx = with(density) { boardExtraSpaceDp.toPx() }

        val availWidthPx = maxOf(0f, containerWidthPx - boardExtraSpacePx)
        val availHeightPx = maxOf(0f, containerHeightPx - boardExtraSpacePx)

        // Fit cell size in pixels:
        // cellSize = min(available width / cols, available height / rows)
        val cellWidthPx = availWidthPx / numCols
        val cellHeightPx = availHeightPx / numRows
        val fitCellSizePx = minOf(cellWidthPx, cellHeightPx)

        val cellSizeDp: Dp = with(density) {
            fitCellSizePx.toDp().coerceIn(10.dp, 48.dp)
        }
        val actualCellSizePx = with(density) { cellSizeDp.toPx() }

        val baseBoardWidthPx = actualCellSizePx * numCols + boardExtraSpacePx
        val baseBoardHeightPx = actualCellSizePx * numRows + boardExtraSpacePx

        var scale by remember { mutableFloatStateOf(1f) }
        var offsetX by remember { mutableFloatStateOf(0f) }
        var offsetY by remember { mutableFloatStateOf(0f) }

        // Reset zoom and pan whenever a new grid or difficulty is loaded
        LaunchedEffect(grid) {
            scale = 1f
            offsetX = 0f
            offsetY = 0f
        }

        // Clamps pan offsets so edges never bleed or leave empty gaps outside the container
        fun clampOffsets(s: Float, targetX: Float, targetY: Float): Pair<Float, Float> {
            val scaledW = baseBoardWidthPx * s
            val scaledH = baseBoardHeightPx * s

            val clampedX = if (scaledW <= containerWidthPx) {
                0f
            } else {
                val maxOx = (scaledW - containerWidthPx) / 2f
                targetX.coerceIn(-maxOx, maxOx)
            }

            val clampedY = if (scaledH <= containerHeightPx) {
                0f
            } else {
                val maxOy = (scaledH - containerHeightPx) / 2f
                targetY.coerceIn(-maxOy, maxOy)
            }

            return clampedX to clampedY
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(isZoomLocked, baseBoardWidthPx, baseBoardHeightPx, containerWidthPx, containerHeightPx) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = if (!isZoomLocked) {
                            (scale * zoom).coerceIn(1f, 3f)
                        } else {
                            scale
                        }
                        scale = newScale

                        val targetX = offsetX + pan.x
                        val targetY = offsetY + pan.y
                        val (cx, cy) = clampOffsets(newScale, targetX, targetY)
                        offsetX = cx
                        offsetY = cy
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
                    .background(theme.boardBackground)
                    .border(
                        width = 4.dp,
                        color = if (theme.isRetroBeveled) Color(0xFF707070) else theme.cellBorderDark,
                        shape = RoundedCornerShape(2.dp)
                    )
                    .padding(4.dp)
            ) {
                Column {
                    grid.forEachIndexed { r, row ->
                        Row {
                            row.forEachIndexed { c, cell ->
                                CellItem(
                                    cell = cell,
                                    theme = theme,
                                    size = cellSizeDp,
                                    isFlagMode = isFlagMode,
                                    chordingTrigger = chordingTrigger,
                                    onClick = { onCellClick(r, c) },
                                    onLongClick = { onCellLongClick(r, c) },
                                    onDoubleTap = { onCellDoubleTap(r, c) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun CellItem(
    cell: Cell,
    theme: MinesweeperTheme,
    size: Dp,
    isFlagMode: Boolean,
    chordingTrigger: ChordingTrigger,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onDoubleTap: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hint_anim")
    val hintAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hint_alpha"
    )

    val isCompactCell = size < 20.dp

    Box(
        modifier = Modifier
            .size(size)
            .testTag("cell_${cell.row}_${cell.col}")
            .drawBehind {
                if (theme.isRetroBeveled) {
                    val stroke = if (isCompactCell) 1.dp.toPx() else 2.dp.toPx()
                    if (!cell.isRevealed) {
                        // Raised 3D effect
                        drawLine(theme.cellBorderLight, Offset(0f, 0f), Offset(this.size.width, 0f), strokeWidth = stroke)
                        drawLine(theme.cellBorderLight, Offset(0f, 0f), Offset(0f, this.size.height), strokeWidth = stroke)
                        drawLine(theme.cellBorderDark, Offset(this.size.width, 0f), Offset(this.size.width, this.size.height), strokeWidth = stroke)
                        drawLine(theme.cellBorderDark, Offset(0f, this.size.height), Offset(this.size.width, this.size.height), strokeWidth = stroke)
                    } else {
                        // Sunken flat 1px grid
                        drawLine(Color(0xFF888888), Offset(0f, 0f), Offset(this.size.width, 0f), strokeWidth = 1f)
                        drawLine(Color(0xFF888888), Offset(0f, 0f), Offset(0f, this.size.height), strokeWidth = 1f)
                    }
                }
            }
            .background(
                when {
                    cell.isExplodedMine -> Color(0xFFE53935)
                    cell.isRevealed -> theme.cellRevealed
                    else -> theme.cellUnrevealed
                }
            )
            .then(
                if (cell.isHinted) {
                    Modifier.border(2.dp, Color(0xFFFFD700).copy(alpha = hintAlpha))
                } else if (!theme.isRetroBeveled) {
                    Modifier.border(0.5.dp, theme.cellBorderDark.copy(alpha = 0.5f))
                } else {
                    Modifier
                }
            )
            .combinedClickable(
                onClick = {
                    if (cell.isRevealed) {
                        if (chordingTrigger == ChordingTrigger.SINGLE_TAP) {
                            onClick()
                        }
                    } else {
                        onClick()
                    }
                },
                onLongClick = {
                    if (cell.isRevealed) {
                        if (chordingTrigger == ChordingTrigger.LONG_PRESS) {
                            onLongClick()
                        }
                    } else {
                        onLongClick()
                    }
                },
                onDoubleClick = {
                    if (cell.isRevealed && chordingTrigger == ChordingTrigger.DOUBLE_TAP) {
                        onDoubleTap()
                    }
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        val fontSize = maxOf(8f, size.value * 0.65f).sp
        val emojiSize = maxOf(7f, size.value * 0.58f).sp

        when {
            cell.isFlagged -> {
                Text(
                    text = theme.flagEmoji,
                    fontSize = emojiSize
                )
            }
            cell.isRevealed && cell.isMine -> {
                Text(
                    text = theme.mineEmoji,
                    fontSize = emojiSize
                )
            }
            cell.isRevealed && cell.adjacentMines > 0 -> {
                val colorIndex = (cell.adjacentMines - 1).coerceIn(0, theme.digitColors.size - 1)
                Text(
                    text = cell.adjacentMines.toString(),
                    color = theme.digitColors[colorIndex],
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
