package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.AvailableThemes
import com.example.minesweeper.model.MinesweeperTheme
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

@Composable
fun ThemesScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    var previewTheme by remember(uiState.currentTheme) { mutableStateOf(uiState.currentTheme) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("themes_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = Color.White
                    )
                }

                Column {
                    Text(
                        text = "ثيمات ومظهر اللوحة 🎨",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "معاينة حية وتخصيص الألوان والأشكال",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp
                    )
                }
            }

            // Live Preview Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                border = androidx.compose.foundation.BorderStroke(2.dp, previewTheme.accentColor)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "معاينة حية: ${previewTheme.nameAr}",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // 4-Cell Mini Live Board Preview
                    Row(
                        modifier = Modifier
                            .background(previewTheme.boardBackground, RoundedCornerShape(8.dp))
                            .border(3.dp, if (previewTheme.isRetroBeveled) Color(0xFF707070) else previewTheme.cellBorderDark, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // 1. Unrevealed cell
                        ThemePreviewCell(
                            theme = previewTheme,
                            isRevealed = false,
                            content = ""
                        )
                        // 2. Flagged cell
                        ThemePreviewCell(
                            theme = previewTheme,
                            isRevealed = false,
                            content = previewTheme.flagEmoji
                        )
                        // 3. Numbered cell (2)
                        ThemePreviewCell(
                            theme = previewTheme,
                            isRevealed = true,
                            content = "2",
                            textColor = previewTheme.digitColors.getOrNull(1) ?: Color.Green
                        )
                        // 4. Mine cell
                        ThemePreviewCell(
                            theme = previewTheme,
                            isRevealed = true,
                            content = previewTheme.mineEmoji
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (previewTheme.id != uiState.currentTheme.id) {
                        Button(
                            onClick = { viewModel.selectTheme(previewTheme) },
                            colors = ButtonDefaults.buttonColors(containerColor = previewTheme.accentColor),
                            modifier = Modifier.fillMaxWidth().testTag("apply_theme_button")
                        ) {
                            Text("تطبيق هذا الثيم ✔", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF065F46), RoundedCornerShape(20.dp))
                                .padding(horizontal = 16.dp, vertical = 6.dp)
                        ) {
                            Text("الثيم الحالي النشط ✔", color = Color(0xFFA7F3D0), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Themes List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(AvailableThemes.allThemes) { theme ->
                    val isSelected = theme.id == previewTheme.id
                    val isApplied = theme.id == uiState.currentTheme.id

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { previewTheme = theme },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF334155) else Color(0xFF1E293B)
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) theme.accentColor else Color(0xFF334155)
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Theme color swatch circle
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(theme.boardBackground, RoundedCornerShape(8.dp))
                                        .border(2.dp, theme.accentColor, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(theme.flagEmoji, fontSize = 16.sp)
                                }

                                Column {
                                    Text(
                                        text = theme.nameAr,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Text(
                                        text = theme.descriptionAr,
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            if (isApplied) {
                                Text("مفعّل", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun ThemePreviewCell(
    theme: MinesweeperTheme,
    isRevealed: Boolean,
    content: String,
    textColor: Color = Color.Black
) {
    Box(
        modifier = Modifier
            .size(42.dp)
            .drawBehind {
                if (theme.isRetroBeveled) {
                    val stroke = 2.dp.toPx()
                    if (!isRevealed) {
                        drawLine(theme.cellBorderLight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                        drawLine(theme.cellBorderLight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                        drawLine(theme.cellBorderDark, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                        drawLine(theme.cellBorderDark, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                    } else {
                        drawLine(Color(0xFF888888), Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = 1f)
                        drawLine(Color(0xFF888888), Offset(0f, 0f), Offset(0f, size.height), strokeWidth = 1f)
                    }
                }
            }
            .background(if (isRevealed) theme.cellRevealed else theme.cellUnrevealed)
            .then(
                if (!theme.isRetroBeveled) Modifier.border(1.dp, theme.cellBorderDark) else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = content,
            color = textColor,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
