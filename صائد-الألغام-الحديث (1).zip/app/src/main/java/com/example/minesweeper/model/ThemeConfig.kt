package com.example.minesweeper.model

import androidx.compose.ui.graphics.Color

data class MinesweeperTheme(
    val id: String,
    val nameAr: String,
    val descriptionAr: String,
    val boardBackground: Color,
    val cellUnrevealed: Color,
    val cellRevealed: Color,
    val cellBorderLight: Color,
    val cellBorderDark: Color,
    val accentColor: Color,
    val digitColors: List<Color>,
    val flagEmoji: String,
    val mineEmoji: String,
    val isRetroBeveled: Boolean = true
)

object AvailableThemes {
    val ClassicRetro = MinesweeperTheme(
        id = "classic_retro",
        nameAr = "ريترو كلاسيكي",
        descriptionAr = "المظهر الأصلي المضلع ثلاثي الأبعاد بنمط نظام التشغيل القديم",
        boardBackground = Color(0xFFC0C0C0),
        cellUnrevealed = Color(0xFFC0C0C0),
        cellRevealed = Color(0xFFBDBDBD),
        cellBorderLight = Color(0xFFFFFFFF),
        cellBorderDark = Color(0xFF7B7B7B),
        accentColor = Color(0xFFD32F2F),
        digitColors = listOf(
            Color(0xFF0000FF), // 1 Blue
            Color(0xFF008000), // 2 Green
            Color(0xFFFF0000), // 3 Red
            Color(0xFF000080), // 4 Navy
            Color(0xFF800000), // 5 Maroon
            Color(0xFF008080), // 6 Teal
            Color(0xFF000000), // 7 Black
            Color(0xFF808080)  // 8 Gray
        ),
        flagEmoji = "🚩",
        mineEmoji = "💣",
        isRetroBeveled = true
    )

    val CyberNeon = MinesweeperTheme(
        id = "cyber_neon",
        nameAr = "سايبر نيون",
        descriptionAr = "ألوان مستقبلية داكنة مع توهج نيون ساطع",
        boardBackground = Color(0xFF0D1117),
        cellUnrevealed = Color(0xFF1E2638),
        cellRevealed = Color(0xFF131A26),
        cellBorderLight = Color(0xFF38BDF8),
        cellBorderDark = Color(0xFF0F172A),
        accentColor = Color(0xFF06B6D4),
        digitColors = listOf(
            Color(0xFF38BDF8), // 1 Cyan
            Color(0xFF4ADE80), // 2 Neon Green
            Color(0xFFF43F5E), // 3 Rose
            Color(0xFFA855F7), // 4 Purple
            Color(0xFFFBBF24), // 5 Amber
            Color(0xFF2DD4BF), // 6 Teal
            Color(0xFFE879F9), // 7 Magenta
            Color(0xFF94A3B8)  // 8 Slate
        ),
        flagEmoji = "⚡",
        mineEmoji = "💥",
        isRetroBeveled = false
    )

    val TacticalRadar = MinesweeperTheme(
        id = "tactical_radar",
        nameAr = "تكتيكي عسكري",
        descriptionAr = "شاشة رادار خضراء عسكرية مع تفاصيل تكتيكية",
        boardBackground = Color(0xFF131A12),
        cellUnrevealed = Color(0xFF223020),
        cellRevealed = Color(0xFF182216),
        cellBorderLight = Color(0xFF4ADE80),
        cellBorderDark = Color(0xFF0C120B),
        accentColor = Color(0xFF22C55E),
        digitColors = listOf(
            Color(0xFF86EFAC),
            Color(0xFF4ADE80),
            Color(0xFFF87171),
            Color(0xFFFBBF24),
            Color(0xFFA78BFA),
            Color(0xFF67E8F9),
            Color(0xFFE2E8F0),
            Color(0xFF64748B)
        ),
        flagEmoji = "📍",
        mineEmoji = "☢️",
        isRetroBeveled = false
    )

    val MinimalPastel = MinesweeperTheme(
        id = "minimal_pastel",
        nameAr = "باستيل هادئ",
        descriptionAr = "ألوان هادئة عصرية وتصميم خفيف ومريح للعين",
        boardBackground = Color(0xFFF1F5F9),
        cellUnrevealed = Color(0xFFE2E8F0),
        cellRevealed = Color(0xFFCBD5E1),
        cellBorderLight = Color(0xFFF8FAFC),
        cellBorderDark = Color(0xFF94A3B8),
        accentColor = Color(0xFF6366F1),
        digitColors = listOf(
            Color(0xFF3B82F6),
            Color(0xFF10B981),
            Color(0xFFEF4444),
            Color(0xFF8B5CF6),
            Color(0xFFF59E0B),
            Color(0xFF06B6D4),
            Color(0xFF374151),
            Color(0xFF6B7280)
        ),
        flagEmoji = "🎯",
        mineEmoji = "⚫",
        isRetroBeveled = false
    )

    val allThemes = listOf(ClassicRetro, CyberNeon, TacticalRadar, MinimalPastel)

    fun getThemeById(id: String): MinesweeperTheme {
        return allThemes.find { it.id == id } ?: ClassicRetro
    }
}
