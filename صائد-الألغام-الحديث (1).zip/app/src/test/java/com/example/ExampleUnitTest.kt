package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testFitCellSizeCalculation_ExpertFitsCompletely() {
        // Standard phone width in dp: 360dp, height: 520dp
        val containerWidth = 360f
        val containerHeight = 520f
        val boardExtraSpace = 24f

        val availWidth = containerWidth - boardExtraSpace
        val availHeight = containerHeight - boardExtraSpace

        // Expert: 16 rows, 30 columns
        val rows = 16
        val cols = 30

        val cellWidth = availWidth / cols
        val cellHeight = availHeight / rows
        val fitCellSize = minOf(cellWidth, cellHeight)

        val totalBoardWidth = fitCellSize * cols + boardExtraSpace
        val totalBoardHeight = fitCellSize * rows + boardExtraSpace

        assertTrue("Expert board width ($totalBoardWidth) must fit in container width ($containerWidth)", totalBoardWidth <= containerWidth + 0.01f)
        assertTrue("Expert board height ($totalBoardHeight) must fit in container height ($containerHeight)", totalBoardHeight <= containerHeight + 0.01f)
    }

    @Test
    fun testFitCellSizeCalculation_IntermediateFitsCompletely() {
        val containerWidth = 360f
        val containerHeight = 520f
        val boardExtraSpace = 24f

        val availWidth = containerWidth - boardExtraSpace
        val availHeight = containerHeight - boardExtraSpace

        // Intermediate: 16 rows, 16 columns
        val rows = 16
        val cols = 16

        val cellWidth = availWidth / cols
        val cellHeight = availHeight / rows
        val fitCellSize = minOf(cellWidth, cellHeight)

        val totalBoardWidth = fitCellSize * cols + boardExtraSpace
        val totalBoardHeight = fitCellSize * rows + boardExtraSpace

        assertTrue("Intermediate board width ($totalBoardWidth) must fit in container width ($containerWidth)", totalBoardWidth <= containerWidth + 0.01f)
        assertTrue("Intermediate board height ($totalBoardHeight) must fit in container height ($containerHeight)", totalBoardHeight <= containerHeight + 0.01f)
    }

    @Test
    fun testFitCellSizeCalculation_BeginnerFitsCompletely() {
        val containerWidth = 360f
        val containerHeight = 520f
        val boardExtraSpace = 24f

        val availWidth = containerWidth - boardExtraSpace
        val availHeight = containerHeight - boardExtraSpace

        // Beginner: 9 rows, 9 columns
        val rows = 9
        val cols = 9

        val cellWidth = availWidth / cols
        val cellHeight = availHeight / rows
        val fitCellSize = minOf(cellWidth, cellHeight)

        val totalBoardWidth = fitCellSize * cols + boardExtraSpace
        val totalBoardHeight = fitCellSize * rows + boardExtraSpace

        assertTrue("Beginner board width ($totalBoardWidth) must fit in container width ($containerWidth)", totalBoardWidth <= containerWidth + 0.01f)
        assertTrue("Beginner board height ($totalBoardHeight) must fit in container height ($containerHeight)", totalBoardHeight <= containerHeight + 0.01f)
    }

    @Test
    fun testClampOffsets_KeepsCenteredWhenNotOverflowing() {
        val containerWidth = 360f
        val baseBoardWidth = 340f

        // At scale 1.0, scaledW = 340 <= 360
        val scale = 1.0f
        val scaledW = baseBoardWidth * scale

        val targetX = 50f
        val clampedX = if (scaledW <= containerWidth) 0f else {
            val maxOx = (scaledW - containerWidth) / 2f
            targetX.coerceIn(-maxOx, maxOx)
        }

        assertEquals(0f, clampedX, 0.001f)
    }

    @Test
    fun testClampOffsets_RestrictsPanWhenZoomedIn() {
        val containerWidth = 360f
        val baseBoardWidth = 360f

        // At scale 2.0, scaledW = 720 > 360
        val scale = 2.0f
        val scaledW = baseBoardWidth * scale
        val maxOx = (scaledW - containerWidth) / 2f // (720 - 360) / 2 = 180f

        // Excessive pan to the right
        val targetXRight = 500f
        val clampedXRight = targetXRight.coerceIn(-maxOx, maxOx)
        assertEquals(180f, clampedXRight, 0.001f)

        // Excessive pan to the left
        val targetXLeft = -500f
        val clampedXLeft = targetXLeft.coerceIn(-maxOx, maxOx)
        assertEquals(-180f, clampedXLeft, 0.001f)
    }
}
