# Ameer AI Assistant (مساعد أمير الذكي) - V1.1

تطبيق أندرويد متطور واحترافي لمساعد الذكاء الاصطناعي **Ameer AI Assistant**، مبني بالكامل باستخدام **Kotlin** و **Jetpack Compose** وفق أفضل الممارسات البرمجية ومعمارية **Clean Architecture + MVVM** مع قاعدة بيانات محلية سريعة **Room Database**.

---

## 🌟 الجديد في الإصدار V1.1

- 📱 **إصلاح ومواءمة أزرار التنقل وشريط الإدخال (WindowInsets & Navigation Bars):**
  - دعم كامل للـ Edge-to-Edge مع ضبط دقيق لمساحات `navigationBarsPadding` و `imePadding`.
  - ظهور مربع الكتابة وزر الإرسال بشكل كامل وواضح فوق أزرار التنقل السفلية للهاتف وفوق لوحة المفاتيح في جميع الشاشات.

- 🗂️ **نظام المحادثات المتعددة والمستقلة (Multi-Conversation Management):**
  - شاشة مخصصة لسجل المحادثات (`ConversationListScreen`).
  - زر "محادثة جديدة" لإنشاء محادثة جديدة فوراً دون حذف أو التأثير على المحادثات القديمة.
  - إمكانية التبديل بين المحادثات واسترجاع سجل الرسائل الخاص بكل محادثة على حدة.
  - عرض عنوان المحادثة، تاريخ الإنشاء، وتوقيت آخر تفاعل.
  - إمكانية حذف محادثة محددة مع جميع رسائلها من قاعدة بيانات Room مع نافذة تأكيد آمنة.
  - تحديث تلقائي لعنوان المحادثة بحسب أول سؤال يُطرح في الجلسة.

---

## 🌟 المميزات الأساسية

- 💬 **واجهة محادثة عصرية (Modern Chat Interface):**
  - تصميم عصري بأسلوب Material Design 3.
  - فقاعات رسائل مميزة للمستخدم والمساعد مع إمكانية نسخ الردود وعرض وقت الإرسال.
  - مؤشر تفاعلي لحالة كتابة/تفكير المساعد الذكي.
  - التمرير التلقائي لأحدث رسالة (Auto-scroll).
  - أسئلة واقتراحات سريعة للبدء الفوري.

- 🗄️ **قاعدة بيانات محلية (Room Database Persistence):**
  - تخزين دائم لكافة المحادثات والرسائل على الجهاز.
  - تحديث واجهات المستخدم بشكل فوري وتفاعلي عبر `Kotlin Flow`.
  - عدم فقدان البيانات بعد إغلاق التطبيق.

- ⚙️ **شاشة إعدادات متكاملة (Settings Screen):**
  - تخصيص وتعديل اسم المساعد.
  - مفتاح تفعيل/تعطيل الوضع الصوتي (تجهيز للمستقبل).
  - مسح كافة المحادثات والرسائل مع نافذة تأكيد آمنة.
  - استعراض لخريطة الطريق البرمجية للمشروع.

- 🚀 **تجهيز مستقبلي كامل (Extensible Architecture):**
  - واجهات برمجية مجردة في طبقة `utils/future/`:
    - `VoiceInputManager`: تحويل الصوت إلى نص (Speech-to-Text).
    - `TtsManager`: نطق الردود صوتياً (Text-to-Speech).
    - `MemorySystem`: نظام ذاكرة وسياق المستخدم طويل الأمد.
    - `ToolSystem`: استدعاء الأدوات والوظائف البرمجية (Function Calling).

---

## 🏗️ المعمارية البرمجية (Clean Architecture + MVVM)

المشروع مقسم إلى طبقات مستقلة لضمان سهولة الاختبار والصيانة والتوسع:

```text
app/src/main/java/com/example/
├── AmeerAiApplication.kt              # فئة التطبيق الرئيسية
├── MainActivity.kt                    # نشاط التطبيق الرئيسي وإدارة الشاشات
│
├── data/                              # طبقة البيانات (Data Layer)
│   ├── local/                         # قاعدة بيانات Room (Entities, DAOs, Database)
│   ├── remote/                        # خدمات الذكاء الاصطناعي (AIService, MockAIService)
│   └── repository/                    # تنفيذ المستودعات (Repository Implementations)
│
├── domain/                            # طبقة منطق الأعمال (Domain Layer)
│   ├── model/                         # نماذج البيانات (ChatMessage, Conversation, Settings)
│   ├── repository/                    # عقود المستودعات التجريدية (Repository Interfaces)
│   └── usecase/                       # حالات الاستخدام المستقلة (CreateConversation, GetConversations, DeleteConversation, SendMessage, ...)
│
├── presentation/                      # طبقة الواجهات (Presentation Layer)
│   ├── chat/                          # شاشة ومنطق المحادثة (ChatScreen, ChatViewModel)
│   ├── conversations/                 # شاشة ومنطق سجل المحادثات (ConversationListScreen, ConversationViewModel)
│   ├── settings/                      # شاشة ومنطق الإعدادات (SettingsScreen, SettingsViewModel)
│   └── components/                    # مكونات الواجهة القابلة لإعادة الاستخدام
│
├── utils/                             # الأدوات المساعدة والتجهيز المستقبلي
│   ├── Constants.kt & DateUtils.kt
│   └── future/                        # واجهات التوسعة (Voice, TTS, Memory, Tools)
│
└── di/
    └── AppContainer.kt                # حاوية حقن الاعتماديات (Dependency Injection)
```

---

## 🛠️ المتطلبات والتقنيات (Tech Stack)

- **Language:** Kotlin 2.2+
- **UI Toolkit:** Jetpack Compose (Material 3)
- **Architecture:** Clean Architecture + MVVM
- **Local Database:** Room Database 2.7+ (مع KSP)
- **Asynchronous & Reactive:** Coroutines & Kotlin Flow
- **Build System:** Gradle (Kotlin DSL - `.gradle.kts`)
- **Compatibility:** Android 7.0 (API Level 24) فما فوق

---

## 💻 طريقة الفتح والتشغيل في Android Studio

1. قم بفك ضغط ملف المشروع `ZIP`.
2. افتح **Android Studio** واختر **Open**.
3. حدد مجلد المشروع وانتظر اكتمال مزامنة Gradle (Sync Project with Gradle Files).
4. اضغط على زر **Run ▶** لتشغيل التطبيق على محاكي (Emulator) أو جهاز حقيقي بنجاح.

---

## 📦 بناء ملف APK

لبناء ملف APK تجريبي عبر سطر الأوامر:

```bash
./gradlew assembleDebug
```

الملف الناتج سيتواجد في المسار:
`app/build/outputs/apk/debug/app-debug.apk`
