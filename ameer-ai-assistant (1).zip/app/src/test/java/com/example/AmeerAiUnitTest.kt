package com.example

import com.example.data.remote.MockAIServiceImpl
import com.example.domain.model.ChatMessage
import com.example.domain.model.Conversation
import com.example.domain.model.MessageSender
import com.example.domain.repository.AIRepository
import com.example.domain.repository.ChatRepository
import com.example.domain.usecase.CreateConversationUseCase
import com.example.domain.usecase.DeleteConversationUseCase
import com.example.domain.usecase.GetConversationsUseCase
import com.example.domain.usecase.SendMessageUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AmeerAiUnitTest {

    @Test
    fun testMockAIServiceResponses() = runTest {
        val service = MockAIServiceImpl()
        val arabicReply = service.generateCompletion(
            prompt = "مرحبا",
            history = emptyList(),
            assistantName = "Ameer AI"
        )
        assertNotNull(arabicReply)
        assertTrue(arabicReply.contains("وعليكم السلام") || arabicReply.contains("أهلاً بك"))

        val englishReply = service.generateCompletion(
            prompt = "hello",
            history = emptyList(),
            assistantName = "Ameer AI"
        )
        assertNotNull(englishReply)
        assertTrue(englishReply.contains("Ameer AI"))
    }

    @Test
    fun testSendMessageUseCaseSuccess() = runTest {
        val mockMessages = mutableListOf<ChatMessage>()
        val mockConversations = mutableListOf(
            Conversation(id = 1L, title = "Main")
        )

        val fakeChatRepository = object : ChatRepository {
            override fun getMessages(conversationId: Long): Flow<List<ChatMessage>> = flowOf(mockMessages)
            override suspend fun insertMessage(message: ChatMessage): Long {
                val newId = (mockMessages.size + 1).toLong()
                mockMessages.add(message.copy(id = newId))
                return newId
            }
            override suspend fun deleteMessage(messageId: Long) {
                mockMessages.removeAll { it.id == messageId }
            }
            override suspend fun clearMessages(conversationId: Long) {
                mockMessages.clear()
            }
            override fun getConversations(): Flow<List<Conversation>> = flowOf(mockConversations)
            override suspend fun createConversation(title: String): Conversation {
                val newConv = Conversation(id = (mockConversations.size + 1).toLong(), title = title)
                mockConversations.add(newConv)
                return newConv
            }
            override suspend fun getConversationById(id: Long): Conversation? {
                return mockConversations.find { it.id == id }
            }
            override suspend fun updateConversationTitle(id: Long, title: String) {
                val idx = mockConversations.indexOfFirst { it.id == id }
                if (idx != -1) {
                    mockConversations[idx] = mockConversations[idx].copy(title = title)
                }
            }
            override suspend fun deleteConversation(conversationId: Long) {
                mockConversations.removeAll { it.id == conversationId }
                mockMessages.removeAll { it.conversationId == conversationId }
            }
            override suspend fun getOrCreateDefaultConversation(): Conversation {
                return mockConversations.first()
            }
        }

        val fakeAiRepository = object : AIRepository {
            override suspend fun generateResponse(
                prompt: String,
                history: List<ChatMessage>,
                assistantName: String
            ): Result<String> {
                return Result.success("This is a response to $prompt from $assistantName")
            }
        }

        val useCase = SendMessageUseCase(fakeChatRepository, fakeAiRepository)
        val result = useCase(
            content = "How are you?",
            conversationId = 1L,
            currentHistory = emptyList(),
            assistantName = "Ameer AI"
        )

        assertTrue(result.isSuccess)
        val assistantMessage = result.getOrThrow()
        assertEquals(MessageSender.ASSISTANT, assistantMessage.sender)
        assertTrue(assistantMessage.content.contains("How are you?"))
        assertEquals(2, mockMessages.size)
        assertEquals(MessageSender.USER, mockMessages[0].sender)
        assertEquals(MessageSender.ASSISTANT, mockMessages[1].sender)
    }

    @Test
    fun testConversationManagementUseCases() = runTest {
        val conversations = mutableListOf(
            Conversation(id = 1L, title = "المحادثة الأولى")
        )

        val fakeChatRepository = object : ChatRepository {
            override fun getMessages(conversationId: Long): Flow<List<ChatMessage>> = flowOf(emptyList())
            override suspend fun insertMessage(message: ChatMessage): Long = 1L
            override suspend fun deleteMessage(messageId: Long) {}
            override suspend fun clearMessages(conversationId: Long) {}
            override fun getConversations(): Flow<List<Conversation>> = flowOf(conversations)
            override suspend fun createConversation(title: String): Conversation {
                val conv = Conversation(id = (conversations.size + 1).toLong(), title = title)
                conversations.add(conv)
                return conv
            }
            override suspend fun getConversationById(id: Long): Conversation? = conversations.find { it.id == id }
            override suspend fun updateConversationTitle(id: Long, title: String) {}
            override suspend fun deleteConversation(conversationId: Long) {
                conversations.removeAll { it.id == conversationId }
            }
            override suspend fun getOrCreateDefaultConversation(): Conversation = conversations.first()
        }

        val createUseCase = CreateConversationUseCase(fakeChatRepository)
        val getUseCase = GetConversationsUseCase(fakeChatRepository)
        val deleteUseCase = DeleteConversationUseCase(fakeChatRepository)

        val created = createUseCase("محادثة الذكاء الاصطناعي")
        assertEquals(2L, created.id)
        assertEquals("محادثة الذكاء الاصطناعي", created.title)

        val list = getUseCase().first()
        assertEquals(2, list.size)

        deleteUseCase(1L)
        val remaining = getUseCase().first()
        assertEquals(1, remaining.size)
        assertEquals(2L, remaining[0].id)
    }
}
