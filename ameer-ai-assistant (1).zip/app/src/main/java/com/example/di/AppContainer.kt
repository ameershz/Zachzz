package com.example.di

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.remote.AIService
import com.example.data.remote.MockAIServiceImpl
import com.example.data.repository.AIRepositoryImpl
import com.example.data.repository.ChatRepositoryImpl
import com.example.data.repository.SettingsRepositoryImpl
import com.example.domain.repository.AIRepository
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.SettingsRepository
import com.example.domain.usecase.ClearChatUseCase
import com.example.domain.usecase.CreateConversationUseCase
import com.example.domain.usecase.DeleteConversationUseCase
import com.example.domain.usecase.GetAssistantSettingsUseCase
import com.example.domain.usecase.GetConversationsUseCase
import com.example.domain.usecase.GetMessagesUseCase
import com.example.domain.usecase.SelectConversationUseCase
import com.example.domain.usecase.SendMessageUseCase
import com.example.domain.usecase.UpdateAssistantSettingsUseCase

/**
 * Dependency container providing single-source-of-truth instances
 * for Database, Remote Services, Repositories, and UseCases without
 * adding heavy annotation-processing DI frameworks.
 */
class AppContainer(context: Context) {

    private val database: AppDatabase by lazy {
        AppDatabase.getDatabase(context)
    }

    val aiService: AIService by lazy {
        MockAIServiceImpl()
    }

    val aiRepository: AIRepository by lazy {
        AIRepositoryImpl(aiService)
    }

    val chatRepository: ChatRepository by lazy {
        ChatRepositoryImpl(
            conversationDao = database.conversationDao(),
            messageDao = database.messageDao()
        )
    }

    val settingsRepository: SettingsRepository by lazy {
        SettingsRepositoryImpl(context)
    }

    // UseCases
    val sendMessageUseCase: SendMessageUseCase by lazy {
        SendMessageUseCase(chatRepository, aiRepository)
    }

    val getMessagesUseCase: GetMessagesUseCase by lazy {
        GetMessagesUseCase(chatRepository)
    }

    val clearChatUseCase: ClearChatUseCase by lazy {
        ClearChatUseCase(chatRepository)
    }

    val getAssistantSettingsUseCase: GetAssistantSettingsUseCase by lazy {
        GetAssistantSettingsUseCase(settingsRepository)
    }

    val updateAssistantSettingsUseCase: UpdateAssistantSettingsUseCase by lazy {
        UpdateAssistantSettingsUseCase(settingsRepository)
    }

    val createConversationUseCase: CreateConversationUseCase by lazy {
        CreateConversationUseCase(chatRepository)
    }

    val getConversationsUseCase: GetConversationsUseCase by lazy {
        GetConversationsUseCase(chatRepository)
    }

    val deleteConversationUseCase: DeleteConversationUseCase by lazy {
        DeleteConversationUseCase(chatRepository)
    }

    val selectConversationUseCase: SelectConversationUseCase by lazy {
        SelectConversationUseCase(chatRepository)
    }
}
