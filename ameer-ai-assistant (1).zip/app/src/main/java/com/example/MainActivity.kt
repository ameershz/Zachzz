package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.presentation.chat.ChatScreen
import com.example.presentation.chat.ChatViewModel
import com.example.presentation.conversations.ConversationListScreen
import com.example.presentation.conversations.ConversationViewModel
import com.example.presentation.settings.SettingsScreen
import com.example.presentation.settings.SettingsViewModel
import com.example.ui.theme.MyApplicationTheme

enum class AppScreen {
    CHAT,
    CONVERSATIONS,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = application as AmeerAiApplication
        val container = app.container

        val chatViewModelFactory = ChatViewModel.Factory(
            sendMessageUseCase = container.sendMessageUseCase,
            getMessagesUseCase = container.getMessagesUseCase,
            clearChatUseCase = container.clearChatUseCase,
            getAssistantSettingsUseCase = container.getAssistantSettingsUseCase,
            createConversationUseCase = container.createConversationUseCase,
            selectConversationUseCase = container.selectConversationUseCase
        )

        val conversationViewModelFactory = ConversationViewModel.Factory(
            getConversationsUseCase = container.getConversationsUseCase,
            createConversationUseCase = container.createConversationUseCase,
            deleteConversationUseCase = container.deleteConversationUseCase
        )

        val settingsViewModelFactory = SettingsViewModel.Factory(
            getSettingsUseCase = container.getAssistantSettingsUseCase,
            updateSettingsUseCase = container.updateAssistantSettingsUseCase,
            clearChatUseCase = container.clearChatUseCase
        )

        setContent {
            MyApplicationTheme {
                var currentScreen by remember { mutableStateOf(AppScreen.CHAT) }

                val chatViewModel: ChatViewModel = viewModel(factory = chatViewModelFactory)
                val conversationViewModel: ConversationViewModel = viewModel(factory = conversationViewModelFactory)
                val settingsViewModel: SettingsViewModel = viewModel(factory = settingsViewModelFactory)

                val chatUiState by chatViewModel.uiState.collectAsStateWithLifecycle()
                val conversationUiState by conversationViewModel.uiState.collectAsStateWithLifecycle()
                val settingsUiState by settingsViewModel.uiState.collectAsStateWithLifecycle()

                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "ScreenTransition"
                ) { screen ->
                    when (screen) {
                        AppScreen.CHAT -> {
                            ChatScreen(
                                uiState = chatUiState,
                                onInputTextChanged = chatViewModel::onInputTextChanged,
                                onSendMessage = { prompt -> chatViewModel.sendMessage(prompt) },
                                onOpenConversations = {
                                    conversationViewModel.setSelectedConversation(chatUiState.currentConversationId)
                                    currentScreen = AppScreen.CONVERSATIONS
                                },
                                onNewChatClick = {
                                    chatViewModel.startNewConversation { newId ->
                                        conversationViewModel.setSelectedConversation(newId)
                                    }
                                },
                                onNavigateToSettings = { currentScreen = AppScreen.SETTINGS },
                                onClearChatClick = chatViewModel::showClearDialog,
                                onConfirmClearChat = chatViewModel::confirmClearChat,
                                onDismissClearDialog = chatViewModel::dismissClearDialog,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        AppScreen.CONVERSATIONS -> {
                            ConversationListScreen(
                                uiState = conversationUiState,
                                onConversationSelected = { id ->
                                    chatViewModel.switchConversation(id)
                                    conversationViewModel.setSelectedConversation(id)
                                    currentScreen = AppScreen.CHAT
                                },
                                onNewConversationClick = {
                                    conversationViewModel.createNewConversation { newId ->
                                        chatViewModel.switchConversation(newId)
                                        currentScreen = AppScreen.CHAT
                                    }
                                },
                                onDeleteConversationClick = conversationViewModel::promptDeleteConversation,
                                onDismissDeleteDialog = conversationViewModel::dismissDeleteDialog,
                                onConfirmDeleteConversation = {
                                    conversationViewModel.confirmDeleteConversation { newActiveId ->
                                        chatViewModel.switchConversation(newActiveId)
                                    }
                                },
                                onNavigateBack = { currentScreen = AppScreen.CHAT },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        AppScreen.SETTINGS -> {
                            SettingsScreen(
                                uiState = settingsUiState,
                                onNavigateBack = { currentScreen = AppScreen.CHAT },
                                onNameInputChanged = settingsViewModel::onNameInputChanged,
                                onSaveName = settingsViewModel::saveAssistantName,
                                onSetEditingName = settingsViewModel::setEditingName,
                                onToggleVoiceMode = settingsViewModel::toggleVoiceMode,
                                onShowClearDialog = settingsViewModel::showClearDialog,
                                onDismissClearDialog = settingsViewModel::dismissClearDialog,
                                onConfirmClear = settingsViewModel::confirmClearAllConversations,
                                onSnackbarShown = settingsViewModel::clearSnackbar,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }
    }
}
