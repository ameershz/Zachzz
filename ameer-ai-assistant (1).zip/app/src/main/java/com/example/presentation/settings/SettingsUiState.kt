package com.example.presentation.settings

data class SettingsUiState(
    val assistantName: String = "Ameer AI",
    val isVoiceModeEnabled: Boolean = false,
    val isEditingName: Boolean = false,
    val nameInputText: String = "Ameer AI",
    val isClearDialogOpen: Boolean = false,
    val messageSnackbar: String? = null
)
