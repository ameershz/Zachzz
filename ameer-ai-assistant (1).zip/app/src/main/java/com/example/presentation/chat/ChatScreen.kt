package com.example.presentation.chat

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.presentation.components.ChatInputField
import com.example.presentation.components.ChatTopBar
import com.example.presentation.components.MessageBubble
import com.example.presentation.components.SuggestionsRow
import com.example.presentation.components.TypingIndicator

@Composable
fun ChatScreen(
    uiState: ChatUiState,
    onInputTextChanged: (String) -> Unit,
    onSendMessage: (String?) -> Unit,
    onOpenConversations: () -> Unit,
    onNewChatClick: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onClearChatClick: () -> Unit,
    onConfirmClearChat: () -> Unit,
    onDismissClearDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    // Scroll to bottom when new messages arrive or when generating response
    LaunchedEffect(uiState.messages.size, uiState.isGenerating) {
        val totalCount = uiState.messages.size + (if (uiState.isGenerating) 1 else 0)
        if (totalCount > 0) {
            listState.animateScrollToItem(totalCount - 1)
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            ChatTopBar(
                assistantName = uiState.assistantName,
                conversationTitle = uiState.currentConversationTitle,
                onOpenConversations = onOpenConversations,
                onNewChatClick = onNewChatClick,
                onNavigateToSettings = onNavigateToSettings,
                onClearChatClick = onClearChatClick
            )
        },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (uiState.messages.isNotEmpty()) {
                    SuggestionsRow(
                        suggestions = uiState.suggestions,
                        onSuggestionClick = { onSendMessage(it) }
                    )
                }
                ChatInputField(
                    inputText = uiState.inputText,
                    onInputTextChanged = onInputTextChanged,
                    onSendMessage = { onSendMessage(null) },
                    isEnabled = !uiState.isGenerating
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (uiState.messages.isEmpty()) {
                // Empty State with Welcome Card & Quick Chips
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "مرحباً بك في ${uiState.assistantName}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = uiState.currentConversationTitle,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "مساعدك الذكي الشخصي V1.1 مع دعم تعدد المحادثات وحفظها في Room Database.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "💡 أسئلة واقتراحات سريعة للبدء:",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            uiState.suggestions.forEach { suggestion ->
                                TextButton(
                                    onClick = { onSendMessage(suggestion) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "• $suggestion",
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.fillMaxWidth(),
                                        textAlign = TextAlign.Start
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Messages List
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(vertical = 12.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("chat_messages_list")
                ) {
                    items(
                        items = uiState.messages,
                        key = { it.id }
                    ) { message ->
                        MessageBubble(
                            message = message,
                            assistantName = uiState.assistantName
                        )
                    }

                    if (uiState.isGenerating) {
                        item(key = "typing_indicator") {
                            TypingIndicator(assistantName = uiState.assistantName)
                        }
                    }
                }
            }
        }
    }

    // Confirmation dialog for clearing messages of current conversation
    if (uiState.isClearDialogOpen) {
        AlertDialog(
            onDismissRequest = onDismissClearDialog,
            title = {
                Text(
                    text = stringResource(id = R.string.clear_chat),
                    style = MaterialTheme.typography.titleLarge
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في حذف جميع رسائل \"${uiState.currentConversationTitle}\"؟",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                TextButton(
                    onClick = onConfirmClearChat,
                    modifier = Modifier.testTag("confirm_clear_button")
                ) {
                    Text(
                        text = stringResource(id = R.string.delete),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = onDismissClearDialog,
                    modifier = Modifier.testTag("cancel_clear_button")
                ) {
                    Text(text = stringResource(id = R.string.cancel))
                }
            }
        )
    }
}
