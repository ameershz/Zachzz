package com.example.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.domain.usecase.ClearChatUseCase
import com.example.domain.usecase.GetAssistantSettingsUseCase
import com.example.domain.usecase.UpdateAssistantSettingsUseCase
import com.example.utils.Constants
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val getSettingsUseCase: GetAssistantSettingsUseCase,
    private val updateSettingsUseCase: UpdateAssistantSettingsUseCase,
    private val clearChatUseCase: ClearChatUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        observeSettings()
    }

    private fun observeSettings() {
        viewModelScope.launch {
            getSettingsUseCase().collect { settings ->
                _uiState.update {
                    it.copy(
                        assistantName = settings.assistantName,
                        nameInputText = settings.assistantName,
                        isVoiceModeEnabled = settings.isVoiceModeEnabled
                    )
                }
            }
        }
    }

    fun onNameInputChanged(newName: String) {
        _uiState.update { it.copy(nameInputText = newName) }
    }

    fun saveAssistantName() {
        val newName = _uiState.value.nameInputText.trim()
        if (newName.isNotEmpty()) {
            viewModelScope.launch {
                updateSettingsUseCase.updateName(newName)
                _uiState.update {
                    it.copy(
                        isEditingName = false,
                        messageSnackbar = "تم تحديث اسم المساعد بنجاح"
                    )
                }
            }
        }
    }

    fun setEditingName(editing: Boolean) {
        _uiState.update {
            it.copy(
                isEditingName = editing,
                nameInputText = it.assistantName
            )
        }
    }

    fun toggleVoiceMode(enabled: Boolean) {
        viewModelScope.launch {
            updateSettingsUseCase.toggleVoice(enabled)
            _uiState.update {
                it.copy(
                    messageSnackbar = if (enabled) {
                        "تم تفعيل وضع الصوت (مُجهز للتكامل مع V2 Voice Layer)"
                    } else {
                        "تم إيقاف وضع الصوت"
                    }
                )
            }
        }
    }

    fun showClearDialog() {
        _uiState.update { it.copy(isClearDialogOpen = true) }
    }

    fun dismissClearDialog() {
        _uiState.update { it.copy(isClearDialogOpen = false) }
    }

    fun confirmClearAllConversations() {
        viewModelScope.launch {
            clearChatUseCase(Constants.DEFAULT_CONVERSATION_ID)
            _uiState.update {
                it.copy(
                    isClearDialogOpen = false,
                    messageSnackbar = "تم مسح المحادثات والرسائل بنجاح"
                )
            }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(messageSnackbar = null) }
    }

    class Factory(
        private val getSettingsUseCase: GetAssistantSettingsUseCase,
        private val updateSettingsUseCase: UpdateAssistantSettingsUseCase,
        private val clearChatUseCase: ClearChatUseCase
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(
                getSettingsUseCase = getSettingsUseCase,
                updateSettingsUseCase = updateSettingsUseCase,
                clearChatUseCase = clearChatUseCase
            ) as T
        }
    }
}
