package com.example.data.remote

import com.example.domain.model.ChatMessage
import kotlinx.coroutines.delay

/**
 * Mock implementation of AIService for V1.
 * Delivers context-aware, structured responses in Arabic and English,
 * and simulates realistic AI generation latency.
 */
class MockAIServiceImpl : AIService {

    override suspend fun generateCompletion(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String
    ): String {
        // Simulate realistic network & inference delay
        delay(1100)

        val clean = prompt.trim().lowercase()

        return when {
            // Identity / Who are you
            clean.contains("من أنت") || clean.contains("اسمك") || clean.contains("who are you") || clean.contains("your name") -> {
                "أهلاً بك! أنا **$assistantName**، مساعدك الذكي المخصص لخدمتك.\n\n" +
                        "تم تصميمي ببنية حديثة (Clean MVVM Architecture) مع قاعدة بيانات Room محلية لحفظ المحادثات والرسائل.\n" +
                        "كيف يمكنني مساعدتك اليوم؟"
            }

            // Arabic Greetings
            clean.contains("مرحبا") || clean.contains("سلام") || clean.contains("أهلا") || clean.contains("مساء الخير") || clean.contains("صباح الخير") -> {
                "وعليكم السلام ورحمة الله وبركاته! أهلاً بك وسهلاً.\n\n" +
                        "أنا هنا لمساعدتك في كتابة الأكواد، التخطيط، الإجابة على الأسئلة، أو تبادل الأفكار.\n" +
                        "ما الذي يشغل بالك اليوم؟ ✨"
            }

            // English Greetings
            clean.contains("hello") || clean.contains("hi") || clean.contains("hey") || clean.contains("good morning") || clean.contains("good evening") -> {
                "Hello there! I am **$assistantName**, your personal AI assistant.\n\n" +
                        "How can I empower your productivity today? Feel free to ask anything about coding, planning, or brainstorming!"
            }

            // Code & Development
            clean.contains("كود") || clean.contains("برمجة") || clean.contains("kotlin") || clean.contains("compose") || clean.contains("code") || clean.contains("android") -> {
                "إليك نموذج برمجي بلغة **Kotlin** مع **Jetpack Compose**:\n\n" +
                        "```kotlin\n" +
                        "@Composable\n" +
                        "fun AssistantGreeting(name: String) {\n" +
                        "    Card(\n" +
                        "        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),\n" +
                        "        modifier = Modifier.padding(16.dp)\n" +
                        "    ) {\n" +
                        "        Text(\n" +
                        "            text = \"مرحباً من \$name!\",\n" +
                        "            style = MaterialTheme.typography.titleMedium,\n" +
                        "            modifier = Modifier.padding(16.dp)\n" +
                        "        )\n" +
                        "    }\n" +
                        "}\n" +
                        "```\n\n" +
                        "هذا الكود يتبع أحدث معايير Material 3. هل تود أن نوسعه بمزيد من الميزات؟"
            }

            // Planning & Productivity
            clean.contains("خطة") || clean.contains("تنظيم") || clean.contains("plan") || clean.contains("organize") || clean.contains("todo") -> {
                "إليك مقترح خطة عمل ذكية ومرتبة لهذا اليوم:\n\n" +
                        "1. **المهمة المركزية (الأولوية القصوى):** إنجاز أهم هدف في الصباح الباكر.\n" +
                        "2. **جلسة تركيز بنظام بومودورو (25/5):** تركيز كامل بدون مشتتات.\n" +
                        "3. **مراجعة التقدم والتنقيح:** فحص ما تم إنجازه وإعادة الترتيب.\n" +
                        "4. **استراحة تجديد الطاقة:** شرب الماء وأخذ نزهة قصيرة.\n\n" +
                        "هل تحب أن نحدد تفاصيل مهمتك الأساسية الآن؟"
            }

            // Architecture / Future readiness
            clean.contains("معمارية") || clean.contains("architecture") || clean.contains("v2") || clean.contains("مستقبل") -> {
                "تطبيق **$assistantName** جاهز للمستقبل بالكامل:\n\n" +
                        "• **Voice Input:** طبقة مجهزة لاستقبال الأوامر الصوتية وتحويل الصوت لنص.\n" +
                        "• **Text To Speech:** مجهزة لقراءة ردود المساعد صوتياً.\n" +
                        "• **Memory System:** بنية مخصصة للذاكرة الدائمة وتخزين السياق.\n" +
                        "• **Tools System:** نظام استدعاء الأدوات الخارجية (Function Calling).\n\n" +
                        "كل هذه الطبقات تم إنشاؤها وفق Clean Architecture لسهولة التفعيل في التحديث القادم!"
            }

            // General / Default response
            else -> {
                "شكراً على رسالتك: \"$prompt\"\n\n" +
                        "بصفتي **$assistantName**، قمت بمعالجة طلبك وحفظ المحادثة محلياً في قاعدة بيانات Room.\n\n" +
                        "• رد ذكي سريع وموثوق.\n" +
                        "• جاهز لتنفيذ أوامرك القادمة.\n\n" +
                        "هل تريد استكشاف المزيد أو مناقشة فكرة جديدة؟"
            }
        }
    }
}
