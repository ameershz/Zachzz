package com.example.data.repository

import com.example.data.remote.AIService
import com.example.domain.model.ChatMessage
import com.example.domain.repository.AIRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AIRepositoryImpl(
    private val aiService: AIService
) : AIRepository {

    override suspend fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        assistantName: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val reply = aiService.generateCompletion(prompt, history, assistantName)
            Result.success(reply)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
