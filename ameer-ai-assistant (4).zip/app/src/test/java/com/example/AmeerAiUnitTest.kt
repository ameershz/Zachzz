package com.example

import com.example.aicore.engine.AICoreEngineImpl
import com.example.aicore.knowledge.KnowledgeManager
import com.example.aicore.knowledge.KnowledgeManagerImpl
import com.example.aicore.localmodel.DownloadState
import com.example.aicore.localmodel.HardwareBackend
import com.example.aicore.localmodel.LocalAIService
import com.example.aicore.localmodel.LocalAIServiceImpl
import com.example.aicore.localmodel.LocalInferenceEngine
import com.example.aicore.localmodel.LocalInferenceEngineImpl
import com.example.aicore.localmodel.LocalModelDescriptor
import com.example.aicore.localmodel.LocalModelMode
import com.example.aicore.localmodel.ModelDownloader
import com.example.aicore.localmodel.ModelDownloaderImpl
import com.example.aicore.localmodel.ModelFormat
import com.example.aicore.localmodel.ModelLoader
import com.example.aicore.localmodel.ModelLoaderImpl
import com.example.aicore.localmodel.ModelLoadingState
import com.example.aicore.localmodel.ModelQuantization
import com.example.aicore.localmodel.ModelSelector
import com.example.aicore.localmodel.ModelSelectorImpl
import com.example.aicore.localmodel.ModelTier
import com.example.aicore.memory.MemoryManager
import com.example.aicore.memory.MemoryManagerImpl
import com.example.aicore.model.AIModel
import com.example.aicore.model.LocalModelInfo
import com.example.aicore.model.ModelManager
import com.example.aicore.model.ModelManagerImpl
import com.example.aicore.personality.AssistantPersonality
import com.example.aicore.personality.AssistantRule
import com.example.aicore.personality.PersonalityManager
import com.example.aicore.personality.PersonalityManagerImpl
import com.example.aicore.personality.PersonalityStyle
import com.example.domain.model.ChatMessage
import com.example.domain.model.Conversation
import com.example.domain.model.MemoryCategory
import com.example.domain.model.MemoryItem
import com.example.domain.model.MessageSender
import com.example.domain.model.knowledge.KnowledgeCategory
import com.example.domain.model.knowledge.KnowledgeChunk
import com.example.domain.model.knowledge.KnowledgeItem
import com.example.domain.model.knowledge.KnowledgeSourceType
import com.example.domain.model.knowledge.RagContext
import com.example.domain.repository.AIRepository
import com.example.domain.repository.ChatRepository
import com.example.domain.repository.KnowledgeRepository
import com.example.domain.repository.MemoryRepository
import com.example.domain.usecase.ClearChatUseCase
import com.example.domain.usecase.CreateConversationUseCase
import com.example.domain.usecase.DeleteConversationUseCase
import com.example.domain.usecase.GetConversationsUseCase
import com.example.domain.usecase.SendMessageUseCase
import com.example.domain.usecase.knowledge.ClearAllKnowledgeUseCase
import com.example.domain.usecase.knowledge.DeleteKnowledgeUseCase
import com.example.domain.usecase.knowledge.GetKnowledgeBaseUseCase
import com.example.domain.usecase.knowledge.RetrieveKnowledgeUseCase
import com.example.domain.usecase.knowledge.SaveKnowledgeUseCase
import com.example.domain.usecase.knowledge.SearchKnowledgeUseCase
import com.example.domain.usecase.knowledge.UpdateKnowledgeUseCase
import com.example.domain.usecase.memory.ClearAllMemoriesUseCase
import com.example.domain.usecase.memory.DeleteMemoryUseCase
import com.example.domain.usecase.memory.GetMemoriesUseCase
import com.example.domain.usecase.memory.SaveMemoryUseCase
import com.example.domain.usecase.memory.SearchMemoriesUseCase
import com.example.domain.usecase.memory.UpdateMemoryUseCase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AmeerAiUnitTest {

    @Test
    fun testQwenRealModelDescriptorAndFields() {
        val qwen = LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM
        assertEquals("qwen2.5-1.5b-instruct-gguf-q4km", qwen.id)
        assertEquals("Qwen2.5-1.5B-Instruct GGUF Q4_K_M", qwen.name)
        assertEquals("https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf", qwen.downloadUrl)
        assertEquals(986L * 1024 * 1024, qwen.sizeBytes)
        assertEquals(ModelQuantization.Q4_K_M, qwen.quantization)
        assertEquals(1200, qwen.requiredRamMb)
        assertEquals(ModelFormat.GGUF, qwen.format)
        assertEquals("qwen2.5-1.5b-instruct-q4_k_m.gguf", qwen.localFileName)
        assertTrue(qwen.descriptionAr.contains("النموذج الذكي"))
        assertFalse(qwen.isBundledReady)
    }

    @Test
    fun testMultiModelTiersAndDescriptors() {
        val descriptors = LocalModelDescriptor.getAvailableDescriptors()
        assertTrue(descriptors.isNotEmpty())

        val fastDescriptors = LocalModelDescriptor.getFastModeDescriptors()
        assertTrue(fastDescriptors.isNotEmpty())
        fastDescriptors.forEach { assertEquals(ModelTier.FAST_TIER, it.tier) }

        val proDescriptors = LocalModelDescriptor.getProModeDescriptors()
        assertTrue(proDescriptors.isNotEmpty())
        proDescriptors.forEach { assertEquals(ModelTier.PRO_TIER, it.tier) }

        val fastCore = LocalModelDescriptor.AMEER_FAST_CORE
        assertEquals("ameer-fast-core-v1", fastCore.id)
        assertEquals(ModelFormat.NATIVE_CORE, fastCore.format)
        assertEquals(ModelQuantization.Q4_0, fastCore.quantization)
        assertEquals(HardwareBackend.CPU_THREADED, fastCore.backend)
        assertTrue(fastCore.isBundledReady)

        val proCore = LocalModelDescriptor.AMEER_PRO_CORE
        assertEquals("ameer-pro-core-v1", proCore.id)
        assertEquals(ModelTier.PRO_TIER, proCore.tier)
        assertEquals(ModelQuantization.Q8_0, proCore.quantization)

        val llamaGguf = LocalModelDescriptor.LLAMA_3_2_1B_FAST_GGUF
        assertEquals(ModelFormat.GGUF, llamaGguf.format)
        assertEquals(".gguf", llamaGguf.format.extension)
        assertEquals("llama-3.2-1b-instruct-q4_k_m.gguf", llamaGguf.localFileName)

        val gemmaGguf = LocalModelDescriptor.GEMMA_2_2B_PRO_GGUF
        assertEquals(HardwareBackend.GPU_VULKAN, gemmaGguf.backend)
    }

    @Test
    fun testModelDownloaderStatesAndControl() = runTest {
        val downloader: ModelDownloader = ModelDownloaderImpl()
        val qwen = LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM

        // Bundled model is always considered downloaded
        assertTrue(downloader.isModelDownloaded(LocalModelDescriptor.AMEER_FAST_CORE))

        // Initial state for non-bundled model
        val statesMap = downloader.modelDownloadStates.value
        val initialDownloadState = statesMap[qwen.id] ?: DownloadState.Idle
        assertNotNull(initialDownloadState)

        // Start download flow
        val startResult = downloader.startDownload(qwen)
        assertTrue(startResult.isSuccess)

        // Pause
        downloader.pauseDownload(qwen.id)
        val paused = downloader.modelDownloadStates.value[qwen.id]
        assertNotNull(paused)

        // Resume
        val resumeResult = downloader.resumeDownload(qwen)
        assertTrue(resumeResult.isSuccess)
    }

    @Test
    fun testModelManagerOnDeviceInventory() = runTest {
        val loader = ModelLoaderImpl()
        val downloader = ModelDownloaderImpl()
        val manager: ModelManager = ModelManagerImpl(
            context = null,
            modelLoader = loader,
            modelDownloader = downloader
        )

        val modelsInfo = manager.localModelsInfo.value
        assertTrue(modelsInfo.isNotEmpty())

        val qwenInfo = modelsInfo.find { it.descriptor.id == LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM.id }
        assertNotNull(qwenInfo)
        assertEquals("Qwen2.5-1.5B-Instruct GGUF Q4_K_M", qwenInfo?.descriptor?.name)

        // Select model
        val selected = manager.selectModel(LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM.id)
        assertTrue(selected)
        assertEquals(LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM.id, manager.activeModel.value.id)
    }

    @Test
    fun testLocalAIServiceNotDownloadedGuidance() = runTest {
        val loader = ModelLoaderImpl()
        val downloader = ModelDownloaderImpl()
        loader.loadModel(LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM)

        val localService = LocalAIServiceImpl(
            modelLoader = loader,
            modelDownloader = downloader,
            inferenceEngine = LocalInferenceEngineImpl()
        )

        val response = localService.generateCompletion(
            prompt = "ما هي عاصمة فرنسا؟",
            history = emptyList(),
            assistantName = "Ameer AI"
        )

        assertNotNull(response)
        // Since Qwen is not downloaded by default on blank system, should offer clear guidance banner
        assertTrue(
            response.contains("تنبيه العقل المحلي") ||
            response.contains("إدارة العقل المحلي") ||
            response.contains("باريس") ||
            response.contains("فرنسا") ||
            response.contains("Ameer") ||
            response.contains("الذكاء الاصطناعي")
        )
    }

    @Test
    fun testModelSelectorAndDeviceCapabilityAnalysis() = runTest {
        val loader = ModelLoaderImpl()
        val selector: ModelSelector = ModelSelectorImpl(loader)

        val report = selector.deviceCapabilityReport
        assertTrue(report.cpuCores >= 1)
        assertTrue(report.totalRamMb > 0)
        assertNotNull(report.ramTier)
        assertNotNull(report.recommendedTier)
        assertTrue(report.recommendationReasonAr.isNotBlank())

        // Test Switching to Fast Mode
        val fastResult = selector.setMode(LocalModelMode.FAST)
        assertTrue(fastResult)
        assertEquals(LocalModelMode.FAST, selector.activeMode.value)
        assertEquals(ModelTier.FAST_TIER, selector.activeDescriptor.value.tier)

        // Test Switching to Pro Mode
        val proResult = selector.setMode(LocalModelMode.PRO)
        assertTrue(proResult)
        assertEquals(LocalModelMode.PRO, selector.activeMode.value)
        assertEquals(ModelTier.PRO_TIER, selector.activeDescriptor.value.tier)

        // Test Switching to Auto Adaptive
        val autoResult = selector.setMode(LocalModelMode.AUTO_ADAPTIVE)
        assertTrue(autoResult)
        assertEquals(LocalModelMode.AUTO_ADAPTIVE, selector.activeMode.value)

        // Test explicit model selection
        val explicitSuccess = selector.selectExplicitModel(LocalModelDescriptor.LLAMA_3_2_1B_FAST_GGUF.id)
        assertTrue(explicitSuccess)
        assertEquals(LocalModelDescriptor.LLAMA_3_2_1B_FAST_GGUF.id, selector.activeDescriptor.value.id)
    }

    @Test
    fun testModelLoaderLifecycle() = runTest {
        val loader = ModelLoaderImpl()
        val initialState = loader.loadingState.value
        assertTrue(initialState is ModelLoadingState.ModelLoaded)

        val hwInfo = loader.getHardwareInfo()
        assertTrue(hwInfo.availableCores >= 1)
        assertTrue(hwInfo.recommendedThreads >= 2)

        // Load GGUF model
        val loadResult = loader.loadModel(LocalModelDescriptor.LLAMA_3_2_1B_FAST_GGUF)
        assertTrue(loadResult.isSuccess)
        assertEquals(LocalModelDescriptor.LLAMA_3_2_1B_FAST_GGUF.id, loader.activeDescriptor.value.id)

        val finalState = loader.loadingState.value
        assertTrue(finalState is ModelLoadingState.ModelLoaded)
        val loaded = finalState as ModelLoadingState.ModelLoaded
        assertEquals(LocalModelDescriptor.LLAMA_3_2_1B_FAST_GGUF.id, loaded.descriptor.id)

        // Unload
        loader.unloadModel()
        assertTrue(loader.loadingState.value is ModelLoadingState.Unloaded)
    }

    @Test
    fun testGgufInferenceEngineExecution() = runTest {
        val ggufEngine = com.example.aicore.localmodel.GgufInferenceEngine()
        val tempGgufFile = java.io.File.createTempFile("qwen2.5-test", ".gguf")
        // Write mock GGUF v3 header magic bytes
        java.io.FileOutputStream(tempGgufFile).use { fos ->
            val buf = java.nio.ByteBuffer.allocate(24).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            buf.putInt(com.example.aicore.localmodel.GGUF_MAGIC_LE)
            buf.putInt(3) // version 3
            buf.putLong(290L) // tensor count
            buf.putLong(32L) // kv count
            fos.write(buf.array())
            fos.write(ByteArray(20000)) // padding bytes
        }

        val header = ggufEngine.parseGgufHeader(tempGgufFile)
        assertNotNull(header)
        assertEquals(3, header?.version)
        assertEquals(290L, header?.tensorCount)

        val metadata = ggufEngine.inspectGgufModel(tempGgufFile, LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM)
        assertEquals("qwen2", metadata.architecture)
        assertEquals(28, metadata.blockCount)

        val response = ggufEngine.executeGgufInference(
            ggufFile = tempGgufFile,
            promptTemplate = "<|im_start|>user\nما هي عاصمة فرنسا؟<|im_end|>\n<|im_start|>assistant\n",
            descriptor = LocalModelDescriptor.QWEN_2_5_1_5B_INSTRUCT_GGUF_Q4KM,
            ragBlock = null,
            memoryBlock = null,
            systemBlock = "أنت مساعد ذكي",
            rawPrompt = "ما هي عاصمة فرنسا؟"
        )

        assertNotNull(response)
        assertTrue(response.contains("Qwen2.5 GGUF") || response.contains("Llama.cpp") || response.contains("عاصمة فرنسا"))
        tempGgufFile.delete()
    }

    @Test
    fun testLocalInferenceEnginePromptTemplateAndSynthesis() = runTest {
        val engine = LocalInferenceEngineImpl()
        val descriptor = LocalModelDescriptor.AMEER_FAST_CORE

        val template = engine.buildPromptTemplate(
            systemPrompt = "أنت مساعد ذكي",
            memoryContext = "اسم المستخدم: أمير",
            ragContext = "توثيق Clean Architecture",
            history = listOf(ChatMessage(id = 1L, conversationId = 1L, content = "مرحبا", sender = MessageSender.USER, timestamp = 100L)),
            userPrompt = "اشرح لي المعمارية",
            assistantName = "Ameer AI"
        )

        assertTrue(template.contains("<|im_start|>system"))
        assertTrue(template.contains("[سياق الذاكرة طويلة المدى]:"))
        assertTrue(template.contains("[قاعدة المعرفة المسترجعة RAG]:"))
        assertTrue(template.contains("<|im_start|>user\nاشرح لي المعمارية"))

        val response = engine.infer(template, descriptor)
        assertNotNull(response)
        assertTrue(response.contains("Clean Architecture") || response.contains("المعرفة") || response.contains("Ameer"))
    }

    @Test
    fun testPersonalityAndRulesSystem() {
        val personality = AssistantPersonality(
            assistantName = "Ameer AI",
            style = PersonalityStyle.PROFESSIONAL,
            rules = AssistantRule.getDefaultRules()
        )

        val prompt = personality.buildSystemPrompt()
        assertTrue(prompt.contains("Ameer AI"))
        assertTrue(prompt.contains("مهني وأكاديمي"))
        assertTrue(prompt.contains("الهوية الثابتة"))
        assertTrue(prompt.contains("الأمانة المعرفية والدقة"))

        // Test Concise Style
        val concisePersonality = personality.copy(style = PersonalityStyle.CONCISE)
        val concisePrompt = concisePersonality.buildSystemPrompt()
        assertTrue(concisePrompt.contains("موجز ومباشر"))
    }

    @Test
    fun testKnowledgeBaseRAGPipeline() = runTest {
        val items = mutableListOf(
            KnowledgeItem(
                id = 1L,
                title = "معمارية أندرويد الحديثة",
                content = "نستخدم Clean Architecture مع MVVM وقاعدة بيانات Room لتخزين المعرفة محلياً.",
                category = KnowledgeCategory.TECHNICAL,
                sourceType = KnowledgeSourceType.MANUAL_TEXT,
                tags = listOf("Android", "Clean Architecture", "Room")
            )
        )

        val fakeKnowledgeRepo = object : KnowledgeRepository {
            override fun getKnowledgeFlow(): Flow<List<KnowledgeItem>> = flowOf(items)
            override suspend fun getAllKnowledge(): List<KnowledgeItem> = items
            override suspend fun getKnowledgeById(id: Long): KnowledgeItem? = items.find { it.id == id }
            override suspend fun saveKnowledge(item: KnowledgeItem): Long = 2L
            override suspend fun updateKnowledge(item: KnowledgeItem) {}
            override suspend fun deleteKnowledge(id: Long) { items.removeAll { it.id == id } }
            override suspend fun clearAllKnowledge() { items.clear() }
            override suspend fun searchKnowledge(query: String): List<KnowledgeItem> {
                return items.filter { it.title.contains(query) || it.content.contains(query) }
            }
            override suspend fun retrieveRelevantChunks(query: String, topK: Int): List<KnowledgeChunk> {
                return items.map { KnowledgeChunk(chunkId = "chunk-1", knowledgeId = it.id, title = it.title, text = it.content, relevanceScore = 1.0f) }
            }
        }

        val manager: KnowledgeManager = KnowledgeManagerImpl(fakeKnowledgeRepo)
        val ragContext = manager.retrieveRagContext("ما هي معمارية التطبيق؟")

        assertTrue(ragContext.hasKnowledge)
        assertEquals(1, ragContext.relevantChunks.size)
        assertTrue(ragContext.ragPromptBlock.contains("معمارية أندرويد الحديثة"))
        assertTrue(ragContext.ragPromptBlock.contains("Clean Architecture"))
    }

    @Test
    fun testMemorySystemContextBuilding() = runTest {
        val memories = listOf(
            MemoryItem(
                id = 1L,
                key = "الاسم",
                content = "أمير",
                category = MemoryCategory.USER_PROFILE
            ),
            MemoryItem(
                id = 2L,
                key = "الاهتمام",
                content = "الذكاء الاصطناعي على الأجهزة المحمولة",
                category = MemoryCategory.PREFERENCE
            )
        )

        val fakeMemoryRepo = object : MemoryRepository {
            override fun getLongTermMemories(): Flow<List<MemoryItem>> = flowOf(memories)
            override suspend fun getAllMemoriesList(): List<MemoryItem> = memories
            override suspend fun getMemoryById(id: Long): MemoryItem? = memories.find { it.id == id }
            override suspend fun saveMemory(memory: MemoryItem): Long = 3L
            override suspend fun updateMemory(memory: MemoryItem) {}
            override suspend fun deleteMemory(id: Long) {}
            override suspend fun clearAllLongTermMemories() {}
            override suspend fun searchMemories(query: String): List<MemoryItem> = memories
            override suspend fun getRelevantMemories(prompt: String): List<MemoryItem> = memories
        }

        val manager: MemoryManager = MemoryManagerImpl(fakeMemoryRepo)
        val context = manager.buildMemoryContext("ما هو اهتمامي؟", emptyList())

        assertTrue(context.memoryInstructionBlock.contains("أمير"))
        assertTrue(context.memoryInstructionBlock.contains("الذكاء الاصطناعي على الأجهزة المحمولة"))
    }

    @Test
    fun testAICoreEngineFullPipelineIntegration() = runTest {
        val memoryRepo = object : MemoryRepository {
            override fun getLongTermMemories(): Flow<List<MemoryItem>> = flowOf(listOf(
                MemoryItem(id = 1L, key = "المطور", content = "أمير", category = MemoryCategory.USER_PROFILE)
            ))
            override suspend fun getAllMemoriesList(): List<MemoryItem> = listOf(MemoryItem(id = 1L, key = "المطور", content = "أمير", category = MemoryCategory.USER_PROFILE))
            override suspend fun getMemoryById(id: Long): MemoryItem? = null
            override suspend fun saveMemory(memory: MemoryItem): Long = 1L
            override suspend fun updateMemory(memory: MemoryItem) {}
            override suspend fun deleteMemory(id: Long) {}
            override suspend fun clearAllLongTermMemories() {}
            override suspend fun searchMemories(query: String): List<MemoryItem> = emptyList()
            override suspend fun getRelevantMemories(prompt: String): List<MemoryItem> = listOf(MemoryItem(id = 1L, key = "المطور", content = "أمير", category = MemoryCategory.USER_PROFILE))
        }

        val knowledgeRepo = object : KnowledgeRepository {
            override fun getKnowledgeFlow(): Flow<List<KnowledgeItem>> = flowOf(listOf(
                KnowledgeItem(id = 1L, title = "مشروع Ameer AI", content = "تطبيق ذكاء اصطناعي محلي مع محرك نماذج متعددة و RAG.", category = KnowledgeCategory.GENERAL, sourceType = KnowledgeSourceType.MANUAL_TEXT)
            ))
            override suspend fun getAllKnowledge(): List<KnowledgeItem> = listOf(KnowledgeItem(id = 1L, title = "مشروع Ameer AI", content = "تطبيق ذكاء اصطناعي محلي مع محرك نماذج متعددة و RAG.", category = KnowledgeCategory.GENERAL, sourceType = KnowledgeSourceType.MANUAL_TEXT))
            override suspend fun getKnowledgeById(id: Long): KnowledgeItem? = null
            override suspend fun saveKnowledge(item: KnowledgeItem): Long = 1L
            override suspend fun updateKnowledge(item: KnowledgeItem) {}
            override suspend fun deleteKnowledge(id: Long) {}
            override suspend fun clearAllKnowledge() {}
            override suspend fun searchKnowledge(query: String): List<KnowledgeItem> = emptyList()
            override suspend fun retrieveRelevantChunks(query: String, topK: Int): List<KnowledgeChunk> = listOf(
                KnowledgeChunk(chunkId = "c1", knowledgeId = 1L, title = "مشروع Ameer AI", text = "تطبيق ذكاء اصطناعي محلي مع محرك نماذج متعددة و RAG.", relevanceScore = 1.0f)
            )
        }

        val memoryManager = MemoryManagerImpl(memoryRepo)
        val knowledgeManager = KnowledgeManagerImpl(knowledgeRepo)
        val loader = ModelLoaderImpl()
        val downloader = ModelDownloaderImpl()
        val selector = ModelSelectorImpl(loader)
        val modelManager = ModelManagerImpl(null, loader, downloader)
        val personalityManager = PersonalityManagerImpl(null)

        val localAiService = LocalAIServiceImpl(
            modelLoader = loader,
            modelDownloader = downloader,
            modelSelector = selector,
            inferenceEngine = LocalInferenceEngineImpl(),
            personalityManager = personalityManager,
            memoryManager = memoryManager,
            knowledgeManager = knowledgeManager
        )

        val engine = AICoreEngineImpl(
            modelManager = modelManager,
            personalityManager = personalityManager,
            memoryManager = memoryManager,
            knowledgeManager = knowledgeManager,
            localAiService = localAiService
        )

        val response = engine.generateResponse(
            prompt = "ما هي معلومات مشروع Ameer AI؟",
            history = emptyList()
        )

        assertTrue(response.isSuccess)
        val text = response.getOrNull()
        assertNotNull(text)
        assertTrue(text!!.isNotBlank())
    }
}
