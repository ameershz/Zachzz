package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole
import com.example.data.model.MessageStatus
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.StatusDisconnected
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatMessageItem(
  message: ChatMessage,
  onRetry: () -> Unit,
  onCancel: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val isUser = message.role == MessageRole.USER
  val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
  val timeString = timeFormat.format(Date(message.timestamp))

  Box(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 12.dp, vertical = 6.dp),
    contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart,
  ) {
    if (isUser) {
      UserMessageBubble(
        message = message,
        timeString = timeString,
        onCopy = { copyToClipboard(context, message.content) },
      )
    } else {
      AssistantMessageBubble(
        message = message,
        timeString = timeString,
        onRetry = onRetry,
        onCancel = onCancel,
        onCopy = { copyToClipboard(context, message.content) },
      )
    }
  }
}

@Composable
private fun UserMessageBubble(
  message: ChatMessage,
  timeString: String,
  onCopy: () -> Unit,
) {
  Column(
    horizontalAlignment = Alignment.End,
    modifier = Modifier.widthIn(max = 320.dp),
  ) {
    Surface(
      shape = RoundedCornerShape(
        topStart = 18.dp,
        topEnd = 18.dp,
        bottomStart = 18.dp,
        bottomEnd = 4.dp,
      ),
      color = MaterialTheme.colorScheme.primary,
      shadowElevation = 2.dp,
      modifier = Modifier.testTag("user_message_bubble"),
    ) {
      Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
        SelectionContainer {
          Text(
            text = message.content,
            color = MaterialTheme.colorScheme.onPrimary,
            style = MaterialTheme.typography.bodyLarge,
            lineHeight = 22.sp,
          )
        }
      }
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(top = 2.dp, end = 4.dp),
    ) {
      Text(
        text = timeString,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
        fontSize = 11.sp,
      )
      Spacer(modifier = Modifier.width(4.dp))
      IconButton(
        onClick = onCopy,
        modifier = Modifier.size(18.dp),
      ) {
        Icon(
          imageVector = Icons.Default.ContentCopy,
          contentDescription = "Copy message",
          tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
          modifier = Modifier.size(12.dp),
        )
      }
    }
  }
}

@Composable
private fun AssistantMessageBubble(
  message: ChatMessage,
  timeString: String,
  onRetry: () -> Unit,
  onCancel: () -> Unit,
  onCopy: () -> Unit,
) {
  Row(
    verticalAlignment = Alignment.Top,
    modifier = Modifier
      .fillMaxWidth(0.92f)
      .testTag("assistant_message_bubble"),
  ) {
    // Assistant Avatar
    Box(
      modifier = Modifier
        .size(34.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.surfaceVariant)
        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), CircleShape),
      contentAlignment = Alignment.Center,
    ) {
      Image(
        painter = painterResource(id = R.drawable.ai_avatar),
        contentDescription = "AI Avatar",
        modifier = Modifier.fillMaxWidth(),
        contentScale = ContentScale.Crop,
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    Column(modifier = Modifier.weight(1f)) {
      Card(
        shape = RoundedCornerShape(
          topStart = 4.dp,
          topEnd = 18.dp,
          bottomStart = 18.dp,
          bottomEnd = 18.dp,
        ),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.75f),
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
      ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
          when (message.status) {
            MessageStatus.SENDING -> {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
              ) {
                TypingIndicator()
                FilledTonalButton(
                  onClick = onCancel,
                  shape = RoundedCornerShape(12.dp),
                  contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                  modifier = Modifier
                    .height(28.dp)
                    .testTag("cancel_generation_button"),
                  colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f),
                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                  ),
                ) {
                  Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(12.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Stop", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
              }
            }

            MessageStatus.ERROR -> {
              Column {
                Row(verticalAlignment = Alignment.Top) {
                  Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = "Error",
                    tint = StatusDisconnected,
                    modifier = Modifier.size(20.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Request Failed",
                    style = MaterialTheme.typography.titleSmall,
                    color = StatusDisconnected,
                    fontWeight = FontWeight.Bold,
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = message.errorMessage ?: "Failed to get a response from the local AI server.",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  fontSize = 13.sp,
                  lineHeight = 18.sp,
                )
                Spacer(modifier = Modifier.height(8.dp))
                FilledTonalButton(
                  onClick = onRetry,
                  modifier = Modifier
                    .height(32.dp)
                    .testTag("retry_button"),
                  contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                ) {
                  Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Retry", fontSize = 12.sp)
                }
              }
            }

            MessageStatus.SENT -> {
              SelectionContainer {
                FormattedMessageContent(content = message.content)
              }
            }
          }
        }
      }

      if (message.status == MessageStatus.SENT) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.padding(top = 2.dp, start = 4.dp),
        ) {
          Text(
            text = timeString,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            fontSize = 11.sp,
          )
          Spacer(modifier = Modifier.width(6.dp))
          IconButton(
            onClick = onCopy,
            modifier = Modifier.size(20.dp),
          ) {
            Icon(
              imageVector = Icons.Default.ContentCopy,
              contentDescription = "Copy message",
              tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
              modifier = Modifier.size(12.dp),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun FormattedMessageContent(content: String) {
  // Simple markdown-style codeblock and paragraph parsing
  if (content.contains("```")) {
    val parts = content.split("```")
    Column {
      parts.forEachIndexed { index, part ->
        if (index % 2 == 1) {
          // Code block
          val lines = part.trim().lines()
          val firstLine = lines.firstOrNull() ?: ""
          val codeBody = if (firstLine.isNotBlank() && !firstLine.contains(" ")) {
            lines.drop(1).joinToString("\n")
          } else {
            part.trim()
          }

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 4.dp),
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              if (firstLine.isNotBlank() && !firstLine.contains(" ")) {
                Text(
                  text = firstLine.uppercase(),
                  style = MaterialTheme.typography.labelSmall,
                  color = CyberCyan,
                  fontWeight = FontWeight.Bold,
                  fontSize = 10.sp,
                )
                Spacer(modifier = Modifier.height(4.dp))
              }
              Text(
                text = codeBody,
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                fontSize = 12.sp,
                lineHeight = 17.sp,
              )
            }
          }
        } else {
          // Standard text
          if (part.isNotBlank()) {
            Text(
              text = part.trim(),
              style = MaterialTheme.typography.bodyLarge,
              color = MaterialTheme.colorScheme.onSurface,
              lineHeight = 22.sp,
              modifier = Modifier.padding(vertical = 2.dp),
            )
          }
        }
      }
    }
  } else {
    Text(
      text = content,
      style = MaterialTheme.typography.bodyLarge,
      color = MaterialTheme.colorScheme.onSurface,
      lineHeight = 22.sp,
    )
  }
}

@Composable
fun TypingIndicator() {
  val transition = rememberInfiniteTransition(label = "dots")

  val dot1Alpha by transition.animateFloat(
    initialValue = 0.3f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(600, delayMillis = 0, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "dot1",
  )

  val dot2Alpha by transition.animateFloat(
    initialValue = 0.3f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(600, delayMillis = 200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "dot2",
  )

  val dot3Alpha by transition.animateFloat(
    initialValue = 0.3f,
    targetValue = 1f,
    animationSpec = infiniteRepeatable(
      animation = tween(600, delayMillis = 400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse,
    ),
    label = "dot3",
  )

  Row(
    verticalAlignment = Alignment.CenterVertically,
    modifier = Modifier.padding(vertical = 4.dp),
  ) {
    Text(
      text = "Thinking",
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.primary,
      fontWeight = FontWeight.Medium,
    )
    Spacer(modifier = Modifier.width(6.dp))
    Box(
      modifier = Modifier
        .size(6.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.primary.copy(alpha = dot1Alpha)),
    )
    Spacer(modifier = Modifier.width(4.dp))
    Box(
      modifier = Modifier
        .size(6.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.primary.copy(alpha = dot2Alpha)),
    )
    Spacer(modifier = Modifier.width(4.dp))
    Box(
      modifier = Modifier
        .size(6.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.primary.copy(alpha = dot3Alpha)),
    )
  }
}

private fun copyToClipboard(context: Context, text: String) {
  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
  val clip = ClipData.newPlainText("AI Chat", text)
  clipboard?.setPrimaryClip(clip)
  Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
}
