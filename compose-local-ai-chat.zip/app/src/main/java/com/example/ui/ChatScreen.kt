package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.MessageStatus
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.StatusConnected
import com.example.ui.theme.StatusDisconnected
import com.example.ui.theme.StatusPending
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ChatScreen(
  viewModel: ChatViewModel,
  modifier: Modifier = Modifier,
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val listState = rememberLazyListState()
  val coroutineScope = rememberCoroutineScope()

  // Auto-scroll to bottom when new messages arrive or loading begins
  LaunchedEffect(uiState.messages.size, uiState.isLoading) {
    if (uiState.messages.isNotEmpty()) {
      listState.animateScrollToItem(uiState.messages.size - 1)
    }
  }

  val isScrolledUp by remember {
    derivedStateOf {
      val layoutInfo = listState.layoutInfo
      val totalItems = layoutInfo.totalItemsCount
      if (totalItems == 0) return@derivedStateOf false
      val lastVisibleItem = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
      lastVisibleItem < totalItems - 2
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    topBar = {
      CenterAlignedTopAppBar(
        title = {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "Local AI Chat",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(top = 2.dp),
            ) {
              val hostDisplay = uiState.serverUrl
                .removePrefix("http://")
                .removePrefix("https://")
                .substringBefore("/")

              val statusColor = when (uiState.connectionStatus) {
                ConnectionStatus.SUCCESS -> StatusConnected
                ConnectionStatus.ERROR -> StatusDisconnected
                ConnectionStatus.TESTING -> StatusPending
                ConnectionStatus.IDLE -> MaterialTheme.colorScheme.primary
              }

              Box(
                modifier = Modifier
                  .size(7.dp)
                  .clip(CircleShape)
                  .background(statusColor),
              )
              Spacer(modifier = Modifier.width(5.dp))
              Text(
                text = hostDisplay,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
              )
            }
          }
        },
        actions = {
          if (uiState.messages.isNotEmpty()) {
            IconButton(
              onClick = { viewModel.clearChat() },
              modifier = Modifier.testTag("clear_chat_button"),
            ) {
              Icon(
                imageVector = Icons.Default.DeleteSweep,
                contentDescription = "Clear Chat",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          IconButton(
            onClick = { viewModel.setSettingsDialogVisible(true) },
            modifier = Modifier.testTag("settings_button"),
          ) {
            Icon(
              imageVector = Icons.Default.Settings,
              contentDescription = "Server Settings",
              tint = MaterialTheme.colorScheme.primary,
            )
          }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
        ),
      )
    },
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues),
    ) {
      Column(
        modifier = Modifier.fillMaxSize(),
      ) {
        // Diagnostic banner for server setup info
        if (!uiState.bannerDismissed) {
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f),
              ) {
                Icon(
                  imageVector = Icons.Default.Info,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                  tint = MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Endpoint: ${uiState.serverUrl}",
                  style = MaterialTheme.typography.labelSmall,
                  fontFamily = FontFamily.Monospace,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Configure",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier
                    .clickable { viewModel.setSettingsDialogVisible(true) }
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                )
                IconButton(
                  onClick = { viewModel.dismissBanner() },
                  modifier = Modifier.size(20.dp),
                ) {
                  Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Dismiss",
                    modifier = Modifier.size(14.dp),
                  )
                }
              }
            }
          }
        }

        // Chat Messages Area
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth(),
        ) {
          if (uiState.messages.isEmpty()) {
            EmptyChatState(
              serverUrl = uiState.serverUrl,
              onSuggestionClicked = { prompt ->
                viewModel.sendMessage(presetText = prompt)
              },
              onOpenSettings = {
                viewModel.setSettingsDialogVisible(true)
              },
            )
          } else {
            LazyColumn(
              state = listState,
              modifier = Modifier
                .fillMaxSize()
                .testTag("chat_message_list"),
              contentPadding = PaddingValues(top = 8.dp, bottom = 12.dp),
            ) {
              items(
                items = uiState.messages,
                key = { it.id },
              ) { message ->
                ChatMessageItem(
                  message = message,
                  onRetry = { viewModel.retryMessage(message.id) },
                  onCancel = { viewModel.cancelGeneration() },
                )
              }
            }
          }

          // Scroll to bottom FAB
          androidx.compose.animation.AnimatedVisibility(
            visible = isScrolledUp,
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 },
            modifier = Modifier
              .align(Alignment.BottomEnd)
              .padding(16.dp),
          ) {
            SmallFloatingActionButton(
              onClick = {
                coroutineScope.launch {
                  if (uiState.messages.isNotEmpty()) {
                    listState.animateScrollToItem(uiState.messages.size - 1)
                  }
                }
              },
              containerColor = MaterialTheme.colorScheme.surfaceVariant,
              contentColor = MaterialTheme.colorScheme.primary,
              modifier = Modifier.testTag("scroll_to_bottom_button"),
            ) {
              Icon(Icons.Default.ArrowDownward, contentDescription = "Scroll to bottom")
            }
          }
        }

        // Bottom Chat Input Bar
        ChatInputBar(
          inputText = uiState.inputText,
          isLoading = uiState.isLoading,
          onTextChanged = { viewModel.onInputTextChanged(it) },
          onSend = { viewModel.sendMessage() },
          onCancel = { viewModel.cancelGeneration() },
        )
      }
    }
  }

  // Settings Dialog
  if (uiState.showSettingsDialog) {
    ServerSettingsDialog(
      currentUrl = uiState.serverUrl,
      currentTemperature = uiState.temperature,
      currentSystemPrompt = uiState.systemPrompt,
      connectionStatus = uiState.connectionStatus,
      connectionMessage = uiState.connectionStatusMessage,
      onDismiss = { viewModel.setSettingsDialogVisible(false) },
      onSave = { newUrl, newTemp, newPrompt ->
        viewModel.setServerUrl(newUrl)
        viewModel.setTemperature(newTemp)
        viewModel.setSystemPrompt(newPrompt)
      },
      onTestConnection = { viewModel.testConnection() },
    )
  }
}

@Composable
private fun EmptyChatState(
  serverUrl: String,
  onSuggestionClicked: (String) -> Unit,
  onOpenSettings: () -> Unit,
) {
  val suggestions = listOf(
    "💡 Explain how local LLMs perform inference",
    "💻 Write a Python script to send requests to llama.cpp",
    "⚡ What are 3 best practices for prompt engineering?",
    "🔬 Compare FP16 vs 4-bit GGUF quantization",
  )

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 24.dp)
      .testTag("empty_chat_state"),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    // Holographic AI Mascot Avatar
    Box(
      modifier = Modifier
        .size(92.dp)
        .clip(CircleShape)
        .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), CircleShape),
      contentAlignment = Alignment.Center,
    ) {
      Image(
        painter = painterResource(id = R.drawable.ai_avatar),
        contentDescription = "AI Assistant",
        modifier = Modifier.fillMaxSize(),
        contentScale = ContentScale.Crop,
      )
    }

    Spacer(modifier = Modifier.height(14.dp))

    Text(
      text = "Local AI Assistant",
      style = MaterialTheme.typography.headlineSmall,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onSurface,
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
      text = "OpenAI & llama.cpp compatible client",
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    Spacer(modifier = Modifier.height(12.dp))

    // Server Endpoint Tag
    Surface(
      shape = RoundedCornerShape(20.dp),
      color = MaterialTheme.colorScheme.surfaceVariant,
      modifier = Modifier.clickable { onOpenSettings() },
    ) {
      Row(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(CyberCyan),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = serverUrl,
          style = MaterialTheme.typography.labelSmall,
          fontFamily = FontFamily.Monospace,
          color = MaterialTheme.colorScheme.primary,
          maxLines = 1,
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    Text(
      text = "Try asking:",
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.align(Alignment.Start),
    )

    Spacer(modifier = Modifier.height(8.dp))

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      suggestions.forEach { suggestion ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          ),
          modifier = Modifier
            .fillMaxWidth()
            .clickable { onSuggestionClicked(suggestion.substringAfter(" ")) }
            .testTag("suggestion_card"),
        ) {
          Text(
            text = suggestion,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun ChatInputBar(
  inputText: String,
  isLoading: Boolean,
  onTextChanged: (String) -> Unit,
  onSend: () -> Unit,
  onCancel: () -> Unit,
) {
  Surface(
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 3.dp,
    modifier = Modifier
      .fillMaxWidth()
      .navigationBarsPadding()
      .imePadding(),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.Bottom,
    ) {
      OutlinedTextField(
        value = inputText,
        onValueChange = onTextChanged,
        modifier = Modifier
          .weight(1f)
          .testTag("message_input"),
        placeholder = {
          Text(
            text = if (isLoading) "Generating response..." else "Message local AI...",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
          )
        },
        maxLines = 5,
        shape = RoundedCornerShape(24.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
          focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
        ),
        keyboardOptions = KeyboardOptions(
          imeAction = if (inputText.isNotBlank()) ImeAction.Send else ImeAction.Default,
        ),
        keyboardActions = KeyboardActions(
          onSend = {
            if (inputText.isNotBlank() && !isLoading) {
              onSend()
            }
          },
        ),
      )

      Spacer(modifier = Modifier.width(8.dp))

      if (isLoading) {
        FilledIconButton(
          onClick = onCancel,
          modifier = Modifier
            .size(50.dp)
            .testTag("stop_generation_button"),
          shape = CircleShape,
          colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
          ),
        ) {
          Icon(
            imageVector = Icons.Default.Stop,
            contentDescription = "Stop Generating",
            modifier = Modifier.size(24.dp),
          )
        }
      } else {
        FilledIconButton(
          onClick = onSend,
          enabled = inputText.isNotBlank(),
          modifier = Modifier
            .size(50.dp)
            .testTag("send_button"),
          shape = CircleShape,
          colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
            disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.38f),
          ),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.Send,
            contentDescription = "Send Message",
            modifier = Modifier.size(20.dp),
          )
        }
      }
    }
  }
}
