package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole
import com.example.data.model.MessageStatus
import com.example.data.repository.LocalAiRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class ConnectionStatus {
  IDLE,
  TESTING,
  SUCCESS,
  ERROR,
}

data class ChatUiState(
  val messages: List<ChatMessage> = emptyList(),
  val inputText: String = "",
  val isLoading: Boolean = false,
  val serverUrl: String = "http://127.0.0.1:8080/v1/chat/completions",
  val temperature: Double = 0.7,
  val systemPrompt: String = "You are a helpful and concise local AI assistant.",
  val connectionStatus: ConnectionStatus = ConnectionStatus.IDLE,
  val connectionStatusMessage: String? = null,
  val showSettingsDialog: Boolean = false,
  val bannerDismissed: Boolean = false,
)

class ChatViewModel(
  private val repository: LocalAiRepository = LocalAiRepository(),
) : ViewModel() {

  private val _uiState = MutableStateFlow(ChatUiState())
  val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

  private var activeGenerationJob: Job? = null

  fun onInputTextChanged(newText: String) {
    _uiState.update { it.copy(inputText = newText) }
  }

  fun setSettingsDialogVisible(visible: Boolean) {
    _uiState.update { it.copy(showSettingsDialog = visible) }
  }

  fun setServerUrl(url: String) {
    _uiState.update { it.copy(serverUrl = url.trim()) }
  }

  fun setTemperature(temperature: Double) {
    val rounded = Math.round(temperature * 100.0) / 100.0
    _uiState.update { it.copy(temperature = rounded) }
  }

  fun setSystemPrompt(prompt: String) {
    _uiState.update { it.copy(systemPrompt = prompt) }
  }

  fun dismissBanner() {
    _uiState.update { it.copy(bannerDismissed = true) }
  }

  fun clearChat() {
    activeGenerationJob?.cancel()
    _uiState.update { it.copy(messages = emptyList(), isLoading = false) }
  }

  fun testConnection() {
    val currentUrl = _uiState.value.serverUrl
    viewModelScope.launch {
      _uiState.update {
        it.copy(
          connectionStatus = ConnectionStatus.TESTING,
          connectionStatusMessage = "Testing reachability at $currentUrl...",
        )
      }
      val result = repository.testConnection(currentUrl)
      result.fold(
        onSuccess = { msg ->
          _uiState.update {
            it.copy(
              connectionStatus = ConnectionStatus.SUCCESS,
              connectionStatusMessage = msg,
            )
          }
        },
        onFailure = { err ->
          _uiState.update {
            it.copy(
              connectionStatus = ConnectionStatus.ERROR,
              connectionStatusMessage = err.localizedMessage ?: "Failed to connect",
            )
          }
        },
      )
    }
  }

  fun cancelGeneration() {
    activeGenerationJob?.cancel()
    activeGenerationJob = null
    _uiState.update { state ->
      val updatedList = state.messages.map { msg ->
        if (msg.status == MessageStatus.SENDING) {
          msg.copy(status = MessageStatus.ERROR, errorMessage = "Cancelled by user")
        } else {
          msg
        }
      }
      state.copy(isLoading = false, messages = updatedList)
    }
  }

  fun sendMessage(presetText: String? = null) {
    val content = (presetText ?: _uiState.value.inputText).trim()
    if (content.isBlank() || _uiState.value.isLoading) return

    val userMessage = ChatMessage(
      role = MessageRole.USER,
      content = content,
      status = MessageStatus.SENT,
    )

    val pendingAssistantMessageId = UUID.randomUUID().toString()
    val pendingAssistantMessage = ChatMessage(
      id = pendingAssistantMessageId,
      role = MessageRole.ASSISTANT,
      content = "",
      status = MessageStatus.SENDING,
    )

    _uiState.update { state ->
      state.copy(
        messages = state.messages + userMessage + pendingAssistantMessage,
        inputText = if (presetText == null) "" else state.inputText,
        isLoading = true,
      )
    }

    executeApiCall(pendingAssistantMessageId)
  }

  fun retryMessage(failedMessageId: String) {
    val state = _uiState.value
    if (state.isLoading) return

    val targetIndex = state.messages.indexOfFirst { it.id == failedMessageId }
    if (targetIndex < 0) return

    val updatedList = state.messages.toMutableList()
    val targetMessage = updatedList[targetIndex]
    updatedList[targetIndex] = targetMessage.copy(
      status = MessageStatus.SENDING,
      errorMessage = null,
      content = "",
    )

    _uiState.update { it.copy(messages = updatedList, isLoading = true) }
    executeApiCall(failedMessageId)
  }

  private fun executeApiCall(assistantMessageId: String) {
    activeGenerationJob?.cancel()
    activeGenerationJob = viewModelScope.launch {
      val currentState = _uiState.value
      // Collect message history excluding the pending placeholder
      val history = currentState.messages.filter { it.id != assistantMessageId && it.status != MessageStatus.ERROR }

      val result = repository.sendChatCompletion(
        endpointUrl = currentState.serverUrl,
        messages = history,
        temperature = currentState.temperature,
        systemPrompt = currentState.systemPrompt.ifBlank { null },
      )

      result.fold(
        onSuccess = { responseText ->
          _uiState.update { state ->
            val updated = state.messages.map { msg ->
              if (msg.id == assistantMessageId) {
                msg.copy(
                  content = responseText,
                  status = MessageStatus.SENT,
                  errorMessage = null,
                )
              } else {
                msg
              }
            }
            state.copy(messages = updated, isLoading = false)
          }
        },
        onFailure = { error ->
          _uiState.update { state ->
            val updated = state.messages.map { msg ->
              if (msg.id == assistantMessageId) {
                msg.copy(
                  content = "",
                  status = MessageStatus.ERROR,
                  errorMessage = error.localizedMessage ?: "Failed to receive response.",
                )
              } else {
                msg
              }
            }
            state.copy(messages = updated, isLoading = false)
          }
        },
      )
      activeGenerationJob = null
    }
  }

  fun deleteMessage(id: String) {
    _uiState.update { state ->
      state.copy(messages = state.messages.filter { it.id != id })
    }
  }
}
