package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.StatusConnected
import com.example.ui.theme.StatusDisconnected
import com.example.ui.theme.StatusPending

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ServerSettingsDialog(
  currentUrl: String,
  currentTemperature: Double,
  currentSystemPrompt: String,
  connectionStatus: ConnectionStatus,
  connectionMessage: String?,
  onDismiss: () -> Unit,
  onSave: (url: String, temperature: Double, systemPrompt: String) -> Unit,
  onTestConnection: () -> Unit,
) {
  var urlInput by remember { mutableStateOf(currentUrl) }
  var tempInput by remember { mutableFloatStateOf(currentTemperature.toFloat()) }
  var systemPromptInput by remember { mutableStateOf(currentSystemPrompt) }
  var showHelpDetails by remember { mutableStateOf(false) }

  val presets = listOf(
    "127.0.0.1:8080" to "http://127.0.0.1:8080/v1/chat/completions",
    "10.0.2.2:8080 (Emulator)" to "http://10.0.2.2:8080/v1/chat/completions",
    "localhost:8080" to "http://localhost:8080/v1/chat/completions",
    "Ollama (11434)" to "http://127.0.0.1:11434/v1/chat/completions",
  )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Default.Dns,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.size(20.dp),
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "Server Configuration",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
          )
        }
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("close_settings_button"),
        ) {
          Icon(Icons.Default.Close, contentDescription = "Close")
        }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
      ) {
        Text(
          text = "Local AI API Endpoint",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.SemiBold,
          color = MaterialTheme.colorScheme.primary,
        )
        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
          value = urlInput,
          onValueChange = { urlInput = it },
          label = { Text("Completion URL") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("server_url_input"),
          textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "Quick Presets:",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(4.dp))

        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          presets.forEach { (label, targetUrl) ->
            FilterChip(
              selected = urlInput == targetUrl,
              onClick = { urlInput = targetUrl },
              label = { Text(label, fontSize = 12.sp) },
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Connection Test Card
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
          ),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Speed,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                  tint = MaterialTheme.colorScheme.primary,
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "Reachability Test",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.SemiBold,
                )
              }

              OutlinedButton(
                onClick = onTestConnection,
                enabled = connectionStatus != ConnectionStatus.TESTING,
                modifier = Modifier
                  .height(34.dp)
                  .testTag("test_connection_button"),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp),
              ) {
                if (connectionStatus == ConnectionStatus.TESTING) {
                  CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Testing...", fontSize = 11.sp)
                } else {
                  Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Test Now", fontSize = 11.sp)
                }
              }
            }

            if (connectionMessage != null) {
              Spacer(modifier = Modifier.height(8.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
              ) {
                val icon = when (connectionStatus) {
                  ConnectionStatus.SUCCESS -> Icons.Default.CheckCircle
                  ConnectionStatus.ERROR -> Icons.Default.Error
                  else -> Icons.Default.Refresh
                }
                val iconColor = when (connectionStatus) {
                  ConnectionStatus.SUCCESS -> StatusConnected
                  ConnectionStatus.ERROR -> StatusDisconnected
                  else -> StatusPending
                }

                Icon(
                  imageVector = icon,
                  contentDescription = null,
                  tint = iconColor,
                  modifier = Modifier
                    .size(16.dp)
                    .padding(top = 2.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = connectionMessage,
                  style = MaterialTheme.typography.bodySmall,
                  color = if (connectionStatus == ConnectionStatus.ERROR) StatusDisconnected else MaterialTheme.colorScheme.onSurface,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Temperature Slider
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Tune,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
              tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Temperature",
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.SemiBold,
            )
          }
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.primaryContainer,
          ) {
            Text(
              text = String.format("%.2f", tempInput),
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            )
          }
        }

        Slider(
          value = tempInput,
          onValueChange = { tempInput = it },
          valueRange = 0.0f..1.5f,
          steps = 14,
          colors = SliderDefaults.colors(
            thumbColor = CyberCyan,
            activeTrackColor = MaterialTheme.colorScheme.primary,
          ),
          modifier = Modifier.testTag("temperature_slider"),
        )
        Text(
          text = "Lower = more deterministic & focused; Higher = more creative.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(modifier = Modifier.height(14.dp))

        // System Prompt
        Text(
          text = "System Prompt",
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.SemiBold,
        )
        Spacer(modifier = Modifier.height(6.dp))
        OutlinedTextField(
          value = systemPromptInput,
          onValueChange = { systemPromptInput = it },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("system_prompt_input"),
          maxLines = 3,
          placeholder = { Text("e.g., You are a helpful and concise local AI assistant.") },
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Helpful connection guide toggle
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable { showHelpDetails = !showHelpDetails }
            .padding(vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Icon(
            imageVector = Icons.Default.HelpOutline,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = MaterialTheme.colorScheme.secondary,
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (showHelpDetails) "Hide Android Connection Tips" else "Android Localhost & Port Tips",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.secondary,
            fontWeight = FontWeight.SemiBold,
          )
        }

        if (showHelpDetails) {
          Card(
            shape = RoundedCornerShape(8.dp),
            colors = CardDefaults.cardColors(
              containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
            ),
            modifier = Modifier.padding(top = 6.dp),
          ) {
            Column(modifier = Modifier.padding(10.dp)) {
              Text(
                text = "• 127.0.0.1: If your llama.cpp/Ollama server runs on the physical Android device itself (via Termux or on-device LLM runner).\n" +
                  "• 10.0.2.2: If your server runs on your host development PC and you run this app inside the Android Studio Emulator.\n" +
                  "• USB Debugging: Run `adb reverse tcp:8080 tcp:8080` on your PC to forward phone's 127.0.0.1:8080 to your PC.\n" +
                  "• Cleartext traffic is enabled in network_security_config for 127.0.0.1, 10.0.2.2 and localhost.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp,
              )
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(urlInput, tempInput.toDouble(), systemPromptInput)
          onDismiss()
        },
        modifier = Modifier.testTag("save_settings_button"),
      ) {
        Text("Save & Apply")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    },
  )
}
