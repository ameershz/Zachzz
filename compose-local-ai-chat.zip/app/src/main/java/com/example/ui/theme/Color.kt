package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Accents
val CyberCyan = Color(0xFF00D2FF)
val CyberCyanDim = Color(0xFF0284C7)
val CyberTeal = Color(0xFF10B981)
val CyberPurple = Color(0xFF8B5CF6)

// Dark Theme Colors
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkSurfaceCard = Color(0xFF151E30)
val DarkBorder = Color(0xFF283548)

val DarkTextPrimary = Color(0xFFF9FAFB)
val DarkTextSecondary = Color(0xFF9CA3AF)
val DarkTextMuted = Color(0xFF6B7280)

val UserBubbleDark = Color(0xFF0284C7)
val UserBubbleDarkText = Color(0xFFFFFFFF)
val AssistantBubbleDark = Color(0xFF1E293B)
val AssistantBubbleDarkText = Color(0xFFF1F5F9)

// Light Theme Colors
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceCard = Color(0xFFFFFFFF)
val LightBorder = Color(0xFFE2E8F0)

val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)

val UserBubbleLight = Color(0xFF0284C7)
val UserBubbleLightText = Color(0xFFFFFFFF)
val AssistantBubbleLight = Color(0xFFF1F5F9)
val AssistantBubbleLightText = Color(0xFF0F172A)

// Status & Indicators
val StatusConnected = Color(0xFF10B981)
val StatusDisconnected = Color(0xFFEF4444)
val StatusPending = Color(0xFFF59E0B)
