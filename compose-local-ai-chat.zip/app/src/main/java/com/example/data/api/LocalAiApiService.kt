package com.example.data.api

import com.example.data.model.ChatCompletionRequest
import com.example.data.model.ChatCompletionResponse
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Url

interface LocalAiApiService {
  @POST
  suspend fun createChatCompletion(
    @Url url: String,
    @Body request: ChatCompletionRequest,
    @Header("Content-Type") contentType: String = "application/json",
  ): Response<ChatCompletionResponse>

  @GET
  suspend fun ping(
    @Url url: String,
  ): Response<ResponseBody>
}
