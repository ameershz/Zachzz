package com.example.data.repository

import com.example.data.api.ApiClient
import com.example.data.api.LocalAiApiService
import com.example.data.model.ApiChatMessage
import com.example.data.model.ChatCompletionRequest
import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class LocalAiRepository(
  private val apiService: LocalAiApiService = ApiClient.apiService,
) {

  suspend fun sendChatCompletion(
    endpointUrl: String,
    messages: List<ChatMessage>,
    temperature: Double = 0.7,
    systemPrompt: String? = null,
  ): Result<String> = withContext(Dispatchers.IO) {
    try {
      val apiMessages = mutableListOf<ApiChatMessage>()

      if (!systemPrompt.isNullOrBlank()) {
        apiMessages.add(ApiChatMessage(role = "system", content = systemPrompt.trim()))
      }

      messages.forEach { msg ->
        val roleStr = when (msg.role) {
          MessageRole.USER -> "user"
          MessageRole.ASSISTANT -> "assistant"
          MessageRole.SYSTEM -> "system"
        }
        apiMessages.add(ApiChatMessage(role = roleStr, content = msg.content))
      }

      val request = ChatCompletionRequest(
        messages = apiMessages,
        temperature = temperature,
      )

      val response = apiService.createChatCompletion(
        url = endpointUrl,
        request = request,
      )

      if (response.isSuccessful) {
        val body = response.body()
        val content = body?.choices?.firstOrNull()?.message?.content

        if (content != null) {
          Result.success(content)
        } else if (body?.error != null) {
          Result.failure(Exception(body.error.message ?: "Server returned an error."))
        } else {
          Result.failure(Exception("Empty response received from local server choices[0].message.content"))
        }
      } else {
        val errorBody = response.errorBody()?.string()
        val errorMsg = if (!errorBody.isNullOrBlank()) {
          "Server Error (${response.code()}): $errorBody"
        } else {
          "HTTP ${response.code()}: ${response.message()}"
        }
        Result.failure(Exception(errorMsg))
      }
    } catch (e: ConnectException) {
      val hint = if (endpointUrl.contains("127.0.0.1")) {
        "Failed to connect to $endpointUrl. If running the server on your computer while testing in an Android emulator, note that '127.0.0.1' points to the Android virtual device itself. Try 'http://10.0.2.2:8080/v1/chat/completions' or run 'adb reverse tcp:8080 tcp:8080'."
      } else {
        "Failed to connect to $endpointUrl. Please ensure your local llama.cpp / OpenAI server is running and listening on this port."
      }
      Result.failure(Exception(hint, e))
    } catch (e: SocketTimeoutException) {
      Result.failure(Exception("Connection timed out waiting for AI response. The local model took too long to complete the inference.", e))
    } catch (e: UnknownHostException) {
      Result.failure(Exception("Unknown host for URL: $endpointUrl. Please check your host and network connection.", e))
    } catch (e: Exception) {
      Result.failure(Exception(e.localizedMessage ?: "Unexpected error connecting to local server", e))
    }
  }

  suspend fun testConnection(endpointUrl: String): Result<String> = withContext(Dispatchers.IO) {
    try {
      // Test with a lightweight ping or 1-token test prompt
      val testRequest = ChatCompletionRequest(
        messages = listOf(ApiChatMessage(role = "user", content = "Hi")),
        temperature = 0.1,
        maxTokens = 2,
      )
      val response = apiService.createChatCompletion(url = endpointUrl, request = testRequest)
      if (response.isSuccessful) {
        Result.success("Connection successful! Server responded with HTTP 200 OK.")
      } else {
        Result.failure(Exception("Server reached but responded with HTTP ${response.code()}: ${response.message()}"))
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }
}
