package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import java.util.UUID

@JsonClass(generateAdapter = true)
data class ChatCompletionRequest(
  @Json(name = "messages") val messages: List<ApiChatMessage>,
  @Json(name = "temperature") val temperature: Double = 0.7,
  @Json(name = "model") val model: String? = null,
  @Json(name = "stream") val stream: Boolean? = false,
  @Json(name = "max_tokens") val maxTokens: Int? = null,
)

@JsonClass(generateAdapter = true)
data class ApiChatMessage(
  @Json(name = "role") val role: String,
  @Json(name = "content") val content: String,
)

@JsonClass(generateAdapter = true)
data class ChatCompletionResponse(
  @Json(name = "id") val id: String? = null,
  @Json(name = "object") val objectType: String? = null,
  @Json(name = "created") val created: Long? = null,
  @Json(name = "model") val model: String? = null,
  @Json(name = "choices") val choices: List<Choice>? = null,
  @Json(name = "usage") val usage: Usage? = null,
  @Json(name = "error") val error: ApiErrorResponse? = null,
)

@JsonClass(generateAdapter = true)
data class Choice(
  @Json(name = "index") val index: Int? = null,
  @Json(name = "message") val message: ChoiceMessage? = null,
  @Json(name = "finish_reason") val finishReason: String? = null,
)

@JsonClass(generateAdapter = true)
data class ChoiceMessage(
  @Json(name = "role") val role: String? = null,
  @Json(name = "content") val content: String? = null,
)

@JsonClass(generateAdapter = true)
data class Usage(
  @Json(name = "prompt_tokens") val promptTokens: Int? = null,
  @Json(name = "completion_tokens") val completionTokens: Int? = null,
  @Json(name = "total_tokens") val totalTokens: Int? = null,
)

@JsonClass(generateAdapter = true)
data class ApiErrorResponse(
  @Json(name = "message") val message: String? = null,
  @Json(name = "type") val type: String? = null,
)

enum class MessageRole {
  USER,
  ASSISTANT,
  SYSTEM,
}

enum class MessageStatus {
  SENDING,
  SENT,
  ERROR,
}

data class ChatMessage(
  val id: String = UUID.randomUUID().toString(),
  val role: MessageRole,
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
  val status: MessageStatus = MessageStatus.SENT,
  val errorMessage: String? = null,
)
