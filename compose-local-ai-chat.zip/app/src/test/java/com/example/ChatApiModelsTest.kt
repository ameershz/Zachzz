package com.example

import com.example.data.api.ApiClient
import com.example.data.model.ApiChatMessage
import com.example.data.model.ChatCompletionRequest
import com.example.data.model.ChatCompletionResponse
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatApiModelsTest {

  @Test
  fun testRequestSerialization() {
    val request = ChatCompletionRequest(
      messages = listOf(
        ApiChatMessage(role = "user", content = "Hello local AI"),
      ),
      temperature = 0.7,
    )

    val adapter = ApiClient.moshi.adapter(ChatCompletionRequest::class.java)
    val json = adapter.toJson(request)

    assertTrue(json.contains("\"role\":\"user\""))
    assertTrue(json.contains("\"content\":\"Hello local AI\""))
    assertTrue(json.contains("\"temperature\":0.7"))
  }

  @Test
  fun testResponseParsing() {
    val sampleOpenAiResponse = """
      {
        "id": "chatcmpl-123",
        "object": "chat.completion",
        "created": 1677652288,
        "model": "llama-3-8b-instruct",
        "choices": [
          {
            "index": 0,
            "message": {
              "role": "assistant",
              "content": "Hello! I am your local AI model running via llama.cpp."
            },
            "finish_reason": "stop"
          }
        ],
        "usage": {
          "prompt_tokens": 9,
          "completion_tokens": 12,
          "total_tokens": 21
        }
      }
    """.trimIndent()

    val adapter = ApiClient.moshi.adapter(ChatCompletionResponse::class.java)
    val parsed = adapter.fromJson(sampleOpenAiResponse)

    assertNotNull(parsed)
    val content = parsed?.choices?.get(0)?.message?.content
    assertEquals("Hello! I am your local AI model running via llama.cpp.", content)
  }
}
