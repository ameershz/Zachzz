package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.inventory.FishInventory

/**
 * Overlay modal showing the player's fish creel/inventory, weights, rarities, and sale values.
 */
class FishInventoryModal(
    val fishInventory: FishInventory,
    var onClose: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set

    private val modalRect = RectF()
    private val closeBtnRect = RectF()

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 8, 14, 24)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 32, 50)
        style = Paint.Style.FILL
    }

    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(52, 152, 219)
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 48, 76)
        style = Paint.Style.FILL
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 22f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val itemBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(14, 22, 36)
        style = Paint.Style.FILL
    }

    private val fishTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val valueTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(241, 196, 15)
        textAlign = Paint.Align.RIGHT
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val closeBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(52, 152, 219)
        style = Paint.Style.FILL
    }

    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun open() {
        isOpen = true
    }

    fun close() {
        isOpen = false
        onClose?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false

        if (closeBtnRect.contains(touchX, touchY)) {
            close()
            return true
        }

        if (!modalRect.contains(touchX, touchY)) {
            close()
            return true
        }

        return true
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        if (!isOpen) return

        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        val cardW = (screenW * 0.90f).coerceIn(320f, 460f)
        val cardH = 430f
        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        canvas.drawRoundRect(modalRect, 18f, 18f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBorderPaint)

        // Header
        val headerH = 56f
        val headerRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + headerH)
        canvas.drawRoundRect(headerRect, 18f, 18f, headerPaint)
        canvas.drawRect(cardLeft, cardTop + headerH - 12f, cardLeft + cardW, cardTop + headerH, headerPaint)

        canvas.drawText("🎒 Fish Creel (${fishInventory.count}/${fishInventory.capacity})", screenW * 0.5f, cardTop + 34f, titlePaint)

        // List box
        val listTop = cardTop + headerH + 16f
        val listH = 265f
        val listRect = RectF(cardLeft + 16f, listTop, cardLeft + cardW - 16f, listTop + listH)
        canvas.drawRoundRect(listRect, 10f, 10f, itemBoxPaint)

        val fishList = fishInventory.getFishList()
        if (fishList.isEmpty()) {
            val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(150, 170, 195)
                textAlign = Paint.Align.CENTER
                textSize = 15f
            }
            canvas.drawText("Your creel is empty.", listRect.centerX(), listRect.centerY() - 8f, emptyPaint)
            canvas.drawText("Walk to the fishing dock and cast your rod!", listRect.centerX(), listRect.centerY() + 18f, emptyPaint)
        } else {
            var itemY = listTop + 28f
            for (i in 0 until minOf(6, fishList.size)) {
                val fish = fishList[i]
                val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = fish.species.rarity.color
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                }
                canvas.drawText("${fish.species.iconEmoji} ${fish.species.speciesName}", listRect.left + 14f, itemY, fishTextPaint)
                canvas.drawText("• ${fish.species.rarity.displayName} (${fish.formattedWeight})", listRect.left + 175f, itemY, badgePaint)
                canvas.drawText(fish.formattedValue, listRect.right - 14f, itemY, valueTextPaint)
                itemY += 38f
            }
            if (fishList.size > 6) {
                val morePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(160, 190, 220)
                    textAlign = Paint.Align.CENTER
                    textSize = 13f
                }
                canvas.drawText("+ ${fishList.size - 6} more fish in creel", listRect.centerX(), listTop + listH - 10f, morePaint)
            }
        }

        // Summary & Close button
        val footerY = cardTop + cardH - 24f
        val summaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(241, 196, 15)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("Total Value: $${fishInventory.totalValue}", cardLeft + 20f, footerY, summaryPaint)

        closeBtnRect.set(cardLeft + cardW - 110f, footerY - 22f, cardLeft + cardW - 20f, footerY + 12f)
        canvas.drawRoundRect(closeBtnRect, 8f, 8f, closeBtnPaint)
        canvas.drawText("CLOSE", closeBtnRect.centerX(), closeBtnRect.centerY() + 5f, btnTextPaint)
    }
}
