package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.physics.RectCollider
import kotlin.math.sin

/**
 * Tropical island environmental props: Palm trees, wooden fishing docks,
 * moored boats, nautical lanterns, and beach boulders.
 */

class PalmTree(
    val x: Float,
    val y: Float,
    val size: Float = 42f
) {
    val collider: RectCollider = RectCollider(
        left = x - 10f,
        top = y - 8f,
        right = x + 10f,
        bottom = y + 10f,
        tag = "palmtree"
    )

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 10, 25, 30)
        style = Paint.Style.FILL
    }

    private val trunkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(139, 94, 52) // Palm bark
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }

    private val coconutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(85, 50, 25)
        style = Paint.Style.FILL
    }

    private val frondDarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(34, 139, 34) // Forest palm green
        style = Paint.Style.FILL
    }

    private val frondLightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113) // Bright tropical highlight
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        // Shadow
        val shadowRect = RectF(x - size * 0.9f, y - size * 0.1f, x + size * 1.1f, y + size * 0.45f)
        canvas.drawOval(shadowRect, shadowPaint)

        // Curved trunk path
        val trunkPath = Path().apply {
            moveTo(x, y)
            quadTo(x + 10f, y - 28f, x - 6f, y - 56f)
        }
        canvas.drawPath(trunkPath, trunkPaint)

        val topX = x - 6f
        val topY = y - 56f

        // Coconuts cluster
        canvas.drawCircle(topX - 4f, topY + 4f, 4f, coconutPaint)
        canvas.drawCircle(topX + 4f, topY + 4f, 4f, coconutPaint)
        canvas.drawCircle(topX, topY + 7f, 4f, coconutPaint)

        // Radiating palm fronds
        drawFrond(canvas, topX, topY, -size * 0.85f, -size * 0.4f, frondDarkPaint)
        drawFrond(canvas, topX, topY, size * 0.85f, -size * 0.4f, frondDarkPaint)
        drawFrond(canvas, topX, topY, -size * 0.7f, size * 0.35f, frondLightPaint)
        drawFrond(canvas, topX, topY, size * 0.7f, size * 0.35f, frondLightPaint)
        drawFrond(canvas, topX, topY, 0f, -size * 0.8f, frondLightPaint)
    }

    private fun drawFrond(canvas: Canvas, sx: Float, sy: Float, ex: Float, ey: Float, paint: Paint) {
        val frondPath = Path().apply {
            moveTo(sx, sy)
            val midX = sx + ex * 0.5f - 8f
            val midY = sy + ey * 0.5f - 10f
            quadTo(midX, midY, sx + ex, sy + ey)
            quadTo(midX + 12f, midY + 8f, sx, sy)
        }
        canvas.drawPath(frondPath, paint)
    }
}

class BeachRock(
    val x: Float,
    val y: Float,
    val radius: Float = 22f
) {
    val collider: RectCollider = RectCollider(
        left = x - radius * 0.8f,
        top = y - radius * 0.7f,
        right = x + radius * 0.8f,
        bottom = y + radius * 0.7f,
        tag = "rock"
    )

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 20, 25, 30)
        style = Paint.Style.FILL
    }

    private val rockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(130, 140, 150)
        style = Paint.Style.FILL
    }

    private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(175, 185, 195)
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        val shadowRect = RectF(x - radius, y - radius * 0.2f, x + radius * 1.1f, y + radius * 0.8f)
        canvas.drawOval(shadowRect, shadowPaint)

        val rockRect = RectF(x - radius, y - radius * 0.7f, x + radius, y + radius * 0.7f)
        canvas.drawRoundRect(rockRect, 10f, 10f, rockPaint)

        // Sun highlight
        canvas.drawCircle(x - radius * 0.3f, y - radius * 0.2f, radius * 0.35f, highlightPaint)
    }
}

class NauticalLantern(
    val x: Float,
    val y: Float
) {
    val collider: RectCollider = RectCollider(x - 6f, y - 6f, x + 6f, y + 6f, tag = "lantern")

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(50, 0, 0, 0)
        style = Paint.Style.FILL
    }

    private val postPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(115, 75, 40)
        strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 255, 220, 120)
        style = Paint.Style.FILL
    }

    private val bulbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 240, 160)
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        // Ground glow pool
        canvas.drawCircle(x, y + 6f, 44f, glowPaint)

        canvas.drawLine(x, y, x + 14f, y + 8f, shadowPaint)
        canvas.drawLine(x, y, x, y - 38f, postPaint)

        // Glass lantern cage
        val lanternRect = RectF(x - 5f, y - 44f, x + 5f, y - 34f)
        canvas.drawRoundRect(lanternRect, 2f, 2f, bulbPaint)
        canvas.drawCircle(x, y - 39f, 2.5f, bulbPaint)
    }
}

class WoodenFishingDock(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    val castingSpotX: Float,
    val castingSpotY: Float,
    val waterTargetX: Float,
    val waterTargetY: Float,
    val dockName: String = "Fishing Pier"
) {
    val right: Float get() = left + width
    val bottom: Float get() = top + height
    val centerX: Float get() = left + width * 0.5f

    private val plankPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 135, 85) // Weathered boardwalk teak
        style = Paint.Style.FILL
    }

    private val plankLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(125, 88, 48)
        strokeWidth = 2.5f
    }

    private val pilingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(90, 60, 32)
        style = Paint.Style.FILL
    }

    private val castingRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(130, 46, 204, 113)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val castingLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 255, 255)
        textAlign = Paint.Align.CENTER
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun render(canvas: Canvas) {
        // Pilings support posts underneath dock
        var yPiling = top + 14f
        while (yPiling < bottom) {
            canvas.drawCircle(left + 6f, yPiling, 6f, pilingPaint)
            canvas.drawCircle(right - 6f, yPiling, 6f, pilingPaint)
            yPiling += 40f
        }

        // Main plank surface
        val dockRect = RectF(left, top, right, bottom)
        canvas.drawRoundRect(dockRect, 4f, 4f, plankPaint)

        // Horizontal plank separator lines
        var yLine = top + 16f
        while (yLine < bottom) {
            canvas.drawLine(left, yLine, right, yLine, plankLinePaint)
            yLine += 16f
        }

        // Outer borders
        canvas.drawRect(left, top, left + 4f, bottom, pilingPaint)
        canvas.drawRect(right - 4f, top, right, bottom, pilingPaint)

        // Visual casting zone marker at the end of the dock
        canvas.drawCircle(castingSpotX, castingSpotY, 26f, castingRingPaint)
        canvas.drawText("🎣 CAST SPOT", castingSpotX, castingSpotY + 5f, castingLabelPaint)
    }
}

class MooredBoat(
    val x: Float,
    val y: Float
) {
    val collider: RectCollider = RectCollider(x - 42f, y - 22f, x + 42f, y + 22f, tag = "boat")

    private val hullPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(230, 235, 240) // White wooden skiff hull
        style = Paint.Style.FILL
    }

    private val trimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(41, 128, 185) // Blue trim
        style = Paint.Style.FILL
    }

    private val seatPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 110, 60)
        style = Paint.Style.FILL
    }

    private val waterRipples = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private var boatTimer: Float = 0f

    fun update(deltaTime: Float) {
        boatTimer += deltaTime
    }

    fun render(canvas: Canvas) {
        val bobY = sin(boatTimer * 2f) * 3f

        // Water wake
        canvas.drawOval(RectF(x - 52f, y + bobY - 14f, x + 52f, y + bobY + 28f), waterRipples)

        // Boat hull
        val boatPath = Path().apply {
            moveTo(x + 44f, y + bobY) // Bow
            quadTo(x + 20f, y + bobY - 20f, x - 38f, y + bobY - 16f) // Port
            lineTo(x - 38f, y + bobY + 16f) // Stern
            quadTo(x + 20f, y + bobY + 20f, x + 44f, y + bobY) // Starboard
        }
        canvas.drawPath(boatPath, hullPaint)

        // Interior seats
        canvas.drawRoundRect(RectF(x - 12f, y + bobY - 14f, x - 2f, y + bobY + 14f), 2f, 2f, seatPaint)
        canvas.drawRoundRect(RectF(x + 12f, y + bobY - 12f, x + 20f, y + bobY + 12f), 2f, 2f, seatPaint)
        canvas.drawRoundRect(RectF(x - 36f, y + bobY - 12f, x - 28f, y + bobY + 12f), 2f, 2f, trimPaint)
    }
}
