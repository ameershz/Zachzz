package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.example.game.physics.CollisionSystem
import com.example.game.physics.RectCollider
import kotlin.math.sin

/**
 * Tropical fishing island environment with surrounding ocean water, animated waves,
 * sandy beaches, lush village grass, wooden fishing piers, shops, and boat dock.
 */
class World(val collisionSystem: CollisionSystem) {
    val width: Float = 2000f
    val height: Float = 2000f

    val buildings = mutableListOf<Building>()
    val palmTrees = mutableListOf<PalmTree>()
    val rocks = mutableListOf<BeachRock>()
    val lanterns = mutableListOf<NauticalLantern>()
    val docks = mutableListOf<WoodenFishingDock>()
    var mooredBoat: MooredBoat? = null

    // Player spawn: island village center path
    val spawnX: Float = 980f
    val spawnY: Float = 860f

    // Main fishing pier reference
    lateinit var mainFishingDock: WoodenFishingDock

    // Island landmass bounds
    val beachRect = RectF(460f, 460f, 1540f, 1540f)
    val grassRect = RectF(560f, 560f, 1440f, 1440f)

    // Animated water wave timer
    private var waterTimer: Float = 0f

    // Paints
    private val oceanDeepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(18, 92, 145) // Deep sapphire ocean
        style = Paint.Style.FILL
    }

    private val oceanShallowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(38, 148, 198) // Shallow coastal turquoise
        style = Paint.Style.FILL
    }

    private val waveFoamPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 240, 250, 255)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val beachSandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(238, 198, 122) // Warm golden beach sand
        style = Paint.Style.FILL
    }

    private val islandGrassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(65, 160, 95) // Lush tropical grass
        style = Paint.Style.FILL
    }

    private val pathStonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(205, 185, 150) // Sandy village gravel walkway
        style = Paint.Style.FILL
    }

    init {
        setupDocks()
        setupBuildings()
        setupProps()
        registerAllColliders()
    }

    private fun setupDocks() {
        // 1. Main North Fishing Dock (extending from beach into ocean)
        mainFishingDock = WoodenFishingDock(
            left = 940f,
            top = 220f,
            width = 80f,
            height = 360f,
            castingSpotX = 980f,
            castingSpotY = 270f,
            waterTargetX = 980f,
            waterTargetY = 140f,
            dockName = "North Ocean Pier"
        )
        docks.add(mainFishingDock)

        // 2. South Boat Marina Dock (for future boat trips)
        val boatPier = WoodenFishingDock(
            left = 940f,
            top = 1420f,
            width = 80f,
            height = 300f,
            castingSpotX = 980f,
            castingSpotY = 1680f,
            waterTargetX = 980f,
            waterTargetY = 1780f,
            dockName = "Marina Boat Pier"
        )
        docks.add(boatPier)

        // Moored fishing skiff beside the South dock
        mooredBoat = MooredBoat(1060f, 1640f)
    }

    private fun setupBuildings() {
        // 1. Pelican Fishmonger (Fish Shop)
        buildings.add(
            Building(
                id = "building_fish_shop",
                name = "Pelican Fishmonger",
                type = BuildingType.FISH_SHOP,
                left = 680f,
                top = 660f,
                width = 190f,
                height = 135f,
                entranceX = 775f,
                entranceY = 795f,
                wallColor = Color.rgb(225, 235, 245),
                roofColor = Color.rgb(35, 115, 175), // Maritime blue roof
                trimColor = Color.rgb(25, 75, 120),
                signText = "FISH SHOP",
                signBgColor = Color.rgb(30, 95, 155),
                hasAwning = true,
                awningColor1 = Color.WHITE,
                awningColor2 = Color.rgb(41, 128, 185),
                interactionLabel = "SELL FISH",
                interactionSubLabel = "Trade catches for gold"
            )
        )

        // 2. Harbor Tackle & Rods (Rod Upgrade Shop)
        buildings.add(
            Building(
                id = "building_rod_shop",
                name = "Harbor Tackle & Rods",
                type = BuildingType.ROD_SHOP,
                left = 1130f,
                top = 660f,
                width = 190f,
                height = 135f,
                entranceX = 1225f,
                entranceY = 795f,
                wallColor = Color.rgb(185, 140, 95), // Weathered teak
                roofColor = Color.rgb(195, 85, 45),  // Terracotta roof
                trimColor = Color.rgb(90, 55, 30),
                signText = "TACKLE & RODS",
                signBgColor = Color.rgb(145, 65, 30),
                interactionLabel = "ROD SHOP",
                interactionSubLabel = "Upgrade fishing rods"
            )
        )

        // 3. Harbor Rest (Player Cottage)
        buildings.add(
            Building(
                id = "building_home",
                name = "Fisherman Cottage",
                type = BuildingType.PLAYER_HOME,
                left = 700f,
                top = 1100f,
                width = 170f,
                height = 130f,
                entranceX = 785f,
                entranceY = 1230f,
                wallColor = Color.rgb(235, 220, 195),
                roofColor = Color.rgb(145, 115, 75), // Thatch / woven palm roof
                trimColor = Color.rgb(80, 55, 35),
                signText = "HARBOR REST",
                signBgColor = Color.rgb(105, 80, 50),
                interactionLabel = "REST",
                interactionSubLabel = "Island home"
            )
        )

        // 4. Marina Harbor House
        buildings.add(
            Building(
                id = "building_marina_hut",
                name = "Boat Master Hut",
                type = BuildingType.DECORATIVE_HUT,
                left = 1140f,
                top = 1100f,
                width = 170f,
                height = 130f,
                entranceX = 1225f,
                entranceY = 1230f,
                wallColor = Color.rgb(215, 225, 235),
                roofColor = Color.rgb(46, 125, 105), // Seafoam green roof
                trimColor = Color.rgb(30, 85, 70),
                signText = "EXPEDITIONS",
                signBgColor = Color.rgb(35, 95, 80),
                interactionLabel = "INSPECT",
                interactionSubLabel = "Future Boat Expeditions"
            )
        )
    }

    private fun setupProps() {
        // Palm trees along beach perimeter and village
        val palmCoords = listOf(
            Pair(520f, 540f), Pair(620f, 490f), Pair(1380f, 490f), Pair(1480f, 540f),
            Pair(490f, 850f), Pair(490f, 1150f), Pair(520f, 1420f),
            Pair(1510f, 850f), Pair(1510f, 1150f), Pair(1480f, 1420f),
            Pair(680f, 1480f), Pair(1320f, 1480f),
            // Village greens
            Pair(980f, 1040f), Pair(880f, 920f), Pair(1080f, 920f)
        )
        for ((px, py) in palmCoords) {
            palmTrees.add(PalmTree(px, py, size = 38f + (sin(px.toDouble() + py.toDouble()) * 4f).toFloat()))
        }

        // Coastal beach rocks
        val rockCoords = listOf(
            Pair(440f, 720f), Pair(440f, 1280f), Pair(1560f, 720f), Pair(1560f, 1280f),
            Pair(860f, 440f), Pair(1140f, 440f), Pair(860f, 1560f), Pair(1140f, 1560f)
        )
        for ((rx, ry) in rockCoords) {
            rocks.add(BeachRock(rx, ry, radius = 20f + (sin(rx.toDouble()) * 4f).toFloat()))
        }

        // Nautical lanterns along paths and docks
        lanterns.add(NauticalLantern(920f, 570f))
        lanterns.add(NauticalLantern(1040f, 570f))
        lanterns.add(NauticalLantern(920f, 240f))
        lanterns.add(NauticalLantern(1040f, 240f))
        lanterns.add(NauticalLantern(890f, 790f))
        lanterns.add(NauticalLantern(1110f, 790f))
        lanterns.add(NauticalLantern(920f, 1430f))
        lanterns.add(NauticalLantern(1040f, 1430f))
    }

    private fun registerAllColliders() {
        collisionSystem.clear()

        // 1. Water boundaries - ensure player stays on island and docks
        // West ocean barrier
        collisionSystem.addCollider(RectCollider(0f, 0f, 440f, height, tag = "water_west"))
        // East ocean barrier
        collisionSystem.addCollider(RectCollider(1560f, 0f, width, height, tag = "water_east"))
        // North ocean barrier (leaving dock corridor X=930..1030 open)
        collisionSystem.addCollider(RectCollider(440f, 0f, 930f, 440f, tag = "water_north_left"))
        collisionSystem.addCollider(RectCollider(1030f, 0f, 1560f, 440f, tag = "water_north_right"))
        // South ocean barrier (leaving marina dock corridor X=930..1030 open)
        collisionSystem.addCollider(RectCollider(440f, 1560f, 930f, height, tag = "water_south_left"))
        collisionSystem.addCollider(RectCollider(1030f, 1560f, 1560f, height, tag = "water_south_right"))

        // North Pier Side Water Barriers
        collisionSystem.addCollider(RectCollider(440f, 200f, 930f, 440f, tag = "pier_water_w"))
        collisionSystem.addCollider(RectCollider(1030f, 200f, 1560f, 440f, tag = "pier_water_e"))
        collisionSystem.addCollider(RectCollider(900f, 0f, 1100f, 210f, tag = "pier_head_water"))

        // South Marina Side Water Barriers
        collisionSystem.addCollider(RectCollider(900f, 1730f, 1100f, height, tag = "boat_pier_head"))

        // 2. Buildings
        for (b in buildings) {
            collisionSystem.addCollider(b.collider)
        }

        // 3. Palm Trees
        for (p in palmTrees) {
            collisionSystem.addCollider(p.collider)
        }

        // 4. Beach Rocks
        for (r in rocks) {
            collisionSystem.addCollider(r.collider)
        }

        // 5. Lanterns
        for (l in lanterns) {
            collisionSystem.addCollider(l.collider)
        }

        // 6. Moored boat
        mooredBoat?.let { collisionSystem.addCollider(it.collider) }
    }

    fun update(deltaTime: Float) {
        waterTimer += deltaTime
        mooredBoat?.update(deltaTime)
    }

    fun render(canvas: Canvas) {
        // 1. Deep Ocean Background
        canvas.drawRect(0f, 0f, width, height, oceanDeepPaint)

        // Animated ocean waves
        var yWave = 60f
        while (yWave < height) {
            val waveOffset = sin(waterTimer * 2f + yWave * 0.05f) * 12f
            canvas.drawLine(0f, yWave + waveOffset, width, yWave + waveOffset, waveFoamPaint)
            yWave += 120f
        }

        // 2. Shallow coastal water halo
        val shallowRect = RectF(400f, 400f, 1600f, 1600f)
        canvas.drawRoundRect(shallowRect, 180f, 180f, oceanShallowPaint)

        // 3. Sandy Beach Landmass
        canvas.drawRoundRect(beachRect, 140f, 140f, beachSandPaint)

        // 4. Lush Village Grass Interior
        canvas.drawRoundRect(grassRect, 90f, 90f, islandGrassPaint)

        // 5. Walkway Paths
        // Central crossroads
        val pathH = RectF(660f, 830f, 1340f, 890f)
        val pathV = RectF(950f, 560f, 1010f, 1440f)
        canvas.drawRoundRect(pathH, 12f, 12f, pathStonePaint)
        canvas.drawRoundRect(pathV, 12f, 12f, pathStonePaint)

        // 6. Docks
        for (d in docks) {
            d.render(canvas)
        }

        // 7. Moored Boat
        mooredBoat?.render(canvas)

        // 8. Beach Rocks
        for (r in rocks) {
            r.render(canvas)
        }

        // 9. Buildings
        for (b in buildings) {
            b.render(canvas)
        }

        // 10. Nautical Lanterns
        for (l in lanterns) {
            l.render(canvas)
        }

        // 11. Palm Trees
        for (p in palmTrees) {
            p.render(canvas)
        }
    }

    /**
     * Checks if player is at or near the main fishing pier casting spot.
     */
    fun isPlayerNearFishingSpot(px: Float, py: Float): Boolean {
        val dx = px - mainFishingDock.castingSpotX
        val dy = py - mainFishingDock.castingSpotY
        return (dx * dx + dy * dy) <= (75f * 75f)
    }

    fun getLocationName(px: Float, py: Float): String {
        return when {
            px in 900f..1060f && py in 200f..400f -> "North Fishing Pier"
            px in 640f..900f && py in 620f..820f -> "Pelican Fish Shop"
            px in 1100f..1350f && py in 620f..820f -> "Tackle & Rod Shop"
            px in 640f..900f && py in 1060f..1280f -> "Fisherman Cottage"
            px in 900f..1060f && py in 1400f..1760f -> "Marina Boat Dock"
            px in 560f..1440f && py in 560f..1440f -> "Island Village"
            else -> "Tropical Beach"
        }
    }
}
