package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.economy.EconomyManager
import com.example.game.fishing.FishingRod

/**
 * Modal dialogue for the Tackle & Rod Shop ("Harbor Rods") where players buy & equip fishing rods.
 */
class RodShopModal(
    val economyManager: EconomyManager,
    var equippedRod: FishingRod,
    val purchasedRods: MutableSet<String>,
    var onRodEquipped: ((FishingRod) -> Unit)? = null,
    var onRodPurchased: ((FishingRod) -> Unit)? = null,
    var onClose: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set

    private val modalRect = RectF()
    private val closeBtnRect = RectF()
    private val rodActionRects = mutableMapOf<String, RectF>()

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(175, 8, 14, 24)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(22, 32, 50)
        style = Paint.Style.FILL
    }

    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(241, 196, 15) // Golden fishing trim
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(32, 46, 72)
        style = Paint.Style.FILL
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 22f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val greetingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 210, 235)
        textAlign = Paint.Align.CENTER
        textSize = 14f
    }

    private val itemBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(15, 24, 38)
        style = Paint.Style.FILL
    }

    private val rodNamePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 225, 110)
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val rodDescPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 195, 215)
        textSize = 12f
    }

    private val actionBtnActive = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113)
        style = Paint.Style.FILL
    }

    private val actionBtnEquipped = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(52, 152, 219)
        style = Paint.Style.FILL
    }

    private val actionBtnDisabled = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(65, 75, 90)
        style = Paint.Style.FILL
    }

    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val closeBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 60, 50)
        style = Paint.Style.FILL
    }

    private val walletTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 215, 65)
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun open() {
        isOpen = true
    }

    fun close() {
        isOpen = false
        onClose?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false

        // Tap Close button
        if (closeBtnRect.contains(touchX, touchY)) {
            close()
            return true
        }

        // Tap on Rod action buttons
        for (rod in FishingRod.ALL_RODS) {
            val rect = rodActionRects[rod.id] ?: continue
            if (rect.contains(touchX, touchY)) {
                val isOwned = purchasedRods.contains(rod.id)
                val isEquipped = equippedRod.id == rod.id

                if (isEquipped) {
                    // Already equipped
                    return true
                }

                if (isOwned) {
                    // Equip owned rod
                    equippedRod = rod
                    onRodEquipped?.invoke(rod)
                    return true
                } else {
                    // Purchase and equip
                    if (economyManager.canAfford(rod.price)) {
                        if (economyManager.spend(rod.price)) {
                            purchasedRods.add(rod.id)
                            equippedRod = rod
                            onRodPurchased?.invoke(rod)
                            onRodEquipped?.invoke(rod)
                        }
                    }
                    return true
                }
            }
        }

        // Tap outside card dismisses
        if (!modalRect.contains(touchX, touchY)) {
            close()
            return true
        }

        return true
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        if (!isOpen) return

        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        val cardW = (screenW * 0.90f).coerceIn(320f, 480f)
        val cardH = 460f
        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        canvas.drawRoundRect(modalRect, 18f, 18f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBorderPaint)

        // Header
        val headerH = 56f
        val headerRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + headerH)
        canvas.drawRoundRect(headerRect, 18f, 18f, headerPaint)
        canvas.drawRect(cardLeft, cardTop + headerH - 12f, cardLeft + cardW, cardTop + headerH, headerPaint)

        canvas.drawText("🎣 Harbor Tackle & Rods", screenW * 0.5f, cardTop + 34f, titlePaint)
        canvas.drawText("Upgrade rods to hook faster bites and rare ocean titans!", screenW * 0.5f, cardTop + headerH + 20f, greetingPaint)

        // List each rod
        var itemY = cardTop + headerH + 34f
        val itemH = 88f
        val btnW = 95f
        val btnH = 34f

        for (rod in FishingRod.ALL_RODS) {
            val itemRect = RectF(cardLeft + 16f, itemY, cardLeft + cardW - 16f, itemY + itemH)
            canvas.drawRoundRect(itemRect, 10f, 10f, itemBoxPaint)

            // Rod icon badge
            val iconBadgeRect = RectF(itemRect.left + 10f, itemY + 14f, itemRect.left + 50f, itemY + 54f)
            val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = rod.rodColor
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(iconBadgeRect, 6f, 6f, iconPaint)
            val iconEmojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textAlign = Paint.Align.CENTER
                textSize = 22f
            }
            canvas.drawText("🎣", iconBadgeRect.centerX(), iconBadgeRect.centerY() + 8f, iconEmojiPaint)

            // Text
            canvas.drawText(rod.name, itemRect.left + 60f, itemY + 28f, rodNamePaint)
            canvas.drawText(rod.description, itemRect.left + 60f, itemY + 48f, rodDescPaint)

            val priceStr = if (rod.price == 0) "Free Starter" else "$${rod.price}"
            val pricePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(255, 215, 65)
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
            }
            canvas.drawText(priceStr, itemRect.left + 60f, itemY + 70f, pricePaint)

            // Action Button (Equipped / Equip / Buy)
            val btnRect = RectF(itemRect.right - btnW - 12f, itemY + 28f, itemRect.right - 12f, itemY + 28f + btnH)
            rodActionRects[rod.id] = btnRect

            val isOwned = purchasedRods.contains(rod.id)
            val isEquipped = equippedRod.id == rod.id
            val canAfford = economyManager.canAfford(rod.price)

            when {
                isEquipped -> {
                    canvas.drawRoundRect(btnRect, 6f, 6f, actionBtnEquipped)
                    canvas.drawText("EQUIPPED", btnRect.centerX(), btnRect.centerY() + 5f, btnTextPaint)
                }
                isOwned -> {
                    canvas.drawRoundRect(btnRect, 6f, 6f, actionBtnActive)
                    canvas.drawText("EQUIP", btnRect.centerX(), btnRect.centerY() + 5f, btnTextPaint)
                }
                canAfford -> {
                    canvas.drawRoundRect(btnRect, 6f, 6f, actionBtnActive)
                    canvas.drawText("BUY $${rod.price}", btnRect.centerX(), btnRect.centerY() + 5f, btnTextPaint)
                }
                else -> {
                    canvas.drawRoundRect(btnRect, 6f, 6f, actionBtnDisabled)
                    canvas.drawText("BUY $${rod.price}", btnRect.centerX(), btnRect.centerY() + 5f, btnTextPaint)
                }
            }

            itemY += itemH + 12f
        }

        // Footer: Wallet balance & Close
        val footerY = cardTop + cardH - 26f
        canvas.drawText("💰 Wallet: ${economyManager.formattedBalance()}", cardLeft + 20f, footerY, walletTextPaint)

        closeBtnRect.set(cardLeft + cardW - 110f, footerY - 24f, cardLeft + cardW - 20f, footerY + 14f)
        canvas.drawRoundRect(closeBtnRect, 8f, 8f, closeBtnPaint)
        canvas.drawText("CLOSE", closeBtnRect.centerX(), closeBtnRect.centerY() + 5f, btnTextPaint)
    }
}
