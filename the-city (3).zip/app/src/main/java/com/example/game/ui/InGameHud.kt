package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.economy.EconomyManager
import com.example.game.fishing.FishingRod
import com.example.game.fishing.FishingState
import com.example.game.interaction.Interactable
import com.example.game.inventory.FishInventory
import kotlin.math.sin

/**
 * Clean, modern fishing HUD for mobile.
 * Displays wallet money, equipped rod, fish creel capacity button, and active state alerts.
 */
class InGameHud(
    val economyManager: EconomyManager,
    val fishInventory: FishInventory
) {
    var currentLocationName: String = "Tropical Island"
    var activeInteractable: Interactable? = null
    var equippedRod: FishingRod = FishingRod.WOODEN_ROD
    var fishingState: FishingState = FishingState.FREE_ROAM

    var onInventoryClicked: (() -> Unit)? = null

    val fishBagRect = RectF()
    private var promptPulseTimer: Float = 0f

    // Paints
    private val pillBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(205, 16, 26, 42) // Deep navy translucent glass
        style = Paint.Style.FILL
    }

    private val pillBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(130, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val goldCoinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 215, 55)
        style = Paint.Style.FILL
    }

    private val moneyTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 230, 100)
        textSize = 19f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val rodTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val inventoryTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 245, 255)
        textAlign = Paint.Align.RIGHT
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val promptBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 18, 30, 48)
        style = Paint.Style.FILL
    }

    private val promptBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113) // Fresh green border
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val promptTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(240, 250, 255)
        textAlign = Paint.Align.CENTER
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun update(deltaTime: Float) {
        promptPulseTimer += deltaTime * 5f
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        // Tapping the Fish Bag badge opens the fish inventory!
        if (fishBagRect.contains(touchX, touchY)) {
            onInventoryClicked?.invoke()
            return true
        }
        return false
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float, safeTopInset: Float = 48f) {
        val topY = safeTopInset + 20f
        val pillH = 40f

        // 1. Top-Left: Money Chip
        val moneyStr = economyManager.formattedBalance()
        val moneyPillW = 120f
        val moneyRect = RectF(20f, topY, 20f + moneyPillW, topY + pillH)
        canvas.drawRoundRect(moneyRect, 20f, 20f, pillBgPaint)
        canvas.drawRoundRect(moneyRect, 20f, 20f, pillBorderPaint)

        val coinX = moneyRect.left + 22f
        val coinY = moneyRect.centerY()
        canvas.drawCircle(coinX, coinY, 9f, goldCoinPaint)
        canvas.drawText(moneyStr, coinX + 16f, coinY + moneyTextPaint.textSize * 0.35f, moneyTextPaint)

        // 2. Top-Center: Equipped Rod Chip
        val rodStr = "🎣 ${equippedRod.name}"
        val rodTextW = rodTextPaint.measureText(rodStr)
        val rodPillW = (rodTextW + 36f).coerceIn(160f, 260f)
        val rodLeft = (screenW - rodPillW) * 0.5f
        val rodRect = RectF(rodLeft, topY, rodLeft + rodPillW, topY + pillH)
        canvas.drawRoundRect(rodRect, 20f, 20f, pillBgPaint)
        canvas.drawRoundRect(rodRect, 20f, 20f, pillBorderPaint)
        canvas.drawText(rodStr, screenW * 0.5f, rodRect.centerY() + rodTextPaint.textSize * 0.35f, rodTextPaint)

        // 3. Top-Right: Fish Bag Badge (Tappable Button!)
        val bagStr = "🎒 ${fishInventory.count}/${fishInventory.capacity}"
        val bagTextW = inventoryTextPaint.measureText(bagStr)
        val bagPillW = bagTextW + 36f
        val bagRight = screenW - 20f
        fishBagRect.set(bagRight - bagPillW, topY, bagRight, topY + pillH)

        val bagBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (fishInventory.isFull) Color.argb(225, 231, 76, 60) else Color.argb(205, 16, 26, 42)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(fishBagRect, 20f, 20f, bagBgPaint)
        canvas.drawRoundRect(fishBagRect, 20f, 20f, pillBorderPaint)
        canvas.drawText(bagStr, bagRight - 16f, fishBagRect.centerY() + inventoryTextPaint.textSize * 0.35f, inventoryTextPaint)

        // 4. State & Proximity Alert Prompts
        val promptStr = when (fishingState) {
            FishingState.CASTING -> "🎣 Casting line..."
            FishingState.WAITING_FOR_BITE -> "🌊 Line in water... Waiting for bite"
            FishingState.BITE -> "⚡ BITE! TAP HOOK NOW!"
            FishingState.CATCHING -> "🎯 REEL! Keep timing in the green zone!"
            else -> {
                activeInteractable?.let { "Near ${it.name} • Tap ${it.actionLabel}" }
            }
        }

        if (promptStr != null) {
            val promptW = promptTextPaint.measureText(promptStr) + 40f
            val promptH = 38f
            val promptY = screenH - 180f
            val promptLeft = (screenW - promptW) * 0.5f
            val promptRect = RectF(promptLeft, promptY, promptLeft + promptW, promptY + promptH)

            canvas.drawRoundRect(promptRect, 18f, 18f, promptBgPaint)

            val isEmergency = fishingState == FishingState.BITE
            promptBorderPaint.color = if (isEmergency) Color.rgb(241, 196, 15) else Color.rgb(46, 204, 113)
            val pulseAlpha = (140 + sin(promptPulseTimer * if (isEmergency) 2f else 1f) * 90).toInt().coerceIn(60, 255)
            promptBorderPaint.alpha = pulseAlpha
            canvas.drawRoundRect(promptRect, 18f, 18f, promptBorderPaint)

            promptTextPaint.color = if (isEmergency) Color.rgb(255, 235, 120) else Color.rgb(240, 250, 255)
            canvas.drawText(promptStr, screenW * 0.5f, promptRect.centerY() + promptTextPaint.textSize * 0.35f, promptTextPaint)
        }
    }
}
