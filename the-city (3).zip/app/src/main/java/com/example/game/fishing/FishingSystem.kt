package com.example.game.fishing

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.inventory.FishInventory
import com.example.game.player.PlayerDirection
import kotlin.math.abs
import kotlin.math.sin

enum class FishingState {
    FREE_ROAM,
    CASTING,
    WAITING_FOR_BITE,
    BITE,
    CATCHING,
    CAUGHT,
    FISH_SHOP,
    ROD_SHOP,
    FISH_INVENTORY
}

/**
 * Handles fishing state machine, rod casting, bite timers, bobber water physics,
 * and the timing-based catch minigame.
 */
class FishingSystem(
    val fishInventory: FishInventory
) {
    var state: FishingState = FishingState.FREE_ROAM
        private set

    var equippedRod: FishingRod = FishingRod.WOODEN_ROD

    // Fishing line & bobber coordinates in world space
    var rodTipX: Float = 0f
    var rodTipY: Float = 0f
    var bobberX: Float = 0f
    var bobberY: Float = 0f

    // Timers
    private var stateTimer: Float = 0f
    private var biteWaitDuration: Float = 3.5f
    private val biteReactionWindow: Float = 2.4f

    // Catch minigame variables
    var targetSpecies: FishSpecies = FishSpecies.CORAL_SARDINE
        private set
    var needlePos: Float = 0f // [0..1]
    var catchZoneStart: Float = 0.35f
    var catchZoneEnd: Float = 0.65f
    private var minigameTimer: Float = 0f
    private val minigameMaxTime: Float = 5.0f

    // Visual ripple effect for bobber
    private var waterRippleTimer: Float = 0f

    // Callbacks
    var onFishCaught: ((CaughtFish) -> Unit)? = null
    var onFishEscaped: ((String) -> Unit)? = null
    var onStateChanged: ((FishingState) -> Unit)? = null

    // Paints
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 255, 255, 255)
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
    }

    private val bobberTopPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(235, 55, 45) // Bright red top
        style = Paint.Style.FILL
    }

    private val bobberBottomPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(140, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val biteAlertPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 220, 40)
        textAlign = Paint.Align.CENTER
        textSize = 28f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val biteStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(30, 20, 10)
        textAlign = Paint.Align.CENTER
        textSize = 28f
        typeface = Typeface.DEFAULT_BOLD
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    fun setState(newState: FishingState) {
        state = newState
        stateTimer = 0f
        onStateChanged?.invoke(newState)
    }

    fun startCasting(playerX: Float, playerY: Float, direction: PlayerDirection, dockReachX: Float, dockReachY: Float) {
        if (fishInventory.isFull) {
            onFishEscaped?.invoke("Fish Creel is full! (10/10) - Sell fish at shop.")
            return
        }

        rodTipX = playerX
        rodTipY = playerY - 32f

        // Place bobber into the water based on dock / cast direction
        bobberX = dockReachX
        bobberY = dockReachY

        // Randomize bite duration based on equipped rod stats
        val baseWait = (2.2f + Math.random().toFloat() * 2.8f)
        biteWaitDuration = baseWait * equippedRod.biteTimeMultiplier

        setState(FishingState.CASTING)
    }

    fun update(deltaTime: Float, playerX: Float, playerY: Float) {
        stateTimer += deltaTime
        waterRippleTimer += deltaTime

        // Update rod tip position near player hands
        rodTipX = playerX + 8f
        rodTipY = playerY - 34f

        when (state) {
            FishingState.CASTING -> {
                if (stateTimer >= 0.5f) {
                    setState(FishingState.WAITING_FOR_BITE)
                }
            }

            FishingState.WAITING_FOR_BITE -> {
                if (stateTimer >= biteWaitDuration) {
                    // Roll prospective fish species for difficulty calculations
                    targetSpecies = FishSpecies.rollRandomFish(equippedRod.rarityBonus)
                    setState(FishingState.BITE)
                }
            }

            FishingState.BITE -> {
                // Bobber plunges and splashes
                if (stateTimer >= biteReactionWindow) {
                    // Too slow, fish got away
                    onFishEscaped?.invoke("Too slow! The fish got away.")
                    setState(FishingState.FREE_ROAM)
                }
            }

            FishingState.CATCHING -> {
                minigameTimer += deltaTime
                // Needle oscillates smoothly across 0..1
                val speed = 2.4f * targetSpecies.rarity.needleSpeed
                needlePos = (sin(minigameTimer * speed) + 1f) * 0.5f

                if (minigameTimer >= minigameMaxTime) {
                    onFishEscaped?.invoke("The line snapped! Fish escaped.")
                    setState(FishingState.FREE_ROAM)
                }
            }

            else -> {}
        }
    }

    fun onActionTriggered(): Boolean {
        when (state) {
            FishingState.BITE -> {
                // Player reacted to the bite! Start catching minigame
                setupMinigame()
                setState(FishingState.CATCHING)
                return true
            }

            FishingState.CATCHING -> {
                // Player tapped REEL! Evaluate needle position
                val inZone = needlePos in catchZoneStart..catchZoneEnd
                if (inZone) {
                    val caught = CaughtFish.generate(targetSpecies)
                    val added = fishInventory.addFish(caught)
                    if (added) {
                        onFishCaught?.invoke(caught)
                    } else {
                        onFishEscaped?.invoke("Creel was full!")
                    }
                    setState(FishingState.CAUGHT)
                } else {
                    onFishEscaped?.invoke("Missed the strike! Fish escaped.")
                    setState(FishingState.FREE_ROAM)
                }
                return true
            }

            FishingState.CAUGHT -> {
                setState(FishingState.FREE_ROAM)
                return true
            }

            else -> return false
        }
    }

    private fun setupMinigame() {
        minigameTimer = 0f
        needlePos = 0f

        // Base zone width + rod bonus
        val baseWidth = targetSpecies.rarity.catchZoneWidth + equippedRod.catchZoneBonus
        val zoneWidth = baseWidth.coerceIn(0.14f, 0.55f)

        // Center the zone around 0.5f with slight random jitter
        val jitter = (Math.random().toFloat() - 0.5f) * 0.15f
        val center = (0.5f + jitter).coerceIn(0.35f, 0.65f)
        catchZoneStart = (center - zoneWidth * 0.5f).coerceIn(0.05f, 0.85f)
        catchZoneEnd = (catchZoneStart + zoneWidth).coerceIn(catchZoneStart + 0.1f, 0.95f)
    }

    fun cancelFishing() {
        if (state != FishingState.FREE_ROAM &&
            state != FishingState.FISH_SHOP &&
            state != FishingState.ROD_SHOP &&
            state != FishingState.FISH_INVENTORY
        ) {
            setState(FishingState.FREE_ROAM)
        }
    }

    fun renderInWorld(canvas: Canvas) {
        if (state == FishingState.FREE_ROAM || state == FishingState.FISH_SHOP ||
            state == FishingState.ROD_SHOP || state == FishingState.FISH_INVENTORY
        ) {
            return
        }

        // 1. Draw flexible curved fishing line from rod tip to bobber
        val path = Path().apply {
            moveTo(rodTipX, rodTipY)
            val midX = (rodTipX + bobberX) * 0.5f
            val sag = if (state == FishingState.BITE || state == FishingState.CATCHING) -8f else 18f
            val midY = (rodTipY + bobberY) * 0.5f + sag
            quadTo(midX, midY, bobberX, bobberY)
        }
        canvas.drawPath(path, linePaint)

        // 2. Draw water ripples around bobber
        val rippleCount = if (state == FishingState.BITE) 3 else 2
        for (i in 0 until rippleCount) {
            val rippleSpeed = if (state == FishingState.BITE) 1.6f else 0.8f
            val progress = (waterRippleTimer * rippleSpeed + i * 0.4f) % 1f
            val maxR = if (state == FishingState.BITE) 24f else 14f
            val r = progress * maxR + 4f
            val alpha = ((1f - progress) * 160).toInt().coerceIn(0, 160)
            ripplePaint.alpha = alpha
            canvas.drawOval(RectF(bobberX - r, bobberY - r * 0.5f, bobberX + r, bobberY + r * 0.5f), ripplePaint)
        }

        // 3. Draw Bobber
        val bobberYOffset = if (state == FishingState.BITE) 4f + sin(waterRippleTimer * 16f) * 3f else sin(waterRippleTimer * 3f) * 2f
        val curBobberY = bobberY + bobberYOffset

        // Red top half
        canvas.drawArc(
            RectF(bobberX - 6f, curBobberY - 7f, bobberX + 6f, curBobberY + 5f),
            180f, 180f, true, bobberTopPaint
        )
        // White bottom half
        canvas.drawArc(
            RectF(bobberX - 6f, curBobberY - 5f, bobberX + 6f, curBobberY + 7f),
            0f, 180f, true, bobberBottomPaint
        )

        // 4. Bite visual indicator above bobber
        if (state == FishingState.BITE) {
            val alertY = bobberY - 32f + sin(waterRippleTimer * 14f) * 4f
            canvas.drawText("🐟 BITE!", bobberX, alertY, biteStrokePaint)
            canvas.drawText("🐟 BITE!", bobberX, alertY, biteAlertPaint)
        }
    }

    fun renderScreenMinigame(canvas: Canvas, screenW: Float, screenH: Float) {
        if (state != FishingState.CATCHING) return

        // Render styled Catching Minigame bar at upper-mid screen
        val barW = (screenW * 0.82f).coerceIn(300f, 480f)
        val barH = 38f
        val barLeft = (screenW - barW) * 0.5f
        val barTop = screenH * 0.32f
        val barRect = RectF(barLeft, barTop, barLeft + barW, barTop + barH)

        // Background shadow & track
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(20, 28, 42)
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 230, 245)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(barRect, 10f, 10f, bgPaint)

        // Green Catch Target Zone
        val zoneLeft = barLeft + barW * catchZoneStart
        val zoneRight = barLeft + barW * catchZoneEnd
        val zoneRect = RectF(zoneLeft, barTop + 3f, zoneRight, barTop + barH - 3f)
        val zonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(46, 204, 113) // Bright green catch zone
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(zoneRect, 6f, 6f, zonePaint)

        // Zone label
        val zoneLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 255, 255)
            textAlign = Paint.Align.CENTER
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("CATCH ZONE", (zoneLeft + zoneRight) * 0.5f, barTop + barH * 0.65f, zoneLabelPaint)

        // Outer border
        canvas.drawRoundRect(barRect, 10f, 10f, borderPaint)

        // Moving Indicator Needle
        val needleX = barLeft + barW * needlePos
        val needleW = 8f
        val needleRect = RectF(needleX - needleW * 0.5f, barTop - 8f, needleX + needleW * 0.5f, barTop + barH + 8f)
        val needlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 225, 50) // Golden needle
            style = Paint.Style.FILL
        }
        val needleBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
        }
        canvas.drawRoundRect(needleRect, 4f, 4f, needlePaint)
        canvas.drawRoundRect(needleRect, 4f, 4f, needleBorder)

        // Title prompt header
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        }
        val subHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 235, 255)
            textAlign = Paint.Align.CENTER
            textSize = 15f
        }
        canvas.drawText("🎣 REEL IN FISH!", screenW * 0.5f, barTop - 28f, headerPaint)
        canvas.drawText("Tap REEL when indicator is in the green zone!", screenW * 0.5f, barTop + barH + 30f, subHeaderPaint)
    }
}
