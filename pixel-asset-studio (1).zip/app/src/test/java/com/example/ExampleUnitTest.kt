package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun testDefaultConfiguration() {
    val viewModel = PixelAssetViewModel()
    assertEquals("https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5", viewModel.apiUrl)
    assertTrue(viewModel.apiKey.startsWith("hf_"))
    assertTrue(viewModel.promptText.isNotEmpty())
    assertTrue(viewModel.uiState.value is AssetGenerationState.Idle)
  }

  @Test
  fun testPromptReset() {
    val viewModel = PixelAssetViewModel()
    viewModel.promptText = "Magic wand"
    assertEquals("Magic wand", viewModel.promptText)
    viewModel.resetToIdle()
    assertTrue(viewModel.uiState.value is AssetGenerationState.Idle)
  }
}
