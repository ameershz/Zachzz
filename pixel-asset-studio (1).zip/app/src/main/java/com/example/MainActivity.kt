package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.concurrent.TimeUnit

// ============================================================================
// Data Models & UI State
// ============================================================================

data class GeneratedAsset(
  val id: String = System.currentTimeMillis().toString(),
  val bitmap: Bitmap,
  val userPrompt: String,
  val fullPrompt: String,
  val timestamp: Long = System.currentTimeMillis()
)

sealed interface AssetGenerationState {
  data object Idle : AssetGenerationState
  data class Loading(val message: String = "Synthesizing 2D pixel art asset...") : AssetGenerationState
  data class Success(val asset: GeneratedAsset) : AssetGenerationState
  data class Error(
    val message: String,
    val httpCode: Int? = null,
    val rawDetails: String? = null,
    val exceptionClass: String? = null,
    val isModelLoading: Boolean = false,
    val estimatedTimeSeconds: Double? = null
  ) : AssetGenerationState
}

// ============================================================================
// ViewModel & Hugging Face Network Logic
// ============================================================================

class PixelAssetViewModel : ViewModel() {

  // Endpoints: Defaults to user specified URL; can easily toggle to router URL
  var apiUrl by mutableStateOf("https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5")
  var apiKey by mutableStateOf("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")

  var promptText by mutableStateOf("A warrior character, side view, run animation, 16-bit")
  var selectedStyleTag by mutableStateOf("16-bit pixel art style, 2D game asset, solid background")

  private val _uiState = MutableStateFlow<AssetGenerationState>(AssetGenerationState.Idle)
  val uiState: StateFlow<AssetGenerationState> = _uiState.asStateFlow()

  private val _history = MutableStateFlow<List<GeneratedAsset>>(emptyList())
  val history: StateFlow<List<GeneratedAsset>> = _history.asStateFlow()

  // OkHttp client with generous timeouts for AI diffusion inference
  private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(60, TimeUnit.SECONDS)
    .readTimeout(90, TimeUnit.SECONDS)
    .writeTimeout(60, TimeUnit.SECONDS)
    .build()

  fun generateAsset() {
    val prompt = promptText.trim()
    if (prompt.isEmpty()) return

    val fullPrompt = if (selectedStyleTag.isNotEmpty()) {
      "$prompt, $selectedStyleTag"
    } else {
      "$prompt, 16-bit pixel art style, 2D game asset, solid background"
    }

    _uiState.value = AssetGenerationState.Loading(
      message = "Contacting Hugging Face AI engine..."
    )

    viewModelScope.launch {
      // CRITICAL: Ensure all network requests and binary transformations run strictly on Dispatchers.IO
      // This guarantees no NetworkOnMainThreadException will ever be thrown.
      val resultState: AssetGenerationState = withContext(Dispatchers.IO) {
        try {
          // Construct JSON Payload safely using org.json.JSONObject
          val jsonPayload = JSONObject().apply {
            put("inputs", fullPrompt)
          }.toString()

          val mediaType = "application/json; charset=utf-8".toMediaType()
          val requestBody = jsonPayload.toRequestBody(mediaType)

          val request = Request.Builder()
            .url(apiUrl)
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(requestBody)
            .build()

          val response = okHttpClient.newCall(request).execute()
          val responseCode = response.code
          val responseMessage = response.message
          val responseBody = response.body

          if (responseBody == null) {
            return@withContext AssetGenerationState.Error(
              message = "HTTP $responseCode $responseMessage: Response body is null",
              httpCode = responseCode,
              rawDetails = "Endpoint: $apiUrl\nHTTP Code: $responseCode\nStatus Message: $responseMessage\nBody: null"
            )
          }

          val bytes = responseBody.bytes()

          if (response.isSuccessful) {
            // Convert byte array returned from the API into a Bitmap
            val decodedBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (decodedBitmap != null) {
              val asset = GeneratedAsset(
                bitmap = decodedBitmap,
                userPrompt = prompt,
                fullPrompt = fullPrompt
              )
              return@withContext AssetGenerationState.Success(asset)
            } else {
              val sample = String(bytes.take(400).toByteArray(), Charsets.UTF_8)
              return@withContext AssetGenerationState.Error(
                message = "HTTP $responseCode $responseMessage: Returned ${bytes.size} bytes but could not decode as image. Response snippet: $sample",
                httpCode = responseCode,
                rawDetails = "Endpoint: $apiUrl\nStatus: HTTP $responseCode $responseMessage\nByte Count: ${bytes.size}\nSample:\n$sample"
              )
            }
          } else {
            // Non-2xx response: Capture EXACT error response body from API
            val errorResponseText = String(bytes, Charsets.UTF_8)
            var isModelLoading = false
            var estimatedTime: Double? = null

            try {
              val errorJson = JSONObject(errorResponseText)
              if (errorJson.has("error")) {
                val rawError = errorJson.getString("error")
                if (rawError.contains("loading", ignoreCase = true)) {
                  isModelLoading = true
                  if (errorJson.has("estimated_time")) {
                    estimatedTime = errorJson.getDouble("estimated_time")
                  }
                }
              }
            } catch (_: Exception) {
              // Not JSON, use raw text directly
            }

            return@withContext AssetGenerationState.Error(
              message = "HTTP $responseCode $responseMessage: $errorResponseText",
              httpCode = responseCode,
              rawDetails = "Endpoint: $apiUrl\nHTTP Code: $responseCode $responseMessage\nResponse Body:\n$errorResponseText",
              isModelLoading = isModelLoading,
              estimatedTimeSeconds = estimatedTime
            )
          }
        } catch (e: Exception) {
          // Capture the EXACT exception type and message directly without generic strings
          val exClass = e.javaClass.name
          val exMsg = e.message ?: e.localizedMessage ?: e.toString()
          val causeInfo = e.cause?.let { " [Caused by ${it.javaClass.simpleName}: ${it.message}]" } ?: ""
          val fullErrorMessage = "$exClass: $exMsg$causeInfo"

          return@withContext AssetGenerationState.Error(
            message = fullErrorMessage,
            exceptionClass = exClass,
            rawDetails = "Endpoint: $apiUrl\nException: $exClass\nMessage: $exMsg\nCause: ${e.cause?.toString() ?: "None"}\n\nStack Trace:\n${e.stackTraceToString()}"
          )
        }
      }

      // Safe state updates on Main thread
      if (resultState is AssetGenerationState.Success) {
        _history.value = listOf(resultState.asset) + _history.value
      }
      _uiState.value = resultState
    }
  }

  fun selectFromHistory(asset: GeneratedAsset) {
    promptText = asset.userPrompt
    _uiState.value = AssetGenerationState.Success(asset)
  }

  fun resetToIdle() {
    _uiState.value = AssetGenerationState.Idle
  }
}

// ============================================================================
// Activity Entry Point
// ============================================================================

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        PixelAssetApp()
      }
    }
  }
}

// ============================================================================
// Main Application UI
// ============================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PixelAssetApp(viewModel: PixelAssetViewModel = viewModel()) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsState()
  val history by viewModel.history.collectAsState()

  var showSettingsDialog by remember { mutableStateOf(false) }
  var showInfoDialog by remember { mutableStateOf(false) }
  var showCheckerboardBg by remember { mutableStateOf(true) }

  val presetPrompts = listOf(
    "Warrior sprite, sword slash animation, 16-bit",
    "Health potion bottle, glowing red elixir, 8-bit",
    "Space fighter starship sprite, top-down view",
    "Treasure chest overflowing with golden coins",
    "Green slime monster, idle breathing stance, retro",
    "Magic wizard staff with floating blue crystal orb"
  )

  val styleOptions = listOf(
    "16-bit pixel art style, 2D game asset, solid background",
    "8-bit retro arcade pixel sprite, solid background",
    "Game Boy 4-shade green monochrome pixel asset",
    "Isometric 2D game building tile, pixel art style",
    "Pixel art inventory item icon, black outline"
  )

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.primaryContainer,
              modifier = Modifier.size(36.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Default.VideogameAsset,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.size(22.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Pixel Asset Studio",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 0.5.sp
                )
              )
              Text(
                text = "2D Game Art Generator",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary
              )
            }
          }
        },
        actions = {
          IconButton(onClick = { showInfoDialog = true }) {
            Icon(
              imageVector = Icons.Default.Info,
              contentDescription = "About App"
            )
          }
          IconButton(onClick = { showSettingsDialog = true }) {
            Icon(
              imageVector = Icons.Default.Settings,
              contentDescription = "API Settings"
            )
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    }
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(rememberScrollState())
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Prompt Input Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
          containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Asset Description",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.SemiBold
            )
            if (viewModel.promptText.isNotEmpty()) {
              Text(
                text = "${viewModel.promptText.length} chars",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          OutlinedTextField(
            value = viewModel.promptText,
            onValueChange = { viewModel.promptText = it },
            modifier = Modifier
              .fillMaxWidth()
              .testTag("prompt_input"),
            placeholder = {
              Text("Enter asset description... (e.g. A warrior character, side view, run animation, 16-bit)")
            },
            maxLines = 3,
            shape = RoundedCornerShape(12.dp),
            trailingIcon = {
              if (viewModel.promptText.isNotEmpty()) {
                IconButton(onClick = { viewModel.promptText = "" }) {
                  Icon(
                    imageVector = Icons.Default.Clear,
                    contentDescription = "Clear Prompt"
                  )
                }
              }
            },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = MaterialTheme.colorScheme.primary,
              unfocusedBorderColor = MaterialTheme.colorScheme.outline
            )
          )

          // Inspiration Presets
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = "Quick Presets:",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              presetPrompts.forEach { preset ->
                SuggestionChip(
                  onClick = { viewModel.promptText = preset },
                  label = {
                    Text(
                      text = preset.substringBefore(","),
                      style = MaterialTheme.typography.labelMedium
                    )
                  }
                )
              }
            }
          }

          // Style Selector
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
              text = "Pixel Art Modifier:",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              styleOptions.forEach { style ->
                val label = style.split(",").firstOrNull() ?: style
                FilterChip(
                  selected = viewModel.selectedStyleTag == style,
                  onClick = { viewModel.selectedStyleTag = style },
                  label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                  colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                  )
                )
              }
            }
          }

          // Generate Asset Button
          val isGenerating = uiState is AssetGenerationState.Loading
          Button(
            onClick = { viewModel.generateAsset() },
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("generate_asset_button"),
            enabled = !isGenerating && viewModel.promptText.isNotBlank(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = MaterialTheme.colorScheme.primaryContainer,
              contentColor = MaterialTheme.colorScheme.onPrimaryContainer
            )
          ) {
            Row(
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (isGenerating) "Generating Asset..." else "Generate Asset",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      // Main Display Area
      when (val state = uiState) {
        is AssetGenerationState.Idle -> {
          IdleCanvasCard()
        }

        is AssetGenerationState.Loading -> {
          LoadingCanvasCard(message = state.message)
        }

        is AssetGenerationState.Error -> {
          ErrorCanvasCard(
            errorState = state,
            currentUrl = viewModel.apiUrl,
            onRetry = { viewModel.generateAsset() },
            onSwitchEndpoint = { newUrl ->
              viewModel.apiUrl = newUrl
              Toast.makeText(context, "Switched endpoint to: $newUrl", Toast.LENGTH_SHORT).show()
              viewModel.generateAsset()
            }
          )
        }

        is AssetGenerationState.Success -> {
          SuccessCanvasCard(
            asset = state.asset,
            showCheckerboard = showCheckerboardBg,
            onToggleCheckerboard = { showCheckerboardBg = !showCheckerboardBg },
            onSave = {
              saveAssetToGallery(context, state.asset.bitmap, state.asset.userPrompt)
            },
            onShare = {
              shareAsset(context, state.asset.bitmap, state.asset.userPrompt)
            }
          )
        }
      }

      // Recent History Carousel
      if (history.isNotEmpty()) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
          )
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              Icon(
                imageVector = Icons.Default.History,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(18.dp)
              )
              Text(
                text = "Session Assets (${history.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.SemiBold
              )
            }

            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              items(history, key = { it.id }) { item ->
                Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  modifier = Modifier
                    .width(88.dp)
                    .clickable { viewModel.selectFromHistory(item) }
                ) {
                  Box(
                    modifier = Modifier
                      .size(80.dp)
                      .clip(RoundedCornerShape(8.dp))
                      .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(8.dp)
                      )
                      .background(Color(0xFF1E1E28)),
                    contentAlignment = Alignment.Center
                  ) {
                    androidx.compose.foundation.Image(
                      bitmap = item.bitmap.asImageBitmap(),
                      contentDescription = item.userPrompt,
                      modifier = Modifier.fillMaxSize(),
                      filterQuality = FilterQuality.None,
                      contentScale = ContentScale.Fit
                    )
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = item.userPrompt,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  // Settings Dialog (API Key & Endpoint)
  if (showSettingsDialog) {
    var tempUrl by remember { mutableStateOf(viewModel.apiUrl) }
    var tempKey by remember { mutableStateOf(viewModel.apiKey) }

    AlertDialog(
      onDismissRequest = { showSettingsDialog = false },
      title = { Text("Hugging Face API Settings") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text(
            text = "Configure your Hugging Face inference endpoint and token.",
            style = MaterialTheme.typography.bodySmall
          )
          OutlinedTextField(
            value = tempUrl,
            onValueChange = { tempUrl = it },
            label = { Text("Model Endpoint URL") },
            maxLines = 2,
            modifier = Modifier.fillMaxWidth()
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            SuggestionChip(
              onClick = {
                tempUrl = "https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5"
              },
              label = { Text("Legacy Host", style = MaterialTheme.typography.labelSmall) }
            )
            SuggestionChip(
              onClick = {
                tempUrl = "https://router.huggingface.co/hf-inference/models/runwayml/stable-diffusion-v1-5"
              },
              label = { Text("Router Host", style = MaterialTheme.typography.labelSmall) }
            )
          }
          OutlinedTextField(
            value = tempKey,
            onValueChange = { tempKey = it },
            label = { Text("Inference Token (API Key)") },
            maxLines = 2,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.apiUrl = tempUrl.trim()
            viewModel.apiKey = tempKey.trim()
            showSettingsDialog = false
            Toast.makeText(context, "API Settings Updated", Toast.LENGTH_SHORT).show()
          }
        ) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { showSettingsDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Info Dialog
  if (showInfoDialog) {
    AlertDialog(
      onDismissRequest = { showInfoDialog = false },
      title = { Text("Pixel Asset Studio") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "Generates high quality 2D game sprites and pixel assets using Hugging Face's Stable Diffusion model.",
            style = MaterialTheme.typography.bodyMedium
          )
          Text(
            text = "• Model: runwayml/stable-diffusion-v1-5\n" +
                "• Crisp pixel scaling enabled (Nearest-Neighbor)\n" +
                "• Supports saving directly to Gallery & PNG sharing\n" +
                "• Cold starts on Hugging Face can take 20-30s",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      },
      confirmButton = {
        TextButton(onClick = { showInfoDialog = false }) {
          Text("OK")
        }
      }
    )
  }
}

// ============================================================================
// Canvas Cards & Visual Components
// ============================================================================

@Composable
fun IdleCanvasCard() {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Surface(
        shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
        modifier = Modifier.size(64.dp)
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Default.VideogameAsset,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(32.dp)
          )
        }
      }
      Spacer(modifier = Modifier.height(16.dp))
      Text(
        text = "Your Game Asset Will Appear Here",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Enter a prompt above and tap 'Generate Asset' to craft 16-bit sprites, potions, weapons, and characters.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )
    }
  }
}

@Composable
fun LoadingCanvasCard(message: String) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(40.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      CircularProgressIndicator(
        modifier = Modifier
          .size(54.dp)
          .testTag("loading_indicator"),
        color = MaterialTheme.colorScheme.primary,
        strokeWidth = 4.dp
      )
      Spacer(modifier = Modifier.height(20.dp))
      Text(
        text = "Generating Asset...",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = message,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.secondary,
        textAlign = TextAlign.Center
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "Please wait (Hugging Face takes ~10-25s)",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}

@Composable
fun ErrorCanvasCard(
  errorState: AssetGenerationState.Error,
  currentUrl: String,
  onRetry: () -> Unit,
  onSwitchEndpoint: (String) -> Unit
) {
  val context = LocalContext.current
  var showDetails by remember { mutableStateOf(false) }

  val routerUrl = "https://router.huggingface.co/hf-inference/models/runwayml/stable-diffusion-v1-5"
  val legacyUrl = "https://api-inference.huggingface.co/models/runwayml/stable-diffusion-v1-5"

  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
    )
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Icon(
          imageVector = Icons.Default.ErrorOutline,
          contentDescription = "Error",
          tint = MaterialTheme.colorScheme.error,
          modifier = Modifier.size(28.dp)
        )
        Text(
          text = if (errorState.isModelLoading) {
            "Model is Loading (~${errorState.estimatedTimeSeconds?.toInt() ?: 20}s)"
          } else {
            "API Request Failed"
          },
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.error
        )
      }

      // Actual exact error message shown directly on the screen
      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
      ) {
        SelectionContainer {
          Text(
            text = errorState.message,
            style = MaterialTheme.typography.bodySmall.copy(
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Medium
            ),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(12.dp)
          )
        }
      }

      // Actions: Retry & Copy exact error
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Button(
          onClick = onRetry,
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error
          ),
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text("Retry Request")
        }

        OutlinedButton(
          onClick = {
            val clip = ClipData.newPlainText("PixelStudio Error", errorState.rawDetails ?: errorState.message)
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(clip)
            Toast.makeText(context, "Copied error to clipboard", Toast.LENGTH_SHORT).show()
          },
          shape = RoundedCornerShape(10.dp)
        ) {
          Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "Copy Error",
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text("Copy")
        }
      }

      // Quick Endpoint switch helper
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        TextButton(onClick = { showDetails = !showDetails }) {
          Icon(
            imageVector = if (showDetails) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
            contentDescription = null,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(if (showDetails) "Hide Technical Trace" else "View Technical Trace")
        }

        if (currentUrl == legacyUrl) {
          TextButton(onClick = { onSwitchEndpoint(routerUrl) }) {
            Icon(
              imageVector = Icons.Default.Link,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("Try Router Host")
          }
        } else {
          TextButton(onClick = { onSwitchEndpoint(legacyUrl) }) {
            Icon(
              imageVector = Icons.Default.Link,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("Try Legacy Host")
          }
        }
      }

      // Expandable Technical Trace
      AnimatedVisibility(visible = showDetails) {
        Surface(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(8.dp),
          color = Color(0xFF111118),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        ) {
          SelectionContainer {
            Text(
              text = errorState.rawDetails ?: errorState.message,
              style = MaterialTheme.typography.labelSmall.copy(
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
              ),
              color = Color(0xFFE2E8F0),
              modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth()
            )
          }
        }
      }
    }
  }
}

@Composable
fun SuccessCanvasCard(
  asset: GeneratedAsset,
  showCheckerboard: Boolean,
  onToggleCheckerboard: () -> Unit,
  onSave: () -> Unit,
  onShare: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Generated 2D Asset",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${asset.bitmap.width}x${asset.bitmap.height} px",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.secondary
          )
        }
        IconButton(onClick = onToggleCheckerboard) {
          Icon(
            imageVector = Icons.Default.GridOn,
            contentDescription = "Toggle Grid/Checkerboard",
            tint = if (showCheckerboard) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
          )
        }
      }

      // Sprite Display Canvas with Checkerboard option
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .aspectRatio(1f)
          .clip(RoundedCornerShape(12.dp))
          .border(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
            shape = RoundedCornerShape(12.dp)
          ),
        contentAlignment = Alignment.Center
      ) {
        if (showCheckerboard) {
          CheckerboardBackground(modifier = Modifier.fillMaxSize())
        } else {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(Color(0xFF14141E))
          )
        }

        // Display the Bitmap in Compose Image using asImageBitmap()
        androidx.compose.foundation.Image(
          bitmap = asset.bitmap.asImageBitmap(),
          contentDescription = "Generated Pixel Art Asset: ${asset.userPrompt}",
          modifier = Modifier
            .fillMaxSize()
            .padding(8.dp)
            .testTag("generated_asset_image"),
          filterQuality = FilterQuality.None, // Crisp nearest-neighbor for pixel art
          contentScale = ContentScale.Fit
        )
      }

      // Prompt Summary badge
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
      ) {
        Text(
          text = asset.fullPrompt,
          style = MaterialTheme.typography.labelSmall,
          fontFamily = FontFamily.Monospace,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      // Action Buttons: Save Asset & Share
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Button(
          onClick = onSave,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("save_asset_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Download,
            contentDescription = null,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text("Save Asset", fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
          onClick = onShare,
          modifier = Modifier
            .height(48.dp)
            .testTag("share_asset_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share",
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}

/**
 * Renders a classic sprite-editor checkerboard background to visualize transparency and outlines.
 */
@Composable
fun CheckerboardBackground(modifier: Modifier = Modifier) {
  val lightColor = Color(0xFF282A3A)
  val darkColor = Color(0xFF1C1E2B)
  val squareSizePx = 28f

  Canvas(modifier = modifier) {
    val cols = (size.width / squareSizePx).toInt() + 1
    val rows = (size.height / squareSizePx).toInt() + 1

    for (c in 0 until cols) {
      for (r in 0 until rows) {
        val color = if ((c + r) % 2 == 0) lightColor else darkColor
        drawRect(
          color = color,
          topLeft = Offset(c * squareSizePx, r * squareSizePx),
          size = Size(squareSizePx, squareSizePx)
        )
      }
    }
  }
}

// ============================================================================
// File Saving & Sharing Helpers
// ============================================================================

fun saveAssetToGallery(context: Context, bitmap: Bitmap, prompt: String) {
  try {
    val filename = "pixel_asset_${System.currentTimeMillis()}.png"
    val contentValues = ContentValues().apply {
      put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
      put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        put(
          MediaStore.MediaColumns.RELATIVE_PATH,
          Environment.DIRECTORY_PICTURES + "/PixelAssets"
        )
        put(MediaStore.MediaColumns.IS_PENDING, 1)
      }
    }

    val resolver = context.contentResolver
    val imageUri: Uri? = resolver.insert(
      MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
      contentValues
    )

    if (imageUri != null) {
      val outputStream: OutputStream? = resolver.openOutputStream(imageUri)
      if (outputStream != null) {
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        outputStream.flush()
        outputStream.close()
      }

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        contentValues.clear()
        contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(imageUri, contentValues, null, null)
      }

      Toast.makeText(
        context,
        "Asset saved to Pictures/PixelAssets!",
        Toast.LENGTH_LONG
      ).show()
    } else {
      Toast.makeText(context, "Failed to create media file.", Toast.LENGTH_SHORT).show()
    }
  } catch (e: Exception) {
    Toast.makeText(context, "Error saving asset: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
  }
}

fun shareAsset(context: Context, bitmap: Bitmap, prompt: String) {
  try {
    val cachePath = File(context.cacheDir, "images")
    cachePath.mkdirs()
    val file = File(cachePath, "pixel_asset_shared.png")
    val stream = FileOutputStream(file)
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
    stream.flush()
    stream.close()

    val contentUri: Uri = FileProvider.getUriForFile(
      context,
      "${context.packageName}.fileprovider",
      file
    )

    val shareIntent = Intent(Intent.ACTION_SEND).apply {
      type = "image/png"
      putExtra(Intent.EXTRA_STREAM, contentUri)
      putExtra(Intent.EXTRA_SUBJECT, "Pixel Art Asset: $prompt")
      putExtra(Intent.EXTRA_TEXT, "Generated 2D game asset for '$prompt' via Pixel Asset Studio")
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    context.startActivity(Intent.createChooser(shareIntent, "Share Pixel Asset"))
  } catch (e: Exception) {
    val shareIntent = Intent(Intent.ACTION_SEND).apply {
      type = "text/plain"
      putExtra(Intent.EXTRA_SUBJECT, "Pixel Art Prompt")
      putExtra(Intent.EXTRA_TEXT, "Pixel Art Game Asset Prompt: $prompt")
    }
    context.startActivity(Intent.createChooser(shareIntent, "Share Prompt"))
  }
}
