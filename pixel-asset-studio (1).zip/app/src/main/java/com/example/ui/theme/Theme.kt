package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = PixelPurpleLight,
  onPrimary = Color(0xFF1E1035),
  primaryContainer = PixelPurplePrimary,
  onPrimaryContainer = Color.White,
  secondary = PixelCyanSecondary,
  onSecondary = Color(0xFF00363D),
  tertiary = PixelAmberTertiary,
  onTertiary = Color(0xFF452B00),
  background = PixelDarkBg,
  onBackground = Color(0xFFF1F5F9),
  surface = PixelDarkSurface,
  onSurface = Color(0xFFF1F5F9),
  surfaceVariant = PixelDarkSurfaceVariant,
  onSurfaceVariant = Color(0xFFCBD5E1),
  outline = PixelDarkOutline,
  error = PixelError,
  onError = Color.White
)

private val LightColorScheme = lightColorScheme(
  primary = PixelPurplePrimary,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFEDE9FE),
  onPrimaryContainer = Color(0xFF4C1D95),
  secondary = PixelCyanSecondary,
  onSecondary = Color.White,
  tertiary = PixelAmberTertiary,
  onTertiary = Color.White,
  background = PixelLightBg,
  onBackground = Color(0xFF0F172A),
  surface = PixelLightSurface,
  onSurface = Color(0xFF0F172A),
  surfaceVariant = PixelLightSurfaceVariant,
  onSurfaceVariant = Color(0xFF475569),
  outline = PixelLightOutline,
  error = PixelError,
  onError = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false, // Use our rich custom game palette by default
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> DarkColorScheme // Game studio looks fantastic in dark mode by default
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
