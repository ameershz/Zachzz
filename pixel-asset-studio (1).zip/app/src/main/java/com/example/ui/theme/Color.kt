package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Pixel Asset Studio Palette
val PixelPurplePrimary = Color(0xFF8B5CF6)
val PixelPurpleLight = Color(0xFFA78BFA)
val PixelCyanSecondary = Color(0xFF06B6D4)
val PixelAmberTertiary = Color(0xFFF59E0B)

val PixelDarkBg = Color(0xFF0F111A)
val PixelDarkSurface = Color(0xFF181A26)
val PixelDarkSurfaceVariant = Color(0xFF242738)
val PixelDarkOutline = Color(0xFF383C56)

val PixelLightBg = Color(0xFFF8FAFC)
val PixelLightSurface = Color(0xFFFFFFFF)
val PixelLightSurfaceVariant = Color(0xFFE2E8F0)
val PixelLightOutline = Color(0xFFCBD5E1)

val PixelSuccess = Color(0xFF10B981)
val PixelError = Color(0xFFEF4444)
val PixelGold = Color(0xFFFBBF24)
