package com.example.farm.data.repository

import android.content.Context
import android.util.Log
import com.example.farm.data.config.GameConfig
import com.example.farm.data.local.AnimalEntity
import com.example.farm.data.local.DailyOrderEntity
import com.example.farm.data.local.DailyRewardEntity
import com.example.farm.data.local.FarmDatabase
import com.example.farm.data.local.FarmPlotEntity
import com.example.farm.data.local.InventoryItemEntity
import com.example.farm.data.local.PlayerProfileEntity
import com.example.farm.data.local.ProductionBuildingEntity
import com.example.farm.data.local.QuestEntity
import com.example.farm.data.local.TransactionEntity
import com.example.farm.data.remote.ConnectionState
import com.example.farm.data.remote.DailyRewardClaimResult
import com.example.farm.data.remote.FirestoreDataSource
import com.example.farm.data.remote.FirestoreFarmPlot
import com.example.farm.data.remote.FirestoreInventoryItem
import com.example.farm.data.remote.FirestoreUserProfile
import com.example.farm.data.remote.NetworkStatusObserver
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

import kotlinx.coroutines.withTimeoutOrNull

data class HarvestResult(
    val cropNameEn: String,
    val cropNameAr: String,
    val xpGained: Int,
    val leveledUp: Boolean,
    val newLevel: Int
)

class FarmRepository(
    private val db: FarmDatabase,
    private val firestoreDataSource: FirestoreDataSource,
    val networkObserver: NetworkStatusObserver
) {
    private val actionMutex = Mutex()
    private var syncJob: Job? = null
    private var listenersJob: Job? = null

    private val _activeUserId = MutableStateFlow<String?>(null)
    val activeUserId: StateFlow<String?> = _activeUserId.asStateFlow()

    private val _syncingState = MutableStateFlow(false)
    val syncingState: StateFlow<Boolean> = _syncingState.asStateFlow()

    // Observable flows for UI backed by fast local Room cache
    val player: Flow<PlayerProfileEntity?> = db.playerDao().getPlayer()
    val plots: Flow<List<FarmPlotEntity>> = db.farmPlotDao().getAllPlots()
    val inventory: Flow<List<InventoryItemEntity>> = db.inventoryDao().getInventoryItems()
    val animals: Flow<List<AnimalEntity>> = db.animalDao().getAllAnimals()
    val productionBuildings: Flow<List<ProductionBuildingEntity>> = db.productionBuildingDao().getAllBuildings()
    val dailyReward: Flow<DailyRewardEntity?> = db.dailyRewardDao().getDailyReward()
    val buildings = db.buildingDao().getAllBuildings()
    val orders: Flow<List<DailyOrderEntity>> = db.dailyOrderDao().getAllOrders()
    val quests: Flow<List<QuestEntity>> = db.questDao().getAllQuests()
    val recentTransactions: Flow<List<TransactionEntity>> = db.transactionDao().getRecentTransactions()

    // Real-time ticking query for local estimated countdown display
    suspend fun checkAndUpdateGrowthTimestamps() = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        db.farmPlotDao().markReadyPlots(now)
        db.animalDao().markReadyAnimals(now)
        db.productionBuildingDao().markReadyProductions(now)
    }

    /**
     * Attaches an authenticated user session:
     * 1. Detects account changes and isolates Room cache.
     * 2. Migrates local Phase 1 data to cloud if new cloud user.
     * 3. Attaches Firestore snapshot listeners and updates Room cache in real-time.
     */
    fun attachUserSession(
        uid: String,
        displayName: String,
        scope: CoroutineScope
    ) {
        if (_activeUserId.value == uid && (syncJob?.isActive == true || listenersJob?.isActive == true)) return
        _activeUserId.value = uid

        listenersJob?.cancel()
        syncJob?.cancel()

        // 1. Launch reactive Firestore listener flows in background job
        listenersJob = scope.launch(Dispatchers.IO) {
            launch {
                firestoreDataSource.observeProfile(uid).collect { remoteProfile ->
                    if (remoteProfile != null) {
                        db.playerDao().deleteOtherProfiles(remoteProfile.uid)
                        db.playerDao().insertOrUpdate(
                            PlayerProfileEntity(
                                id = remoteProfile.uid,
                                username = remoteProfile.username,
                                farmName = remoteProfile.farmName,
                                level = remoteProfile.level,
                                xp = remoteProfile.xp,
                                coins = remoteProfile.coins,
                                gems = remoteProfile.gems,
                                storageCapacity = remoteProfile.storageCapacity,
                                totalHarvests = remoteProfile.totalHarvests,
                                totalCoinsEarned = remoteProfile.totalCoinsEarned,
                                totalAnimalCollections = remoteProfile.totalAnimalCollections,
                                totalGoodsProduced = remoteProfile.totalGoodsProduced,
                                soundEnabled = remoteProfile.soundEnabled,
                                hapticEnabled = remoteProfile.hapticEnabled,
                                language = remoteProfile.language,
                                createdAt = remoteProfile.createdAt,
                                lastLoginAt = remoteProfile.lastLoginAt
                            )
                        )
                    }
                }
            }

            launch {
                firestoreDataSource.observePlots(uid).collect { remotePlots ->
                    if (remotePlots.isNotEmpty()) {
                        db.farmPlotDao().insertPlots(
                            remotePlots.map {
                                FarmPlotEntity(
                                    plotIndex = it.plotIndex,
                                    isUnlocked = it.isUnlocked,
                                    unlockLevel = it.unlockLevel,
                                    unlockCost = it.unlockCost,
                                    cropId = it.cropId,
                                    plantedAt = it.plantedAt,
                                    readyAt = it.readyAt,
                                    state = it.state
                                )
                            }
                        )
                    }
                }
            }

            launch {
                firestoreDataSource.observeInventory(uid).collect { remoteItems ->
                    for (item in remoteItems) {
                        db.inventoryDao().insertOrUpdate(
                            InventoryItemEntity(
                                itemId = item.itemId,
                                category = item.category,
                                quantity = item.quantity
                            )
                        )
                    }
                }
            }

            launch {
                firestoreDataSource.observeAnimals(uid).collect { remoteAnimals ->
                    if (remoteAnimals.isNotEmpty()) {
                        db.animalDao().insertAnimals(
                            remoteAnimals.map {
                                AnimalEntity(
                                    animalId = it.animalId,
                                    animalType = it.animalType,
                                    name = it.name,
                                    fedAt = it.fedAt,
                                    readyAt = it.readyAt,
                                    state = it.state
                                )
                            }
                        )
                    }
                }
            }

            launch {
                firestoreDataSource.observeBuildings(uid).collect { remoteBuildings ->
                    if (remoteBuildings.isNotEmpty()) {
                        db.productionBuildingDao().insertBuildings(
                            remoteBuildings.map {
                                val bConfig = GameConfig.getBuildingById(it.buildingId)
                                ProductionBuildingEntity(
                                    buildingId = it.buildingId,
                                    nameEn = bConfig?.nameEn ?: it.buildingId,
                                    nameAr = bConfig?.nameAr ?: it.buildingId,
                                    level = it.level,
                                    isUnlocked = it.isUnlocked,
                                    unlockLevel = it.unlockLevel,
                                    unlockCost = it.unlockCost,
                                    currentRecipeId = it.currentRecipeId,
                                    startedAt = it.startedAt,
                                    readyAt = it.readyAt,
                                    state = it.state
                                )
                            }
                        )
                    }
                }
            }

            launch {
                firestoreDataSource.observeDailyReward(uid).collect { remoteReward ->
                    if (remoteReward != null) {
                        db.dailyRewardDao().insertOrUpdate(
                            DailyRewardEntity(
                                id = "daily_reward_singleton",
                                lastClaimedDay = remoteReward.lastClaimedDay,
                                lastClaimedAt = remoteReward.lastClaimedAt
                            )
                        )
                    }
                }
            }

            launch {
                firestoreDataSource.observeOrders(uid).collect { remoteOrders ->
                    if (remoteOrders.isNotEmpty()) {
                        db.dailyOrderDao().insertOrders(
                            remoteOrders.map {
                                DailyOrderEntity(
                                    orderId = it.orderId,
                                    titleEn = it.titleEn,
                                    titleAr = it.titleAr,
                                    requiredItemId = it.requiredItemId,
                                    requiredAmount = it.requiredAmount,
                                    rewardCoins = it.rewardCoins,
                                    rewardXp = it.rewardXp,
                                    isCompleted = it.isCompleted,
                                    expiresAt = it.expiresAt
                                )
                            }
                        )
                    }
                }
            }

            launch {
                firestoreDataSource.observeQuests(uid).collect { remoteQuests ->
                    if (remoteQuests.isNotEmpty()) {
                        db.questDao().insertQuests(
                            remoteQuests.map {
                                QuestEntity(
                                    questId = it.questId,
                                    titleEn = it.titleEn,
                                    titleAr = it.titleAr,
                                    descEn = it.descEn,
                                    descAr = it.descAr,
                                    questType = it.questType,
                                    targetCount = it.targetCount,
                                    currentCount = it.currentCount,
                                    rewardCoins = it.rewardCoins,
                                    rewardXp = it.rewardXp,
                                    isClaimed = it.isClaimed
                                )
                            }
                        )
                    }
                }
            }
        }

        // 2. Perform initial sync and migration safely with timeout and guaranteed finally cleanup
        syncJob = scope.launch(Dispatchers.IO) {
            _syncingState.value = true
            try {
                val currentCachedPlayer = db.playerDao().getPlayerDirect()
                var migrationProfile: FirestoreUserProfile? = null
                var migrationPlots: List<FirestoreFarmPlot>? = null
                var migrationInventory: List<FirestoreInventoryItem>? = null

                if (currentCachedPlayer != null && currentCachedPlayer.id == "player_main") {
                    Log.d("FarmRepo", "Found Phase 1 local data, preparing migration for uid: $uid")
                    migrationProfile = FirestoreUserProfile(
                        uid = uid,
                        username = displayName.ifEmpty { currentCachedPlayer.username },
                        farmName = currentCachedPlayer.farmName,
                        level = currentCachedPlayer.level,
                        xp = currentCachedPlayer.xp,
                        coins = currentCachedPlayer.coins,
                        gems = currentCachedPlayer.gems,
                        storageCapacity = currentCachedPlayer.storageCapacity,
                        totalHarvests = currentCachedPlayer.totalHarvests,
                        totalCoinsEarned = currentCachedPlayer.totalCoinsEarned,
                        soundEnabled = currentCachedPlayer.soundEnabled,
                        hapticEnabled = currentCachedPlayer.hapticEnabled,
                        language = currentCachedPlayer.language
                    )

                    val localPlots = db.farmPlotDao().getAllPlotsDirect()
                    if (localPlots.isNotEmpty()) {
                        migrationPlots = localPlots.map {
                            FirestoreFarmPlot(
                                plotIndex = it.plotIndex,
                                isUnlocked = it.isUnlocked,
                                unlockLevel = it.unlockLevel,
                                unlockCost = it.unlockCost,
                                cropId = it.cropId,
                                plantedAt = it.plantedAt,
                                readyAt = it.readyAt,
                                state = it.state
                            )
                        }
                    }

                    val localItems = db.inventoryDao().getAllItemsDirect()
                    if (localItems.isNotEmpty()) {
                        migrationInventory = localItems.map {
                            FirestoreInventoryItem(
                                itemId = it.itemId,
                                category = it.category,
                                quantity = it.quantity
                            )
                        }
                    }
                }

                // Clear cache if switching to a new account ID
                if (currentCachedPlayer != null && currentCachedPlayer.id != uid && currentCachedPlayer.id != "player_main") {
                    Log.d("FarmRepo", "Account switched: Clearing old cache for new UID: $uid")
                    db.clearAllTables()
                }

                // Initialize cloud database with defaults / migrated data if needed
                val initResult = firestoreDataSource.initializeCloudProfileIfMissing(
                    uid = uid,
                    displayName = displayName,
                    initialProfile = migrationProfile,
                    initialPlots = migrationPlots,
                    initialInventory = migrationInventory
                )

                if (initResult.isSuccess) {
                    Log.d("FarmRepo", "Cloud profile verified / initialized successfully for $uid")
                }

                // Await initial profile snapshot with a 3-second timeout so it never hangs indefinitely
                try {
                    withTimeoutOrNull(3000L) {
                        val initialProfile = firestoreDataSource.observeProfile(uid).firstOrNull { it != null }
                        if (initialProfile != null) {
                            db.playerDao().deleteOtherProfiles(initialProfile.uid)
                            db.playerDao().insertOrUpdate(
                                PlayerProfileEntity(
                                    id = initialProfile.uid,
                                    username = initialProfile.username,
                                    farmName = initialProfile.farmName,
                                    level = initialProfile.level,
                                    xp = initialProfile.xp,
                                    coins = initialProfile.coins,
                                    gems = initialProfile.gems,
                                    storageCapacity = initialProfile.storageCapacity,
                                    totalHarvests = initialProfile.totalHarvests,
                                    totalCoinsEarned = initialProfile.totalCoinsEarned,
                                    totalAnimalCollections = initialProfile.totalAnimalCollections,
                                    totalGoodsProduced = initialProfile.totalGoodsProduced,
                                    soundEnabled = initialProfile.soundEnabled,
                                    hapticEnabled = initialProfile.hapticEnabled,
                                    language = initialProfile.language,
                                    createdAt = initialProfile.createdAt,
                                    lastLoginAt = initialProfile.lastLoginAt
                                )
                            )
                        }
                    }
                } catch (e: Exception) {
                    Log.e("FarmRepo", "Error pre-populating Room profile: ${e.message}")
                }
            } catch (e: Exception) {
                Log.e("FarmRepo", "Error attaching user session: ${e.message}", e)
            } finally {
                _syncingState.value = false
            }
        }
    }

    fun detachUserSession() {
        _activeUserId.value = null
        syncJob?.cancel()
        syncJob = null
        listenersJob?.cancel()
        listenersJob = null
        _syncingState.value = false
        CoroutineScope(Dispatchers.IO).launch {
            db.clearAllTables()
        }
    }

    suspend fun updatePreferences(
        farmName: String? = null,
        soundEnabled: Boolean? = null,
        hapticEnabled: Boolean? = null,
        language: String? = null
    ): Result<Unit> {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in"))
        val result = firestoreDataSource.updatePreferences(uid, farmName, soundEnabled, hapticEnabled, language)
        if (result.isSuccess) {
            val player = db.playerDao().getPlayerDirect()
            if (player != null) {
                val updated = player.copy(
                    farmName = farmName ?: player.farmName,
                    soundEnabled = soundEnabled ?: player.soundEnabled,
                    hapticEnabled = hapticEnabled ?: player.hapticEnabled,
                    language = language ?: player.language
                )
                db.playerDao().insertOrUpdate(updated)
                if (farmName != null) {
                    publishCurrentPlayerPublicProfile()
                }
            }
        }

        return result
    }

    // GAMEPLAY OPERATIONS (SERVER-AUTHORITATIVE & MUTEX-PROTECTED)

    suspend fun plantCrop(plotIndex: Int, cropId: String): Result<Unit> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to plant crops"))
        firestoreDataSource.plantCropAuthoritative(uid, plotIndex, cropId)
    }

    suspend fun harvestCrop(plotIndex: Int): Result<HarvestResult> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to harvest"))
        firestoreDataSource.harvestCropAuthoritative(uid, plotIndex)
    }

    suspend fun harvestAllReadyPlots(): Result<Int> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to harvest"))
        val now = System.currentTimeMillis()
        val plotsList = db.farmPlotDao().getAllPlotsDirect()
        val readyPlots = plotsList.filter { it.isUnlocked && it.cropId != null && (it.state == "READY" || (it.readyAt in 1..now)) }

        var count = 0
        for (p in readyPlots) {
            val res = firestoreDataSource.harvestCropAuthoritative(uid, p.plotIndex)
            if (res.isSuccess) count++
        }
        Result.success(count)
    }

    suspend fun buySeeds(cropId: String, quantity: Int = 1): Result<Unit> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to purchase seeds"))
        firestoreDataSource.buySeedsAuthoritative(uid, cropId, quantity)
    }

    suspend fun sellItem(itemId: String, quantity: Int = 1): Result<Int> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to sell items"))
        firestoreDataSource.sellItemAuthoritative(uid, itemId, quantity)
    }

    suspend fun buyAnimal(animalType: String): Result<Unit> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to buy animals"))
        firestoreDataSource.buyAnimalAuthoritative(uid, animalType)
    }

    suspend fun feedAnimal(animalId: String): Result<Unit> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to feed animal"))
        firestoreDataSource.feedAnimalAuthoritative(uid, animalId)
    }

    suspend fun collectAnimalProduct(animalId: String): Result<HarvestResult> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to collect products"))
        firestoreDataSource.collectAnimalProductAuthoritative(uid, animalId)
    }

    suspend fun unlockBuilding(buildingId: String): Result<Unit> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to build workshop"))
        firestoreDataSource.unlockBuildingAuthoritative(uid, buildingId)
    }

    suspend fun startProduction(buildingId: String, recipeId: String): Result<Unit> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to start crafting"))
        firestoreDataSource.startProductionAuthoritative(uid, buildingId, recipeId)
    }

    suspend fun collectProduction(buildingId: String): Result<HarvestResult> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to collect crafted goods"))
        firestoreDataSource.collectProductionAuthoritative(uid, buildingId)
    }

    suspend fun claimDailyReward(): Result<DailyRewardClaimResult> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to claim daily reward"))
        firestoreDataSource.claimDailyRewardAuthoritative(uid)
    }

    suspend fun upgradeSilo(): Result<Int> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to upgrade storage"))
        firestoreDataSource.upgradeSiloAuthoritative(uid)
    }

    suspend fun expandLand(plotIndex: Int): Result<Unit> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to expand farm"))
        firestoreDataSource.expandLandAuthoritative(uid, plotIndex)
    }

    suspend fun completeOrder(orderId: String): Result<HarvestResult> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to complete order"))
        firestoreDataSource.completeOrderAuthoritative(uid, orderId)
    }

    suspend fun claimQuest(questId: String): Result<HarvestResult> = actionMutex.withLock {
        val uid = _activeUserId.value
            ?: return Result.failure(IllegalStateException("Must be signed in to claim quest"))
        firestoreDataSource.claimQuestAuthoritative(uid, questId)
    }

    // PHASE 5: Social & Public World Repository Methods
    suspend fun publishCurrentPlayerPublicProfile(): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = _activeUserId.value ?: return@withContext Result.failure(IllegalStateException("Not signed in"))
        val playerEntity = db.playerDao().getPlayerDirect() ?: return@withContext Result.failure(IllegalStateException("No player profile"))
        val plotEntities = db.farmPlotDao().getAllPlotsDirect()
        val animalEntities = db.animalDao().getAllAnimals()
        val buildingEntities = db.productionBuildingDao().getAllBuildings()

        val firestorePlots = plotEntities.map { p ->
            com.example.farm.data.remote.FirestoreFarmPlot(
                plotIndex = p.plotIndex,
                isUnlocked = p.isUnlocked,
                unlockLevel = p.unlockLevel,
                unlockCost = p.unlockCost,
                cropId = p.cropId,
                plantedAt = p.plantedAt,
                readyAt = p.readyAt,
                state = p.state
            )
        }
        val firestoreAnimals = animalEntities.firstOrNull()?.map { a ->
            com.example.farm.data.remote.FirestoreAnimal(
                animalId = a.animalId,
                animalType = a.animalType,
                name = a.name,
                fedAt = a.fedAt,
                readyAt = a.readyAt,
                state = a.state
            )
        } ?: emptyList()

        val firestoreBuildings = buildingEntities.firstOrNull()?.map { b ->
            com.example.farm.data.remote.FirestoreProductionBuilding(
                buildingId = b.buildingId,
                level = b.level,
                isUnlocked = b.isUnlocked,
                unlockLevel = b.unlockLevel,
                unlockCost = b.unlockCost,
                currentRecipeId = b.currentRecipeId,
                startedAt = b.startedAt,
                readyAt = b.readyAt,
                state = b.state
            )
        } ?: emptyList()

        firestoreDataSource.publishPublicProfileAndFarm(
            uid = uid,
            displayName = playerEntity.username,
            farmName = playerEntity.farmName,
            level = playerEntity.level,
            plots = firestorePlots,
            animals = firestoreAnimals,
            buildings = firestoreBuildings
        )
    }

    fun observeAllPublicProfiles(): Flow<List<com.example.farm.data.local.PublicProfileEntity>> {
        return db.publicProfileDao().getAllPublicProfiles()
    }

    suspend fun refreshPublicProfiles(): Result<List<com.example.farm.data.model.PublicProfile>> = withContext(Dispatchers.IO) {
        val currentUid = _activeUserId.value ?: ""
        firestoreDataSource.fetchPublicProfiles(limitCount = 20).map { remoteProfiles ->
            val entities = remoteProfiles.map { rp ->
                val isLiked = if (currentUid.isNotEmpty() && rp.uid != currentUid) {
                    firestoreDataSource.hasUserLiked(rp.uid, currentUid)
                } else false

                com.example.farm.data.local.PublicProfileEntity(
                    uid = rp.uid,
                    displayName = rp.displayName,
                    farmName = rp.farmName,
                    avatarId = rp.avatarId,
                    level = rp.level,
                    unlockedLandCount = rp.unlockedLandCount,
                    visitorCount = rp.visitorCount,
                    likeCount = rp.likeCount,
                    isLikedByMe = isLiked,
                    updatedAt = rp.updatedAt
                )
            }
            db.publicProfileDao().insertProfiles(entities)

            entities.map { e ->
                com.example.farm.data.model.PublicProfile(
                    uid = e.uid,
                    displayName = e.displayName,
                    farmName = e.farmName,
                    avatarId = e.avatarId,
                    level = e.level,
                    unlockedLandCount = e.unlockedLandCount,
                    visitorCount = e.visitorCount,
                    likeCount = e.likeCount,
                    isLikedByMe = e.isLikedByMe,
                    updatedAt = e.updatedAt
                )
            }
        }
    }

    suspend fun getPublicFarmSnapshot(targetUid: String): Result<com.example.farm.data.model.PublicFarm> = withContext(Dispatchers.IO) {
        firestoreDataSource.fetchPublicFarm(targetUid).map { remoteFarm ->
            if (remoteFarm != null) {
                com.example.farm.data.model.PublicFarm(
                    uid = remoteFarm.uid,
                    farmName = remoteFarm.farmName,
                    ownerName = remoteFarm.ownerName,
                    level = remoteFarm.level,
                    plots = remoteFarm.plots,
                    animals = remoteFarm.animals,
                    buildings = remoteFarm.buildings,
                    updatedAt = remoteFarm.updatedAt
                )
            } else {
                throw IllegalStateException("Farm snapshot not found for user $targetUid")
            }
        }
    }

    suspend fun likePlayerFarm(ownerUid: String): Result<Boolean> = withContext(Dispatchers.IO) {
        val visitorUid = _activeUserId.value ?: return@withContext Result.failure(IllegalStateException("Must be signed in to like farm"))
        val result = firestoreDataSource.likeFarm(ownerUid, visitorUid)
        if (result.isSuccess && result.getOrDefault(false)) {
            val cached = db.publicProfileDao().getPublicProfileDirect(ownerUid)
            if (cached != null) {
                db.publicProfileDao().insertOrUpdate(
                    cached.copy(likeCount = cached.likeCount + 1, isLikedByMe = true)
                )
            }
        }
        result
    }

    suspend fun recordFarmVisit(ownerUid: String): Result<Boolean> = withContext(Dispatchers.IO) {
        val visitorUid = _activeUserId.value ?: return@withContext Result.success(false)
        firestoreDataSource.recordVisit(ownerUid, visitorUid)
    }
}

