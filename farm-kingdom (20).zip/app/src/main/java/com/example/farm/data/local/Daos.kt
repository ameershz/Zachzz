package com.example.farm.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerDao {
    @Query("SELECT * FROM player_profile ORDER BY CASE WHEN id != 'player_main' THEN 0 ELSE 1 END LIMIT 1")
    fun getPlayer(): Flow<PlayerProfileEntity?>

    @Query("SELECT * FROM player_profile ORDER BY CASE WHEN id != 'player_main' THEN 0 ELSE 1 END LIMIT 1")
    suspend fun getPlayerDirect(): PlayerProfileEntity?

    @Query("SELECT * FROM player_profile WHERE id = :id LIMIT 1")
    suspend fun getPlayerById(id: String): PlayerProfileEntity?

    @Query("DELETE FROM player_profile WHERE id != :currentId")
    suspend fun deleteOtherProfiles(currentId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(player: PlayerProfileEntity)

    @Update
    suspend fun update(player: PlayerProfileEntity)

    @Query("DELETE FROM player_profile")
    suspend fun clearAll()
}

@Dao
interface FarmPlotDao {
    @Query("SELECT * FROM farm_plots ORDER BY plotIndex ASC")
    fun getAllPlots(): Flow<List<FarmPlotEntity>>

    @Query("SELECT * FROM farm_plots ORDER BY plotIndex ASC")
    suspend fun getAllPlotsDirect(): List<FarmPlotEntity>

    @Query("SELECT * FROM farm_plots WHERE plotIndex = :index LIMIT 1")
    suspend fun getPlot(index: Int): FarmPlotEntity?

    @Query("UPDATE farm_plots SET state = 'READY' WHERE state = 'GROWING' AND readyAt > 0 AND readyAt <= :currentTime")
    suspend fun markReadyPlots(currentTime: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlots(plots: List<FarmPlotEntity>)

    @Update
    suspend fun updatePlot(plot: FarmPlotEntity)
}

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory_items WHERE quantity > 0")
    fun getInventoryItems(): Flow<List<InventoryItemEntity>>

    @Query("SELECT * FROM inventory_items WHERE quantity > 0")
    suspend fun getAllItemsDirect(): List<InventoryItemEntity>

    @Query("SELECT * FROM inventory_items WHERE itemId = :id LIMIT 1")
    suspend fun getItem(id: String): InventoryItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(item: InventoryItemEntity)

    @Query("DELETE FROM inventory_items WHERE itemId = :id")
    suspend fun deleteItem(id: String)
}

@Dao
interface AnimalDao {
    @Query("SELECT * FROM farm_animals")
    fun getAllAnimals(): Flow<List<AnimalEntity>>

    @Query("SELECT * FROM farm_animals WHERE animalId = :id LIMIT 1")
    suspend fun getAnimal(id: String): AnimalEntity?

    @Query("UPDATE farm_animals SET state = 'READY' WHERE state = 'PRODUCING' AND readyAt > 0 AND readyAt <= :currentTime")
    suspend fun markReadyAnimals(currentTime: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimals(animals: List<AnimalEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(animal: AnimalEntity)

    @Update
    suspend fun updateAnimal(animal: AnimalEntity)
}

@Dao
interface ProductionBuildingDao {
    @Query("SELECT * FROM production_buildings")
    fun getAllBuildings(): Flow<List<ProductionBuildingEntity>>

    @Query("SELECT * FROM production_buildings WHERE buildingId = :id LIMIT 1")
    suspend fun getBuilding(id: String): ProductionBuildingEntity?

    @Query("UPDATE production_buildings SET state = 'READY' WHERE state = 'PRODUCING' AND readyAt > 0 AND readyAt <= :currentTime")
    suspend fun markReadyProductions(currentTime: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuildings(buildings: List<ProductionBuildingEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(building: ProductionBuildingEntity)

    @Update
    suspend fun updateBuilding(building: ProductionBuildingEntity)
}

@Dao
interface DailyRewardDao {
    @Query("SELECT * FROM daily_reward WHERE id = 'daily_reward_singleton' LIMIT 1")
    fun getDailyReward(): Flow<DailyRewardEntity?>

    @Query("SELECT * FROM daily_reward WHERE id = 'daily_reward_singleton' LIMIT 1")
    suspend fun getDailyRewardDirect(): DailyRewardEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(reward: DailyRewardEntity)
}

@Dao
interface BuildingDao {
    @Query("SELECT * FROM buildings")
    fun getAllBuildings(): Flow<List<BuildingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBuildings(buildings: List<BuildingEntity>)

    @Update
    suspend fun updateBuilding(building: BuildingEntity)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC LIMIT 20")
    fun getRecentTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: TransactionEntity)
}

@Dao
interface DailyOrderDao {
    @Query("SELECT * FROM daily_orders")
    fun getAllOrders(): Flow<List<DailyOrderEntity>>

    @Query("SELECT * FROM daily_orders WHERE orderId = :id LIMIT 1")
    suspend fun getOrder(id: String): DailyOrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<DailyOrderEntity>)

    @Update
    suspend fun updateOrder(order: DailyOrderEntity)
}

@Dao
interface QuestDao {
    @Query("SELECT * FROM quests")
    fun getAllQuests(): Flow<List<QuestEntity>>

    @Query("SELECT * FROM quests WHERE questId = :id LIMIT 1")
    suspend fun getQuest(id: String): QuestEntity?

    @Query("SELECT * FROM quests WHERE questType = :type")
    suspend fun getQuestsByType(type: String): List<QuestEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuests(quests: List<QuestEntity>)

    @Update
    suspend fun updateQuest(quest: QuestEntity)
}

@Dao
interface PublicProfileDao {
    @Query("SELECT * FROM public_profiles ORDER BY likeCount DESC, updatedAt DESC")
    fun getAllPublicProfiles(): Flow<List<PublicProfileEntity>>

    @Query("SELECT * FROM public_profiles WHERE uid = :uid LIMIT 1")
    fun getPublicProfile(uid: String): Flow<PublicProfileEntity?>

    @Query("SELECT * FROM public_profiles WHERE uid = :uid LIMIT 1")
    suspend fun getPublicProfileDirect(uid: String): PublicProfileEntity?

    @Query("SELECT * FROM public_profiles WHERE displayName LIKE '%' || :query || '%' OR farmName LIKE '%' || :query || '%' ORDER BY likeCount DESC")
    suspend fun searchPublicProfiles(query: String): List<PublicProfileEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(profile: PublicProfileEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfiles(profiles: List<PublicProfileEntity>)
}

@Dao
interface PublicFarmDao {
    @Query("SELECT * FROM public_farms WHERE uid = :uid LIMIT 1")
    fun getPublicFarm(uid: String): Flow<PublicFarmEntity?>

    @Query("SELECT * FROM public_farms WHERE uid = :uid LIMIT 1")
    suspend fun getPublicFarmDirect(uid: String): PublicFarmEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(farm: PublicFarmEntity)
}

