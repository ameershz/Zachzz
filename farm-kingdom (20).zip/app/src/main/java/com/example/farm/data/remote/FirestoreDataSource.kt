package com.example.farm.data.remote

import android.content.Context
import com.example.R
import com.example.farm.data.config.GameConfig
import com.example.farm.data.repository.HarvestResult
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

class FirestoreDataSource(context: Context) {
    private val databaseId = context.getString(R.string.firestore_database_id)
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(databaseId)

    // Real-time observation Flows
    fun observeProfile(uid: String): Flow<FirestoreUserProfile?> {
        val path = "users/$uid"
        return db.collection("users").document(uid).snapshots()
            .map { it.toObject(FirestoreUserProfile::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
                emit(null)
            }
    }

    fun observePlots(uid: String): Flow<List<FirestoreFarmPlot>> {
        val path = "users/$uid/plots"
        return db.collection("users").document(uid).collection("plots")
            .orderBy("plotIndex")
            .snapshots()
            .map { it.toObjects(FirestoreFarmPlot::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    fun observeInventory(uid: String): Flow<List<FirestoreInventoryItem>> {
        val path = "users/$uid/inventory"
        return db.collection("users").document(uid).collection("inventory")
            .whereGreaterThan("quantity", 0)
            .snapshots()
            .map { it.toObjects(FirestoreInventoryItem::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    fun observeAnimals(uid: String): Flow<List<FirestoreAnimal>> {
        val path = "users/$uid/animals"
        return db.collection("users").document(uid).collection("animals")
            .snapshots()
            .map { it.toObjects(FirestoreAnimal::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    fun observeBuildings(uid: String): Flow<List<FirestoreProductionBuilding>> {
        val path = "users/$uid/buildings"
        return db.collection("users").document(uid).collection("buildings")
            .snapshots()
            .map { it.toObjects(FirestoreProductionBuilding::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    fun observeDailyReward(uid: String): Flow<FirestoreDailyReward?> {
        val path = "users/$uid/dailyReward/daily_reward"
        return db.collection("users").document(uid).collection("dailyReward").document("daily_reward").snapshots()
            .map { it.toObject(FirestoreDailyReward::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
                emit(null)
            }
    }

    fun observeOrders(uid: String): Flow<List<FirestoreDailyOrder>> {
        val path = "users/$uid/orders"
        return db.collection("users").document(uid).collection("orders")
            .snapshots()
            .map { it.toObjects(FirestoreDailyOrder::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    fun observeQuests(uid: String): Flow<List<FirestoreQuest>> {
        val path = "users/$uid/quests"
        return db.collection("users").document(uid).collection("quests")
            .snapshots()
            .map { it.toObjects(FirestoreQuest::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    fun observeTransactions(uid: String): Flow<List<FirestoreTransaction>> {
        val path = "users/$uid/transactions"
        return db.collection("users").document(uid).collection("transactions")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(25)
            .snapshots()
            .map { it.toObjects(FirestoreTransaction::class.java) }
            .catch { e ->
                if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
                emit(emptyList())
            }
    }

    // Profile & Starter Seeding
    suspend fun initializeCloudProfileIfMissing(
        uid: String,
        displayName: String,
        initialProfile: FirestoreUserProfile? = null,
        initialPlots: List<FirestoreFarmPlot>? = null,
        initialInventory: List<FirestoreInventoryItem>? = null
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        try {
            val snapshot = userDocRef.get().await()
            val userExists = snapshot.exists()
            val now = System.currentTimeMillis()

            // 1. Ensure user profile document exists
            if (!userExists) {
                val profileToSave = initialProfile?.copy(uid = uid, username = displayName.ifEmpty { initialProfile.username })
                    ?: FirestoreUserProfile(
                        uid = uid,
                        username = displayName.ifEmpty { "Farmer" },
                        farmName = "Green Meadow Farm",
                        level = 1,
                        xp = 0,
                        coins = GameConfig.STARTING_COINS,
                        gems = GameConfig.STARTING_GEMS,
                        storageCapacity = GameConfig.STARTING_STORAGE,
                        createdAt = now,
                        lastLoginAt = now
                    )
                userDocRef.set(profileToSave).await()
            }

            // 2. Ensure plots subcollection is populated (Self-healing if missing)
            val plotsColl = userDocRef.collection("plots")
            val existingPlotsSnap = plotsColl.limit(1).get().await()
            if (existingPlotsSnap.isEmpty) {
                val plotsToSeed = initialPlots?.takeIf { it.isNotEmpty() } ?: run {
                    val list = mutableListOf<FirestoreFarmPlot>()
                    for (i in 0 until GameConfig.INITIAL_PLOTS_COUNT) {
                        if (i < GameConfig.INITIAL_UNLOCKED_COUNT) {
                            list.add(FirestoreFarmPlot(plotIndex = i, isUnlocked = true, unlockLevel = 1, unlockCost = 0, state = "EMPTY"))
                        } else {
                            val costInfo = GameConfig.PLOT_EXPANSION_COSTS.getOrNull(i - GameConfig.INITIAL_UNLOCKED_COUNT)
                            list.add(FirestoreFarmPlot(plotIndex = i, isUnlocked = false, unlockLevel = costInfo?.first ?: (i - 4), unlockCost = costInfo?.second ?: (i * 500), state = "LOCKED"))
                        }
                    }
                    list
                }
                val plotBatch = db.batch()
                for (p in plotsToSeed) {
                    val plotRef = plotsColl.document("plot_${p.plotIndex}")
                    plotBatch.set(plotRef, p)
                }
                plotBatch.commit().await()
            }

            // 3. Ensure inventory subcollection is populated (Self-healing if missing)
            val invColl = userDocRef.collection("inventory")
            val existingInvSnap = invColl.limit(1).get().await()
            if (existingInvSnap.isEmpty) {
                val inventoryToSeed = initialInventory?.takeIf { it.isNotEmpty() } ?: listOf(
                    FirestoreInventoryItem("wheat_seed", "SEED", 10),
                    FirestoreInventoryItem("corn_seed", "SEED", 6),
                    FirestoreInventoryItem("carrot_seed", "SEED", 4)
                )
                val invBatch = db.batch()
                for (item in inventoryToSeed) {
                    val itemRef = invColl.document(item.itemId)
                    invBatch.set(itemRef, item)
                }
                invBatch.commit().await()
            }

            // 4. Ensure other starter subcollections exist
            val animalsColl = userDocRef.collection("animals")
            if (animalsColl.limit(1).get().await().isEmpty) {
                val chickenRef = animalsColl.document("starter_chicken")
                chickenRef.set(FirestoreAnimal("starter_chicken", "chicken", "Pippa the Hen", 0L, 0L, "HUNGRY")).await()
            }

            val buildingsColl = userDocRef.collection("buildings")
            if (buildingsColl.limit(1).get().await().isEmpty) {
                val bBatch = db.batch()
                for (b in GameConfig.BUILDINGS) {
                    val bRef = buildingsColl.document(b.id)
                    bBatch.set(bRef, FirestoreProductionBuilding(b.id, 1, false, b.unlockLevel, b.unlockCost, null, 0L, 0L, "LOCKED"))
                }
                bBatch.commit().await()
            }

            val dailyRef = userDocRef.collection("dailyReward").document("daily_reward")
            if (!dailyRef.get().await().exists()) {
                dailyRef.set(FirestoreDailyReward("daily_reward", 0, 0L)).await()
            }

            val ordersColl = userDocRef.collection("orders")
            if (ordersColl.limit(1).get().await().isEmpty) {
                val oBatch = db.batch()
                val orders = listOf(
                    FirestoreDailyOrder("order_1", "Grand Wheat Delivery", "توريد قمح ملكي", "crop_wheat", 4, 150, 45, false, now + 86400000L),
                    FirestoreDailyOrder("order_2", "Fresh Sweet Corn", "ذرة حلوة طازجة", "crop_corn", 2, 220, 70, false, now + 86400000L),
                    FirestoreDailyOrder("order_3", "Crispy Carrots Supply", "سلة جزر مقرمش", "crop_carrot", 2, 380, 120, false, now + 86400000L),
                    FirestoreDailyOrder("order_4", "Fresh Farm Eggs Basket", "سلة بيض طازج", "egg", 3, 300, 90, false, now + 86400000L),
                    FirestoreDailyOrder("order_5", "Village Bakery Bread", "خبز القرية الذهبي", "item_bread", 2, 450, 140, false, now + 86400000L)
                )
                for (order in orders) {
                    oBatch.set(ordersColl.document(order.orderId), order)
                }
                oBatch.commit().await()
            }

            val questsColl = userDocRef.collection("quests")
            if (questsColl.limit(1).get().await().isEmpty) {
                val qBatch = db.batch()
                val quests = listOf(
                    FirestoreQuest("quest_1", "Green Beginning", "بداية خضراء", "Plant 3 crops on your farm", "ازرع 3 محاصيل في مزرعتك", "PLANT_CROPS", 3, 0, 150, 40, false),
                    FirestoreQuest("quest_2", "First Bounty", "أول حصاد", "Harvest 3 mature crops", "احصد 3 محاصيل ناضجة", "HARVEST_CROPS", 3, 0, 200, 60, false),
                    FirestoreQuest("quest_3", "Caring Farmer", "مزارع حنون", "Feed your farm animals 2 times", "أطعم حيوانات المزرعة مرتين", "FEED_ANIMALS", 2, 0, 250, 75, false),
                    FirestoreQuest("quest_4", "Fresh Harvest Egg", "سلة الخيرات", "Collect 2 fresh eggs from chickens", "اجمع بيضتين طازجتين من الدجاج", "COLLECT_ANIMAL_PRODUCTS", 2, 0, 300, 90, false),
                    FirestoreQuest("quest_5", "Kingdom Trader", "تاجر المملكة", "Earn 500 Coins from your farm", "اكسب 500 قطعة نقدية من منتجاتك", "EARN_COINS", 500, 0, 350, 100, false),
                    FirestoreQuest("quest_6", "Master Farmer", "مزارع خبير", "Reach Level 3 in the Kingdom", "صل إلى المستوى 3 في المملكة", "LEVEL_UP", 3, 1, 600, 200, false)
                )
                for (quest in quests) {
                    qBatch.set(questsColl.document(quest.questId), quest)
                }
                qBatch.commit().await()
            }

            Result.success(!userExists)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userDocRef.path)
            Result.failure(e)
        }
    }

    // SERVER-AUTHORITATIVE ACTIONS

    suspend fun plantCropAuthoritative(
        uid: String,
        plotIndex: Int,
        cropId: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val crop = GameConfig.getCropById(cropId)
            ?: return@withContext Result.failure(Exception("Unknown crop: $cropId"))

        val plotDocRef = db.collection("users").document(uid).collection("plots").document("plot_$plotIndex")
        val seedDocRef = db.collection("users").document(uid).collection("inventory").document("${cropId}_seed")

        try {
            db.runTransaction { tx ->
                var plotSnap = tx.get(plotDocRef)
                if (!plotSnap.exists()) {
                    if (plotIndex in 0 until GameConfig.INITIAL_PLOTS_COUNT) {
                        val isUnlockedInit = plotIndex < GameConfig.INITIAL_UNLOCKED_COUNT
                        val newPlot = FirestoreFarmPlot(
                            plotIndex = plotIndex,
                            isUnlocked = isUnlockedInit,
                            unlockLevel = if (isUnlockedInit) 1 else (plotIndex - 2),
                            unlockCost = if (isUnlockedInit) 0 else (plotIndex * 500),
                            state = if (isUnlockedInit) "EMPTY" else "LOCKED"
                        )
                        tx.set(plotDocRef, newPlot)
                        plotSnap = tx.get(plotDocRef)
                    } else {
                        throw IllegalStateException("Plot not found")
                    }
                }
                val isUnlocked = plotSnap.getBoolean("isUnlocked") ?: false
                val state = plotSnap.getString("state") ?: "LOCKED"
                if (!isUnlocked || state != "EMPTY") throw IllegalStateException("Plot is not ready for planting")

                val seedSnap = tx.get(seedDocRef)
                if (!seedSnap.exists()) throw IllegalStateException("No ${crop.nameEn} seeds in inventory")
                val seedQty = (seedSnap.getLong("quantity") ?: 0L).toInt()
                if (seedQty <= 0) throw IllegalStateException("No ${crop.nameEn} seeds left")

                if (seedQty == 1) {
                    tx.delete(seedDocRef)
                } else {
                    tx.update(seedDocRef, "quantity", seedQty - 1)
                }

                val now = System.currentTimeMillis()
                val readyAt = now + (crop.growthTimeSeconds * 1000L)
                tx.update(
                    plotDocRef,
                    mapOf(
                        "cropId" to cropId,
                        "plantedAt" to now,
                        "readyAt" to readyAt,
                        "state" to "GROWING"
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, plotDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun harvestCropAuthoritative(
        uid: String,
        plotIndex: Int,
        requestId: String = UUID.randomUUID().toString()
    ): Result<HarvestResult> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val plotDocRef = userDocRef.collection("plots").document("plot_$plotIndex")

        try {
            val result = db.runTransaction { tx ->
                val plotSnap = tx.get(plotDocRef)
                if (!plotSnap.exists()) throw IllegalStateException("Plot not found")

                val isUnlocked = plotSnap.getBoolean("isUnlocked") ?: false
                val state = plotSnap.getString("state") ?: "LOCKED"
                val readyAt = plotSnap.getLong("readyAt") ?: 0L
                val cropId = plotSnap.getString("cropId") ?: throw IllegalStateException("No crop on plot")
                val crop = GameConfig.getCropById(cropId) ?: throw IllegalStateException("Invalid crop")

                val now = System.currentTimeMillis()
                if (!isUnlocked) throw IllegalStateException("Plot is locked")
                if (state != "READY" && !(state == "GROWING" && readyAt > 0 && now >= readyAt)) {
                    throw IllegalStateException("Crop is still growing!")
                }

                val userSnap = tx.get(userDocRef)
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()
                val currentXp = (userSnap.getLong("xp") ?: 0L).toInt()
                val totalHarvests = (userSnap.getLong("totalHarvests") ?: 0L).toInt()

                val cropItemId = "crop_$cropId"
                val cropDocRef = userDocRef.collection("inventory").document(cropItemId)
                val cropSnap = tx.get(cropDocRef)
                val existingQty = if (cropSnap.exists()) (cropSnap.getLong("quantity") ?: 0L).toInt() else 0

                tx.set(
                    cropDocRef,
                    FirestoreInventoryItem(cropItemId, "CROP", existingQty + 1)
                )

                tx.update(
                    plotDocRef,
                    mapOf(
                        "cropId" to null,
                        "plantedAt" to 0L,
                        "readyAt" to 0L,
                        "state" to "EMPTY"
                    )
                )

                var newXp = currentXp + crop.xpReward
                var newLevel = currentLevel
                while (true) {
                    val needed = GameConfig.getXpForLevel(newLevel)
                    if (newXp >= needed) {
                        newXp -= needed
                        newLevel += 1
                    } else {
                        break
                    }
                }

                tx.update(
                    userDocRef,
                    mapOf(
                        "level" to newLevel,
                        "xp" to newXp,
                        "totalHarvests" to totalHarvests + 1
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "HARVEST",
                        descEn = "Harvested ${crop.nameEn} (+${crop.xpReward} XP)",
                        descAr = "تم حصاد ${crop.nameAr} (+${crop.xpReward} نقطة خبرة)",
                        amountCoins = 0,
                        amountXp = crop.xpReward,
                        timestamp = now
                    )
                )

                HarvestResult(
                    cropNameEn = crop.nameEn,
                    cropNameAr = crop.nameAr,
                    xpGained = crop.xpReward,
                    leveledUp = newLevel > currentLevel,
                    newLevel = newLevel
                )
            }.await()

            Result.success(result)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, plotDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun buySeedsAuthoritative(
        uid: String,
        cropId: String,
        quantity: Int,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val crop = GameConfig.getCropById(cropId)
            ?: return@withContext Result.failure(Exception("Unknown crop: $cropId"))

        val totalCost = crop.seedPrice * quantity
        val userDocRef = db.collection("users").document(uid)
        val seedItemId = "${cropId}_seed"
        val seedDocRef = userDocRef.collection("inventory").document(seedItemId)

        try {
            db.runTransaction { tx ->
                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()

                if (currentLevel < crop.unlockLevel) {
                    throw IllegalStateException("Requires Level ${crop.unlockLevel}")
                }
                if (currentCoins < totalCost) {
                    throw IllegalStateException("Not enough coins! Need $totalCost, have $currentCoins")
                }

                val seedSnap = tx.get(seedDocRef)
                val existingQty = if (seedSnap.exists()) (seedSnap.getLong("quantity") ?: 0L).toInt() else 0

                tx.update(userDocRef, "coins", currentCoins - totalCost)
                tx.set(seedDocRef, FirestoreInventoryItem(seedItemId, "SEED", existingQty + quantity))

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "BUY_SEEDS",
                        descEn = "Bought ${quantity}x ${crop.nameEn} Seeds (-$totalCost Coins)",
                        descAr = "شراء ${quantity}x بذور ${crop.nameAr} (-$totalCost قطعة نقدية)",
                        amountCoins = -totalCost,
                        amountXp = 0
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, userDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun sellItemAuthoritative(
        uid: String,
        itemId: String,
        quantity: Int,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Int> = withContext(Dispatchers.IO) {
        var unitPrice = 0
        var itemNameEn = itemId
        var itemNameAr = itemId

        if (itemId.startsWith("crop_")) {
            val cropId = itemId.removePrefix("crop_")
            val crop = GameConfig.getCropById(cropId)
            if (crop != null) {
                unitPrice = crop.sellPrice
                itemNameEn = crop.nameEn
                itemNameAr = crop.nameAr
            }
        } else if (itemId == "egg") {
            unitPrice = 45
            itemNameEn = "Fresh Egg"
            itemNameAr = "بيض طازج"
        } else if (itemId == "milk") {
            unitPrice = 120
            itemNameEn = "Pure Milk"
            itemNameAr = "حليب صافي"
        } else if (itemId == "wool") {
            unitPrice = 280
            itemNameEn = "Soft Wool"
            itemNameAr = "صوف ناعم"
        } else if (itemId.startsWith("item_")) {
            val recipeId = itemId.removePrefix("item_")
            val recipe = GameConfig.getRecipeById(recipeId)
            if (recipe != null) {
                unitPrice = recipe.sellPrice
                itemNameEn = recipe.nameEn
                itemNameAr = recipe.nameAr
            }
        }

        if (unitPrice <= 0) return@withContext Result.failure(Exception("Item not sellable: $itemId"))

        val totalEarnings = unitPrice * quantity
        val userDocRef = db.collection("users").document(uid)
        val itemDocRef = userDocRef.collection("inventory").document(itemId)

        try {
            db.runTransaction { tx ->
                val itemSnap = tx.get(itemDocRef)
                if (!itemSnap.exists()) throw IllegalStateException("Item not found in storage")
                val existingQty = (itemSnap.getLong("quantity") ?: 0L).toInt()
                if (existingQty < quantity) throw IllegalStateException("Not enough items to sell")

                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val totalCoinsEarned = userSnap.getLong("totalCoinsEarned") ?: 0L

                if (existingQty == quantity) {
                    tx.delete(itemDocRef)
                } else {
                    tx.update(itemDocRef, "quantity", existingQty - quantity)
                }

                tx.update(
                    userDocRef,
                    mapOf(
                        "coins" to currentCoins + totalEarnings,
                        "totalCoinsEarned" to totalCoinsEarned + totalEarnings
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "SELL_ITEM",
                        descEn = "Sold ${quantity}x $itemNameEn (+$totalEarnings Coins)",
                        descAr = "بيع ${quantity}x $itemNameAr (+$totalEarnings قطعة نقدية)",
                        amountCoins = totalEarnings,
                        amountXp = 0
                    )
                )
            }.await()
            Result.success(totalEarnings)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, itemDocRef.path)
            Result.failure(e)
        }
    }

    // ANIMALS ACTIONS
    suspend fun buyAnimalAuthoritative(
        uid: String,
        animalType: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val config = GameConfig.getAnimalById(animalType)
            ?: return@withContext Result.failure(Exception("Unknown animal: $animalType"))

        val userDocRef = db.collection("users").document(uid)
        val animalDocRef = userDocRef.collection("animals").document()

        try {
            db.runTransaction { tx ->
                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()

                if (currentLevel < config.requiredLevel) throw IllegalStateException("Requires Level ${config.requiredLevel}")
                if (currentCoins < config.purchaseCost) throw IllegalStateException("Requires ${config.purchaseCost} Coins")

                tx.update(userDocRef, "coins", currentCoins - config.purchaseCost)
                tx.set(
                    animalDocRef,
                    FirestoreAnimal(
                        animalId = animalDocRef.id,
                        animalType = animalType,
                        name = "${config.nameEn} #${animalDocRef.id.take(4)}",
                        fedAt = 0L,
                        readyAt = 0L,
                        state = "HUNGRY"
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "BUY_ANIMAL",
                        descEn = "Adopted ${config.nameEn} (-${config.purchaseCost} Coins)",
                        descAr = "شراء ${config.nameAr} (-${config.purchaseCost} قطعة نقدية)",
                        amountCoins = -config.purchaseCost,
                        amountXp = 0
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, userDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun feedAnimalAuthoritative(
        uid: String,
        animalId: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val animalDocRef = userDocRef.collection("animals").document(animalId)

        try {
            db.runTransaction { tx ->
                val animalSnap = tx.get(animalDocRef)
                if (!animalSnap.exists()) throw IllegalStateException("Animal not found")
                val state = animalSnap.getString("state") ?: "HUNGRY"
                if (state != "HUNGRY") throw IllegalStateException("Animal is already producing or ready")

                val animalType = animalSnap.getString("animalType") ?: "chicken"
                val config = GameConfig.getAnimalById(animalType) ?: throw IllegalStateException("Unknown animal type")

                val feedDocRef = userDocRef.collection("inventory").document(config.feedItemId)
                val feedSnap = tx.get(feedDocRef)
                val feedQty = if (feedSnap.exists()) (feedSnap.getLong("quantity") ?: 0L).toInt() else 0
                if (feedQty <= 0) throw IllegalStateException("Need 1x ${config.feedItemNameEn} to feed this animal")

                if (feedQty == 1) {
                    tx.delete(feedDocRef)
                } else {
                    tx.update(feedDocRef, "quantity", feedQty - 1)
                }

                val now = System.currentTimeMillis()
                val readyAt = now + (config.productionTimeSeconds * 1000L)

                tx.update(
                    animalDocRef,
                    mapOf(
                        "fedAt" to now,
                        "readyAt" to readyAt,
                        "state" to "PRODUCING"
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, animalDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun collectAnimalProductAuthoritative(
        uid: String,
        animalId: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<HarvestResult> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val animalDocRef = userDocRef.collection("animals").document(animalId)

        try {
            val result = db.runTransaction { tx ->
                val animalSnap = tx.get(animalDocRef)
                if (!animalSnap.exists()) throw IllegalStateException("Animal not found")
                val animalType = animalSnap.getString("animalType") ?: "chicken"
                val config = GameConfig.getAnimalById(animalType) ?: throw IllegalStateException("Unknown animal type")

                val state = animalSnap.getString("state") ?: "HUNGRY"
                val readyAt = animalSnap.getLong("readyAt") ?: 0L
                val now = System.currentTimeMillis()

                if (state != "READY" && !(state == "PRODUCING" && readyAt > 0 && now >= readyAt)) {
                    throw IllegalStateException("Product is not ready yet!")
                }

                val userSnap = tx.get(userDocRef)
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()
                val currentXp = (userSnap.getLong("xp") ?: 0L).toInt()
                val collections = (userSnap.getLong("totalAnimalCollections") ?: 0L).toInt()

                val prodDocRef = userDocRef.collection("inventory").document(config.productItemId)
                val prodSnap = tx.get(prodDocRef)
                val existingQty = if (prodSnap.exists()) (prodSnap.getLong("quantity") ?: 0L).toInt() else 0

                tx.set(prodDocRef, FirestoreInventoryItem(config.productItemId, "ANIMAL_PRODUCT", existingQty + 1))

                tx.update(
                    animalDocRef,
                    mapOf(
                        "fedAt" to 0L,
                        "readyAt" to 0L,
                        "state" to "HUNGRY"
                    )
                )

                var newXp = currentXp + config.xpReward
                var newLevel = currentLevel
                while (true) {
                    val needed = GameConfig.getXpForLevel(newLevel)
                    if (newXp >= needed) {
                        newXp -= needed
                        newLevel += 1
                    } else {
                        break
                    }
                }

                tx.update(
                    userDocRef,
                    mapOf(
                        "level" to newLevel,
                        "xp" to newXp,
                        "totalAnimalCollections" to collections + 1
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "ANIMAL_COLLECT",
                        descEn = "Collected 1x ${config.productNameEn} (+${config.xpReward} XP)",
                        descAr = "جمع 1x ${config.productNameAr} (+${config.xpReward} نقطة خبرة)",
                        amountCoins = 0,
                        amountXp = config.xpReward,
                        timestamp = now
                    )
                )

                HarvestResult(
                    cropNameEn = config.productNameEn,
                    cropNameAr = config.productNameAr,
                    xpGained = config.xpReward,
                    leveledUp = newLevel > currentLevel,
                    newLevel = newLevel
                )
            }.await()
            Result.success(result)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, animalDocRef.path)
            Result.failure(e)
        }
    }

    // PRODUCTION BUILDINGS ACTIONS
    suspend fun unlockBuildingAuthoritative(
        uid: String,
        buildingId: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val config = GameConfig.getBuildingById(buildingId)
            ?: return@withContext Result.failure(Exception("Unknown building: $buildingId"))

        val userDocRef = db.collection("users").document(uid)
        val buildingDocRef = userDocRef.collection("buildings").document(buildingId)

        try {
            db.runTransaction { tx ->
                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()

                if (currentLevel < config.unlockLevel) throw IllegalStateException("Requires Level ${config.unlockLevel}")
                if (currentCoins < config.unlockCost) throw IllegalStateException("Requires ${config.unlockCost} Coins")

                tx.update(userDocRef, "coins", currentCoins - config.unlockCost)
                tx.set(
                    buildingDocRef,
                    FirestoreProductionBuilding(
                        buildingId = buildingId,
                        level = 1,
                        isUnlocked = true,
                        unlockLevel = config.unlockLevel,
                        unlockCost = config.unlockCost,
                        currentRecipeId = null,
                        startedAt = 0L,
                        readyAt = 0L,
                        state = "IDLE"
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "UNLOCK_BUILDING",
                        descEn = "Constructed ${config.nameEn} (-${config.unlockCost} Coins)",
                        descAr = "بناء ${config.nameAr} (-${config.unlockCost} قطعة نقدية)",
                        amountCoins = -config.unlockCost,
                        amountXp = 50
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, userDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun startProductionAuthoritative(
        uid: String,
        buildingId: String,
        recipeId: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val recipe = GameConfig.getRecipeById(recipeId)
            ?: return@withContext Result.failure(Exception("Unknown recipe: $recipeId"))

        val userDocRef = db.collection("users").document(uid)
        val buildingDocRef = userDocRef.collection("buildings").document(buildingId)

        try {
            db.runTransaction { tx ->
                val bSnap = tx.get(buildingDocRef)
                if (!bSnap.exists() || (bSnap.getBoolean("isUnlocked") != true)) {
                    throw IllegalStateException("Building is locked or not built")
                }
                val state = bSnap.getString("state") ?: "IDLE"
                if (state != "IDLE") throw IllegalStateException("Building is currently busy crafting")

                val inDocRef = userDocRef.collection("inventory").document(recipe.inputItemId)
                val inSnap = tx.get(inDocRef)
                val inQty = if (inSnap.exists()) (inSnap.getLong("quantity") ?: 0L).toInt() else 0
                if (inQty < recipe.inputAmount) throw IllegalStateException("Need ${recipe.inputAmount}x ${recipe.inputItemNameEn}")

                var secDocRef: com.google.firebase.firestore.DocumentReference? = null
                var secQty = 0
                if (recipe.secondaryInputItemId != null && recipe.secondaryInputAmount > 0) {
                    secDocRef = userDocRef.collection("inventory").document(recipe.secondaryInputItemId)
                    val secSnap = tx.get(secDocRef)
                    secQty = if (secSnap.exists()) (secSnap.getLong("quantity") ?: 0L).toInt() else 0
                    if (secQty < recipe.secondaryInputAmount) throw IllegalStateException("Need ${recipe.secondaryInputAmount}x ${recipe.secondaryInputNameEn}")
                }

                if (inQty == recipe.inputAmount) {
                    tx.delete(inDocRef)
                } else {
                    tx.update(inDocRef, "quantity", inQty - recipe.inputAmount)
                }

                secDocRef?.let {
                    if (secQty == recipe.secondaryInputAmount) {
                        tx.delete(it)
                    } else {
                        tx.update(it, "quantity", secQty - recipe.secondaryInputAmount)
                    }
                }

                val now = System.currentTimeMillis()
                val readyAt = now + (recipe.productionTimeSeconds * 1000L)

                tx.update(
                    buildingDocRef,
                    mapOf(
                        "currentRecipeId" to recipeId,
                        "startedAt" to now,
                        "readyAt" to readyAt,
                        "state" to "PRODUCING"
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, buildingDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun collectProductionAuthoritative(
        uid: String,
        buildingId: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<HarvestResult> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val buildingDocRef = userDocRef.collection("buildings").document(buildingId)

        try {
            val result = db.runTransaction { tx ->
                val bSnap = tx.get(buildingDocRef)
                if (!bSnap.exists()) throw IllegalStateException("Building not found")
                val recipeId = bSnap.getString("currentRecipeId") ?: throw IllegalStateException("No recipe active")
                val recipe = GameConfig.getRecipeById(recipeId) ?: throw IllegalStateException("Unknown recipe")

                val state = bSnap.getString("state") ?: "IDLE"
                val readyAt = bSnap.getLong("readyAt") ?: 0L
                val now = System.currentTimeMillis()

                if (state != "READY" && !(state == "PRODUCING" && readyAt > 0 && now >= readyAt)) {
                    throw IllegalStateException("Production is not ready yet!")
                }

                val userSnap = tx.get(userDocRef)
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()
                val currentXp = (userSnap.getLong("xp") ?: 0L).toInt()
                val goodsProduced = (userSnap.getLong("totalGoodsProduced") ?: 0L).toInt()

                val outDocRef = userDocRef.collection("inventory").document(recipe.outputItemId)
                val outSnap = tx.get(outDocRef)
                val existingOut = if (outSnap.exists()) (outSnap.getLong("quantity") ?: 0L).toInt() else 0

                tx.set(outDocRef, FirestoreInventoryItem(recipe.outputItemId, "PROCESSED", existingOut + recipe.outputAmount))

                tx.update(
                    buildingDocRef,
                    mapOf(
                        "currentRecipeId" to null,
                        "startedAt" to 0L,
                        "readyAt" to 0L,
                        "state" to "IDLE"
                    )
                )

                var newXp = currentXp + recipe.xpReward
                var newLevel = currentLevel
                while (true) {
                    val needed = GameConfig.getXpForLevel(newLevel)
                    if (newXp >= needed) {
                        newXp -= needed
                        newLevel += 1
                    } else {
                        break
                    }
                }

                tx.update(
                    userDocRef,
                    mapOf(
                        "level" to newLevel,
                        "xp" to newXp,
                        "totalGoodsProduced" to goodsProduced + 1
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "PRODUCTION_COLLECT",
                        descEn = "Crafted ${recipe.outputAmount}x ${recipe.nameEn} (+${recipe.xpReward} XP)",
                        descAr = "صناعة ${recipe.outputAmount}x ${recipe.nameAr} (+${recipe.xpReward} نقطة خبرة)",
                        amountCoins = 0,
                        amountXp = recipe.xpReward,
                        timestamp = now
                    )
                )

                HarvestResult(
                    cropNameEn = recipe.nameEn,
                    cropNameAr = recipe.nameAr,
                    xpGained = recipe.xpReward,
                    leveledUp = newLevel > currentLevel,
                    newLevel = newLevel
                )
            }.await()
            Result.success(result)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, buildingDocRef.path)
            Result.failure(e)
        }
    }

    // DAILY REWARDS
    suspend fun claimDailyRewardAuthoritative(
        uid: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<DailyRewardClaimResult> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val rewardDocRef = userDocRef.collection("dailyReward").document("daily_reward")

        try {
            val result = db.runTransaction { tx ->
                val rewardSnap = tx.get(rewardDocRef)
                val now = System.currentTimeMillis()
                var lastClaimedDay = 0
                var lastClaimedAt = 0L

                if (rewardSnap.exists()) {
                    lastClaimedDay = (rewardSnap.getLong("lastClaimedDay") ?: 0L).toInt()
                    lastClaimedAt = rewardSnap.getLong("lastClaimedAt") ?: 0L
                }

                val ONE_DAY_MS = 24 * 60 * 60 * 1000L
                if (lastClaimedAt > 0 && now - lastClaimedAt < ONE_DAY_MS) {
                    throw IllegalStateException("Daily reward already claimed today. Come back tomorrow!")
                }

                var nextDay = lastClaimedDay + 1
                if (nextDay > 7 || (lastClaimedAt > 0 && now - lastClaimedAt > 48 * 60 * 60 * 1000L)) {
                    nextDay = 1
                }

                val config = GameConfig.DAILY_REWARDS.find { it.day == nextDay } ?: GameConfig.DAILY_REWARDS.first()

                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val currentGems = (userSnap.getLong("gems") ?: 0L).toInt()

                tx.update(
                    userDocRef,
                    mapOf(
                        "coins" to currentCoins + config.rewardCoins,
                        "gems" to currentGems + config.rewardGems
                    )
                )

                if (config.rewardItemId != null && config.rewardItemAmount > 0) {
                    val seedDocRef = userDocRef.collection("inventory").document(config.rewardItemId)
                    val seedSnap = tx.get(seedDocRef)
                    val existing = if (seedSnap.exists()) (seedSnap.getLong("quantity") ?: 0L).toInt() else 0
                    tx.set(seedDocRef, FirestoreInventoryItem(config.rewardItemId, "SEED", existing + config.rewardItemAmount))
                }

                tx.set(
                    rewardDocRef,
                    FirestoreDailyReward("daily_reward", nextDay, now)
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "DAILY_REWARD",
                        descEn = "Claimed Day $nextDay Bounty (+${config.rewardCoins} Coins, +${config.rewardGems} Gems)",
                        descAr = "استلام مكافأة اليوم $nextDay (+${config.rewardCoins} قطعة نقدية، +${config.rewardGems} جوهرة)",
                        amountCoins = config.rewardCoins,
                        amountXp = 0,
                        timestamp = now
                    )
                )

                DailyRewardClaimResult(
                    day = nextDay,
                    coins = config.rewardCoins,
                    gems = config.rewardGems,
                    seedId = config.rewardItemId,
                    seedAmount = config.rewardItemAmount
                )
            }.await()
            Result.success(result)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, rewardDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun upgradeSiloAuthoritative(
        uid: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Int> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        try {
            val newCap = db.runTransaction { tx ->
                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val currentCap = (userSnap.getLong("storageCapacity") ?: 100L).toInt()
                val cost = currentCap * 5

                if (currentCoins < cost) throw IllegalStateException("Need $cost Coins to upgrade storage")

                val updatedCap = currentCap + GameConfig.STORAGE_UPGRADE_INCREMENT
                tx.update(
                    userDocRef,
                    mapOf(
                        "coins" to currentCoins - cost,
                        "storageCapacity" to updatedCap
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "SILO_UPGRADE",
                        descEn = "Upgraded Silo capacity to $updatedCap (-$cost Coins)",
                        descAr = "ترقية سعة الصومعة إلى $updatedCap (-$cost قطعة نقدية)",
                        amountCoins = -cost,
                        amountXp = 0
                    )
                )
                updatedCap
            }.await()
            Result.success(newCap)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, userDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun expandLandAuthoritative(
        uid: String,
        plotIndex: Int,
        requestId: String = UUID.randomUUID().toString()
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val plotDocRef = userDocRef.collection("plots").document("plot_$plotIndex")

        try {
            db.runTransaction { tx ->
                val plotSnap = tx.get(plotDocRef)
                if (!plotSnap.exists()) throw IllegalStateException("Plot not found")
                val isUnlocked = plotSnap.getBoolean("isUnlocked") ?: false
                if (isUnlocked) throw IllegalStateException("Plot is already unlocked")

                val unlockLevel = (plotSnap.getLong("unlockLevel") ?: 1L).toInt()
                val unlockCost = (plotSnap.getLong("unlockCost") ?: 0L).toInt()

                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()

                if (currentLevel < unlockLevel) throw IllegalStateException("Requires Level $unlockLevel")
                if (currentCoins < unlockCost) throw IllegalStateException("Requires $unlockCost Coins")

                tx.update(userDocRef, "coins", currentCoins - unlockCost)
                tx.update(
                    plotDocRef,
                    mapOf(
                        "isUnlocked" to true,
                        "state" to "EMPTY",
                        "cropId" to null,
                        "plantedAt" to 0L,
                        "readyAt" to 0L
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "EXPAND_LAND",
                        descEn = "Unlocked Plot #${plotIndex + 1} (-$unlockCost Coins)",
                        descAr = "فتح القطعة الزراعية #${plotIndex + 1} (-$unlockCost قطعة نقدية)",
                        amountCoins = -unlockCost,
                        amountXp = 0
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, plotDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun completeOrderAuthoritative(
        uid: String,
        orderId: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<HarvestResult> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val orderDocRef = userDocRef.collection("orders").document(orderId)

        try {
            val result = db.runTransaction { tx ->
                val orderSnap = tx.get(orderDocRef)
                if (!orderSnap.exists()) throw IllegalStateException("Order not found")
                val isCompleted = orderSnap.getBoolean("isCompleted") ?: false
                if (isCompleted) throw IllegalStateException("Order already completed")

                val reqItemId = orderSnap.getString("requiredItemId") ?: ""
                val reqAmount = (orderSnap.getLong("requiredAmount") ?: 1L).toInt()
                val rewardCoins = (orderSnap.getLong("rewardCoins") ?: 0L).toInt()
                val rewardXp = (orderSnap.getLong("rewardXp") ?: 0L).toInt()
                val titleEn = orderSnap.getString("titleEn") ?: "Order"
                val titleAr = orderSnap.getString("titleAr") ?: "طلب"

                val itemDocRef = userDocRef.collection("inventory").document(reqItemId)
                val itemSnap = tx.get(itemDocRef)
                val currentQty = if (itemSnap.exists()) (itemSnap.getLong("quantity") ?: 0L).toInt() else 0

                if (currentQty < reqAmount) throw IllegalStateException("Insufficient items! Have $currentQty, need $reqAmount")

                // Ensure all reads are executed before any writes
                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val totalCoinsEarned = userSnap.getLong("totalCoinsEarned") ?: 0L
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()
                val currentXp = (userSnap.getLong("xp") ?: 0L).toInt()

                // Writes start here
                if (currentQty == reqAmount) {
                    tx.delete(itemDocRef)
                } else {
                    tx.update(itemDocRef, "quantity", currentQty - reqAmount)
                }

                tx.update(orderDocRef, "isCompleted", true)

                var newXp = currentXp + rewardXp
                var newLevel = currentLevel
                while (true) {
                    val needed = GameConfig.getXpForLevel(newLevel)
                    if (newXp >= needed) {
                        newXp -= needed
                        newLevel += 1
                    } else {
                        break
                    }
                }

                tx.update(
                    userDocRef,
                    mapOf(
                        "coins" to currentCoins + rewardCoins,
                        "totalCoinsEarned" to totalCoinsEarned + rewardCoins,
                        "level" to newLevel,
                        "xp" to newXp
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "ORDER_COMPLETE",
                        descEn = "Completed: $titleEn (+$rewardCoins Coins, +$rewardXp XP)",
                        descAr = "إكمال: $titleAr (+$rewardCoins قطعة نقدية، +$rewardXp خبرة)",
                        amountCoins = rewardCoins,
                        amountXp = rewardXp
                    )
                )

                HarvestResult(
                    cropNameEn = titleEn,
                    cropNameAr = titleAr,
                    xpGained = rewardXp,
                    leveledUp = newLevel > currentLevel,
                    newLevel = newLevel
                )
            }.await()
            Result.success(result)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, orderDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun claimQuestAuthoritative(
        uid: String,
        questId: String,
        requestId: String = UUID.randomUUID().toString()
    ): Result<HarvestResult> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val questDocRef = userDocRef.collection("quests").document(questId)

        try {
            val result = db.runTransaction { tx ->
                val questSnap = tx.get(questDocRef)
                if (!questSnap.exists()) throw IllegalStateException("Quest not found")
                val isClaimed = questSnap.getBoolean("isClaimed") ?: false
                if (isClaimed) throw IllegalStateException("Quest reward already claimed")

                val targetCount = (questSnap.getLong("targetCount") ?: 1L).toInt()
                val currentCount = (questSnap.getLong("currentCount") ?: 0L).toInt()
                if (currentCount < targetCount) throw IllegalStateException("Quest objectives not completed yet")

                val rewardCoins = (questSnap.getLong("rewardCoins") ?: 0L).toInt()
                val rewardXp = (questSnap.getLong("rewardXp") ?: 0L).toInt()
                val titleEn = questSnap.getString("titleEn") ?: "Quest"
                val titleAr = questSnap.getString("titleAr") ?: "مهمة"

                // Ensure all reads are executed before any writes
                val userSnap = tx.get(userDocRef)
                val currentCoins = (userSnap.getLong("coins") ?: 0L).toInt()
                val totalCoinsEarned = userSnap.getLong("totalCoinsEarned") ?: 0L
                val currentLevel = (userSnap.getLong("level") ?: 1L).toInt()
                val currentXp = (userSnap.getLong("xp") ?: 0L).toInt()

                // Writes start here
                tx.update(questDocRef, "isClaimed", true)

                var newXp = currentXp + rewardXp
                var newLevel = currentLevel
                while (true) {
                    val needed = GameConfig.getXpForLevel(newLevel)
                    if (newXp >= needed) {
                        newXp -= needed
                        newLevel += 1
                    } else {
                        break
                    }
                }

                tx.update(
                    userDocRef,
                    mapOf(
                        "coins" to currentCoins + rewardCoins,
                        "totalCoinsEarned" to totalCoinsEarned + rewardCoins,
                        "level" to newLevel,
                        "xp" to newXp
                    )
                )

                val txRef = userDocRef.collection("transactions").document()
                tx.set(
                    txRef,
                    FirestoreTransaction(
                        id = txRef.id,
                        type = "QUEST_CLAIM",
                        descEn = "Claimed: $titleEn (+$rewardCoins Coins, +$rewardXp XP)",
                        descAr = "استلام: $titleAr (+$rewardCoins قطعة نقدية، +$rewardXp خبرة)",
                        amountCoins = rewardCoins,
                        amountXp = rewardXp
                    )
                )

                HarvestResult(
                    cropNameEn = titleEn,
                    cropNameAr = titleAr,
                    xpGained = rewardXp,
                    leveledUp = newLevel > currentLevel,
                    newLevel = newLevel
                )
            }.await()
            Result.success(result)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.TRANSACTION, questDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun updatePreferences(
        uid: String,
        farmName: String? = null,
        soundEnabled: Boolean? = null,
        hapticEnabled: Boolean? = null,
        language: String? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val userDocRef = db.collection("users").document(uid)
        val updates = mutableMapOf<String, Any>()
        farmName?.let { updates["farmName"] = it }
        soundEnabled?.let { updates["soundEnabled"] = it }
        hapticEnabled?.let { updates["hapticEnabled"] = it }
        language?.let { updates["language"] = it }
        updates["lastLoginAt"] = System.currentTimeMillis()

        try {
            userDocRef.update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, userDocRef.path)
            Result.failure(e)
        }
    }

    // PHASE 5: Public Profiles, Farm Snapshots, Likes, and Visits
    suspend fun publishPublicProfileAndFarm(
        uid: String,
        displayName: String,
        farmName: String,
        level: Int,
        plots: List<FirestoreFarmPlot>,
        animals: List<FirestoreAnimal>,
        buildings: List<FirestoreProductionBuilding>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val profileRef = db.collection("publicProfiles").document(uid)
        val farmRef = db.collection("publicFarms").document(uid)

        try {
            val unlockedPlotsCount = plots.count { it.isUnlocked }
            val batch = db.batch()

            // Update public profile
            val profileUpdates = mapOf(
                "uid" to uid,
                "displayName" to displayName.ifEmpty { "Farmer" },
                "farmName" to farmName.ifEmpty { "Green Meadow Farm" },
                "avatarId" to "avatar_1",
                "level" to level,
                "unlockedLandCount" to unlockedPlotsCount,
                "updatedAt" to System.currentTimeMillis()
            )
            batch.set(profileRef, profileUpdates, com.google.firebase.firestore.SetOptions.merge())

            // Update public farm snapshot
            val publicFarm = FirestorePublicFarm(
                uid = uid,
                farmName = farmName,
                ownerName = displayName,
                level = level,
                plots = plots,
                animals = animals,
                buildings = buildings,
                updatedAt = System.currentTimeMillis()
            )
            batch.set(farmRef, publicFarm, com.google.firebase.firestore.SetOptions.merge())

            batch.commit().await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, profileRef.path)
            Result.failure(e)
        }
    }

    suspend fun fetchPublicProfiles(limitCount: Long = 20): Result<List<FirestorePublicProfile>> = withContext(Dispatchers.IO) {
        val path = "publicProfiles"
        try {
            val snapshot = db.collection(path)
                .limit(limitCount)
                .get()
                .await()
            val profiles = snapshot.documents.mapNotNull { doc ->
                val base = doc.toObject(FirestorePublicProfile::class.java) ?: return@mapNotNull null
                val uid = doc.id
                val likesCount = try {
                    db.collection("publicProfiles").document(uid).collection("likes").get().await().size()
                } catch (e: Exception) { 0 }
                val visitsCount = try {
                    db.collection("publicProfiles").document(uid).collection("visits").get().await().size()
                } catch (e: Exception) { 0 }
                base.copy(likeCount = likesCount, visitorCount = visitsCount)
            }
            Result.success(profiles)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            Result.failure(e)
        }
    }

    suspend fun fetchPublicProfile(uid: String): Result<FirestorePublicProfile?> = withContext(Dispatchers.IO) {
        val path = "publicProfiles/$uid"
        try {
            val doc = db.collection("publicProfiles").document(uid).get().await()
            val base = doc.toObject(FirestorePublicProfile::class.java)
            if (base != null) {
                val likesCount = try {
                    db.collection("publicProfiles").document(uid).collection("likes").get().await().size()
                } catch (e: Exception) { 0 }
                val visitsCount = try {
                    db.collection("publicProfiles").document(uid).collection("visits").get().await().size()
                } catch (e: Exception) { 0 }
                Result.success(base.copy(likeCount = likesCount, visitorCount = visitsCount))
            } else {
                Result.success(null)
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }


    suspend fun fetchPublicFarm(uid: String): Result<FirestorePublicFarm?> = withContext(Dispatchers.IO) {
        val path = "publicFarms/$uid"
        try {
            val snapshot = db.collection("publicFarms").document(uid).get().await()
            val farm = snapshot.toObject(FirestorePublicFarm::class.java)
            Result.success(farm)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            Result.failure(e)
        }
    }

    suspend fun hasUserLiked(ownerUid: String, visitorUid: String): Boolean = withContext(Dispatchers.IO) {
        if (ownerUid == visitorUid) return@withContext false
        try {
            val doc = db.collection("publicProfiles").document(ownerUid)
                .collection("likes").document(visitorUid).get().await()
            doc.exists()
        } catch (e: Exception) {
            false
        }
    }

    suspend fun likeFarm(ownerUid: String, visitorUid: String): Result<Boolean> = withContext(Dispatchers.IO) {
        if (ownerUid == visitorUid) return@withContext Result.failure(IllegalArgumentException("Cannot like own farm"))
        val likeDocRef = db.collection("publicProfiles").document(ownerUid)
            .collection("likes").document(visitorUid)

        try {
            val existing = likeDocRef.get().await()
            if (existing.exists()) {
                return@withContext Result.success(false) // Already liked
            }

            likeDocRef.set(FirestoreLike(visitorUid = visitorUid, createdAt = System.currentTimeMillis())).await()
            Result.success(true)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, likeDocRef.path)
            Result.failure(e)
        }
    }

    suspend fun recordVisit(ownerUid: String, visitorUid: String): Result<Boolean> = withContext(Dispatchers.IO) {
        if (ownerUid == visitorUid) return@withContext Result.success(false)
        val visitDocRef = db.collection("publicProfiles").document(ownerUid)
            .collection("visits").document(visitorUid)

        try {
            val existing = visitDocRef.get().await()
            if (!existing.exists()) {
                visitDocRef.set(FirestoreVisit(visitorUid = visitorUid, visitedAt = System.currentTimeMillis())).await()
                Result.success(true)
            } else {
                visitDocRef.update("visitedAt", System.currentTimeMillis()).await()
                Result.success(false)
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, visitDocRef.path)
            Result.failure(e)
        }
    }

}


data class DailyRewardClaimResult(
    val day: Int,
    val coins: Int,
    val gems: Int,
    val seedId: String?,
    val seedAmount: Int
)
