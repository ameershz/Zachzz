package com.example.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast

@SuppressLint("ViewConstructor")
class InPlaceOverlayCanvasView(
    context: Context,
    private val windowManager: WindowManager,
    private val onDismissCallback: () -> Unit
) : View(context) {

    private var isAttached = false
    private var translatedBlocks: List<InPlaceTranslatedBlock> = emptyList()

    private var bitmapWidth: Int = 1080
    private var bitmapHeight: Int = 1920

    private var onOpenDetailCardAction: ((String, String) -> Unit)? = null

    // Cache of scaled rects for click interaction
    private val scaledHitRects = mutableListOf<Pair<RectF, InPlaceTranslatedBlock>>()

    // 1. Solid Dark Background Mask Paint (No stroke, fully opaque/masking)
    private val bgMaskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#E6202124") // Solid dark mask like Google/Bubble Translate
    }

    // 2. Crisp High-Contrast Text Paint
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
    }

    // Top Minimal Control Bar Rects
    private val topBarRect = RectF()
    private val copyBtnRect = RectF()
    private val cardBtnRect = RectF()
    private val closeBtnRect = RectF()

    private val topBarBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F2202124")
        style = Paint.Style.FILL
    }

    private val btnBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun show(
        blocks: List<InPlaceTranslatedBlock>,
        bmpWidth: Int,
        bmpHeight: Int,
        onOpenDetailCard: (String, String) -> Unit
    ) {
        this.translatedBlocks = blocks
        this.bitmapWidth = bmpWidth.coerceAtLeast(1)
        this.bitmapHeight = bmpHeight.coerceAtLeast(1)
        this.onOpenDetailCardAction = onOpenDetailCard

        attachToWindow()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (translatedBlocks.isEmpty()) return

        // Calculate Exact Coordinate Scaling from Bitmap to Screen
        val displayW = width.toFloat()
        val displayH = height.toFloat()
        val scaleX = displayW / bitmapWidth.toFloat()
        val scaleY = displayH / bitmapHeight.toFloat()

        scaledHitRects.clear()

        val cornerRadius = dpToPx(3f)
        val padX = dpToPx(3f)
        val padY = dpToPx(2f)

        // Render each translated text block with solid mask and clean fitted text
        for (block in translatedBlocks) {
            val rawBox = block.boundingBox

            // Precise coordinate scaling
            val scaledLeft = (rawBox.left * scaleX) - padX
            val scaledTop = (rawBox.top * scaleY) - padY
            val scaledRight = (rawBox.right * scaleX) + padX
            val scaledBottom = (rawBox.bottom * scaleY) + padY

            val boxWidth = (scaledRight - scaledLeft).coerceAtLeast(dpToPx(20f))
            val boxHeight = (scaledBottom - scaledTop).coerceAtLeast(dpToPx(16f))

            val clampedLeft = scaledLeft.coerceIn(0f, displayW - boxWidth)
            val clampedTop = scaledTop.coerceIn(0f, displayH - boxHeight)
            val rectF = RectF(clampedLeft, clampedTop, clampedLeft + boxWidth, clampedTop + boxHeight)

            scaledHitRects.add(Pair(rectF, block))

            // 1. Draw Solid Masking Background Rectangle (No stroke, completely covers original text)
            bgMaskPaint.color = if (block.isShowingOriginal) Color.parseColor("#E62E3035") else Color.parseColor("#E6202124")
            canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, bgMaskPaint)

            // 2. Render Text cleanly fitted inside the bounding box
            val displayText = if (block.isShowingOriginal) block.originalText else block.translatedText
            val horizontalPadding = dpToPx(4f)
            val availableTextWidth = (rectF.width() - (horizontalPadding * 2)).toInt().coerceAtLeast(10)

            // Auto-fit font size based on box height and text length
            val optimalFontSize = calculateOptimalFontSize(
                text = displayText,
                availableWidth = availableTextWidth,
                availableHeight = (rectF.height() - dpToPx(4f)).toInt()
            )

            textPaint.textSize = optimalFontSize
            textPaint.color = if (block.isShowingOriginal) Color.parseColor("#FFD54F") else Color.WHITE

            val staticLayout = createStaticLayout(displayText, textPaint, availableTextWidth)

            val layoutHeight = staticLayout.height
            val verticalOffset = rectF.top + ((rectF.height() - layoutHeight) / 2f).coerceAtLeast(0f)
            val horizontalOffset = rectF.left + horizontalPadding

            canvas.save()
            canvas.translate(horizontalOffset, verticalOffset)
            staticLayout.draw(canvas)
            canvas.restore()
        }

        // Draw Minimal Top Action Bar
        drawTopControlBar(canvas)
    }

    private fun calculateOptimalFontSize(text: CharSequence, availableWidth: Int, availableHeight: Int): Float {
        // Start from an ideal maximum size and scale down until the text fits nicely
        var sizeSp = when {
            availableHeight >= dpToPx(48f) -> 14f
            availableHeight >= dpToPx(32f) -> 12f
            availableHeight >= dpToPx(22f) -> 10.5f
            availableHeight >= dpToPx(16f) -> 9.5f
            else -> 8.5f
        }

        var pxSize = dpToPx(sizeSp)
        textPaint.textSize = pxSize

        for (i in 0 until 4) {
            val layout = createStaticLayout(text, textPaint, availableWidth)
            if (layout.height <= availableHeight || sizeSp <= 7.5f) {
                break
            }
            sizeSp -= 1f
            pxSize = dpToPx(sizeSp)
            textPaint.textSize = pxSize
        }

        return pxSize
    }

    private fun drawTopControlBar(canvas: Canvas) {
        val barW = dpToPx(240f)
        val barH = dpToPx(36f)
        val barLeft = (width - barW) / 2f
        val barTop = dpToPx(36f)
        topBarRect.set(barLeft, barTop, barLeft + barW, barTop + barH)

        // Subtle dark bar background
        canvas.drawRoundRect(topBarRect, dpToPx(18f), dpToPx(18f), topBarBgPaint)

        // Text count
        textPaint.textSize = dpToPx(11f)
        textPaint.color = Color.parseColor("#00E5FF")
        val countStr = "⚡ ${translatedBlocks.size}"
        canvas.drawText(countStr, barLeft + dpToPx(14f), barTop + dpToPx(22.5f), textPaint)

        val btnH = dpToPx(24f)
        val btnY = barTop + (barH - btnH) / 2f

        // Copy Button
        val copyW = dpToPx(48f)
        val copyX = barLeft + dpToPx(66f)
        copyBtnRect.set(copyX, btnY, copyX + copyW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#3300E676")
        canvas.drawRoundRect(copyBtnRect, dpToPx(12f), dpToPx(12f), btnBgPaint)
        textPaint.textSize = dpToPx(10f)
        textPaint.color = Color.parseColor("#00E676")
        canvas.drawText("نسخ", copyX + dpToPx(14f), btnY + dpToPx(16f), textPaint)

        // Card Button
        val cardW = dpToPx(52f)
        val cardX = copyX + copyW + dpToPx(6f)
        cardBtnRect.set(cardX, btnY, cardX + cardW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#33B388FF")
        canvas.drawRoundRect(cardBtnRect, dpToPx(12f), dpToPx(12f), btnBgPaint)
        textPaint.color = Color.parseColor("#B388FF")
        canvas.drawText("بطاقة", cardX + dpToPx(12f), btnY + dpToPx(16f), textPaint)

        // Close Button
        val closeW = dpToPx(32f)
        val closeX = cardX + cardW + dpToPx(6f)
        closeBtnRect.set(closeX, btnY, closeX + closeW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#33FF5252")
        canvas.drawRoundRect(closeBtnRect, dpToPx(12f), dpToPx(12f), btnBgPaint)
        textPaint.color = Color.parseColor("#FF5252")
        canvas.drawText("✕", closeX + dpToPx(11f), btnY + dpToPx(16f), textPaint)
    }

    private fun createStaticLayout(text: CharSequence, paint: TextPaint, width: Int): StaticLayout {
        val safeWidth = width.coerceAtLeast(10)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, safeWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, 1.0f)
                .setIncludePad(false)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(
                text,
                paint,
                safeWidth,
                Layout.Alignment.ALIGN_CENTER,
                1.0f,
                0f,
                false
            )
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val x = event.x
            val y = event.y

            // 1. Top Bar Actions
            if (copyBtnRect.contains(x, y)) {
                val fullAr = translatedBlocks.joinToString("\n\n") { it.translatedText }
                copyToClipboard("Translations", fullAr)
                Toast.makeText(context, "تم نسخ جميع الترجمات (${translatedBlocks.size})", Toast.LENGTH_SHORT).show()
                return true
            }

            if (cardBtnRect.contains(x, y)) {
                val fullEn = translatedBlocks.joinToString("\n\n") { it.originalText }
                val fullAr = translatedBlocks.joinToString("\n\n") { it.translatedText }
                dismiss()
                onOpenDetailCardAction?.invoke(fullEn, fullAr)
                return true
            }

            if (closeBtnRect.contains(x, y)) {
                dismiss()
                return true
            }

            if (topBarRect.contains(x, y)) {
                return true
            }

            // 2. Tap on individual translated block to toggle between Arabic & Original English
            for ((rectF, block) in scaledHitRects) {
                if (rectF.contains(x, y)) {
                    block.isShowingOriginal = !block.isShowingOriginal
                    invalidate()
                    return true
                }
            }

            // 3. Tapping empty space dismisses the overlay
            dismiss()
            return true
        }
        return true
    }

    private fun attachToWindow() {
        if (isAttached) return

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        try {
            windowManager.addView(this, windowParams)
            isAttached = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismiss() {
        if (isAttached) {
            try {
                windowManager.removeView(this)
            } catch (_: Exception) {}
            isAttached = false
            translatedBlocks = emptyList()
            scaledHitRects.clear()
            onDismissCallback()
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    private fun dpToPx(dp: Float): Float {
        return dp * context.resources.displayMetrics.density
    }

    fun isShowing(): Boolean = isAttached
}
