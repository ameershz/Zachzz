package com.example

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Point
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.AttributeSet
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

/**
 * Custom View matching AutoCropView architecture from Bubble Translate.
 * Performs in-place text translation directly over detected screen bounding boxes.
 */
class ScannerOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    data class TranslationItem(
        val originalBoundingBox: Rect,
        val originalText: String,
        var translatedText: String = "",
        val clampedRectF: RectF = RectF()
    )

    var onDismissListener: (() -> Unit)? = null

    // 1. Paints matching the original architecture:
    // strokePaint: orange #FFA800, STROKE, width 1.5dp, CornerPathEffect, StrokeCap.ROUND
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFA800")
        style = Paint.Style.STROKE
        strokeWidth = dpToPx(1.5f)
        strokeCap = Paint.Cap.ROUND
        pathEffect = CornerPathEffect(dpToPx(6f))
    }

    // bgPaint: semi-transparent black screen dimming (Alpha 51 / #33000000)
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#33000000") // 20% alpha
        style = Paint.Style.FILL
    }

    // clearPaint: hole punch over detected text using PorterDuff.Mode.CLEAR
    private val clearPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    }

    // Paint for solid translation card background (covering original foreign text)
    private val textCardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E60F172A") // 90% solid dark slate
        style = Paint.Style.FILL
        pathEffect = CornerPathEffect(dpToPx(6f))
    }

    // TextPaint for translated text
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = spToPx(13f)
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }

    // Close tip paint
    private val tipPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFA800")
        textSize = spToPx(12f)
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }

    private val tipBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC1E293B")
        style = Paint.Style.FILL
        pathEffect = CornerPathEffect(dpToPx(12f))
    }

    private val items = mutableListOf<TranslationItem>()
    private var screenDimensions = Point()

    // 2. Scanning animation: ValueAnimator 0f -> 1f, 300ms, AccelerateDecelerateInterpolator
    private var animProgress = 0f
    private val scanAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 300L
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener { animator ->
            animProgress = animator.animatedValue as Float
            invalidate()
        }
    }

    init {
        // Enable hardware layer for PorterDuff.Mode.CLEAR support
        setLayerType(LAYER_TYPE_HARDWARE, null)
    }

    /**
     * Requirement 4: Point Fix. Clamps bounding boxes to physical screen bounds
     * and performs strict manual comparison: `if (x < y)`.
     */
    fun updateData(newItems: List<TranslationItem>, realScreenPoint: Point) {
        screenDimensions.set(realScreenPoint.x, realScreenPoint.y)

        // Manual orientation comparison
        val isPortrait = screenDimensions.x < screenDimensions.y
        val screenW = screenDimensions.x.toFloat()
        val screenH = screenDimensions.y.toFloat()

        items.clear()
        for (item in newItems) {
            val box = item.originalBoundingBox
            val left = box.left.toFloat().coerceIn(0f, screenW)
            val top = box.top.toFloat().coerceIn(0f, screenH)
            val right = box.right.toFloat().coerceIn(0f, screenW)
            val bottom = box.bottom.toFloat().coerceIn(0f, screenH)

            if (right > left && bottom > top) {
                // Add comfortable reading padding around bounding box
                val padX = dpToPx(4f)
                val padY = dpToPx(4f)
                item.clampedRectF.set(
                    (left - padX).coerceAtLeast(0f),
                    (top - padY).coerceAtLeast(0f),
                    (right + padX).coerceAtMost(screenW),
                    (bottom + padY).coerceAtMost(screenH)
                )
                items.add(item)
            }
        }

        // Start 300ms expand/scan animation
        scanAnimator.cancel()
        animProgress = 0f
        scanAnimator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // Save layer for clearPaint PorterDuff mode
        val layerId = canvas.saveLayer(0f, 0f, w, h, null)

        // Draw semi-transparent dimming background (#33000000)
        canvas.drawRect(0f, 0f, w, h, bgPaint)

        // Requirement 2 & 3: For each detected item, animate expanding RectF and draw in-place translation
        for (item in items) {
            val fullRect = item.clampedRectF
            val cx = fullRect.centerX()
            val cy = fullRect.centerY()

            // Animate expansion from center using animProgress (0f -> 1f)
            val currentLeft = cx + (fullRect.left - cx) * animProgress
            val currentTop = cy + (fullRect.top - cy) * animProgress
            val currentRight = cx + (fullRect.right - cx) * animProgress
            val currentBottom = cy + (fullRect.bottom - cy) * animProgress
            val animatedRect = RectF(currentLeft, currentTop, currentRight, currentBottom)

            // 1. Hole punch over original text area using clearPaint
            canvas.drawRect(animatedRect, clearPaint)

            // 2. Draw solid background card for translated text to cleanly replace original text
            canvas.drawRect(animatedRect, textCardBgPaint)

            // 3. Draw orange stroke boundary (#FFA800, width 1.5, CornerPathEffect)
            canvas.drawRect(animatedRect, strokePaint)

            // 4. Draw in-place translated text inside the bounding box
            val displayTxt = if (item.translatedText.isNotBlank()) item.translatedText else item.originalText
            if (animProgress >= 0.5f && displayTxt.isNotBlank() && animatedRect.width() > dpToPx(20f)) {
                drawWrappedText(canvas, displayTxt, animatedRect)
            }
        }

        canvas.restoreToCount(layerId)

        // Top dismiss hint badge
        drawDismissTip(canvas, w)
    }

    private fun drawWrappedText(canvas: Canvas, text: String, rect: RectF) {
        val availableWidth = (rect.width() - dpToPx(8f)).toInt().coerceAtLeast(10)
        val availableHeight = (rect.height() - dpToPx(6f)).coerceAtLeast(10f)

        // Dynamically scale text size to fit box nicely
        val targetSize = when {
            rect.height() < dpToPx(24f) -> spToPx(10f)
            rect.height() < dpToPx(38f) -> spToPx(12f)
            else -> spToPx(13.5f)
        }
        textPaint.textSize = targetSize

        val staticLayout = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, textPaint, availableWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.05f)
                .setIncludePad(false)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, textPaint, availableWidth, Layout.Alignment.ALIGN_NORMAL, 1.05f, 0f, false)
        }

        canvas.save()
        val textY = rect.top + dpToPx(3f)
        val textX = rect.left + dpToPx(4f)
        canvas.translate(textX, textY)
        staticLayout.draw(canvas)
        canvas.restore()
    }

    private fun drawDismissTip(canvas: Canvas, screenWidth: Float) {
        val tipText = "انقر في أي مكان للإغلاق • Tap anywhere to dismiss"
        val tipWidth = tipPaint.measureText(tipText) + dpToPx(32f)
        val tipHeight = dpToPx(32f)
        val tipLeft = (screenWidth - tipWidth) / 2f
        val tipTop = dpToPx(36f)
        val tipRect = RectF(tipLeft, tipTop, tipLeft + tipWidth, tipTop + tipHeight)

        canvas.drawRect(tipRect, tipBgPaint)
        canvas.drawRect(tipRect, strokePaint)
        canvas.drawText(
            tipText,
            screenWidth / 2f,
            tipTop + tipHeight / 2f + dpToPx(4f),
            tipPaint
        )
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            // Tapping on the overlay closes and dismisses the translation layer
            onDismissListener?.invoke()
            return true
        }
        return true
    }

    private fun dpToPx(dp: Float): Float {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)
    }

    private fun spToPx(sp: Float): Float {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)
    }
}
