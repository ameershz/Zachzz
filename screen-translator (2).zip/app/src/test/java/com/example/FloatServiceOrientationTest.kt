package com.example

import android.graphics.Point
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class FloatServiceOrientationTest {

    @Test
    fun testOrientationPointDetection() {
        // Portrait mode: width < height
        val portraitPoint = Point(1080, 2400)
        val isPortrait = portraitPoint.x < portraitPoint.y
        assertTrue("Point with x < y must be recognized as Portrait", isPortrait)

        // Landscape mode: width > height
        val landscapePoint = Point(2400, 1080)
        val isLandscapePortrait = landscapePoint.x < landscapePoint.y
        assertFalse("Point with x > y must be recognized as Landscape", isLandscapePortrait)
    }

    @Test
    fun testClampingWithinPointBoundaries() {
        val screenPoint = Point(1080, 2400)
        val bubbleSize = 160 // in px

        val maxX = (screenPoint.x - bubbleSize).coerceAtLeast(0)
        val maxY = (screenPoint.y - bubbleSize).coerceAtLeast(0)

        assertEquals(920, maxX)
        assertEquals(2240, maxY)

        // Test coordinates out of bounds clamped to boundaries
        val testXNegative = -50
        val testXTooLarge = 1500
        val clampedX1 = testXNegative.coerceIn(0, maxX)
        val clampedX2 = testXTooLarge.coerceIn(0, maxX)

        assertEquals(0, clampedX1)
        assertEquals(maxX, clampedX2)
    }
}
