package com.example.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.DisplayMetrics
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.Toast

@SuppressLint("ViewConstructor")
class InPlaceOverlayCanvasView(
    context: Context,
    private val windowManager: WindowManager,
    private val onDismissCallback: () -> Unit
) : View(context) {

    enum class OverlayState {
        IDLE,
        SCANNING,
        DETECTED,
        TRANSLATED
    }

    private var currentState: OverlayState = OverlayState.IDLE
    private var isAttached = false

    private var detectedBoxes: List<Rect> = emptyList()
    private var translatedBlocks: List<InPlaceTranslatedBlock> = emptyList()

    private var bitmapWidth: Int = 1080
    private var bitmapHeight: Int = 1920

    private var onOpenDetailCardAction: ((String, String) -> Unit)? = null

    // Cache of scaled rects for touch & click interaction
    private val scaledHitRects = mutableListOf<Pair<RectF, InPlaceTranslatedBlock>>()

    // Scanning Animation
    private var scanProgress: Float = 0f
    private var scanAnimator: ValueAnimator? = null

    // Paints
    private val scanLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        strokeWidth = dpToPx(2.5f)
        style = Paint.Style.STROKE
    }

    private val scanGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    // State 2: Green detection borders
    private val greenBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpToPx(1.5f)
        color = Color.parseColor("#00E676")
    }

    private val greenFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#1800E676")
    }

    // State 3: Solid dark background mask
    private val bgMaskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#E6202124")
    }

    // Arabic text paint
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
    }

    // Top Action Bar Rects
    private val topBarRect = RectF()
    private val copyBtnRect = RectF()
    private val cardBtnRect = RectF()
    private val closeBtnRect = RectF()

    private val topBarBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F2202124")
        style = Paint.Style.FILL
    }

    private val btnBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    // Gesture detector for Swipe-to-Dismiss (Fling Up)
    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onFling(
            e1: MotionEvent?,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            if (e1 == null) return false
            val diffY = e2.y - e1.y
            // Fling UP detection (negative Y velocity or upward delta)
            if (diffY < -80 || velocityY < -600f) {
                animateDismissUp()
                return true
            }
            return false
        }
    })

    init {
        fitsSystemWindows = false
    }

    // ==========================================
    // State 1: Start Scanning Animation
    // ==========================================
    fun startScanning(bmpWidth: Int, bmpHeight: Int) {
        this.bitmapWidth = bmpWidth.coerceAtLeast(1)
        this.bitmapHeight = bmpHeight.coerceAtLeast(1)
        this.currentState = OverlayState.SCANNING
        this.detectedBoxes = emptyList()
        this.translatedBlocks = emptyList()
        this.translationY = 0f
        this.alpha = 1f

        attachToWindow()

        scanAnimator?.cancel()
        scanAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                scanProgress = animator.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    // ==========================================
    // State 2: Show Detected Text Bounding Boxes (Green Outlines)
    // ==========================================
    fun showDetected(boxes: List<Rect>, bmpWidth: Int, bmpHeight: Int) {
        scanAnimator?.cancel()
        this.bitmapWidth = bmpWidth.coerceAtLeast(1)
        this.bitmapHeight = bmpHeight.coerceAtLeast(1)
        this.detectedBoxes = boxes
        this.currentState = OverlayState.DETECTED

        attachToWindow()
        invalidate()
    }

    // ==========================================
    // State 3: Show Final In-Place Translations (Solid Masks + Arabic)
    // ==========================================
    fun showTranslated(
        blocks: List<InPlaceTranslatedBlock>,
        bmpWidth: Int,
        bmpHeight: Int,
        onOpenDetailCard: (String, String) -> Unit
    ) {
        scanAnimator?.cancel()
        this.bitmapWidth = bmpWidth.coerceAtLeast(1)
        this.bitmapHeight = bmpHeight.coerceAtLeast(1)
        this.translatedBlocks = blocks
        this.onOpenDetailCardAction = onOpenDetailCard
        this.currentState = OverlayState.TRANSLATED

        attachToWindow()
        invalidate()
    }

    private fun getRealScreenDimensions(): Pair<Int, Int> {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = windowManager.currentWindowMetrics.bounds
                Pair(bounds.width(), bounds.height())
            } else {
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getRealMetrics(metrics)
                Pair(metrics.widthPixels, metrics.heightPixels)
            }
        } catch (_: Exception) {
            val metrics = context.resources.displayMetrics
            Pair(metrics.widthPixels, metrics.heightPixels)
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val (realDisplayW, realDisplayH) = getRealScreenDimensions()
        val displayW = if (width > 0) width.toFloat() else realDisplayW.toFloat()
        val displayH = if (height > 0) height.toFloat() else realDisplayH.toFloat()

        // 1:1 Scale Ratios strictly matching physical coordinates without offsets
        val scaleX = displayW / bitmapWidth.toFloat()
        val scaleY = displayH / bitmapHeight.toFloat()

        when (currentState) {
            OverlayState.SCANNING -> {
                drawScanningEffect(canvas, displayW, displayH)
            }
            OverlayState.DETECTED -> {
                drawDetectedState(canvas, scaleX, scaleY, displayW, displayH)
            }
            OverlayState.TRANSLATED -> {
                drawTranslatedState(canvas, scaleX, scaleY, displayW, displayH)
            }
            OverlayState.IDLE -> {}
        }
    }

    // ----------------------------------------------------
    // State 1 Drawing: Laser Scanning Line
    // ----------------------------------------------------
    private fun drawScanningEffect(canvas: Canvas, displayW: Float, displayH: Float) {
        val lineY = scanProgress * displayH
        val glowHeight = dpToPx(36f)

        // Gradient glow above the laser line
        val gradient = LinearGradient(
            0f, lineY - glowHeight,
            0f, lineY,
            Color.TRANSPARENT,
            Color.parseColor("#4400E5FF"),
            Shader.TileMode.CLAMP
        )
        scanGlowPaint.shader = gradient
        canvas.drawRect(0f, (lineY - glowHeight).coerceAtLeast(0f), displayW, lineY, scanGlowPaint)

        // Laser scan line
        canvas.drawLine(0f, lineY, displayW, lineY, scanLinePaint)

        // Scanning Status Pill
        drawCenterPill(canvas, displayW, "🔍 جارِ مسح وترجمة الشاشة...")
    }

    // ----------------------------------------------------
    // State 2 Drawing: Thin Green Borders (Detected)
    // ----------------------------------------------------
    private fun drawDetectedState(canvas: Canvas, scaleX: Float, scaleY: Float, displayW: Float, displayH: Float) {
        val cornerRadius = dpToPx(3f)

        for (rawBox in detectedBoxes) {
            val left = (rawBox.left * scaleX).coerceIn(0f, displayW)
            val top = (rawBox.top * scaleY).coerceIn(0f, displayH)
            val right = (rawBox.right * scaleX).coerceIn(0f, displayW)
            val bottom = (rawBox.bottom * scaleY).coerceIn(0f, displayH)

            val rectF = RectF(left, top, right, bottom)
            canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, greenFillPaint)
            canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, greenBorderPaint)
        }

        drawCenterPill(canvas, displayW, "✨ تم تحديد ${detectedBoxes.size} نصوص • جارِ الترجمة...")
    }

    // ----------------------------------------------------
    // State 3 Drawing: Solid Mask + Arabic Text (Pixel-Perfect)
    // ----------------------------------------------------
    private fun drawTranslatedState(canvas: Canvas, scaleX: Float, scaleY: Float, displayW: Float, displayH: Float) {
        if (translatedBlocks.isEmpty()) return

        scaledHitRects.clear()
        val cornerRadius = dpToPx(3f)

        for (block in translatedBlocks) {
            val rawBox = block.boundingBox

            // Exact 1:1 coordinate matching: top-left corner matches the bitmap text directly
            val scaledLeft = rawBox.left * scaleX
            val scaledTop = rawBox.top * scaleY
            val scaledRight = rawBox.right * scaleX
            val scaledBottom = rawBox.bottom * scaleY

            val boxWidth = (scaledRight - scaledLeft).coerceAtLeast(dpToPx(16f))
            val boxHeight = (scaledBottom - scaledTop).coerceAtLeast(dpToPx(14f))

            val clampedLeft = scaledLeft.coerceIn(0f, displayW - boxWidth)
            val clampedTop = scaledTop.coerceIn(0f, displayH - boxHeight)
            val rectF = RectF(clampedLeft, clampedTop, clampedLeft + boxWidth, clampedTop + boxHeight)

            scaledHitRects.add(Pair(rectF, block))

            // 1. Solid Dark Background Masking Rectangle (Covers English Text)
            bgMaskPaint.color = if (block.isShowingOriginal) Color.parseColor("#E62E3035") else Color.parseColor("#E6202124")
            canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, bgMaskPaint)

            // 2. Centered Arabic / English Text
            val displayText = if (block.isShowingOriginal) block.originalText else block.translatedText
            val horizontalPadding = dpToPx(3f)
            val availableTextWidth = (rectF.width() - (horizontalPadding * 2)).toInt().coerceAtLeast(10)

            val optimalFontSize = calculateOptimalFontSize(
                text = displayText,
                availableWidth = availableTextWidth,
                availableHeight = (rectF.height() - dpToPx(2f)).toInt()
            )

            textPaint.textSize = optimalFontSize
            textPaint.color = if (block.isShowingOriginal) Color.parseColor("#FFD54F") else Color.WHITE

            val staticLayout = createStaticLayout(displayText, textPaint, availableTextWidth)

            val layoutHeight = staticLayout.height
            val verticalOffset = rectF.top + ((rectF.height() - layoutHeight) / 2f).coerceAtLeast(0f)
            val horizontalOffset = rectF.left + horizontalPadding

            canvas.save()
            canvas.translate(horizontalOffset, verticalOffset)
            staticLayout.draw(canvas)
            canvas.restore()
        }

        // Draw Minimal Top Action Bar with Swipe-Up Gesture Hint
        drawTopControlBar(canvas, displayW)
    }

    private fun drawCenterPill(canvas: Canvas, displayW: Float, message: String) {
        val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E6121722")
            style = Paint.Style.FILL
        }
        val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#3300E5FF")
            style = Paint.Style.STROKE
            strokeWidth = dpToPx(1f)
        }
        textPaint.textSize = dpToPx(12f)
        textPaint.color = Color.parseColor("#00E5FF")

        val textWidth = textPaint.measureText(message)
        val pillW = textWidth + dpToPx(32f)
        val pillH = dpToPx(36f)
        val pillLeft = (displayW - pillW) / 2f
        val pillTop = dpToPx(48f)
        val pillRect = RectF(pillLeft, pillTop, pillLeft + pillW, pillTop + pillH)

        canvas.drawRoundRect(pillRect, dpToPx(18f), dpToPx(18f), pillPaint)
        canvas.drawRoundRect(pillRect, dpToPx(18f), dpToPx(18f), pillStroke)
        canvas.drawText(message, pillLeft + dpToPx(16f), pillTop + dpToPx(22.5f), textPaint)
    }

    private fun drawTopControlBar(canvas: Canvas, displayW: Float) {
        val barW = dpToPx(250f)
        val barH = dpToPx(36f)
        val barLeft = (displayW - barW) / 2f
        val barTop = dpToPx(44f)
        topBarRect.set(barLeft, barTop, barLeft + barW, barTop + barH)

        canvas.drawRoundRect(topBarRect, dpToPx(18f), dpToPx(18f), topBarBgPaint)

        // Count Text + Swipe Hint
        textPaint.textSize = dpToPx(11f)
        textPaint.color = Color.parseColor("#00E5FF")
        val countStr = "⚡ ${translatedBlocks.size} • ⬆ اسحب للإغلاق"
        canvas.drawText(countStr, barLeft + dpToPx(12f), barTop + dpToPx(22.5f), textPaint)

        val btnH = dpToPx(24f)
        val btnY = barTop + (barH - btnH) / 2f

        // Copy Button
        val copyW = dpToPx(46f)
        val copyX = barLeft + barW - dpToPx(96f)
        copyBtnRect.set(copyX, btnY, copyX + copyW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#3300E676")
        canvas.drawRoundRect(copyBtnRect, dpToPx(12f), dpToPx(12f), btnBgPaint)
        textPaint.textSize = dpToPx(10f)
        textPaint.color = Color.parseColor("#00E676")
        canvas.drawText("نسخ", copyX + dpToPx(13f), btnY + dpToPx(16f), textPaint)

        // Card Button
        val cardW = dpToPx(44f)
        val cardX = copyX + copyW + dpToPx(4f)
        cardBtnRect.set(cardX, btnY, cardX + cardW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#33B388FF")
        canvas.drawRoundRect(cardBtnRect, dpToPx(12f), dpToPx(12f), btnBgPaint)
        textPaint.color = Color.parseColor("#B388FF")
        canvas.drawText("بطاقة", cardX + dpToPx(9f), btnY + dpToPx(16f), textPaint)
    }

    private fun calculateOptimalFontSize(text: CharSequence, availableWidth: Int, availableHeight: Int): Float {
        var sizeSp = when {
            availableHeight >= dpToPx(48f) -> 14f
            availableHeight >= dpToPx(32f) -> 12f
            availableHeight >= dpToPx(22f) -> 10.5f
            availableHeight >= dpToPx(16f) -> 9.5f
            else -> 8.5f
        }

        var pxSize = dpToPx(sizeSp)
        textPaint.textSize = pxSize

        for (i in 0 until 4) {
            val layout = createStaticLayout(text, textPaint, availableWidth)
            if (layout.height <= availableHeight || sizeSp <= 7.5f) {
                break
            }
            sizeSp -= 1f
            pxSize = dpToPx(sizeSp)
            textPaint.textSize = pxSize
        }

        return pxSize
    }

    private fun createStaticLayout(text: CharSequence, paint: TextPaint, width: Int): StaticLayout {
        val safeWidth = width.coerceAtLeast(10)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, safeWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, 1.0f)
                .setIncludePad(false)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(
                text,
                paint,
                safeWidth,
                Layout.Alignment.ALIGN_CENTER,
                1.0f,
                0f,
                false
            )
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        // First check swipe gestures
        if (gestureDetector.onTouchEvent(event)) {
            return true
        }

        if (event.action == MotionEvent.ACTION_UP) {
            val x = event.x
            val y = event.y

            // Top Bar Actions
            if (copyBtnRect.contains(x, y)) {
                val fullAr = translatedBlocks.joinToString("\n\n") { it.translatedText }
                copyToClipboard("Translations", fullAr)
                Toast.makeText(context, "تم نسخ جميع الترجمات (${translatedBlocks.size})", Toast.LENGTH_SHORT).show()
                return true
            }

            if (cardBtnRect.contains(x, y)) {
                val fullEn = translatedBlocks.joinToString("\n\n") { it.originalText }
                val fullAr = translatedBlocks.joinToString("\n\n") { it.translatedText }
                dismiss()
                onOpenDetailCardAction?.invoke(fullEn, fullAr)
                return true
            }

            if (topBarRect.contains(x, y)) {
                return true
            }

            // Click on individual translated block
            for ((rectF, block) in scaledHitRects) {
                if (rectF.contains(x, y)) {
                    block.isShowingOriginal = !block.isShowingOriginal
                    invalidate()
                    return true
                }
            }

            // Single tap on empty space
            animateDismissUp()
            return true
        }
        return true
    }

    // Smooth Swipe-Up Dismiss Animation
    fun animateDismissUp() {
        if (!isAttached) return
        animate()
            .translationY(-height.toFloat().coerceAtLeast(dpToPx(600f)))
            .alpha(0f)
            .setDuration(260)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                dismiss()
            }
            .start()
    }

    private fun attachToWindow() {
        if (isAttached) return

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            windowManager.addView(this, windowParams)
            isAttached = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismiss() {
        scanAnimator?.cancel()
        scanAnimator = null
        if (isAttached) {
            try {
                windowManager.removeView(this)
            } catch (_: Exception) {}
            isAttached = false
            currentState = OverlayState.IDLE
            detectedBoxes = emptyList()
            translatedBlocks = emptyList()
            scaledHitRects.clear()
            translationY = 0f
            alpha = 1f
            onDismissCallback()
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    private fun dpToPx(dp: Float): Float {
        return dp * context.resources.displayMetrics.density
    }

    fun isShowing(): Boolean = isAttached && currentState != OverlayState.IDLE
}
