package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.OmniTransApplication
import com.example.overlay.FloatingBubbleView
import com.example.overlay.InPlaceOverlayCanvasView
import com.example.overlay.InPlaceTranslatedBlock
import com.example.overlay.OverlayResultsWindow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FloatingOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager

    private var floatingBubbleView: FloatingBubbleView? = null
    private var overlayResultsWindow: OverlayResultsWindow? = null
    private var inPlaceOverlayCanvasView: InPlaceOverlayCanvasView? = null

    private val app by lazy { application as OmniTransApplication }

    companion object {
        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "omnitrans_overlay_channel"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning = _isServiceRunning.asStateFlow()
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                // 1. Android 14+ requirement: startForeground must precede getMediaProjection
                startForegroundServiceWithNotification()

                // 2. Safe extraction of projection result
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData: Intent? = try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(EXTRA_RESULT_DATA)
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    null
                }

                if (resultCode != 0 && resultData != null) {
                    val initialized = app.screenCaptureManager.initProjection(resultCode, resultData)
                    if (!initialized) {
                        Toast.makeText(this, "Screen capture could not be initialized.", Toast.LENGTH_LONG).show()
                    }
                }

                // 3. Setup Floating Bubble & Canvas Overlay System
                setupOverlaySystem()
                _isServiceRunning.value = true
            }
        }
        return START_STICKY
    }

    private fun startForegroundServiceWithNotification() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OmniTrans In-Place Screen Translator")
            .setContentText("Tap bubble to translate game & app text in-place")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "OmniTrans Screen Translator",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows persistent status while translator bubble is active"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun setupOverlaySystem() {
        if (floatingBubbleView != null) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant Overlay permission in settings.", Toast.LENGTH_LONG).show()
            return
        }

        val bubbleSize = (64 * resources.displayMetrics.density).toInt().coerceAtLeast(140)
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 350
        }

        val bubble = FloatingBubbleView(
            context = this,
            windowManager = windowManager,
            layoutParams = params,
            onBubbleClick = { handleScreenTranslateTrigger() },
            onBubbleLongClick = { openAppMainActivity() }
        )
        floatingBubbleView = bubble

        // Results Card Window (Detail mode)
        overlayResultsWindow = OverlayResultsWindow(
            context = this,
            windowManager = windowManager,
            onDismiss = {},
            onSaveHistory = { en, ar ->
                serviceScope.launch {
                    app.translationRepository.saveTranslation(en, ar, "Screen Overlay")
                }
            }
        )

        // Single Full-Screen In-Place Canvas Overlay View
        inPlaceOverlayCanvasView = InPlaceOverlayCanvasView(
            context = this,
            windowManager = windowManager,
            onDismissCallback = {}
        )

        try {
            windowManager.addView(bubble, params)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Failed to create overlay: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleScreenTranslateTrigger() {
        val bubble = floatingBubbleView ?: return

        // If in-place canvas overlay is currently active, clicking bubble dismisses it with animation
        if (inPlaceOverlayCanvasView?.isShowing() == true) {
            inPlaceOverlayCanvasView?.animateDismissUp()
            return
        }

        serviceScope.launch {
            try {
                // Change bubble state
                bubble.currentState = FloatingBubbleView.State.CAPTURING

                val metrics = resources.displayMetrics
                val defaultW = metrics.widthPixels
                val defaultH = metrics.heightPixels

                // ==========================================
                // STEP 1 (Scanning): Start horizontal laser animation
                // ==========================================
                withContext(Dispatchers.Main) {
                    inPlaceOverlayCanvasView?.startScanning(defaultW, defaultH)
                }

                delay(120)

                // Capture Screen Frame
                val bitmap = app.screenCaptureManager.captureScreen()
                if (bitmap == null) {
                    bubble.currentState = FloatingBubbleView.State.ERROR
                    withContext(Dispatchers.Main) {
                        inPlaceOverlayCanvasView?.dismiss()
                        Toast.makeText(
                            this@FloatingOverlayService,
                            "Screen capture unavailable. Please re-grant screen permission in OmniTrans.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    delay(1200)
                    bubble.currentState = FloatingBubbleView.State.IDLE
                    return@launch
                }

                val bmpW = bitmap.width
                val bmpH = bitmap.height

                bubble.currentState = FloatingBubbleView.State.TRANSLATING

                // OCR Extraction with Bounding Boxes
                val ocrResult = app.ocrEngine.recognizeText(bitmap)
                try {
                    bitmap.recycle() // Free bitmap memory immediately
                } catch (_: Exception) {}

                if (!ocrResult.isSuccessful || ocrResult.blocks.isEmpty()) {
                    bubble.currentState = FloatingBubbleView.State.ERROR
                    withContext(Dispatchers.Main) {
                        inPlaceOverlayCanvasView?.dismiss()
                        Toast.makeText(
                            this@FloatingOverlayService,
                            "No English text detected on screen.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    delay(1000)
                    bubble.currentState = FloatingBubbleView.State.IDLE
                    return@launch
                }

                // ==========================================
                // STEP 2 (Detection): Draw thin green borders around detected text
                // ==========================================
                val detectedBoxes: List<Rect> = ocrResult.blocks.mapNotNull { it.boundingBox }
                withContext(Dispatchers.Main) {
                    inPlaceOverlayCanvasView?.showDetected(detectedBoxes, bmpW, bmpH)
                }

                // Allow brief moment for the user to see the detected bounding boxes
                delay(180)

                // Translate each TextBlock in parallel
                val translationDeferreds = ocrResult.blocks.mapIndexed { index, block ->
                    async(Dispatchers.Default) {
                        val translated = app.translationEngine.translate(block.text)
                        val box = block.boundingBox ?: Rect(20, 100 + (index * 80), 300, 160 + (index * 80))
                        InPlaceTranslatedBlock(
                            id = index,
                            originalText = block.text,
                            translatedText = translated.ifBlank { block.text },
                            boundingBox = box
                        )
                    }
                }

                val translatedBlocks = translationDeferreds.awaitAll()

                // Save full text summary to Room history database
                val fullDetected = translatedBlocks.joinToString("\n\n") { it.originalText }
                val fullTranslated = translatedBlocks.joinToString("\n\n") { it.translatedText }
                app.translationRepository.saveTranslation(fullDetected, fullTranslated, "In-Place Overlay")

                // ==========================================
                // STEP 3 (Translation): Solid Dark Mask + Centered Arabic Text
                // ==========================================
                withContext(Dispatchers.Main) {
                    inPlaceOverlayCanvasView?.showTranslated(
                        blocks = translatedBlocks,
                        bmpWidth = bmpW,
                        bmpHeight = bmpH,
                        onOpenDetailCard = { en, ar ->
                            overlayResultsWindow?.show(en, ar)
                        }
                    )
                }

                bubble.currentState = FloatingBubbleView.State.IDLE

            } catch (e: Exception) {
                e.printStackTrace()
                bubble.currentState = FloatingBubbleView.State.ERROR
                withContext(Dispatchers.Main) {
                    inPlaceOverlayCanvasView?.dismiss()
                    Toast.makeText(this@FloatingOverlayService, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
                delay(1200)
                bubble.currentState = FloatingBubbleView.State.IDLE
            }
        }
    }

    private fun openAppMainActivity() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceRunning.value = false

        floatingBubbleView?.let {
            it.destroy()
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
            floatingBubbleView = null
        }

        inPlaceOverlayCanvasView?.dismiss()
        inPlaceOverlayCanvasView = null

        overlayResultsWindow?.dismiss()
        overlayResultsWindow = null

        app.screenCaptureManager.stopProjection()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
