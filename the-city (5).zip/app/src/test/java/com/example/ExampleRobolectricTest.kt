package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.game.economy.EconomyManager
import com.example.game.fishing.CaughtFish
import com.example.game.fishing.FishRarity
import com.example.game.fishing.FishSpecies
import com.example.game.fishing.FishingRod
import com.example.game.fishing.FishingState
import com.example.game.fishing.FishingSystem
import com.example.game.input.ActionButton
import com.example.game.input.VirtualJoystick
import com.example.game.inventory.FishInventory
import com.example.game.physics.CollisionSystem
import com.example.game.physics.RectCollider
import com.example.game.player.PlayerDirection
import com.example.game.save.GameSaveManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("The City", appName)
    }

    @Test
    fun `economy manager handles earning and spending transactions`() {
        val economy = EconomyManager(50)
        assertEquals(50, economy.money)
        assertEquals("$50", economy.formattedBalance())

        economy.earn(100)
        assertEquals(150, economy.money)

        assertTrue(economy.canAfford(120))
        assertTrue(economy.spend(120))
        assertEquals(30, economy.money)

        assertFalse(economy.canAfford(50))
        assertFalse(economy.spend(50))
        assertEquals(30, economy.money)
    }

    @Test
    fun `fish inventory respects capacity and calculates sale values`() {
        val inventory = FishInventory(capacity = 3)
        assertEquals(0, inventory.count)
        assertFalse(inventory.isFull)

        val sardine = CaughtFish.generate(FishSpecies.CORAL_SARDINE)
        val snapper = CaughtFish.generate(FishSpecies.AZURE_REEF_SNAPPER)
        val moonfin = CaughtFish.generate(FishSpecies.LUMINOUS_MOONFIN)

        assertTrue(inventory.addFish(sardine))
        assertTrue(inventory.addFish(snapper))
        assertTrue(inventory.addFish(moonfin))
        assertEquals(3, inventory.count)
        assertTrue(inventory.isFull)

        // Cannot exceed capacity
        val extra = CaughtFish.generate(FishSpecies.STRIPED_SUNFISH)
        assertFalse(inventory.addFish(extra))

        // Total value is sum of caught fish
        val expectedTotal = sardine.value + snapper.value + moonfin.value
        assertEquals(expectedTotal, inventory.totalValue)

        // Selling clears inventory and returns earnings
        val (soldCount, earned) = inventory.clearAndSellAll()
        assertEquals(3, soldCount)
        assertEquals(expectedTotal, earned)
        assertEquals(0, inventory.count)
    }

    @Test
    fun `fishing rods catalog provides proper upgrade progression`() {
        val wooden = FishingRod.WOODEN_ROD
        val reinforced = FishingRod.REINFORCED_ROD
        val master = FishingRod.MASTER_ROD

        assertEquals(0, wooden.price)
        assertEquals(120, reinforced.price)
        assertEquals(350, master.price)

        assertTrue(reinforced.catchZoneBonus > wooden.catchZoneBonus)
        assertTrue(master.catchZoneBonus > reinforced.catchZoneBonus)
        assertTrue(master.rarityBonus > reinforced.rarityBonus)
    }

    @Test
    fun `game save manager persists and restores state across restarts`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val saveManager = GameSaveManager(context)

        val sampleFish = listOf(
            CaughtFish.generate(FishSpecies.CORAL_SARDINE),
            CaughtFish.generate(FishSpecies.GOLDEN_TIDE_MACKEREL)
        )

        saveManager.saveGame(
            money = 275,
            equippedRod = FishingRod.REINFORCED_ROD,
            purchasedRods = setOf(FishingRod.WOODEN_ROD.id, FishingRod.REINFORCED_ROD.id),
            fishList = sampleFish,
            totalCaughtStat = 12
        )

        // Reload
        val loadedMoney = saveManager.loadMoney()
        val loadedRodId = saveManager.loadEquippedRodId()
        val loadedPurchased = saveManager.loadPurchasedRods()
        val loadedFish = saveManager.loadFishInventory()
        val loadedStat = saveManager.loadTotalCaughtStat()

        assertEquals(275, loadedMoney)
        assertEquals(FishingRod.REINFORCED_ROD.id, loadedRodId)
        assertTrue(loadedPurchased.contains(FishingRod.REINFORCED_ROD.id))
        assertEquals(2, loadedFish.size)
        assertEquals(12, loadedStat)
    }

    @Test
    fun `fishing cycle cleanup and transition to FREE_ROAM resets all variables`() {
        val inventory = FishInventory(10)
        val fishing = FishingSystem(inventory)

        assertEquals(FishingState.FREE_ROAM, fishing.state)

        // Start casting
        fishing.startCasting(100f, 200f, PlayerDirection.NORTH, 100f, 50f)
        assertEquals(FishingState.CASTING, fishing.state)
        assertEquals(100f, fishing.bobberX, 0.01f)
        assertEquals(50f, fishing.bobberY, 0.01f)

        // Reset fishing should cleanly restore FREE_ROAM and clear bobber/rod variables
        fishing.resetFishing()
        assertEquals(FishingState.FREE_ROAM, fishing.state)
        assertEquals(0f, fishing.bobberX, 0.01f)
        assertEquals(0f, fishing.bobberY, 0.01f)
        assertEquals(0f, fishing.rodTipX, 0.01f)
        assertEquals(0f, fishing.rodTipY, 0.01f)
    }

    @Test
    fun `virtual joystick and action button maintain consistent visual sizes in portrait and landscape`() {
        val joystick = VirtualJoystick()
        val actionButton = ActionButton()

        // Portrait 1080 x 2400
        joystick.setDefaultPosition(1080f, 2400f)
        actionButton.setDefaultPosition(1080f, 2400f)

        val portraitBaseRadius = joystick.baseRadius
        val portraitStickRadius = joystick.stickRadius
        val portraitActionRadius = actionButton.radius

        // Landscape 2400 x 1080
        joystick.setDefaultPosition(2400f, 1080f)
        actionButton.setDefaultPosition(2400f, 1080f)

        val landscapeBaseRadius = joystick.baseRadius
        val landscapeStickRadius = joystick.stickRadius
        val landscapeActionRadius = actionButton.radius

        // Radii must remain exactly the same between portrait and landscape
        assertEquals(portraitBaseRadius, landscapeBaseRadius, 0.01f)
        assertEquals(portraitStickRadius, landscapeStickRadius, 0.01f)
        assertEquals(portraitActionRadius, landscapeActionRadius, 0.01f)
    }

    @Test
    fun `collision system resolves movement without sticking to obstacles`() {
        val collisionSystem = CollisionSystem()
        collisionSystem.worldBounds = RectCollider(0f, 0f, 1000f, 1000f)

        collisionSystem.addCollider(RectCollider(200f, 200f, 400f, 400f))

        val resolved = collisionSystem.resolveMovement(
            currentX = 180f,
            currentY = 250f,
            targetX = 210f,
            targetY = 260f,
            halfWidth = 10f,
            halfHeight = 10f
        )

        assertEquals(180f, resolved.x, 0.1f)
        assertEquals(260f, resolved.y, 0.1f)
    }
}
