package com.example.game.inventory

import com.example.game.fishing.CaughtFish

/**
 * Manages caught fish storage, capacity constraints, and sale calculations.
 */
class FishInventory(val capacity: Int = 10) {
    private val fishList = mutableListOf<CaughtFish>()

    var onInventoryChanged: (() -> Unit)? = null

    val count: Int get() = fishList.size
    val isFull: Boolean get() = fishList.size >= capacity
    val totalValue: Int get() = fishList.sumOf { it.value }

    fun getFishList(): List<CaughtFish> = fishList.toList()

    fun addFish(fish: CaughtFish): Boolean {
        if (isFull) return false
        fishList.add(fish)
        onInventoryChanged?.invoke()
        return true
    }

    fun removeFish(fishId: String): CaughtFish? {
        val index = fishList.indexOfFirst { it.id == fishId }
        if (index != -1) {
            val removed = fishList.removeAt(index)
            onInventoryChanged?.invoke()
            return removed
        }
        return null
    }

    fun clearAndSellAll(): Pair<Int, Int> {
        val totalWorth = totalValue
        val totalSold = fishList.size
        fishList.clear()
        onInventoryChanged?.invoke()
        return Pair(totalSold, totalWorth)
    }

    fun setLoadedFish(list: List<CaughtFish>) {
        fishList.clear()
        fishList.addAll(list.take(capacity))
        onInventoryChanged?.invoke()
    }
}
