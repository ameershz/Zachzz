package com.example.game.fishing

import java.util.UUID

/**
 * An individual fish caught by the player with specific weight and sale value.
 */
data class CaughtFish(
    val id: String = UUID.randomUUID().toString(),
    val species: FishSpecies,
    val weightKg: Float,
    val value: Int
) {
    val formattedWeight: String
        get() = String.format(java.util.Locale.US, "%.1f kg", weightKg)

    val formattedValue: String
        get() = "$$value"

    companion object {
        fun generate(species: FishSpecies): CaughtFish {
            val weightRange = species.maxWeightKg - species.minWeightKg
            val randomFactor = Math.random().toFloat()
            val weight = species.minWeightKg + weightRange * randomFactor

            // Value scales with weight variance: larger fish are worth up to +35% more
            val bonusPercent = (weight - species.minWeightKg) / weightRange.coerceAtLeast(0.1f)
            val value = (species.baseValue * (1f + bonusPercent * 0.35f)).toInt()

            return CaughtFish(
                species = species,
                weightKg = weight,
                value = value
            )
        }
    }
}
