package com.example.game.fishing

import android.graphics.Color

/**
 * Definition of a fishing rod with stats that impact bite speed, timing difficulty, and rarity.
 */
data class FishingRod(
    val id: String,
    val name: String,
    val price: Int,
    val description: String,
    val catchZoneBonus: Float,  // Expands the green catch zone in minigame
    val biteTimeMultiplier: Float, // < 1.0f means faster bites
    val rarityBonus: Float,      // Increases roll chances for Rare/Epic/Legendary fish
    val rodColor: Int,
    val lineReach: Float = 140f
) {
    companion object {
        val WOODEN_ROD = FishingRod(
            id = "rod_wooden",
            name = "Wooden Drift Rod",
            price = 0,
            description = "A humble starter rod whittled from driftwood. Good for lagoon fish.",
            catchZoneBonus = 0.0f,
            biteTimeMultiplier = 1.0f,
            rarityBonus = 1.0f,
            rodColor = Color.rgb(165, 115, 65),
            lineReach = 140f
        )

        val REINFORCED_ROD = FishingRod(
            id = "rod_reinforced",
            name = "Reinforced Carbon Rod",
            price = 120,
            description = "Woven carbon fibers provide +25% catch zone and 20% faster bites.",
            catchZoneBonus = 0.08f,
            biteTimeMultiplier = 0.8f,
            rarityBonus = 1.8f,
            rodColor = Color.rgb(45, 55, 75),
            lineReach = 165f
        )

        val MASTER_ROD = FishingRod(
            id = "rod_master",
            name = "Master Tide Rod",
            price = 350,
            description = "Enchanted pearl finish. +50% catch zone, 40% faster bites, attracts legends.",
            catchZoneBonus = 0.16f,
            biteTimeMultiplier = 0.6f,
            rarityBonus = 3.2f,
            rodColor = Color.rgb(240, 195, 45),
            lineReach = 190f
        )

        val ALL_RODS = listOf(WOODEN_ROD, REINFORCED_ROD, MASTER_ROD)

        fun getById(id: String): FishingRod {
            return ALL_RODS.find { it.id == id } ?: WOODEN_ROD
        }
    }
}
