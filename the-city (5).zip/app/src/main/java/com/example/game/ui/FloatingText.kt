package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface

/**
 * Animated rising text notification in the game world or on screen.
 */
class FloatingText(
    var x: Float,
    var y: Float,
    val text: String,
    val color: Int = Color.rgb(255, 220, 60),
    val duration: Float = 1.3f
) {
    private var timer: Float = 0f
    val isDead: Boolean get() = timer >= duration

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 24f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 24f
        typeface = Typeface.DEFAULT_BOLD
        color = Color.argb(200, 0, 0, 0)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    fun update(deltaTime: Float) {
        timer += deltaTime
        y -= deltaTime * 35f // Float upwards
    }

    fun render(canvas: Canvas) {
        val progress = (timer / duration).coerceIn(0f, 1f)
        val alpha = ((1f - progress * progress) * 255).toInt().coerceIn(0, 255)

        textPaint.color = color
        textPaint.alpha = alpha
        strokePaint.alpha = (alpha * 0.7f).toInt()

        canvas.drawText(text, x, y, strokePaint)
        canvas.drawText(text, x, y, textPaint)
    }
}
