package com.example.game.fishing

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.inventory.FishInventory
import com.example.game.player.PlayerDirection
import kotlin.math.abs
import kotlin.math.sin

enum class FishingState {
    FREE_ROAM,
    CASTING,
    WAITING_FOR_BITE,
    BITE,
    CATCHING,
    CAUGHT,
    FISH_SHOP,
    ROD_SHOP,
    FISH_INVENTORY
}

/**
 * Handles fishing state machine, rod casting, bite timers, bobber water physics,
 * and the timing-based catch minigame.
 */
class FishingSystem(
    val fishInventory: FishInventory
) {
    var state: FishingState = FishingState.FREE_ROAM
        private set

    var equippedRod: FishingRod = FishingRod.WOODEN_ROD

    // Fishing line & bobber coordinates in world space
    var rodTipX: Float = 0f
    var rodTipY: Float = 0f
    var bobberX: Float = 0f
    var bobberY: Float = 0f

    // Timers
    private var stateTimer: Float = 0f
    private var biteWaitDuration: Float = 3.5f
    private val biteReactionWindow: Float = 2.4f

    // Catch minigame variables
    var targetSpecies: FishSpecies = FishSpecies.CORAL_SARDINE
        private set
    var needlePos: Float = 0f // [0..1]
    var catchZoneStart: Float = 0.35f
    var catchZoneEnd: Float = 0.65f
    private var minigameTimer: Float = 0f
    private val minigameMaxTime: Float = 5.0f

    // Visual ripple effect for bobber
    private var waterRippleTimer: Float = 0f

    // Callbacks
    var onFishCaught: ((CaughtFish) -> Unit)? = null
    var onFishEscaped: ((String) -> Unit)? = null
    var onStateChanged: ((FishingState) -> Unit)? = null

    // Paints
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 255, 255, 255)
        strokeWidth = 2.5f
        style = Paint.Style.STROKE
    }

    private val bobberTopPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(235, 55, 45) // Bright red top
        style = Paint.Style.FILL
    }

    private val bobberBottomPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val ripplePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(140, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val biteAlertPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 220, 40)
        textAlign = Paint.Align.CENTER
        textSize = 28f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val biteStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(30, 20, 10)
        textAlign = Paint.Align.CENTER
        textSize = 28f
        typeface = Typeface.DEFAULT_BOLD
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    fun setState(newState: FishingState) {
        state = newState
        stateTimer = 0f
        if (newState == FishingState.FREE_ROAM) {
            rodTipX = 0f
            rodTipY = 0f
            bobberX = 0f
            bobberY = 0f
            minigameTimer = 0f
        }
        onStateChanged?.invoke(newState)
    }

    /**
     * Completely resets all fishing variables and safely returns to FREE_ROAM.
     */
    fun resetFishing() {
        setState(FishingState.FREE_ROAM)
    }

    fun startCasting(playerX: Float, playerY: Float, direction: PlayerDirection, dockReachX: Float, dockReachY: Float) {
        if (fishInventory.isFull) {
            onFishEscaped?.invoke("Fish Creel is full! (10/10) - Sell fish at shop.")
            return
        }

        rodTipX = playerX
        rodTipY = playerY - 32f

        // Place bobber into the water based on dock / cast direction
        bobberX = dockReachX
        bobberY = dockReachY

        // Randomize bite duration based on equipped rod stats
        val baseWait = (2.2f + Math.random().toFloat() * 2.8f)
        biteWaitDuration = baseWait * equippedRod.biteTimeMultiplier

        setState(FishingState.CASTING)
    }

    fun update(deltaTime: Float, playerX: Float, playerY: Float) {
        stateTimer += deltaTime
        waterRippleTimer += deltaTime

        // Update rod tip position near player hands
        rodTipX = playerX + 8f
        rodTipY = playerY - 34f

        when (state) {
            FishingState.CASTING -> {
                if (stateTimer >= 0.5f) {
                    setState(FishingState.WAITING_FOR_BITE)
                }
            }

            FishingState.WAITING_FOR_BITE -> {
                if (stateTimer >= biteWaitDuration) {
                    // Roll prospective fish species for difficulty calculations
                    targetSpecies = FishSpecies.rollRandomFish(equippedRod.rarityBonus)
                    setState(FishingState.BITE)
                }
            }

            FishingState.BITE -> {
                // Bobber plunges and splashes
                if (stateTimer >= biteReactionWindow) {
                    // Too slow, fish got away
                    onFishEscaped?.invoke("Too slow! The fish got away.")
                    resetFishing()
                }
            }

            FishingState.CATCHING -> {
                minigameTimer += deltaTime
                // Needle oscillates smoothly across 0..1
                val speed = 2.4f * targetSpecies.rarity.needleSpeed
                needlePos = (sin(minigameTimer * speed) + 1f) * 0.5f

                if (minigameTimer >= minigameMaxTime) {
                    onFishEscaped?.invoke("The line snapped! Fish escaped.")
                    resetFishing()
                }
            }

            else -> {}
        }
    }

    fun onActionTriggered(): Boolean {
        when (state) {
            FishingState.BITE -> {
                // Player reacted to the bite! Start catching minigame
                setupMinigame()
                setState(FishingState.CATCHING)
                return true
            }

            FishingState.CATCHING -> {
                // Player tapped REEL! Evaluate needle position
                val inZone = needlePos in catchZoneStart..catchZoneEnd
                if (inZone) {
                    val caught = CaughtFish.generate(targetSpecies)
                    val added = fishInventory.addFish(caught)
                    if (added) {
                        onFishCaught?.invoke(caught)
                    } else {
                        onFishEscaped?.invoke("Creel was full!")
                    }
                    setState(FishingState.CAUGHT)
                } else {
                    onFishEscaped?.invoke("Missed the strike! Fish escaped.")
                    resetFishing()
                }
                return true
            }

            FishingState.CAUGHT -> {
                resetFishing()
                return true
            }

            else -> return false
        }
    }

    private fun setupMinigame() {
        minigameTimer = 0f
        needlePos = 0f

        // Base zone width + rod bonus
        val baseWidth = targetSpecies.rarity.catchZoneWidth + equippedRod.catchZoneBonus
        val zoneWidth = baseWidth.coerceIn(0.14f, 0.55f)

        // Center the zone around 0.5f with slight random jitter
        val jitter = (Math.random().toFloat() - 0.5f) * 0.15f
        val center = (0.5f + jitter).coerceIn(0.35f, 0.65f)
        catchZoneStart = (center - zoneWidth * 0.5f).coerceIn(0.05f, 0.85f)
        catchZoneEnd = (catchZoneStart + zoneWidth).coerceIn(catchZoneStart + 0.1f, 0.95f)
    }

    fun cancelFishing() {
        resetFishing()
    }

    fun renderInWorld(canvas: Canvas) {
        if (state == FishingState.FREE_ROAM || state == FishingState.CAUGHT ||
            state == FishingState.FISH_SHOP || state == FishingState.ROD_SHOP ||
            state == FishingState.FISH_INVENTORY
        ) {
            return
        }

        // 1. Draw flexible curved fishing line from rod tip to bobber
        val path = Path().apply {
            moveTo(rodTipX, rodTipY)
            val midX = (rodTipX + bobberX) * 0.5f
            val sag = if (state == FishingState.BITE || state == FishingState.CATCHING) -6f else 16f
            val midY = (rodTipY + bobberY) * 0.5f + sag
            quadTo(midX, midY, bobberX, bobberY)
        }
        canvas.drawPath(path, linePaint)

        // 2. Draw soft concentric water ripples around bobber
        val rippleCount = if (state == FishingState.BITE) 3 else 2
        for (i in 0 until rippleCount) {
            val rippleSpeed = if (state == FishingState.BITE) 2.0f else 0.85f
            val progress = (waterRippleTimer * rippleSpeed + i * 0.38f) % 1f
            val maxR = if (state == FishingState.BITE) 26f else 16f
            val r = progress * maxR + 5f
            val alpha = ((1f - progress) * 170).toInt().coerceIn(0, 170)
            ripplePaint.alpha = alpha
            canvas.drawOval(RectF(bobberX - r, bobberY - r * 0.45f, bobberX + r, bobberY + r * 0.45f), ripplePaint)
        }

        // 3. Draw Stylized Bobber Float
        val bobberYOffset = if (state == FishingState.BITE) 5f + sin(waterRippleTimer * 18f) * 3.5f else sin(waterRippleTimer * 3.2f) * 2f
        val curBobberY = bobberY + bobberYOffset

        // Bobber float shadow
        val bobShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(60, 5, 25, 45)
            style = Paint.Style.FILL
        }
        canvas.drawOval(RectF(bobberX - 7f, curBobberY + 2f, bobberX + 7f, curBobberY + 8f), bobShadow)

        // Red top bulb
        canvas.drawArc(
            RectF(bobberX - 7f, curBobberY - 8f, bobberX + 7f, curBobberY + 6f),
            180f, 180f, true, bobberTopPaint
        )
        // Yellow center band
        val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(241, 196, 15)
            style = Paint.Style.FILL
        }
        canvas.drawRect(bobberX - 7f, curBobberY - 2f, bobberX + 7f, curBobberY + 2f, bandPaint)

        // White bottom bulb
        canvas.drawArc(
            RectF(bobberX - 7f, curBobberY - 3f, bobberX + 7f, curBobberY + 8f),
            0f, 180f, true, bobberBottomPaint
        )

        // Antenna stem on top
        val stemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(40, 40, 40)
            strokeWidth = 2f
        }
        canvas.drawLine(bobberX, curBobberY - 8f, bobberX, curBobberY - 16f, stemPaint)
        canvas.drawCircle(bobberX, curBobberY - 16f, 2.5f, bobberTopPaint)

        // 4. Bite visual indicator above bobber
        if (state == FishingState.BITE) {
            val alertY = bobberY - 36f + sin(waterRippleTimer * 16f) * 4f
            canvas.drawText("⚡ BITE! ⚡", bobberX, alertY, biteStrokePaint)
            canvas.drawText("⚡ BITE! ⚡", bobberX, alertY, biteAlertPaint)
        }
    }

    fun renderScreenMinigame(canvas: Canvas, screenW: Float, screenH: Float) {
        if (state != FishingState.CATCHING) return

        val barW = (screenW * 0.82f).coerceIn(320f, 500f)
        val barH = 44f
        val barLeft = (screenW - barW) * 0.5f
        val barTop = screenH * 0.30f
        val barRect = RectF(barLeft, barTop, barLeft + barW, barTop + barH)

        // Outer Brass Frame with Bevel
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(180, 140, 60)
            style = Paint.Style.STROKE
            strokeWidth = 5f
        }
        val innerTrackBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(12, 22, 36)
            style = Paint.Style.FILL
        }

        canvas.drawRoundRect(RectF(barLeft - 6f, barTop - 6f, barLeft + barW + 6f, barTop + barH + 6f), 14f, 14f, framePaint)
        canvas.drawRoundRect(barRect, 10f, 10f, innerTrackBg)

        // Green Catch Target Zone with Outer Glow Halo
        val zoneLeft = barLeft + barW * catchZoneStart
        val zoneRight = barLeft + barW * catchZoneEnd

        val zoneGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(70, 46, 204, 113)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(zoneLeft - 6f, barTop - 2f, zoneRight + 6f, barTop + barH + 2f), 8f, 8f, zoneGlowPaint)

        val zonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(39, 174, 96)
            style = Paint.Style.FILL
        }
        val zoneRect = RectF(zoneLeft, barTop + 3f, zoneRight, barTop + barH - 3f)
        canvas.drawRoundRect(zoneRect, 6f, 6f, zonePaint)

        // Catch zone pattern lines
        val hatchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(45, 255, 255, 255)
            strokeWidth = 2f
        }
        var hx = zoneLeft + 10f
        while (hx < zoneRight) {
            canvas.drawLine(hx, barTop + 4f, hx + 8f, barTop + barH - 4f, hatchPaint)
            hx += 14f
        }

        // Catch zone label
        val zoneLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = 13.5f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("CATCH ZONE", (zoneLeft + zoneRight) * 0.5f, barTop + barH * 0.62f, zoneLabelPaint)

        // Moving Indicator Needle with motion glow
        val needleX = barLeft + barW * needlePos
        val needleW = 10f
        val needleRect = RectF(needleX - needleW * 0.5f, barTop - 9f, needleX + needleW * 0.5f, barTop + barH + 9f)

        val needleGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(120, 255, 230, 80)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(needleRect.left - 4f, needleRect.top - 4f, needleRect.right + 4f, needleRect.bottom + 4f), 6f, 6f, needleGlowPaint)

        val needlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 225, 45) // Luminous gold needle
            style = Paint.Style.FILL
        }
        val needleBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(30, 20, 10)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(needleRect, 4f, 4f, needlePaint)
        canvas.drawRoundRect(needleRect, 4f, 4f, needleBorder)

        // Decorative corner rivets
        val rivetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 185, 90)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(barLeft - 2f, barTop - 2f, 3f, rivetPaint)
        canvas.drawCircle(barLeft + barW + 2f, barTop - 2f, 3f, rivetPaint)
        canvas.drawCircle(barLeft - 2f, barTop + barH + 2f, 3f, rivetPaint)
        canvas.drawCircle(barLeft + barW + 2f, barTop + barH + 2f, 3f, rivetPaint)

        // Title prompt header
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 235, 120)
            textAlign = Paint.Align.CENTER
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
        }
        val subHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 240, 255)
            textAlign = Paint.Align.CENTER
            textSize = 14.5f
        }
        canvas.drawText("🎣 REEL IN FISH!", screenW * 0.5f, barTop - 26f, headerPaint)
        canvas.drawText("Tap REEL when indicator is in the green zone!", screenW * 0.5f, barTop + barH + 28f, subHeaderPaint)
    }
}
