package com.example.game.economy

/**
 * Manages player wallet, transactions, and economy state.
 */
class EconomyManager(initialMoney: Int = 100) {
    var money: Int = initialMoney
        private set

    var onMoneyChanged: ((Int) -> Unit)? = null

    fun canAfford(amount: Int): Boolean = money >= amount

    fun spend(amount: Int): Boolean {
        if (canAfford(amount)) {
            money -= amount
            onMoneyChanged?.invoke(money)
            return true
        }
        return false
    }

    fun earn(amount: Int) {
        money += amount
        onMoneyChanged?.invoke(money)
    }

    fun formattedBalance(): String = "$$money"
}
