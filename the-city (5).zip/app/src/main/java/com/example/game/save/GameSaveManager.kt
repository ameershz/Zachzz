package com.example.game.save

import android.content.Context
import android.content.SharedPreferences
import com.example.game.fishing.CaughtFish
import com.example.game.fishing.FishSpecies
import com.example.game.fishing.FishingRod

/**
 * Handles persistent offline save data using Android SharedPreferences.
 * Stores money, fish inventory, equipped rod, and purchased rods.
 */
class GameSaveManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("TheCityFishingSaveData", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_MONEY = "player_money"
        private const val KEY_EQUIPPED_ROD = "equipped_rod_id"
        private const val KEY_PURCHASED_RODS = "purchased_rod_ids"
        private const val KEY_FISH_INVENTORY = "saved_fish_inventory"
        private const val KEY_TOTAL_CAUGHT = "total_fish_caught_stat"
    }

    fun saveGame(
        money: Int,
        equippedRod: FishingRod,
        purchasedRods: Set<String>,
        fishList: List<CaughtFish>,
        totalCaughtStat: Int
    ) {
        val serializedFish = fishList.joinToString(";;") { fish ->
            "${fish.id}::${fish.species.name}::${fish.weightKg}::${fish.value}"
        }

        prefs.edit()
            .putInt(KEY_MONEY, money)
            .putString(KEY_EQUIPPED_ROD, equippedRod.id)
            .putStringSet(KEY_PURCHASED_RODS, purchasedRods)
            .putString(KEY_FISH_INVENTORY, serializedFish)
            .putInt(KEY_TOTAL_CAUGHT, totalCaughtStat)
            .apply()
    }

    fun loadMoney(defaultMoney: Int = 50): Int {
        return prefs.getInt(KEY_MONEY, defaultMoney)
    }

    fun loadEquippedRodId(): String {
        return prefs.getString(KEY_EQUIPPED_ROD, FishingRod.WOODEN_ROD.id) ?: FishingRod.WOODEN_ROD.id
    }

    fun loadPurchasedRods(): MutableSet<String> {
        val saved = prefs.getStringSet(KEY_PURCHASED_RODS, null)
        val set = mutableSetOf(FishingRod.WOODEN_ROD.id)
        if (saved != null) {
            set.addAll(saved)
        }
        return set
    }

    fun loadFishInventory(): List<CaughtFish> {
        val raw = prefs.getString(KEY_FISH_INVENTORY, "") ?: ""
        if (raw.isBlank()) return emptyList()

        val list = mutableListOf<CaughtFish>()
        val entries = raw.split(";;")
        for (entry in entries) {
            if (entry.isBlank()) continue
            val parts = entry.split("::")
            if (parts.size >= 4) {
                try {
                    val id = parts[0]
                    val species = FishSpecies.valueOf(parts[1])
                    val weight = parts[2].toFloat()
                    val value = parts[3].toInt()
                    list.add(CaughtFish(id = id, species = species, weightKg = weight, value = value))
                } catch (_: Exception) {
                }
            }
        }
        return list
    }

    fun loadTotalCaughtStat(): Int {
        return prefs.getInt(KEY_TOTAL_CAUGHT, 0)
    }
}
