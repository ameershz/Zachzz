package com.example.game.input

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import kotlin.math.sin

/**
 * Highly stylized, responsive action button with dynamic metallic rims,
 * state-specific color themes, custom vector icons, drop shadows, and press animation.
 */
class ActionButton {
    var x: Float = 900f
    var y: Float = 900f
    var radius: Float = 75f

    var isVisible: Boolean = false
    var isPressed: Boolean = false
    var label: String = "ACTION"
    var subLabel: String = ""

    var activePointerId: Int = -1

    var animScale: Float = 0f
    private var pulseTimer: Float = 0f

    // Paints
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 8, 16, 28)
        style = Paint.Style.FILL
    }

    private val outerBevelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(240, 195, 75)
        style = Paint.Style.STROKE
        strokeWidth = 4.5f
    }

    private val innerGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(80, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val baseBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val pulseRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }

    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val iconStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }

    private val textShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(190, 10, 15, 25)
        textAlign = Paint.Align.CENTER
        textSize = 24f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 24f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(235, 245, 255)
        textAlign = Paint.Align.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun setDefaultPosition(screenW: Float, screenH: Float) {
        val shortDim = minOf(screenW, screenH)
        val density = (shortDim / 400f).coerceIn(1.8f, 2.7f)
        radius = 36f * density
        x = screenW - 40f - radius
        y = screenH - 36f - radius
        textPaint.textSize = 13.5f * density
        textShadowPaint.textSize = 13.5f * density
        subTextPaint.textSize = 9.5f * density
    }

    fun update(deltaTime: Float) {
        val targetScale = if (isVisible) 1f else 0f
        animScale += (targetScale - animScale) * (deltaTime * 12f).coerceIn(0f, 1f)
        pulseTimer += deltaTime * 4.5f
    }

    fun contains(touchX: Float, touchY: Float): Boolean {
        if (!isVisible || animScale < 0.3f) return false
        val dx = touchX - x
        val dy = touchY - y
        return (dx * dx + dy * dy) <= (radius * 1.25f) * (radius * 1.25f)
    }

    fun onTouchDown(pointerId: Int, touchX: Float, touchY: Float): Boolean {
        if (contains(touchX, touchY)) {
            activePointerId = pointerId
            isPressed = true
            return true
        }
        return false
    }

    fun onTouchUp(pointerId: Int, touchX: Float, touchY: Float): Boolean {
        if (pointerId == activePointerId) {
            val wasPressed = isPressed
            activePointerId = -1
            isPressed = false
            return wasPressed && contains(touchX, touchY)
        }
        return false
    }

    fun cancelTouch() {
        activePointerId = -1
        isPressed = false
    }

    fun render(canvas: Canvas) {
        if (animScale <= 0.01f) return

        canvas.save()
        val currentScale = animScale * if (isPressed) 0.91f else 1f
        canvas.translate(x, y)
        canvas.scale(currentScale, currentScale)

        // Determine Theme based on Action Label
        val (primaryColor, pressedColor, rimColor, isSpecial) = when {
            label.contains("HOOK", ignoreCase = true) -> {
                Quad(Color.rgb(241, 196, 15), Color.rgb(212, 172, 13), Color.rgb(255, 240, 160), true)
            }
            label.contains("REEL", ignoreCase = true) -> {
                Quad(Color.rgb(39, 174, 96), Color.rgb(30, 132, 73), Color.rgb(125, 235, 165), true)
            }
            label.contains("CAST", ignoreCase = true) -> {
                Quad(Color.rgb(230, 126, 34), Color.rgb(186, 94, 18), Color.rgb(255, 210, 140), false)
            }
            else -> {
                Quad(Color.rgb(41, 128, 185), Color.rgb(31, 97, 141), Color.rgb(130, 205, 255), false)
            }
        }

        // 1. Pulsing Outer Wave when active
        val pulseRadius = radius + (sin(pulseTimer * if (isSpecial) 2f else 1f) * 0.5f + 0.5f) * 12f
        val pulseAlpha = ((1f - (pulseRadius - radius) / 12f) * 120).toInt().coerceIn(0, 160)
        pulseRingPaint.color = primaryColor
        pulseRingPaint.alpha = pulseAlpha
        canvas.drawCircle(0f, 0f, pulseRadius, pulseRingPaint)

        // 2. Drop Shadow underneath
        canvas.drawCircle(3f, 6f, radius, shadowPaint)

        // 3. Main Circular Body
        baseBgPaint.color = if (isPressed) pressedColor else primaryColor
        canvas.drawCircle(0f, 0f, radius, baseBgPaint)

        // 4. Subtle Top Gloss Arc
        val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(55, 255, 255, 255)
            style = Paint.Style.FILL
        }
        canvas.drawOval(RectF(-radius * 0.8f, -radius * 0.85f, radius * 0.8f, -radius * 0.05f), glossPaint)

        // 5. Metallic Outer Bevel Rim
        outerBevelPaint.color = rimColor
        canvas.drawCircle(0f, 0f, radius - 1.5f, outerBevelPaint)
        canvas.drawCircle(0f, 0f, radius - 4f, innerGlowPaint)

        // 6. Vector Icon above text
        renderActionIcon(canvas)

        // 7. Action Typography
        val textY = if (subLabel.isEmpty()) radius * 0.38f else radius * 0.22f
        val subY = textY + subTextPaint.textSize * 1.25f

        // Text drop shadow
        canvas.drawText(label, 0f, textY + 2f, textShadowPaint)
        canvas.drawText(label, 0f, textY, textPaint)

        if (subLabel.isNotEmpty()) {
            canvas.drawText(subLabel, 0f, subY + 1.5f, textShadowPaint)
            canvas.drawText(subLabel, 0f, subY, subTextPaint)
        }

        canvas.restore()
    }

    private fun renderActionIcon(canvas: Canvas) {
        val iconY = -radius * 0.32f

        when {
            label.contains("HOOK", ignoreCase = true) -> {
                // Lightning Bolt Icon
                val bolt = Path().apply {
                    moveTo(3f, iconY - 14f)
                    lineTo(-9f, iconY + 1f)
                    lineTo(-1f, iconY + 1f)
                    lineTo(-4f, iconY + 14f)
                    lineTo(8f, iconY - 2f)
                    lineTo(1f, iconY - 2f)
                    close()
                }
                iconPaint.color = Color.WHITE
                canvas.drawPath(bolt, iconPaint)
            }
            label.contains("REEL", ignoreCase = true) -> {
                // Circular Reel / Target Spool Icon
                canvas.drawCircle(0f, iconY, 11f, iconStrokePaint)
                canvas.drawCircle(0f, iconY, 4f, iconPaint)
                canvas.drawLine(-11f, iconY, 11f, iconY, iconStrokePaint)
                canvas.drawLine(0f, iconY - 11f, 0f, iconY + 11f, iconStrokePaint)
            }
            label.contains("CAST", ignoreCase = true) -> {
                // Curved Fish Hook Icon
                val hook = Path().apply {
                    moveTo(0f, iconY - 12f)
                    lineTo(0f, iconY + 4f)
                    quadTo(0f, iconY + 12f, 8f, iconY + 12f)
                    quadTo(14f, iconY + 12f, 14f, iconY + 5f)
                    lineTo(11f, iconY + 7f)
                }
                canvas.drawPath(hook, iconStrokePaint)
                canvas.drawCircle(0f, iconY - 12f, 2.5f, iconStrokePaint)
            }
            else -> {
                // Nautical Compass / Storefront Diamond
                val star = Path().apply {
                    moveTo(0f, iconY - 12f)
                    lineTo(8f, iconY)
                    lineTo(0f, iconY + 12f)
                    lineTo(-8f, iconY)
                    close()
                }
                canvas.drawPath(star, iconStrokePaint)
                canvas.drawCircle(0f, iconY, 3f, iconPaint)
            }
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
