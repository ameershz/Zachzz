package com.example.game.engine

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.view.MotionEvent
import com.example.game.art.AssetCache
import com.example.game.art.VfxManager
import com.example.game.camera.Camera2D
import com.example.game.economy.EconomyManager
import com.example.game.fishing.CaughtFish
import com.example.game.fishing.FishingRod
import com.example.game.fishing.FishingState
import com.example.game.fishing.FishingSystem
import com.example.game.input.ActionButton
import com.example.game.input.TouchController
import com.example.game.input.VirtualJoystick
import com.example.game.interaction.Interactable
import com.example.game.interaction.InteractionManager
import com.example.game.inventory.FishInventory
import com.example.game.model.World
import com.example.game.physics.CollisionSystem
import com.example.game.player.Player
import com.example.game.player.PlayerDirection
import com.example.game.save.GameSaveManager
import com.example.game.ui.CatchCelebrationModal
import com.example.game.ui.FishInventoryModal
import com.example.game.ui.FishShopModal
import com.example.game.ui.FloatingText
import com.example.game.ui.InGameHud
import com.example.game.ui.RodShopModal

/**
 * Core game engine orchestrating the tropical island fishing game:
 * world physics, fishing mechanics, touch controls, shops, inventory, and local saves.
 */
class GameEngine(val context: Context) {
    val collisionSystem = CollisionSystem()
    val world = World(collisionSystem)
    val player = Player(world.spawnX, world.spawnY)
    val camera = Camera2D()

    val economyManager = EconomyManager(initialMoney = 50)
    val fishInventory = FishInventory(capacity = 10)
    val fishingSystem = FishingSystem(fishInventory)
    val interactionManager = InteractionManager()
    val saveManager = GameSaveManager(context)

    val joystick = VirtualJoystick()
    val actionButton = ActionButton()
    val touchController = TouchController(joystick, actionButton)

    val hud = InGameHud(economyManager, fishInventory)
    val vfxManager = VfxManager()
    val fishShopModal: FishShopModal
    val rodShopModal: RodShopModal
    val fishInventoryModal = FishInventoryModal(fishInventory)
    val catchCelebrationModal = CatchCelebrationModal()

    val purchasedRods = mutableSetOf<String>()
    private val floatingTexts = mutableListOf<FloatingText>()
    private var totalCaughtStat = 0

    var screenWidth: Float = 1080f
    var screenHeight: Float = 1920f

    init {
        // Initialize central asset cache for fish artworks & rod illustrations
        AssetCache.initialize(context)

        // Load persistent save data
        loadSavedData()

        camera.setTarget(player.x, player.y, instant = true)

        fishShopModal = FishShopModal(economyManager, fishInventory)
        rodShopModal = RodShopModal(economyManager, fishingSystem.equippedRod, purchasedRods)

        setupInteractions()
        setupCallbacks()
    }

    private fun loadSavedData() {
        val savedMoney = saveManager.loadMoney(defaultMoney = 50)
        economyManager.earn(savedMoney - economyManager.money)

        val loadedRods = saveManager.loadPurchasedRods()
        purchasedRods.clear()
        purchasedRods.addAll(loadedRods)

        val equippedId = saveManager.loadEquippedRodId()
        val equipped = FishingRod.getById(equippedId)
        fishingSystem.equippedRod = equipped
        hud.equippedRod = equipped
        player.equippedRodColor = equipped.rodColor

        val savedFish = saveManager.loadFishInventory()
        fishInventory.setLoadedFish(savedFish)

        totalCaughtStat = saveManager.loadTotalCaughtStat()
    }

    fun saveProgress() {
        saveManager.saveGame(
            money = economyManager.money,
            equippedRod = fishingSystem.equippedRod,
            purchasedRods = purchasedRods,
            fishList = fishInventory.getFishList(),
            totalCaughtStat = totalCaughtStat
        )
    }

    private fun setupInteractions() {
        interactionManager.clear()

        for (building in world.buildings) {
            val interactable = when (building.id) {
                "building_fish_shop" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "SELL FISH",
                        actionSubLabel = "Market Shop",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 85f,
                        onTrigger = {
                            fishShopModal.open()
                        }
                    )
                }

                "building_rod_shop" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "ROD SHOP",
                        actionSubLabel = "Gear Upgrades",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 85f,
                        onTrigger = {
                            rodShopModal.equippedRod = fishingSystem.equippedRod
                            rodShopModal.open()
                        }
                    )
                }

                "building_home" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "REST",
                        actionSubLabel = "Save Game",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 85f,
                        onTrigger = {
                            saveProgress()
                            addFloatingText(player.x, player.y - 45f, "✨ Rested at Cottage! Progress Saved.", Color.rgb(46, 204, 113))
                        }
                    )
                }

                "building_marina_hut" -> {
                    Interactable(
                        id = building.id,
                        name = building.name,
                        actionLabel = "INSPECT",
                        actionSubLabel = "Boat Dock",
                        triggerX = building.entranceX,
                        triggerY = building.entranceY,
                        radius = 85f,
                        onTrigger = {
                            addFloatingText(player.x, player.y - 45f, "⛵ Sea Expeditions dock (Coming Soon!)", Color.rgb(52, 152, 219))
                        }
                    )
                }

                else -> null
            }

            if (interactable != null) {
                interactionManager.register(interactable)
            }
        }
    }

    private fun setupCallbacks() {
        // Tapping HUD Fish Bag button
        hud.onInventoryClicked = {
            if (fishingSystem.state == FishingState.FREE_ROAM) {
                fishInventoryModal.open()
            }
        }

        // Action button tap callback
        touchController.onActionClicked = {
            handleActionTap()
        }

        // Screen tap interceptor for UI modals
        touchController.onScreenTapped = { tx, ty ->
            when {
                catchCelebrationModal.isOpen -> catchCelebrationModal.onTouch(tx, ty)
                fishShopModal.isOpen -> fishShopModal.onTouch(tx, ty)
                rodShopModal.isOpen -> rodShopModal.onTouch(tx, ty)
                fishInventoryModal.isOpen -> fishInventoryModal.onTouch(tx, ty)
                hud.onTouch(tx, ty) -> true
                else -> false
            }
        }

        // Catch celebration modal callback
        catchCelebrationModal.onCollect = {
            fishingSystem.resetFishing()
            player.isFishing = false
            joystick.reset()
            saveProgress()
        }

        // State change callback
        fishingSystem.onStateChanged = { newState ->
            if (newState == FishingState.FREE_ROAM) {
                player.isFishing = false
                joystick.reset()
            } else if (newState == FishingState.BITE) {
                vfxManager.spawnWaterSplash(fishingSystem.bobberX, fishingSystem.bobberY, 14, 1.1f)
            }
        }

        // Fishing system callbacks
        fishingSystem.onFishCaught = { caughtFish ->
            totalCaughtStat++
            saveProgress()
            vfxManager.spawnWaterSplash(fishingSystem.bobberX, fishingSystem.bobberY, 20, 1.3f)
            vfxManager.spawnCelebrationBurst(screenWidth * 0.5f, screenHeight * 0.38f, caughtFish.species.rarity)
            catchCelebrationModal.show(caughtFish)
            addFloatingText(player.x, player.y - 40f, "+1 ${caughtFish.species.speciesName}!", caughtFish.species.rarity.color)
        }

        fishingSystem.onFishEscaped = { reason ->
            player.isFishing = false
            joystick.reset()
            addFloatingText(player.x, player.y - 40f, reason, Color.rgb(231, 76, 60))
        }

        // Fish Shop sale callback
        fishShopModal.onSoldFish = { count, totalEarned ->
            saveProgress()
            addFloatingText(player.x, player.y - 40f, "+$$totalEarned!", Color.rgb(241, 196, 15))
            addFloatingText(player.x, player.y - 15f, "Sold $count fish to monger", Color.rgb(46, 204, 113))
        }

        // Rod Shop callbacks
        rodShopModal.onRodPurchased = { rod ->
            saveProgress()
            addFloatingText(player.x, player.y - 40f, "Unlocked ${rod.name}!", Color.rgb(241, 196, 15))
        }

        rodShopModal.onRodEquipped = { rod ->
            fishingSystem.equippedRod = rod
            hud.equippedRod = rod
            player.equippedRodColor = rod.rodColor
            saveProgress()
            addFloatingText(player.x, player.y - 40f, "Equipped ${rod.name}!", Color.WHITE)
        }
    }

    private fun handleActionTap() {
        when (fishingSystem.state) {
            FishingState.FREE_ROAM -> {
                // If near fishing spot, start casting!
                if (world.isPlayerNearFishingSpot(player.x, player.y)) {
                    val dock = world.mainFishingDock
                    player.direction = PlayerDirection.NORTH
                    player.vx = 0f
                    player.vy = 0f
                    fishingSystem.startCasting(
                        playerX = player.x,
                        playerY = player.y,
                        direction = PlayerDirection.NORTH,
                        dockReachX = dock.waterTargetX,
                        dockReachY = dock.waterTargetY
                    )
                } else {
                    // Otherwise trigger closest building interaction
                    interactionManager.triggerActive()
                }
            }

            FishingState.WAITING_FOR_BITE -> {
                // Cancel casting and reel line back in
                fishingSystem.cancelFishing()
                addFloatingText(player.x, player.y - 30f, "Reeled in line", Color.rgb(180, 195, 210))
            }

            FishingState.BITE, FishingState.CATCHING -> {
                fishingSystem.onActionTriggered()
            }

            FishingState.CAUGHT -> {
                catchCelebrationModal.dismiss()
                fishingSystem.resetFishing()
                player.isFishing = false
                joystick.reset()
            }

            else -> {}
        }
    }

    fun onSurfaceChanged(width: Float, height: Float) {
        screenWidth = width
        screenHeight = height

        camera.resize(width, height)
        camera.setWorldBounds(collisionSystem.worldBounds)
        camera.setTarget(player.x, player.y, instant = true)

        joystick.setDefaultPosition(width, height)
        actionButton.setDefaultPosition(width, height)
    }

    fun update(deltaTime: Float) {
        val dt = deltaTime.coerceIn(0.001f, 0.05f)

        world.update(dt)

        // Failsafe state reconciliation: if celebration modal closed while CAUGHT, return to FREE_ROAM
        if (fishingSystem.state == FishingState.CAUGHT && !catchCelebrationModal.isOpen) {
            fishingSystem.resetFishing()
            player.isFishing = false
            joystick.reset()
        }

        val anyModalOpen = catchCelebrationModal.isOpen || fishShopModal.isOpen ||
                rodShopModal.isOpen || fishInventoryModal.isOpen

        // Handle player movement and state
        if (anyModalOpen) {
            player.vx = 0f
            player.vy = 0f
            player.isFishing = false
            joystick.reset()
            actionButton.isVisible = false
        } else if (fishingSystem.state != FishingState.FREE_ROAM) {
            // Player is in an active fishing state
            player.vx = 0f
            player.vy = 0f
            player.direction = PlayerDirection.NORTH
            player.isFishing = true
            joystick.reset()

            // Update fishing system
            fishingSystem.update(dt, player.x, player.y)

            // Configure Action Button for fishing
            when (fishingSystem.state) {
                FishingState.CASTING -> {
                    actionButton.isVisible = false
                }
                FishingState.WAITING_FOR_BITE -> {
                    actionButton.isVisible = true
                    actionButton.label = "REEL IN"
                    actionButton.subLabel = "Cancel"
                }
                FishingState.BITE -> {
                    actionButton.isVisible = true
                    actionButton.label = "HOOK! ⚡"
                    actionButton.subLabel = "STRIKE"
                }
                FishingState.CATCHING -> {
                    actionButton.isVisible = true
                    actionButton.label = "REEL! 🎯"
                    actionButton.subLabel = "TIMING"
                }
                else -> {
                    actionButton.isVisible = false
                }
            }
        } else {
            // Free roam state
            player.isFishing = false

            player.update(
                deltaTime = dt,
                inputDirX = joystick.dirX,
                inputDirY = joystick.dirY,
                inputIntensity = joystick.intensity,
                collisionSystem = collisionSystem
            )

            // Proximity checks
            val nearFishingSpot = world.isPlayerNearFishingSpot(player.x, player.y)
            if (nearFishingSpot) {
                interactionManager.update(0f, 0f) // Clear building active
                actionButton.isVisible = true
                actionButton.label = "CAST 🎣"
                actionButton.subLabel = "Start Fishing"
            } else {
                interactionManager.update(player.x, player.y)
                val active = interactionManager.activeInteractable
                if (active != null) {
                    actionButton.isVisible = true
                    actionButton.label = active.actionLabel
                    actionButton.subLabel = active.actionSubLabel
                } else {
                    actionButton.isVisible = false
                }
            }
        }

        camera.setTarget(player.x, player.y)
        camera.update(dt)
        actionButton.update(dt)
        vfxManager.update(dt)
        catchCelebrationModal.update(dt)

        // HUD updates
        hud.currentLocationName = world.getLocationName(player.x, player.y)
        hud.activeInteractable = interactionManager.activeInteractable
        hud.fishingState = fishingSystem.state
        hud.update(dt)

        // Update floating texts
        val textIterator = floatingTexts.iterator()
        while (textIterator.hasNext()) {
            val ft = textIterator.next()
            ft.update(dt)
            if (ft.isDead) textIterator.remove()
        }
    }

    fun render(canvas: Canvas) {
        // Deep blue ocean background
        canvas.drawColor(Color.rgb(10, 50, 95))

        // 1. World Rendering with Camera Transform
        camera.applyTransform(canvas)

        world.render(canvas)

        // Draw fishing line and bobber if active
        fishingSystem.renderInWorld(canvas)

        // Draw World Particle VFX (Water Splashes)
        vfxManager.renderWorldVfx(canvas)

        // Draw Player with equipped fishing rod and directional animation
        player.render(canvas)

        // Floating notifications in world
        for (ft in floatingTexts) {
            ft.render(canvas)
        }

        canvas.restore()

        // 2. Screen Space Rendering
        // Catching Minigame bar
        fishingSystem.renderScreenMinigame(canvas, screenWidth, screenHeight)

        // Screen Particle VFX (Celebration Stars)
        vfxManager.renderScreenVfx(canvas)

        // HUD (Money, Equipped Rod, Fish Bag)
        hud.render(canvas, screenWidth, screenHeight)

        // Virtual joystick (if no modal is open and not fishing)
        val anyModalOpen = catchCelebrationModal.isOpen || fishShopModal.isOpen ||
                rodShopModal.isOpen || fishInventoryModal.isOpen

        if (!anyModalOpen && fishingSystem.state == FishingState.FREE_ROAM) {
            joystick.render(canvas)
        }

        // Action button
        if (!anyModalOpen) {
            actionButton.render(canvas)
        }

        // Modals
        if (fishShopModal.isOpen) {
            fishShopModal.render(canvas, screenWidth, screenHeight)
        }
        if (rodShopModal.isOpen) {
            rodShopModal.render(canvas, screenWidth, screenHeight)
        }
        if (fishInventoryModal.isOpen) {
            fishInventoryModal.render(canvas, screenWidth, screenHeight)
        }
        if (catchCelebrationModal.isOpen) {
            catchCelebrationModal.render(canvas, screenWidth, screenHeight)
        }
    }

    fun handleTouchEvent(event: MotionEvent): Boolean {
        return touchController.handleTouchEvent(event, screenWidth, screenHeight)
    }

    fun addFloatingText(wx: Float, wy: Float, text: String, color: Int = Color.rgb(255, 220, 60)) {
        floatingTexts.add(FloatingText(wx, wy, text, color))
    }
}
