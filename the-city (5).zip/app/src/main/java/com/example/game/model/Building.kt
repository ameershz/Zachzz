package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.physics.RectCollider

/**
 * Detailed 2D top-down building entity tailored for the tropical fishing village.
 */
class Building(
    val id: String,
    val name: String,
    val type: BuildingType,
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    val entranceX: Float,
    val entranceY: Float,
    val wallColor: Int,
    val roofColor: Int,
    val trimColor: Int,
    val signText: String,
    val signBgColor: Int = Color.rgb(24, 34, 52),
    val signTextColor: Int = Color.WHITE,
    val hasAwning: Boolean = false,
    val awningColor1: Int = Color.WHITE,
    val awningColor2: Int = Color.rgb(41, 128, 185),
    val interactionLabel: String = "ENTER",
    val interactionSubLabel: String = ""
) {
    val right: Float get() = left + width
    val bottom: Float get() = top + height
    val centerX: Float get() = left + width * 0.5f
    val centerY: Float get() = top + height * 0.5f

    // Collision box (covers main structure; entrance area is clear for walking up to door)
    val collider: RectCollider = RectCollider(
        left = left + 4f,
        top = top + 8f,
        right = right - 4f,
        bottom = bottom - 8f,
        tag = id
    )

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(65, 10, 25, 40)
        style = Paint.Style.FILL
    }

    private val wallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = wallColor
        style = Paint.Style.FILL
    }

    private val roofPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = roofColor
        style = Paint.Style.FILL
    }

    private val roofShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 0, 0, 0)
        style = Paint.Style.FILL
    }

    private val trimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = trimColor
        style = Paint.Style.FILL
    }

    private val doorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(85, 52, 28) // Teak wood
        style = Paint.Style.FILL
    }

    private val windowGlassPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(175, 220, 245)
        style = Paint.Style.FILL
    }

    private val windowFramePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val signBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = signBgColor
        style = Paint.Style.FILL
    }

    private val signTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = signTextColor
        textAlign = Paint.Align.CENTER
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val entryMatPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 45, 55, 65)
        style = Paint.Style.FILL
    }

    fun update(deltaTime: Float) {
    }

    fun render(canvas: Canvas) {
        // 1. Building cast ground shadow
        val shadowRect = RectF(left + 8f, top + 15f, right + 16f, bottom + 14f)
        canvas.drawRoundRect(shadowRect, 10f, 10f, shadowPaint)

        // 2. Doorstep / entry mat
        val matW = 44f
        val matH = 16f
        val matRect = RectF(entranceX - matW * 0.5f, bottom - 6f, entranceX + matW * 0.5f, bottom + matH - 6f)
        canvas.drawRoundRect(matRect, 3f, 3f, entryMatPaint)

        // 3. Main building base wall
        val baseRect = RectF(left, top + 32f, right, bottom)
        canvas.drawRoundRect(baseRect, 8f, 8f, wallPaint)

        // Plinth base trim
        val plinthRect = RectF(left, bottom - 8f, right, bottom)
        canvas.drawRect(plinthRect, trimPaint)

        // 4. Windows and Doors
        renderWindowsAndDoors(canvas)

        // 5. Roof rendering
        renderRoof(canvas)

        // 6. Awning if applicable (e.g. Fish Shop)
        if (hasAwning) {
            renderAwning(canvas)
        }

        // 7. Storefront Sign
        if (signText.isNotEmpty()) {
            renderSign(canvas)
        }

        // 8. Custom props beside building
        when (type) {
            BuildingType.FISH_SHOP -> renderFishCrates(canvas)
            BuildingType.ROD_SHOP -> renderRodRacks(canvas)
            else -> {}
        }
    }

    private fun renderWindowsAndDoors(canvas: Canvas) {
        val doorW = 34f
        val doorH = 48f
        val doorX = entranceX - doorW * 0.5f
        val doorY = bottom - doorH

        // Door frame & body
        canvas.drawRoundRect(RectF(doorX - 2f, doorY - 2f, doorX + doorW + 2f, bottom), 4f, 4f, trimPaint)
        canvas.drawRoundRect(RectF(doorX, doorY, doorX + doorW, bottom), 3f, 3f, doorPaint)

        // Glass panel on door
        val doorGlassRect = RectF(doorX + 5f, doorY + 6f, doorX + doorW - 5f, doorY + 22f)
        canvas.drawRoundRect(doorGlassRect, 2f, 2f, windowGlassPaint)

        // Brass doorknob
        val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(240, 205, 75)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(doorX + doorW - 6f, doorY + 30f, 2.5f, knobPaint)

        // Window on side
        val winW = 34f
        val winH = 32f
        val winY = bottom - 50f
        val winX = left + 18f
        if (winX + winW < doorX - 10f) {
            val winRect = RectF(winX, winY, winX + winW, winY + winH)
            canvas.drawRoundRect(winRect, 3f, 3f, windowGlassPaint)
            canvas.drawRoundRect(winRect, 3f, 3f, windowFramePaint)
            canvas.drawLine(winX + winW * 0.5f, winY, winX + winW * 0.5f, winY + winH, windowFramePaint)
            canvas.drawLine(winX, winY + winH * 0.5f, winX + winW, winY + winH * 0.5f, windowFramePaint)
        }
    }

    private fun renderRoof(canvas: Canvas) {
        val roofOverhang = 8f
        val roofHeight = 44f
        val roofRect = RectF(left - roofOverhang, top, right + roofOverhang, top + roofHeight)
        canvas.drawRoundRect(roofRect, 6f, 6f, roofPaint)

        // Roof overhang shadow under eaves
        val eaveShadow = RectF(left, top + roofHeight, right, top + roofHeight + 5f)
        canvas.drawRect(eaveShadow, roofShadowPaint)

        // Slanted shingle lines
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(40, 255, 255, 255)
            strokeWidth = 2f
        }
        var xLine = left
        while (xLine < right) {
            canvas.drawLine(xLine, top + 4f, xLine, top + roofHeight - 4f, linePaint)
            xLine += 20f
        }
    }

    private fun renderAwning(canvas: Canvas) {
        val awningY = bottom - 62f
        val awningH = 22f
        val awningLeft = left + 10f
        val awningRight = right - 10f
        val totalW = awningRight - awningLeft
        val stripeCount = (totalW / 18f).toInt().coerceAtLeast(4)
        val stripeW = totalW / stripeCount

        val p1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = awningColor1 }
        val p2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = awningColor2 }

        for (i in 0 until stripeCount) {
            val sX = awningLeft + i * stripeW
            val stripeRect = RectF(sX, awningY, sX + stripeW, awningY + awningH)
            canvas.drawRect(stripeRect, if (i % 2 == 0) p1 else p2)

            val scallopRect = RectF(sX, awningY + awningH - 4f, sX + stripeW, awningY + awningH + 6f)
            canvas.drawOval(scallopRect, if (i % 2 == 0) p1 else p2)
        }

        val awShadow = RectF(awningLeft, awningY + awningH + 4f, awningRight, awningY + awningH + 8f)
        canvas.drawRect(awShadow, roofShadowPaint)
    }

    private fun renderSign(canvas: Canvas) {
        val signW = (width * 0.72f).coerceIn(120f, 220f)
        val signH = 26f
        val signX = centerX - signW * 0.5f
        val signY = top + 12f

        val signRect = RectF(signX, signY, signX + signW, signY + signH)
        canvas.drawRoundRect(RectF(signX + 2f, signY + 2f, signX + signW + 2f, signY + signH + 2f), 4f, 4f, roofShadowPaint)
        canvas.drawRoundRect(signRect, 4f, 4f, signBgPaint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(180, 255, 255, 255)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(signRect, 4f, 4f, borderPaint)

        val textY = signY + signH * 0.5f + signTextPaint.textSize * 0.35f
        canvas.drawText(signText, centerX, textY, signTextPaint)
    }

    private fun renderFishCrates(canvas: Canvas) {
        // Decorative fish barrels & ice crates beside the shop
        val crateX = right - 36f
        val crateY = bottom - 30f
        val cratePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(165, 115, 65)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(RectF(crateX, crateY, crateX + 26f, crateY + 26f), 3f, 3f, cratePaint)
        // Ice inside
        val icePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 240, 255)
            style = Paint.Style.FILL
        }
        canvas.drawRect(crateX + 3f, crateY + 3f, crateX + 23f, crateY + 10f, icePaint)
    }

    private fun renderRodRacks(canvas: Canvas) {
        // Crossed fishing rods rack beside rod shop
        val rackX = left + 14f
        val rackY = bottom - 24f
        val rodPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(180, 130, 70)
            strokeWidth = 3f
            strokeCap = Paint.Cap.ROUND
        }
        canvas.drawLine(rackX, rackY + 18f, rackX + 16f, rackY - 8f, rodPaint)
        canvas.drawLine(rackX + 16f, rackY + 18f, rackX, rackY - 8f, rodPaint)
    }
}
