package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.art.AssetCache
import com.example.game.fishing.CaughtFish
import com.example.game.fishing.FishRarity
import kotlin.math.cos
import kotlin.math.sin

/**
 * High-end reward celebration modal popup showcasing the fish artwork,
 * dynamic radiance rays, rarity ribbons, weight and market value badges.
 */
class CatchCelebrationModal(
    var onCollect: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set
    var caughtFish: CaughtFish? = null
        private set

    private val modalRect = RectF()
    private val collectBtnRect = RectF()
    private var celebrationTimer: Float = 0f

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(195, 6, 12, 22)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(18, 26, 42)
        style = Paint.Style.FILL
    }

    private val pedestalBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(10, 16, 28)
        style = Paint.Style.FILL
    }

    private val rayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 225, 75)
        textAlign = Paint.Align.CENTER
        textSize = 21f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val fishNamePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 23f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val ribbonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val ribbonTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val statPillBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 40, 60)
        style = Paint.Style.FILL
    }

    private val statTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(230, 242, 255)
        textAlign = Paint.Align.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val collectBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(39, 174, 96)
        style = Paint.Style.FILL
    }

    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun show(fish: CaughtFish) {
        caughtFish = fish
        celebrationTimer = 0f
        isOpen = true
    }

    fun dismiss() {
        if (!isOpen) return
        isOpen = false
        caughtFish = null
        onCollect?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false
        dismiss()
        return true
    }

    fun update(deltaTime: Float) {
        if (isOpen) {
            celebrationTimer += deltaTime
        }
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        val fish = caughtFish ?: return
        if (!isOpen) return

        celebrationTimer += 0.016f

        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        val cardW = (screenW * 0.86f).coerceIn(320f, 440f)
        val cardH = 430f
        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        val rarity = fish.species.rarity

        // 1. Rotating Radiance Rays (for Rare, Epic, Legendary)
        if (rarity != FishRarity.COMMON) {
            canvas.save()
            val rayCenterY = cardTop + 145f
            canvas.translate(screenW * 0.5f, rayCenterY)
            val rayAlpha = when (rarity) {
                FishRarity.UNCOMMON -> 35
                FishRarity.RARE -> 55
                FishRarity.EPIC -> 80
                FishRarity.LEGENDARY -> 110
                else -> 20
            }
            rayPaint.color = rarity.color
            rayPaint.alpha = rayAlpha

            val rayCount = if (rarity == FishRarity.LEGENDARY) 12 else 8
            val rotAngle = celebrationTimer * 25f
            canvas.rotate(rotAngle)

            for (i in 0 until rayCount) {
                canvas.rotate(360f / rayCount)
                val rayPath = Path().apply {
                    moveTo(0f, 0f)
                    lineTo(-18f, -170f)
                    lineTo(18f, -170f)
                    close()
                }
                canvas.drawPath(rayPath, rayPaint)
            }
            canvas.restore()
        }

        // 2. Card Background & Golden/Rarity Border
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = rarity.color
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRoundRect(modalRect, 22f, 22f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 22f, 22f, borderPaint)

        // 3. Header Title
        val headerText = when (rarity) {
            FishRarity.LEGENDARY -> "👑 LEGENDARY DISCOVERY! 👑"
            FishRarity.EPIC -> "✨ EPIC CATCH! ✨"
            FishRarity.RARE -> "⭐ RARE TROPHY! ⭐"
            else -> "✨ FRESH CATCH! ✨"
        }
        canvas.drawText(headerText, screenW * 0.5f, cardTop + 40f, titlePaint)

        // 4. Central Art Pedestal & Fish Artwork
        val pedestalSize = 135f
        val pedestalRect = RectF(
            screenW * 0.5f - pedestalSize * 0.5f,
            cardTop + 60f,
            screenW * 0.5f + pedestalSize * 0.5f,
            cardTop + 60f + pedestalSize
        )
        canvas.drawRoundRect(pedestalRect, 16f, 16f, pedestalBgPaint)

        val pedestalBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(120, 255, 255, 255)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(pedestalRect, 16f, 16f, pedestalBorder)

        // Draw High-Definition Fish Artwork inside Pedestal
        val artPad = 8f
        val artRect = RectF(pedestalRect.left + artPad, pedestalRect.top + artPad, pedestalRect.right - artPad, pedestalRect.bottom - artPad)
        AssetCache.drawFishArtwork(canvas, fish.species, artRect)

        // 5. Fish Species Name
        canvas.drawText(fish.species.speciesName, screenW * 0.5f, pedestalRect.bottom + 32f, fishNamePaint)

        // 6. Rarity Ribbon Badge
        val ribbonW = 150f
        val ribbonH = 26f
        val ribbonY = pedestalRect.bottom + 42f
        val ribbonRect = RectF(screenW * 0.5f - ribbonW * 0.5f, ribbonY, screenW * 0.5f + ribbonW * 0.5f, ribbonY + ribbonH)
        ribbonPaint.color = rarity.color
        canvas.drawRoundRect(ribbonRect, 13f, 13f, ribbonPaint)
        canvas.drawText(rarity.displayName.uppercase(), screenW * 0.5f, ribbonY + ribbonH * 0.68f, ribbonTextPaint)

        // 7. Dual Stat Pills: Weight & Sell Value
        val pillW = (cardW - 56f) * 0.48f
        val pillH = 38f
        val pillY = ribbonRect.bottom + 16f

        // Weight Pill
        val weightRect = RectF(cardLeft + 20f, pillY, cardLeft + 20f + pillW, pillY + pillH)
        canvas.drawRoundRect(weightRect, 8f, 8f, statPillBg)
        canvas.drawText("⚖️ ${fish.formattedWeight}", weightRect.centerX(), weightRect.centerY() + statTextPaint.textSize * 0.35f, statTextPaint)

        // Value Pill
        val valueRect = RectF(cardLeft + cardW - 20f - pillW, pillY, cardLeft + cardW - 20f, pillY + pillH)
        canvas.drawRoundRect(valueRect, 8f, 8f, statPillBg)
        val valueColorPaint = Paint(statTextPaint).apply { color = Color.rgb(255, 215, 65) }
        canvas.drawText("💰 ${fish.formattedValue}", valueRect.centerX(), valueRect.centerY() + statTextPaint.textSize * 0.35f, valueColorPaint)

        // 8. Collect Button with Pulse Animation
        val btnW = 180f
        val btnH = 46f
        val btnY = cardTop + cardH - 64f
        collectBtnRect.set((screenW - btnW) * 0.5f, btnY, (screenW + btnW) * 0.5f, btnY + btnH)

        val btnPulse = sin(celebrationTimer * 5f) * 1.5f
        val pulseBtnRect = RectF(collectBtnRect.left - btnPulse, collectBtnRect.top - btnPulse, collectBtnRect.right + btnPulse, collectBtnRect.bottom + btnPulse)
        canvas.drawRoundRect(pulseBtnRect, 12f, 12f, collectBtnPaint)
        canvas.drawText("KEEP IN CREEL", screenW * 0.5f, collectBtnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)
    }
}
