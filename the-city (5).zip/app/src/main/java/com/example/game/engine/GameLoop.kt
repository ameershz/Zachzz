package com.example.game.engine

import android.view.SurfaceHolder

/**
 * Dedicated high-performance game loop worker thread.
 * Coordinates real-time update and canvas rendering at 60 FPS.
 */
class GameLoop(
    private val surfaceHolder: SurfaceHolder,
    private val engine: GameEngine
) : Thread("TheCity-GameLoop") {

    @Volatile
    var isRunning: Boolean = false

    private val targetFps: Long = 60
    private val targetFrameTimeMs: Long = 1000 / targetFps

    fun stopLoop() {
        isRunning = false
        try {
            join(500)
        } catch (_: InterruptedException) {
        }
    }

    override fun run() {
        var lastTime = System.nanoTime()

        while (isRunning) {
            val now = System.nanoTime()
            val elapsedNanos = now - lastTime
            lastTime = now

            val deltaTime = elapsedNanos / 1_000_000_000f

            // Update game physics and state
            engine.update(deltaTime)

            // Render game world to SurfaceView canvas
            var canvas = try {
                surfaceHolder.lockCanvas()
            } catch (e: Exception) {
                null
            }

            if (canvas != null) {
                try {
                    synchronized(surfaceHolder) {
                        engine.render(canvas)
                    }
                } finally {
                    try {
                        surfaceHolder.unlockCanvasAndPost(canvas)
                    } catch (_: Exception) {
                    }
                }
            }

            // Frame rate pacing
            val frameTimeMs = (System.nanoTime() - now) / 1_000_000L
            val sleepTimeMs = targetFrameTimeMs - frameTimeMs
            if (sleepTimeMs > 1) {
                try {
                    sleep(sleepTimeMs)
                } catch (_: InterruptedException) {
                }
            }
        }
    }
}
