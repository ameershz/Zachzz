package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.art.AssetCache
import com.example.game.inventory.FishInventory

/**
 * Redesigned stylized Fish Creel / Inventory modal featuring high-definition fish artworks,
 * rarity badges, weights, and individual values.
 */
class FishInventoryModal(
    val fishInventory: FishInventory,
    var onClose: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set

    private val modalRect = RectF()
    private val closeBtnRect = RectF()

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(185, 6, 14, 24)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(18, 28, 44)
        style = Paint.Style.FILL
    }

    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(52, 152, 219)
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(24, 40, 64)
        style = Paint.Style.FILL
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 21f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val itemBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(12, 20, 32)
        style = Paint.Style.FILL
    }

    private val itemBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(70, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
    }

    private val fishTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val weightTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(175, 195, 215)
        textSize = 12f
    }

    private val valueTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(241, 196, 15)
        textAlign = Paint.Align.RIGHT
        textSize = 15.5f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val closeBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(52, 152, 219)
        style = Paint.Style.FILL
    }

    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun open() {
        isOpen = true
    }

    fun close() {
        isOpen = false
        onClose?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false

        if (closeBtnRect.contains(touchX, touchY)) {
            close()
            return true
        }

        if (!modalRect.contains(touchX, touchY)) {
            close()
            return true
        }

        return true
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        if (!isOpen) return

        val isLandscape = screenW > screenH

        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        val cardW = if (isLandscape) (screenW * 0.74f).coerceIn(520f, 720f) else (screenW * 0.90f).coerceIn(320f, 480f)
        val cardH = if (isLandscape) (screenH * 0.88f).coerceIn(340f, 440f) else 480f.coerceAtMost(screenH * 0.88f)
        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        canvas.drawRoundRect(modalRect, 18f, 18f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBorderPaint)

        // Header
        val headerH = if (isLandscape) 46f else 54f
        val headerRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + headerH)
        canvas.drawRoundRect(headerRect, 18f, 18f, headerPaint)
        canvas.drawRect(cardLeft, cardTop + headerH - 12f, cardLeft + cardW, cardTop + headerH, headerPaint)

        canvas.drawText("🎒 Fish Creel (${fishInventory.count}/${fishInventory.capacity})", screenW * 0.5f, cardTop + headerH * 0.62f, titlePaint)

        // Items list area
        val footerH = if (isLandscape) 42f else 48f
        val listTop = cardTop + headerH + 12f
        val listBottom = cardTop + cardH - footerH - 6f
        val listRect = RectF(cardLeft + 14f, listTop, cardLeft + cardW - 14f, listBottom)

        val fishList = fishInventory.getFishList()
        if (fishList.isEmpty()) {
            val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(150, 175, 205)
                textAlign = Paint.Align.CENTER
                textSize = 15f
            }
            canvas.drawText("Your creel is empty.", listRect.centerX(), listRect.centerY() - 10f, emptyPaint)
            canvas.drawText("Walk up the pier and cast your line!", listRect.centerX(), listRect.centerY() + 16f, emptyPaint)
        } else {
            var itemY = listTop + 4f
            val itemH = if (isLandscape) 52f else 56f
            val maxItems = if (isLandscape) 4 else 5

            for (i in 0 until minOf(maxItems, fishList.size)) {
                val fish = fishList[i]
                val rowRect = RectF(listRect.left + 4f, itemY, listRect.right - 4f, itemY + itemH)

                canvas.drawRoundRect(rowRect, 8f, 8f, itemBoxPaint)

                // Rarity border indicator on row
                val rowBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = fish.species.rarity.color
                    style = Paint.Style.STROKE
                    strokeWidth = 1.8f
                }
                canvas.drawRoundRect(rowRect, 8f, 8f, rowBorder)

                // Fish Artwork Thumbnail (Asset instead of Emoji!)
                val thumbPad = 5f
                val thumbRect = RectF(rowRect.left + 8f, rowRect.top + thumbPad, rowRect.left + 8f + itemH - thumbPad * 2, rowRect.bottom - thumbPad)
                AssetCache.drawFishArtwork(canvas, fish.species, thumbRect)

                // Fish Name & Rarity badge
                val textX = thumbRect.right + 12f
                canvas.drawText(fish.species.speciesName, textX, rowRect.top + 22f, fishTextPaint)

                val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = fish.species.rarity.color
                    textSize = 11.5f
                    typeface = Typeface.DEFAULT_BOLD
                }
                canvas.drawText("${fish.species.rarity.displayName.uppercase()}  •  ${fish.formattedWeight}", textX, rowRect.top + 40f, badgePaint)

                // Value on right
                canvas.drawText(fish.formattedValue, rowRect.right - 14f, rowRect.centerY() + valueTextPaint.textSize * 0.35f, valueTextPaint)

                itemY += itemH + 6f
            }

            if (fishList.size > maxItems) {
                val morePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(170, 200, 230)
                    textAlign = Paint.Align.CENTER
                    textSize = 12.5f
                }
                canvas.drawText("+ ${fishList.size - maxItems} more fish in creel", listRect.centerX(), listBottom - 4f, morePaint)
            }
        }

        // Footer: Total value & Close Button
        val footerY = cardTop + cardH - (if (isLandscape) 18f else 22f)
        val summaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 215, 65)
            textSize = 15.5f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("Total Value: $${fishInventory.totalValue}", cardLeft + 20f, footerY, summaryPaint)

        closeBtnRect.set(cardLeft + cardW - 110f, footerY - 22f, cardLeft + cardW - 18f, footerY + 12f)
        canvas.drawRoundRect(closeBtnRect, 8f, 8f, closeBtnPaint)
        canvas.drawText("CLOSE", closeBtnRect.centerX(), closeBtnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)
    }
}
