package com.example.game.fishing

import android.graphics.Color

enum class FishRarity(
    val displayName: String,
    val color: Int,
    val catchZoneWidth: Float, // Fraction of the timing bar [0.1..0.4]
    val needleSpeed: Float,     // Speed multiplier
    val chanceWeight: Int       // Relative spawn weight
) {
    COMMON("Common", Color.rgb(180, 190, 200), 0.35f, 1.0f, 50),
    UNCOMMON("Uncommon", Color.rgb(46, 204, 113), 0.28f, 1.25f, 30),
    RARE("Rare", Color.rgb(52, 152, 219), 0.22f, 1.55f, 14),
    EPIC("Epic", Color.rgb(155, 89, 182), 0.17f, 1.85f, 5),
    LEGENDARY("Legendary", Color.rgb(241, 196, 15), 0.12f, 2.2f, 1)
}

/**
 * The 5 original fish species in The City: Island Fishing.
 */
enum class FishSpecies(
    val speciesName: String,
    val rarity: FishRarity,
    val minWeightKg: Float,
    val maxWeightKg: Float,
    val baseValue: Int,
    val primaryColor: Int,
    val secondaryColor: Int,
    val description: String,
    val iconEmoji: String
) {
    CORAL_SARDINE(
        speciesName = "Coral Sardine",
        rarity = FishRarity.COMMON,
        minWeightKg = 0.5f,
        maxWeightKg = 1.6f,
        baseValue = 12,
        primaryColor = Color.rgb(195, 205, 215),
        secondaryColor = Color.rgb(255, 145, 90),
        description = "A nimble silver fish that dart along shallow coastal reefs.",
        iconEmoji = "🐟"
    ),
    STRIPED_SUNFISH(
        speciesName = "Striped Sunfish",
        rarity = FishRarity.UNCOMMON,
        minWeightKg = 1.8f,
        maxWeightKg = 4.5f,
        baseValue = 28,
        primaryColor = Color.rgb(255, 215, 65),
        secondaryColor = Color.rgb(40, 180, 160),
        description = "A radiant lagoon fish with gleaming turquoise stripes.",
        iconEmoji = "🐠"
    ),
    AZURE_REEF_SNAPPER(
        speciesName = "Azure Reef Snapper",
        rarity = FishRarity.RARE,
        minWeightKg = 4.0f,
        maxWeightKg = 9.5f,
        baseValue = 65,
        primaryColor = Color.rgb(35, 110, 230),
        secondaryColor = Color.rgb(130, 220, 255),
        description = "A strong deep-reef hunter with shimmering sapphire scales.",
        iconEmoji = "🐡"
    ),
    GOLDEN_TIDE_MACKEREL(
        speciesName = "Golden Tide Mackerel",
        rarity = FishRarity.EPIC,
        minWeightKg = 8.5f,
        maxWeightKg = 18.5f,
        baseValue = 160,
        primaryColor = Color.rgb(235, 175, 35),
        secondaryColor = Color.rgb(255, 240, 150),
        description = "A swift pelagic swimmer with lustrous gold-plated scales.",
        iconEmoji = "🦈"
    ),
    LUMINOUS_MOONFIN(
        speciesName = "Luminous Moonfin",
        rarity = FishRarity.LEGENDARY,
        minWeightKg = 16.0f,
        maxWeightKg = 36.0f,
        baseValue = 420,
        primaryColor = Color.rgb(180, 100, 255),
        secondaryColor = Color.rgb(100, 240, 255),
        description = "A mythical deep-ocean fish that radiates a mesmerizing lunar glow.",
        iconEmoji = "✨"
    );

    companion object {
        fun rollRandomFish(rarityBonus: Float = 1.0f): FishSpecies {
            // Apply rod rarity bonus to weight calculations
            val weights = values().map { species ->
                val bonus = if (species.rarity != FishRarity.COMMON) rarityBonus else 1.0f
                (species.rarity.chanceWeight * bonus).toInt().coerceAtLeast(1)
            }
            val totalWeight = weights.sum()
            var roll = (1..totalWeight).random()
            for (i in values().indices) {
                roll -= weights[i]
                if (roll <= 0) return values()[i]
            }
            return CORAL_SARDINE
        }
    }
}
