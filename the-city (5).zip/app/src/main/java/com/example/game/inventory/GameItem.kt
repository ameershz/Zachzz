package com.example.game.inventory

/**
 * Definition of an in-game inventory item.
 */
data class GameItem(
    val id: String,
    val name: String,
    val description: String,
    val price: Int,
    val iconEmoji: String,
    val category: String = "Supplies"
) {
    companion object {
        val FOOD = GameItem(
            id = "item_food",
            name = "Fresh Food",
            description = "Wholesome groceries to keep your traveler nourished and healthy.",
            price = 10,
            iconEmoji = "🍞",
            category = "Groceries"
        )

        val HOT_MEAL = GameItem(
            id = "item_meal",
            name = "Golden Diner Special",
            description = "A sizzling burger combo with crispy fries, fresh from the grill.",
            price = 15,
            iconEmoji = "🍔",
            category = "Restaurant"
        )

        val TOOL_KIT = GameItem(
            id = "item_tools",
            name = "Mechanic Wrench Kit",
            description = "Heavy-duty toolkit for tinkering, repairing, and city building.",
            price = 25,
            iconEmoji = "🔧",
            category = "Workshop"
        )

        val ENERGY_SODA = GameItem(
            id = "item_soda",
            name = "Speedy Turbo Cola",
            description = "An ice-cold sparkling beverage packed with invigorating flavor.",
            price = 5,
            iconEmoji = "🥤",
            category = "Gas Station"
        )
    }
}
