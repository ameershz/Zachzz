package com.example.game.input

import android.view.MotionEvent

/**
 * Dispatches multi-touch pointer events to the virtual joystick, action button,
 * and overlay modals.
 */
class TouchController(
    val joystick: VirtualJoystick,
    val actionButton: ActionButton
) {
    var onActionClicked: (() -> Unit)? = null
    var onScreenTapped: ((Float, Float) -> Boolean)? = null

    fun handleTouchEvent(event: MotionEvent, screenWidth: Float, screenHeight: Float): Boolean {
        val actionMasked = event.actionMasked
        val pointerIndex = event.actionIndex
        val pointerId = event.getPointerId(pointerIndex)
        val touchX = event.getX(pointerIndex)
        val touchY = event.getY(pointerIndex)

        when (actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                // If modal intercept handler returns true, absorb the event
                if (onScreenTapped?.invoke(touchX, touchY) == true) {
                    return true
                }

                // Check action button first (if visible)
                if (actionButton.isVisible && actionButton.onTouchDown(pointerId, touchX, touchY)) {
                    return true
                }

                // If touch is on the left half or lower 70% of screen, allocate to joystick
                if (touchX < screenWidth * 0.65f && touchY > screenHeight * 0.3f) {
                    if (!joystick.isDragging) {
                        joystick.onTouchDown(pointerId, touchX, touchY)
                        return true
                    }
                }
            }

            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val pId = event.getPointerId(i)
                    val pX = event.getX(i)
                    val pY = event.getY(i)

                    if (pId == joystick.activePointerId) {
                        joystick.onTouchMove(pId, pX, pY)
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                if (pointerId == joystick.activePointerId) {
                    joystick.onTouchUp(pointerId)
                }
                if (pointerId == actionButton.activePointerId) {
                    val triggered = actionButton.onTouchUp(pointerId, touchX, touchY)
                    if (triggered) {
                        onActionClicked?.invoke()
                    }
                }
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                joystick.reset()
                actionButton.cancelTouch()
                return true
            }
        }
        return true
    }
}
