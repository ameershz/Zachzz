package com.example.game.camera

import android.graphics.Canvas
import android.graphics.RectF
import com.example.game.physics.RectCollider

/**
 * 2D top-down camera with smooth follow (lerp), zoom scaling, and world boundary clamping.
 */
class Camera2D {
    var x: Float = 0f
    var y: Float = 0f

    var targetX: Float = 0f
    var targetY: Float = 0f

    var viewportWidth: Float = 1080f
    var viewportHeight: Float = 1920f

    // Zoom level: 1.0f means 1 world unit = 1 pixel. ~1.3f is great for mobile screens.
    var zoom: Float = 1.35f

    // Follow smoothing factor (0 = stationary, 1 = instant snap)
    var followSpeed: Float = 8f // lerp rate per second

    private var worldBounds: RectCollider = RectCollider(0f, 0f, 2400f, 2400f)

    fun setWorldBounds(bounds: RectCollider) {
        worldBounds = bounds
    }

    fun resize(width: Float, height: Float) {
        viewportWidth = width
        viewportHeight = height
        // Adjust zoom slightly based on screen density/width so game world scales nicely on all phones
        val minDim = minOf(width, height)
        zoom = (minDim / 480f).coerceIn(1.1f, 1.8f)
    }

    fun setTarget(tx: Float, ty: Float, instant: Boolean = false) {
        targetX = tx
        targetY = ty
        if (instant) {
            x = targetX
            y = targetY
            clampPosition()
        }
    }

    fun update(deltaTime: Float) {
        // Smooth lerp towards target
        val t = (followSpeed * deltaTime).coerceIn(0f, 1f)
        x += (targetX - x) * t
        y += (targetY - y) * t

        clampPosition()
    }

    private fun clampPosition() {
        val halfViewWorldW = (viewportWidth / (2f * zoom))
        val halfViewWorldH = (viewportHeight / (2f * zoom))

        val minCamX = worldBounds.left + halfViewWorldW
        val maxCamX = worldBounds.right - halfViewWorldW
        val minCamY = worldBounds.top + halfViewWorldH
        val maxCamY = worldBounds.bottom - halfViewWorldH

        if (minCamX <= maxCamX) {
            x = x.coerceIn(minCamX, maxCamX)
        } else {
            x = worldBounds.centerX
        }

        if (minCamY <= maxCamY) {
            y = y.coerceIn(minCamY, maxCamY)
        } else {
            y = worldBounds.centerY
        }
    }

    fun worldToScreenX(worldX: Float): Float {
        return (worldX - x) * zoom + (viewportWidth * 0.5f)
    }

    fun worldToScreenY(worldY: Float): Float {
        return (worldY - y) * zoom + (viewportHeight * 0.5f)
    }

    fun screenToWorldX(screenX: Float): Float {
        return (screenX - viewportWidth * 0.5f) / zoom + x
    }

    fun screenToWorldY(screenY: Float): Float {
        return (screenY - viewportHeight * 0.5f) / zoom + y
    }

    fun getVisibleWorldBounds(): RectF {
        val left = screenToWorldX(0f)
        val top = screenToWorldY(0f)
        val right = screenToWorldX(viewportWidth)
        val bottom = screenToWorldY(viewportHeight)
        return RectF(left, top, right, bottom)
    }

    fun isWorldRectVisible(left: Float, top: Float, right: Float, bottom: Float, margin: Float = 100f): Boolean {
        val visible = getVisibleWorldBounds()
        return right >= visible.left - margin && left <= visible.right + margin &&
                bottom >= visible.top - margin && top <= visible.bottom + margin
    }

    /**
     * Applies camera transformation to the Canvas before drawing world entities.
     * Must be paired with canvas.restore() after world rendering.
     */
    fun applyTransform(canvas: Canvas) {
        canvas.save()
        canvas.translate(viewportWidth * 0.5f, viewportHeight * 0.5f)
        canvas.scale(zoom, zoom)
        canvas.translate(-x, -y)
    }
}
