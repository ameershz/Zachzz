package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.economy.EconomyManager
import com.example.game.fishing.FishingRod
import com.example.game.fishing.FishingState
import com.example.game.interaction.Interactable
import com.example.game.inventory.FishInventory
import kotlin.math.sin

/**
 * Modern stylized nautical HUD for mobile.
 * Features embossed coin counters, rod emblem badge, interactive creel basket button,
 * and clean situational alerts.
 */
class InGameHud(
    val economyManager: EconomyManager,
    val fishInventory: FishInventory
) {
    var currentLocationName: String = "Tropical Island"
    var activeInteractable: Interactable? = null
    var equippedRod: FishingRod = FishingRod.WOODEN_ROD
    var fishingState: FishingState = FishingState.FREE_ROAM

    var onInventoryClicked: (() -> Unit)? = null

    val fishBagRect = RectF()
    private var promptPulseTimer: Float = 0f

    // Paints
    private val chipBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(215, 14, 24, 38)
        style = Paint.Style.FILL
    }

    private val chipBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val goldCoinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 215, 55)
        style = Paint.Style.FILL
    }

    private val goldCoinRimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(205, 155, 30)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private val moneyTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 235, 115)
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val rodTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 14.5f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val inventoryTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(220, 245, 255)
        textAlign = Paint.Align.RIGHT
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val locationTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(190, 215, 235, 255)
        textSize = 12.5f
    }

    private val promptBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(225, 16, 28, 44)
        style = Paint.Style.FILL
    }

    private val promptBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val promptTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 15.5f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun update(deltaTime: Float) {
        promptPulseTimer += deltaTime * 5f
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (fishBagRect.contains(touchX, touchY)) {
            onInventoryClicked?.invoke()
            return true
        }
        return false
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float, safeTopInset: Float = 48f) {
        val topY = safeTopInset + 18f
        val pillH = 38f

        // 1. Top-Left: Gold Coin Counter Chip
        val moneyStr = economyManager.formattedBalance()
        val moneyPillW = 125f
        val moneyRect = RectF(18f, topY, 18f + moneyPillW, topY + pillH)
        canvas.drawRoundRect(moneyRect, 19f, 19f, chipBgPaint)
        canvas.drawRoundRect(moneyRect, 19f, 19f, chipBorderPaint)

        // Embossed gold coin emblem
        val coinX = moneyRect.left + 20f
        val coinY = moneyRect.centerY()
        canvas.drawCircle(coinX, coinY, 9.5f, goldCoinPaint)
        canvas.drawCircle(coinX, coinY, 9.5f, goldCoinRimPaint)
        canvas.drawText(moneyStr, coinX + 16f, coinY + moneyTextPaint.textSize * 0.35f, moneyTextPaint)

        // 2. Top-Center: Equipped Rod Badge Chip
        val rodStr = "🎣 ${equippedRod.name}"
        val rodTextW = rodTextPaint.measureText(rodStr)
        val rodPillW = (rodTextW + 36f).coerceIn(160f, 260f)
        val rodLeft = (screenW - rodPillW) * 0.5f
        val rodRect = RectF(rodLeft, topY, rodLeft + rodPillW, topY + pillH)
        canvas.drawRoundRect(rodRect, 19f, 19f, chipBgPaint)

        val rodBorderPaint = Paint(chipBorderPaint).apply {
            color = equippedRod.rodColor
            alpha = 180
            strokeWidth = 2.5f
        }
        canvas.drawRoundRect(rodRect, 19f, 19f, rodBorderPaint)
        canvas.drawText(rodStr, screenW * 0.5f, rodRect.centerY() + rodTextPaint.textSize * 0.35f, rodTextPaint)

        // 3. Top-Right: Fish Creel Button Chip (Interactive!)
        val isFull = fishInventory.isFull
        val bagStr = "🎒 ${fishInventory.count}/${fishInventory.capacity}"
        val bagTextW = inventoryTextPaint.measureText(bagStr)
        val bagPillW = bagTextW + 34f
        val bagRight = screenW - 18f
        fishBagRect.set(bagRight - bagPillW, topY, bagRight, topY + pillH)

        val bagBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isFull) Color.argb(230, 215, 60, 50) else Color.argb(215, 14, 24, 38)
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(fishBagRect, 19f, 19f, bagBgPaint)
        canvas.drawRoundRect(fishBagRect, 19f, 19f, chipBorderPaint)
        canvas.drawText(bagStr, bagRight - 15f, fishBagRect.centerY() + inventoryTextPaint.textSize * 0.35f, inventoryTextPaint)

        // 4. Subtle Location Tag beneath Top-Left
        canvas.drawText("📍 $currentLocationName", 22f, topY + pillH + 18f, locationTextPaint)

        // 5. Context-Sensitive Alert Banner
        val promptStr = when (fishingState) {
            FishingState.CASTING -> "🎣 Casting into deep water..."
            FishingState.WAITING_FOR_BITE -> "🌊 Line floating... Watching the bobber"
            FishingState.BITE -> "⚡ BITE! TAP HOOK NOW! ⚡"
            FishingState.CATCHING -> "🎯 REEL! Keep timing in the sweet spot!"
            else -> {
                activeInteractable?.let { "Near ${it.name} • Tap ${it.actionLabel}" }
            }
        }

        if (promptStr != null) {
            val promptW = promptTextPaint.measureText(promptStr) + 40f
            val promptH = 38f
            val promptY = screenH - 180f
            val promptLeft = (screenW - promptW) * 0.5f
            val promptRect = RectF(promptLeft, promptY, promptLeft + promptW, promptY + promptH)

            canvas.drawRoundRect(promptRect, 19f, 19f, promptBgPaint)

            val isEmergency = fishingState == FishingState.BITE
            promptBorderPaint.color = if (isEmergency) Color.rgb(241, 196, 15) else Color.rgb(46, 204, 113)
            val pulseAlpha = (140 + sin(promptPulseTimer * if (isEmergency) 2f else 1f) * 90).toInt().coerceIn(60, 255)
            promptBorderPaint.alpha = pulseAlpha
            canvas.drawRoundRect(promptRect, 19f, 19f, promptBorderPaint)

            promptTextPaint.color = if (isEmergency) Color.rgb(255, 235, 120) else Color.WHITE
            canvas.drawText(promptStr, screenW * 0.5f, promptRect.centerY() + promptTextPaint.textSize * 0.35f, promptTextPaint)
        }
    }
}
