package com.example.game.art

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.example.game.fishing.FishRarity
import kotlin.math.cos
import kotlin.math.sin

data class WaterSplashParticle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var radius: Float,
    var life: Float,
    var maxLife: Float,
    var color: Int
)

data class CelebrationStar(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    var life: Float,
    var maxLife: Float,
    var color: Int
)

/**
 * Visual effects system managing water splashes, bobber ripples,
 * bite bursts, and celebration particle fireworks.
 */
class VfxManager {
    private val splashes = mutableListOf<WaterSplashParticle>()
    private val celebrationStars = mutableListOf<CelebrationStar>()

    private val splashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun spawnWaterSplash(x: Float, y: Float, count: Int = 14, intensity: Float = 1.0f) {
        for (i in 0 until count) {
            val angle = (Math.random() * Math.PI * 2).toFloat()
            val speed = (40f + Math.random().toFloat() * 90f) * intensity
            val maxLife = 0.4f + Math.random().toFloat() * 0.4f
            val radius = (3.5f + Math.random().toFloat() * 4.5f) * intensity

            val c = if (Math.random() > 0.4) Color.WHITE else Color.rgb(180, 240, 255)

            splashes.add(
                WaterSplashParticle(
                    x = x,
                    y = y,
                    vx = cos(angle.toDouble()).toFloat() * speed,
                    vy = sin(angle.toDouble()).toFloat() * speed - 25f * intensity,
                    radius = radius,
                    life = maxLife,
                    maxLife = maxLife,
                    color = c
                )
            )
        }
    }

    fun spawnCelebrationBurst(x: Float, y: Float, rarity: FishRarity) {
        val count = when (rarity) {
            FishRarity.COMMON -> 10
            FishRarity.UNCOMMON -> 18
            FishRarity.RARE -> 28
            FishRarity.EPIC -> 45
            FishRarity.LEGENDARY -> 70
        }

        for (i in 0 until count) {
            val angle = (Math.random() * Math.PI * 2).toFloat()
            val speed = (60f + Math.random().toFloat() * 160f)
            val maxLife = 0.8f + Math.random().toFloat() * 0.9f
            val size = 4f + Math.random().toFloat() * 6f

            celebrationStars.add(
                CelebrationStar(
                    x = x,
                    y = y,
                    vx = cos(angle.toDouble()).toFloat() * speed,
                    vy = sin(angle.toDouble()).toFloat() * speed,
                    size = size,
                    life = maxLife,
                    maxLife = maxLife,
                    color = if (rarity == FishRarity.LEGENDARY && i % 2 == 0) Color.rgb(100, 240, 255) else rarity.color
                )
            )
        }
    }

    fun update(deltaTime: Float) {
        // Update water splashes
        val splashIter = splashes.iterator()
        while (splashIter.hasNext()) {
            val p = splashIter.next()
            p.life -= deltaTime
            p.x += p.vx * deltaTime
            p.y += p.vy * deltaTime
            p.vy += 120f * deltaTime // Gravity
            p.radius = (p.radius - deltaTime * 1.5f).coerceAtLeast(0.5f)
            if (p.life <= 0f) splashIter.remove()
        }

        // Update celebration stars
        val starIter = celebrationStars.iterator()
        while (starIter.hasNext()) {
            val s = starIter.next()
            s.life -= deltaTime
            s.x += s.vx * deltaTime
            s.y += s.vy * deltaTime
            s.vx *= 0.96f
            s.vy *= 0.96f
            if (s.life <= 0f) starIter.remove()
        }
    }

    fun renderWorldVfx(canvas: Canvas) {
        for (p in splashes) {
            val alpha = ((p.life / p.maxLife) * 220).toInt().coerceIn(0, 255)
            splashPaint.color = p.color
            splashPaint.alpha = alpha
            canvas.drawCircle(p.x, p.y, p.radius, splashPaint)
        }
    }

    fun renderScreenVfx(canvas: Canvas) {
        for (s in celebrationStars) {
            val alpha = ((s.life / s.maxLife) * 255).toInt().coerceIn(0, 255)
            starPaint.color = s.color
            starPaint.alpha = alpha

            // Draw diamond star
            val r = s.size
            canvas.drawCircle(s.x, s.y, r * 0.6f, starPaint)
            canvas.drawLine(s.x - r, s.y, s.x + r, s.y, starPaint)
            canvas.drawLine(s.x, s.y - r, s.x, s.y + r, starPaint)
        }
    }
}
