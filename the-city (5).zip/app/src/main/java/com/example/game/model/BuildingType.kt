package com.example.game.model

enum class BuildingType {
    FISH_SHOP,
    ROD_SHOP,
    PLAYER_HOME,
    FISHING_PIER,
    BOAT_DOCK,
    DECORATIVE_HUT
}
