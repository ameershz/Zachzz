package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.economy.EconomyManager
import com.example.game.inventory.GameItem
import com.example.game.inventory.Inventory

/**
 * In-game shop overlay panel rendered directly on the Canvas.
 * Provides buying functionality, balance feedback, and inventory status.
 */
class InGameShopModal(
    val economyManager: EconomyManager,
    val inventory: Inventory,
    var onBuySuccess: ((GameItem) -> Unit)? = null,
    var onClose: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set

    var currentShopTitle: String = "Fresh Market"
    var currentItem: GameItem = GameItem.FOOD
    var greetingText: String = "Welcome! Fresh provisions for city travelers."

    // Modal layout bounds
    private var modalRect = RectF()
    private var buyBtnRect = RectF()
    private var closeBtnRect = RectF()

    private var isBuyPressed = false
    private var isClosePressed = false

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(165, 10, 15, 25)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(24, 32, 48) // Dark sleek navy
        style = Paint.Style.FILL
    }

    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(235, 185, 65) // Golden border trim
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(35, 45, 68)
        style = Paint.Style.FILL
    }

    private val itemBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(18, 24, 36)
        style = Paint.Style.FILL
    }

    private val titleTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 24f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val greetingTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(190, 205, 225)
        textAlign = Paint.Align.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT
    }

    private val itemNamePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 225, 120)
        textAlign = Paint.Align.LEFT
        textSize = 20f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val itemDescPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 195, 210)
        textAlign = Paint.Align.LEFT
        textSize = 14f
    }

    private val itemPricePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(90, 225, 140) // Fresh green price
        textAlign = Paint.Align.LEFT
        textSize = 22f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val inventoryCountPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 200, 240)
        textAlign = Paint.Align.RIGHT
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val buyBtnActivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(42, 175, 95) // Vibrant green
        style = Paint.Style.FILL
    }

    private val buyBtnDisabledPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(65, 75, 88) // Dim grey
        style = Paint.Style.FILL
    }

    private val buyBtnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 18f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val closeBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(215, 60, 50)
        style = Paint.Style.FILL
    }

    private val walletTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 215, 75)
        textAlign = Paint.Align.LEFT
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun open(title: String, item: GameItem, greeting: String) {
        currentShopTitle = title
        currentItem = item
        greetingText = greeting
        isOpen = true
        isBuyPressed = false
        isClosePressed = false
    }

    fun close() {
        isOpen = false
        isBuyPressed = false
        isClosePressed = false
        onClose?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false

        // Tap Buy button
        if (buyBtnRect.contains(touchX, touchY)) {
            if (economyManager.canAfford(currentItem.price)) {
                if (economyManager.spend(currentItem.price)) {
                    inventory.addItem(currentItem, 1)
                    onBuySuccess?.invoke(currentItem)
                }
            }
            return true
        }

        // Tap Close button
        if (closeBtnRect.contains(touchX, touchY)) {
            close()
            return true
        }

        // Tap outside card dismisses modal
        if (!modalRect.contains(touchX, touchY)) {
            close()
            return true
        }

        // Absorb touch inside card
        return true
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        if (!isOpen) return

        // 1. Dim background
        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        // 2. Center card dimensions
        val cardW = (screenW * 0.88f).coerceIn(320f, 440f)
        val cardH = 340f
        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        // Card base & border
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBorderPaint)

        // Header ribbon
        val headerH = 56f
        val headerRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + headerH)
        canvas.drawRoundRect(headerRect, 18f, 18f, headerPaint)
        // Square off bottom of header
        canvas.drawRect(cardLeft, cardTop + headerH - 12f, cardLeft + cardW, cardTop + headerH, headerPaint)

        // Title text
        val titleY = cardTop + headerH * 0.5f + titleTextPaint.textSize * 0.35f
        canvas.drawText(currentShopTitle, screenW * 0.5f, titleY, titleTextPaint)

        // Greeting dialogue text
        val greetingY = cardTop + headerH + 24f
        canvas.drawText(greetingText, screenW * 0.5f, greetingY, greetingTextPaint)

        // 3. Featured Item Box
        val boxMargin = 16f
        val boxTop = greetingY + 16f
        val boxH = 140f
        val boxRect = RectF(cardLeft + boxMargin, boxTop, cardLeft + cardW - boxMargin, boxTop + boxH)
        canvas.drawRoundRect(boxRect, 12f, 12f, itemBoxPaint)

        // Item icon badge
        val iconBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(38, 52, 75)
            style = Paint.Style.FILL
        }
        val iconRect = RectF(boxRect.left + 14f, boxTop + 16f, boxRect.left + 64f, boxTop + 66f)
        canvas.drawRoundRect(iconRect, 8f, 8f, iconBadgePaint)

        // Icon text / emoji
        val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            textSize = 28f
        }
        canvas.drawText(currentItem.iconEmoji, iconRect.centerX(), iconRect.centerY() + 10f, emojiPaint)

        // Item details
        val textLeft = boxRect.left + 76f
        canvas.drawText(currentItem.name, textLeft, boxTop + 32f, itemNamePaint)

        // Truncate or fit item description
        canvas.drawText(currentItem.description.take(38) + "...", textLeft, boxTop + 54f, itemDescPaint)

        // Item price
        canvas.drawText("Price: $${currentItem.price}", textLeft, boxTop + 88f, itemPricePaint)

        // Current Inventory Count
        val ownedCount = inventory.getCount(currentItem)
        canvas.drawText("In Bag: $ownedCount", boxRect.right - 14f, boxTop + 88f, inventoryCountPaint)

        // Buy button inside item box
        val canAfford = economyManager.canAfford(currentItem.price)
        val btnW = 120f
        val btnH = 36f
        buyBtnRect.set(boxRect.right - btnW - 14f, boxTop + 96f, boxRect.right - 14f, boxTop + 96f + btnH)

        canvas.drawRoundRect(buyBtnRect, 8f, 8f, if (canAfford) buyBtnActivePaint else buyBtnDisabledPaint)
        val buyTextY = buyBtnRect.centerY() + buyBtnTextPaint.textSize * 0.35f
        val buyLabel = if (canAfford) "BUY $${currentItem.price}" else "TOO EXPENSIVE"
        buyBtnTextPaint.textSize = if (canAfford) 15f else 11f
        canvas.drawText(buyLabel, buyBtnRect.centerX(), buyTextY, buyBtnTextPaint)

        // 4. Bottom Footer (Player Wallet + Close Button)
        val footerY = boxRect.bottom + 32f
        canvas.drawText("🪙 Wallet: " + economyManager.formattedBalance(), cardLeft + boxMargin + 6f, footerY, walletTextPaint)

        // Close button
        val closeBtnW = 90f
        val closeBtnH = 34f
        closeBtnRect.set(cardLeft + cardW - boxMargin - closeBtnW, footerY - 22f, cardLeft + cardW - boxMargin, footerY + 12f)
        canvas.drawRoundRect(closeBtnRect, 8f, 8f, closeBtnPaint)
        canvas.drawText("CLOSE", closeBtnRect.centerX(), closeBtnRect.centerY() + 6f, buyBtnTextPaint)
    }
}
