package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.example.game.art.OceanRenderer
import com.example.game.physics.CollisionSystem
import com.example.game.physics.RectCollider
import kotlin.math.sin

/**
 * Tropical island fishing environment with stylized multi-layer ocean,
 * textured golden beaches, lush village pathways, swaying palms, and docks.
 */
class World(val collisionSystem: CollisionSystem) {
    val width: Float = 2000f
    val height: Float = 2000f

    val oceanRenderer = OceanRenderer(width, height)

    val buildings = mutableListOf<Building>()
    val palmTrees = mutableListOf<PalmTree>()
    val rocks = mutableListOf<BeachRock>()
    val shells = mutableListOf<BeachShell>()
    val lanterns = mutableListOf<NauticalLantern>()
    val docks = mutableListOf<WoodenFishingDock>()
    var mooredBoat: MooredBoat? = null

    // Player spawn: island village center path
    val spawnX: Float = 980f
    val spawnY: Float = 860f

    // Main fishing pier reference
    lateinit var mainFishingDock: WoodenFishingDock

    // Island landmass bounds
    val beachRect = RectF(460f, 460f, 1540f, 1540f)
    val grassRect = RectF(560f, 560f, 1440f, 1440f)

    // Paints
    private val beachSandBase = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(240, 202, 130) // Warm tropical golden sand
        style = Paint.Style.FILL
    }

    private val beachWetSand = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(218, 178, 108) // Wet tide sand near water
        style = Paint.Style.STROKE
        strokeWidth = 14f
    }

    private val islandGrassBase = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(58, 165, 88) // Vibrant lush tropical grass
        style = Paint.Style.FILL
    }

    private val pathStoneBase = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(212, 192, 158) // Sandy gravel path
        style = Paint.Style.FILL
    }

    private val pathBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 120, 95, 60)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    init {
        setupDocks()
        setupBuildings()
        setupProps()
        registerAllColliders()
    }

    private fun setupDocks() {
        mainFishingDock = WoodenFishingDock(
            left = 940f,
            top = 220f,
            width = 80f,
            height = 360f,
            castingSpotX = 980f,
            castingSpotY = 270f,
            waterTargetX = 980f,
            waterTargetY = 140f,
            dockName = "North Ocean Pier"
        )
        docks.add(mainFishingDock)

        val boatPier = WoodenFishingDock(
            left = 940f,
            top = 1420f,
            width = 80f,
            height = 300f,
            castingSpotX = 980f,
            castingSpotY = 1680f,
            waterTargetX = 980f,
            waterTargetY = 1780f,
            dockName = "Marina Boat Pier"
        )
        docks.add(boatPier)

        mooredBoat = MooredBoat(1060f, 1640f)
    }

    private fun setupBuildings() {
        // 1. Pelican Fishmonger (Fish Shop)
        buildings.add(
            Building(
                id = "building_fish_shop",
                name = "Pelican Fishmonger",
                type = BuildingType.FISH_SHOP,
                left = 680f,
                top = 660f,
                width = 190f,
                height = 135f,
                entranceX = 775f,
                entranceY = 795f,
                wallColor = Color.rgb(230, 240, 248),
                roofColor = Color.rgb(32, 118, 180),
                trimColor = Color.rgb(20, 68, 110),
                signText = "PELICAN FISH",
                signBgColor = Color.rgb(28, 92, 148),
                hasAwning = true,
                awningColor1 = Color.WHITE,
                awningColor2 = Color.rgb(38, 140, 205),
                interactionLabel = "SELL FISH",
                interactionSubLabel = "Trade catches for gold"
            )
        )

        // 2. Harbor Tackle & Rods (Rod Upgrade Shop)
        buildings.add(
            Building(
                id = "building_rod_shop",
                name = "Harbor Tackle & Rods",
                type = BuildingType.ROD_SHOP,
                left = 1130f,
                top = 660f,
                width = 190f,
                height = 135f,
                entranceX = 1225f,
                entranceY = 795f,
                wallColor = Color.rgb(188, 142, 98),
                roofColor = Color.rgb(205, 90, 48),
                trimColor = Color.rgb(95, 58, 32),
                signText = "TACKLE & RODS",
                signBgColor = Color.rgb(148, 68, 32),
                interactionLabel = "ROD SHOP",
                interactionSubLabel = "Upgrade fishing rods"
            )
        )

        // 3. Harbor Rest (Player Cottage)
        buildings.add(
            Building(
                id = "building_home",
                name = "Fisherman Cottage",
                type = BuildingType.PLAYER_HOME,
                left = 700f,
                top = 1100f,
                width = 170f,
                height = 130f,
                entranceX = 785f,
                entranceY = 1230f,
                wallColor = Color.rgb(238, 224, 198),
                roofColor = Color.rgb(150, 118, 78),
                trimColor = Color.rgb(85, 58, 36),
                signText = "HARBOR REST",
                signBgColor = Color.rgb(108, 82, 52),
                interactionLabel = "REST",
                interactionSubLabel = "Island home"
            )
        )

        // 4. Marina Harbor House
        buildings.add(
            Building(
                id = "building_marina_hut",
                name = "Boat Master Hut",
                type = BuildingType.DECORATIVE_HUT,
                left = 1140f,
                top = 1100f,
                width = 170f,
                height = 130f,
                entranceX = 1225f,
                entranceY = 1230f,
                wallColor = Color.rgb(218, 228, 238),
                roofColor = Color.rgb(44, 128, 108),
                trimColor = Color.rgb(32, 88, 72),
                signText = "EXPEDITIONS",
                signBgColor = Color.rgb(36, 98, 82),
                interactionLabel = "INSPECT",
                interactionSubLabel = "Future Boat Expeditions"
            )
        )
    }

    private fun setupProps() {
        val palmCoords = listOf(
            Pair(520f, 540f), Pair(620f, 490f), Pair(1380f, 490f), Pair(1480f, 540f),
            Pair(490f, 850f), Pair(490f, 1150f), Pair(520f, 1420f),
            Pair(1510f, 850f), Pair(1510f, 1150f), Pair(1480f, 1420f),
            Pair(680f, 1480f), Pair(1320f, 1480f),
            Pair(980f, 1040f), Pair(880f, 920f), Pair(1080f, 920f)
        )
        for ((px, py) in palmCoords) {
            palmTrees.add(PalmTree(px, py, size = 42f + (sin(px.toDouble() + py.toDouble()) * 4f).toFloat()))
        }

        val rockCoords = listOf(
            Pair(440f, 720f), Pair(440f, 1280f), Pair(1560f, 720f), Pair(1560f, 1280f),
            Pair(860f, 440f), Pair(1140f, 440f), Pair(860f, 1560f), Pair(1140f, 1560f)
        )
        for ((rx, ry) in rockCoords) {
            rocks.add(BeachRock(rx, ry, radius = 22f + (sin(rx.toDouble()) * 4f).toFloat()))
        }

        // Beach seashells & starfish
        val shellCoords = listOf(
            Triple(480f, 620f, false), Triple(500f, 780f, true), Triple(475f, 960f, false),
            Triple(510f, 1340f, false), Triple(720f, 1520f, true), Triple(840f, 1540f, false),
            Triple(1160f, 1530f, true), Triple(1420f, 1500f, false), Triple(1520f, 1020f, false),
            Triple(1530f, 640f, true), Triple(1360f, 470f, false), Triple(640f, 470f, true)
        )
        for ((sx, sy, isStar) in shellCoords) {
            shells.add(BeachShell(sx, sy, isStar))
        }

        lanterns.add(NauticalLantern(920f, 570f))
        lanterns.add(NauticalLantern(1040f, 570f))
        lanterns.add(NauticalLantern(920f, 240f))
        lanterns.add(NauticalLantern(1040f, 240f))
        lanterns.add(NauticalLantern(890f, 790f))
        lanterns.add(NauticalLantern(1110f, 790f))
        lanterns.add(NauticalLantern(920f, 1430f))
        lanterns.add(NauticalLantern(1040f, 1430f))
    }

    private fun registerAllColliders() {
        collisionSystem.clear()

        collisionSystem.addCollider(RectCollider(0f, 0f, 440f, height, tag = "water_west"))
        collisionSystem.addCollider(RectCollider(1560f, 0f, width, height, tag = "water_east"))
        collisionSystem.addCollider(RectCollider(440f, 0f, 930f, 440f, tag = "water_north_left"))
        collisionSystem.addCollider(RectCollider(1030f, 0f, 1560f, 440f, tag = "water_north_right"))
        collisionSystem.addCollider(RectCollider(440f, 1560f, 930f, height, tag = "water_south_left"))
        collisionSystem.addCollider(RectCollider(1030f, 1560f, 1560f, height, tag = "water_south_right"))

        collisionSystem.addCollider(RectCollider(440f, 200f, 930f, 440f, tag = "pier_water_w"))
        collisionSystem.addCollider(RectCollider(1030f, 200f, 1560f, 440f, tag = "pier_water_e"))
        collisionSystem.addCollider(RectCollider(900f, 0f, 1100f, 210f, tag = "pier_head_water"))

        collisionSystem.addCollider(RectCollider(900f, 1730f, 1100f, height, tag = "boat_pier_head"))

        for (b in buildings) collisionSystem.addCollider(b.collider)
        for (p in palmTrees) collisionSystem.addCollider(p.collider)
        for (r in rocks) collisionSystem.addCollider(r.collider)
        for (l in lanterns) collisionSystem.addCollider(l.collider)
        mooredBoat?.let { collisionSystem.addCollider(it.collider) }
    }

    fun update(deltaTime: Float) {
        oceanRenderer.update(deltaTime)
        mooredBoat?.update(deltaTime)
        for (p in palmTrees) p.update(deltaTime)
    }

    fun render(canvas: Canvas) {
        // 1. Dynamic Ocean System
        oceanRenderer.renderOcean(canvas, beachRect)

        // 2. Sandy Beach Landmass
        canvas.drawRoundRect(beachRect, 140f, 140f, beachSandBase)
        canvas.drawRoundRect(beachRect, 140f, 140f, beachWetSand)

        // 3. Seashells & Starfish scattered on beach
        for (s in shells) s.render(canvas)

        // 4. Lush Village Grass Interior
        canvas.drawRoundRect(grassRect, 90f, 90f, islandGrassBase)

        // 5. Village Boardwalk Pathways
        val pathH = RectF(660f, 830f, 1340f, 890f)
        val pathV = RectF(950f, 560f, 1010f, 1440f)
        canvas.drawRoundRect(pathH, 12f, 12f, pathStoneBase)
        canvas.drawRoundRect(pathH, 12f, 12f, pathBorder)
        canvas.drawRoundRect(pathV, 12f, 12f, pathStoneBase)
        canvas.drawRoundRect(pathV, 12f, 12f, pathBorder)

        // 6. Docks
        for (d in docks) d.render(canvas)

        // 7. Moored Boat
        mooredBoat?.render(canvas)

        // 8. Beach Rocks
        for (r in rocks) r.render(canvas)

        // 9. Buildings
        for (b in buildings) b.render(canvas)

        // 10. Nautical Lanterns
        for (l in lanterns) l.render(canvas)

        // 11. Animated Swaying Palm Trees
        for (p in palmTrees) p.render(canvas)
    }

    fun isPlayerNearFishingSpot(px: Float, py: Float): Boolean {
        val dx = px - mainFishingDock.castingSpotX
        val dy = py - mainFishingDock.castingSpotY
        return (dx * dx + dy * dy) <= (75f * 75f)
    }

    fun getLocationName(px: Float, py: Float): String {
        return when {
            px in 900f..1060f && py in 200f..400f -> "North Fishing Pier"
            px in 640f..900f && py in 620f..820f -> "Pelican Fish Shop"
            px in 1100f..1350f && py in 620f..820f -> "Tackle & Rod Shop"
            px in 640f..900f && py in 1060f..1280f -> "Fisherman Cottage"
            px in 900f..1060f && py in 1400f..1760f -> "Marina Boat Dock"
            px in 560f..1440f && py in 560f..1440f -> "Island Village"
            else -> "Tropical Beach"
        }
    }
}
