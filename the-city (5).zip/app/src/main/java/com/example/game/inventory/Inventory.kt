package com.example.game.inventory

/**
 * Manages player inventory item storage and quantity queries.
 */
class Inventory {
    private val items = mutableMapOf<String, Int>()

    var onInventoryChanged: (() -> Unit)? = null

    fun addItem(item: GameItem, count: Int = 1) {
        val current = items.getOrDefault(item.id, 0)
        items[item.id] = current + count
        onInventoryChanged?.invoke()
    }

    fun removeItem(item: GameItem, count: Int = 1): Boolean {
        val current = items.getOrDefault(item.id, 0)
        if (current >= count) {
            val remaining = current - count
            if (remaining <= 0) {
                items.remove(item.id)
            } else {
                items[item.id] = remaining
            }
            onInventoryChanged?.invoke()
            return true
        }
        return false
    }

    fun getCount(item: GameItem): Int {
        return items.getOrDefault(item.id, 0)
    }

    fun getCount(itemId: String): Int {
        return items.getOrDefault(itemId, 0)
    }

    fun getFoodCount(): Int {
        return getCount(GameItem.FOOD)
    }

    fun getTotalItemCount(): Int {
        return items.values.sum()
    }

    fun getAllItems(): Map<String, Int> = items.toMap()
}
