package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF

/**
 * Manages the neighborhood road network, sidewalks, curbs, asphalt surfaces,
 * lane dividers, and pedestrian zebra crosswalks.
 */
class RoadNetwork {

    data class RoadSegment(
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        val isHorizontal: Boolean
    )

    data class Crosswalk(
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        val isHorizontal: Boolean
    )

    val roads = mutableListOf<RoadSegment>()
    val crosswalks = mutableListOf<Crosswalk>()

    // Paints
    private val sidewalkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 188, 198) // Light concrete sidewalk
        style = Paint.Style.FILL
    }

    private val curbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(140, 148, 158) // Darker concrete curb bevel
        style = Paint.Style.FILL
    }

    private val asphaltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(44, 48, 58) // Rich charcoal asphalt
        style = Paint.Style.FILL
    }

    private val yellowDashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(245, 205, 55) // Vibrant yellow center lane dividers
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
        pathEffect = DashPathEffect(floatArrayOf(24f, 20f), 0f)
    }

    private val whiteLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val crosswalkStripePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(240, 245, 255) // Thick white pedestrian zebra stripes
        style = Paint.Style.FILL
    }

    init {
        setupRoads()
    }

    private fun setupRoads() {
        // Main Central Boulevard (Horizontal, Y=1200, width=120f)
        roads.add(RoadSegment(0f, 1140f, 2400f, 1260f, isHorizontal = true))

        // North Connecting Street (Horizontal, Y=580, width=110f)
        roads.add(RoadSegment(200f, 525f, 2200f, 635f, isHorizontal = true))

        // South Connecting Street (Horizontal, Y=1820, width=110f)
        roads.add(RoadSegment(200f, 1765f, 2200f, 1875f, isHorizontal = true))

        // West Avenue (Vertical, X=650, width=120f)
        roads.add(RoadSegment(590f, 200f, 710f, 2200f, isHorizontal = false))

        // East Avenue (Vertical, X=1750, width=120f)
        roads.add(RoadSegment(1690f, 200f, 1810f, 2200f, isHorizontal = false))

        // Crosswalks at intersections
        // Center Boulevard & West Avenue
        crosswalks.add(Crosswalk(520f, 1140f, 570f, 1260f, isHorizontal = false))
        crosswalks.add(Crosswalk(730f, 1140f, 780f, 1260f, isHorizontal = false))
        crosswalks.add(Crosswalk(590f, 1070f, 710f, 1120f, isHorizontal = true))
        crosswalks.add(Crosswalk(590f, 1280f, 710f, 1330f, isHorizontal = true))

        // Center Boulevard & East Avenue
        crosswalks.add(Crosswalk(1620f, 1140f, 1670f, 1260f, isHorizontal = false))
        crosswalks.add(Crosswalk(1830f, 1140f, 1880f, 1260f, isHorizontal = false))
        crosswalks.add(Crosswalk(1690f, 1070f, 1810f, 1120f, isHorizontal = true))
        crosswalks.add(Crosswalk(1690f, 1280f, 1810f, 1330f, isHorizontal = true))

        // North Street & East Avenue (Near Grocery & Diner)
        crosswalks.add(Crosswalk(1690f, 460f, 1810f, 510f, isHorizontal = true))
        crosswalks.add(Crosswalk(1620f, 525f, 1670f, 635f, isHorizontal = false))
    }

    fun render(canvas: Canvas) {
        // 1. Draw sidewalks surrounding roads (wider than asphalt)
        val sidewalkMargin = 22f
        for (road in roads) {
            val swRect = RectF(
                road.left - if (!road.isHorizontal) sidewalkMargin else 0f,
                road.top - if (road.isHorizontal) sidewalkMargin else 0f,
                road.right + if (!road.isHorizontal) sidewalkMargin else 0f,
                road.bottom + if (road.isHorizontal) sidewalkMargin else 0f
            )
            canvas.drawRect(swRect, sidewalkPaint)
        }

        // 2. Draw dark asphalt road surfaces
        for (road in roads) {
            canvas.drawRect(road.left, road.top, road.right, road.bottom, asphaltPaint)

            // Side white boundary lines
            if (road.isHorizontal) {
                canvas.drawLine(road.left, road.top + 5f, road.right, road.top + 5f, whiteLinePaint)
                canvas.drawLine(road.left, road.bottom - 5f, road.right, road.bottom - 5f, whiteLinePaint)

                // Yellow center dashed lane markings
                val centerY = (road.top + road.bottom) * 0.5f
                canvas.drawLine(road.left, centerY, road.right, centerY, yellowDashPaint)
            } else {
                canvas.drawLine(road.left + 5f, road.top, road.left + 5f, road.bottom, whiteLinePaint)
                canvas.drawLine(road.right - 5f, road.top, road.right - 5f, road.bottom, whiteLinePaint)

                // Yellow center dashed lane markings
                val centerX = (road.left + road.right) * 0.5f
                canvas.drawLine(centerX, road.top, centerX, road.bottom, yellowDashPaint)
            }
        }

        // 3. Draw pedestrian zebra crosswalks
        for (cw in crosswalks) {
            if (cw.isHorizontal) {
                val stripeCount = ((cw.right - cw.left) / 14f).toInt()
                val stripeW = 8f
                for (i in 0 until stripeCount) {
                    val sX = cw.left + i * 14f
                    canvas.drawRect(sX, cw.top, sX + stripeW, cw.bottom, crosswalkStripePaint)
                }
            } else {
                val stripeCount = ((cw.bottom - cw.top) / 14f).toInt()
                val stripeH = 8f
                for (i in 0 until stripeCount) {
                    val sY = cw.top + i * 14f
                    canvas.drawRect(cw.left, sY, cw.right, sY + stripeH, crosswalkStripePaint)
                }
            }
        }
    }
}
