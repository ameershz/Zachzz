package com.example.game.engine

import android.annotation.SuppressLint
import android.content.Context
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView

/**
 * Native SurfaceView implementation hosting the 2D rendering canvas and touch dispatcher.
 */
@SuppressLint("ClickableViewAccessibility")
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    val engine: GameEngine = GameEngine(context)
    private var gameLoop: GameLoop? = null

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        startLoop()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        engine.onSurfaceChanged(width.toFloat(), height.toFloat())
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        stopLoop()
    }

    private fun startLoop() {
        if (gameLoop == null || !gameLoop!!.isAlive) {
            gameLoop = GameLoop(holder, engine).apply {
                isRunning = true
                start()
            }
        }
    }

    private fun stopLoop() {
        gameLoop?.stopLoop()
        gameLoop = null
    }

    fun pause() {
        stopLoop()
        engine.saveProgress()
    }

    fun resume() {
        if (holder.surface.isValid) {
            startLoop()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return engine.handleTouchEvent(event) || super.onTouchEvent(event)
    }
}
