package com.example.game.player

enum class PlayerDirection {
    SOUTH, // Facing camera / down
    NORTH, // Facing away / up
    EAST,  // Facing right
    WEST   // Facing left
}
