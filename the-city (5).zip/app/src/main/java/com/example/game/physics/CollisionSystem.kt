package com.example.game.physics

import android.graphics.PointF

/**
 * Handles spatial collision detection and smooth sliding resolution against solid obstacles
 * and world boundaries.
 */
class CollisionSystem {
    private val staticColliders = mutableListOf<RectCollider>()
    var worldBounds: RectCollider = RectCollider(0f, 0f, 2400f, 2400f)

    fun clear() {
        staticColliders.clear()
    }

    fun addCollider(collider: RectCollider) {
        staticColliders.add(collider)
    }

    fun addColliders(colliders: Collection<RectCollider>) {
        staticColliders.addAll(colliders)
    }

    /**
     * Resolves movement from (currentX, currentY) towards (targetX, targetY) for an entity of
     * given halfWidth and halfHeight. Resolves X and Y independently so the character can smoothly
     * slide along walls and fences without snagging.
     */
    fun resolveMovement(
        currentX: Float,
        currentY: Float,
        targetX: Float,
        targetY: Float,
        halfWidth: Float,
        halfHeight: Float
    ): PointF {
        // Clamp to world boundaries first
        var resolvedX = targetX.coerceIn(
            worldBounds.left + halfWidth,
            worldBounds.right - halfWidth
        )
        var resolvedY = targetY.coerceIn(
            worldBounds.top + halfHeight,
            worldBounds.bottom - halfHeight
        )

        // Try movement along X axis
        val testColliderX = RectCollider(
            resolvedX - halfWidth,
            currentY - halfHeight,
            resolvedX + halfWidth,
            currentY + halfHeight
        )

        for (obstacle in staticColliders) {
            if (!obstacle.isTrigger && testColliderX.intersects(obstacle)) {
                // Collision on X: keep previous X position
                resolvedX = currentX
                break
            }
        }

        // Try movement along Y axis with the (possibly adjusted) resolvedX
        val testColliderY = RectCollider(
            resolvedX - halfWidth,
            resolvedY - halfHeight,
            resolvedX + halfWidth,
            resolvedY + halfHeight
        )

        for (obstacle in staticColliders) {
            if (!obstacle.isTrigger && testColliderY.intersects(obstacle)) {
                // Collision on Y: keep previous Y position
                resolvedY = currentY
                break
            }
        }

        // Final safety check: if both X and Y simultaneously collide diagonally
        val testColliderBoth = RectCollider(
            resolvedX - halfWidth,
            resolvedY - halfHeight,
            resolvedX + halfWidth,
            resolvedY + halfHeight
        )
        for (obstacle in staticColliders) {
            if (!obstacle.isTrigger && testColliderBoth.intersects(obstacle)) {
                // Diagonal stuck: revert to safe current position
                return PointF(currentX, currentY)
            }
        }

        return PointF(resolvedX, resolvedY)
    }

    /**
     * Returns true if the given test box intersects any solid obstacle or is out of bounds.
     */
    fun checkCollision(x: Float, y: Float, halfWidth: Float, halfHeight: Float): Boolean {
        if (x - halfWidth < worldBounds.left || x + halfWidth > worldBounds.right ||
            y - halfHeight < worldBounds.top || y + halfHeight > worldBounds.bottom
        ) {
            return true
        }

        val testBox = RectCollider(
            x - halfWidth,
            y - halfHeight,
            x + halfWidth,
            y + halfHeight
        )

        for (obstacle in staticColliders) {
            if (!obstacle.isTrigger && testBox.intersects(obstacle)) {
                return true
            }
        }
        return false
    }

    fun getAllColliders(): List<RectCollider> = staticColliders
}
