package com.example.game.interaction

/**
 * Tracks interactable objects in the world and finds the closest one to the player.
 */
class InteractionManager {
    private val interactables = mutableListOf<Interactable>()

    var activeInteractable: Interactable? = null
        private set

    fun register(interactable: Interactable) {
        interactables.add(interactable)
    }

    fun registerAll(list: Collection<Interactable>) {
        interactables.addAll(list)
    }

    fun clear() {
        interactables.clear()
        activeInteractable = null
    }

    fun update(playerX: Float, playerY: Float) {
        var closest: Interactable? = null
        var closestDist = Float.MAX_VALUE

        for (item in interactables) {
            val dist = item.distanceTo(playerX, playerY)
            if (dist <= item.radius && dist < closestDist) {
                closest = item
                closestDist = dist
            }
        }

        activeInteractable = closest
    }

    fun triggerActive() {
        activeInteractable?.onTrigger?.invoke()
    }
}
