package com.example.game.interaction

import kotlin.math.hypot

/**
 * An interactable entity in the game world (e.g. building entrance, NPC, or feature point).
 */
data class Interactable(
    val id: String,
    val name: String,
    val actionLabel: String,
    val actionSubLabel: String,
    val triggerX: Float,
    val triggerY: Float,
    val radius: Float = 85f,
    val onTrigger: () -> Unit
) {
    fun distanceTo(px: Float, py: Float): Float {
        return hypot(px - triggerX, py - triggerY)
    }

    fun isPlayerNear(px: Float, py: Float): Boolean {
        return distanceTo(px, py) <= radius
    }
}
