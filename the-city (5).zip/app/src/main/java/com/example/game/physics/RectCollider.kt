package com.example.game.physics

import android.graphics.RectF

/**
 * Axis-Aligned Bounding Box (AABB) collider for 2D collision detection and resolution.
 */
data class RectCollider(
    var left: Float,
    var top: Float,
    var right: Float,
    var bottom: Float,
    val isTrigger: Boolean = false,
    val tag: String = ""
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) * 0.5f
    val centerY: Float get() = (top + bottom) * 0.5f

    fun intersects(other: RectCollider): Boolean {
        return left < other.right && right > other.left &&
                top < other.bottom && bottom > other.top
    }

    fun intersects(oLeft: Float, oTop: Float, oRight: Float, oBottom: Float): Boolean {
        return left < oRight && right > oLeft &&
                top < oBottom && bottom > oTop
    }

    fun contains(px: Float, py: Float): Boolean {
        return px in left..right && py in top..bottom
    }

    fun distanceTo(px: Float, py: Float): Float {
        val dx = when {
            px < left -> left - px
            px > right -> px - right
            else -> 0f
        }
        val dy = when {
            py < top -> top - py
            py > bottom -> py - bottom
            else -> 0f
        }
        return kotlin.math.hypot(dx, dy)
    }

    fun toRectF(): RectF = RectF(left, top, right, bottom)
}
