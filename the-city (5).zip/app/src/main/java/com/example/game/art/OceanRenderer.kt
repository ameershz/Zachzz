package com.example.game.art

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.sin

/**
 * High-quality multi-layered tropical ocean renderer with depth gradients,
 * dynamic wave swells, shoreline surf foam, and animated caustic sparkles.
 */
class OceanRenderer(val worldWidth: Float, val worldHeight: Float) {

    private var time: Float = 0f

    // Pre-allocated paints to avoid GC in game loop
    private val deepOceanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val shelfOceanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(20, 115, 175)
        style = Paint.Style.FILL
    }

    private val shallowLagoonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(38, 166, 186)
        style = Paint.Style.FILL
    }

    private val waveSwellPaint1 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 160, 230, 255)
        style = Paint.Style.STROKE
        strokeWidth = 4f
        strokeCap = Paint.Cap.ROUND
    }

    private val waveSwellPaint2 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 210, 245, 255)
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }

    private val shoreFoamPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(140, 245, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val shoreBackFoamPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 140, 235, 245)
        style = Paint.Style.STROKE
        strokeWidth = 14f
    }

    private val sparklePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    // Static sparkle points in world coordinates
    private val sparkleSeeds = List(36) { i ->
        val x = (i * 197) % worldWidth.toInt()
        val y = (i * 313) % worldHeight.toInt()
        val freq = 1.2f + (i % 7) * 0.35f
        val phase = (i * 1.37f)
        Triple(x.toFloat(), y.toFloat(), Pair(freq, phase))
    }

    init {
        // Multi-stage radial gradient for ocean depths centered on island
        val cx = worldWidth * 0.5f
        val cy = worldHeight * 0.5f
        val radius = worldWidth * 0.72f
        val colors = intArrayOf(
            Color.rgb(35, 155, 195), // Coastal shelf
            Color.rgb(20, 105, 165), // Mid ocean
            Color.rgb(10, 55, 105)   // Abyss
        )
        val stops = floatArrayOf(0.35f, 0.65f, 1.0f)
        deepOceanPaint.shader = RadialGradient(cx, cy, radius, colors, stops, Shader.TileMode.CLAMP)
    }

    fun update(deltaTime: Float) {
        time += deltaTime
    }

    fun renderOcean(canvas: Canvas, islandBeachRect: RectF) {
        // 1. Deep Ocean Base with Radial Depth Gradient
        canvas.drawRect(0f, 0f, worldWidth, worldHeight, deepOceanPaint)

        // 2. Animated Deep Water Swell Waves (layered organic curves)
        renderSwellWaves(canvas)

        // 3. Shimmering Sun Caustic Sparkles
        renderSparkles(canvas)

        // 4. Coastal Reef Shallow Halo
        val haloRect = RectF(
            islandBeachRect.left - 130f,
            islandBeachRect.top - 130f,
            islandBeachRect.right + 130f,
            islandBeachRect.bottom + 130f
        )
        canvas.drawRoundRect(haloRect, 180f, 180f, shallowLagoonPaint)

        // 5. Shoreline Foam and Lapping Surf
        renderShoreSurf(canvas, islandBeachRect)
    }

    private fun renderSwellWaves(canvas: Canvas) {
        // Multi-frequency organic swells
        val wavePath1 = Path()
        val wavePath2 = Path()

        var y = 80f
        var row = 0
        while (y < worldHeight) {
            val speed = if (row % 2 == 0) 1.2f else 0.85f
            val phaseOffset = row * 0.8f
            val yOffset = sin(time * speed + phaseOffset) * 14f

            var x = 40f
            while (x < worldWidth) {
                val waveLength = 140f
                val h1 = sin(time * 1.5f + (x * 0.015f)) * 8f
                val h2 = cos(time * 1.1f + (x * 0.02f)) * 6f

                // Staggered wavy strokes
                if ((row + (x / 200).toInt()) % 3 == 0) {
                    wavePath1.reset()
                    wavePath1.moveTo(x, y + yOffset + h1)
                    wavePath1.quadTo(x + waveLength * 0.5f, y + yOffset + h1 - 8f, x + waveLength, y + yOffset + h2)
                    canvas.drawPath(wavePath1, waveSwellPaint1)
                } else if ((row + (x / 200).toInt()) % 3 == 1) {
                    wavePath2.reset()
                    wavePath2.moveTo(x, y + yOffset + h2)
                    wavePath2.quadTo(x + waveLength * 0.5f, y + yOffset + h2 + 7f, x + waveLength, y + yOffset + h1)
                    canvas.drawPath(wavePath2, waveSwellPaint2)
                }

                x += waveLength + 50f
            }

            y += 90f
            row++
        }
    }

    private fun renderSparkles(canvas: Canvas) {
        for ((sx, sy, params) in sparkleSeeds) {
            val (freq, phase) = params
            val alphaNorm = (sin(time * freq + phase) * 0.5f + 0.5f)
            if (alphaNorm > 0.45f) {
                val alpha = ((alphaNorm - 0.45f) / 0.55f * 180).toInt().coerceIn(0, 200)
                sparklePaint.alpha = alpha

                val size = 3f + alphaNorm * 3f
                // Draw 4-point diamond sparkle
                canvas.drawCircle(sx, sy, size * 0.6f, sparklePaint)
                canvas.drawLine(sx - size, sy, sx + size, sy, sparklePaint)
                canvas.drawLine(sx, sy - size, sx, sy + size, sparklePaint)
            }
        }
    }

    private fun renderShoreSurf(canvas: Canvas, islandBeachRect: RectF) {
        // Dynamic surf expansion and retreat
        val surfPulse = sin(time * 1.8f) * 6f
        val surfRect = RectF(
            islandBeachRect.left - 18f - surfPulse,
            islandBeachRect.top - 18f - surfPulse,
            islandBeachRect.right + 18f + surfPulse,
            islandBeachRect.bottom + 18f + surfPulse
        )

        // Soft back foam layer
        canvas.drawRoundRect(surfRect, 140f, 140f, shoreBackFoamPaint)

        // Crisp white foam boundary
        val crispSurfRect = RectF(
            islandBeachRect.left - 8f - surfPulse * 0.7f,
            islandBeachRect.top - 8f - surfPulse * 0.7f,
            islandBeachRect.right + 8f + surfPulse * 0.7f,
            islandBeachRect.bottom + 8f + surfPulse * 0.7f
        )
        canvas.drawRoundRect(crispSurfRect, 135f, 135f, shoreFoamPaint)
    }
}
