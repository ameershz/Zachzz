package com.example.game.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.art.AssetCache
import com.example.game.economy.EconomyManager
import com.example.game.inventory.FishInventory

/**
 * Redesigned Pelican Fishmonger shop modal with illustrated fish cards,
 * clear pricing, bulk sale CTA, and responsive landscape handling.
 */
class FishShopModal(
    val economyManager: EconomyManager,
    val fishInventory: FishInventory,
    var onSoldFish: ((Int, Int) -> Unit)? = null,
    var onClose: (() -> Unit)? = null
) {
    var isOpen: Boolean = false
        private set

    private val modalRect = RectF()
    private val sellAllBtnRect = RectF()
    private val closeBtnRect = RectF()

    // Paints
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(185, 6, 14, 24)
        style = Paint.Style.FILL
    }

    private val cardBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(18, 28, 44)
        style = Paint.Style.FILL
    }

    private val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113) // Fresh sea-green trim
        style = Paint.Style.STROKE
        strokeWidth = 3.5f
    }

    private val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(24, 44, 64)
        style = Paint.Style.FILL
    }

    private val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 21f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val greetingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(180, 215, 240)
        textAlign = Paint.Align.CENTER
        textSize = 13f
    }

    private val itemBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(12, 20, 32)
        style = Paint.Style.FILL
    }

    private val fishTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val valueTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(241, 196, 15)
        textAlign = Paint.Align.RIGHT
        textSize = 15.5f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val sellAllBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(39, 174, 96)
        style = Paint.Style.FILL
    }

    private val sellAllDisabledPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(55, 68, 82)
        style = Paint.Style.FILL
    }

    private val btnTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
    }

    private val closeBtnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(215, 60, 50)
        style = Paint.Style.FILL
    }

    fun open() {
        isOpen = true
    }

    fun close() {
        isOpen = false
        onClose?.invoke()
    }

    fun onTouch(touchX: Float, touchY: Float): Boolean {
        if (!isOpen) return false

        // Tap Sell All button
        if (sellAllBtnRect.contains(touchX, touchY)) {
            if (fishInventory.count > 0) {
                val (soldCount, totalEarned) = fishInventory.clearAndSellAll()
                if (totalEarned > 0) {
                    economyManager.earn(totalEarned)
                    onSoldFish?.invoke(soldCount, totalEarned)
                }
            }
            return true
        }

        // Tap Close button
        if (closeBtnRect.contains(touchX, touchY)) {
            close()
            return true
        }

        // Tap outside card dismisses
        if (!modalRect.contains(touchX, touchY)) {
            close()
            return true
        }

        return true
    }

    fun render(canvas: Canvas, screenW: Float, screenH: Float) {
        if (!isOpen) return

        val isLandscape = screenW > screenH

        canvas.drawRect(0f, 0f, screenW, screenH, dimPaint)

        val cardW = if (isLandscape) (screenW * 0.74f).coerceIn(520f, 720f) else (screenW * 0.90f).coerceIn(320f, 480f)
        val cardH = if (isLandscape) (screenH * 0.88f).coerceIn(340f, 440f) else 480f.coerceAtMost(screenH * 0.88f)
        val cardLeft = (screenW - cardW) * 0.5f
        val cardTop = (screenH - cardH) * 0.5f
        modalRect.set(cardLeft, cardTop, cardLeft + cardW, cardTop + cardH)

        canvas.drawRoundRect(modalRect, 18f, 18f, cardBgPaint)
        canvas.drawRoundRect(modalRect, 18f, 18f, cardBorderPaint)

        // Header
        val headerH = if (isLandscape) 46f else 54f
        val headerRect = RectF(cardLeft, cardTop, cardLeft + cardW, cardTop + headerH)
        canvas.drawRoundRect(headerRect, 18f, 18f, headerPaint)
        canvas.drawRect(cardLeft, cardTop + headerH - 12f, cardLeft + cardW, cardTop + headerH, headerPaint)

        canvas.drawText("🐟 Pelican Fishmonger", screenW * 0.5f, cardTop + headerH * 0.62f, titlePaint)

        val greetingY = cardTop + headerH + (if (isLandscape) 14f else 18f)
        canvas.drawText("Top market rates for island catches! Fresh fish wanted.", screenW * 0.5f, greetingY, greetingPaint)

        // List box of fish
        val footerH = if (isLandscape) 52f else 58f
        val listTop = greetingY + (if (isLandscape) 8f else 12f)
        val listBottom = cardTop + cardH - footerH - 8f
        val listRect = RectF(cardLeft + 14f, listTop, cardLeft + cardW - 14f, listBottom)

        val fishList = fishInventory.getFishList()
        if (fishList.isEmpty()) {
            val emptyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(150, 175, 205)
                textAlign = Paint.Align.CENTER
                textSize = 15f
            }
            canvas.drawText("No fish in creel to sell!", listRect.centerX(), listRect.centerY() - 8f, emptyPaint)
            canvas.drawText("Go cast your line at the ocean dock.", listRect.centerX(), listRect.centerY() + 16f, emptyPaint)
        } else {
            var itemY = listTop + 4f
            val itemH = if (isLandscape) 50f else 54f
            val maxItems = if (isLandscape) 3 else 4

            for (i in 0 until minOf(maxItems, fishList.size)) {
                val fish = fishList[i]
                val rowRect = RectF(listRect.left + 4f, itemY, listRect.right - 4f, itemY + itemH)

                canvas.drawRoundRect(rowRect, 8f, 8f, itemBoxPaint)

                // Rarity border
                val rowBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = fish.species.rarity.color
                    style = Paint.Style.STROKE
                    strokeWidth = 1.8f
                }
                canvas.drawRoundRect(rowRect, 8f, 8f, rowBorder)

                // Fish Artwork Thumbnail
                val thumbPad = 5f
                val thumbRect = RectF(rowRect.left + 8f, rowRect.top + thumbPad, rowRect.left + 8f + itemH - thumbPad * 2, rowRect.bottom - thumbPad)
                AssetCache.drawFishArtwork(canvas, fish.species, thumbRect)

                val textX = thumbRect.right + 12f
                canvas.drawText(fish.species.speciesName, textX, rowRect.top + 20f, fishTextPaint)

                val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = fish.species.rarity.color
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                }
                canvas.drawText("${fish.species.rarity.displayName.uppercase()}  •  ${fish.formattedWeight}", textX, rowRect.top + 38f, badgePaint)

                canvas.drawText("+${fish.formattedValue}", rowRect.right - 14f, rowRect.centerY() + valueTextPaint.textSize * 0.35f, valueTextPaint)

                itemY += itemH + 6f
            }

            if (fishList.size > maxItems) {
                val morePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(170, 200, 230)
                    textAlign = Paint.Align.CENTER
                    textSize = 12f
                }
                canvas.drawText("+ ${fishList.size - maxItems} more fish in creel", listRect.centerX(), listBottom - 4f, morePaint)
            }
        }

        // Footer: Summary, SELL ALL button, and CLOSE
        val totalWorth = fishInventory.totalValue
        val footerY = cardTop + cardH - (if (isLandscape) 24f else 28f)

        val summaryPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 215, 65)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("Creel: $$totalWorth (${fishList.size}/10)", cardLeft + 18f, footerY - 4f, summaryPaint)

        // SELL ALL button
        val canSell = fishList.isNotEmpty()
        val sellBtnW = 160f
        val sellBtnH = 38f
        sellAllBtnRect.set(cardLeft + cardW - sellBtnW - 110f, footerY - 26f, cardLeft + cardW - 110f, footerY + 12f)
        canvas.drawRoundRect(sellAllBtnRect, 8f, 8f, if (canSell) sellAllBtnPaint else sellAllDisabledPaint)
        canvas.drawText(if (canSell) "SELL ALL ($$totalWorth)" else "EMPTY CREEL", sellAllBtnRect.centerX(), sellAllBtnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)

        // Close button
        val closeBtnW = 85f
        closeBtnRect.set(cardLeft + cardW - closeBtnW - 14f, footerY - 26f, cardLeft + cardW - 14f, footerY + 12f)
        canvas.drawRoundRect(closeBtnRect, 8f, 8f, closeBtnPaint)
        canvas.drawText("CLOSE", closeBtnRect.centerX(), closeBtnRect.centerY() + btnTextPaint.textSize * 0.35f, btnTextPaint)
    }
}
