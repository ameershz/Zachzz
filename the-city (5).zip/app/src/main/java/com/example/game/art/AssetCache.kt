package com.example.game.art

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import com.example.R
import com.example.game.fishing.FishSpecies
import com.example.game.fishing.FishingRod

/**
 * Central asset cache for stylized fish artworks, rod illustrations,
 * and pre-rendered textures to ensure 60fps performance without frame allocations.
 */
object AssetCache {
    private val fishBitmaps = mutableMapOf<FishSpecies, Bitmap>()
    private val rodBitmaps = mutableMapOf<String, Bitmap>()
    var isInitialized = false
        private set

    fun initialize(context: Context) {
        if (isInitialized) return

        loadFishBitmaps(context)
        preRenderRodIllustrations()
        isInitialized = true
    }

    private fun loadFishBitmaps(context: Context) {
        val res = context.resources

        val map = mapOf(
            FishSpecies.CORAL_SARDINE to R.drawable.img_fish_sardine,
            FishSpecies.STRIPED_SUNFISH to R.drawable.img_fish_sunfish,
            FishSpecies.AZURE_REEF_SNAPPER to R.drawable.img_fish_snapper,
            FishSpecies.GOLDEN_TIDE_MACKEREL to R.drawable.img_fish_mackerel,
            FishSpecies.LUMINOUS_MOONFIN to R.drawable.img_fish_moonfin
        )

        for ((species, resId) in map) {
            try {
                val opts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                val bmp = BitmapFactory.decodeResource(res, resId, opts)
                if (bmp != null) {
                    fishBitmaps[species] = bmp
                }
            } catch (_: Exception) {
            }
        }
    }

    fun getFishBitmap(species: FishSpecies): Bitmap? {
        return fishBitmaps[species]
    }

    /**
     * Pre-renders crisp vector illustrations of each rod onto cached bitmaps for UI and menus.
     */
    private fun preRenderRodIllustrations() {
        val size = 180
        for (rod in FishingRod.ALL_RODS) {
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            renderRodVector(canvas, rod, size.toFloat(), size.toFloat())
            rodBitmaps[rod.id] = bmp
        }
    }

    fun getRodBitmap(rodId: String): Bitmap? {
        return rodBitmaps[rodId]
    }

    private fun renderRodVector(canvas: Canvas, rod: FishingRod, w: Float, h: Float) {
        val rodPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = rod.rodColor
            strokeWidth = 5.5f
            strokeCap = Paint.Cap.ROUND
        }

        val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = when (rod.id) {
                FishingRod.WOODEN_ROD.id -> Color.rgb(110, 75, 45)
                FishingRod.REINFORCED_ROD.id -> Color.rgb(25, 30, 42)
                else -> Color.rgb(215, 175, 40)
            }
            strokeWidth = 10f
            strokeCap = Paint.Cap.ROUND
        }

        val guidePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(240, 240, 240)
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }

        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(190, 230, 240, 255)
            strokeWidth = 1.5f
            style = Paint.Style.STROKE
        }

        // Draw main shaft diagonally
        val startX = 28f
        val startY = h - 28f
        val tipX = w - 24f
        val tipY = 24f

        // Handle grip at base
        val handleEndX = startX + (tipX - startX) * 0.28f
        val handleEndY = startY + (tipY - startY) * 0.28f
        canvas.drawLine(startX, startY, handleEndX, handleEndY, handlePaint)

        // Main rod blank
        canvas.drawLine(startX, startY, tipX, tipY, rodPaint)

        // Guide rings
        for (i in 1..4) {
            val t = 0.35f + i * 0.15f
            val gx = startX + (tipX - startX) * t
            val gy = startY + (tipY - startY) * t
            canvas.drawCircle(gx + 4f, gy - 4f, 3.5f, guidePaint)
        }

        // Reel body near handle
        val reelX = startX + (tipX - startX) * 0.18f + 8f
        val reelY = startY + (tipY - startY) * 0.18f + 8f
        val reelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (rod.id == FishingRod.MASTER_ROD.id) Color.rgb(255, 215, 60) else Color.rgb(90, 100, 115)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(reelX, reelY, 9f, reelPaint)

        // Line curving from tip
        val linePath = Path().apply {
            moveTo(tipX, tipY)
            quadTo(tipX + 10f, tipY + 45f, tipX - 15f, tipY + 65f)
        }
        canvas.drawPath(linePath, linePaint)
    }

    /**
     * Renders a fish artwork into a target rectangle.
     * Uses the loaded high-res bitmap if available with rounded corners,
     * or procedurally draws a stylized vector illustration if bitmap is missing.
     */
    fun drawFishArtwork(canvas: Canvas, species: FishSpecies, destRect: RectF, paint: Paint = Paint(Paint.ANTI_ALIAS_FLAG)) {
        val bmp = getFishBitmap(species)
        if (bmp != null) {
            canvas.save()
            val clipPath = Path().apply {
                addRoundRect(destRect, 10f, 10f, Path.Direction.CW)
            }
            canvas.clipPath(clipPath)
            canvas.drawBitmap(bmp, null, destRect, paint)
            canvas.restore()
        } else {
            drawProceduralFish(canvas, species, destRect)
        }
    }

    private fun drawProceduralFish(canvas: Canvas, species: FishSpecies, destRect: RectF) {
        val cx = destRect.centerX()
        val cy = destRect.centerY()
        val w = destRect.width()
        val h = destRect.height()

        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = species.primaryColor
            style = Paint.Style.FILL
        }
        val finPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = species.secondaryColor
            style = Paint.Style.FILL
        }
        val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.FILL
        }

        // Fish body oval
        val bodyW = w * 0.55f
        val bodyH = h * 0.32f
        canvas.drawOval(RectF(cx - bodyW * 0.5f, cy - bodyH * 0.5f, cx + bodyW * 0.5f, cy + bodyH * 0.5f), bodyPaint)

        // Caudal fin (tail)
        val tailPath = Path().apply {
            moveTo(cx - bodyW * 0.45f, cy)
            lineTo(cx - bodyW * 0.75f, cy - bodyH * 0.5f)
            lineTo(cx - bodyW * 0.65f, cy)
            lineTo(cx - bodyW * 0.75f, cy + bodyH * 0.5f)
            close()
        }
        canvas.drawPath(tailPath, finPaint)

        // Dorsal fin
        val dorsalPath = Path().apply {
            moveTo(cx - bodyW * 0.1f, cy - bodyH * 0.45f)
            quadTo(cx, cy - bodyH * 0.85f, cx + bodyW * 0.2f, cy - bodyH * 0.45f)
            close()
        }
        canvas.drawPath(dorsalPath, finPaint)

        // Eye
        canvas.drawCircle(cx + bodyW * 0.25f, cy - bodyH * 0.12f, bodyH * 0.16f, eyePaint)
    }
}
