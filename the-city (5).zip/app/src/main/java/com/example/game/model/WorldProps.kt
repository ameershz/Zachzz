package com.example.game.model

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.example.game.physics.RectCollider
import kotlin.math.sin

/**
 * Tropical island environmental props: animated swaying Palm trees, beach rocks,
 * seashells & starfish, nautical lanterns, wooden piers, and moored skiffs.
 */

class PalmTree(
    val x: Float,
    val y: Float,
    val size: Float = 44f
) {
    val collider: RectCollider = RectCollider(
        left = x - 12f,
        top = y - 10f,
        right = x + 12f,
        bottom = y + 10f,
        tag = "palmtree"
    )

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 15, 30, 45)
        style = Paint.Style.FILL
    }

    private val trunkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(130, 85, 45) // Warm coconut bark
        strokeWidth = 11f
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }

    private val trunkRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(105, 65, 32)
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }

    private val coconutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(85, 48, 22)
        style = Paint.Style.FILL
    }

    private val frondDarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 120, 48) // Forest palm
        style = Paint.Style.FILL
    }

    private val frondMidPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(40, 160, 70) // Emerald tropical
        style = Paint.Style.FILL
    }

    private val frondLightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(76, 205, 110) // Sunlit frond tip
        style = Paint.Style.FILL
    }

    private var windTimer: Float = (x * 0.05f + y * 0.03f)

    fun update(deltaTime: Float) {
        windTimer += deltaTime
    }

    fun render(canvas: Canvas) {
        // Wind sway offset
        val sway = sin(windTimer * 1.6f) * 4.5f

        // Soft ground shadow
        val shadowRect = RectF(x - size * 0.85f, y - 8f, x + size * 1.15f, y + 18f)
        canvas.drawOval(shadowRect, shadowPaint)

        // Curved trunk path
        val topX = x - 8f + sway * 0.6f
        val topY = y - 58f

        val trunkPath = Path().apply {
            moveTo(x, y)
            quadTo(x + 12f, y - 28f, topX, topY)
        }
        canvas.drawPath(trunkPath, trunkPaint)

        // Trunk bark rings
        for (i in 1..4) {
            val t = i * 0.2f
            val rx = x + (topX - x) * t + 2f
            val ry = y - 58f * t
            canvas.drawLine(rx - 5f, ry, rx + 5f, ry, trunkRingPaint)
        }

        // Coconuts cluster under crown
        canvas.drawCircle(topX - 4f, topY + 5f, 4.5f, coconutPaint)
        canvas.drawCircle(topX + 4f, topY + 5f, 4.5f, coconutPaint)
        canvas.drawCircle(topX, topY + 8f, 4f, coconutPaint)

        // Multi-layered lush swaying palm fronds
        drawFrond(canvas, topX, topY, -size * 0.95f + sway, -size * 0.45f, frondDarkPaint)
        drawFrond(canvas, topX, topY, size * 0.95f + sway, -size * 0.45f, frondDarkPaint)
        drawFrond(canvas, topX, topY, -size * 0.75f + sway * 0.8f, size * 0.35f, frondMidPaint)
        drawFrond(canvas, topX, topY, size * 0.75f + sway * 0.8f, size * 0.35f, frondMidPaint)
        drawFrond(canvas, topX, topY, sway * 1.2f, -size * 0.9f, frondLightPaint)
    }

    private fun drawFrond(canvas: Canvas, sx: Float, sy: Float, ex: Float, ey: Float, paint: Paint) {
        val path = Path().apply {
            moveTo(sx, sy)
            val midX = sx + ex * 0.5f - 8f
            val midY = sy + ey * 0.5f - 12f
            quadTo(midX, midY, sx + ex, sy + ey)
            quadTo(midX + 14f, midY + 10f, sx, sy)
        }
        canvas.drawPath(path, paint)
    }
}

class BeachRock(
    val x: Float,
    val y: Float,
    val radius: Float = 22f
) {
    val collider: RectCollider = RectCollider(
        left = x - radius * 0.8f,
        top = y - radius * 0.7f,
        right = x + radius * 0.8f,
        bottom = y + radius * 0.7f,
        tag = "rock"
    )

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(55, 15, 25, 35)
        style = Paint.Style.FILL
    }

    private val baseRockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(120, 130, 142)
        style = Paint.Style.FILL
    }

    private val shadowFacetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(90, 100, 112)
        style = Paint.Style.FILL
    }

    private val highlightFacetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(165, 178, 192)
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        // Soft ground shadow
        val shadowRect = RectF(x - radius * 1.1f, y - radius * 0.2f, x + radius * 1.2f, y + radius * 0.9f)
        canvas.drawOval(shadowRect, shadowPaint)

        // Main boulder body
        val rockRect = RectF(x - radius, y - radius * 0.75f, x + radius, y + radius * 0.75f)
        canvas.drawRoundRect(rockRect, 12f, 12f, baseRockPaint)

        // Shadow facet on bottom-right
        val shadowPath = Path().apply {
            moveTo(x, y + radius * 0.75f)
            lineTo(x + radius, y + radius * 0.75f)
            lineTo(x + radius, y)
            close()
        }
        canvas.drawPath(shadowPath, shadowFacetPaint)

        // Sunlit top-left highlight plane
        canvas.drawRoundRect(RectF(x - radius * 0.7f, y - radius * 0.65f, x + radius * 0.2f, y - radius * 0.1f), 6f, 6f, highlightFacetPaint)
    }
}

class BeachShell(
    val x: Float,
    val y: Float,
    val isStarfish: Boolean = false
) {
    private val shellPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = if (isStarfish) Color.rgb(240, 110, 60) else Color.rgb(250, 235, 215)
        style = Paint.Style.FILL
    }

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 0, 0, 0)
        style = Paint.Style.FILL
    }

    fun render(canvas: Canvas) {
        canvas.drawCircle(x + 1.5f, y + 1.5f, if (isStarfish) 6f else 4f, shadowPaint)

        if (isStarfish) {
            // Draw 5-arm starfish
            for (i in 0 until 5) {
                val angle = i * (Math.PI * 2 / 5.0)
                val ax = x + kotlin.math.cos(angle).toFloat() * 7f
                val ay = y + kotlin.math.sin(angle).toFloat() * 7f
                canvas.drawCircle(ax, ay, 2.8f, shellPaint)
            }
            canvas.drawCircle(x, y, 4f, shellPaint)
        } else {
            // Spiral scallop shell
            canvas.drawOval(RectF(x - 5f, y - 4f, x + 5f, y + 4f), shellPaint)
            val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(220, 195, 175)
                style = Paint.Style.STROKE
                strokeWidth = 1.2f
            }
            canvas.drawArc(RectF(x - 4f, y - 3f, x + 4f, y + 3f), 0f, 180f, false, ringPaint)
        }
    }
}

class NauticalLantern(
    val x: Float,
    val y: Float
) {
    val collider: RectCollider = RectCollider(x - 6f, y - 6f, x + 6f, y + 6f, tag = "lantern")

    private val postPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(115, 75, 40)
        strokeWidth = 6.5f
        strokeCap = Paint.Cap.ROUND
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(40, 255, 215, 100)
        style = Paint.Style.FILL
    }

    private val bulbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 240, 160)
        style = Paint.Style.FILL
    }

    private val cagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(55, 40, 25)
        style = Paint.Style.STROKE
        strokeWidth = 1.8f
    }

    fun render(canvas: Canvas) {
        // Soft ground illumination
        canvas.drawCircle(x, y + 6f, 48f, glowPaint)

        // Wood lantern post
        canvas.drawLine(x, y, x, y - 42f, postPaint)

        // Glass lantern
        val lanternRect = RectF(x - 6f, y - 48f, x + 6f, y - 36f)
        canvas.drawRoundRect(lanternRect, 3f, 3f, bulbPaint)
        canvas.drawRoundRect(lanternRect, 3f, 3f, cagePaint)
        canvas.drawCircle(x, y - 42f, 3f, bulbPaint)
    }
}

class WoodenFishingDock(
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
    val castingSpotX: Float,
    val castingSpotY: Float,
    val waterTargetX: Float,
    val waterTargetY: Float,
    val dockName: String = "Fishing Pier"
) {
    val right: Float get() = left + width
    val bottom: Float get() = top + height
    val centerX: Float get() = left + width * 0.5f

    private val plankPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(182, 138, 88) // Weathered boardwalk teak
        style = Paint.Style.FILL
    }

    private val plankLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(118, 82, 44)
        strokeWidth = 2.5f
    }

    private val nailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(75, 52, 28)
        style = Paint.Style.FILL
    }

    private val pilingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(85, 56, 30)
        style = Paint.Style.FILL
    }

    private val castingRingGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 46, 204, 113)
        style = Paint.Style.FILL
    }

    private val castingRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(46, 204, 113)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    private val castingLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 13.5f
        typeface = Typeface.DEFAULT_BOLD
    }

    fun render(canvas: Canvas) {
        // Pilings support posts in water
        var yPiling = top + 14f
        while (yPiling < bottom) {
            canvas.drawCircle(left + 6f, yPiling, 7f, pilingPaint)
            canvas.drawCircle(right - 6f, yPiling, 7f, pilingPaint)
            yPiling += 40f
        }

        // Main plank surface
        val dockRect = RectF(left, top, right, bottom)
        canvas.drawRoundRect(dockRect, 4f, 4f, plankPaint)

        // Wood grain plank separators & nail heads
        var yLine = top + 18f
        while (yLine < bottom) {
            canvas.drawLine(left, yLine, right, yLine, plankLinePaint)
            canvas.drawCircle(left + 8f, yLine - 9f, 1.8f, nailPaint)
            canvas.drawCircle(right - 8f, yLine - 9f, 1.8f, nailPaint)
            yLine += 18f
        }

        // Outer timber beam edges
        canvas.drawRect(left, top, left + 4.5f, bottom, pilingPaint)
        canvas.drawRect(right - 4.5f, top, right, bottom, pilingPaint)

        // Stylized casting zone circle at pier tip
        canvas.drawCircle(castingSpotX, castingSpotY, 28f, castingRingGlow)
        canvas.drawCircle(castingSpotX, castingSpotY, 28f, castingRingPaint)
        canvas.drawText("🎣 CAST SPOT", castingSpotX, castingSpotY + 5f, castingLabelPaint)
    }
}

class MooredBoat(
    val x: Float,
    val y: Float
) {
    val collider: RectCollider = RectCollider(x - 42f, y - 22f, x + 42f, y + 22f, tag = "boat")

    private val hullPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(238, 242, 246)
        style = Paint.Style.FILL
    }

    private val hullTrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(33, 150, 243) // Seaside blue trim
        style = Paint.Style.FILL
    }

    private val benchPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(175, 125, 75)
        style = Paint.Style.FILL
    }

    private val wakePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 220, 245, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private var timer: Float = 0f

    fun update(deltaTime: Float) {
        timer += deltaTime
    }

    fun render(canvas: Canvas) {
        val bobY = sin(timer * 2.2f) * 3.5f

        // Water ripples
        canvas.drawOval(RectF(x - 52f, y + bobY - 14f, x + 52f, y + bobY + 28f), wakePaint)

        // Skiff hull path
        val boatPath = Path().apply {
            moveTo(x + 46f, y + bobY)
            quadTo(x + 22f, y + bobY - 22f, x - 40f, y + bobY - 18f)
            lineTo(x - 40f, y + bobY + 18f)
            quadTo(x + 22f, y + bobY + 22f, x + 46f, y + bobY)
        }
        canvas.drawPath(boatPath, hullPaint)

        // Blue gunwale trim
        canvas.drawRoundRect(RectF(x - 38f, y + bobY - 15f, x - 30f, y + bobY + 15f), 2f, 2f, hullTrimPaint)

        // Wood bench seats
        canvas.drawRoundRect(RectF(x - 12f, y + bobY - 16f, x - 2f, y + bobY + 16f), 2f, 2f, benchPaint)
        canvas.drawRoundRect(RectF(x + 14f, y + bobY - 14f, x + 22f, y + bobY + 14f), 2f, 2f, benchPaint)
    }
}
