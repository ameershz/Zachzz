package com.example

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.game.engine.GameView

/**
 * Main activity for "The City" 2D game.
 * Launches the native SurfaceView game engine in immersive full-screen mode.
 */
class MainActivity : ComponentActivity() {

    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        gameView = GameView(this)
        setContentView(gameView)

        setupImmersiveMode()
        setupBackHandler()
    }

    private fun setupImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    private fun setupBackHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val engine = gameView.engine
                when {
                    engine.catchCelebrationModal.isOpen -> engine.catchCelebrationModal.dismiss()
                    engine.fishShopModal.isOpen -> engine.fishShopModal.close()
                    engine.rodShopModal.isOpen -> engine.rodShopModal.close()
                    engine.fishInventoryModal.isOpen -> engine.fishInventoryModal.close()
                    engine.fishingSystem.state != com.example.game.fishing.FishingState.FREE_ROAM ->
                        engine.fishingSystem.cancelFishing()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        setupImmersiveMode()
        gameView.resume()
    }

    override fun onPause() {
        super.onPause()
        gameView.pause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            setupImmersiveMode()
        }
    }
}
