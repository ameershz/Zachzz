package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class ScreenCaptureManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    private val handler = Handler(Looper.getMainLooper())

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 1080
    private var screenHeight = 1920
    private var screenDensity = DisplayMetrics.DENSITY_DEFAULT

    fun initProjection(resultCode: Int, data: Intent) {
        stopProjection()
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                super.onStop()
                releaseVirtualDisplay()
            }
        }, handler)
    }

    private fun updateScreenMetrics() {
        val metrics = DisplayMetrics()
        val defaultDisplay = windowManager.defaultDisplay
        defaultDisplay.getRealMetrics(metrics)

        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
    }

    @SuppressLint("WrongConstant")
    private fun setupVirtualDisplay() {
        releaseVirtualDisplay()
        updateScreenMetrics()

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "OmniTransVirtualDisplay",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            handler
        )
    }

    suspend fun captureScreen(): Bitmap? = withContext(Dispatchers.Default) {
        if (mediaProjection == null) {
            return@withContext null
        }

        setupVirtualDisplay()

        // Wait a short moment for the first valid frame from the VirtualDisplay
        var bitmap: Bitmap? = null
        withTimeoutOrNull(1200) {
            for (i in 0 until 12) {
                val image = imageReader?.acquireLatestImage()
                if (image != null) {
                    try {
                        bitmap = convertImageToBitmap(image)
                    } finally {
                        image.close()
                    }
                    if (bitmap != null) {
                        break
                    }
                }
                delay(80)
            }
        }

        releaseVirtualDisplay()
        bitmap
    }

    private fun convertImageToBitmap(image: Image): Bitmap? {
        val planes = image.planes
        if (planes.isEmpty()) return null

        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * screenWidth

        val width = screenWidth + rowPadding / pixelStride
        val height = screenHeight

        val rawBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        rawBitmap.copyPixelsFromBuffer(buffer)

        // Crop padding if rowPadding exists
        return if (rowPadding > 0) {
            val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, screenWidth, screenHeight)
            rawBitmap.recycle()
            cropped
        } else {
            rawBitmap
        }
    }

    private fun releaseVirtualDisplay() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {}
    }

    fun stopProjection() {
        releaseVirtualDisplay()
        try {
            mediaProjection?.stop()
            mediaProjection = null
        } catch (_: Exception) {}
    }

    fun isProjectionActive(): Boolean = mediaProjection != null
}
