package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.OmniTransApplication
import com.example.R
import com.example.overlay.FloatingBubbleView
import com.example.overlay.OverlayResultsWindow
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FloatingOverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager

    private var floatingBubbleView: FloatingBubbleView? = null
    private var overlayResultsWindow: OverlayResultsWindow? = null

    private val app by lazy { application as OmniTransApplication }

    companion object {
        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"

        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "omnitrans_overlay_channel"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning = _isServiceRunning.asStateFlow()
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode != 0 && resultData != null) {
                    app.screenCaptureManager.initProjection(resultCode, resultData)
                }

                startForegroundServiceWithNotification()
                setupFloatingBubble()
                _isServiceRunning.value = true
            }
        }
        return START_STICKY
    }

    private fun startForegroundServiceWithNotification() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OmniTrans Floating Translator")
            .setContentText("Tap bubble on screen to translate games & apps")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "OmniTrans Screen Translator",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows persistent status while translator bubble is active"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun setupFloatingBubble() {
        if (floatingBubbleView != null) return

        val bubbleSize = (64 * resources.displayMetrics.density).toInt()
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 350
        }

        floatingBubbleView = FloatingBubbleView(
            context = this,
            windowManager = windowManager,
            layoutParams = params,
            onBubbleClick = { handleScreenTranslateTrigger() },
            onBubbleLongClick = { openAppMainActivity() }
        )

        overlayResultsWindow = OverlayResultsWindow(
            context = this,
            windowManager = windowManager,
            onDismiss = {
                // Return focus or keep idle
            },
            onSaveHistory = { en, ar ->
                serviceScope.launch {
                    app.translationRepository.saveTranslation(en, ar, "Screen Overlay")
                }
            }
        )

        try {
            windowManager.addView(floatingBubbleView, params)
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to create overlay: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleScreenTranslateTrigger() {
        val bubble = floatingBubbleView ?: return

        serviceScope.launch {
            try {
                // 1. Set bubble state to Capturing
                bubble.currentState = FloatingBubbleView.State.CAPTURING

                // Give 100ms for bubble animation to paint before screen capture
                delay(120)

                // 2. Capture the Screen
                val bitmap = app.screenCaptureManager.captureScreen()
                if (bitmap == null) {
                    bubble.currentState = FloatingBubbleView.State.ERROR
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@FloatingOverlayService,
                            "Screen capture unavailable. Please re-grant screen permission in OmniTrans.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    delay(1200)
                    bubble.currentState = FloatingBubbleView.State.IDLE
                    return@launch
                }

                // 3. Set bubble state to Translating
                bubble.currentState = FloatingBubbleView.State.TRANSLATING

                // 4. OCR Extraction
                val ocrResult = app.ocrEngine.recognizeText(bitmap)
                bitmap.recycle() // Release bitmap immediately to conserve RAM

                if (!ocrResult.isSuccessful || ocrResult.fullText.isBlank()) {
                    bubble.currentState = FloatingBubbleView.State.ERROR
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            this@FloatingOverlayService,
                            "No English text found on screen.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    delay(1000)
                    bubble.currentState = FloatingBubbleView.State.IDLE
                    return@launch
                }

                // 5. Translate text (ML Kit + Offline Dictionary fallback)
                val detectedText = ocrResult.fullText
                val translatedArabic = app.translationEngine.translate(detectedText)

                // 6. Save to Room database history
                app.translationRepository.saveTranslation(detectedText, translatedArabic, "Game / Screen")

                // 7. Show Overlay Window
                withContext(Dispatchers.Main) {
                    overlayResultsWindow?.show(detectedText, translatedArabic)
                }

                // Reset Bubble to idle
                bubble.currentState = FloatingBubbleView.State.IDLE

            } catch (e: Exception) {
                bubble.currentState = FloatingBubbleView.State.ERROR
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@FloatingOverlayService, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
                delay(1200)
                bubble.currentState = FloatingBubbleView.State.IDLE
            }
        }
    }

    private fun openAppMainActivity() {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceRunning.value = false

        floatingBubbleView?.let {
            it.destroy()
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
            floatingBubbleView = null
        }

        overlayResultsWindow?.dismiss()
        overlayResultsWindow = null

        app.screenCaptureManager.stopProjection()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
