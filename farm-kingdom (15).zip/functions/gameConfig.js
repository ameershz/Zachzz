// Server-Authoritative Game Configuration (Phase 3 Expansion)

const CROPS = {
  wheat: {
    id: "wheat",
    nameEn: "Wheat",
    nameAr: "قمح ذهبي",
    growthTimeSeconds: 15,
    buySeedPrice: 10,
    sellPrice: 25,
    xpReward: 12,
    unlockLevel: 1
  },
  corn: {
    id: "corn",
    nameEn: "Corn",
    nameAr: "ذرة حلوة",
    growthTimeSeconds: 30,
    buySeedPrice: 25,
    sellPrice: 65,
    xpReward: 30,
    unlockLevel: 2
  },
  carrot: {
    id: "carrot",
    nameEn: "Carrot",
    nameAr: "جزر طازج",
    growthTimeSeconds: 60,
    buySeedPrice: 50,
    sellPrice: 135,
    xpReward: 65,
    unlockLevel: 3
  },
  potato: {
    id: "potato",
    nameEn: "Potato",
    nameAr: "بطاطس ريفية",
    growthTimeSeconds: 90,
    buySeedPrice: 75,
    sellPrice: 200,
    xpReward: 95,
    unlockLevel: 3
  },
  tomato: {
    id: "tomato",
    nameEn: "Tomato",
    nameAr: "طماطم حمراء",
    growthTimeSeconds: 120,
    buySeedPrice: 110,
    sellPrice: 300,
    xpReward: 140,
    unlockLevel: 4
  },
  strawberry: {
    id: "strawberry",
    nameEn: "Strawberry",
    nameAr: "فراولة برية",
    growthTimeSeconds: 240,
    buySeedPrice: 220,
    sellPrice: 640,
    xpReward: 290,
    unlockLevel: 5
  },
  cotton: {
    id: "cotton",
    nameEn: "Cotton",
    nameAr: "قطن ناصع",
    growthTimeSeconds: 360,
    buySeedPrice: 320,
    sellPrice: 950,
    xpReward: 420,
    unlockLevel: 7
  },
  pumpkin: {
    id: "pumpkin",
    nameEn: "Pumpkin",
    nameAr: "قرع الخريف",
    growthTimeSeconds: 480,
    buySeedPrice: 450,
    sellPrice: 1400,
    xpReward: 600,
    unlockLevel: 8
  },
  watermelon: {
    id: "watermelon",
    nameEn: "Watermelon",
    nameAr: "بطيخ منعش",
    growthTimeSeconds: 720,
    buySeedPrice: 900,
    sellPrice: 3000,
    xpReward: 1200,
    unlockLevel: 10
  }
};

const ANIMALS = {
  chicken: {
    id: "chicken",
    nameEn: "Clucking Chicken",
    nameAr: "دجاجة المزرعة",
    purchaseCost: 350,
    requiredLevel: 3,
    productionTimeSeconds: 20,
    feedItemId: "wheat_seed",
    productItemId: "egg",
    productSellPrice: 45,
    xpReward: 25
  },
  cow: {
    id: "cow",
    nameEn: "Dairy Cow",
    nameAr: "بقرة حلوب",
    purchaseCost: 850,
    requiredLevel: 5,
    productionTimeSeconds: 45,
    feedItemId: "corn_seed",
    productItemId: "milk",
    productSellPrice: 120,
    xpReward: 65
  },
  sheep: {
    id: "sheep",
    nameEn: "Woolly Sheep",
    nameAr: "خروف صوفي",
    purchaseCost: 1800,
    requiredLevel: 8,
    productionTimeSeconds: 90,
    feedItemId: "carrot_seed",
    productItemId: "wool",
    productSellPrice: 280,
    xpReward: 140
  }
};

const BUILDINGS = {
  bakery: {
    id: "bakery",
    nameEn: "Royal Bakery",
    nameAr: "المخبز الملكي",
    unlockLevel: 4,
    unlockCost: 750
  },
  dairy: {
    id: "dairy",
    nameEn: "Artisan Dairy",
    nameAr: "معمل الألبان",
    unlockLevel: 6,
    unlockCost: 1600
  },
  textile_mill: {
    id: "textile_mill",
    nameEn: "Textile Mill",
    nameAr: "مصنع النسيج",
    unlockLevel: 9,
    unlockCost: 3500
  }
};

const RECIPES = {
  bread: {
    id: "bread",
    nameEn: "Crusty Bread",
    nameAr: "خبز ريفي مقرمش",
    buildingId: "bakery",
    requiredLevel: 4,
    productionTimeSeconds: 30,
    inputItemId: "crop_wheat",
    inputAmount: 3,
    outputItemId: "item_bread",
    outputAmount: 1,
    sellPrice: 140,
    xpReward: 55
  },
  cornbread: {
    id: "cornbread",
    nameEn: "Sweet Cornbread",
    nameAr: "خبز الذرة الحلو",
    buildingId: "bakery",
    requiredLevel: 5,
    productionTimeSeconds: 50,
    inputItemId: "crop_corn",
    inputAmount: 2,
    secondaryInputItemId: "item_egg",
    secondaryInputAmount: 1,
    outputItemId: "item_cornbread",
    outputAmount: 1,
    sellPrice: 280,
    xpReward: 95
  },
  strawberry_cake: {
    id: "strawberry_cake",
    nameEn: "Strawberry Cake",
    nameAr: "كعكة الفراولة الملكية",
    buildingId: "bakery",
    requiredLevel: 6,
    productionTimeSeconds: 90,
    inputItemId: "crop_strawberry",
    inputAmount: 2,
    secondaryInputItemId: "item_egg",
    secondaryInputAmount: 2,
    outputItemId: "item_strawberry_cake",
    outputAmount: 1,
    sellPrice: 780,
    xpReward: 260
  },
  butter: {
    id: "butter",
    nameEn: "Creamy Butter",
    nameAr: "زبدة ريفية طازجة",
    buildingId: "dairy",
    requiredLevel: 6,
    productionTimeSeconds: 40,
    inputItemId: "item_milk",
    inputAmount: 2,
    outputItemId: "item_butter",
    outputAmount: 1,
    sellPrice: 240,
    xpReward: 80
  },
  cheese: {
    id: "cheese",
    nameEn: "Aged Farm Cheese",
    nameAr: "جبن قروي معتق",
    buildingId: "dairy",
    requiredLevel: 7,
    productionTimeSeconds: 75,
    inputItemId: "item_milk",
    inputAmount: 3,
    outputItemId: "item_cheese",
    outputAmount: 1,
    sellPrice: 420,
    xpReward: 160
  },
  cloth: {
    id: "cloth",
    nameEn: "Royal Cloth",
    nameAr: "قماش صوفي ملكي",
    buildingId: "textile_mill",
    requiredLevel: 9,
    productionTimeSeconds: 100,
    inputItemId: "item_wool",
    inputAmount: 2,
    outputItemId: "item_cloth",
    outputAmount: 1,
    sellPrice: 650,
    xpReward: 240
  },
  cotton_fabric: {
    id: "cotton_fabric",
    nameEn: "Fine Cotton Fabric",
    nameAr: "نسيج قطني فاخر",
    buildingId: "textile_mill",
    requiredLevel: 9,
    productionTimeSeconds: 80,
    inputItemId: "crop_cotton",
    inputAmount: 3,
    outputItemId: "item_cotton_fabric",
    outputAmount: 1,
    sellPrice: 520,
    xpReward: 190
  }
};

const DAILY_REWARDS = {
  1: { coins: 250, gems: 2, seedId: "wheat_seed", seedAmount: 5 },
  2: { coins: 400, gems: 3, seedId: "corn_seed", seedAmount: 4 },
  3: { coins: 600, gems: 5, seedId: "carrot_seed", seedAmount: 3 },
  4: { coins: 900, gems: 8, seedId: "potato_seed", seedAmount: 3 },
  5: { coins: 1400, gems: 10, seedId: "strawberry_seed", seedAmount: 2 },
  6: { coins: 2000, gems: 15, seedId: "pumpkin_seed", seedAmount: 2 },
  7: { coins: 3500, gems: 30, seedId: "cotton_seed", seedAmount: 4 }
};

const LAND_EXPANSIONS = {
  0: { unlockLevel: 1, unlockCost: 0 },
  1: { unlockLevel: 1, unlockCost: 0 },
  2: { unlockLevel: 1, unlockCost: 0 },
  3: { unlockLevel: 1, unlockCost: 0 },
  4: { unlockLevel: 1, unlockCost: 0 },
  5: { unlockLevel: 1, unlockCost: 0 },
  6: { unlockLevel: 2, unlockCost: 200 },
  7: { unlockLevel: 3, unlockCost: 450 },
  8: { unlockLevel: 4, unlockCost: 900 },
  9: { unlockLevel: 5, unlockCost: 1800 },
  10: { unlockLevel: 6, unlockCost: 3500 },
  11: { unlockLevel: 7, unlockCost: 6000 }
};

function getXpForLevel(level) {
  return (level * level * 80) + (level * 100);
}

function calculateLevelAndXp(currentLevel, currentXp, addedXp) {
  let newXp = currentXp + addedXp;
  let newLevel = currentLevel;
  while (true) {
    const needed = getXpForLevel(newLevel);
    if (newXp >= needed) {
      newXp -= needed;
      newLevel += 1;
    } else {
      break;
    }
  }
  return { newLevel, newXp, leveledUp: newLevel > currentLevel };
}

function getSiloUpgradeCost(currentCapacity) {
  return Math.max(300, currentCapacity * 5);
}

module.exports = {
  CROPS,
  ANIMALS,
  BUILDINGS,
  RECIPES,
  DAILY_REWARDS,
  LAND_EXPANSIONS,
  getXpForLevel,
  calculateLevelAndXp,
  getSiloUpgradeCost
};
