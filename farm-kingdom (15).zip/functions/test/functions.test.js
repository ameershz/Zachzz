const { test, before, after, beforeEach } = require("node:test");
const assert = require("node:assert");
const { initializeTestEnvironment } = require("@firebase/rules-unit-testing");
const fs = require("node:fs");
const {
  CROPS,
  ANIMALS,
  BUILDINGS,
  RECIPES,
  DAILY_REWARDS,
  calculateLevelAndXp,
  getSiloUpgradeCost
} = require("../gameConfig");

let testEnv;
const PROJECT_ID = "demo-no-project";
const ALICE_UID = "alice_fn_test";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();

    await testEnv.withSecurityRulesDisabled(async (context) => {
      const db = context.firestore();
      const userRef = db.collection("users").doc(ALICE_UID);
      await userRef.set({
        uid: ALICE_UID,
        username: "Alice",
        farmName: "Test Farm",
        level: 1,
        xp: 0,
        coins: 1000,
        gems: 10,
        storageCapacity: 100,
        totalHarvests: 0,
        totalCoinsEarned: 0,
        soundEnabled: true,
        hapticEnabled: true,
        language: "ar"
      });

      await userRef.collection("plots").doc("plot_0").set({
        plotIndex: 0,
        isUnlocked: true,
        cropId: null,
        plantedAt: 0,
        readyAt: 0,
        state: "EMPTY"
      });

      await userRef.collection("inventory").doc("wheat_seed").set({
        itemId: "wheat_seed",
        category: "SEED",
        quantity: 5
      });
    });
  }
});

test("Phase 3 Catalogs: validates animals, buildings, and recipes", () => {
  assert.strictEqual(ANIMALS.chicken.purchaseCost, 350);
  assert.strictEqual(ANIMALS.chicken.productItemId, "egg");
  assert.strictEqual(ANIMALS.cow.productItemId, "milk");
  assert.strictEqual(ANIMALS.sheep.productItemId, "wool");

  assert.strictEqual(BUILDINGS.bakery.unlockLevel, 4);
  assert.strictEqual(RECIPES.bread.buildingId, "bakery");
  assert.strictEqual(RECIPES.bread.inputAmount, 3);
  assert.strictEqual(RECIPES.bread.outputItemId, "item_bread");
});

test("Phase 3 Animal System: feeding transitions animal to producing state", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    const userRef = db.collection("users").doc(ALICE_UID);
    const animalRef = userRef.collection("animals").doc("chick_1");
    const feedRef = userRef.collection("inventory").doc("wheat_seed");

    await animalRef.set({
      animalId: "chick_1",
      animalType: "chicken",
      name: "Henrietta",
      fedAt: 0,
      readyAt: 0,
      state: "HUNGRY"
    });

    const now = Date.now();
    const readyAt = now + ANIMALS.chicken.productionTimeSeconds * 1000;

    await db.runTransaction(async (tx) => {
      const feedSnap = await tx.get(feedRef);
      const qty = feedSnap.data().quantity;
      tx.update(feedRef, { quantity: qty - 1 });
      tx.update(animalRef, {
        fedAt: now,
        readyAt,
        state: "PRODUCING"
      });
    });

    const updatedAnimal = (await animalRef.get()).data();
    const updatedFeed = (await feedRef.get()).data();

    assert.strictEqual(updatedAnimal.state, "PRODUCING");
    assert.strictEqual(updatedAnimal.readyAt, readyAt);
    assert.strictEqual(updatedFeed.quantity, 4);
  });
});

test("Phase 3 Workshop Production: crafts bread from wheat with XP reward", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const db = context.firestore();
    const userRef = db.collection("users").doc(ALICE_UID);
    const breadRef = userRef.collection("inventory").doc("item_bread");

    const recipe = RECIPES.bread;
    await db.runTransaction(async (tx) => {
      // Execute reads before writes
      const userSnap = await tx.get(userRef);
      const user = userSnap.data();
      const { newLevel, newXp } = calculateLevelAndXp(user.level, user.xp, recipe.xpReward);

      tx.set(breadRef, {
        itemId: recipe.outputItemId,
        category: "PROCESSED",
        quantity: 1
      });
      tx.update(userRef, { level: newLevel, xp: newXp });
    });

    const updatedBread = (await breadRef.get()).data();
    const updatedUser = (await userRef.get()).data();

    assert.strictEqual(updatedBread.quantity, 1);
    assert.strictEqual(updatedUser.xp, 55);
  });
});

test("Phase 3 Daily Bounty: Day 1 grants starter coins and seeds", () => {
  const reward = DAILY_REWARDS[1];
  assert.strictEqual(reward.coins, 250);
  assert.strictEqual(reward.gems, 2);
  assert.strictEqual(reward.seedId, "wheat_seed");
  assert.strictEqual(reward.seedAmount, 5);
});
