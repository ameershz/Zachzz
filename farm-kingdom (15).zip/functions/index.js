const { onCall, HttpsError } = require("firebase-functions/v2/https");
const admin = require("firebase-admin");
const {
  CROPS,
  ANIMALS,
  BUILDINGS,
  RECIPES,
  DAILY_REWARDS,
  LAND_EXPANSIONS,
  calculateLevelAndXp,
  getSiloUpgradeCost
} = require("./gameConfig");

if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();

function requireAuth(request) {
  if (!request.auth || !request.auth.uid) {
    throw new HttpsError(
      "unauthenticated",
      "Authentication required to perform this action."
    );
  }
  return request.auth.uid;
}

/**
 * 1. plantCrop
 */
exports.plantCrop = onCall(async (request) => {
  const uid = requireAuth(request);
  const { plotIndex, cropId, requestId } = request.data || {};

  if (plotIndex === undefined || !cropId) {
    throw new HttpsError("invalid-argument", "plotIndex and cropId are required.");
  }

  const crop = CROPS[cropId];
  if (!crop) {
    throw new HttpsError("invalid-argument", `Unknown crop: ${cropId}`);
  }

  const userDocRef = db.collection("users").document(uid);
  const plotDocRef = userDocRef.collection("plots").document(`plot_${plotIndex}`);
  const seedDocRef = userDocRef.collection("inventory").document(`${cropId}_seed`);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const plotSnap = await tx.get(plotDocRef);
    if (!plotSnap.exists) throw new HttpsError("not-found", "Plot does not exist.");
    const plotData = plotSnap.data();
    if (!plotData.isUnlocked) throw new HttpsError("failed-precondition", "Plot is locked.");
    if (plotData.state !== "EMPTY") throw new HttpsError("failed-precondition", "Plot is already planted or not empty.");

    const seedSnap = await tx.get(seedDocRef);
    if (!seedSnap.exists) throw new HttpsError("failed-precondition", `No ${crop.nameEn} seeds in inventory.`);
    const seedQty = seedSnap.data().quantity || 0;
    if (seedQty <= 0) throw new HttpsError("failed-precondition", `No ${crop.nameEn} seeds remaining.`);

    if (seedQty === 1) {
      tx.delete(seedDocRef);
    } else {
      tx.update(seedDocRef, { quantity: seedQty - 1 });
    }

    const now = Date.now();
    const readyAt = now + crop.growthTimeSeconds * 1000;

    tx.update(plotDocRef, {
      cropId,
      plantedAt: now,
      readyAt,
      state: "GROWING"
    });

    const result = {
      success: true,
      plotIndex,
      cropId,
      plantedAt: now,
      readyAt,
      remainingSeeds: seedQty - 1
    };

    if (actionDocRef) {
      tx.set(actionDocRef, {
        action: "plantCrop",
        requestId,
        timestamp: now,
        result
      });
    }

    return result;
  });
});

/**
 * 2. harvestCrop
 */
exports.harvestCrop = onCall(async (request) => {
  const uid = requireAuth(request);
  const { plotIndex, requestId } = request.data || {};

  if (plotIndex === undefined) {
    throw new HttpsError("invalid-argument", "plotIndex is required.");
  }

  const userDocRef = db.collection("users").document(uid);
  const plotDocRef = userDocRef.collection("plots").document(`plot_${plotIndex}`);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const plotSnap = await tx.get(plotDocRef);
    if (!plotSnap.exists) throw new HttpsError("not-found", "Plot not found.");
    const plot = plotSnap.data();
    if (!plot.isUnlocked) throw new HttpsError("failed-precondition", "Plot is locked.");
    if (!plot.cropId) throw new HttpsError("failed-precondition", "No crop planted on plot.");

    const crop = CROPS[plot.cropId];
    if (!crop) throw new HttpsError("invalid-argument", "Invalid crop data.");

    const now = Date.now();
    const readyAt = plot.readyAt || 0;
    if (plot.state !== "READY" && now < readyAt) {
      throw new HttpsError("failed-precondition", "Crop is still growing on the server.");
    }

    const userSnap = await tx.get(userDocRef);
    const userData = userSnap.data() || {};
    const currentLevel = userData.level || 1;
    const currentXp = userData.xp || 0;
    const totalHarvests = userData.totalHarvests || 0;

    const cropItemId = `crop_${crop.id}`;
    const cropDocRef = userDocRef.collection("inventory").document(cropItemId);
    const cropSnap = await tx.get(cropDocRef);
    const existingQty = cropSnap.exists ? (cropSnap.data().quantity || 0) : 0;

    tx.set(cropDocRef, {
      itemId: cropItemId,
      category: "CROP",
      quantity: existingQty + 1
    });

    tx.update(plotDocRef, {
      cropId: null,
      plantedAt: 0,
      readyAt: 0,
      state: "EMPTY"
    });

    const { newLevel, newXp, leveledUp } = calculateLevelAndXp(currentLevel, currentXp, crop.xpReward);

    tx.update(userDocRef, {
      level: newLevel,
      xp: newXp,
      totalHarvests: totalHarvests + 1
    });

    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "HARVEST",
      descEn: `Harvested ${crop.nameEn} (+${crop.xpReward} XP)`,
      descAr: `تم حصاد ${crop.nameAr} (+${crop.xpReward} نقطة خبرة)`,
      amountCoins: 0,
      amountXp: crop.xpReward,
      timestamp: now
    });

    const result = {
      success: true,
      plotIndex,
      cropId: crop.id,
      cropNameEn: crop.nameEn,
      cropNameAr: crop.nameAr,
      xpGained: crop.xpReward,
      newLevel,
      newXp,
      leveledUp
    };

    if (actionDocRef) {
      tx.set(actionDocRef, {
        action: "harvestCrop",
        requestId,
        timestamp: now,
        result
      });
    }

    return result;
  });
});

/**
 * 3. harvestAll
 */
exports.harvestAll = onCall(async (request) => {
  const uid = requireAuth(request);
  const { requestId } = request.data || {};

  const userDocRef = db.collection("users").document(uid);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const plotsQuery = await tx.get(userDocRef.collection("plots"));
    const now = Date.now();
    const readyPlots = [];

    plotsQuery.forEach((doc) => {
      const p = doc.data();
      if (p.isUnlocked && p.cropId && (p.state === "READY" || (p.readyAt > 0 && now >= p.readyAt))) {
        readyPlots.push({ ref: doc.ref, data: p });
      }
    });

    if (readyPlots.length === 0) {
      return { success: true, harvestedCount: 0, totalXp: 0 };
    }

    const userSnap = await tx.get(userDocRef);
    const userData = userSnap.data() || {};
    let currentLevel = userData.level || 1;
    let currentXp = userData.xp || 0;
    let totalHarvests = userData.totalHarvests || 0;
    let gainedXp = 0;

    const inventoryUpdates = {};

    for (const item of readyPlots) {
      const crop = CROPS[item.data.cropId];
      if (!crop) continue;

      gainedXp += crop.xpReward;
      totalHarvests += 1;

      const cropItemId = `crop_${crop.id}`;
      inventoryUpdates[cropItemId] = (inventoryUpdates[cropItemId] || 0) + 1;

      tx.update(item.ref, {
        cropId: null,
        plantedAt: 0,
        readyAt: 0,
        state: "EMPTY"
      });
    }

    for (const [itemId, addedQty] of Object.entries(inventoryUpdates)) {
      const itemRef = userDocRef.collection("inventory").document(itemId);
      const itemSnap = await tx.get(itemRef);
      const existing = itemSnap.exists ? (itemSnap.data().quantity || 0) : 0;
      tx.set(itemRef, {
        itemId,
        category: "CROP",
        quantity: existing + addedQty
      });
    }

    const { newLevel, newXp, leveledUp } = calculateLevelAndXp(currentLevel, currentXp, gainedXp);

    tx.update(userDocRef, {
      level: newLevel,
      xp: newXp,
      totalHarvests
    });

    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "HARVEST_ALL",
      descEn: `Harvested ${readyPlots.length} crops (+${gainedXp} XP)`,
      descAr: `تم حصاد ${readyPlots.length} محاصيل (+${gainedXp} نقطة خبرة)`,
      amountCoins: 0,
      amountXp: gainedXp,
      timestamp: now
    });

    const result = {
      success: true,
      harvestedCount: readyPlots.length,
      totalXp: gainedXp,
      newLevel,
      newXp,
      leveledUp
    };

    if (actionDocRef) {
      tx.set(actionDocRef, {
        action: "harvestAll",
        requestId,
        timestamp: now,
        result
      });
    }

    return result;
  });
});

/**
 * 4. buySeeds
 */
exports.buySeeds = onCall(async (request) => {
  const uid = requireAuth(request);
  const { cropId, quantity, requestId } = request.data || {};

  if (!cropId || !quantity || quantity <= 0) {
    throw new HttpsError("invalid-argument", "cropId and positive quantity are required.");
  }

  const crop = CROPS[cropId];
  if (!crop) {
    throw new HttpsError("invalid-argument", `Unknown crop: ${cropId}`);
  }

  const totalCost = crop.buySeedPrice * quantity;
  const userDocRef = db.collection("users").document(uid);
  const seedItemId = `${cropId}_seed`;
  const seedDocRef = userDocRef.collection("inventory").document(seedItemId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const userSnap = await tx.get(userDocRef);
    if (!userSnap.exists) throw new HttpsError("not-found", "User profile not found.");
    const user = userSnap.data();
    const currentCoins = user.coins || 0;
    const currentLevel = user.level || 1;

    if (currentLevel < crop.unlockLevel) {
      throw new HttpsError("failed-precondition", `Requires Level ${crop.unlockLevel}.`);
    }

    if (currentCoins < totalCost) {
      throw new HttpsError("failed-precondition", `Not enough coins. Need ${totalCost}, have ${currentCoins}.`);
    }

    const seedSnap = await tx.get(seedDocRef);
    const existingQty = seedSnap.exists ? (seedSnap.data().quantity || 0) : 0;

    tx.update(userDocRef, {
      coins: currentCoins - totalCost
    });

    tx.set(seedDocRef, {
      itemId: seedItemId,
      category: "SEED",
      quantity: existingQty + quantity
    });

    const now = Date.now();
    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "BUY_SEEDS",
      descEn: `Purchased ${quantity}x ${crop.nameEn} Seeds (-${totalCost} Coins)`,
      descAr: `شراء ${quantity}x بذور ${crop.nameAr} (-${totalCost} قطعة نقدية)`,
      amountCoins: -totalCost,
      amountXp: 0,
      timestamp: now
    });

    const result = {
      success: true,
      cropId,
      quantity,
      cost: totalCost,
      remainingCoins: currentCoins - totalCost
    };

    if (actionDocRef) {
      tx.set(actionDocRef, {
        action: "buySeeds",
        requestId,
        timestamp: now,
        result
      });
    }

    return result;
  });
});

/**
 * 5. sellCrop / sellItem
 */
exports.sellCrop = onCall(async (request) => {
  const uid = requireAuth(request);
  const { itemId, quantity, requestId } = request.data || {};

  if (!itemId || !quantity || quantity <= 0) {
    throw new HttpsError("invalid-argument", "itemId and positive quantity are required.");
  }

  let unitPrice = 0;
  let itemNameEn = itemId;
  let itemNameAr = itemId;

  if (itemId.startsWith("crop_")) {
    const cropId = itemId.replace("crop_", "");
    const crop = CROPS[cropId];
    if (crop) {
      unitPrice = crop.sellPrice;
      itemNameEn = crop.nameEn;
      itemNameAr = crop.nameAr;
    }
  } else if (itemId === "egg") {
    unitPrice = 45;
    itemNameEn = "Fresh Egg";
    itemNameAr = "بيض طازج";
  } else if (itemId === "milk") {
    unitPrice = 120;
    itemNameEn = "Pure Milk";
    itemNameAr = "حليب صافي";
  } else if (itemId === "wool") {
    unitPrice = 280;
    itemNameEn = "Soft Wool";
    itemNameAr = "صوف ناعم";
  } else if (itemId.startsWith("item_")) {
    const recipeId = itemId.replace("item_", "");
    const recipe = RECIPES[recipeId];
    if (recipe) {
      unitPrice = recipe.sellPrice;
      itemNameEn = recipe.nameEn;
      itemNameAr = recipe.nameAr;
    }
  }

  if (unitPrice <= 0) {
    throw new HttpsError("invalid-argument", `Unknown sellable item: ${itemId}`);
  }

  const totalEarned = unitPrice * quantity;
  const userDocRef = db.collection("users").document(uid);
  const itemDocRef = userDocRef.collection("inventory").document(itemId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const itemSnap = await tx.get(itemDocRef);
    if (!itemSnap.exists) throw new HttpsError("failed-precondition", "Item not in inventory.");
    const existingQty = itemSnap.data().quantity || 0;

    if (existingQty < quantity) {
      throw new HttpsError("failed-precondition", `Not enough items to sell. Have ${existingQty}, requested ${quantity}.`);
    }

    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const currentCoins = user.coins || 0;
    const totalCoinsEarned = user.totalCoinsEarned || 0;

    if (existingQty === quantity) {
      tx.delete(itemDocRef);
    } else {
      tx.update(itemDocRef, { quantity: existingQty - quantity });
    }

    tx.update(userDocRef, {
      coins: currentCoins + totalEarned,
      totalCoinsEarned: totalCoinsEarned + totalEarned
    });

    const now = Date.now();
    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "SELL_ITEM",
      descEn: `Sold ${quantity}x ${itemNameEn} (+${totalEarned} Coins)`,
      descAr: `بيع ${quantity}x ${itemNameAr} (+${totalEarned} قطعة نقدية)`,
      amountCoins: totalEarned,
      amountXp: 0,
      timestamp: now
    });

    const result = {
      success: true,
      itemId,
      quantity,
      coinsEarned: totalEarned,
      newCoins: currentCoins + totalEarned
    };

    if (actionDocRef) {
      tx.set(actionDocRef, {
        action: "sellCrop",
        requestId,
        timestamp: now,
        result
      });
    }

    return result;
  });
});

/**
 * 6. buyAnimal
 */
exports.buyAnimal = onCall(async (request) => {
  const uid = requireAuth(request);
  const { animalType, requestId } = request.data || {};

  const config = ANIMALS[animalType];
  if (!config) throw new HttpsError("invalid-argument", `Unknown animal: ${animalType}`);

  const userDocRef = db.collection("users").document(uid);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const coins = user.coins || 0;
    const level = user.level || 1;

    if (level < config.requiredLevel) {
      throw new HttpsError("failed-precondition", `Requires Level ${config.requiredLevel}.`);
    }
    if (coins < config.purchaseCost) {
      throw new HttpsError("failed-precondition", `Requires ${config.purchaseCost} Coins.`);
    }

    const animalDocRef = userDocRef.collection("animals").document();
    tx.update(userDocRef, { coins: coins - config.purchaseCost });

    tx.set(animalDocRef, {
      animalId: animalDocRef.id,
      animalType,
      name: `${config.nameEn} #${animalDocRef.id.substring(0, 4)}`,
      fedAt: 0,
      readyAt: 0,
      state: "HUNGRY"
    });

    const now = Date.now();
    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "BUY_ANIMAL",
      descEn: `Adopted ${config.nameEn} (-${config.purchaseCost} Coins)`,
      descAr: `شراء ${config.nameAr} (-${config.purchaseCost} قطعة نقدية)`,
      amountCoins: -config.purchaseCost,
      amountXp: 0,
      timestamp: now
    });

    const result = {
      success: true,
      animalId: animalDocRef.id,
      animalType,
      remainingCoins: coins - config.purchaseCost
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "buyAnimal", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 7. feedAnimal
 */
exports.feedAnimal = onCall(async (request) => {
  const uid = requireAuth(request);
  const { animalId, requestId } = request.data || {};

  if (!animalId) throw new HttpsError("invalid-argument", "animalId is required.");

  const userDocRef = db.collection("users").document(uid);
  const animalDocRef = userDocRef.collection("animals").document(animalId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const animalSnap = await tx.get(animalDocRef);
    if (!animalSnap.exists) throw new HttpsError("not-found", "Animal not found.");
    const animal = animalSnap.data();

    if (animal.state !== "HUNGRY") {
      throw new HttpsError("failed-precondition", "Animal is already producing or ready.");
    }

    const config = ANIMALS[animal.animalType];
    if (!config) throw new HttpsError("invalid-argument", "Unknown animal type.");

    const feedDocRef = userDocRef.collection("inventory").document(config.feedItemId);
    const feedSnap = await tx.get(feedDocRef);
    if (!feedSnap.exists || (feedSnap.data().quantity || 0) <= 0) {
      throw new HttpsError("failed-precondition", `Need 1x ${config.feedItemId} to feed this animal.`);
    }

    const feedQty = feedSnap.data().quantity;
    if (feedQty === 1) {
      tx.delete(feedDocRef);
    } else {
      tx.update(feedDocRef, { quantity: feedQty - 1 });
    }

    const now = Date.now();
    const readyAt = now + config.productionTimeSeconds * 1000;

    tx.update(animalDocRef, {
      fedAt: now,
      readyAt,
      state: "PRODUCING"
    });

    const result = {
      success: true,
      animalId,
      state: "PRODUCING",
      fedAt: now,
      readyAt
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "feedAnimal", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 8. collectAnimalProduct
 */
exports.collectAnimalProduct = onCall(async (request) => {
  const uid = requireAuth(request);
  const { animalId, requestId } = request.data || {};

  if (!animalId) throw new HttpsError("invalid-argument", "animalId is required.");

  const userDocRef = db.collection("users").document(uid);
  const animalDocRef = userDocRef.collection("animals").document(animalId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const animalSnap = await tx.get(animalDocRef);
    if (!animalSnap.exists) throw new HttpsError("not-found", "Animal not found.");
    const animal = animalSnap.data();

    const config = ANIMALS[animal.animalType];
    if (!config) throw new HttpsError("invalid-argument", "Unknown animal type.");

    const now = Date.now();
    if (animal.state !== "READY" && now < (animal.readyAt || 0)) {
      throw new HttpsError("failed-precondition", "Animal production is not finished yet.");
    }

    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const level = user.level || 1;
    const xp = user.xp || 0;
    const collections = user.totalAnimalCollections || 0;

    const productDocRef = userDocRef.collection("inventory").document(config.productItemId);
    const productSnap = await tx.get(productDocRef);
    const existingQty = productSnap.exists ? (productSnap.data().quantity || 0) : 0;

    tx.set(productDocRef, {
      itemId: config.productItemId,
      category: "ANIMAL_PRODUCT",
      quantity: existingQty + 1
    });

    tx.update(animalDocRef, {
      fedAt: 0,
      readyAt: 0,
      state: "HUNGRY"
    });

    const { newLevel, newXp, leveledUp } = calculateLevelAndXp(level, xp, config.xpReward);

    tx.update(userDocRef, {
      level: newLevel,
      xp: newXp,
      totalAnimalCollections: collections + 1
    });

    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "ANIMAL_COLLECT",
      descEn: `Collected 1x ${config.productItemId} (+${config.xpReward} XP)`,
      descAr: `جمع 1x ${config.nameAr} (+${config.xpReward} نقطة خبرة)`,
      amountCoins: 0,
      amountXp: config.xpReward,
      timestamp: now
    });

    const result = {
      success: true,
      animalId,
      productItemId: config.productItemId,
      xpGained: config.xpReward,
      newLevel,
      newXp,
      leveledUp
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "collectAnimalProduct", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 9. unlockBuilding
 */
exports.unlockBuilding = onCall(async (request) => {
  const uid = requireAuth(request);
  const { buildingId, requestId } = request.data || {};

  const config = BUILDINGS[buildingId];
  if (!config) throw new HttpsError("invalid-argument", `Unknown building: ${buildingId}`);

  const userDocRef = db.collection("users").document(uid);
  const buildingDocRef = userDocRef.collection("buildings").document(buildingId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const coins = user.coins || 0;
    const level = user.level || 1;

    if (level < config.unlockLevel) {
      throw new HttpsError("failed-precondition", `Requires Level ${config.unlockLevel}.`);
    }
    if (coins < config.unlockCost) {
      throw new HttpsError("failed-precondition", `Requires ${config.unlockCost} Coins.`);
    }

    tx.update(userDocRef, { coins: coins - config.unlockCost });
    tx.set(buildingDocRef, {
      buildingId,
      level: 1,
      isUnlocked: true,
      currentRecipeId: null,
      startedAt: 0,
      readyAt: 0,
      state: "IDLE"
    });

    const now = Date.now();
    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "UNLOCK_BUILDING",
      descEn: `Constructed ${config.nameEn} (-${config.unlockCost} Coins)`,
      descAr: `بناء ${config.nameAr} (-${config.unlockCost} قطعة نقدية)`,
      amountCoins: -config.unlockCost,
      amountXp: 50,
      timestamp: now
    });

    const result = {
      success: true,
      buildingId,
      remainingCoins: coins - config.unlockCost
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "unlockBuilding", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 10. startProduction
 */
exports.startProduction = onCall(async (request) => {
  const uid = requireAuth(request);
  const { buildingId, recipeId, requestId } = request.data || {};

  const recipe = RECIPES[recipeId];
  if (!recipe || recipe.buildingId !== buildingId) {
    throw new HttpsError("invalid-argument", `Invalid recipe: ${recipeId}`);
  }

  const userDocRef = db.collection("users").document(uid);
  const buildingDocRef = userDocRef.collection("buildings").document(buildingId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const buildingSnap = await tx.get(buildingDocRef);
    if (!buildingSnap.exists || !buildingSnap.data().isUnlocked) {
      throw new HttpsError("failed-precondition", "Building is locked or not constructed.");
    }
    const bData = buildingSnap.data();
    if (bData.state !== "IDLE") {
      throw new HttpsError("failed-precondition", "Building is currently busy crafting.");
    }

    // Check primary ingredient
    const inputDocRef = userDocRef.collection("inventory").document(recipe.inputItemId);
    const inputSnap = await tx.get(inputDocRef);
    if (!inputSnap.exists || (inputSnap.data().quantity || 0) < recipe.inputAmount) {
      throw new HttpsError("failed-precondition", `Requires ${recipe.inputAmount}x ${recipe.inputItemId}.`);
    }

    // Check secondary ingredient if required
    let secDocRef = null;
    let secQty = 0;
    if (recipe.secondaryInputItemId && recipe.secondaryInputAmount > 0) {
      secDocRef = userDocRef.collection("inventory").document(recipe.secondaryInputItemId);
      const secSnap = await tx.get(secDocRef);
      if (!secSnap.exists || (secSnap.data().quantity || 0) < recipe.secondaryInputAmount) {
        throw new HttpsError("failed-precondition", `Requires ${recipe.secondaryInputAmount}x ${recipe.secondaryInputItemId}.`);
      }
      secQty = secSnap.data().quantity;
    }

    // Deduct ingredients
    const inQty = inputSnap.data().quantity;
    if (inQty === recipe.inputAmount) {
      tx.delete(inputDocRef);
    } else {
      tx.update(inputDocRef, { quantity: inQty - recipe.inputAmount });
    }

    if (secDocRef) {
      if (secQty === recipe.secondaryInputAmount) {
        tx.delete(secDocRef);
      } else {
        tx.update(secDocRef, { quantity: secQty - recipe.secondaryInputAmount });
      }
    }

    const now = Date.now();
    const readyAt = now + recipe.productionTimeSeconds * 1000;

    tx.update(buildingDocRef, {
      currentRecipeId: recipeId,
      startedAt: now,
      readyAt,
      state: "PRODUCING"
    });

    const result = {
      success: true,
      buildingId,
      recipeId,
      startedAt: now,
      readyAt
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "startProduction", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 11. collectProduction
 */
exports.collectProduction = onCall(async (request) => {
  const uid = requireAuth(request);
  const { buildingId, requestId } = request.data || {};

  const userDocRef = db.collection("users").document(uid);
  const buildingDocRef = userDocRef.collection("buildings").document(buildingId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const buildingSnap = await tx.get(buildingDocRef);
    if (!buildingSnap.exists) throw new HttpsError("not-found", "Building not found.");
    const bData = buildingSnap.data();

    const recipe = RECIPES[bData.currentRecipeId];
    if (!recipe) throw new HttpsError("invalid-argument", "Invalid recipe state.");

    const now = Date.now();
    if (bData.state !== "READY" && now < (bData.readyAt || 0)) {
      throw new HttpsError("failed-precondition", "Production is still in progress.");
    }

    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const level = user.level || 1;
    const xp = user.xp || 0;
    const goodsProduced = user.totalGoodsProduced || 0;

    const outDocRef = userDocRef.collection("inventory").document(recipe.outputItemId);
    const outSnap = await tx.get(outDocRef);
    const existingOut = outSnap.exists ? (outSnap.data().quantity || 0) : 0;

    tx.set(outDocRef, {
      itemId: recipe.outputItemId,
      category: "PROCESSED",
      quantity: existingOut + recipe.outputAmount
    });

    tx.update(buildingDocRef, {
      currentRecipeId: null,
      startedAt: 0,
      readyAt: 0,
      state: "IDLE"
    });

    const { newLevel, newXp, leveledUp } = calculateLevelAndXp(level, xp, recipe.xpReward);

    tx.update(userDocRef, {
      level: newLevel,
      xp: newXp,
      totalGoodsProduced: goodsProduced + 1
    });

    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "PRODUCTION_COLLECT",
      descEn: `Crafted ${recipe.outputAmount}x ${recipe.nameEn} (+${recipe.xpReward} XP)`,
      descAr: `صناعة ${recipe.outputAmount}x ${recipe.nameAr} (+${recipe.xpReward} نقطة خبرة)`,
      amountCoins: 0,
      amountXp: recipe.xpReward,
      timestamp: now
    });

    const result = {
      success: true,
      buildingId,
      outputItemId: recipe.outputItemId,
      outputAmount: recipe.outputAmount,
      xpGained: recipe.xpReward,
      newLevel,
      newXp,
      leveledUp
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "collectProduction", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 12. claimDailyReward
 */
exports.claimDailyReward = onCall(async (request) => {
  const uid = requireAuth(request);
  const { requestId } = request.data || {};

  const userDocRef = db.collection("users").document(uid);
  const rewardDocRef = userDocRef.collection("dailyReward").document("daily_reward");
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const rewardSnap = await tx.get(rewardDocRef);
    const now = Date.now();
    let lastClaimedDay = 0;
    let lastClaimedAt = 0;

    if (rewardSnap.exists) {
      lastClaimedDay = rewardSnap.data().lastClaimedDay || 0;
      lastClaimedAt = rewardSnap.data().lastClaimedAt || 0;
    }

    const ONE_DAY_MS = 24 * 60 * 60 * 1000;
    if (lastClaimedAt > 0 && now - lastClaimedAt < ONE_DAY_MS) {
      throw new HttpsError("failed-precondition", "Daily reward already claimed today. Come back tomorrow!");
    }

    let nextDay = lastClaimedDay + 1;
    if (nextDay > 7 || (lastClaimedAt > 0 && now - lastClaimedAt > 48 * 60 * 60 * 1000)) {
      nextDay = 1; // reset streak if missed
    }

    const reward = DAILY_REWARDS[nextDay] || DAILY_REWARDS[1];
    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const coins = user.coins || 0;
    const gems = user.gems || 0;

    tx.update(userDocRef, {
      coins: coins + reward.coins,
      gems: gems + reward.gems
    });

    if (reward.seedId && reward.seedAmount > 0) {
      const seedDocRef = userDocRef.collection("inventory").document(reward.seedId);
      const seedSnap = await tx.get(seedDocRef);
      const existing = seedSnap.exists ? (seedSnap.data().quantity || 0) : 0;
      tx.set(seedDocRef, {
        itemId: reward.seedId,
        category: "SEED",
        quantity: existing + reward.seedAmount
      });
    }

    tx.set(rewardDocRef, {
      id: "daily_reward",
      lastClaimedDay: nextDay,
      lastClaimedAt: now
    });

    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "DAILY_REWARD",
      descEn: `Claimed Day ${nextDay} Daily Bounty (+${reward.coins} Coins, +${reward.gems} Gems)`,
      descAr: `استلام مكافأة اليوم ${nextDay} (+${reward.coins} قطعة نقدية، +${reward.gems} جوهرة)`,
      amountCoins: reward.coins,
      amountXp: 0,
      timestamp: now
    });

    const result = {
      success: true,
      day: nextDay,
      coins: reward.coins,
      gems: reward.gems,
      seedId: reward.seedId,
      seedAmount: reward.seedAmount
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "claimDailyReward", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 13. upgradeSilo
 */
exports.upgradeSilo = onCall(async (request) => {
  const uid = requireAuth(request);
  const { requestId } = request.data || {};

  const userDocRef = db.collection("users").document(uid);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const userSnap = await tx.get(userDocRef);
    if (!userSnap.exists) throw new HttpsError("not-found", "User not found.");
    const user = userSnap.data();
    const currentCapacity = user.storageCapacity || 100;
    const cost = getSiloUpgradeCost(currentCapacity);
    const currentCoins = user.coins || 0;

    if (currentCoins < cost) {
      throw new HttpsError("failed-precondition", `Need ${cost} coins to upgrade silo.`);
    }

    const newCapacity = currentCapacity + 50;
    tx.update(userDocRef, {
      coins: currentCoins - cost,
      storageCapacity: newCapacity
    });

    const now = Date.now();
    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "SILO_UPGRADE",
      descEn: `Upgraded Silo capacity to ${newCapacity} (-${cost} Coins)`,
      descAr: `ترقية سعة الصومعة إلى ${newCapacity} (-${cost} قطعة نقدية)`,
      amountCoins: -cost,
      amountXp: 0,
      timestamp: now
    });

    const result = {
      success: true,
      newCapacity,
      cost,
      remainingCoins: currentCoins - cost
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "upgradeSilo", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 14. expandLand
 */
exports.expandLand = onCall(async (request) => {
  const uid = requireAuth(request);
  const { plotIndex, requestId } = request.data || {};

  if (plotIndex === undefined) throw new HttpsError("invalid-argument", "plotIndex is required.");

  const expansion = LAND_EXPANSIONS[plotIndex];
  if (!expansion) throw new HttpsError("invalid-argument", "Invalid plot index.");

  const userDocRef = db.collection("users").document(uid);
  const plotDocRef = userDocRef.collection("plots").document(`plot_${plotIndex}`);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const plotSnap = await tx.get(plotDocRef);
    if (!plotSnap.exists) throw new HttpsError("not-found", "Plot not found.");
    if (plotSnap.data().isUnlocked) throw new HttpsError("failed-precondition", "Plot is already unlocked.");

    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const level = user.level || 1;
    const coins = user.coins || 0;

    if (level < expansion.unlockLevel) {
      throw new HttpsError("failed-precondition", `Requires Level ${expansion.unlockLevel}. Current level: ${level}.`);
    }
    if (coins < expansion.unlockCost) {
      throw new HttpsError("failed-precondition", `Requires ${expansion.unlockCost} Coins. Current coins: ${coins}.`);
    }

    tx.update(userDocRef, { coins: coins - expansion.unlockCost });
    tx.update(plotDocRef, {
      isUnlocked: true,
      state: "EMPTY",
      cropId: null,
      plantedAt: 0,
      readyAt: 0
    });

    const now = Date.now();
    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "EXPAND_LAND",
      descEn: `Unlocked Plot #${plotIndex + 1} (-${expansion.unlockCost} Coins)`,
      descAr: `فتح القطعة الزراعية #${plotIndex + 1} (-${expansion.unlockCost} قطعة نقدية)`,
      amountCoins: -expansion.unlockCost,
      amountXp: 0,
      timestamp: now
    });

    const result = {
      success: true,
      plotIndex,
      cost: expansion.unlockCost,
      remainingCoins: coins - expansion.unlockCost
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "expandLand", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 15. completeOrder
 */
exports.completeOrder = onCall(async (request) => {
  const uid = requireAuth(request);
  const { orderId, requestId } = request.data || {};

  if (!orderId) throw new HttpsError("invalid-argument", "orderId is required.");

  const userDocRef = db.collection("users").document(uid);
  const orderDocRef = userDocRef.collection("orders").document(orderId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const orderSnap = await tx.get(orderDocRef);
    if (!orderSnap.exists) throw new HttpsError("not-found", "Order not found.");
    const order = orderSnap.data();
    if (order.isCompleted) throw new HttpsError("failed-precondition", "Order is already completed.");

    const itemDocRef = userDocRef.collection("inventory").document(order.requiredItemId);
    const itemSnap = await tx.get(itemDocRef);
    if (!itemSnap.exists) throw new HttpsError("failed-precondition", "Required item not found in inventory.");
    const currentQty = itemSnap.data().quantity || 0;

    if (currentQty < order.requiredAmount) {
      throw new HttpsError("failed-precondition", `Insufficient items. Need ${order.requiredAmount}, have ${currentQty}.`);
    }

    if (currentQty === order.requiredAmount) {
      tx.delete(itemDocRef);
    } else {
      tx.update(itemDocRef, { quantity: currentQty - order.requiredAmount });
    }

    tx.update(orderDocRef, { isCompleted: true });

    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const coins = user.coins || 0;
    const totalCoinsEarned = user.totalCoinsEarned || 0;
    const currentLevel = user.level || 1;
    const currentXp = user.xp || 0;

    const { newLevel, newXp, leveledUp } = calculateLevelAndXp(currentLevel, currentXp, order.rewardXp);

    tx.update(userDocRef, {
      coins: coins + order.rewardCoins,
      totalCoinsEarned: totalCoinsEarned + order.rewardCoins,
      level: newLevel,
      xp: newXp
    });

    const now = Date.now();
    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "ORDER_COMPLETE",
      descEn: `Fulfilled order: ${order.titleEn} (+${order.rewardCoins} Coins, +${order.rewardXp} XP)`,
      descAr: `إكمال طلب: ${order.titleAr} (+${order.rewardCoins} قطعة نقدية، +${order.rewardXp} خبرة)`,
      amountCoins: order.rewardCoins,
      amountXp: order.rewardXp,
      timestamp: now
    });

    const result = {
      success: true,
      orderId,
      rewardCoins: order.rewardCoins,
      rewardXp: order.rewardXp,
      newLevel,
      newXp,
      leveledUp
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "completeOrder", requestId, timestamp: now, result });
    }

    return result;
  });
});

/**
 * 16. claimQuestReward
 */
exports.claimQuestReward = onCall(async (request) => {
  const uid = requireAuth(request);
  const { questId, requestId } = request.data || {};

  if (!questId) throw new HttpsError("invalid-argument", "questId is required.");

  const userDocRef = db.collection("users").document(uid);
  const questDocRef = userDocRef.collection("quests").document(questId);
  const actionDocRef = requestId ? userDocRef.collection("actions").document(requestId) : null;

  return await db.runTransaction(async (tx) => {
    if (actionDocRef) {
      const actionSnap = await tx.get(actionDocRef);
      if (actionSnap.exists) return actionSnap.data().result;
    }

    const questSnap = await tx.get(questDocRef);
    if (!questSnap.exists) throw new HttpsError("not-found", "Quest not found.");
    const quest = questSnap.data();
    if (quest.isClaimed) throw new HttpsError("failed-precondition", "Quest reward already claimed.");

    if ((quest.currentCount || 0) < (quest.targetCount || 0)) {
      throw new HttpsError("failed-precondition", "Quest objectives not yet completed.");
    }

    tx.update(questDocRef, { isClaimed: true });

    const userSnap = await tx.get(userDocRef);
    const user = userSnap.data() || {};
    const coins = user.coins || 0;
    const totalCoinsEarned = user.totalCoinsEarned || 0;
    const currentLevel = user.level || 1;
    const currentXp = user.xp || 0;

    const { newLevel, newXp, leveledUp } = calculateLevelAndXp(currentLevel, currentXp, quest.rewardXp);

    tx.update(userDocRef, {
      coins: coins + quest.rewardCoins,
      totalCoinsEarned: totalCoinsEarned + quest.rewardCoins,
      level: newLevel,
      xp: newXp
    });

    const now = Date.now();
    const txRef = userDocRef.collection("transactions").document();
    tx.set(txRef, {
      id: txRef.id,
      type: "QUEST_CLAIM",
      descEn: `Claimed Quest: ${quest.titleEn} (+${quest.rewardCoins} Coins, +${quest.rewardXp} XP)`,
      descAr: `استلام مكافأة المهمة: ${quest.titleAr} (+${quest.rewardCoins} قطعة نقدية، +${quest.rewardXp} خبرة)`,
      amountCoins: quest.rewardCoins,
      amountXp: quest.rewardXp,
      timestamp: now
    });

    const result = {
      success: true,
      questId,
      rewardCoins: quest.rewardCoins,
      rewardXp: quest.rewardXp,
      newLevel,
      newXp,
      leveledUp
    };

    if (actionDocRef) {
      tx.set(actionDocRef, { action: "claimQuestReward", requestId, timestamp: now, result });
    }

    return result;
  });
});
