const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();

    // Seed valid initial profile for Alice
    await testEnv.withSecurityRulesDisabled(async (context) => {
      const db = context.firestore();
      await db.collection("users").doc(ALICE_UID).set({
        uid: ALICE_UID,
        username: "Alice Farmer",
        farmName: "Sunny Meadow",
        level: 1,
        xp: 0,
        coins: 1000,
        gems: 10,
        storageCapacity: 100,
        totalHarvests: 0,
        totalCoinsEarned: 0,
        soundEnabled: true,
        hapticEnabled: true,
        language: "ar"
      });

      await db.collection("users").doc(ALICE_UID).collection("plots").doc("plot_0").set({
        plotIndex: 0,
        isUnlocked: true,
        state: "GROWING",
        cropId: "wheat",
        plantedAt: 1000,
        readyAt: 20000
      });

      await db.collection("users").doc(ALICE_UID).collection("inventory").doc("wheat_seed").set({
        itemId: "wheat_seed",
        category: "SEED",
        quantity: 5
      });
    });
  }
});

// --- ANTI-CHEAT & SECURITY AUDIT ATTACK TESTS ---

test("Attack 1: Modified client tries coins = 999999999 -> REJECTED", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      coins: 999999999
    })
  );
});

test("Attack 2: Modified client tries gems = 999999999 -> REJECTED", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      gems: 999999999
    })
  );
});

test("Attack 3: Modified client tries xp = 999999999 -> REJECTED", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).update({
      xp: 999999999
    })
  );
});

test("Attack 4: Modified client tries inventory.quantity = 999999 -> REJECTED", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("inventory").doc("wheat_seed").update({
      quantity: 999999
    })
  );
});

test("Attack 5: Modified client tries plot.state = READY -> REJECTED", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("plots").doc("plot_0").update({
      state: "READY"
    })
  );
});

test("Attack 6: Modified client tries plot.readyAt = past timestamp -> REJECTED", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("plots").doc("plot_0").update({
      readyAt: 1
    })
  );
});

test("Attack 7: Modified client tries to create fake transaction ledger record -> REJECTED", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("transactions").doc("fake_tx").set({
      amountCoins: 1000000,
      type: "CHEAT"
    })
  );
});

test("Attack 8: Modified client tries to modify another player's data -> REJECTED", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).update({
      farmName: "Hacked by Bob"
    })
  );
});

test("Attack 9: Unauthenticated client tries to read private inventory -> REJECTED", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("inventory").doc("wheat_seed").get()
  );
});

test("Legitimate: Owner can update safe client preferences (farmName, language, sound) -> SUCCEEDS", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).update({
      farmName: "Royal Golden Farm",
      language: "en",
      soundEnabled: false
    })
  );
});

// --- PHASE 5 SOCIAL WORLD SECURITY & VISITOR MODE TESTS ---

test("Social 1: Player A (Bob) can read Public Profile of Player B (Alice) -> SUCCEEDS", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("publicProfiles").doc(ALICE_UID).set({
      uid: ALICE_UID,
      displayName: "Alice Farmer",
      farmName: "Sunny Meadow",
      level: 5,
      likeCount: 10,
      visitorCount: 25
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(
    bobDb.collection("publicProfiles").doc(ALICE_UID).get()
  );
});

test("Social 2: Player A (Bob) CANNOT read private user document of Player B (Alice) -> REJECTED", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).get()
  );
});

test("Social 3: Player A (Bob) can read Public Farm Snapshot of Player B (Alice) -> SUCCEEDS", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("publicFarms").doc(ALICE_UID).set({
      uid: ALICE_UID,
      farmName: "Sunny Meadow",
      ownerName: "Alice Farmer",
      level: 5
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(
    bobDb.collection("publicFarms").doc(ALICE_UID).get()
  );
});

test("Social 4: Player A (Bob) CANNOT modify Public Farm Snapshot of Player B (Alice) -> REJECTED", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("publicFarms").doc(ALICE_UID).update({
      farmName: "Hacked Farm"
    })
  );
});

test("Social 5: Player A (Bob) CANNOT modify plots or inventory of Player B (Alice) -> REJECTED", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("plots").doc("plot_0").set({
      plotIndex: 0,
      isUnlocked: true,
      state: "EMPTY"
    })
  );
});

test("Social 6: Player A (Bob) can create a like document for Player B (Alice) -> SUCCEEDS", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(
    bobDb.collection("publicProfiles").doc(ALICE_UID).collection("likes").doc(BOB_UID).set({
      visitorUid: BOB_UID,
      createdAt: 10000
    })
  );
});

test("Social 7: Player A (Bob) CANNOT like own farm (Bob -> Bob) -> REJECTED", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("publicProfiles").doc(BOB_UID).collection("likes").doc(BOB_UID).set({
      visitorUid: BOB_UID,
      createdAt: 10000
    })
  );
});

test("Social 8: Visitor (Bob) CANNOT directly write likeCount on Player B -> REJECTED", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("publicProfiles").doc(ALICE_UID).update({
      likeCount: 999999
    })
  );
});

test("Social 9: Visitor (Bob) can record visit for Player B (Alice) -> SUCCEEDS", async () => {
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertSucceeds(
    bobDb.collection("publicProfiles").doc(ALICE_UID).collection("visits").doc(BOB_UID).set({
      visitorUid: BOB_UID,
      visitedAt: 10000
    })
  );
});

test("Social 10: Owner (Alice) can update her own Public Profile -> SUCCEEDS", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("publicProfiles").doc(ALICE_UID).set({
      uid: ALICE_UID,
      displayName: "Alice Farmer",
      farmName: "Sunny Meadow",
      level: 1
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb.collection("publicProfiles").doc(ALICE_UID).update({
      farmName: "Golden Acres",
      level: 2
    })
  );
});

test("Social 11: Owner (Alice) CANNOT directly modify likeCount or visitorCount -> REJECTED", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(
    aliceDb.collection("publicProfiles").doc(ALICE_UID).update({
      likeCount: 999999
    })
  );
  await assertFails(
    aliceDb.collection("publicProfiles").doc(ALICE_UID).update({
      visitorCount: 999999
    })
  );
});

test("Social 12: Visitor (Bob) CANNOT overwrite existing like document -> REJECTED", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("publicProfiles").doc(ALICE_UID).collection("likes").doc(BOB_UID).set({
      visitorUid: BOB_UID,
      createdAt: 1000
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("publicProfiles").doc(ALICE_UID).collection("likes").doc(BOB_UID).set({
      visitorUid: BOB_UID,
      createdAt: 5000
    })
  );
});


