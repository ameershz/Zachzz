package com.example.farm

import com.example.base.FirestoreEmulatorTestBase
import com.example.farm.data.remote.FirestoreFarmPlot
import com.example.farm.data.remote.FirestoreInventoryItem
import com.example.farm.data.remote.FirestoreUserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class FarmFirestoreRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun unauthenticatedUser_cannotReadProfile() = runTest {
        auth.signOut()
        try {
            firestore.collection("users").document("someone").get().await()
            fail("Expected unauthenticated read to fail")
        } catch (e: Exception) {
            assertTrue(e is FirebaseFirestoreException || e.message?.contains("PERMISSION_DENIED") == true)
        }
    }

    @Test
    fun owner_canCreateAndReadInitialProfile() = runTest {
        val aliceUid = signInTestUser("alice_farm@test.com")
        val profile = FirestoreUserProfile(
            uid = aliceUid,
            username = "Alice Queen",
            farmName = "Sunny Farm",
            level = 1,
            xp = 0,
            coins = 1000,
            gems = 10,
            storageCapacity = 100
        )

        val docRef = firestore.collection("users").document(aliceUid)
        docRef.set(profile).await()

        val snapshot = docRef.get().await()
        assertTrue(snapshot.exists())
        val loaded = snapshot.toObject(FirestoreUserProfile::class.java)
        assertNotNull(loaded)
        assertEquals(aliceUid, loaded?.uid)
        assertEquals(1000, loaded?.coins)
    }

    @Test
    fun modifiedClient_cannotDirectlyModifyCoins() = runTest {
        val aliceUid = signInTestUser("alice_coins_attack@test.com")
        val docRef = firestore.collection("users").document(aliceUid)

        // Seed initial profile
        docRef.set(
            FirestoreUserProfile(
                uid = aliceUid,
                username = "Alice",
                farmName = "Sunny Farm",
                level = 1,
                xp = 0,
                coins = 1000,
                gems = 10,
                storageCapacity = 100
            )
        ).await()

        // Attack: attempt direct client modification of coins
        try {
            docRef.update("coins", 999999999).await()
            fail("Expected direct coins update to fail with PERMISSION_DENIED")
        } catch (e: Exception) {
            assertTrue(e is FirebaseFirestoreException || e.message?.contains("PERMISSION_DENIED") == true)
        }
    }

    @Test
    fun modifiedClient_cannotDirectlyModifyInventory() = runTest {
        val aliceUid = signInTestUser("alice_inv_attack@test.com")
        val itemRef = firestore.collection("users").document(aliceUid)
            .collection("inventory").document("wheat_seed")

        try {
            itemRef.set(mapOf("quantity" to 999999)).await()
            fail("Expected direct inventory modification to fail with PERMISSION_DENIED")
        } catch (e: Exception) {
            assertTrue(e is FirebaseFirestoreException || e.message?.contains("PERMISSION_DENIED") == true)
        }
    }

    @Test
    fun modifiedClient_cannotDirectlyModifyPlotState() = runTest {
        val aliceUid = signInTestUser("alice_plot_attack@test.com")
        val plotRef = firestore.collection("users").document(aliceUid)
            .collection("plots").document("plot_0")

        // Seed initial empty plot
        plotRef.set(
            FirestoreFarmPlot(
                plotIndex = 0,
                isUnlocked = true,
                state = "EMPTY"
            )
        ).await()

        // Attack: attempt to directly change plot state to READY
        try {
            plotRef.update("state", "READY").await()
            fail("Expected direct plot update to fail with PERMISSION_DENIED")
        } catch (e: Exception) {
            assertTrue(e is FirebaseFirestoreException || e.message?.contains("PERMISSION_DENIED") == true)
        }
    }

    @Test
    fun crossUser_cannotWriteToAnotherUsersPlots() = runTest {
        val aliceUid = signInTestUser("alice_cross@test.com")
        // Sign in as Bob
        val bobUid = signInTestUser("bob_cross@test.com")

        val plot = FirestoreFarmPlot(
            plotIndex = 0,
            isUnlocked = true,
            state = "EMPTY"
        )

        try {
            firestore.collection("users").document(aliceUid)
                .collection("plots").document("plot_0")
                .set(plot).await()
            fail("Expected cross-user write to fail with PERMISSION_DENIED")
        } catch (e: Exception) {
            assertTrue(e is FirebaseFirestoreException || e.message?.contains("PERMISSION_DENIED") == true)
        }
    }

    @Test
    fun owner_canUpdateSafePreferences() = runTest {
        val aliceUid = signInTestUser("alice_pref@test.com")
        val docRef = firestore.collection("users").document(aliceUid)

        docRef.set(
            FirestoreUserProfile(
                uid = aliceUid,
                username = "Alice",
                farmName = "Sunny Farm",
                level = 1,
                xp = 0,
                coins = 1000,
                gems = 10,
                storageCapacity = 100
            )
        ).await()

        // Update non-authoritative preferences
        docRef.update(
            mapOf(
                "farmName" to "Emerald Kingdom",
                "soundEnabled" to false,
                "language" to "en"
            )
        ).await()

        val snap = docRef.get().await()
        assertEquals("Emerald Kingdom", snap.getString("farmName"))
        assertEquals(false, snap.getBoolean("soundEnabled"))
        assertEquals("en", snap.getString("language"))
    }
}
