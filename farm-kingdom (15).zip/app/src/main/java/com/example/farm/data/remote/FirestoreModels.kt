package com.example.farm.data.remote

import com.google.firebase.firestore.PropertyName

data class FirestoreUserProfile(
    val uid: String = "",
    val username: String = "Farmer",
    val farmName: String = "Green Meadow Farm",
    val level: Int = 1,
    val xp: Int = 0,
    val coins: Int = 1000,
    val gems: Int = 10,
    val storageCapacity: Int = 100,
    val totalHarvests: Int = 0,
    val totalCoinsEarned: Long = 0L,
    val totalAnimalCollections: Int = 0,
    val totalGoodsProduced: Int = 0,
    val soundEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
    val language: String = "ar",
    val schemaVersion: Int = 3,
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = System.currentTimeMillis()
)

data class FirestoreFarmPlot(
    val plotIndex: Int = 0,
    @get:PropertyName("isUnlocked") @set:PropertyName("isUnlocked")
    var isUnlocked: Boolean = false,
    val unlockLevel: Int = 1,
    val unlockCost: Int = 0,
    val cropId: String? = null,
    val plantedAt: Long = 0L,
    val readyAt: Long = 0L,
    val state: String = "EMPTY" // LOCKED, EMPTY, GROWING, READY
)

data class FirestoreInventoryItem(
    val itemId: String = "",
    val category: String = "SEED", // SEED, CROP, ANIMAL_PRODUCT, PROCESSED, MATERIAL
    val quantity: Int = 0
)

data class FirestoreAnimal(
    val animalId: String = "",
    val animalType: String = "chicken", // chicken, cow, sheep
    val name: String = "",
    val fedAt: Long = 0L,
    val readyAt: Long = 0L,
    val state: String = "HUNGRY" // HUNGRY, PRODUCING, READY
)

data class FirestoreProductionBuilding(
    val buildingId: String = "", // bakery, dairy, textile_mill
    val level: Int = 1,
    @get:PropertyName("isUnlocked") @set:PropertyName("isUnlocked")
    var isUnlocked: Boolean = false,
    val unlockLevel: Int = 4,
    val unlockCost: Int = 750,
    val currentRecipeId: String? = null,
    val startedAt: Long = 0L,
    val readyAt: Long = 0L,
    val state: String = "IDLE" // LOCKED, IDLE, PRODUCING, READY
)

data class FirestoreDailyReward(
    val id: String = "daily_reward",
    val lastClaimedDay: Int = 0,
    val lastClaimedAt: Long = 0L
)

data class FirestoreDailyOrder(
    val orderId: String = "",
    val titleEn: String = "",
    val titleAr: String = "",
    val requiredItemId: String = "",
    val requiredAmount: Int = 0,
    val rewardCoins: Int = 0,
    val rewardXp: Int = 0,
    @get:PropertyName("isCompleted") @set:PropertyName("isCompleted")
    var isCompleted: Boolean = false,
    val expiresAt: Long = 0L
)

data class FirestoreQuest(
    val questId: String = "",
    val titleEn: String = "",
    val titleAr: String = "",
    val descEn: String = "",
    val descAr: String = "",
    val questType: String = "",
    val targetCount: Int = 0,
    val currentCount: Int = 0,
    val rewardCoins: Int = 0,
    val rewardXp: Int = 0,
    @get:PropertyName("isClaimed") @set:PropertyName("isClaimed")
    var isClaimed: Boolean = false
)

data class FirestoreTransaction(
    val id: String = "",
    val type: String = "",
    val descEn: String = "",
    val descAr: String = "",
    val amountCoins: Int = 0,
    val amountXp: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

data class FirestorePublicProfile(
    val uid: String = "",
    val displayName: String = "Farmer",
    val farmName: String = "Green Meadow Farm",
    val avatarId: String = "avatar_1",
    val level: Int = 1,
    val unlockedLandCount: Int = 4,
    val visitorCount: Int = 0,
    val likeCount: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)

data class FirestorePublicFarm(
    val uid: String = "",
    val farmName: String = "Green Meadow Farm",
    val ownerName: String = "Farmer",
    val level: Int = 1,
    val plots: List<FirestoreFarmPlot> = emptyList(),
    val animals: List<FirestoreAnimal> = emptyList(),
    val buildings: List<FirestoreProductionBuilding> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class FirestoreLike(
    val visitorUid: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class FirestoreVisit(
    val visitorUid: String = "",
    val visitedAt: Long = System.currentTimeMillis()
)

