package com.example.farm.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.config.GameConfig
import com.example.farm.data.local.AnimalEntity
import com.example.farm.data.local.ProductionBuildingEntity
import com.example.farm.ui.viewmodel.FarmViewModel
import com.example.farm.ui.viewmodel.MainTab

@Composable
fun ProductionScreen(
    viewModel: FarmViewModel,
    modifier: Modifier = Modifier
) {
    val player by viewModel.player.collectAsState()
    val animals by viewModel.animals.collectAsState()
    val buildings by viewModel.productionBuildings.collectAsState()
    val inventory by viewModel.inventory.collectAsState()
    val currentTime by viewModel.currentTime.collectAsState()
    val isArabic = player?.language == "ar"

    var selectedSubTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sub-tabs Header
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = {
                    Text(
                        text = if (isArabic) "حيوانات المزرعة 🐄" else "Livestock 🐄",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = {
                    Text(
                        text = if (isArabic) "المصانع والمخابز 🏭" else "Workshops 🏭",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            )
        }

        if (selectedSubTab == 0) {
            // Animals Livestock List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isArabic) "الحظيرة والرعاية (${animals.size})" else "Barn & Pasture (${animals.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        OutlinedButton(
                            onClick = { viewModel.setTab(MainTab.SHOP) },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(if (isArabic) "شراء حيوان" else "Adopt Animal", fontSize = 13.sp)
                        }
                    }
                }

                if (animals.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🐓", fontSize = 48.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = if (isArabic) "لا توجد حيوانات في مزرعتك بعد" else "No animals on your farm yet",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = if (isArabic) "زر المتجر لتبني دجاج أو أبقار أو خراف!" else "Visit the Shop to adopt Chickens, Cows or Sheep!",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(animals, key = { it.animalId }) { animal ->
                        AnimalItemCard(
                            animal = animal,
                            currentTime = currentTime,
                            inventory = inventory,
                            isArabic = isArabic,
                            onFeed = { viewModel.feedAnimal(animal.animalId) },
                            onCollect = { viewModel.collectAnimalProduct(animal.animalId) }
                        )
                    }
                }
            }
        } else {
            // Production Workshops List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = if (isArabic) "المعامل وخطوط الإنتاج" else "Artisan Production Lines",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                items(GameConfig.BUILDINGS, key = { it.id }) { bConfig ->
                    val buildingEntity = buildings.find { it.buildingId == bConfig.id }
                    val playerLevel = player?.level ?: 1
                    val playerCoins = player?.coins ?: 0

                    WorkshopBuildingCard(
                        config = bConfig,
                        entity = buildingEntity,
                        playerLevel = playerLevel,
                        playerCoins = playerCoins,
                        inventory = inventory,
                        currentTime = currentTime,
                        isArabic = isArabic,
                        onUnlock = { viewModel.unlockBuilding(bConfig.id) },
                        onStartProduction = { recipeId -> viewModel.startProduction(bConfig.id, recipeId) },
                        onCollect = { viewModel.collectProduction(bConfig.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun AnimalItemCard(
    animal: AnimalEntity,
    currentTime: Long,
    inventory: List<com.example.farm.data.local.InventoryItemEntity>,
    isArabic: Boolean,
    onFeed: () -> Unit,
    onCollect: () -> Unit
) {
    val config = GameConfig.getAnimalById(animal.animalType) ?: return
    val feedItem = inventory.find { it.itemId == config.feedItemId }
    val feedQty = feedItem?.quantity ?: 0

    val isProducing = animal.state == "PRODUCING" && animal.readyAt > currentTime
    val isReady = animal.state == "READY" || (animal.state == "PRODUCING" && animal.readyAt in 1..currentTime)

    val totalDuration = config.productionTimeSeconds * 1000f
    val elapsed = if (animal.fedAt > 0) (currentTime - animal.fedAt).coerceAtLeast(0L).toFloat() else 0f
    val progress = if (totalDuration > 0) (elapsed / totalDuration).coerceIn(0f, 1f) else 0f

    val remainingSec = if (animal.readyAt > currentTime) ((animal.readyAt - currentTime) / 1000).coerceAtLeast(0) else 0

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isReady) Color(0xFFF1F8E9) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFF9C4)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(config.emoji, fontSize = 28.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isArabic) config.nameAr else config.nameEn,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${if (isArabic) "المنتج:" else "Yields:"} ${if (isArabic) config.productNameAr else config.productNameEn} (+${config.xpReward} XP)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Status Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            when {
                                isReady -> Color(0xFF2E7D32)
                                isProducing -> Color(0xFF1976D2)
                                else -> Color(0xFFE65100)
                            }
                        )
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = when {
                            isReady -> if (isArabic) "جاهز للجمع! ✨" else "Ready! ✨"
                            isProducing -> "${remainingSec}s ⏳"
                            else -> if (isArabic) "جائع 🍽️" else "Hungry 🍽️"
                        },
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (isProducing) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Color(0xFF4CAF50),
                    trackColor = Color(0xFFE0E0E0)
                )
            }

            Spacer(Modifier.height(12.dp))

            // Action Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                when {
                    isReady -> {
                        Button(
                            onClick = onCollect,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isArabic) "جمع المحصول" else "Collect Product", fontWeight = FontWeight.Bold)
                        }
                    }
                    isProducing -> {
                        Text(
                            text = if (isArabic) "جارِ إنتاج ${config.productNameAr}... ⏳" else "Producing ${config.productNameEn}... ⏳",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                    }
                    else -> {
                        Button(
                            onClick = onFeed,
                            enabled = feedQty > 0,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Restaurant, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "${if (isArabic) "إطعام" else "Feed"} (${if (isArabic) config.feedItemNameAr else config.feedItemNameEn}: $feedQty)",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WorkshopBuildingCard(
    config: com.example.farm.data.config.BuildingConfig,
    entity: ProductionBuildingEntity?,
    playerLevel: Int,
    playerCoins: Int,
    inventory: List<com.example.farm.data.local.InventoryItemEntity>,
    currentTime: Long,
    isArabic: Boolean,
    onUnlock: () -> Unit,
    onStartProduction: (String) -> Unit,
    onCollect: () -> Unit
) {
    val isUnlocked = entity?.isUnlocked == true
    val recipes = GameConfig.RECIPES.filter { it.buildingId == config.id }

    val activeRecipe = recipes.find { it.id == entity?.currentRecipeId }
    val isProducing = entity?.state == "PRODUCING" && (entity.readyAt > currentTime)
    val isReady = entity?.state == "READY" || (entity?.state == "PRODUCING" && entity.readyAt in 1..currentTime)

    val totalDuration = (activeRecipe?.productionTimeSeconds ?: 30L) * 1000f
    val elapsed = if ((entity?.startedAt ?: 0L) > 0) (currentTime - entity!!.startedAt).coerceAtLeast(0L).toFloat() else 0f
    val progress = if (totalDuration > 0) (elapsed / totalDuration).coerceIn(0f, 1f) else 0f
    val remainingSec = if ((entity?.readyAt ?: 0L) > currentTime) ((entity!!.readyAt - currentTime) / 1000).coerceAtLeast(0) else 0

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (!isUnlocked) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE1F5FE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(config.emoji, fontSize = 28.sp)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isArabic) config.nameAr else config.nameEn,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isArabic) config.descriptionAr else config.descriptionEn,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (!isUnlocked) {
                    Icon(Icons.Filled.Lock, contentDescription = null, tint = Color.Gray)
                }
            }

            Spacer(Modifier.height(12.dp))

            if (!isUnlocked) {
                // Locked View with Construct button
                val canUnlock = playerLevel >= config.unlockLevel && playerCoins >= config.unlockCost
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${if (isArabic) "المستوى المطلوب:" else "Requires:"} Lv ${config.unlockLevel} • ${config.unlockCost} 🪙",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (canUnlock) MaterialTheme.colorScheme.primary else Color.Red
                    )

                    Button(
                        onClick = onUnlock,
                        enabled = canUnlock,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (isArabic) "بناء المصنع 🏗️" else "Construct 🏗️", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                // Unlocked View
                if (isReady) {
                    // Collect finished product
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(activeRecipe?.emoji ?: "📦", fontSize = 24.sp)
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = if (isArabic) (activeRecipe?.outputNameAr ?: "المنتج") else (activeRecipe?.outputNameEn ?: "Product"),
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "+${activeRecipe?.xpReward ?: 0} XP",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF2E7D32)
                                    )
                                }
                            }

                            Button(
                                onClick = onCollect,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(if (isArabic) "استلام 🧺" else "Collect 🧺", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else if (isProducing) {
                    // In Progress Bar
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${if (isArabic) "جارِ تصنيع:" else "Crafting:"} ${if (isArabic) activeRecipe?.nameAr else activeRecipe?.nameEn}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${remainingSec}s ⏳",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = Color(0xFF1976D2),
                            trackColor = Color(0xFFE0E0E0)
                        )
                    }
                } else {
                    // Idle - Recipe selector
                    Text(
                        text = if (isArabic) "الوصفات المتاحة للتصنيع:" else "Available Crafting Recipes:",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        recipes.forEach { recipe ->
                            val in1 = inventory.find { it.itemId == recipe.inputItemId }
                            val in1Qty = in1?.quantity ?: 0
                            var hasAll = in1Qty >= recipe.inputAmount

                            var in2Qty = 0
                            if (recipe.secondaryInputItemId != null && recipe.secondaryInputAmount > 0) {
                                val in2 = inventory.find { it.itemId == recipe.secondaryInputItemId }
                                in2Qty = in2?.quantity ?: 0
                                if (in2Qty < recipe.secondaryInputAmount) hasAll = false
                            }

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(recipe.emoji, fontSize = 24.sp)
                                        Spacer(Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = if (isArabic) recipe.nameAr else recipe.nameEn,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = "${recipe.inputAmount}x ${if (isArabic) recipe.inputItemNameAr else recipe.inputItemNameEn} ($in1Qty)" +
                                                        if (recipe.secondaryInputItemId != null) " + ${recipe.secondaryInputAmount}x ${if (isArabic) recipe.secondaryInputNameAr else recipe.secondaryInputNameEn} ($in2Qty)" else "",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = if (hasAll) Color(0xFF2E7D32) else Color(0xFFC62828)
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { onStartProduction(recipe.id) },
                                        enabled = hasAll,
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(if (isArabic) "صناعة" else "Craft", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
