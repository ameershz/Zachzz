package com.example.farm.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Agriculture
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.local.FarmPlotEntity
import com.example.farm.data.local.PlayerProfileEntity
import com.example.farm.ui.components.PlotCard
import com.example.farm.ui.localization.GameStrings
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary

@Composable
fun FarmGridScreen(
    player: PlayerProfileEntity?,
    plots: List<FarmPlotEntity>,
    currentTime: Long,
    isAr: Boolean,
    onPlantClick: (FarmPlotEntity) -> Unit,
    onHarvestClick: (Int) -> Unit,
    onUnlockClick: (Int) -> Unit,
    onHarvestAllClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val readyPlotsCount = plots.count {
        it.state == "READY" || (it.state == "GROWING" && it.readyAt > 0 && currentTime >= it.readyAt)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFFE8F5E9),
                        Color(0xFFC8E6C9),
                        Color(0xFFA5D6A7)
                    )
                )
            )
    ) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 88.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Farm Ambiance & Season Header Banner
            item(span = { GridItemSpan(3) }) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = FarmGreenDark),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🏡", fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (isAr) "مزرعة المملكة الخضراء" else "Kingdom Verdant Fields",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (isAr) "الموسم: ربيع مشمس ☀️ • إنتاج نشط" else "Season: Sunny Spring ☀️ • Active",
                                    color = FarmGoldWheat,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Weather Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "🌤️ 24°C",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Grid of Plots
            items(plots, key = { it.plotIndex }) { plot ->
                PlotCard(
                    plot = plot,
                    currentTime = currentTime,
                    isAr = isAr,
                    onPlantClick = { onPlantClick(plot) },
                    onHarvestClick = { onHarvestClick(plot.plotIndex) },
                    onUnlockClick = { onUnlockClick(plot.plotIndex) }
                )
            }
        }

        // Quick Harvest All Floating Button when plots are ready
        AnimatedVisibility(
            visible = readyPlotsCount > 0,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 16.dp)
        ) {
            ExtendedFloatingActionButton(
                onClick = onHarvestAllClick,
                containerColor = FarmGoldWheat,
                contentColor = Color(0xFF3E2723),
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
                shape = RoundedCornerShape(20.dp),
                icon = {
                    Icon(
                        imageVector = Icons.Default.Agriculture,
                        contentDescription = "Harvest All",
                        modifier = Modifier.size(24.dp)
                    )
                },
                text = {
                    Text(
                        text = if (isAr) "احصد الكل ($readyPlotsCount)" else "Harvest All ($readyPlotsCount)",
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                },
                modifier = Modifier.testTag("harvest_all_fab")
            )
        }
    }
}
