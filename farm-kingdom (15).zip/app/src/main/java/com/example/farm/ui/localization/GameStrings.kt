package com.example.farm.ui.localization

object GameStrings {
    fun t(key: String, isAr: Boolean): String {
        return if (isAr) AR[key] ?: EN[key] ?: key else EN[key] ?: key
    }

    private val EN = mapOf(
        "app_title" to "Farm Kingdom",
        "tab_farm" to "Farm",
        "tab_shop" to "Shop",
        "tab_silo" to "Silo",
        "tab_orders" to "Orders",
        "tab_profile" to "Profile",
        "tab_settings" to "Settings",

        // Farm
        "plot_empty" to "Empty Soil",
        "plot_ready" to "Harvest Ready!",
        "plot_growing" to "Growing...",
        "plot_locked" to "Locked Land",
        "tap_to_plant" to "Tap to Plant",
        "tap_to_harvest" to "Tap to Harvest!",
        "expand_cost" to "Expand Plot: %d Coins (Level %d)",
        "remaining_time" to "%ds remaining",
        "harvest_all" to "Quick Harvest",
        "water_soil" to "Water",
        "growth_progress" to "Growth: %d%%",

        // Shop
        "shop_title" to "Kingdom Seed Market",
        "shop_subtitle" to "Buy high quality seeds to cultivate your kingdom",
        "buy" to "Buy",
        "growth_time" to "Growth: %ds",
        "sell_value" to "Yield: %d Coins",
        "seed_cost" to "Cost: %d Coins",
        "unlocks_level" to "Unlocks at Level %d",
        "owned" to "In Silo: %d",

        // Silo
        "silo_title" to "Farm Silo & Barn",
        "silo_capacity" to "Capacity: %d / %d items",
        "upgrade_silo" to "Upgrade Capacity (+50)",
        "sell" to "Sell",
        "sell_for" to "Sell 1 for %d Coins",
        "sell_all" to "Sell All for %d Coins",
        "empty_inventory" to "Your Silo is empty. Harvest crops or buy seeds!",
        "cat_all" to "All",
        "cat_seeds" to "Seeds",
        "cat_crops" to "Crops",
        "cat_products" to "Products",

        // Orders & Quests
        "orders_title" to "Daily Village Orders",
        "deliver" to "Deliver",
        "completed" to "Completed",
        "reward" to "Reward: +%d Coins, +%d XP",
        "quests_tab" to "Quests",
        "orders_tab" to "Daily Orders",
        "claim" to "Claim Reward",
        "claimed" to "Claimed",
        "progress" to "%d / %d",

        // Profile
        "profile_title" to "Kingdom Farmer Profile",
        "farmer_level" to "Level %d",
        "xp_progress" to "%d / %d XP to Level %d",
        "total_harvests" to "Total Crops Harvested",
        "total_earnings" to "Total Lifetime Coins",
        "farm_status" to "Online Kingdom: Connected",
        "edit_farm_name" to "Edit Farm Name",
        "save" to "Save",
        "cancel" to "Cancel",

        // Settings
        "settings_title" to "Game Settings",
        "sound_fx" to "Sound Effects",
        "vibrations" to "Haptic Feedback",
        "language_choice" to "Language (اللغة)",
        "reset_game" to "Reset Farm Progress",
        "reset_confirm" to "Are you sure? This will reset your farm to starting state.",
        "reset_done" to "Farm reset successfully!",
        "about_game" to "About Farm Kingdom",
        "about_desc" to "Version 1.0 • Built with Jetpack Compose & SQLite Room. Real-time online persistent farming simulator.",

        // Dialogs & Feedback
        "plant_dialog_title" to "Select Seed to Plant",
        "select_seed_desc" to "Choose from seeds in your inventory:",
        "no_seeds_in_silo" to "No seeds available. Visit the Shop to buy seeds!",
        "leveled_up" to "🎉 LEVEL UP! You reached Level %d!",
        "harvest_success" to "🌾 Harvested %s (+%d XP)",
        "need_level" to "Requires Level %d",
        "need_coins" to "Need %d Coins",
        "storage_full" to "Silo is full! Please sell items or upgrade storage.",
        "land_unlocked" to "✨ New plot unlocked and ready for farming!",
        "silo_upgraded_success" to "Silo storage upgraded to",
        "plot_unlocked_success" to "Land expanded and plot unlocked! ✨",
        "order_completed_success" to "Order delivered successfully!",
        "quest_claimed_success" to "Quest reward claimed!",

        // Phase 5 Social World
        "tab_visit" to "Visit",
        "visit_players_title" to "Kingdom Farmers World",
        "visit_players_subtitle" to "Visit other farms, discover kingdom layouts, and leave likes!",
        "search_players_hint" to "Search by player or farm name...",
        "visit_farm_btn" to "Visit Farm 🌾",
        "visiting_mode_title" to "Visiting %s's Farm",
        "back_to_my_farm" to "Back to My Farm 🌾",
        "likes_count" to "%d Likes",
        "visitors_count" to "%d Visitors",
        "liked_success" to "❤️ You liked %s's farm!",
        "already_liked" to "❤️ You have already liked this farm",
        "visiting_read_only_msg" to "Visitor Mode: Farm is view-only",
        "public_profile_section" to "Public Profile (Visible to Everyone)",
        "private_data_section" to "Private Account Capital",
        "no_farmers_found" to "No kingdom farmers found"
    )

    private val AR = mapOf(
        "app_title" to "مملكة المزرعة 🌾",
        "tab_farm" to "المزرعة",
        "tab_shop" to "المتجر",
        "tab_silo" to "المخزن",
        "tab_orders" to "الطلبات",
        "tab_profile" to "الملف",
        "tab_settings" to "الإعدادات",

        // Farm
        "plot_empty" to "أرض فارغة",
        "plot_ready" to "جاهز للحصاد!",
        "plot_growing" to "قيد النمو...",
        "plot_locked" to "أرض مقفلة",
        "tap_to_plant" to "اضغط للزراعة",
        "tap_to_harvest" to "اضغط للحصاد!",
        "expand_cost" to "توسعة الأرض: %d عملة (المستوى %d)",
        "remaining_time" to "متبقي: %d ثانية",
        "harvest_all" to "حصاد الكل",
        "water_soil" to "ري الأرض",
        "growth_progress" to "اكتمال النمو: %d%%",

        // Shop
        "shop_title" to "متجر بذور المملكة",
        "shop_subtitle" to "اشترِ أفضل البذور عالية الجودة لتطوير مزرعتك",
        "buy" to "شراء",
        "growth_time" to "وقت النمو: %d ثانية",
        "sell_value" to "سعر البيع: %d عملة",
        "seed_cost" to "السعر: %d عملة",
        "unlocks_level" to "يفتح عند المستوى %d",
        "owned" to "في المخزن: %d",

        // Silo
        "silo_title" to "مخزن ومستودع المزرعة",
        "silo_capacity" to "السعة: %d / %d عنصر",
        "upgrade_silo" to "ترقية السعة (+50)",
        "sell" to "بيع",
        "sell_for" to "بيع 1 مقابل %d عملة",
        "sell_all" to "بيع الكل مقابل %d عملة",
        "empty_inventory" to "المخزن فارغ حالياً. احصد المحاصيل أو اشترِ البذور!",
        "cat_all" to "الكل",
        "cat_seeds" to "البذور",
        "cat_crops" to "المحاصيل",
        "cat_products" to "المنتجات",

        // Orders & Quests
        "orders_title" to "طلبات القرية اليومية",
        "deliver" to "تسليم الطلب",
        "completed" to "مكتمل",
        "reward" to "المكافأة: +%d عملة، +%d خبرة",
        "quests_tab" to "المهام",
        "orders_tab" to "الطلبات اليومية",
        "claim" to "استلام المكافأة",
        "claimed" to "تم الاستلام",
        "progress" to "%d / %d",

        // Profile
        "profile_title" to "ملف مزارع المملكة",
        "farmer_level" to "المستوى %d",
        "xp_progress" to "%d / %d خبرة للمستوى %d",
        "total_harvests" to "إجمالي المحاصيل المحصودة",
        "total_earnings" to "إجمالي الأرباح التاريخية",
        "farm_status" to "عالم أونلاين: متصل وآمن",
        "edit_farm_name" to "تعديل اسم المزرعة",
        "save" to "حفظ",
        "cancel" to "إلغاء",

        // Settings
        "settings_title" to "إعدادات اللعبة",
        "sound_fx" to "المؤثرات الصوتية",
        "vibrations" to "الاهتزاز اللمسي",
        "language_choice" to "Language (اللغة)",
        "reset_game" to "إعادة تعيين المزرعة",
        "reset_confirm" to "هل أنت متأكد؟ سيتم إعادة المزرعة للحالة المبدئية الأولى.",
        "reset_done" to "تمت إعادة تعيين المزرعة بنجاح!",
        "about_game" to "عن مملكة المزرعة",
        "about_desc" to "الإصدار 1.0 • صُممت باستخدام Jetpack Compose و Room Database. محاكي زراعي حقيقي بأوقات نمو حية وحفظ دائم.",

        // Dialogs & Feedback
        "plant_dialog_title" to "اختر البذور للزراعة",
        "select_seed_desc" to "اختر نوع البذور من مخزونك الحالي:",
        "no_seeds_in_silo" to "لا توجد بذور كافية في المخزن. توجه إلى المتجر لشرائها!",
        "leveled_up" to "🎉 ترقية! وصلت إلى المستوى %d!",
        "harvest_success" to "🌾 تم حصاد %s (+%d خبرة)",
        "need_level" to "يتطلب المستوى %d",
        "need_coins" to "يتطلب %d عملة",
        "storage_full" to "المخزن ممتلئ! قم ببيع بعض المحاصيل أو ترقية سعة المخزن.",
        "land_unlocked" to "✨ تم فتح قطعة أرض جديدة وجاهزة للزراعة!",
        "silo_upgraded_success" to "تمت ترقية سعة المخزن إلى",
        "plot_unlocked_success" to "تمت توسعة المزرعة وفتح الأرض بنجاح! ✨",
        "order_completed_success" to "تم تسليم الطلب واستلام الأرباح بنجاح!",
        "quest_claimed_success" to "تم استلام مكافأة المهمة بنجاح!",

        // Phase 5 Social World
        "tab_visit" to "الزيارات",
        "visit_players_title" to "عالم مزارعي المملكة",
        "visit_players_subtitle" to "زر مزارع الآخرين، اكتشف تصميمات المملكة، واترك إعجابك!",
        "search_players_hint" to "البحث باسم اللاعب أو المزرعة...",
        "visit_farm_btn" to "زيارة المزرعة 🌾",
        "visiting_mode_title" to "زيارة مزرعة %s",
        "back_to_my_farm" to "العودة إلى مزرعتي 🌾",
        "likes_count" to "%d إعجاب",
        "visitors_count" to "%d زائر",
        "liked_success" to "❤️ أبديت إعجابك بمزرعة %s!",
        "already_liked" to "❤️ لقد أبديت إعجابك بهذه المزرعة سابقاً",
        "visiting_read_only_msg" to "وضع الزيارة: المزرعة للعرض فقط",
        "public_profile_section" to "الملف العام (يراه الجميع)",
        "private_data_section" to "رأس مال الحساب الخاص",
        "no_farmers_found" to "لم يتم العثور على مزارعين"
    )

}
