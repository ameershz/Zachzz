package com.example.farm.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PrecisionManufacturing
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material.icons.filled.Yard

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.ui.localization.GameStrings
import com.example.farm.ui.viewmodel.MainTab
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark

@Composable
fun BottomNavBar(
    selectedTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    isAr: Boolean,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier.windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = FarmGreenDark,
        tonalElevation = 8.dp
    ) {
        // Tab 1: Farm
        NavigationBarItem(
            selected = selectedTab == MainTab.FARM,
            onClick = { onTabSelected(MainTab.FARM) },
            icon = { Icon(Icons.Default.Yard, contentDescription = "Farm") },
            label = { Text(GameStrings.t("tab_farm", isAr), fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGoldWheat,
                indicatorColor = FarmGoldWheat,
                unselectedIconColor = Color.White.copy(alpha = 0.7f),
                unselectedTextColor = Color.White.copy(alpha = 0.7f)
            ),
            modifier = Modifier.testTag("nav_farm_tab")
        )

        // Tab 2: Shop
        NavigationBarItem(
            selected = selectedTab == MainTab.SHOP,
            onClick = { onTabSelected(MainTab.SHOP) },
            icon = { Icon(Icons.Default.ShoppingBag, contentDescription = "Shop") },
            label = { Text(GameStrings.t("tab_shop", isAr), fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGoldWheat,
                indicatorColor = FarmGoldWheat,
                unselectedIconColor = Color.White.copy(alpha = 0.7f),
                unselectedTextColor = Color.White.copy(alpha = 0.7f)
            ),
            modifier = Modifier.testTag("nav_shop_tab")
        )

        // Tab 3: Production (Workshops & Animals)
        NavigationBarItem(
            selected = selectedTab == MainTab.PRODUCTION,
            onClick = { onTabSelected(MainTab.PRODUCTION) },
            icon = { Icon(Icons.Default.PrecisionManufacturing, contentDescription = "Production") },
            label = { Text(if (isAr) "الإنتاج" else "Production", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGoldWheat,
                indicatorColor = FarmGoldWheat,
                unselectedIconColor = Color.White.copy(alpha = 0.7f),
                unselectedTextColor = Color.White.copy(alpha = 0.7f)
            ),
            modifier = Modifier.testTag("nav_production_tab")
        )

        // Tab 4: Orders
        NavigationBarItem(
            selected = selectedTab == MainTab.ORDERS,
            onClick = { onTabSelected(MainTab.ORDERS) },
            icon = { Icon(Icons.AutoMirrored.Filled.Assignment, contentDescription = "Orders") },
            label = { Text(GameStrings.t("tab_orders", isAr), fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGoldWheat,
                indicatorColor = FarmGoldWheat,
                unselectedIconColor = Color.White.copy(alpha = 0.7f),
                unselectedTextColor = Color.White.copy(alpha = 0.7f)
            ),
            modifier = Modifier.testTag("nav_orders_tab")
        )

        // Tab 5: Visit
        NavigationBarItem(
            selected = selectedTab == MainTab.VISIT_PLAYERS || selectedTab == MainTab.VISITING_FARM,
            onClick = { onTabSelected(MainTab.VISIT_PLAYERS) },
            icon = { Icon(Icons.Default.TravelExplore, contentDescription = "Visit") },
            label = { Text(GameStrings.t("tab_visit", isAr), fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGoldWheat,
                indicatorColor = FarmGoldWheat,
                unselectedIconColor = Color.White.copy(alpha = 0.7f),
                unselectedTextColor = Color.White.copy(alpha = 0.7f)
            ),
            modifier = Modifier.testTag("nav_visit_tab")
        )

        // Tab 6: Profile
        NavigationBarItem(
            selected = selectedTab == MainTab.PROFILE,
            onClick = { onTabSelected(MainTab.PROFILE) },
            icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
            label = { Text(GameStrings.t("tab_profile", isAr), fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = FarmGreenDark,
                selectedTextColor = FarmGoldWheat,
                indicatorColor = FarmGoldWheat,
                unselectedIconColor = Color.White.copy(alpha = 0.7f),
                unselectedTextColor = Color.White.copy(alpha = 0.7f)
            ),
            modifier = Modifier.testTag("nav_profile_tab")
        )

    }
}
