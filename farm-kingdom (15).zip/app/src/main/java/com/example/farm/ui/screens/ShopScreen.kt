package com.example.farm.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.config.GameConfig
import com.example.farm.data.local.InventoryItemEntity
import com.example.farm.data.local.PlayerProfileEntity
import com.example.farm.ui.localization.GameStrings
import com.example.ui.theme.FarmGoldDark
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary

@Composable
fun ShopScreen(
    player: PlayerProfileEntity?,
    inventory: List<InventoryItemEntity>,
    isAr: Boolean,
    onBuySeed: (String, Int) -> Unit,
    onBuyAnimal: (String) -> Unit = {},
    onUnlockBuilding: (String) -> Unit = {},
    onUpgradeSilo: () -> Unit = {},
    isSyncing: Boolean = false,
    modifier: Modifier = Modifier
) {
    val playerLevel = player?.level ?: 1
    val playerCoins = player?.coins ?: 0
    val storageCapacity = player?.storageCapacity ?: 100
    val siloUpgradeCost = storageCapacity * 5
    val isReadyForPurchases = player != null && !isSyncing

    var selectedShopTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9FBF7))
    ) {
        if (!isReadyForPurchases) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFF3E0))
                    .padding(vertical = 8.dp, horizontal = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isAr) "⏳ جاري مزامنة رصيد وبيانات المتجر، يرجى الانتظار..." else "⏳ Syncing account & store data, please wait...",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE65100)
                )
            }
        }

        // Shop Navigation Tabs
        TabRow(
            selectedTabIndex = selectedShopTab,
            containerColor = FarmGreenDark,
            contentColor = FarmGoldWheat
        ) {
            Tab(
                selected = selectedShopTab == 0,
                onClick = { selectedShopTab = 0 },
                text = { Text(if (isAr) "بذور المحاصيل 🌾" else "Seeds 🌾", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = selectedShopTab == 1,
                onClick = { selectedShopTab = 1 },
                text = { Text(if (isAr) "المواشي 🐄" else "Animals 🐄", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = selectedShopTab == 2,
                onClick = { selectedShopTab = 2 },
                text = { Text(if (isAr) "المباني والتوسعات 🏗️" else "Buildings 🏗️", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
        }

        when (selectedShopTab) {
            0 -> {
                // Seeds Shop
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(GameConfig.CROPS, key = { it.id }) { crop ->
                        val isUnlocked = playerLevel >= crop.unlockLevel
                        val ownedSeed = inventory.find { it.itemId == "${crop.id}_seed" }?.quantity ?: 0
                        val name = if (isAr) crop.nameAr else crop.nameEn
                        val desc = if (isAr) crop.descriptionAr else crop.descriptionEn

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("shop_item_${crop.id}"),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnlocked) Color.White else Color(0xFFF0F0F0)
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = if (isUnlocked) FarmGreenPrimary.copy(alpha = 0.2f) else Color.LightGray
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = if (isUnlocked) 2.dp else 0.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (isUnlocked) FarmGoldWheat.copy(alpha = 0.3f)
                                                    else Color.LightGray.copy(alpha = 0.4f)
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(text = crop.emoji, fontSize = 26.sp)
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column {
                                            Text(
                                                text = name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = if (isUnlocked) FarmGreenDark else Color.Gray
                                            )
                                            Text(
                                                text = desc,
                                                fontSize = 11.sp,
                                                color = Color.DarkGray,
                                                maxLines = 1
                                            )
                                        }
                                    }

                                    if (isUnlocked && ownedSeed > 0) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(FarmGreenPrimary.copy(alpha = 0.15f))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = if (isAr) "في المخزن: $ownedSeed" else "Owned: $ownedSeed",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = FarmGreenPrimary
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFF5F5F5))
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("⏱️ ${crop.growthTimeSeconds}s", fontSize = 11.sp, color = Color.DarkGray)
                                    Text("💰 ${crop.sellPrice} 🪙", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = FarmGoldDark)
                                    Text("⭐ +${crop.xpReward} XP", fontSize = 11.sp, color = FarmGreenPrimary)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                if (!isUnlocked) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isAr) "يفتح عند المستوى ${crop.unlockLevel}" else "Requires Farm Level ${crop.unlockLevel}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Gray
                                        )
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "🪙 ${crop.seedPrice} / seed",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = FarmGoldDark
                                        )

                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Button(
                                                onClick = { onBuySeed(crop.id, 1) },
                                                enabled = isReadyForPurchases && playerCoins >= crop.seedPrice,
                                                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                            ) {
                                                Text(text = if (isAr) "شراء 1" else "Buy 1", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }

                                            Button(
                                                onClick = { onBuySeed(crop.id, 5) },
                                                enabled = isReadyForPurchases && playerCoins >= (crop.seedPrice * 5),
                                                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Text(text = "x5", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // Animals Shop
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(GameConfig.ANIMALS, key = { it.id }) { animal ->
                        val isUnlocked = playerLevel >= animal.requiredLevel
                        val canAfford = isReadyForPurchases && playerCoins >= animal.purchaseCost

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnlocked) Color.White else Color(0xFFF5F5F5)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(52.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFFFF9C4)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(animal.emoji, fontSize = 28.sp)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = if (isAr) animal.nameAr else animal.nameEn,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = if (isUnlocked) FarmGreenDark else Color.Gray
                                            )
                                            Text(
                                                text = if (isAr) animal.descriptionAr else animal.descriptionEn,
                                                fontSize = 11.sp,
                                                color = Color.DarkGray
                                            )
                                        }
                                    }
                                }

                                Spacer(Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFFF5F5F5))
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("⏱️ ${animal.productionTimeSeconds}s", fontSize = 11.sp)
                                    Text("📦 ${if (isAr) animal.productNameAr else animal.productNameEn}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                                    Text("⭐ +${animal.xpReward} XP", fontSize = 11.sp, color = FarmGreenPrimary)
                                }

                                Spacer(Modifier.height(10.dp))

                                if (!isUnlocked) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (isAr) "يفتح عند المستوى ${animal.requiredLevel}" else "Requires Farm Level ${animal.requiredLevel}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Gray
                                        )
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "🪙 ${animal.purchaseCost} Coins",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = FarmGoldDark
                                        )

                                        Button(
                                            onClick = { onBuyAnimal(animal.id) },
                                            enabled = canAfford,
                                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(if (isAr) "تبني حيوان 🐾" else "Adopt 🐾", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                // Buildings & Storage Shop
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Silo Upgrade Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("🌾", fontSize = 32.sp)
                                        Spacer(Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = if (isAr) "ترقية سعة الصومعة" else "Silo Storage Upgrade",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = FarmGreenDark
                                            )
                                            Text(
                                                text = "${if (isAr) "السعة الحالية:" else "Current:"} $storageCapacity (+50 slots)",
                                                fontSize = 12.sp,
                                                color = Color.DarkGray
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = onUpgradeSilo,
                                        enabled = isReadyForPurchases && playerCoins >= siloUpgradeCost,
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text("$siloUpgradeCost 🪙", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Workshops
                    items(GameConfig.BUILDINGS, key = { it.id }) { bConfig ->
                        val isUnlocked = playerLevel >= bConfig.unlockLevel
                        val canAfford = isReadyForPurchases && playerCoins >= bConfig.unlockCost

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUnlocked) Color.White else Color(0xFFF5F5F5)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(bConfig.emoji, fontSize = 32.sp)
                                        Spacer(Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = if (isAr) bConfig.nameAr else bConfig.nameEn,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = if (isUnlocked) FarmGreenDark else Color.Gray
                                            )
                                            Text(
                                                text = if (isAr) bConfig.descriptionAr else bConfig.descriptionEn,
                                                fontSize = 11.sp,
                                                color = Color.DarkGray
                                            )
                                        }
                                    }
                                }

                                Spacer(Modifier.height(10.dp))

                                if (!isUnlocked) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = if (isAr) "يفتح عند المستوى ${bConfig.unlockLevel}" else "Requires Farm Level ${bConfig.unlockLevel}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Gray
                                        )
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "🪙 ${bConfig.unlockCost} Coins",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = FarmGoldDark
                                        )

                                        Button(
                                            onClick = { onUnlockBuilding(bConfig.id) },
                                            enabled = canAfford,
                                            colors = ButtonDefaults.buttonColors(containerColor = FarmGreenDark),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(if (isAr) "بناء 🏗️" else "Build 🏗️", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
