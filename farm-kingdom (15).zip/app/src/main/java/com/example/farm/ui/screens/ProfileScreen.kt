package com.example.farm.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.config.GameConfig
import com.example.farm.ui.localization.GameStrings
import com.example.farm.ui.viewmodel.FarmViewModel
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary

@Composable
fun ProfileScreen(
    viewModel: FarmViewModel,
    onSaveFarmName: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val player by viewModel.player.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val dailyReward by viewModel.dailyReward.collectAsState()
    val currentTime by viewModel.currentTime.collectAsState()
    val isAr = player?.language == "ar"

    var isEditingName by remember { mutableStateOf(false) }
    var editedName by remember(player?.farmName) { mutableStateOf(player?.farmName ?: "") }

    val lastClaimedAt = dailyReward?.lastClaimedAt ?: 0L
    val lastClaimedDay = dailyReward?.lastClaimedDay ?: 0
    val ONE_DAY_MS = 24 * 60 * 60 * 1000L
    val canClaimDaily = lastClaimedAt == 0L || (currentTime - lastClaimedAt >= ONE_DAY_MS)
    val nextDay = if (lastClaimedDay >= 7 || (lastClaimedAt > 0 && currentTime - lastClaimedAt > 48 * 60 * 60 * 1000L)) 1 else (lastClaimedDay + 1)

    val remainingMs = if (!canClaimDaily) (ONE_DAY_MS - (currentTime - lastClaimedAt)).coerceAtLeast(0L) else 0L
    val remainingHours = remainingMs / (1000 * 60 * 60)
    val remainingMinutes = (remainingMs / (1000 * 60)) % 60

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9FBF7)),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Profile Hero Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = FarmGreenDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(FarmGoldWheat),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "👨‍🌾", fontSize = 42.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (isEditingName) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedTextField(
                                value = editedName,
                                onValueChange = { editedName = it },
                                label = { Text(if (isAr) "اسم المزرعة" else "Farm Name", color = Color.White) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("edit_farm_name_input"),
                                singleLine = true
                            )
                            IconButton(
                                onClick = {
                                    onSaveFarmName(editedName)
                                    isEditingName = false
                                }
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Save", tint = FarmGoldWheat)
                            }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = player?.farmName ?: "Green Meadow Farm",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            IconButton(onClick = { isEditingName = true }) {
                                Icon(
                                    Icons.Default.Edit,
                                    contentDescription = "Edit Name",
                                    tint = FarmGoldWheat,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = player?.username ?: "Farmer King",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Online Status Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.15f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "🟢 ${GameStrings.t("farm_status", isAr)}",
                            color = Color(0xFFA5D6A7),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Public Social Badges (Likes & Visitors)
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.2f))
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "❤️", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = String.format(GameStrings.t("likes_count", isAr), player?.totalAnimalCollections ?: 0),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "👁️", fontSize = 16.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = String.format(GameStrings.t("visitors_count", isAr), player?.totalGoodsProduced ?: 0),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Visit Other Farmers Navigation Button
                    Button(
                        onClick = { viewModel.setTab(com.example.farm.ui.viewmodel.MainTab.VISIT_PLAYERS) },
                        colors = ButtonDefaults.buttonColors(containerColor = FarmGoldWheat),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("go_to_visit_players_button")
                    ) {
                        Text(
                            text = if (isAr) "🌐 زيارة مزارعي المملكة" else "🌐 Visit Other Farmers",
                            color = FarmGreenDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }


        // Daily Reward 7-Day Bounty Calendar Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                border = BorderStroke(1.dp, Color(0xFFFFD54F)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.CardGiftcard, contentDescription = null, tint = Color(0xFFE65100))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = if (isAr) "مكافآت الحضور اليومية 🎁" else "Daily Login Bounty 🎁",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE65100)
                            )
                        }

                        Button(
                            onClick = { viewModel.claimDailyReward() },
                            enabled = canClaimDaily,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = if (canClaimDaily) (if (isAr) "استلام" else "Claim") else "${remainingHours}h ${remainingMinutes}m ⏳",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // 7-day row
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(GameConfig.DAILY_REWARDS) { reward ->
                            val isClaimed = lastClaimedDay >= reward.day
                            val isCurrent = nextDay == reward.day

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = when {
                                        isClaimed -> Color(0xFFE8F5E9)
                                        isCurrent -> Color(0xFFFFECB3)
                                        else -> Color.White
                                    }
                                ),
                                border = BorderStroke(
                                    1.dp,
                                    if (isCurrent) Color(0xFFFFA000) else Color(0xFFE0E0E0)
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .width(72.dp)
                                        .padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("Day ${reward.day}", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(4.dp))
                                    Text(if (isClaimed) "✅" else "🪙", fontSize = 20.sp)
                                    Spacer(Modifier.height(2.dp))
                                    Text("${reward.rewardCoins}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    if (reward.rewardGems > 0) {
                                        Text("+${reward.rewardGems} 💎", fontSize = 9.sp, color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Stats Cards Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE0E0E0))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "🌾", fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = (player?.totalHarvests ?: 0).toString(),
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = FarmGreenDark
                        )
                        Text(
                            text = GameStrings.t("total_harvests", isAr),
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE0E0E0))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "🪙", fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = (player?.totalCoinsEarned ?: 0L).toString(),
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = Color(0xFFC17900)
                        )
                        Text(
                            text = GameStrings.t("total_earnings", isAr),
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE0E0E0))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "🥛", fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = (player?.totalAnimalCollections ?: 0).toString(),
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = Color(0xFF1976D2)
                        )
                        Text(
                            text = if (isAr) "إنتاج الحيوانات" else "Livestock Yields",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE0E0E0))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(text = "🍞", fontSize = 24.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = (player?.totalGoodsProduced ?: 0).toString(),
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = Color(0xFF8D6E63)
                        )
                        Text(
                            text = if (isAr) "منتجات المصانع" else "Crafted Goods",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        // Recent Activity / Transactions Header
        item {
            Text(
                text = if (isAr) "سجل المعاملات والنشاط الأخير" else "Recent Farm Activity & Transactions",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = FarmGreenDark,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
        }

        // Transactions list
        if (transactions.isEmpty()) {
            item {
                Text(
                    text = if (isAr) "لا توجد معاملات بعد." else "No transactions recorded yet.",
                    color = Color.Gray,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        } else {
            items(transactions, key = { it.id }) { tx ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFEEEEEE))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isAr) tx.descAr else tx.descEn,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF2E3A2F)
                            )
                            Text(
                                text = tx.type,
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }

                        if (tx.amountCoins != 0) {
                            Text(
                                text = (if (tx.amountCoins > 0) "+${tx.amountCoins}" else "${tx.amountCoins}") + " 🪙",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (tx.amountCoins > 0) FarmGreenPrimary else Color(0xFFD32F2F)
                            )
                        }
                    }
                }
            }
        }
    }
}
