package com.example.farm.data.model

enum class PlotState {
    LOCKED,
    EMPTY,
    GROWING,
    READY
}

enum class AnimalState {
    HUNGRY,
    PRODUCING,
    READY
}

enum class BuildingState {
    LOCKED,
    IDLE,
    PRODUCING,
    READY
}

enum class ItemCategory {
    ALL,
    SEED,
    CROP,
    ANIMAL_PRODUCT,
    PROCESSED,
    MATERIAL
}

enum class QuestType {
    PLANT_CROPS,
    HARVEST_CROPS,
    FEED_ANIMALS,
    COLLECT_ANIMAL_PRODUCTS,
    PRODUCE_GOODS,
    EARN_COINS,
    UPGRADE_STORAGE,
    EXPAND_LAND,
    BUY_SEEDS
}

data class PublicProfile(
    val uid: String,
    val displayName: String,
    val farmName: String,
    val avatarId: String = "avatar_1",
    val level: Int = 1,
    val unlockedLandCount: Int = 4,
    val visitorCount: Int = 0,
    val likeCount: Int = 0,
    val isLikedByMe: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

data class PublicFarm(
    val uid: String,
    val farmName: String,
    val ownerName: String,
    val level: Int = 1,
    val plots: List<com.example.farm.data.remote.FirestoreFarmPlot> = emptyList(),
    val animals: List<com.example.farm.data.remote.FirestoreAnimal> = emptyList(),
    val buildings: List<com.example.farm.data.remote.FirestoreProductionBuilding> = emptyList(),
    val updatedAt: Long = System.currentTimeMillis()
)

