package com.example.farm.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.config.GameConfig
import com.example.farm.data.local.FarmPlotEntity
import com.example.farm.ui.localization.GameStrings
import com.example.ui.theme.FarmAmberGlow
import com.example.ui.theme.FarmGoldDark
import com.example.ui.theme.FarmGoldLight
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenLight
import com.example.ui.theme.FarmGreenPrimary
import com.example.ui.theme.FarmSoilBrown
import com.example.ui.theme.FarmSoilDark
import com.example.ui.theme.FarmSoilFertile

@Composable
fun PlotCard(
    plot: FarmPlotEntity,
    currentTime: Long,
    isAr: Boolean,
    onPlantClick: () -> Unit,
    onHarvestClick: () -> Unit,
    onUnlockClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val crop = plot.cropId?.let { GameConfig.getCropById(it) }

    // Pulsing animation for ready plots
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val isPlotReady = plot.state == "READY" || (plot.state == "GROWING" && plot.readyAt > 0 && currentTime >= plot.readyAt)

    Card(
        modifier = modifier
            .height(132.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable(
                onClick = {
                    when {
                        !plot.isUnlocked -> onUnlockClick()
                        isPlotReady -> onHarvestClick()
                        plot.state == "EMPTY" -> onPlantClick()
                        else -> Unit
                    }
                }
            )
            .testTag("plot_card_${plot.plotIndex}"),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(
            width = if (isPlotReady) 2.5.dp else if (!plot.isUnlocked) 1.dp else 1.5.dp,
            color = when {
                isPlotReady -> FarmGoldWheat
                !plot.isUnlocked -> Color(0xFFBDBDBD)
                plot.state == "GROWING" -> Color(0xFF795548)
                else -> Color(0xFF8D6E63)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isPlotReady) 8.dp else 3.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    when {
                        !plot.isUnlocked -> Brush.verticalGradient(
                            listOf(Color(0xFFE8EAF6), Color(0xFFCFD8DC))
                        )
                        isPlotReady -> Brush.verticalGradient(
                            listOf(Color(0xFFFFFDE7), Color(0xFFFFF59D), Color(0xFFFFE082))
                        )
                        plot.state == "GROWING" -> Brush.verticalGradient(
                            listOf(FarmSoilBrown, FarmSoilFertile, FarmSoilDark)
                        )
                        else -> Brush.verticalGradient(
                            listOf(Color(0xFF6D4C41), Color(0xFF5D4037), FarmSoilDark)
                        )
                    }
                )
                .padding(6.dp),
            contentAlignment = Alignment.Center
        ) {
            when {
                // State 1: LOCKED LAND
                !plot.isUnlocked -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.8f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Locked",
                                tint = Color(0xFF455A64),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = if (isAr) "المستوى ${plot.unlockLevel}" else "Lv. ${plot.unlockLevel}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF37474F)
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.9f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "🪙 ${plot.unlockCost}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = FarmGoldDark
                            )
                        }
                    }
                }

                // State 2: READY FOR HARVEST
                isPlotReady -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .scale(pulseScale),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.85f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = crop?.emoji ?: "🌾",
                                fontSize = 32.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(FarmGreenDark)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = FarmGoldWheat,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = if (isAr) "احصد!" else "HARVEST!",
                                    color = Color.White,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Text(
                            text = if (isAr) crop?.nameAr ?: "" else crop?.nameEn ?: "",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32),
                            maxLines = 1
                        )
                    }
                }

                // State 3: GROWING CROP
                plot.state == "GROWING" -> {
                    val totalDuration = ((crop?.growthTimeSeconds ?: 30L) * 1000L).coerceAtLeast(1000L)
                    val elapsed = (currentTime - plot.plantedAt).coerceIn(0L, totalDuration)
                    val progress = (elapsed.toFloat() / totalDuration.toFloat()).coerceIn(0f, 1f)
                    val remainingSeconds = (((plot.readyAt - currentTime).coerceAtLeast(0L)) / 1000L)

                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "#${plot.plotIndex + 1}",
                                fontSize = 9.sp,
                                color = Color.White.copy(alpha = 0.5f)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Black.copy(alpha = 0.4f))
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "${remainingSeconds}s",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FarmGoldLight
                                )
                            }
                        }

                        // Growth seedling graphic based on progress
                        Text(
                            text = if (progress < 0.35f) "🌱" else if (progress < 0.75f) "🌿" else (crop?.emoji ?: "🌾"),
                            fontSize = 30.sp
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.25f))
                                .padding(horizontal = 4.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (isAr) crop?.nameAr ?: "" else crop?.nameEn ?: "",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(5.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = FarmGreenLight,
                                trackColor = Color.White.copy(alpha = 0.2f),
                            )
                        }
                    }
                }

                // State 4: EMPTY SOIL
                else -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Plant",
                                tint = FarmGoldLight,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = GameStrings.t("tap_to_plant", isAr),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFECC2),
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "#${plot.plotIndex + 1}",
                            fontSize = 9.sp,
                            color = Color.White.copy(alpha = 0.4f)
                        )
                    }
                }
            }
        }
    }
}
