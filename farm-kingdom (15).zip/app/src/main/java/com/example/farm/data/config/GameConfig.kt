package com.example.farm.data.config

data class CropConfig(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val seedPrice: Int,
    val sellPrice: Int,
    val growthTimeSeconds: Long,
    val xpReward: Int,
    val unlockLevel: Int,
    val emoji: String,
    val category: String = "CROP"
)

data class AnimalConfig(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val purchaseCost: Int,
    val requiredLevel: Int,
    val productionTimeSeconds: Long,
    val feedItemId: String,
    val feedItemNameEn: String,
    val feedItemNameAr: String,
    val productItemId: String,
    val productNameEn: String,
    val productNameAr: String,
    val productSellPrice: Int,
    val xpReward: Int,
    val emoji: String
)

data class ProductionRecipe(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val buildingId: String,
    val requiredLevel: Int,
    val productionTimeSeconds: Long,
    val inputItemId: String,
    val inputAmount: Int,
    val inputItemNameEn: String,
    val inputItemNameAr: String,
    val secondaryInputItemId: String? = null,
    val secondaryInputAmount: Int = 0,
    val secondaryInputNameEn: String? = null,
    val secondaryInputNameAr: String? = null,
    val outputItemId: String,
    val outputNameEn: String,
    val outputNameAr: String,
    val outputAmount: Int = 1,
    val sellPrice: Int,
    val xpReward: Int,
    val emoji: String
)

data class BuildingConfig(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val unlockLevel: Int,
    val unlockCost: Int,
    val emoji: String
)

data class DailyRewardConfig(
    val day: Int,
    val rewardCoins: Int,
    val rewardGems: Int,
    val rewardItemId: String?,
    val rewardItemAmount: Int,
    val descriptionEn: String,
    val descriptionAr: String
)

object GameConfig {
    const val STARTING_COINS = 1000
    const val STARTING_GEMS = 10
    const val STARTING_STORAGE = 100
    const val STORAGE_UPGRADE_INCREMENT = 50
    const val BASE_STORAGE_UPGRADE_COST = 500

    val CROPS: List<CropConfig> = listOf(
        CropConfig(
            id = "wheat",
            nameEn = "Wheat",
            nameAr = "قمح ذهبي",
            descriptionEn = "Essential golden crop, fast growing staple.",
            descriptionAr = "محصول أساسي سريع النمو ومثالي للبداية.",
            seedPrice = 10,
            sellPrice = 25,
            growthTimeSeconds = 15L,
            xpReward = 12,
            unlockLevel = 1,
            emoji = "🌾"
        ),
        CropConfig(
            id = "corn",
            nameEn = "Corn",
            nameAr = "ذرة حلوة",
            descriptionEn = "Tall and sweet ears of delicious yellow corn.",
            descriptionAr = "أكواز ذرة صفراء وحلوة المذاق.",
            seedPrice = 25,
            sellPrice = 65,
            growthTimeSeconds = 30L,
            xpReward = 30,
            unlockLevel = 2,
            emoji = "🌽"
        ),
        CropConfig(
            id = "carrot",
            nameEn = "Carrot",
            nameAr = "جزر طازج",
            descriptionEn = "Crisp, healthy root vegetable loved by rabbits.",
            descriptionAr = "خضار جذري مقرمش ومغذي.",
            seedPrice = 50,
            sellPrice = 135,
            growthTimeSeconds = 60L,
            xpReward = 65,
            unlockLevel = 3,
            emoji = "🥕"
        ),
        CropConfig(
            id = "potato",
            nameEn = "Potato",
            nameAr = "بطاطس ريفية",
            descriptionEn = "Hearty potato crops yielding abundant harvest.",
            descriptionAr = "محصول بطاطس ريفي مغذي ولذيذ.",
            seedPrice = 75,
            sellPrice = 200,
            growthTimeSeconds = 90L,
            xpReward = 95,
            unlockLevel = 3,
            emoji = "🥔"
        ),
        CropConfig(
            id = "tomato",
            nameEn = "Tomato",
            nameAr = "طماطم حمراء",
            descriptionEn = "Juicy red tomatoes packed with sun-ripened flavor.",
            descriptionAr = "طماطم حمراء طازجة غنية بالنكهة.",
            seedPrice = 110,
            sellPrice = 300,
            growthTimeSeconds = 120L,
            xpReward = 140,
            unlockLevel = 4,
            emoji = "🍅"
        ),
        CropConfig(
            id = "strawberry",
            nameEn = "Strawberry",
            nameAr = "فراولة برية",
            descriptionEn = "Sweet and aromatic berries with high market value.",
            descriptionAr = "توت وفراولة برية ذات قيمة سوقية عالية.",
            seedPrice = 220,
            sellPrice = 640,
            growthTimeSeconds = 240L,
            xpReward = 290,
            unlockLevel = 5,
            emoji = "🍓"
        ),
        CropConfig(
            id = "cotton",
            nameEn = "Cotton",
            nameAr = "قطن ناصع",
            descriptionEn = "Fluffy white cotton fibers for weaving cloths.",
            descriptionAr = "ألياف قطنية بيضاء فاخرة لنسج الأقمشة.",
            seedPrice = 320,
            sellPrice = 950,
            growthTimeSeconds = 360L,
            xpReward = 420,
            unlockLevel = 7,
            emoji = "☁️"
        ),
        CropConfig(
            id = "pumpkin",
            nameEn = "Pumpkin",
            nameAr = "قرع الخريف",
            descriptionEn = "Huge autumnal pumpkin yielding great profits.",
            descriptionAr = "يقطين خريفي كبير ومربح لموسم الحصاد.",
            seedPrice = 450,
            sellPrice = 1400,
            growthTimeSeconds = 480L,
            xpReward = 600,
            unlockLevel = 8,
            emoji = "🎃"
        ),
        CropConfig(
            id = "watermelon",
            nameEn = "Watermelon",
            nameAr = "بطيخ منعش",
            descriptionEn = "Giant refreshing melon prized across the kingdom.",
            descriptionAr = "بطيخ ملكي ضخم يدر أرباحاً هائلة.",
            seedPrice = 900,
            sellPrice = 3000,
            growthTimeSeconds = 720L,
            xpReward = 1200,
            unlockLevel = 10,
            emoji = "🍉"
        )
    )

    val ANIMALS: List<AnimalConfig> = listOf(
        AnimalConfig(
            id = "chicken",
            nameEn = "Clucking Chicken",
            nameAr = "دجاجة المزرعة",
            descriptionEn = "Produces fresh country eggs when fed golden wheat seeds.",
            descriptionAr = "تنتج بيضاً طازجاً عند إطعامها بذور القمح الذهبي.",
            purchaseCost = 350,
            requiredLevel = 3,
            productionTimeSeconds = 20L,
            feedItemId = "wheat_seed",
            feedItemNameEn = "Wheat Seeds",
            feedItemNameAr = "بذور قمح",
            productItemId = "egg",
            productNameEn = "Fresh Egg",
            productNameAr = "بيض طازج",
            productSellPrice = 45,
            xpReward = 25,
            emoji = "🐔"
        ),
        AnimalConfig(
            id = "cow",
            nameEn = "Dairy Cow",
            nameAr = "بقرة حلوب",
            descriptionEn = "Produces rich and creamy milk when fed sweet corn seeds.",
            descriptionAr = "تنتج حليباً طازجاً دَسماً عند إطعامها بذور الذرة.",
            purchaseCost = 850,
            requiredLevel = 5,
            productionTimeSeconds = 45L,
            feedItemId = "corn_seed",
            feedItemNameEn = "Corn Seeds",
            feedItemNameAr = "بذور ذرة",
            productItemId = "milk",
            productNameEn = "Pure Milk",
            productNameAr = "حليب صافي",
            productSellPrice = 120,
            xpReward = 65,
            emoji = "🐄"
        ),
        AnimalConfig(
            id = "sheep",
            nameEn = "Woolly Sheep",
            nameAr = "خروف صوفي",
            descriptionEn = "Produces high-quality wool for textiles when fed carrot seeds.",
            descriptionAr = "ينتج صوفاً ناعماً فاخراً لصناعة الأقمشة عند إطعامه بذور الجزر.",
            purchaseCost = 1800,
            requiredLevel = 8,
            productionTimeSeconds = 90L,
            feedItemId = "carrot_seed",
            feedItemNameEn = "Carrot Seeds",
            feedItemNameAr = "بذور جزر",
            productItemId = "wool",
            productNameEn = "Soft Wool",
            productNameAr = "صوف ناعم",
            productSellPrice = 280,
            xpReward = 140,
            emoji = "🐑"
        )
    )

    val BUILDINGS: List<BuildingConfig> = listOf(
        BuildingConfig(
            id = "bakery",
            nameEn = "Royal Bakery",
            nameAr = "المخبز الملكي",
            descriptionEn = "Bakes golden bread, pies, and sweet pastries.",
            descriptionAr = "يخبز أرغفة الخبز الذهبية والفطائر الشهية.",
            unlockLevel = 4,
            unlockCost = 750,
            emoji = "🍞"
        ),
        BuildingConfig(
            id = "dairy",
            nameEn = "Artisan Dairy",
            nameAr = "معمل الألبان",
            descriptionEn = "Churns farm milk into delicious butter and aged cheese.",
            descriptionAr = "يحول الحليب الطازج إلى زبدة ريفية وجبن معتق.",
            unlockLevel = 6,
            unlockCost = 1600,
            emoji = "🧀"
        ),
        BuildingConfig(
            id = "textile_mill",
            nameEn = "Textile Mill",
            nameAr = "مصنع النسيج",
            descriptionEn = "Weaves wool and cotton into fine royal fabrics.",
            descriptionAr = "ينسج الصوف والقطن إلى أقمشة ملكية فاخرة.",
            unlockLevel = 9,
            unlockCost = 3500,
            emoji = "🧵"
        )
    )

    val RECIPES: List<ProductionRecipe> = listOf(
        ProductionRecipe(
            id = "bread",
            nameEn = "Crusty Bread",
            nameAr = "خبز ريفي مقرمش",
            buildingId = "bakery",
            requiredLevel = 4,
            productionTimeSeconds = 30L,
            inputItemId = "crop_wheat",
            inputAmount = 3,
            inputItemNameEn = "Wheat",
            inputItemNameAr = "قمح",
            outputItemId = "item_bread",
            outputNameEn = "Crusty Bread",
            outputNameAr = "خبز ريفي مقرمش",
            sellPrice = 140,
            xpReward = 55,
            emoji = "🥖"
        ),
        ProductionRecipe(
            id = "cornbread",
            nameEn = "Sweet Cornbread",
            nameAr = "خبز الذرة الحلو",
            buildingId = "bakery",
            requiredLevel = 5,
            productionTimeSeconds = 50L,
            inputItemId = "crop_corn",
            inputAmount = 2,
            inputItemNameEn = "Corn",
            inputItemNameAr = "ذرة",
            secondaryInputItemId = "item_egg",
            secondaryInputAmount = 1,
            secondaryInputNameEn = "Egg",
            secondaryInputNameAr = "بيض",
            outputItemId = "item_cornbread",
            outputNameEn = "Sweet Cornbread",
            outputNameAr = "خبز الذرة الحلو",
            sellPrice = 280,
            xpReward = 95,
            emoji = "🥧"
        ),
        ProductionRecipe(
            id = "strawberry_cake",
            nameEn = "Strawberry Cake",
            nameAr = "كعكة الفراولة الملكية",
            buildingId = "bakery",
            requiredLevel = 6,
            productionTimeSeconds = 90L,
            inputItemId = "crop_strawberry",
            inputAmount = 2,
            inputItemNameEn = "Strawberry",
            inputItemNameAr = "فراولة",
            secondaryInputItemId = "item_egg",
            secondaryInputAmount = 2,
            secondaryInputNameEn = "Egg",
            secondaryInputNameAr = "بيض",
            outputItemId = "item_strawberry_cake",
            outputNameEn = "Strawberry Cake",
            outputNameAr = "كعكة الفراولة الملكية",
            sellPrice = 780,
            xpReward = 260,
            emoji = "🍰"
        ),
        ProductionRecipe(
            id = "butter",
            nameEn = "Creamy Butter",
            nameAr = "زبدة ريفية طازجة",
            buildingId = "dairy",
            requiredLevel = 6,
            productionTimeSeconds = 40L,
            inputItemId = "item_milk",
            inputAmount = 2,
            inputItemNameEn = "Milk",
            inputItemNameAr = "حليب",
            outputItemId = "item_butter",
            outputNameEn = "Creamy Butter",
            outputNameAr = "زبدة ريفية طازجة",
            sellPrice = 240,
            xpReward = 80,
            emoji = "🧈"
        ),
        ProductionRecipe(
            id = "cheese",
            nameEn = "Aged Farm Cheese",
            nameAr = "جبن قروي معتق",
            buildingId = "dairy",
            requiredLevel = 7,
            productionTimeSeconds = 75L,
            inputItemId = "item_milk",
            inputAmount = 3,
            inputItemNameEn = "Milk",
            inputItemNameAr = "حليب",
            outputItemId = "item_cheese",
            outputNameEn = "Aged Farm Cheese",
            outputNameAr = "جبن قروي معتق",
            sellPrice = 420,
            xpReward = 160,
            emoji = "🧀"
        ),
        ProductionRecipe(
            id = "cloth",
            nameEn = "Royal Cloth",
            nameAr = "قماش صوفي ملكي",
            buildingId = "textile_mill",
            requiredLevel = 9,
            productionTimeSeconds = 100L,
            inputItemId = "item_wool",
            inputAmount = 2,
            inputItemNameEn = "Wool",
            inputItemNameAr = "صوف",
            outputItemId = "item_cloth",
            outputNameEn = "Royal Cloth",
            outputNameAr = "قماش صوفي ملكي",
            sellPrice = 650,
            xpReward = 240,
            emoji = "🧣"
        ),
        ProductionRecipe(
            id = "cotton_fabric",
            nameEn = "Fine Cotton Fabric",
            nameAr = "نسيج قطني فاخر",
            buildingId = "textile_mill",
            requiredLevel = 9,
            productionTimeSeconds = 80L,
            inputItemId = "crop_cotton",
            inputAmount = 3,
            inputItemNameEn = "Cotton",
            inputItemNameAr = "قطن",
            outputItemId = "item_cotton_fabric",
            outputNameEn = "Fine Cotton Fabric",
            outputNameAr = "نسيج قطني فاخر",
            sellPrice = 520,
            xpReward = 190,
            emoji = "🧵"
        )
    )

    val DAILY_REWARDS: List<DailyRewardConfig> = listOf(
        DailyRewardConfig(1, 250, 2, "wheat_seed", 5, "Day 1 Starter Bounty", "مكافأة اليوم الأول"),
        DailyRewardConfig(2, 400, 3, "corn_seed", 4, "Day 2 Farmer Gift", "مكافأة اليوم الثاني"),
        DailyRewardConfig(3, 600, 5, "carrot_seed", 3, "Day 3 Harvest Blessings", "مكافأة اليوم الثالث"),
        DailyRewardConfig(4, 900, 8, "potato_seed", 3, "Day 4 Abundant Crop Gift", "مكافأة اليوم الرابع"),
        DailyRewardConfig(5, 1400, 10, "strawberry_seed", 2, "Day 5 Royal Berry Gift", "مكافأة اليوم الخامس"),
        DailyRewardConfig(6, 2000, 15, "pumpkin_seed", 2, "Day 6 Grand Harvest Chest", "مكافأة اليوم السادس"),
        DailyRewardConfig(7, 3500, 30, "cotton_seed", 4, "Day 7 Kingdom Emperor Treasure", "كنز إمبراطور المملكة الأسبوعي")
    )

    fun getCropById(id: String): CropConfig? = CROPS.find { it.id == id }
    fun getAnimalById(id: String): AnimalConfig? = ANIMALS.find { it.id == id }
    fun getBuildingById(id: String): BuildingConfig? = BUILDINGS.find { it.id == id }
    fun getRecipeById(id: String): ProductionRecipe? = RECIPES.find { it.id == id }

    fun getXpForLevel(level: Int): Int {
        return (level * level * 80) + (level * 100)
    }

    val INITIAL_PLOTS_COUNT = 12
    val INITIAL_UNLOCKED_COUNT = 6

    val PLOT_EXPANSION_COSTS = listOf(
        Pair(2, 200),    // Plot 6
        Pair(3, 450),    // Plot 7
        Pair(4, 900),    // Plot 8
        Pair(5, 1800),   // Plot 9
        Pair(6, 3500),   // Plot 10
        Pair(7, 6000)    // Plot 11
    )
}
