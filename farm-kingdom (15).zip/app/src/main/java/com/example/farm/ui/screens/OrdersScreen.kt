package com.example.farm.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.config.GameConfig
import com.example.farm.data.local.DailyOrderEntity
import com.example.farm.data.local.InventoryItemEntity
import com.example.farm.data.local.QuestEntity
import com.example.farm.ui.localization.GameStrings
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary

@Composable
fun OrdersScreen(
    orders: List<DailyOrderEntity>,
    quests: List<QuestEntity>,
    inventory: List<InventoryItemEntity>,
    isAr: Boolean,
    onDeliverOrder: (String) -> Unit,
    onClaimQuest: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9FBF7))
    ) {
        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = FarmGreenDark,
            contentColor = Color.White,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = FarmGoldWheat,
                    height = 3.dp
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text(GameStrings.t("orders_tab", isAr), fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                modifier = Modifier.testTag("tab_daily_orders")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text(GameStrings.t("quests_tab", isAr), fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                modifier = Modifier.testTag("tab_quests")
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (selectedTab == 0) {
                // DAILY ORDERS LIST
                items(orders, key = { it.orderId }) { order ->
                    val cropId = order.requiredItemId.removePrefix("crop_")
                    val crop = GameConfig.getCropById(cropId)
                    val ownedQty = inventory.find { it.itemId == order.requiredItemId }?.quantity ?: 0
                    val canFulfill = !order.isCompleted && ownedQty >= order.requiredAmount

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("order_item_${order.orderId}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (order.isCompleted) Color(0xFFF5F5F5) else Color.White
                        ),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (order.isCompleted) Color.LightGray else FarmGreenPrimary.copy(alpha = 0.3f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = if (order.isCompleted) 0.dp else 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (order.isCompleted) Color.LightGray.copy(alpha = 0.3f)
                                                else FarmGoldWheat.copy(alpha = 0.3f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = crop?.emoji ?: "📦", fontSize = 24.sp)
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Text(
                                            text = if (isAr) order.titleAr else order.titleEn,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = if (order.isCompleted) Color.Gray else FarmGreenDark
                                        )
                                        Text(
                                            text = if (isAr) "المطلوب: ${order.requiredAmount} من ${crop?.nameAr ?: cropId}"
                                            else "Need: ${order.requiredAmount}x ${crop?.nameEn ?: cropId}",
                                            fontSize = 12.sp,
                                            color = Color.DarkGray
                                        )
                                    }
                                }

                                if (order.isCompleted) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = "Completed",
                                        tint = FarmGreenPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🎁 🪙 +${order.rewardCoins}  ⭐ +${order.rewardXp} XP",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFC17900)
                                )

                                if (!order.isCompleted) {
                                    Button(
                                        onClick = { onDeliverOrder(order.orderId) },
                                        enabled = canFulfill,
                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("deliver_order_${order.orderId}")
                                    ) {
                                        Text(
                                            text = if (canFulfill) (if (isAr) "تسليم الطلب" else "Deliver")
                                            else (if (isAr) "لديك ($ownedQty/${order.requiredAmount})" else "Own ($ownedQty/${order.requiredAmount})"),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // QUESTS LIST
                items(quests, key = { it.questId }) { quest ->
                    val isCompleted = quest.currentCount >= quest.targetCount
                    val progressRatio = (quest.currentCount.toFloat() / quest.targetCount.toFloat()).coerceIn(0f, 1f)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quest_item_${quest.questId}"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (quest.isClaimed) Color(0xFFF5F5F5) else Color.White
                        ),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (quest.isClaimed) Color.LightGray else FarmGoldWheat.copy(alpha = 0.5f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = if (quest.isClaimed) 0.dp else 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isAr) quest.titleAr else quest.titleEn,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = if (quest.isClaimed) Color.Gray else FarmGreenDark
                                    )
                                    Text(
                                        text = if (isAr) quest.descAr else quest.descEn,
                                        fontSize = 12.sp,
                                        color = Color.DarkGray
                                    )
                                }

                                if (quest.isClaimed) {
                                    Text(
                                        text = GameStrings.t("claimed", isAr),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Gray
                                    )
                                } else if (isCompleted) {
                                    Button(
                                        onClick = { onClaimQuest(quest.questId) },
                                        colors = ButtonDefaults.buttonColors(containerColor = FarmGoldWheat),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("claim_quest_${quest.questId}")
                                    ) {
                                        Text(
                                            text = GameStrings.t("claim", isAr),
                                            color = Color(0xFF3E2723),
                                            fontWeight = FontWeight.Black,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            LinearProgressIndicator(
                                progress = { progressRatio },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = if (isCompleted) FarmGreenPrimary else FarmGoldWheat,
                                trackColor = Color(0xFFEEEEEE)
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "🪙 +${quest.rewardCoins}  ⭐ +${quest.rewardXp} XP",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFC17900)
                                )
                                Text(
                                    text = "${quest.currentCount} / ${quest.targetCount}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.DarkGray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
