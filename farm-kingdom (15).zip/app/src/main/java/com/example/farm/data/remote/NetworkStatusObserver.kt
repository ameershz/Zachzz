package com.example.farm.data.remote

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

enum class ConnectionState {
    ONLINE,
    OFFLINE,
    RECONNECTING,
    SYNCING
}

class NetworkStatusObserver(context: Context) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    val connectionStatus: Flow<ConnectionState> = callbackFlow {
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(ConnectionState.ONLINE)
            }

            override fun onLost(network: Network) {
                trySend(ConnectionState.OFFLINE)
            }

            override fun onLosing(network: Network, maxMsToLive: Int) {
                trySend(ConnectionState.RECONNECTING)
            }

            override fun onUnavailable() {
                trySend(ConnectionState.OFFLINE)
            }
        }

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        connectivityManager.registerNetworkCallback(request, callback)

        // Initial state emission
        val isCurrentlyConnected = connectivityManager.activeNetwork?.let { net ->
            connectivityManager.getNetworkCapabilities(net)
                ?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
        } ?: false

        trySend(if (isCurrentlyConnected) ConnectionState.ONLINE else ConnectionState.OFFLINE)

        awaitClose {
            connectivityManager.unregisterNetworkCallback(callback)
        }
    }.distinctUntilChanged()
}
