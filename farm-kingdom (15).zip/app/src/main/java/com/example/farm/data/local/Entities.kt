package com.example.farm.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: String = "player_main",
    val username: String = "Farmer",
    val farmName: String = "Green Meadow Farm",
    val level: Int = 1,
    val xp: Int = 0,
    val coins: Int = 1000,
    val gems: Int = 10,
    val storageCapacity: Int = 100,
    val totalHarvests: Int = 0,
    val totalCoinsEarned: Long = 0L,
    val totalAnimalCollections: Int = 0,
    val totalGoodsProduced: Int = 0,
    val soundEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
    val language: String = "ar",
    val createdAt: Long = System.currentTimeMillis(),
    val lastLoginAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "farm_plots")
data class FarmPlotEntity(
    @PrimaryKey val plotIndex: Int,
    val isUnlocked: Boolean,
    val unlockLevel: Int,
    val unlockCost: Int,
    val cropId: String? = null,
    val plantedAt: Long = 0L,
    val readyAt: Long = 0L,
    val state: String = "EMPTY" // LOCKED, EMPTY, GROWING, READY
)

@Entity(tableName = "inventory_items")
data class InventoryItemEntity(
    @PrimaryKey val itemId: String,
    val category: String, // SEED, CROP, ANIMAL_PRODUCT, PROCESSED, MATERIAL
    val quantity: Int
)

@Entity(tableName = "farm_animals")
data class AnimalEntity(
    @PrimaryKey val animalId: String,
    val animalType: String, // chicken, cow, sheep
    val name: String,
    val fedAt: Long = 0L,
    val readyAt: Long = 0L,
    val state: String = "HUNGRY" // HUNGRY, PRODUCING, READY
)

@Entity(tableName = "production_buildings")
data class ProductionBuildingEntity(
    @PrimaryKey val buildingId: String, // bakery, dairy, textile_mill
    val nameEn: String,
    val nameAr: String,
    val level: Int = 1,
    val isUnlocked: Boolean = false,
    val unlockLevel: Int = 4,
    val unlockCost: Int = 750,
    val currentRecipeId: String? = null,
    val startedAt: Long = 0L,
    val readyAt: Long = 0L,
    val state: String = "IDLE" // LOCKED, IDLE, PRODUCING, READY
)

@Entity(tableName = "daily_reward")
data class DailyRewardEntity(
    @PrimaryKey val id: String = "daily_reward_singleton",
    val lastClaimedDay: Int = 0,
    val lastClaimedAt: Long = 0L
)

@Entity(tableName = "buildings")
data class BuildingEntity(
    @PrimaryKey val buildingId: String,
    val nameEn: String,
    val nameAr: String,
    val level: Int = 1,
    val isBuilt: Boolean = false,
    val unlockLevel: Int = 1,
    val costCoins: Int = 0
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val type: String,
    val descEn: String,
    val descAr: String,
    val amountCoins: Int,
    val amountXp: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_orders")
data class DailyOrderEntity(
    @PrimaryKey val orderId: String,
    val titleEn: String,
    val titleAr: String,
    val requiredItemId: String,
    val requiredAmount: Int,
    val rewardCoins: Int,
    val rewardXp: Int,
    val isCompleted: Boolean = false,
    val expiresAt: Long = 0L
)

@Entity(tableName = "quests")
data class QuestEntity(
    @PrimaryKey val questId: String,
    val titleEn: String,
    val titleAr: String,
    val descEn: String,
    val descAr: String,
    val questType: String,
    val targetCount: Int,
    val currentCount: Int = 0,
    val rewardCoins: Int,
    val rewardXp: Int,
    val isClaimed: Boolean = false
)

@Entity(tableName = "public_profiles")
data class PublicProfileEntity(
    @PrimaryKey val uid: String,
    val displayName: String,
    val farmName: String,
    val avatarId: String = "avatar_1",
    val level: Int = 1,
    val unlockedLandCount: Int = 4,
    val visitorCount: Int = 0,
    val likeCount: Int = 0,
    val isLikedByMe: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "public_farms")
data class PublicFarmEntity(
    @PrimaryKey val uid: String,
    val farmName: String,
    val ownerName: String,
    val level: Int = 1,
    val plotsJson: String = "[]",
    val animalsJson: String = "[]",
    val buildingsJson: String = "[]",
    val updatedAt: Long = System.currentTimeMillis()
)

