package com.example.farm.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

sealed interface AuthState {
    data object Initializing : AuthState
    data object Unauthenticated : AuthState
    data object Authenticating : AuthState
    data class Authenticated(val user: FirebaseUser) : AuthState
    data class Error(val message: String) : AuthState
}

class AuthManager(private val context: Context) {
    private val auth: FirebaseAuth = Firebase.auth
    private val applicationCredentialManager: CredentialManager = CredentialManager.create(context)

    private val _authState = MutableStateFlow<AuthState>(AuthState.Initializing)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _diagnosticLogs = MutableStateFlow<List<String>>(emptyList())
    val diagnosticLogs: StateFlow<List<String>> = _diagnosticLogs.asStateFlow()

    private fun addDiagnosticLog(message: String) {
        val timeStr = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val entry = "[$timeStr] $message"
        Log.d("AuthDiagnostics", entry)
        _diagnosticLogs.value = _diagnosticLogs.value + entry
    }

    init {
        val initialUser = auth.currentUser
        addDiagnosticLog("AuthManager init. Current currentUser: ${initialUser?.uid ?: "null"}")
        if (initialUser != null) {
            _authState.value = AuthState.Authenticated(initialUser)
        } else {
            _authState.value = AuthState.Unauthenticated
        }

        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            Log.d("AuthManager", "AuthStateListener fired. User: ${user?.uid}")
            if (user != null) {
                addDiagnosticLog("AuthStateListener: User authenticated (${user.uid}, ${user.email})")
                _authState.value = AuthState.Authenticated(user)
            } else {
                if (_authState.value is AuthState.Authenticated) {
                    addDiagnosticLog("AuthStateListener: User signed out")
                    _authState.value = AuthState.Unauthenticated
                }
            }
        }
    }

    fun attemptAutoSignIn(scope: CoroutineScope) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            addDiagnosticLog("Auto-sign-in check: User already logged in (${currentUser.uid})")
            _authState.value = AuthState.Authenticated(currentUser)
            return
        }

        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            addDiagnosticLog("Auto-sign-in check skipped: default_web_client_id missing (${e.message})")
            if (_authState.value is AuthState.Initializing) {
                _authState.value = AuthState.Unauthenticated
            }
            return
        }

        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(true)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(true)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        scope.launch(Dispatchers.IO) {
            try {
                addDiagnosticLog("Auto-sign-in: Attempting silent auto-select...")
                val result = applicationCredentialManager.getCredential(context, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = auth.signInWithCredential(authCredential).await()
                    authResult.user?.let {
                        addDiagnosticLog("Auto-sign-in SUCCESS: ${it.uid}")
                        _authState.value = AuthState.Authenticated(it)
                    } ?: run {
                        addDiagnosticLog("Auto-sign-in: Firebase returned null user")
                        if (_authState.value is AuthState.Initializing) {
                            _authState.value = AuthState.Unauthenticated
                        }
                    }
                } else {
                    addDiagnosticLog("Auto-sign-in: No saved google credential match")
                    if (_authState.value is AuthState.Initializing) {
                        _authState.value = AuthState.Unauthenticated
                    }
                }
            } catch (e: Exception) {
                addDiagnosticLog("Auto-sign-in silent check result: ${e.javaClass.simpleName} - ${e.message}")
                if (_authState.value is AuthState.Initializing) {
                    _authState.value = AuthState.Unauthenticated
                }
            }
        }
    }

    fun signInWithGoogle(
        activity: Activity,
        scope: CoroutineScope,
        onCancelled: () -> Unit = {}
    ) {
        _authState.value = AuthState.Authenticating
        addDiagnosticLog("==========================================")
        addDiagnosticLog("1. GOOGLE SIGN-IN STARTED")

        val clientId = try {
            activity.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            val errMsg = "Google Sign-In configuration missing: default_web_client_id not found (${e.message})"
            Log.e("AuthManager", errMsg, e)
            addDiagnosticLog("CONFIG ERROR: $errMsg")
            _authState.value = AuthState.Error(errMsg)
            return
        }

        addDiagnosticLog("Target Web Client ID: $clientId")

        // Use Activity context to instantiate CredentialManager
        val activityCredentialManager = CredentialManager.create(activity)

        scope.launch(Dispatchers.Main) {
            try {
                addDiagnosticLog("2. Requesting credential via CredentialManager...")
                var credentialResult: androidx.credentials.GetCredentialResponse? = null

                // Attempt Option 1: GetSignInWithGoogleOption
                try {
                    addDiagnosticLog("Trying GetSignInWithGoogleOption...")
                    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
                    val request = GetCredentialRequest.Builder()
                        .addCredentialOption(signInOption)
                        .build()
                    credentialResult = activityCredentialManager.getCredential(activity, request)
                    addDiagnosticLog("3. Credential received via GetSignInWithGoogleOption!")
                } catch (optionEx: Exception) {
                    Log.w("AuthManager", "GetSignInWithGoogleOption failed, attempting GetGoogleIdOption fallback: ${optionEx.javaClass.simpleName} (${optionEx.message})")
                    addDiagnosticLog("Option 1 failed [${optionEx.javaClass.simpleName}: ${optionEx.message}]. Retrying with GetGoogleIdOption fallback...")

                    // Fallback to Option 2: GetGoogleIdOption
                    val googleIdOption = GetGoogleIdOption.Builder()
                        .setFilterByAuthorizedAccounts(false)
                        .setServerClientId(clientId)
                        .setAutoSelectEnabled(false)
                        .build()
                    val fallbackRequest = GetCredentialRequest.Builder()
                        .addCredentialOption(googleIdOption)
                        .build()

                    credentialResult = activityCredentialManager.getCredential(activity, fallbackRequest)
                    addDiagnosticLog("3. Credential received via GetGoogleIdOption fallback!")
                }

                val credential = credentialResult.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                    val googleIdToken = googleIdTokenCredential.idToken
                    addDiagnosticLog("4. Google ID Token RECEIVED! (Length: ${googleIdToken.length})")

                    addDiagnosticLog("5. Authenticating with Firebase Auth (signInWithCredential)...")
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = auth.signInWithCredential(authCredential).await()

                    val user = authResult.user
                    if (user != null) {
                        addDiagnosticLog("6. FIREBASE SIGN-IN SUCCESS! UID: ${user.uid}, Email: ${user.email}")
                        _authState.value = AuthState.Authenticated(user)
                    } else {
                        val msg = "Firebase sign-in completed but returned null user."
                        addDiagnosticLog("6. FIREBASE SIGN-IN FAILED: $msg")
                        _authState.value = AuthState.Error(msg)
                    }
                } else {
                    val msg = "Unexpected credential type returned: ${credential.type}"
                    addDiagnosticLog("4. FAILED: $msg")
                    _authState.value = AuthState.Error(msg)
                }
            } catch (e: GetCredentialCancellationException) {
                val msg = "CredentialManager Exception [${e.javaClass.simpleName}]: ${e.message}"
                Log.w("AuthManager", msg, e)
                addDiagnosticLog("CANCELLATION/DISMISSAL: $msg")
                _authState.value = AuthState.Error("Google Sign-In cancelled or dismissed.\nException: ${e.javaClass.simpleName}\nDetails: ${e.message ?: "Dialog closed"}")
                onCancelled()
            } catch (e: Exception) {
                val msg = "Sign-In Error [${e.javaClass.name}]: ${e.message}"
                Log.e("AuthManager", msg, e)
                addDiagnosticLog("ERROR: $msg")
                _authState.value = AuthState.Error("Google Sign-In failed.\nException: ${e.javaClass.simpleName}\nDetails: ${e.localizedMessage ?: e.message}")
            }
        }
    }

    fun signOut(scope: CoroutineScope, onComplete: () -> Unit = {}) {
        addDiagnosticLog("Signing out from Firebase and CredentialManager...")
        auth.signOut()
        scope.launch(Dispatchers.IO) {
            try {
                applicationCredentialManager.clearCredentialState(ClearCredentialStateRequest())
                addDiagnosticLog("CredentialManager state cleared.")
            } catch (e: Exception) {
                Log.e("AuthManager", "Failed to clear credential state", e)
                addDiagnosticLog("Clear credential state error: ${e.message}")
            } finally {
                _authState.value = AuthState.Unauthenticated
                launch(Dispatchers.Main) {
                    onComplete()
                }
            }
        }
    }
}
