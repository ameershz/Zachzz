package com.example.farm.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.config.GameConfig
import com.example.farm.data.model.PublicFarm
import com.example.farm.data.model.PublicProfile
import com.example.farm.data.remote.FirestoreAnimal
import com.example.farm.data.remote.FirestoreFarmPlot
import com.example.farm.data.remote.FirestoreProductionBuilding
import com.example.farm.ui.localization.GameStrings
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenLight
import com.example.ui.theme.FarmSoilBrown


@Composable
fun VisitingFarmScreen(
    profile: PublicProfile,
    farm: PublicFarm?,
    isLoading: Boolean,
    isLiking: Boolean,
    isAr: Boolean,
    onLikeClick: () -> Unit,
    onBackToMyFarm: () -> Unit,
    modifier: Modifier = Modifier
) {
    var toastTooltip by remember { mutableStateOf<String?>(null) }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = Color(0xFFF4F1EA)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Visitor HUD Header
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = FarmGreenDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Top row: Back button & Visiting Title
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onBackToMyFarm,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f))
                                    .testTag("back_to_my_farm_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = String.format(GameStrings.t("visiting_mode_title", isAr), profile.displayName),
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Back to My Farm Chip Button
                        Button(
                            onClick = onBackToMyFarm,
                            colors = ButtonDefaults.buttonColors(containerColor = FarmGoldWheat),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = GameStrings.t("back_to_my_farm", isAr),
                                color = FarmGreenDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Player Stats Banner
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(FarmGoldWheat),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Avatar",
                                tint = FarmGreenDark,
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🏡 ${profile.farmName}",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Level ${profile.level}",
                                    color = FarmGoldWheat,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Visibility,
                                        contentDescription = "Visitors",
                                        tint = Color.White.copy(alpha = 0.8f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${profile.visitorCount}",
                                        color = Color.White,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }

                        // Like Button Component
                        Button(
                            onClick = onLikeClick,
                            enabled = !isLiking && !profile.isLikedByMe,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (profile.isLikedByMe) Color(0xFFE53935) else Color.White.copy(alpha = 0.25f),
                                disabledContainerColor = if (profile.isLikedByMe) Color(0xFFE53935) else Color.Gray
                            ),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("like_farm_button")
                        ) {
                            if (isLiking) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (profile.isLikedByMe) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                        contentDescription = "Like",
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${profile.likeCount}",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Read-only Notice Banner
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White.copy(alpha = 0.15f))
                            .padding(vertical = 6.dp, horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = FarmGoldWheat,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = GameStrings.t("visiting_read_only_msg", isAr),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = FarmGreenDark)
                }
            } else if (farm != null) {
                // Section 1: Kingdom Plots
                Text(
                    text = if (isAr) "🌾 أرض المزرعة" else "🌾 Farmland Plots",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = FarmGreenDark
                )
                Spacer(modifier = Modifier.height(8.dp))

                val plots = farm.plots
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height((Math.max(1, (plots.size + 2) / 3) * 110).dp),
                    userScrollEnabled = false
                ) {
                    items(plots, key = { it.plotIndex }) { plot ->
                        ReadOnlyPlotCard(
                            plot = plot,
                            isAr = isAr,
                            onClick = {
                                toastTooltip = GameStrings.t("visiting_read_only_msg", isAr)
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Section 2: Farm Animals
                if (farm.animals.isNotEmpty()) {
                    Text(
                        text = if (isAr) "🐔 حيوانات المزرعة" else "🐔 Farm Animals",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        farm.animals.forEach { animal ->
                            ReadOnlyAnimalCard(
                                animal = animal,
                                isAr = isAr,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Section 3: Production Buildings
                if (farm.buildings.isNotEmpty()) {
                    Text(
                        text = if (isAr) "🏭 ورشات الإنتاج" else "🏭 Production Workshops",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        farm.buildings.forEach { building ->
                            ReadOnlyBuildingCard(
                                building = building,
                                isAr = isAr,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReadOnlyPlotCard(
    plot: FirestoreFarmPlot,
    isAr: Boolean,
    onClick: () -> Unit
) {
    val cropConfig = GameConfig.CROPS.find { it.id == plot.cropId }
    val cropEmoji = cropConfig?.emoji ?: "🌱"
    val cropName = if (isAr) cropConfig?.nameAr ?: "" else cropConfig?.nameEn ?: ""


    val containerColor = when {
        !plot.isUnlocked -> Color(0xFFD7CCC8)
        plot.state == "READY" -> Color(0xFFFFF8E1)
        plot.state == "GROWING" -> Color(0xFFE8F5E9)
        else -> Color(0xFFEFEBE9)
    }

    val borderColor = when {
        !plot.isUnlocked -> Color(0xFFA1887F)
        plot.state == "READY" -> FarmGoldWheat
        plot.state == "GROWING" -> FarmGreenLight
        else -> Color(0xFFD7CCC8)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .border(1.5.dp, borderColor, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp),
            contentAlignment = Alignment.Center
        ) {
            if (!plot.isUnlocked) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = GameStrings.t("plot_locked", isAr),
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            } else if (plot.state == "READY") {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = cropEmoji, fontSize = 28.sp)
                    Text(
                        text = cropName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FarmGreenDark
                    )
                    Text(
                        text = "Ready!",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF388E3C)
                    )
                }
            } else if (plot.state == "GROWING") {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = cropEmoji, fontSize = 24.sp)
                    Text(
                        text = cropName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = FarmSoilBrown
                    )
                    Text(

                        text = GameStrings.t("plot_growing", isAr),
                        fontSize = 9.sp,
                        color = Color.Gray
                    )
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "🤎", fontSize = 20.sp)
                    Text(
                        text = GameStrings.t("plot_empty", isAr),
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

@Composable
private fun ReadOnlyAnimalCard(
    animal: FirestoreAnimal,
    isAr: Boolean,
    modifier: Modifier = Modifier
) {
    val emoji = when (animal.animalType) {
        "chicken" -> "🐔"
        "cow" -> "🐄"
        "sheep" -> "🐑"
        else -> "🐾"
    }

    Card(
        modifier = modifier.height(90.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = emoji, fontSize = 24.sp)
            Text(
                text = animal.name.ifEmpty { animal.animalType.capitalize() },
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Text(
                text = animal.state,
                fontSize = 9.sp,
                color = if (animal.state == "READY") Color(0xFF388E3C) else Color.Gray
            )
        }
    }
}

@Composable
private fun ReadOnlyBuildingCard(
    building: FirestoreProductionBuilding,
    isAr: Boolean,
    modifier: Modifier = Modifier
) {
    val name = when (building.buildingId) {
        "bakery" -> if (isAr) "المخبز" else "Bakery"
        "dairy" -> if (isAr) "الألبان" else "Dairy"
        "textile_mill" -> if (isAr) "المغزل" else "Textile Mill"
        else -> building.buildingId
    }
    val emoji = when (building.buildingId) {
        "bakery" -> "🍞"
        "dairy" -> "🧀"
        "textile_mill" -> "🧵"
        else -> "🏭"
    }

    Card(
        modifier = modifier.height(90.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = if (building.isUnlocked) Color.White else Color(0xFFE0E0E0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = emoji, fontSize = 24.sp)
            Text(
                text = name,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Text(
                text = if (building.isUnlocked) "Lvl ${building.level}" else "Locked",
                fontSize = 9.sp,
                color = Color.Gray
            )
        }
    }
}
