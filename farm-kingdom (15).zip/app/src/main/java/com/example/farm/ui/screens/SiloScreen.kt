package com.example.farm.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.config.GameConfig
import com.example.farm.data.local.InventoryItemEntity
import com.example.farm.data.local.PlayerProfileEntity
import com.example.farm.ui.localization.GameStrings
import com.example.ui.theme.FarmGoldDark
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary

@Composable
fun SiloScreen(
    player: PlayerProfileEntity?,
    inventory: List<InventoryItemEntity>,
    isAr: Boolean,
    onSellItem: (String, Int) -> Unit,
    onUpgradeStorage: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf("ALL") }

    val totalItems = inventory.sumOf { it.quantity }
    val maxCapacity = player?.storageCapacity ?: GameConfig.STARTING_STORAGE
    val capacityRatio = (totalItems.toFloat() / maxCapacity.toFloat()).coerceIn(0f, 1f)

    val upgradesDone = (maxCapacity - GameConfig.STARTING_STORAGE) / GameConfig.STORAGE_UPGRADE_INCREMENT
    val upgradeCost = GameConfig.BASE_STORAGE_UPGRADE_COST + (upgradesDone * 400)
    val canUpgrade = (player?.coins ?: 0) >= upgradeCost

    val filteredItems = inventory.filter {
        when (selectedCategory) {
            "SEEDS" -> it.category == "SEED"
            "CROPS" -> it.category == "CROP"
            else -> true
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9FBF7)),
        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Storage Header & Capacity Meter
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = FarmGreenDark),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(FarmGoldWheat),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "📦", fontSize = 24.sp)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = GameStrings.t("silo_title", isAr),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = GameStrings.t("silo_capacity", isAr).format(totalItems, maxCapacity),
                                    color = if (totalItems >= maxCapacity) Color(0xFFFF8A80) else Color.White.copy(alpha = 0.85f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        // Upgrade Button
                        Button(
                            onClick = onUpgradeStorage,
                            enabled = canUpgrade,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = FarmGoldWheat,
                                contentColor = Color(0xFF3E2723)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("upgrade_storage_btn")
                        ) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "🪙 $upgradeCost", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { capacityRatio },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (capacityRatio > 0.9f) Color(0xFFFF5252) else FarmGoldWheat,
                        trackColor = Color.White.copy(alpha = 0.25f)
                    )
                }
            }
        }

        // Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == "ALL",
                    onClick = { selectedCategory = "ALL" },
                    label = { Text(GameStrings.t("cat_all", isAr)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FarmGreenPrimary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedCategory == "SEEDS",
                    onClick = { selectedCategory = "SEEDS" },
                    label = { Text(GameStrings.t("cat_seeds", isAr)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FarmGreenPrimary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedCategory == "CROPS",
                    onClick = { selectedCategory = "CROPS" },
                    label = { Text(GameStrings.t("cat_crops", isAr)) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FarmGreenPrimary,
                        selectedLabelColor = Color.White
                    )
                )
                FilterChip(
                    selected = selectedCategory == "PRODUCTS",
                    onClick = { selectedCategory = "PRODUCTS" },
                    label = { Text(if (isAr) "المنتجات" else "Goods") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FarmGreenPrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Items List
        if (filteredItems.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🌾", fontSize = 42.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = GameStrings.t("empty_inventory", isAr),
                            fontSize = 13.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        } else {
            items(filteredItems, key = { it.itemId }) { item ->
                val isSeed = item.category == "SEED" || item.itemId.endsWith("_seed")
                val isCrop = item.category == "CROP" || item.itemId.startsWith("crop_")
                val cropId = if (isCrop) item.itemId.removePrefix("crop_") else if (isSeed) item.itemId.removeSuffix("_seed") else item.itemId
                val crop = GameConfig.getCropById(cropId)
                val animal = GameConfig.ANIMALS.find { it.productItemId == item.itemId || it.productItemId == item.itemId.removePrefix("item_") }
                val recipe = GameConfig.RECIPES.find { it.outputItemId == item.itemId }

                val itemEmoji = when {
                    recipe != null -> recipe.emoji
                    animal != null -> when (animal.productItemId) {
                        "egg" -> "🥚"
                        "milk" -> "🥛"
                        "wool" -> "🧶"
                        else -> animal.emoji
                    }
                    crop != null -> if (isSeed) "🌱" else crop.emoji
                    else -> "📦"
                }

                val itemName = when {
                    recipe != null -> if (isAr) recipe.outputNameAr else recipe.outputNameEn
                    animal != null -> if (isAr) animal.productNameAr else animal.productNameEn
                    crop != null -> when {
                        isCrop -> if (isAr) crop.nameAr else crop.nameEn
                        else -> if (isAr) "بذور ${crop.nameAr}" else "${crop.nameEn} Seeds"
                    }
                    else -> item.itemId
                }

                val unitSellPrice = when {
                    recipe != null -> recipe.sellPrice
                    animal != null -> animal.productSellPrice
                    crop != null -> if (isCrop) crop.sellPrice else ((crop.seedPrice) / 2).coerceAtLeast(1)
                    else -> 10
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("silo_item_${item.itemId}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE0E0E0))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(FarmGoldWheat.copy(alpha = 0.25f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = itemEmoji, fontSize = 24.sp)
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = itemName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = FarmGreenDark
                                )
                                Text(
                                    text = "💰 ${unitSellPrice} Coins / item",
                                    fontSize = 11.sp,
                                    color = FarmGoldDark,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = if (isAr) "الكمية: ${item.quantity}" else "Qty: ${item.quantity}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.DarkGray
                                )
                            }
                        }

                        // Sell Action Buttons
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = { onSellItem(item.itemId, 1) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("sell_1_${item.itemId}")
                            ) {
                                Text(text = if (isAr) "بيع 1" else "Sell 1", fontSize = 11.sp)
                            }

                            Button(
                                onClick = { onSellItem(item.itemId, item.quantity) },
                                colors = ButtonDefaults.buttonColors(containerColor = FarmGoldDark),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("sell_all_${item.itemId}")
                            ) {
                                Text(
                                    text = if (isAr) "بيع الكل (+${unitSellPrice * item.quantity})"
                                    else "Sell All (+${unitSellPrice * item.quantity})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
