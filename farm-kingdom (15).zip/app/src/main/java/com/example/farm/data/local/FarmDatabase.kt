package com.example.farm.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.withTransaction
import com.example.farm.data.config.GameConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        PlayerProfileEntity::class,
        FarmPlotEntity::class,
        InventoryItemEntity::class,
        AnimalEntity::class,
        ProductionBuildingEntity::class,
        DailyRewardEntity::class,
        BuildingEntity::class,
        TransactionEntity::class,
        DailyOrderEntity::class,
        QuestEntity::class,
        PublicProfileEntity::class,
        PublicFarmEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class FarmDatabase : RoomDatabase() {
    abstract fun playerDao(): PlayerDao
    abstract fun farmPlotDao(): FarmPlotDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun animalDao(): AnimalDao
    abstract fun productionBuildingDao(): ProductionBuildingDao
    abstract fun dailyRewardDao(): DailyRewardDao
    abstract fun buildingDao(): BuildingDao
    abstract fun transactionDao(): TransactionDao
    abstract fun dailyOrderDao(): DailyOrderDao
    abstract fun questDao(): QuestDao
    abstract fun publicProfileDao(): PublicProfileDao
    abstract fun publicFarmDao(): PublicFarmDao


    companion object {
        @Volatile
        private var INSTANCE: FarmDatabase? = null

        fun getDatabase(context: Context): FarmDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FarmDatabase::class.java,
                    "farm_kingdom_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance

                // Prepopulate on background coroutine if empty
                CoroutineScope(Dispatchers.IO).launch {
                    instance.prepopulateIfEmpty()
                }

                instance
            }
        }
    }

    suspend fun prepopulateIfEmpty() {
        withTransaction {
            val player = playerDao().getPlayerDirect()
            if (player == null) {
                // Seed Player Profile
                playerDao().insertOrUpdate(
                    PlayerProfileEntity(
                        id = "player_main",
                        username = "Farmer King",
                        farmName = "Green Meadow Farm",
                        level = 1,
                        xp = 0,
                        coins = GameConfig.STARTING_COINS,
                        gems = GameConfig.STARTING_GEMS,
                        storageCapacity = GameConfig.STARTING_STORAGE
                    )
                )

                // Seed 12 plots
                val plots = mutableListOf<FarmPlotEntity>()
                for (i in 0 until GameConfig.INITIAL_PLOTS_COUNT) {
                    if (i < GameConfig.INITIAL_UNLOCKED_COUNT) {
                        plots.add(
                            FarmPlotEntity(
                                plotIndex = i,
                                isUnlocked = true,
                                unlockLevel = 1,
                                unlockCost = 0,
                                cropId = null,
                                plantedAt = 0L,
                                readyAt = 0L,
                                state = "EMPTY"
                            )
                        )
                    } else {
                        val costInfo = GameConfig.PLOT_EXPANSION_COSTS.getOrNull(i - GameConfig.INITIAL_UNLOCKED_COUNT)
                        plots.add(
                            FarmPlotEntity(
                                plotIndex = i,
                                isUnlocked = false,
                                unlockLevel = costInfo?.first ?: (i - 4),
                                unlockCost = costInfo?.second ?: (i * 500),
                                cropId = null,
                                plantedAt = 0L,
                                readyAt = 0L,
                                state = "LOCKED"
                            )
                        )
                    }
                }
                farmPlotDao().insertPlots(plots)

                // Seed starter inventory
                inventoryDao().insertOrUpdate(
                    InventoryItemEntity(itemId = "wheat_seed", category = "SEED", quantity = 10)
                )
                inventoryDao().insertOrUpdate(
                    InventoryItemEntity(itemId = "corn_seed", category = "SEED", quantity = 6)
                )
                inventoryDao().insertOrUpdate(
                    InventoryItemEntity(itemId = "carrot_seed", category = "SEED", quantity = 4)
                )

                // Seed starter animals (Chicken unlocked at level 3, start with 1 starter chicken)
                animalDao().insertAnimals(
                    listOf(
                        AnimalEntity("chicken_1", "chicken", "Pippa the Hen", fedAt = 0L, readyAt = 0L, state = "HUNGRY")
                    )
                )

                // Seed production buildings
                productionBuildingDao().insertBuildings(
                    listOf(
                        ProductionBuildingEntity("bakery", "Royal Bakery", "المخبز الملكي", level = 1, isUnlocked = false, unlockLevel = 4, unlockCost = 750),
                        ProductionBuildingEntity("dairy", "Artisan Dairy", "معمل الألبان", level = 1, isUnlocked = false, unlockLevel = 6, unlockCost = 1600),
                        ProductionBuildingEntity("textile_mill", "Textile Mill", "مصنع النسيج", level = 1, isUnlocked = false, unlockLevel = 9, unlockCost = 3500)
                    )
                )

                // Seed daily reward tracker
                dailyRewardDao().insertOrUpdate(
                    DailyRewardEntity("daily_reward_singleton", lastClaimedDay = 0, lastClaimedAt = 0L)
                )

                // Seed initial daily orders
                dailyOrderDao().insertOrders(
                    listOf(
                        DailyOrderEntity("order_1", "Grand Wheat Delivery", "توريد قمح ملكي", "crop_wheat", 4, 150, 45, false, System.currentTimeMillis() + 86400000L),
                        DailyOrderEntity("order_2", "Fresh Sweet Corn", "ذرة حلوة طازجة", "crop_corn", 2, 220, 70, false, System.currentTimeMillis() + 86400000L),
                        DailyOrderEntity("order_3", "Crispy Carrots Supply", "سلة جزر مقرمش", "crop_carrot", 2, 380, 120, false, System.currentTimeMillis() + 86400000L),
                        DailyOrderEntity("order_4", "Fresh Farm Eggs Basket", "سلة بيض طازج", "egg", 3, 300, 90, false, System.currentTimeMillis() + 86400000L),
                        DailyOrderEntity("order_5", "Village Bakery Bread", "خبز القرية الذهبي", "item_bread", 2, 450, 140, false, System.currentTimeMillis() + 86400000L)
                    )
                )

                // Seed initial quests
                questDao().insertQuests(
                    listOf(
                        QuestEntity("quest_1", "Green Beginning", "بداية خضراء", "Plant 3 crops on your farm", "ازرع 3 محاصيل في مزرعتك", "PLANT_CROPS", 3, 0, 150, 40, false),
                        QuestEntity("quest_2", "First Bounty", "أول حصاد", "Harvest 3 mature crops", "احصد 3 محاصيل ناضجة", "HARVEST_CROPS", 3, 0, 200, 60, false),
                        QuestEntity("quest_3", "Caring Farmer", "مزارع حنون", "Feed your farm animals 2 times", "أطعم حيوانات المزرعة مرتين", "FEED_ANIMALS", 2, 0, 250, 75, false),
                        QuestEntity("quest_4", "Fresh Harvest Egg", "سلة الخيرات", "Collect 2 fresh eggs from chickens", "اجمع بيضتين طازجتين من الدجاج", "COLLECT_ANIMAL_PRODUCTS", 2, 0, 300, 90, false),
                        QuestEntity("quest_5", "Kingdom Trader", "تاجر المملكة", "Earn 500 Coins from your farm", "اكسب 500 قطعة نقدية من منتجاتك", "EARN_COINS", 500, 0, 350, 100, false),
                        QuestEntity("quest_6", "Master Farmer", "مزارع خبير", "Reach Level 3 in the Kingdom", "صل إلى المستوى 3 في المملكة", "LEVEL_UP", 3, 1, 600, 200, false)
                    )
                )

                // Initial transaction log
                transactionDao().insert(
                    TransactionEntity(
                        type = "WELCOME",
                        descEn = "Welcome to Farm Kingdom! Starting capital granted.",
                        descAr = "مرحباً بك في مملكة المزرعة! تم منح رأس المال المبدئي.",
                        amountCoins = GameConfig.STARTING_COINS,
                        amountXp = 0
                    )
                )
            }
        }
    }
}
