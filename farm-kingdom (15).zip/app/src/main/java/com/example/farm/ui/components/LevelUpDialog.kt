package com.example.farm.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.farm.data.config.GameConfig
import com.example.farm.ui.localization.GameStrings
import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmGreenPrimary

@Composable
fun LevelUpDialog(
    newLevel: Int,
    isAr: Boolean,
    onDismiss: () -> Unit
) {
    val unlockedCrops = GameConfig.CROPS.filter { it.unlockLevel == newLevel }
    val unlockedAnimals = GameConfig.ANIMALS.filter { it.requiredLevel == newLevel }
    val unlockedBuildings = GameConfig.BUILDINGS.filter { it.unlockLevel == newLevel }
    val hasUnlocks = unlockedCrops.isNotEmpty() || unlockedAnimals.isNotEmpty() || unlockedBuildings.isNotEmpty()

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = FarmGreenPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("level_up_continue_btn")
            ) {
                Text(
                    text = if (isAr) "متابعة الزراعة والازدهار 🌾" else "Continue Farming 🌾",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(FarmGoldWheat),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "👑", fontSize = 42.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isAr) "🎉 ترقية في المملكة! 🎉" else "🎉 LEVEL UP! 🎉",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = FarmGreenDark,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isAr) "تهانينا! لقد وصلت إلى المستوى $newLevel"
                    else "Congratulations! You reached Farm Level $newLevel",
                    fontSize = 14.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Center
                )

                if (hasUnlocks) {
                    Spacer(modifier = Modifier.height(14.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (isAr) "✨ تم فتح إمكانيات جديدة:" else "✨ New Unlocks Available:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = FarmGreenDark
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            unlockedCrops.forEach { crop ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                ) {
                                    Text(text = crop.emoji, fontSize = 18.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isAr) "محصول: ${crop.nameAr}" else "Crop: ${crop.nameEn}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = FarmGreenPrimary
                                    )
                                }
                            }

                            unlockedAnimals.forEach { animal ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                ) {
                                    Text(text = animal.emoji, fontSize = 18.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isAr) "مواشي: ${animal.nameAr}" else "Animal: ${animal.nameEn}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF1976D2)
                                    )
                                }
                            }

                            unlockedBuildings.forEach { b ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                ) {
                                    Text(text = b.emoji, fontSize = 18.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isAr) "معمل: ${b.nameAr}" else "Building: ${b.nameEn}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFFE65100)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    )
}
