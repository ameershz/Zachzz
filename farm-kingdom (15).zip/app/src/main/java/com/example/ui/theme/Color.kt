package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Farm Kingdom Palette - Rich, Warm, Countryside Palette
val FarmGreenPrimary = Color(0xFF2E7D32)
val FarmGreenDark = Color(0xFF1B5E20)
val FarmGreenLight = Color(0xFF81C784)
val FarmGreenContainer = Color(0xFFD7E8CD)
val FarmOnGreenContainer = Color(0xFF0F200E)

val FarmLawnGreen = Color(0xFF43A047)
val FarmSproutGreen = Color(0xFF66BB6A)
val FarmPastureLight = Color(0xFFE8F5E9)

val FarmGoldWheat = Color(0xFFF9A825)
val FarmGoldDark = Color(0xFFC17900)
val FarmGoldLight = Color(0xFFFFF275)
val FarmGoldContainer = Color(0xFFFFECC2)
val FarmAmberGlow = Color(0xFFFFB300)

val FarmSoilBrown = Color(0xFF5D4037)
val FarmSoilLight = Color(0xFF8D6E63)
val FarmSoilDark = Color(0xFF3E2723)
val FarmSoilFertile = Color(0xFF4E342E)

val FarmParchment = Color(0xFFFFFDF5)
val FarmParchmentBorder = Color(0xFFFFE0B2)

val FarmGrassBg = Color(0xFFF4F9F2)
val FarmGrassDarkBg = Color(0xFF121B13)

val FarmCardBg = Color(0xFFFFFFFF)
val FarmCardDarkBg = Color(0xFF1A261C)

val FarmSkyBlue = Color(0xFF29B6F6)
val FarmGemPurple = Color(0xFFAB47BC)
val FarmRedHarvest = Color(0xFFE53935)
val FarmEggYellow = Color(0xFFFFEE58)
val FarmMilkWhite = Color(0xFFFAFAFA)
val FarmWoolIvory = Color(0xFFF5F5F0)
