package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = FarmGreenLight,
    onPrimary = Color.Black,
    primaryContainer = FarmGreenDark,
    onPrimaryContainer = FarmGreenContainer,
    secondary = FarmGoldLight,
    onSecondary = Color.Black,
    secondaryContainer = FarmGoldDark,
    tertiary = FarmSoilLight,
    background = FarmGrassDarkBg,
    surface = FarmCardDarkBg,
    onBackground = Color(0xFFE8F5E9),
    onSurface = Color(0xFFE8F5E9)
)

private val LightColorScheme = lightColorScheme(
    primary = FarmGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = FarmGreenContainer,
    onPrimaryContainer = FarmOnGreenContainer,
    secondary = FarmGoldWheat,
    onSecondary = Color.Black,
    secondaryContainer = FarmGoldContainer,
    tertiary = FarmSoilBrown,
    background = FarmGrassBg,
    surface = FarmCardBg,
    onBackground = Color(0xFF1B2E1D),
    onSurface = Color(0xFF1B2E1D)
)

@Composable
fun FarmKingdomTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep farm branding consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
