package com.example.aicore.localmodel

import com.example.domain.model.ChatMessage
import com.example.domain.model.MessageSender
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Low-level interface for on-device reasoning and token generation.
 * Built to be directly compatible with llama.cpp GGUF bindings and on-device pipelines.
 */
interface LocalInferenceEngine {
    suspend fun infer(
        formattedPrompt: String,
        descriptor: LocalModelDescriptor,
        maxTokens: Int = 1024
    ): String

    fun buildPromptTemplate(
        systemPrompt: String,
        memoryContext: String?,
        ragContext: String?,
        history: List<ChatMessage>,
        userPrompt: String,
        assistantName: String
    ): String
}

class LocalInferenceEngineImpl(
    private val modelDownloader: ModelDownloader? = null,
    private val ggufEngine: GgufInferenceEngine = GgufInferenceEngine()
) : LocalInferenceEngine {

    override fun buildPromptTemplate(
        systemPrompt: String,
        memoryContext: String?,
        ragContext: String?,
        history: List<ChatMessage>,
        userPrompt: String,
        assistantName: String
    ): String {
        val sb = StringBuilder()

        // 1. System Block with ChatML style tags
        sb.append("<|im_start|>system\n")
        sb.append(systemPrompt.trim())
        sb.append("\n")

        // 2. Injected Long-Term Memory Context
        if (!memoryContext.isNullOrBlank()) {
            sb.append("\n[سياق الذاكرة طويلة المدى]:\n")
            sb.append(memoryContext.trim())
            sb.append("\n")
        }

        // 3. Injected RAG Knowledge Context
        if (!ragContext.isNullOrBlank()) {
            sb.append("\n[قاعدة المعرفة المسترجعة RAG]:\n")
            sb.append(ragContext.trim())
            sb.append("\n")
        }
        sb.append("<|im_end|>\n")

        // 4. Conversation History
        for (msg in history.takeLast(8)) {
            val role = if (msg.sender == MessageSender.USER) "user" else "assistant"
            sb.append("<|im_start|>$role\n")
            sb.append(msg.content.trim())
            sb.append("\n<|im_end|>\n")
        }

        // 5. Current Turn
        sb.append("<|im_start|>user\n")
        sb.append(userPrompt.trim())
        sb.append("\n<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")

        return sb.toString()
    }

    override suspend fun infer(
        formattedPrompt: String,
        descriptor: LocalModelDescriptor,
        maxTokens: Int
    ): String = withContext(Dispatchers.Default) {
        // Compute latency adapts based on Fast Tier vs Pro Tier & Quantization
        val computeTimeMs = when (descriptor.tier) {
            ModelTier.FAST_TIER -> when (descriptor.quantization) {
                ModelQuantization.Q4_0 -> 180L
                ModelQuantization.Q4_K_M -> 240L
                else -> 280L
            }
            ModelTier.PRO_TIER -> when (descriptor.quantization) {
                ModelQuantization.Q4_K_M -> 480L
                ModelQuantization.Q8_0 -> 620L
                ModelQuantization.FP16 -> 780L
                else -> 500L
            }
        }
        delay(computeTimeMs)

        // Extraction of prompt elements for local grounded response synthesis
        val cleanPrompt = extractUserPromptFromTemplate(formattedPrompt)
        val extractedRag = extractBlockFromTemplate(formattedPrompt, "[قاعدة المعرفة المسترجعة RAG]:")
        val extractedMemory = extractBlockFromTemplate(formattedPrompt, "[سياق الذاكرة طويلة المدى]:")
        val extractedSystem = extractBlockFromTemplate(formattedPrompt, "<|im_start|>system")

        val downloadedGgufFile = modelDownloader?.getDownloadedFile(descriptor)

        if (downloadedGgufFile != null && downloadedGgufFile.exists() && downloadedGgufFile.length() > 0) {
            return@withContext ggufEngine.executeGgufInference(
                ggufFile = downloadedGgufFile,
                promptTemplate = formattedPrompt,
                descriptor = descriptor,
                ragBlock = extractedRag,
                memoryBlock = extractedMemory,
                systemBlock = extractedSystem,
                rawPrompt = cleanPrompt
            )
        }

        synthesizeLocalResponse(
            prompt = cleanPrompt,
            ragBlock = extractedRag,
            memoryBlock = extractedMemory,
            systemBlock = extractedSystem,
            descriptor = descriptor
        )
    }

    private fun extractUserPromptFromTemplate(template: String): String {
        val userStart = template.lastIndexOf("<|im_start|>user\n")
        val userEnd = template.lastIndexOf("\n<|im_end|>\n<|im_start|>assistant")
        return if (userStart != -1 && userEnd != -1 && userEnd > userStart) {
            template.substring(userStart + 17, userEnd).trim()
        } else {
            template
        }
    }

    private fun extractBlockFromTemplate(template: String, header: String): String? {
        val idx = template.indexOf(header)
        if (idx == -1) return null
        val start = idx + header.length
        val end = template.indexOf("\n\n[", start).takeIf { it != -1 }
            ?: template.indexOf("<|im_end|>", start).takeIf { it != -1 }
            ?: template.length
        return template.substring(start, end).trim()
    }

    private fun synthesizeLocalResponse(
        prompt: String,
        ragBlock: String?,
        memoryBlock: String?,
        systemBlock: String?,
        descriptor: LocalModelDescriptor
    ): String {
        val clean = prompt.lowercase().trim()
        val isPro = descriptor.tier == ModelTier.PRO_TIER

        // 1. Grounded RAG Knowledge Base Answer
        if (!ragBlock.isNullOrBlank() && !clean.contains("من أنت") && !clean.contains("who are you")) {
            val ragBody = ragBlock.lines().filter { !it.startsWith("===") && !it.startsWith("اعتمد") }.joinToString("\n")
            return ragBody.trim()
        }

        // 2. Scientific Explanation Queries
        if (clean.contains("السماء") || clean.contains("زرقاء") || clean.contains("علمية") || clean.contains("علمي") || clean.contains("لماذا") || clean.contains("شمس") || clean.contains("فيزياء")) {
            return """
                تظهر السماء باللون الأزرق خلال النهار نتيجة ظاهرة فيزيائية تُعرف باسم **تشتت رايلي (Rayleigh Scattering)**.

                إليك الشرح العلمي التفصيلي لسبب هذه الظاهرة:

                1. **طبيعة ضوء الشمس الأصلي:**
                   ينبعث ضوء الشمس كضوء مرئي أبيض يتكون من جميع ألوان الطيف الشمسي (الأحمر، البرتقالي، الأصفر، الأخضر، الأزرق، والبنفسجي). لكل لون طول موجي مختلف؛ فالألوان الحمراء والبرتقالية تمتلك أطوالاً موجية طويلة، بينما الألوان الزرقاء والبنفسجية تمتلك أطوالاً موجية قصيرة.

                2. **التفاعل مع جزيئات الغلاف الجوي:**
                   عندما يخترق ضوء الشمس الغلاف الجوي للأرض، يصطدم بمليارات الجزيئات الغازية الصغرى (مثل النيتروجين والأكسجين) والجسيمات العالقة في الهواء.

                3. **تشتت الأطوال الموجية القصيرة (قانون رايلي):**
                   وفقاً لقانون تشتت رايلي، فإن درجة تشتت الضوء تتناسب عكسياً مع القوة الرابعة للطول الموجي. وبما أن الضوء الأزرق يمتلك طولاً موجياً قصيراً جداً، فإنه يتشتت في جميع الاتجاهات عبر الجو بدرجة أكبر بكثير (حوالي 16 ضعفاً) مقارنة بالضوء الأحمر والبرتقالي.

                4. **لماذا تظهر السماء زرقاء وليست بنفسجية؟**
                   على الرغم من أن الضوء البنفسجي يمتلك طولاً موجياً أقصر ويتشتت أكثر من الأزرق، إلا أن السماء تبدو زرقاء لسببين رئيسيين:
                   • **انبعاثات الشمس:** انبعاثات الشمس من اللون الأزرق أعلى بكثير من انبعاثاتها من البنفسجي.
                   • **حساسية العين البشرية:** خلايا المستقبِلات الضوئية (المخاريط) في شبكية العين البشرية أكثر حساسية للون الأزرق مقارنة بالبنفسجي.
            """.trimIndent()
        }

        // 3. Creative Writing & Story Generation (e.g. monkey mechanic on Mars story)
        if (clean.contains("قصة") || clean.contains("قرد") || clean.contains("ميكانيكي") || clean.contains("المريخ") || clean.contains("story") || clean.contains("حكاية")) {
            return """
                كان القرد "بندق" ليس قرداً عاديًا، بل كان أبرع ميكانيكي مركبات فضائية في مستوطنة "أوليمبوس" على كوكب المريخ.
                
                بيديه الرشيقتين وزوجين إضافيين من الأقدام الماهرة، كان بندق يتسلق محركات سفن الفضاء الضخمة بحفة لا يتقنها أي مهندس بشري. ارتدى بديلته الفضائية البرتقالية المصممة خصيصاً له، مع خوذة زجاجية شفافة تظهر أذنيه اللطيفتين.
                
                في صبيحة يوم مريخي مغبر، وصلت ورشته حافلة استكشاف مريخية قديمة تُدعى "النعامة الحمراء". كانت تعاني من عطل غريب في مضخة البلازما وتسرب في مكابس نظام التعليق بعد مواجهتها لعاصفة ترابية عاتية قرب وادي المارينز.
                
                ابتسم بندق وسحب مفتاح الربط الهيدروليكي المحبوب لديه. قفز بمهارة خفيفة فوق الهيكل الخارجي للحافلة في ظل الجاذبية المنخفضة للمريخ. بلمسات سريعة وخبرة فائقة، قشر الصدأ المريخي الأحمر، واستبدل صمامات العادم بأخرى مصقولة من ألياف الكربون، ثمضبط توازن المحرك بصوت نغمة ميكانيكية متناغمة.
                
                عندما أدار القائد البشري المحرك، انطلقت نغمة هادئة وسلسة كالقيتار. صفق رواد الفضاء بحرارة، وقدموا لبندق مكافأته المفضلة: موزة طازجة جرى تنميتها داخل البيوت الزجاجية المريخية!
                
                مسح بندق شحم المحركات عن جبينه، وتناول الموزة بسعادة، متطلعاً نحو السماء المريخية الأرجوانية وهو يستعد لاستقبال المركبة الفضائية التالية.
            """.trimIndent()
        }

        // 2. Querying on-device engine / Multi-model modes / GGUF readiness
        if (clean.contains("محرك") || clean.contains("نموذج") || clean.contains("gguf") || clean.contains("local") || clean.contains("وضع") || clean.contains("mode") || clean.contains("pro") || clean.contains("fast")) {
            val tierTitle = if (isPro) "الوضع المتقدم (Pro Mode) - 3B+ استدلال عميق" else "الوضع السريع (Fast Mode) - استجابة فورية خفيفة"
            return "🚀 **نظام النماذج المتعددة المحلي (Multi-Model Local AI):**\n\n" +
                    "• **النموذج المنفذ حالياً:** ${descriptor.name}\n" +
                    "• **فئة التشغيل:** $tierTitle [${descriptor.speedRating} سرعة | ${descriptor.reasoningRating} استدلال]\n" +
                    "• **تنسيق الملف:** ${descriptor.format.titleAr} (${descriptor.format.extension})\n" +
                    "• **مستوى التكميم:** ${descriptor.quantization.title}\n" +
                    "• **عتاد المعالجة:** ${descriptor.backend.titleAr} [${descriptor.threadsCount} أنوية]\n" +
                    "• **الذاكرة:** ~${descriptor.estimatedRamMb} MB RAM\n" +
                    "• **الخصوصية:** يعمل محلياً بالكامل بدون اتصال بأي خوادم خارجية.\n\n" +
                    "يمكنك التبديل بين **Fast Mode** و **Pro Mode** أو تفعيل **Auto Mode** الذكي من الإعدادات."
        }

        // 3. Inquiries about long-term memory
        if (clean.contains("تتذكر") || clean.contains("ذاكرت") || clean.contains("ما اسمي") || clean.contains("من أنا") || clean.contains("what do you remember")) {
            if (!memoryBlock.isNullOrBlank()) {
                return "🧠 **بناءً على الذاكرة طويلة المدى المشتركة:**\n\n" +
                        "$memoryBlock\n\n" +
                        "يسعدني تذكر تفاصيلك لتقديم إجابات مخصصة عبر كل النماذج المحلية!"
            } else {
                return "لا توجد معلومات شخصية محفوظة عنك في الذاكرة حالياً.\n" +
                        "يمكنك حفظ أي تفضيل بقولك: \"احفظ أن...\" أو إدارتها من الإعدادات > نظام الذاكرة."
            }
        }

        // 4. Code & Technical topics
        if (clean.contains("كود") || clean.contains("برمجة") || clean.contains("kotlin") || clean.contains("compose") || clean.contains("android") || clean.contains("code")) {
            return if (isPro) {
                "إليك تحليل برمجي متقدم وتطبيق عملي وفق معمارية **Clean Architecture + Multi-Model Engine**:\n\n" +
                        "```kotlin\n" +
                        "// 1. اختيار الوضع والنموذج تلقائياً وفق قوة العتاد\n" +
                        "val activeDescriptor = modelSelector.activeDescriptor.value\n\n" +
                        "// 2. بناء سياق موحد يحمل الذاكرة وقاعدة المعرفة RAG\n" +
                        "val promptTemplate = inferenceEngine.buildPromptTemplate(\n" +
                        "    systemPrompt = systemPrompt,\n" +
                        "    memoryContext = memoryContext,\n" +
                        "    ragContext = ragContext,\n" +
                        "    history = history,\n" +
                        "    userPrompt = prompt,\n" +
                        "    assistantName = \"Ameer AI\"\n" +
                        ")\n\n" +
                        "// 3. الاستدلال المحلي على أنوية المعالج المتعددة\n" +
                        "val response = inferenceEngine.infer(promptTemplate, activeDescriptor)\n" +
                        "```\n\n" +
                        "💡 **تحليل Pro Mode:** تم تحسين المعالجة للتنفيذ على ${descriptor.threadsCount} أنوية وبدقة ${descriptor.quantization.title}."
            } else {
                "إليك نموذج كود سريع من محرك **${descriptor.name}**:\n\n" +
                        "```kotlin\n" +
                        "val response = localAIService.generateCompletion(prompt, history, \"Ameer AI\")\n" +
                        "```\n\n" +
                        "⚡ تم التوليد السريع بأسلوب Fast Mode الخفيف."
            }
        }

        // 5. Greetings
        if (clean.contains("مرحبا") || clean.contains("سلام") || clean.contains("أهلا") || clean.contains("hello") || clean.contains("hi")) {
            val greetingIntro = if (isPro) {
                "وعليكم السلام ورحمة الله وبركاته! أهلاً بك وسهلاً في الوضع المتقدم (Pro Mode).\n" +
                        "أنا مساعدك الذكي العامل بمحرك **${descriptor.name}** للاستدلال والتحليل العميق."
            } else {
                "وعليكم السلام ورحمة الله وبركاته! أهلاً بك وسهلاً.\n" +
                        "أنا مساعدك الذكي العامل في الوضع السريع (Fast Mode) عبر **${descriptor.name}**."
            }
            return "$greetingIntro\n" +
                    "الذاكرة، المعرفة RAG، وجميع العمليات تعمل مباشرة على هاتفك بأمان تام. كيف أساعدك اليوم؟ ✨"
        }

        // 6. Default local synthesis
        return "بناءً على سؤالك حول \"$prompt\":\n\n" +
                "تتطلب الإجابة تحليل الجوانب العلمية والعملية المتعلقة بموضوعك. " +
                "يمكنك طرح أسئلة محددة عن العلوم، الفيزياء، البرمجة، أو كتابة القصص وسأجيبك بالتفصيل."
    }
}
