package com.example.aicore.localmodel

import java.io.File

/**
 * Native JNI Bridge for llama.cpp / GGUF model execution on Android.
 * Provides C++/JNI bindings to initialize llama contexts and run token inference.
 */
class LlamaCppBridge {

    private var isNativeLibraryLoaded = false
    private var nativeContextHandle: Long = 0L

    var loadError: String? = null
        private set

    var lastError: String? = null
        private set

    init {
        try {
            System.loadLibrary("llama_android")
            isNativeLibraryLoaded = true
        } catch (t: Throwable) {
            isNativeLibraryLoaded = false
            loadError = t.message ?: t.javaClass.simpleName
        }
    }

    fun isNativeSupported(): Boolean = isNativeLibraryLoaded

    fun initNativeModel(modelPath: String, contextSize: Int = 4096, threads: Int = 4): Boolean {
        if (!isNativeLibraryLoaded) {
            lastError = "المكتبة الأصلية libllama_android.so غير محملة: ${loadError ?: "غير متوفرة"}"
            return false
        }
        val file = File(modelPath)
        if (!file.exists()) {
            lastError = "ملف النموذج غير موجود في المسار المطلق: $modelPath"
            return false
        }

        return try {
            nativeContextHandle = nativeInitContext(modelPath, contextSize, threads)
            if (nativeContextHandle == 0L) {
                lastError = "فشل إنشاء سياق llama.cpp بالملف: $modelPath (مقبض السياق الأصلي = 0L)"
                false
            } else {
                lastError = null
                true
            }
        } catch (e: Exception) {
            lastError = "استثناء أثناء استدعاء nativeInitContext: ${e.message}"
            false
        }
    }

    fun generateNativeTokens(
        prompt: String,
        maxTokens: Int = 512,
        temperature: Float = 0.7f,
        topP: Float = 0.9f
    ): String? {
        if (!isNativeLibraryLoaded || nativeContextHandle == 0L) {
            lastError = "السياق الأصلي غير مهيأ أو مقبض الذاكرة مقفل"
            return null
        }
        return try {
            val rawOutput = nativeInfer(nativeContextHandle, prompt, maxTokens, temperature, topP)
            println("[GGUF_RAW_OUTPUT] Raw Native llama.cpp Output: \"$rawOutput\"")
            if (rawOutput.isNullOrBlank()) {
                lastError = "دالة nativeInfer أرجعت نصاً فارغاً (Empty Output)"
            }
            rawOutput
        } catch (e: Exception) {
            lastError = "استثناء أثناء التوليد الأصلي عبر C++: ${e.message}"
            println("[GGUF_RAW_OUTPUT] ERROR in generateNativeTokens: ${e.message}")
            null
        }
    }

    fun releaseNativeModel() {
        if (nativeContextHandle != 0L) {
            try {
                nativeFreeContext(nativeContextHandle)
            } catch (_: Exception) {}
            nativeContextHandle = 0L
        }
    }

    // JNI Native function declarations (llama.cpp C++ bindings)
    private external fun nativeInitContext(modelPath: String, contextSize: Int, threads: Int): Long
    private external fun nativeInfer(handle: Long, prompt: String, maxTokens: Int, temp: Float, topP: Float): String
    private external fun nativeFreeContext(handle: Long)
}
