package com.example.minesweeper.model

enum class ChordingTrigger(val titleAr: String, val description: String) {
    LONG_PRESS("الضغط المطول", "اضغط مطولاً على الرقم لكشف المربعات الآمنة المحيطة"),
    DOUBLE_TAP("النقر المزدوج", "انقر مرتين متتاليتين بسرعة على الرقم"),
    SINGLE_TAP("النقر المباشر", "انقر نقرة واحدة على الرقم المكتمل أعلامه")
}

data class SettingsState(
    val chordingTrigger: ChordingTrigger = ChordingTrigger.LONG_PRESS,
    val volumeKeyToggleEnabled: Boolean = true,
    val hapticFeedbackEnabled: Boolean = true,
    val soundEffectsEnabled: Boolean = true,
    val lockZoomByDefault: Boolean = false,
    val guessFreeOptionEnabled: Boolean = false,
    val selectedThemeId: String = "classic_retro",
    val questionMarksEnabled: Boolean = true,
    val noFlagMode: Boolean = false,
    val repetitiveChording: Boolean = false,
    val chordingOnReveal: Boolean = false,
    val flagChording: Boolean = false,
    val longPressDurationMs: Int = 350,
    val undoOnLossEnabled: Boolean = false,
    val unlimitedHints: Boolean = false,
    val showHud: Boolean = true,
    val showNavigationArrows: Boolean = true,
    val showHintButton: Boolean = true,
    val showWandButton: Boolean = true,
    val showTimerPanel: Boolean = true,
    val showStatusBar: Boolean = true,
    val show3bvDuringGame: Boolean = false,
    val classicTimer: Boolean = true,
    val soundFlag: Boolean = true,
    val soundReveal: Boolean = true,
    val soundWin: Boolean = true,
    val soundExplosion: Boolean = true,
    val inertiaScrolling: Boolean = true,
    val freeScrollingOutside: Boolean = true,
    val confirmNewGame: Boolean = false,
    val confirmLeaveGame: Boolean = false,
    val pauseTimerOnIdle: Boolean = true
)
