package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

data class TournamentItem(
    val id: String,
    val titleAr: String,
    val subtitleAr: String,
    val timeRemaining: String,
    val participants: Int,
    val prizePool: String,
    val difficultyAr: String,
    val topPlayers: List<Pair<String, String>>
)

@Composable
fun TournamentsScreen(
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    var selectedTournament by remember { mutableStateOf<TournamentItem?>(null) }
    var showJoinSuccessDialog by remember { mutableStateOf(false) }

    val tournaments = remember {
        listOf(
            TournamentItem(
                id = "t1",
                titleAr = "كأس المبتدئين الأسبوعي 🏆",
                subtitleAr = "تنافس على أسرع حل للوحة 9×9 وحقق أعلى 3BV/s",
                timeRemaining = "متبقي 3 أيام",
                participants = 1420,
                prizePool = "50 تلميح + 20 عصا سحرية",
                difficultyAr = "مبتدئ (9×9)",
                topPlayers = listOf(
                    "صقر الصحراء" to "00:08",
                    "نجم الألغام" to "00:11",
                    "كاسح الميدان" to "00:14",
                    "الفارس الأزرق" to "00:16"
                )
            ),
            TournamentItem(
                id = "t2",
                titleAr = "بطولة الخبراء الكبرى 👑",
                subtitleAr = "تحدي اللوحة العملاقة 16×30 مع 99 لغم لمحترفي المنطق",
                timeRemaining = "متبقي 5 أيام",
                participants = 860,
                prizePool = "وسام الأسطورة الذهبي + 100 تلميح",
                difficultyAr = "خبير (16×30)",
                topPlayers = listOf(
                    "البروفيسور" to "01:24",
                    "العاصفة الرقمية" to "01:42",
                    "صياد المحيط" to "01:58",
                    "الشبح الأسود" to "02:15"
                )
            ),
            TournamentItem(
                id = "t3",
                titleAr = "تحدي الـ 3BV الخاطف ⚡",
                subtitleAr = "جولات سريعة تقيس معدل النقرات الفعالة والدقة المطلقة",
                timeRemaining = "متبقي 18 ساعة",
                participants = 2100,
                prizePool = "شحنات طاقة لا نهائية + حزمة ثيمات",
                difficultyAr = "متوسط (16×16)",
                topPlayers = listOf(
                    "الرعد الخاطف" to "3.42 3BV/s",
                    "الموج الأزرق" to "3.10 3BV/s",
                    "الصقر العربي" to "2.85 3BV/s",
                    "محارب الألغاز" to "2.60 3BV/s"
                )
            )
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RetroLightGray)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("tournaments_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = NavyPrimary
                    )
                }

                Column {
                    Text(
                        text = "البطولات والمنافسات 🏆",
                        color = NavyPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "بطولات رسمية وجوائز فورية للمحترفين",
                        color = NavyPrimary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }

            // Tournaments List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tournaments) { item ->
                    TournamentCard(
                        tournament = item,
                        onJoinClick = {
                            selectedTournament = item
                            showJoinSuccessDialog = true
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }

        if (showJoinSuccessDialog && selectedTournament != null) {
            Dialog(onDismissRequest = { showJoinSuccessDialog = false }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .drawBehind {
                            val stroke = 2.dp.toPx()
                            drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                            drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                            drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                            drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                        }
                        .background(RetroPanelGray, RoundedCornerShape(4.dp))
                        .padding(20.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = "🏆", fontSize = 40.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "تم التسجيل في البطولة بنجاح!",
                            color = NavyPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = selectedTournament?.titleAr ?: "",
                            color = NavyPrimary.copy(alpha = 0.8f),
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        RetroButton(
                            onClick = { showJoinSuccessDialog = false },
                            containerColor = NavyPrimary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                        ) {
                            Text("حسناً", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TournamentCard(
    tournament: TournamentItem,
    onJoinClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .drawBehind {
                val stroke = 2.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(RetroPanelGray, RoundedCornerShape(4.dp))
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tournament.titleAr,
                    color = NavyPrimary,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
                Box(
                    modifier = Modifier
                        .drawBehind {
                            val stroke = 1.dp.toPx()
                            drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                            drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                            drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                            drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                        }
                        .background(RetroLightGray, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = tournament.difficultyAr,
                        color = NavyPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = tournament.subtitleAr,
                color = NavyPrimary.copy(alpha = 0.8f),
                fontSize = 13.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(imageVector = Icons.Default.Timer, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(16.dp))
                    Text(text = tournament.timeRemaining, color = NavyPrimary.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(imageVector = Icons.Default.People, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(16.dp))
                    Text(text = "${tournament.participants} مشارك", color = NavyPrimary.copy(alpha = 0.7f), fontSize = 12.sp)
                }
            }

            // Leaderboard preview box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        val stroke = 1.dp.toPx()
                        drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                        drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                        drawLine(RetroWhiteHighlight, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                        drawLine(RetroWhiteHighlight, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                    }
                    .background(RetroLightGray, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "لوحة الشرف الحالية:",
                        color = NavyPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    tournament.topPlayers.forEachIndexed { idx, player ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${idx + 1}. ${player.first}",
                                color = NavyPrimary,
                                fontSize = 12.sp
                            )
                            Text(
                                text = player.second,
                                color = NavyPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            RetroButton(
                onClick = onJoinClick,
                containerColor = NavyPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(42.dp)
                    .testTag("join_tournament_${tournament.id}")
            ) {
                Text(
                    text = "انضم للبطولة الآن 🎮",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}
