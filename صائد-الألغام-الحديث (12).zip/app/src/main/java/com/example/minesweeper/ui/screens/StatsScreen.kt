package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.DifficultyStats
import com.example.minesweeper.model.MatchRecord
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatsScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("مبتدئ", "متوسط", "خبير", "مخصص", "سجل المباريات")

    val currentStats: DifficultyStats = when (selectedTabIndex) {
        0 -> uiState.statsBeginner
        1 -> uiState.statsIntermediate
        2 -> uiState.statsExpert
        else -> uiState.statsCustom
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RetroLightGray)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("stats_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = NavyPrimary
                    )
                }

                Column {
                    Text(
                        text = "سجل الإحصائيات والأرقام 📊",
                        color = NavyPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "قياسات 3BV والسرعة ومعدل الفوز لكل صعوبة",
                        color = NavyPrimary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }

            // Tabs with Retro Colors
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = RetroPanelGray,
                contentColor = NavyPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = NavyPrimary
                    )
                },
                edgePadding = 16.dp
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) NavyPrimary else NavyPrimary.copy(alpha = 0.6f)
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (selectedTabIndex in 0..3) {
                // Difficulty stats breakdown
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        // Win Rate Card
                        RetroBeveledCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(RetroPanelGray)
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatHighlightItem(title = "مرات اللعب", value = currentStats.gamesPlayed.toString())
                                StatHighlightItem(title = "مرات الفوز", value = currentStats.gamesWon.toString())
                                StatHighlightItem(
                                    title = "نسبة الفوز",
                                    value = "${currentStats.winRatePct}%",
                                    textColor = Color(0xFF2E7D32)
                                )
                            }
                        }
                    }

                    item {
                        // Speed & 3BV Card
                        RetroBeveledCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(RetroPanelGray)
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "مقاييس السرعة والكفاءة ⏱️",
                                    color = NavyPrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                StatDetailRow("أفضل وقت مسجل:", if (currentStats.bestTimeSeconds > 0) "${currentStats.bestTimeSeconds} ثانية" else "--")
                                StatDetailRow("متوسط وقت الفوز:", if (currentStats.averageTimeSeconds > 0) "${currentStats.averageTimeSeconds} ثانية" else "--")
                                StatDetailRow("أعلى مؤشر 3BV:", if (currentStats.best3BV > 0) currentStats.best3BV.toString() else "--")
                                StatDetailRow("أعلى سرعة 3BV/ثانية:", if (currentStats.best3BVs > 0) String.format("%.2f", currentStats.best3BVs) else "--")
                                StatDetailRow("أفضل كفاءة نقرات:", if (currentStats.bestEfficiencyPct > 0) "${currentStats.bestEfficiencyPct.toInt()}%" else "--")
                            }
                        }
                    }

                    item {
                        // Explanation of 3BV
                        RetroBeveledCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(RetroPanelGray)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = "ما هو مؤشر 3BV؟",
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "هو المقياس العالمي المعتمد لأقل عدد نقرات ممكن لإكمال اللوحة. يقيس سرعة ومهارة اللاعب بمعيار (3BV في الثانية) بشكل عادل ومستقل عن التوزيع.",
                                    color = NavyPrimary.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            } else {
                // Match History List
                if (uiState.matchHistory.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لا توجد مباريات مسجلة بعد.\nابدأ جولة جديدة لتسجيل إحصائياتك!",
                            color = NavyPrimary.copy(alpha = 0.6f),
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(uiState.matchHistory) { match ->
                            MatchHistoryCard(match = match)
                        }
                        item {
                            Spacer(modifier = Modifier.height(20.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatHighlightItem(
    title: String,
    value: String,
    textColor: Color = NavyPrimary
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = title, color = NavyPrimary.copy(alpha = 0.7f), fontSize = 12.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, color = textColor, fontSize = 20.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun StatDetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = NavyPrimary.copy(alpha = 0.7f), fontSize = 13.sp)
        Text(text = value, color = NavyPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun MatchHistoryCard(match: MatchRecord) {
    val dateFormat = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .drawBehind {
                val stroke = 2.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(RetroPanelGray)
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = if (match.won) "فوز ✔" else "خسارة ✖",
                        color = if (match.won) Color(0xFF2E7D32) else Color(0xFFC0392B),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = match.difficulty.titleAr,
                        color = NavyPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
                Text(
                    text = dateFormat.format(Date(match.timestamp)),
                    color = NavyPrimary.copy(alpha = 0.5f),
                    fontSize = 11.sp
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${match.timeSeconds} ثانية",
                    color = NavyPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "3BV: ${match.threeBV} (${String.format("%.1f", match.threeBVs)}/s)",
                    color = NavyPrimary.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            }
        }
    }
}
