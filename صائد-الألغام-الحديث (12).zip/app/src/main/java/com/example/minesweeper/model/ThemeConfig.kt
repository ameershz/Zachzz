package com.example.minesweeper.model

import androidx.compose.ui.graphics.Color

data class MinesweeperTheme(
    val name: String,
    val cellFace: Color,
    val cellLight: Color,
    val cellDark: Color,
    val pressedFace: Color,
    val pressedEdge: Color,
    val floor: Color,
    val mineColor: Color,
    val flagColor: Color,
    val flagStand: Color,
    val id: String = "",
    val index: Int = 0
) {
    val nameAr: String get() = name
    val boardBackground: Color get() = floor
    val cellUnrevealed: Color get() = cellFace
    val cellRevealed: Color get() = floor
    val cellBorderLight: Color get() = cellLight
    val cellBorderDark: Color get() = cellDark
    val accentColor: Color get() = flagColor
    val isRetroBeveled: Boolean get() = true
    val numberColors: List<Color> get() = AvailableThemes.standardDigitColors
}

object AvailableThemes {

    // Fixed standard digit colors across all themes (1 to 8)
    val standardDigitColors = listOf(
        Color(0xFF0000FF), // 1 Blue
        Color(0xFF008000), // 2 Green
        Color(0xFFF40000), // 3 Red
        Color(0xFF000080), // 4 Navy
        Color(0xFF800000), // 5 Maroon
        Color(0xFF008080), // 6 Teal
        Color(0xFF000000), // 7 Black
        Color(0xFF808080)  // 8 Gray
    )

    // 0: Classic Gray (Default)
    val ClassicGray = MinesweeperTheme(
        name = "رمادي كلاسيكي",
        cellFace = Color(0xFFBDBDBD),
        cellLight = Color(0xFFFFFFFF),
        cellDark = Color(0xFF7B7B7B),
        pressedFace = Color(0xFFDEDEDE),
        pressedEdge = Color(0xFF7B7B7B),
        floor = Color(0xFFBDBDBD),
        mineColor = Color(0xFF000000),
        flagColor = Color(0xFFFF0000),
        flagStand = Color(0xFF000000),
        id = "theme_0",
        index = 0
    )

    // 1: Charcoal
    val Charcoal = MinesweeperTheme(
        name = "فحمي",
        cellFace = Color(0xFF5F5F5F),
        cellLight = Color(0xFF808080),
        cellDark = Color(0xFF3E3E3E),
        pressedFace = Color(0xFF6E6E6E),
        pressedEdge = Color(0xFF303030),
        floor = Color(0xFF4A4A4A),
        mineColor = Color(0xFFC8C8C8),
        flagColor = Color(0xFFCA3B3B),
        flagStand = Color(0xFFC8C8C8),
        id = "theme_1",
        index = 1
    )

    // 2: Copper
    val Copper = MinesweeperTheme(
        name = "نحاسي",
        cellFace = Color(0xFFB07858),
        cellLight = Color(0xFFCAA58F),
        cellDark = Color(0xFF8B5D42),
        pressedFace = Color(0xFFBD8F75),
        pressedEdge = Color(0xFF82573E),
        floor = Color(0xFFAD7352),
        mineColor = Color(0xFFF6F6F6),
        flagColor = Color(0xFFECECEC),
        flagStand = Color(0xFF444444),
        id = "theme_2",
        index = 2
    )

    // 3: Dark Pink
    val DarkPink = MinesweeperTheme(
        name = "وردي غامق",
        cellFace = Color(0xFFA83F68),
        cellLight = Color(0xFFC7698D),
        cellDark = Color(0xFF7F2F4E),
        pressedFace = Color(0xFFB16281),
        pressedEdge = Color(0xFF782D4A),
        floor = Color(0xFF9E3B61),
        mineColor = Color(0xFFF6F6F6),
        flagColor = Color(0xFFEDEDED),
        flagStand = Color(0xFF434343),
        id = "theme_3",
        index = 3
    )

    // 4: Mint
    val Mint = MinesweeperTheme(
        name = "نعناعي",
        cellFace = Color(0xFF41AE85),
        cellLight = Color(0xFF72CBA9),
        cellDark = Color(0xFF318364),
        pressedFace = Color(0xFF61B092),
        pressedEdge = Color(0xFF2C765A),
        floor = Color(0xFF3A9C77),
        mineColor = Color(0xFFF8AFFF),
        flagColor = Color(0xFFFF8181),
        flagStand = Color(0xFFF3F3F3),
        id = "theme_4",
        index = 4
    )

    // 5: Gold
    val Gold = MinesweeperTheme(
        name = "ذهبي",
        cellFace = Color(0xFFDD960E),
        cellLight = Color(0xFFF5B741),
        cellDark = Color(0xFFA6710A),
        pressedFace = Color(0xFFF4E59F),
        pressedEdge = Color(0xFFA6710A),
        floor = Color(0xFFEFD355),
        mineColor = Color(0xFF474747),
        flagColor = Color(0xFFF73C3C),
        flagStand = Color(0xFFECECEC),
        id = "theme_5",
        index = 5
    )

    // 6: Royal Blue
    val RoyalBlue = MinesweeperTheme(
        name = "أزرق ملكي",
        cellFace = Color(0xFF577BDB),
        cellLight = Color(0xFF819CE2),
        cellDark = Color(0xFF364D8B),
        pressedFace = Color(0xFFDBE0EE),
        pressedEdge = Color(0xFF405798),
        floor = Color(0xFFBBC5E0),
        mineColor = Color(0xFF3A3A3A),
        flagColor = Color(0xFFFA0000),
        flagStand = Color(0xFFFFFFFF),
        id = "theme_6",
        index = 6
    )

    // 7: Misty
    val Misty = MinesweeperTheme(
        name = "ضبابي",
        cellFace = Color(0xFFADC7C8),
        cellLight = Color(0xFFFFFFFF),
        cellDark = Color(0xFF64918F),
        pressedFace = Color(0xFFD1DFE0),
        pressedEdge = Color(0xFF65908F),
        floor = Color(0xFFADC7C8),
        mineColor = Color(0xFF5C1A4A),
        flagColor = Color(0xFFFD46C9),
        flagStand = Color(0xFF5C1A4A),
        id = "theme_7",
        index = 7
    )

    // 8: Calm Green
    val CalmGreen = MinesweeperTheme(
        name = "أخضر هادئ",
        cellFace = Color(0xFF97AE7F),
        cellLight = Color(0xFFCEE5B6),
        cellDark = Color(0xFF607648),
        pressedFace = Color(0xFFAFC29B),
        pressedEdge = Color(0xFF607648),
        floor = Color(0xFF97AE7F),
        mineColor = Color(0xFF293F11),
        flagColor = Color(0xFF475F2D),
        flagStand = Color(0xFFCEE5B6),
        id = "theme_8",
        index = 8
    )

    // 9: Night
    val Night = MinesweeperTheme(
        name = "ليلي",
        cellFace = Color(0xFF4D4D4D),
        cellLight = Color(0xFF6A6A6A),
        cellDark = Color(0xFF313131),
        pressedFace = Color(0xFF656565),
        pressedEdge = Color(0xFF313131),
        floor = Color(0xFF4D4D4D),
        mineColor = Color(0xFFFF8A00),
        flagColor = Color(0xFFFF8A00),
        flagStand = Color(0xFFDF2AEB),
        id = "theme_9",
        index = 9
    )

    // 10: Glacial
    val Glacial = MinesweeperTheme(
        name = "جليدي",
        cellFace = Color(0xFF00AEFF),
        cellLight = Color(0xFF76D3FF),
        cellDark = Color(0xFF006FA2),
        pressedFace = Color(0xFF95DDFF),
        pressedEdge = Color(0xFF006FA3),
        floor = Color(0xFF59CAFF),
        mineColor = Color(0xFFFFFFFF),
        flagColor = Color(0xFFFFD200),
        flagStand = Color(0xFFFFFFFF),
        id = "theme_10",
        index = 10
    )

    // 11: Purple
    val Purple = MinesweeperTheme(
        name = "بنفسجي",
        cellFace = Color(0xFFB242CA),
        cellLight = Color(0xFFB772C6),
        cellDark = Color(0xFF7F2D91),
        pressedFace = Color(0xFFA058B0),
        pressedEdge = Color(0xFF6E277D),
        floor = Color(0xFF9D38B3),
        mineColor = Color(0xFFF6F6F6),
        flagColor = Color(0xFFFFFFFF),
        flagStand = Color(0xFFF2B7FF),
        id = "theme_11",
        index = 11
    )

    val allThemes: List<MinesweeperTheme> = listOf(
        ClassicGray, Charcoal, Copper, DarkPink, Mint, Gold,
        RoyalBlue, Misty, CalmGreen, Night, Glacial, Purple
    )

    val ClassicRetro: MinesweeperTheme = ClassicGray

    fun getThemeById(id: String): MinesweeperTheme {
        return allThemes.find { it.id == id || it.name == id }
            ?: (if (id == "classic_retro") ClassicGray else null)
            ?: ClassicGray
    }
}
