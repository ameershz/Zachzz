package com.example.minesweeper.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.minesweeper.model.GameStatus

@Composable
fun RetroFaceButton(
    status: GameStatus,
    isInteractingWithBoard: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(48.dp)
            .testTag("reset_face_button")
            .drawBehind {
                val stroke = 3.dp.toPx()
                drawLine(Color.White, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(Color.White, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(Color(0xFF707070), Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(Color(0xFF707070), Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(Color(0xFFC6C6C6), shape = RoundedCornerShape(2.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(36.dp)) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = size.width * 0.45f

            drawCircle(color = Color(0xFFFFEE00), radius = r, center = Offset(cx, cy))
            drawCircle(color = Color(0xFFC7B800), radius = r, center = Offset(cx, cy), style = Stroke(width = 2f))

            val eyeR = r * 0.12f
            val leftEyeX = cx - r * 0.35f
            val rightEyeX = cx + r * 0.35f
            val eyeY = cy - r * 0.25f

            when {
                status == GameStatus.WON -> {
                    drawCircle(Color.Black, radius = eyeR * 1.3f, center = Offset(leftEyeX, eyeY))
                    drawCircle(Color.Black, radius = eyeR * 1.3f, center = Offset(rightEyeX, eyeY))
                    drawLine(Color.Black, Offset(leftEyeX - eyeR * 1.5f, eyeY), Offset(rightEyeX + eyeR * 1.5f, eyeY), strokeWidth = 3f)
                    drawArc(
                        color = Color.Black,
                        startAngle = 0f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = Offset(cx - r * 0.4f, cy - r * 0.1f),
                        size = Size(r * 0.8f, r * 0.6f),
                        style = Stroke(width = 2.5f)
                    )
                }
                status == GameStatus.LOST -> {
                    drawLine(Color.Black, Offset(leftEyeX - eyeR, eyeY - eyeR), Offset(leftEyeX + eyeR, eyeY + eyeR), strokeWidth = 2.5f)
                    drawLine(Color.Black, Offset(leftEyeX - eyeR, eyeY + eyeR), Offset(leftEyeX + eyeR, eyeY - eyeR), strokeWidth = 2.5f)
                    drawLine(Color.Black, Offset(rightEyeX - eyeR, eyeY - eyeR), Offset(rightEyeX + eyeR, eyeY + eyeR), strokeWidth = 2.5f)
                    drawLine(Color.Black, Offset(rightEyeX - eyeR, eyeY + eyeR), Offset(rightEyeX + eyeR, eyeY - eyeR), strokeWidth = 2.5f)
                    drawArc(
                        color = Color.Black,
                        startAngle = 180f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = Offset(cx - r * 0.4f, cy + r * 0.1f),
                        size = Size(r * 0.8f, r * 0.5f),
                        style = Stroke(width = 2.5f)
                    )
                }
                isInteractingWithBoard -> {
                    drawCircle(Color.Black, radius = eyeR, center = Offset(leftEyeX, eyeY))
                    drawCircle(Color.Black, radius = eyeR, center = Offset(rightEyeX, eyeY))
                    drawCircle(Color.Black, radius = eyeR * 1.2f, center = Offset(cx, cy + r * 0.2f), style = Stroke(width = 2.5f))
                }
                else -> {
                    drawCircle(Color.Black, radius = eyeR, center = Offset(leftEyeX, eyeY))
                    drawCircle(Color.Black, radius = eyeR, center = Offset(rightEyeX, eyeY))
                    drawArc(
                        color = Color.Black,
                        startAngle = 0f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = Offset(cx - r * 0.4f, cy - r * 0.1f),
                        size = Size(r * 0.8f, r * 0.6f),
                        style = Stroke(width = 2.5f)
                    )
                }
            }
        }
    }
}
