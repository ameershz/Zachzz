package com.example.minesweeper.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.ui.components.DigitalLedDisplay

@Composable
fun TutorialDialog(
    onDismiss: () -> Unit
) {
    var step by remember { mutableIntStateOf(1) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val stroke = 2.dp.toPx()
                    drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                    drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                    drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                }
                .background(RetroPanelGray, RoundedCornerShape(4.dp))
                .padding(8.dp)
                .testTag("tutorial_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header: Step Indicator & Skip button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "جولة تعليمية ($step من 4)",
                        color = NavyPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("tutorial_skip_button")
                    ) {
                        Text("تخطي ✕", color = NavyPrimary.copy(alpha = 0.7f), fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (step) {
                    1 -> TutorialStepOne()
                    2 -> TutorialStepTwo()
                    3 -> TutorialStepThreePractice()
                    4 -> TutorialStepFourBoosts()
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Navigation buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (step > 1) {
                        RetroButton(
                            onClick = { step-- },
                            containerColor = RetroLightGray,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("السابق", color = NavyPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    RetroButton(
                        onClick = {
                            if (step < 4) {
                                step++
                            } else {
                                onDismiss()
                            }
                        },
                        containerColor = NavyPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tutorial_next_button")
                    ) {
                        Text(
                            text = if (step < 4) "التالي ⬅" else "ابدأ اللعب الآن 🚀",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TutorialStepOne() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "شريط اللعبة العلوي ⏱️",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )
        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val stroke = 1.dp.toPx()
                    drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                    drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                }
                .background(RetroLightGray, RoundedCornerShape(4.dp))
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("الألغام المتبقية", color = NavyPrimary.copy(alpha = 0.7f), fontSize = 11.sp)
                    DigitalLedDisplay(value = 10)
                }
                Text("🙂", fontSize = 28.sp)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("المؤقت", color = NavyPrimary.copy(alpha = 0.7f), fontSize = 11.sp)
                    DigitalLedDisplay(value = 42)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "يتابع العداد عدد الألغام غير المعلَّمة ويحسب الوقت المنقضي بدقة لدخول لوحة الشرف.",
            color = NavyPrimary.copy(alpha = 0.8f),
            fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}

@Composable
private fun TutorialStepTwo() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "طريقة الكشف ووضع الأعلام 🚩",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )
        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val stroke = 1.dp.toPx()
                    drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                    drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                }
                .background(RetroLightGray, RoundedCornerShape(4.dp))
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "👉 انقر نقرة قصيرة لكشف الخلية.", color = NavyPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "⏱️ اضغط مطولاً لزرع علم.", color = NavyPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "⚡ استخدم الكورد السريع عند الأرقام المكتملة.", color = NavyPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = "الخلايا المكشوفة تعرض عدد الألغام المجاورة. استنتج مواقع الألغام بحذر!",
            color = NavyPrimary.copy(alpha = 0.8f),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun TutorialStepThreePractice() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "وضع بلا تخمين 🧠",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )
        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val stroke = 1.dp.toPx()
                    drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                    drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                }
                .background(RetroLightGray, RoundedCornerShape(4.dp))
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "يضمن هذا الوضع أن كل لوحة قابلة للحل منطقياً 100% دون الحاجة لأي تخمين عشوائي.",
                color = NavyPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(8.dp)
            )
        }
    }
}

@Composable
private fun TutorialStepFourBoosts() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "المساعدات والأدوات 💡🪄",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )
        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val stroke = 1.dp.toPx()
                    drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                    drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                }
                .background(RetroLightGray, RoundedCornerShape(4.dp))
                .padding(12.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(text = "💡 تلميح ذكي: يكشف لك خلية آمنة مقترحة.", color = NavyPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "🪄 العصا السحرية: تكشف خلية بدون أخطاء.", color = NavyPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
