package com.example.minesweeper.model

enum class BoardDifficulty(
    val titleAr: String,
    val rows: Int,
    val cols: Int,
    val defaultMines: Int,
    val description: String
) {
    BEGINNER("مبتدئ", 9, 9, 10, "حقل 9×9 - 10 ألغام"),
    INTERMEDIATE("متوسط", 16, 16, 40, "حقل 16×16 - 40 لغماً"),
    EXPERT("خبير", 30, 16, 99, "حقل 16×30 - 99 لغماً"),
    CUSTOM("مخصص", 10, 10, 15, "حقل مخصص حسب رغبتك");

    fun getDimensions(): Pair<Int, Int> {
        return rows to cols
    }

    fun getMinesCount(customMines: Int = defaultMines): Int {
        return if (this == CUSTOM) customMines else defaultMines
    }
}
