package com.example.minesweeper.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.GameStatus
import com.example.minesweeper.model.MinesweeperTheme

val RetroLightGray = Color(0xFFC0C0C0)
val RetroPanelGray = Color(0xFFD6D6D6)
val RetroWhiteHighlight = Color(0xFFFFFFFF)
val RetroDarkShadow = Color(0xFF707070)
val NavyPrimary = Color(0xFF1C2A39)

@Composable
fun TopGameHUD(
    remainingMines: Int,
    timerSeconds: Int,
    gameStatus: GameStatus,
    isInteracting: Boolean,
    theme: MinesweeperTheme,
    onResetClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = if (theme.isRetroBeveled) RetroLightGray else theme.boardBackground,
        tonalElevation = 4.dp
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (theme.isRetroBeveled) Color(0xFFB0B0B0) else Color(0x22FFFFFF),
                        shape = RoundedCornerShape(6.dp)
                    )
                    .border(
                        2.dp,
                        if (theme.isRetroBeveled) RetroDarkShadow else Color.Transparent,
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "الألغام",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (theme.isRetroBeveled) Color.DarkGray else Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    DigitalLedDisplay(value = remainingMines)
                }

                RetroFaceButton(
                    status = gameStatus,
                    isInteractingWithBoard = isInteracting,
                    onClick = onResetClick
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "الوقت",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (theme.isRetroBeveled) Color.DarkGray else Color.LightGray
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    DigitalLedDisplay(value = timerSeconds)
                }
            }
        }
    }
}

@Composable
fun BottomControlsHUD(
    isFlagMode: Boolean,
    onToggleFlagMode: () -> Unit,
    hintsCount: Int,
    wandsCount: Int,
    onHintClick: () -> Unit,
    onWandClick: () -> Unit,
    onBackClick: () -> Unit,
    onSettingsClick: () -> Unit,
    gameStatus: GameStatus = GameStatus.IN_PROGRESS,
    onInfoClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isGameOver = gameStatus == GameStatus.WON || gameStatus == GameStatus.LOST

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = RetroLightGray,
        tonalElevation = 8.dp
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        val stroke = 2.dp.toPx()
                        drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Back Arrow (Far Left)
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(44.dp)
                        .drawBeveledBox()
                        .testTag("hud_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = NavyPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // 2. Info Button if game over, else Magic Wand
                if (isGameOver) {
                    IconButton(
                        onClick = onInfoClick,
                        modifier = Modifier
                            .size(44.dp)
                            .drawBeveledBox()
                            .testTag("hud_info_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "النتائج",
                            tint = NavyPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                } else {
                    ToolButtonWithCounter(
                        icon = "🪄",
                        count = wandsCount,
                        onClick = onWandClick,
                        tag = "boost_wand"
                    )
                }

                // 3. Center Mode Toggle Button (Square Beveled Box with Canvas Shovel / Flag)
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .drawBeveledBox(isPressed = isFlagMode)
                        .clickable(onClick = onToggleFlagMode)
                        .testTag("mode_toggle_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(28.dp)) {
                        if (isFlagMode) {
                            drawCanvasFlag()
                        } else {
                            drawCanvasShovel()
                        }
                    }
                }

                // 4. Hint Button with Counter
                ToolButtonWithCounter(
                    icon = "💡",
                    count = hintsCount,
                    onClick = onHintClick,
                    tag = "boost_hint"
                )

                // 5. Settings Gear (Far Right)
                IconButton(
                    onClick = onSettingsClick,
                    modifier = Modifier
                        .size(44.dp)
                        .drawBeveledBox()
                        .testTag("hud_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "الإعدادات",
                        tint = NavyPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawCanvasShovel() {
    val w = size.width
    val h = size.height
    // Handle
    drawLine(
        color = Color(0xFF8B4513),
        start = Offset(w * 0.2f, h * 0.8f),
        end = Offset(w * 0.8f, h * 0.2f),
        strokeWidth = 3f
    )
    // Blade
    val bladePath = Path().apply {
        moveTo(w * 0.65f, h * 0.35f)
        lineTo(w * 0.9f, h * 0.1f)
        lineTo(w * 0.95f, h * 0.35f)
        lineTo(w * 0.7f, h * 0.6f)
        close()
    }
    drawPath(bladePath, color = Color(0xFF708090))
}

private fun DrawScope.drawCanvasFlag() {
    val w = size.width
    val h = size.height
    // Pole
    drawLine(
        color = Color(0xFF333333),
        start = Offset(w * 0.3f, h * 0.1f),
        end = Offset(w * 0.3f, h * 0.9f),
        strokeWidth = 3f
    )
    // Flag banner
    val flagPath = Path().apply {
        moveTo(w * 0.3f, h * 0.15f)
        lineTo(w * 0.85f, h * 0.35f)
        lineTo(w * 0.3f, h * 0.55f)
        close()
    }
    drawPath(flagPath, color = Color(0xFFE53935))
}

@Composable
private fun ToolButtonWithCounter(
    icon: String,
    count: Int,
    onClick: () -> Unit,
    tag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(tag)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .drawBeveledBox(),
            contentAlignment = Alignment.Center
        ) {
            Text(text = icon, fontSize = 20.sp)
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = "$count",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )
    }
}

@Composable
fun Modifier.drawBeveledBox(isPressed: Boolean = false): Modifier {
    val light = if (isPressed) RetroDarkShadow else RetroWhiteHighlight
    val shadow = if (isPressed) RetroWhiteHighlight else RetroDarkShadow
    return this
        .background(RetroPanelGray)
        .drawBehind {
            val stroke = 2.dp.toPx()
            drawLine(light, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
            drawLine(light, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
            drawLine(shadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
            drawLine(shadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
        }
}
