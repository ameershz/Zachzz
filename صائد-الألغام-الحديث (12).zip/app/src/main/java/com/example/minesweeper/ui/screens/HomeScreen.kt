package com.example.minesweeper.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.model.BoardDifficulty
import com.example.minesweeper.model.GameMode
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

val NavyPrimary = Color(0xFF1C2A39)
val RetroLightGray = Color(0xFFC0C0C0)
val RetroPanelGray = Color(0xFFD6D6D6)
val RetroWhiteHighlight = Color(0xFFFFFFFF)
val RetroDarkShadow = Color(0xFF707070)

@Composable
fun HomeScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    var showDifficultyDialog by remember { mutableStateOf(false) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = RetroLightGray,
                drawerContentColor = NavyPrimary,
                modifier = Modifier.width(300.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(RetroLightGray)
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Drawer Header
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                            .drawBehind {
                                val stroke = 3.dp.toPx()
                                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                            }
                            .background(RetroPanelGray)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("💣 صائد الألغام 🚩", fontSize = 18.sp, fontWeight = FontWeight.Black, color = NavyPrimary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("ريترو احترافي", fontSize = 11.sp, color = NavyPrimary.copy(alpha = 0.7f))
                        }
                    }

                    DrawerMenuItem(
                        icon = Icons.Default.Home,
                        title = "الرئيسية",
                        onClick = { scope.launch { drawerState.close() } }
                    )

                    if (uiState.hasSavedGame) {
                        DrawerMenuItem(
                            icon = Icons.Default.PlayArrow,
                            title = "استئناف اللعبة الجارية",
                            badge = "جارية",
                            onClick = {
                                scope.launch { drawerState.close() }
                                viewModel.resumeSavedGame()
                            }
                        )
                    }

                    DrawerMenuItem(
                        icon = Icons.Default.PlayArrow,
                        title = "لعبة جديدة (GO)",
                        onClick = {
                            scope.launch { drawerState.close() }
                            showDifficultyDialog = true
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.Map,
                        title = "الحملة (المراحل)",
                        badge = "مستوى ${uiState.campaignProgress.unlockedLevel}",
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(ScreenState.CAMPAIGN)
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.EmojiEvents,
                        title = "البطولات اليومية",
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(ScreenState.TOURNAMENTS)
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.Palette,
                        title = "الثيمات (12 ثيم)",
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(ScreenState.THEMES)
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.BarChart,
                        title = "الإحصائيات والأرقام",
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(ScreenState.STATS)
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.Settings,
                        title = "الإعدادات العامة",
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.navigateTo(ScreenState.SETTINGS)
                        }
                    )

                    DrawerMenuItem(
                        icon = Icons.Default.Info,
                        title = "دليل اللعب والتعليمات",
                        onClick = {
                            scope.launch { drawerState.close() }
                            viewModel.showTutorialAgain()
                        }
                    )

                    Spacer(modifier = Modifier.weight(1f))

                    Text(
                        text = "100% كلاسيكي ريترو • تحكّم دقيق",
                        color = NavyPrimary.copy(alpha = 0.5f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp)
                    )
                }
            }
        }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(RetroLightGray)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // (أ) Logo & Title with Red Flag motif + Resume Card
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .drawBehind {
                                    val stroke = 3.dp.toPx()
                                    drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                                    drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                                    drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                                    drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                                }
                                .background(RetroPanelGray),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("💣🚩", fontSize = 22.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "صائد الألغام",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black,
                                color = NavyPrimary,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "ريترو احترافي",
                                fontSize = 11.sp,
                                color = NavyPrimary.copy(alpha = 0.7f),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Resume Ongoing Game Card (if one exists)
                    AnimatedVisibility(visible = uiState.hasSavedGame) {
                        RetroBeveledCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.resumeSavedGame() }
                                .testTag("resume_game_card")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF2E7D32).copy(alpha = 0.10f))
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(32.dp)
                                            .background(Color(0xFF2E7D32), RoundedCornerShape(6.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "استئناف",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Column {
                                        Text(
                                            text = "استئناف اللعبة الجارية ⏳",
                                            color = NavyPrimary,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                        uiState.savedGameSummary?.let {
                                            Text(
                                                text = it,
                                                color = Color(0xFF2E7D32),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                RetroButton(
                                    onClick = { viewModel.resumeSavedGame() },
                                    containerColor = Color(0xFF2E7D32),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("متابعة", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // (ب) بطاقة المكافآت اليومية
                DailyRewardsCard(uiState = uiState, viewModel = viewModel)

                // (ج) بطاقة GO (بسطر الصعوبة)
                val diffSummary = when (uiState.difficulty) {
                    BoardDifficulty.BEGINNER -> "مبتدئ — حقل 9×9 - 10 ألغام"
                    BoardDifficulty.INTERMEDIATE -> "متوسط — حقل 16×16 - 40 لغماً"
                    BoardDifficulty.EXPERT -> "خبير — حقل 16×30 - 99 لغماً"
                    BoardDifficulty.CUSTOM -> "مخصص — حقل ${uiState.customRows}×${uiState.customCols} - ${uiState.customMines} لغماً"
                }

                RetroBeveledCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.startNewGame(
                                difficulty = uiState.difficulty,
                                mode = uiState.gameMode,
                                customRows = uiState.customRows,
                                customCols = uiState.customCols,
                                customMines = uiState.customMines,
                                guessFree = uiState.isGuessFree
                            )
                        }
                        .testTag("go_play_card")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RetroPanelGray)
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "الصعوبة المختارة:",
                                    color = NavyPrimary.copy(alpha = 0.7f),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = diffSummary,
                                    color = NavyPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            RetroButton(
                                onClick = { showDifficultyDialog = true },
                                containerColor = RetroLightGray,
                                modifier = Modifier
                                    .height(30.dp)
                                    .testTag("change_difficulty_button")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Settings,
                                        contentDescription = "تغيير الصعوبة",
                                        tint = NavyPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "تعديل",
                                        color = NavyPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Big GO Play Button
                        RetroButton(
                            onClick = {
                                viewModel.startNewGame(
                                    difficulty = uiState.difficulty,
                                    mode = uiState.gameMode,
                                    customRows = uiState.customRows,
                                    customCols = uiState.customCols,
                                    customMines = uiState.customMines,
                                    guessFree = uiState.isGuessFree
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("play_menu_button"),
                            containerColor = NavyPrimary
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = "ابدأ",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "GO — ابدأ اللعب فوراً",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }

                // (د) مربعا الحملة والبطولات جنباً + صف الثيمات والإحصائيات
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RetroSubMenuButton(
                            title = "الحملة (المراحل)",
                            icon = Icons.Default.Map,
                            modifier = Modifier.weight(1f),
                            tag = "campaign_menu_button",
                            onClick = { viewModel.navigateTo(ScreenState.CAMPAIGN) }
                        )
                        RetroSubMenuButton(
                            title = "البطولات",
                            icon = Icons.Default.EmojiEvents,
                            modifier = Modifier.weight(1f),
                            tag = "tournaments_menu_button",
                            onClick = { viewModel.navigateTo(ScreenState.TOURNAMENTS) }
                        )
                    }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RetroSubMenuButton(
                            title = "الثيمات",
                            icon = Icons.Default.Palette,
                            modifier = Modifier.weight(1f),
                            tag = "themes_menu_button",
                            onClick = { viewModel.navigateTo(ScreenState.THEMES) }
                        )
                        RetroSubMenuButton(
                            title = "الإحصائيات",
                            icon = Icons.Default.BarChart,
                            modifier = Modifier.weight(1f),
                            tag = "stats_menu_button",
                            onClick = { viewModel.navigateTo(ScreenState.STATS) }
                        )
                    }
                }
            }

            // Hamburger Menu Button (Drawer Trigger)
            IconButton(
                onClick = { scope.launch { drawerState.open() } },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .zIndex(10f)
                    .padding(16.dp)
                    .testTag("drawer_menu_button")
            ) {
                Text("≡", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = NavyPrimary)
            }

            // Quick Settings Shortcut at Top End
            IconButton(
                onClick = { viewModel.navigateTo(ScreenState.SETTINGS) },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .zIndex(10f)
                    .padding(16.dp)
                    .testTag("settings_top_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "الإعدادات",
                    tint = NavyPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Difficulty & Game Launch Dialog
            if (showDifficultyDialog) {
                DifficultySelectionDialog(
                    initialDifficulty = uiState.difficulty,
                    initialMode = uiState.gameMode,
                    currentGuessFree = uiState.isGuessFree,
                    initialCustomRows = uiState.customRows,
                    initialCustomCols = uiState.customCols,
                    initialCustomMines = uiState.customMines,
                    onDismiss = { showDifficultyDialog = false },
                    onSelectDifficulty = { diff, mode, guessFree, r, c, m ->
                        viewModel.selectDifficulty(
                            difficulty = diff,
                            mode = mode,
                            customRows = r,
                            customCols = c,
                            customMines = m,
                            guessFree = guessFree
                        )
                    },
                    onStartGame = { diff, mode, guessFree, r, c, m ->
                        showDifficultyDialog = false
                        viewModel.startNewGame(
                            difficulty = diff,
                            mode = mode,
                            customRows = r,
                            customCols = c,
                            customMines = m,
                            guessFree = guessFree
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun DrawerMenuItem(
    icon: ImageVector,
    title: String,
    badge: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onClick)
            .drawBehind {
                val stroke = 2.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(RetroPanelGray)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = NavyPrimary, modifier = Modifier.size(22.dp))
            Text(text = title, color = NavyPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        badge?.let {
            Box(
                modifier = Modifier
                    .background(NavyPrimary, RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(it, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun RetroBeveledCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .drawBehind {
                val stroke = 2.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(RetroPanelGray)
    ) {
        content()
    }
}

@Composable
fun RetroButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = RetroPanelGray,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .drawBehind {
                val stroke = 3.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(containerColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
private fun RetroMenuButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tag: String,
    onClick: () -> Unit
) {
    RetroButton(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = NavyPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Column {
                    Text(
                        text = title,
                        color = NavyPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = subtitle,
                        color = NavyPrimary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }
            Text("◀", color = NavyPrimary, fontSize = 16.sp)
        }
    }
}

@Composable
private fun RetroSubMenuButton(
    title: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    tag: String,
    onClick: () -> Unit
) {
    RetroButton(
        onClick = onClick,
        modifier = modifier
            .height(56.dp)
            .testTag(tag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(horizontal = 12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = NavyPrimary,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = title,
                color = NavyPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DifficultySelectionDialog(
    initialDifficulty: BoardDifficulty,
    initialMode: GameMode,
    currentGuessFree: Boolean,
    initialCustomRows: Int,
    initialCustomCols: Int,
    initialCustomMines: Int,
    onDismiss: () -> Unit,
    onSelectDifficulty: (BoardDifficulty, GameMode, Boolean, Int, Int, Int) -> Unit,
    onStartGame: (BoardDifficulty, GameMode, Boolean, Int, Int, Int) -> Unit
) {
    var selectedDifficulty by remember { mutableStateOf(initialDifficulty) }
    var selectedMode by remember { mutableStateOf(initialMode) }
    var guessFree by remember { mutableStateOf(currentGuessFree) }

    var customR by remember { mutableIntStateOf(initialCustomRows) }
    var customC by remember { mutableIntStateOf(initialCustomCols) }
    var customM by remember { mutableIntStateOf(initialCustomMines) }

    Dialog(onDismissRequest = onDismiss) {
        RetroBeveledCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("difficulty_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "اختر الصعوبة والطور 🎮",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = NavyPrimary
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Mode toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetroLightGray, RoundedCornerShape(4.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (selectedMode == GameMode.CLASSIC) NavyPrimary else Color.Transparent)
                            .clickable { selectedMode = GameMode.CLASSIC }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "حر كلاسيك",
                            color = if (selectedMode == GameMode.CLASSIC) Color.White else NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (selectedMode == GameMode.TIMER) NavyPrimary else Color.Transparent)
                            .clickable { selectedMode = GameMode.TIMER }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "تحدي المؤقت ⏱️",
                            color = if (selectedMode == GameMode.TIMER) Color.White else NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Difficulties List
                listOf(
                    BoardDifficulty.BEGINNER,
                    BoardDifficulty.INTERMEDIATE,
                    BoardDifficulty.EXPERT,
                    BoardDifficulty.CUSTOM
                ).forEach { diff ->
                    val isSelected = selectedDifficulty == diff
                    val desc = when (diff) {
                        BoardDifficulty.BEGINNER -> "حقل 9×9 - 10 ألغام"
                        BoardDifficulty.INTERMEDIATE -> "حقل 16×16 - 40 لغماً"
                        BoardDifficulty.EXPERT -> "حقل 16×30 - 99 لغماً"
                        BoardDifficulty.CUSTOM -> "حقل مخصص حسب رغبتك"
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .drawBehind {
                                val stroke = if (isSelected) 2.dp.toPx() else 1.dp.toPx()
                                drawLine(if (isSelected) NavyPrimary else RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                                drawLine(if (isSelected) NavyPrimary else RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                                drawLine(if (isSelected) NavyPrimary else RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                                drawLine(if (isSelected) NavyPrimary else RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                            }
                            .background(if (isSelected) Color(0xFFE2E8F0) else RetroPanelGray)
                            .clickable { selectedDifficulty = diff }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = diff.titleAr,
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = desc,
                                    color = NavyPrimary.copy(alpha = 0.7f),
                                    fontSize = 12.sp
                                )
                            }
                            if (isSelected) {
                                Text("✔", color = NavyPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                if (selectedDifficulty == BoardDifficulty.CUSTOM) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RetroLightGray, RoundedCornerShape(4.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CustomDimensionControlRow(
                            label = "الصفوف",
                            value = customR,
                            onDec = { if (customR > 8) customR-- },
                            onInc = { if (customR < 30) customR++ }
                        )
                        CustomDimensionControlRow(
                            label = "الأعمدة",
                            value = customC,
                            onDec = { if (customC > 8) customC-- },
                            onInc = { if (customC < 30) customC++ }
                        )
                        val maxMines = ((customR * customC) - 9).coerceAtLeast(1)
                        if (customM > maxMines) customM = maxMines
                        CustomDimensionControlRow(
                            label = "الألغام",
                            value = customM,
                            onDec = { if (customM > 1) customM-- },
                            onInc = { if (customM < maxMines) customM++ }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Guess-Free switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetroLightGray, RoundedCornerShape(4.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "خيار «بدون تخمين» 🧠",
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "لوحات قابلة للحل 100% بالمنطق",
                            color = NavyPrimary.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = guessFree,
                        onCheckedChange = { guessFree = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = NavyPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    RetroButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Text("إلغاء", color = NavyPrimary, fontWeight = FontWeight.Bold)
                    }

                    RetroButton(
                        onClick = {
                            onSelectDifficulty(selectedDifficulty, selectedMode, guessFree, customR, customC, customM)
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1.1f)
                            .height(44.dp)
                            .testTag("apply_difficulty_button"),
                        containerColor = RetroLightGray
                    ) {
                        Text("حفظ واختيار", color = NavyPrimary, fontWeight = FontWeight.Bold)
                    }

                    RetroButton(
                        onClick = {
                            onStartGame(selectedDifficulty, selectedMode, guessFree, customR, customC, customM)
                        },
                        modifier = Modifier
                            .weight(1.3f)
                            .height(44.dp)
                            .testTag("start_game_confirm_button"),
                        containerColor = NavyPrimary
                    ) {
                        Text("ابدأ اللعب GO 🚀", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyRewardsCard(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    val streak = uiState.dailyStreak
    val todayNumber = ((streak.currentStreak) % 7).let { if (it == 0) 7 else it }
    val reward = streak.getRewardForDay(todayNumber)

    RetroBeveledCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(RetroPanelGray)
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("🎁", fontSize = 15.sp)
                    Text(
                        text = "المكافآت اليومية (سلسلة: ${streak.currentStreak} يوم)",
                        color = NavyPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp
                    )
                }
                Text(
                    text = "اليوم $todayNumber",
                    color = NavyPrimary.copy(alpha = 0.7f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = reward.labelAr,
                color = NavyPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )

            uiState.dailyClaimRewardMessage?.let { msg ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF2E7D32).copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = msg, color = Color(0xFF1B5E20), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { viewModel.clearDailyMessage() }) {
                        Text("×", color = Color(0xFF1B5E20), fontWeight = FontWeight.Bold)
                    }
                }
            }

            RetroButton(
                onClick = {
                    if (!streak.isClaimedToday) {
                        viewModel.claimDailyReward()
                    }
                },
                containerColor = if (streak.isClaimedToday) RetroLightGray else NavyPrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
                    .testTag("claim_daily_button")
            ) {
                Text(
                    text = if (streak.isClaimedToday) "تم الاستلام اليوم ✅" else "استلام مكافأة اليوم 💰",
                    color = if (streak.isClaimedToday) NavyPrimary.copy(alpha = 0.6f) else Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun CustomDimensionControlRow(
    label: String,
    value: Int,
    onDec: () -> Unit,
    onInc: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = NavyPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            RetroButton(
                onClick = onDec,
                containerColor = NavyPrimary,
                modifier = Modifier.size(36.dp, 32.dp)
            ) {
                Text("-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Text(
                text = "$value",
                color = NavyPrimary,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp,
                modifier = Modifier.widthIn(min = 36.dp),
                textAlign = TextAlign.Center
            )
            RetroButton(
                onClick = onInc,
                containerColor = NavyPrimary,
                modifier = Modifier.size(36.dp, 32.dp)
            ) {
                Text("+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}
