package com.example.minesweeper.model

data class CampaignLevel(
    val id: Int,
    val nameAr: String,
    val rows: Int,
    val cols: Int,
    val mines: Int,
    val targetSeconds: Int? = null,
    val maxClicks: Int? = null,
    val descriptionAr: String,
    val rewardHints: Int = 1,
    val rewardWands: Int = 0
)

object CampaignLevels {
    val levels = listOf(
        CampaignLevel(1, "المبتدئ الأول", 5, 5, 3, targetSeconds = null, maxClicks = null, "تعرف على الأساسيات في لوحة مصغرة 5×5 مع 3 ألغام", rewardHints = 1),
        CampaignLevel(2, "أول خطوة", 6, 6, 5, targetSeconds = null, maxClicks = null, "لوحة 6×6 مع 5 ألغام", rewardHints = 1),
        CampaignLevel(3, "حديقة الألغام", 7, 7, 8, targetSeconds = null, maxClicks = null, "احذر من الألغام المتجاورة في 7×7", rewardHints = 1, rewardWands = 1),
        CampaignLevel(4, "تحدي السرعة 1", 8, 8, 9, targetSeconds = 45, maxClicks = null, "أكمل اللوحة خلال 45 ثانية فقط!", rewardHints = 2),
        CampaignLevel(5, "مبتدئ محترف", 9, 9, 10, targetSeconds = null, maxClicks = null, "المستوى الكلاسيكي للمبتدئين 9×9 مع 10 ألغام", rewardHints = 2),
        CampaignLevel(6, "دقة النقرات", 9, 9, 10, targetSeconds = null, maxClicks = 25, "حل اللوحة الكلاسيكية بـ 25 نقرة أو أقل!", rewardHints = 2, rewardWands = 1),
        CampaignLevel(7, "حقل الأطلسي", 10, 10, 15, targetSeconds = null, maxClicks = null, "لوحة متوسعة 10×10 مع 15 لغم", rewardHints = 2),
        CampaignLevel(8, "تحدي السرعة 2", 11, 11, 18, targetSeconds = 60, maxClicks = null, "أكمل اللوحة بـ 60 ثانية قبل نفاد المؤقت!", rewardHints = 3),
        CampaignLevel(9, "المنطقة المتوسطة", 12, 12, 22, targetSeconds = null, maxClicks = null, "تركيز أعلى مع 22 لغم في 12×12", rewardHints = 2, rewardWands = 1),
        CampaignLevel(10, "مستوى الكلاسيك", 16, 16, 40, targetSeconds = null, maxClicks = null, "التحدي المتوسط الأصلي 16×16 مع 40 لغم", rewardHints = 3, rewardWands = 2),
        CampaignLevel(11, "كاسحة النخبة", 16, 16, 40, targetSeconds = 120, maxClicks = null, "أنهِ اللوحة المتوسطة خلال دقيقتين فقط!", rewardHints = 3, rewardWands = 2),
        CampaignLevel(12, "حقل الأشباح", 18, 14, 48, targetSeconds = null, maxClicks = null, "لوحة عريضة ومكثفة مع 48 لغم", rewardHints = 4, rewardWands = 2),
        CampaignLevel(13, "عاصفة الصحراء", 20, 15, 65, targetSeconds = null, maxClicks = null, "مستوى متقدم يقترب من مستوى الخبراء", rewardHints = 4, rewardWands = 3),
        CampaignLevel(14, "المعركة الكبرى", 24, 15, 80, targetSeconds = null, maxClicks = null, "لوحة عملاقة 24×15 تتطلب دقة متناهية", rewardHints = 5, rewardWands = 3),
        CampaignLevel(15, "أسطورة صائد الألغام", 16, 30, 99, targetSeconds = null, maxClicks = null, "مستوى الخبير الأسطوري 16×30 مع 99 لغم!", rewardHints = 10, rewardWands = 5)
    )
}

data class CampaignProgress(
    val unlockedLevel: Int = 1,
    val starsPerLevel: Map<Int, Int> = emptyMap(),
    val hintsInventory: Int = 3,
    val magicWandsInventory: Int = 1
)
