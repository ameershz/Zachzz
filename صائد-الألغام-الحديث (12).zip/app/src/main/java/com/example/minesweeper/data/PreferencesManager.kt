package com.example.minesweeper.data

import android.content.Context
import android.content.SharedPreferences
import com.example.minesweeper.model.BoardDifficulty
import com.example.minesweeper.model.CampaignProgress
import com.example.minesweeper.model.ChordingTrigger
import com.example.minesweeper.model.DailyStreakState
import com.example.minesweeper.model.DifficultyStats
import com.example.minesweeper.model.GameMode
import com.example.minesweeper.model.MatchRecord
import com.example.minesweeper.model.SavedGameData
import com.example.minesweeper.model.SettingsState
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("minesweeper_prefs", Context.MODE_PRIVATE)

    // Settings
    fun loadSettings(): SettingsState {
        val chordingName = prefs.getString("chording_trigger", ChordingTrigger.LONG_PRESS.name) ?: ChordingTrigger.LONG_PRESS.name
        val chordingTrigger = try {
            ChordingTrigger.valueOf(chordingName)
        } catch (e: Exception) {
            ChordingTrigger.LONG_PRESS
        }

        return SettingsState(
            chordingTrigger = chordingTrigger,
            volumeKeyToggleEnabled = prefs.getBoolean("volume_key_toggle", true),
            hapticFeedbackEnabled = prefs.getBoolean("haptic_feedback", true),
            soundEffectsEnabled = prefs.getBoolean("sound_effects", true),
            lockZoomByDefault = prefs.getBoolean("lock_zoom", false),
            guessFreeOptionEnabled = prefs.getBoolean("guess_free_mode", false),
            selectedThemeId = prefs.getString("selected_theme", "classic_retro") ?: "classic_retro",
            questionMarksEnabled = prefs.getBoolean("question_marks", true),
            noFlagMode = prefs.getBoolean("no_flag_mode", false),
            repetitiveChording = prefs.getBoolean("repetitive_chording", false),
            chordingOnReveal = prefs.getBoolean("chording_on_reveal", false),
            flagChording = prefs.getBoolean("flag_chording", false),
            longPressDurationMs = prefs.getInt("long_press_duration_ms", 350),
            undoOnLossEnabled = prefs.getBoolean("undo_on_loss", false),
            unlimitedHints = prefs.getBoolean("unlimited_hints", false),
            showHud = prefs.getBoolean("show_hud", true),
            showNavigationArrows = prefs.getBoolean("show_nav_arrows", true),
            showHintButton = prefs.getBoolean("show_hint_btn", true),
            showWandButton = prefs.getBoolean("show_wand_btn", true),
            showTimerPanel = prefs.getBoolean("show_timer_panel", true),
            showStatusBar = prefs.getBoolean("show_status_bar", true),
            show3bvDuringGame = prefs.getBoolean("show_3bv", false),
            classicTimer = prefs.getBoolean("classic_timer", true),
            soundFlag = prefs.getBoolean("sound_flag", true),
            soundReveal = prefs.getBoolean("sound_reveal", true),
            soundWin = prefs.getBoolean("sound_win", true),
            soundExplosion = prefs.getBoolean("sound_explosion", true),
            inertiaScrolling = prefs.getBoolean("inertia_scrolling", true),
            freeScrollingOutside = prefs.getBoolean("free_scrolling_outside", true),
            confirmNewGame = prefs.getBoolean("confirm_new_game", false),
            confirmLeaveGame = prefs.getBoolean("confirm_leave_game", false),
            pauseTimerOnIdle = prefs.getBoolean("pause_timer_on_idle", true)
        )
    }

    fun saveSettings(settings: SettingsState) {
        prefs.edit()
            .putString("chording_trigger", settings.chordingTrigger.name)
            .putBoolean("volume_key_toggle", settings.volumeKeyToggleEnabled)
            .putBoolean("haptic_feedback", settings.hapticFeedbackEnabled)
            .putBoolean("sound_effects", settings.soundEffectsEnabled)
            .putBoolean("lock_zoom", settings.lockZoomByDefault)
            .putBoolean("guess_free_mode", settings.guessFreeOptionEnabled)
            .putString("selected_theme", settings.selectedThemeId)
            .putBoolean("question_marks", settings.questionMarksEnabled)
            .putBoolean("no_flag_mode", settings.noFlagMode)
            .putBoolean("repetitive_chording", settings.repetitiveChording)
            .putBoolean("chording_on_reveal", settings.chordingOnReveal)
            .putBoolean("flag_chording", settings.flagChording)
            .putInt("long_press_duration_ms", settings.longPressDurationMs)
            .putBoolean("undo_on_loss", settings.undoOnLossEnabled)
            .putBoolean("unlimited_hints", settings.unlimitedHints)
            .putBoolean("show_hud", settings.showHud)
            .putBoolean("show_nav_arrows", settings.showNavigationArrows)
            .putBoolean("show_hint_btn", settings.showHintButton)
            .putBoolean("show_wand_btn", settings.showWandButton)
            .putBoolean("show_timer_panel", settings.showTimerPanel)
            .putBoolean("show_status_bar", settings.showStatusBar)
            .putBoolean("show_3bv", settings.show3bvDuringGame)
            .putBoolean("classic_timer", settings.classicTimer)
            .putBoolean("sound_flag", settings.soundFlag)
            .putBoolean("sound_reveal", settings.soundReveal)
            .putBoolean("sound_win", settings.soundWin)
            .putBoolean("sound_explosion", settings.soundExplosion)
            .putBoolean("inertia_scrolling", settings.inertiaScrolling)
            .putBoolean("free_scrolling_outside", settings.freeScrollingOutside)
            .putBoolean("confirm_new_game", settings.confirmNewGame)
            .putBoolean("confirm_leave_game", settings.confirmLeaveGame)
            .putBoolean("pause_timer_on_idle", settings.pauseTimerOnIdle)
            .apply()
    }

    fun resetSettings(): SettingsState {
        val defaultSettings = SettingsState()
        saveSettings(defaultSettings)
        return defaultSettings
    }

    // Stats
    fun loadStats(difficulty: BoardDifficulty): DifficultyStats {
        val prefix = "stats_${difficulty.name}_"
        return DifficultyStats(
            gamesPlayed = prefs.getInt("${prefix}played", 0),
            gamesWon = prefs.getInt("${prefix}won", 0),
            bestTimeSeconds = prefs.getInt("${prefix}best_time", 0),
            totalTimeSeconds = prefs.getLong("${prefix}total_time", 0L),
            best3BV = prefs.getInt("${prefix}best_3bv", 0),
            best3BVs = prefs.getFloat("${prefix}best_3bvs", 0f),
            bestEfficiencyPct = prefs.getFloat("${prefix}best_eff", 0f)
        )
    }

    fun recordGameResult(
        difficulty: BoardDifficulty,
        won: Boolean,
        timeSeconds: Int,
        threeBV: Int,
        threeBVs: Float,
        clicks: Int,
        efficiencyPct: Float
    ) {
        val current = loadStats(difficulty)
        val prefix = "stats_${difficulty.name}_"
        val newPlayed = current.gamesPlayed + 1
        val newWon = if (won) current.gamesWon + 1 else current.gamesWon
        val newTotalTime = if (won) current.totalTimeSeconds + timeSeconds else current.totalTimeSeconds
        val newBestTime = if (won) {
            if (current.bestTimeSeconds == 0 || timeSeconds < current.bestTimeSeconds) timeSeconds else current.bestTimeSeconds
        } else current.bestTimeSeconds

        val newBest3BV = maxOf(current.best3BV, threeBV)
        val newBest3BVs = if (won) maxOf(current.best3BVs, threeBVs) else current.best3BVs
        val newBestEff = if (won) maxOf(current.bestEfficiencyPct, efficiencyPct) else current.bestEfficiencyPct

        prefs.edit()
            .putInt("${prefix}played", newPlayed)
            .putInt("${prefix}won", newWon)
            .putInt("${prefix}best_time", newBestTime)
            .putLong("${prefix}total_time", newTotalTime)
            .putInt("${prefix}best_3bv", newBest3BV)
            .putFloat("${prefix}best_3bvs", newBest3BVs)
            .putFloat("${prefix}best_eff", newBestEff)
            .apply()

        addMatchRecord(
            MatchRecord(
                timestamp = System.currentTimeMillis(),
                difficulty = difficulty,
                won = won,
                timeSeconds = timeSeconds,
                threeBV = threeBV,
                threeBVs = threeBVs,
                clicks = clicks,
                efficiencyPct = efficiencyPct
            )
        )
    }

    private fun addMatchRecord(record: MatchRecord) {
        val records = loadMatchHistory().toMutableList()
        records.add(0, record)
        if (records.size > 20) {
            records.removeAt(records.size - 1)
        }
        val array = JSONArray()
        for (r in records) {
            val obj = JSONObject().apply {
                put("ts", r.timestamp)
                put("diff", r.difficulty.name)
                put("won", r.won)
                put("time", r.timeSeconds)
                put("3bv", r.threeBV)
                put("3bvs", r.threeBVs.toDouble())
                put("clicks", r.clicks)
                put("eff", r.efficiencyPct.toDouble())
            }
            array.put(obj)
        }
        prefs.edit().putString("match_history", array.toString()).apply()
    }

    fun loadMatchHistory(): List<MatchRecord> {
        val jsonStr = prefs.getString("match_history", null) ?: return emptyList()
        val list = mutableListOf<MatchRecord>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val diff = try {
                    BoardDifficulty.valueOf(obj.getString("diff"))
                } catch (e: Exception) {
                    BoardDifficulty.BEGINNER
                }
                list.add(
                    MatchRecord(
                        timestamp = obj.getLong("ts"),
                        difficulty = diff,
                        won = obj.getBoolean("won"),
                        timeSeconds = obj.getInt("time"),
                        threeBV = obj.getInt("3bv"),
                        threeBVs = obj.getDouble("3bvs").toFloat(),
                        clicks = obj.getInt("clicks"),
                        efficiencyPct = obj.getDouble("eff").toFloat()
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    // Campaign Progress
    fun loadCampaignProgress(): CampaignProgress {
        val unlocked = prefs.getInt("campaign_unlocked_level", 1)
        val hints = prefs.getInt("campaign_hints", 3)
        val wands = prefs.getInt("campaign_wands", 1)
        return CampaignProgress(
            unlockedLevel = unlocked,
            hintsInventory = hints,
            magicWandsInventory = wands
        )
    }

    fun saveCampaignProgress(progress: CampaignProgress) {
        prefs.edit()
            .putInt("campaign_unlocked_level", progress.unlockedLevel)
            .putInt("campaign_hints", progress.hintsInventory)
            .putInt("campaign_wands", progress.magicWandsInventory)
            .apply()
    }

    // Daily Streak
    fun loadDailyStreak(): DailyStreakState {
        val currentStreak = prefs.getInt("daily_streak_current", 0)
        val longestStreak = prefs.getInt("daily_streak_longest", 0)
        val lastClaimMillis = prefs.getLong("daily_streak_last_claim", 0L)

        val isClaimedToday = isSameDay(lastClaimMillis, System.currentTimeMillis())

        return DailyStreakState(
            currentStreak = currentStreak,
            longestStreak = longestStreak,
            lastClaimDateMillis = lastClaimMillis,
            isClaimedToday = isClaimedToday
        )
    }

    fun claimDailyReward(): Pair<DailyStreakState, Pair<Int, Int>> {
        val current = loadDailyStreak()
        val now = System.currentTimeMillis()
        if (current.isClaimedToday) {
            return current to (0 to 0)
        }

        val wasYesterday = isYesterday(current.lastClaimDateMillis, now)
        val newStreak = if (wasYesterday || current.currentStreak == 0) {
            current.currentStreak + 1
        } else {
            1
        }

        val newLongest = maxOf(current.longestStreak, newStreak)
        val reward = current.getRewardForDay(((newStreak - 1) % 7) + 1)

        prefs.edit()
            .putInt("daily_streak_current", newStreak)
            .putInt("daily_streak_longest", newLongest)
            .putLong("daily_streak_last_claim", now)
            .apply()

        val campProgress = loadCampaignProgress()
        saveCampaignProgress(
            campProgress.copy(
                hintsInventory = campProgress.hintsInventory + reward.hints,
                magicWandsInventory = campProgress.magicWandsInventory + reward.magicWands
            )
        )

        val newState = DailyStreakState(
            currentStreak = newStreak,
            longestStreak = newLongest,
            lastClaimDateMillis = now,
            isClaimedToday = true
        )
        return newState to (reward.hints to reward.magicWands)
    }

    // Tutorial completed flag
    fun hasCompletedTutorial(): Boolean {
        return prefs.getBoolean("has_completed_tutorial", false)
    }

    fun setTutorialCompleted(completed: Boolean) {
        prefs.edit().putBoolean("has_completed_tutorial", completed).apply()
    }

    // Auto-save Game with coordinate strings (r,c;r,c;...)
    fun saveSavedGame(data: SavedGameData) {
        prefs.edit()
            .putBoolean("saved_game_exists", true)
            .putString("saved_game_diff", data.difficulty.name)
            .putString("saved_game_mode", data.gameMode.name)
            .putInt("saved_game_rows", data.rows)
            .putInt("saved_game_cols", data.cols)
            .putInt("saved_game_mines", data.totalMines)
            .putString("saved_game_mine_coords", serializeCoords(data.mineCoords))
            .putString("saved_game_revealed_coords", serializeCoords(data.revealedCoords))
            .putString("saved_game_flag_coords", serializeCoords(data.flaggedCoords))
            .putString("saved_game_question_coords", serializeCoords(data.questionCoords))
            .putInt("saved_game_timer", data.timerSeconds)
            .putInt("saved_game_timer_limit", data.timerLimitSeconds ?: -1)
            .putBoolean("saved_game_guess_free", data.isGuessFree)
            .putInt("saved_game_campaign_level", data.campaignLevelId ?: -1)
            .putBoolean("saved_game_has_started", data.hasStarted)
            .apply()
    }

    fun loadSavedGame(): SavedGameData? {
        if (!prefs.getBoolean("saved_game_exists", false)) return null

        val diffName = prefs.getString("saved_game_diff", BoardDifficulty.BEGINNER.name) ?: BoardDifficulty.BEGINNER.name
        val difficulty = try { BoardDifficulty.valueOf(diffName) } catch (e: Exception) { BoardDifficulty.BEGINNER }

        val modeName = prefs.getString("saved_game_mode", GameMode.CLASSIC.name) ?: GameMode.CLASSIC.name
        val gameMode = try { GameMode.valueOf(modeName) } catch (e: Exception) { GameMode.CLASSIC }

        val rows = prefs.getInt("saved_game_rows", difficulty.rows)
        val cols = prefs.getInt("saved_game_cols", difficulty.cols)
        val totalMines = prefs.getInt("saved_game_mines", difficulty.defaultMines)
        val mineCoords = deserializeCoords(prefs.getString("saved_game_mine_coords", null))
        val revealedCoords = deserializeCoords(prefs.getString("saved_game_revealed_coords", null))
        val flaggedCoords = deserializeCoords(prefs.getString("saved_game_flag_coords", null))
        val questionCoords = deserializeCoords(prefs.getString("saved_game_question_coords", null))
        val timerSeconds = prefs.getInt("saved_game_timer", 0)
        val limitRaw = prefs.getInt("saved_game_timer_limit", -1)
        val timerLimitSeconds = if (limitRaw > 0) limitRaw else null
        val isGuessFree = prefs.getBoolean("saved_game_guess_free", false)
        val campRaw = prefs.getInt("saved_game_campaign_level", -1)
        val campaignLevelId = if (campRaw > 0) campRaw else null
        val hasStarted = prefs.getBoolean("saved_game_has_started", false)

        return SavedGameData(
            difficulty = difficulty,
            gameMode = gameMode,
            rows = rows,
            cols = cols,
            totalMines = totalMines,
            mineCoords = mineCoords,
            revealedCoords = revealedCoords,
            flaggedCoords = flaggedCoords,
            questionCoords = questionCoords,
            timerSeconds = timerSeconds,
            timerLimitSeconds = timerLimitSeconds,
            isGuessFree = isGuessFree,
            campaignLevelId = campaignLevelId,
            hasStarted = hasStarted
        )
    }

    fun clearSavedGame() {
        prefs.edit()
            .remove("saved_game_exists")
            .remove("saved_game_diff")
            .remove("saved_game_mode")
            .remove("saved_game_rows")
            .remove("saved_game_cols")
            .remove("saved_game_mines")
            .remove("saved_game_mine_coords")
            .remove("saved_game_revealed_coords")
            .remove("saved_game_flag_coords")
            .remove("saved_game_question_coords")
            .remove("saved_game_timer")
            .remove("saved_game_timer_limit")
            .remove("saved_game_guess_free")
            .remove("saved_game_campaign_level")
            .remove("saved_game_has_started")
            .apply()
    }

    fun hasSavedGame(): Boolean {
        return prefs.getBoolean("saved_game_exists", false)
    }

    private fun serializeCoords(coords: Collection<Pair<Int, Int>>): String {
        return coords.joinToString(";") { "${it.first},${it.second}" }
    }

    private fun deserializeCoords(str: String?): Set<Pair<Int, Int>> {
        if (str.isNullOrBlank()) return emptySet()
        return str.split(";").mapNotNull { part ->
            val sub = part.split(",")
            if (sub.size == 2) {
                val r = sub[0].toIntOrNull()
                val c = sub[1].toIntOrNull()
                if (r != null && c != null) r to c else null
            } else null
        }.toSet()
    }

    private fun isSameDay(timeA: Long, timeB: Long): Boolean {
        if (timeA == 0L || timeB == 0L) return false
        val calA = Calendar.getInstance().apply { timeInMillis = timeA }
        val calB = Calendar.getInstance().apply { timeInMillis = timeB }
        return calA.get(Calendar.YEAR) == calB.get(Calendar.YEAR) &&
                calA.get(Calendar.DAY_OF_YEAR) == calB.get(Calendar.DAY_OF_YEAR)
    }

    private fun isYesterday(timeA: Long, timeB: Long): Boolean {
        if (timeA == 0L || timeB == 0L) return false
        val calA = Calendar.getInstance().apply { timeInMillis = timeA }
        val calB = Calendar.getInstance().apply { timeInMillis = timeB }
        calA.add(Calendar.DAY_OF_YEAR, 1)
        return calA.get(Calendar.YEAR) == calB.get(Calendar.YEAR) &&
                calA.get(Calendar.DAY_OF_YEAR) == calB.get(Calendar.DAY_OF_YEAR)
    }
}
