package com.example.minesweeper.engine

import com.example.minesweeper.model.Cell
import com.example.minesweeper.model.GameStatus
import com.example.minesweeper.model.RevealResult
import kotlin.random.Random

class MinesweeperEngine(
    val rows: Int,
    val cols: Int,
    val totalMines: Int,
    val isGuessFreeRequested: Boolean = false
) {
    var grid: List<List<Cell>> = List(rows) { r ->
        List(cols) { c -> Cell(row = r, col = c) }
    }
        private set

    var status: GameStatus = GameStatus.NOT_STARTED
        private set

    var isFirstClick: Boolean = true
        private set

    var threeBV: Int = 0
        private set

    var clicksCount: Int = 0
        private set

    var effectiveClicksCount: Int = 0
        private set

    private var initialMinePositions: Set<Pair<Int, Int>>? = null

    val minePositions: Set<Pair<Int, Int>>
        get() {
            val list = mutableSetOf<Pair<Int, Int>>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (grid[r][c].isMine) list.add(r to c)
                }
            }
            return list
        }

    val totalCells: Int = rows * cols
    val safeCellsCount: Int = totalCells - totalMines

    val revealedCount: Int
        get() = grid.sumOf { row -> row.count { it.isRevealed && !it.isMine } }

    val flaggedCount: Int
        get() = grid.sumOf { row -> row.count { it.isFlagged } }

    val remainingMines: Int
        get() = totalMines - flaggedCount

    fun getNeighbors(r: Int, c: Int): List<Pair<Int, Int>> {
        val list = mutableListOf<Pair<Int, Int>>()
        for (dr in -1..1) {
            for (dc in -1..1) {
                if (dr == 0 && dc == 0) continue
                val nr = r + dr
                val nc = c + dc
                if (nr in 0 until rows && nc in 0 until cols) {
                    list.add(nr to nc)
                }
            }
        }
        return list
    }

    private fun generateBoard(firstR: Int, firstC: Int, forcedMines: Set<Pair<Int, Int>>? = null) {
        val preFlagged = mutableSetOf<Pair<Int, Int>>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (grid[r][c].isFlagged) {
                    preFlagged.add(r to c)
                }
            }
        }

        if (forcedMines != null) {
            val candidateGrid = List(rows) { r ->
                MutableList(cols) { c -> Cell(row = r, col = c, isFlagged = preFlagged.contains(r to c)) }
            }
            for ((r, c) in forcedMines) {
                if (r in 0 until rows && c in 0 until cols) {
                    candidateGrid[r][c] = candidateGrid[r][c].copy(isMine = true)
                }
            }
            // Calculate adjacent mines
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (!candidateGrid[r][c].isMine) {
                        val count = getNeighbors(r, c).count { (nr, nc) -> candidateGrid[nr][nc].isMine }
                        candidateGrid[r][c] = candidateGrid[r][c].copy(adjacentMines = count)
                    }
                }
            }
            grid = candidateGrid.map { it.toList() }
            initialMinePositions = forcedMines
            threeBV = ThreeBVCalculator.calculate(grid, rows, cols)
            return
        }

        var chosenGrid: List<List<Cell>>? = null
        var chosenMines: Set<Pair<Int, Int>> = emptySet()

        while (chosenGrid == null) {
            val candidateGrid = List(rows) { r ->
                MutableList(cols) { c -> Cell(row = r, col = c, isFlagged = preFlagged.contains(r to c)) }
            }

            val forbidden = mutableSetOf<Pair<Int, Int>>()
            forbidden.add(firstR to firstC)
            for (pf in preFlagged) {
                forbidden.add(pf)
            }
            if (totalCells - 9 >= totalMines) {
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        val nr = firstR + dr
                        val nc = firstC + dc
                        if (nr in 0 until rows && nc in 0 until cols) {
                            forbidden.add(nr to nc)
                        }
                    }
                }
            }

            val allCoords = mutableListOf<Pair<Int, Int>>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if ((r to c) !in forbidden) {
                        allCoords.add(r to c)
                    }
                }
            }
            allCoords.shuffle(Random)

            val minesNeeded = maxOf(0, totalMines - preFlagged.size)
            val minePositions = allCoords.take(minesNeeded).toSet() + preFlagged

            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val isMine = (r to c) in minePositions
                    candidateGrid[r][c] = candidateGrid[r][c].copy(isMine = isMine, isFlagged = preFlagged.contains(r to c))
                }
            }

            // Calculate adjacent mines
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    if (!candidateGrid[r][c].isMine) {
                        val count = getNeighbors(r, c).count { (nr, nc) -> candidateGrid[nr][nc].isMine }
                        candidateGrid[r][c] = candidateGrid[r][c].copy(adjacentMines = count)
                    }
                }
            }

            val candidateList = candidateGrid.map { it.toList() }

            if (!isGuessFreeRequested || GuessFreeSolver.isSolvable(candidateList, rows, cols, firstR, firstC)) {
                chosenGrid = candidateList
                chosenMines = minePositions
                break
            }
        }

        grid = chosenGrid ?: grid
        initialMinePositions = chosenMines
        threeBV = ThreeBVCalculator.calculate(grid, rows, cols)
    }

    fun flagCells(coords: List<Pair<Int, Int>>) {
        if (status == GameStatus.WON || status == GameStatus.LOST) return
        val coordSet = coords.toSet()
        grid = grid.mapIndexed { ri, row ->
            row.mapIndexed { ci, cl ->
                if ((ri to ci) in coordSet && !cl.isRevealed && !cl.isFlagged) {
                    cl.copy(isFlagged = true, isQuestionMark = false)
                } else {
                    cl
                }
            }
        }
    }

    private fun chosenMinesHolder(grid: List<List<Cell>>): Set<Pair<Int, Int>> {
        val mines = mutableSetOf<Pair<Int, Int>>()
        for (r in grid.indices) {
            for (c in grid[r].indices) {
                if (grid[r][c].isMine) mines.add(r to c)
            }
        }
        return mines
    }

    private fun chosenMinePositions(candidateGrid: List<MutableList<Cell>>, outSet: Set<Pair<Int, Int>>) {
        // no-op helper
    }

    fun revealCell(r: Int, c: Int): RevealResult {
        if (status == GameStatus.WON || status == GameStatus.LOST) return RevealResult.NoOp
        val cell = grid[r][c]
        if (cell.isRevealed || cell.isFlagged) return RevealResult.NoOp

        clicksCount++

        if (isFirstClick) {
            generateBoard(r, c)
            isFirstClick = false
            status = GameStatus.IN_PROGRESS
        }

        val target = grid[r][c]
        val mutableGrid = grid.map { it.toMutableList() }.toMutableList()

        if (target.isMine) {
            mutableGrid[r][c] = target.copy(isRevealed = true, isExplodedMine = true)
            for (row in 0 until rows) {
                for (col in 0 until cols) {
                    val curr = mutableGrid[row][col]
                    if (curr.isMine) {
                        mutableGrid[row][col] = curr.copy(isRevealed = true)
                    }
                }
            }
            grid = mutableGrid.map { it.toList() }
            status = GameStatus.LOST
            return RevealResult.HitMine(r, c)
        }

        effectiveClicksCount++
        revealFloodFill(mutableGrid, r, c)
        grid = mutableGrid.map { it.toList() }

        if (checkWin()) {
            status = GameStatus.WON
            grid = grid.map { row ->
                row.map { curr ->
                    if (curr.isMine && !curr.isFlagged) curr.copy(isFlagged = true) else curr
                }
            }
            return RevealResult.Win
        }

        return RevealResult.Success
    }

    private fun revealFloodFill(mutableGrid: MutableList<MutableList<Cell>>, startR: Int, startC: Int) {
        val queue = ArrayDeque<Pair<Int, Int>>()
        if (!mutableGrid[startR][startC].isRevealed && !mutableGrid[startR][startC].isFlagged) {
            mutableGrid[startR][startC] = mutableGrid[startR][startC].copy(isRevealed = true, isHinted = false)
            if (mutableGrid[startR][startC].adjacentMines == 0) {
                queue.add(startR to startC)
            }
        }

        while (queue.isNotEmpty()) {
            val (currR, currC) = queue.removeFirst()
            for ((nr, nc) in getNeighbors(currR, currC)) {
                val neighbor = mutableGrid[nr][nc]
                if (!neighbor.isRevealed && !neighbor.isFlagged && !neighbor.isMine) {
                    mutableGrid[nr][nc] = neighbor.copy(isRevealed = true, isHinted = false)
                    if (neighbor.adjacentMines == 0) {
                        queue.add(nr to nc)
                    }
                }
            }
        }
    }

    fun toggleFlag(r: Int, c: Int, questionMarksEnabled: Boolean = true, noFlagMode: Boolean = false): Boolean {
        if (status == GameStatus.WON || status == GameStatus.LOST) return false
        if (noFlagMode) return false
        val cell = grid[r][c]
        if (cell.isRevealed) return false

        clicksCount++
        val (newFlag, newQuestion) = if (questionMarksEnabled) {
            when {
                !cell.isFlagged && !cell.isQuestionMark -> true to false
                cell.isFlagged -> false to true
                else -> false to false
            }
        } else {
            val f = !cell.isFlagged
            f to false
        }

        grid = grid.mapIndexed { ri, row ->
            row.mapIndexed { ci, cl ->
                if (ri == r && ci == c) cl.copy(isFlagged = newFlag, isQuestionMark = newQuestion) else cl
            }
        }
        return newFlag
    }

    fun chordCell(r: Int, c: Int, repetitive: Boolean = false): RevealResult {
        if (status != GameStatus.IN_PROGRESS) return RevealResult.NoOp
        val cell = grid[r][c]
        if (!cell.isRevealed || cell.adjacentMines == 0) return RevealResult.NoOp

        val neighbors = getNeighbors(r, c)
        val flaggedCount = neighbors.count { (nr, nc) -> grid[nr][nc].isFlagged }

        if (flaggedCount == cell.adjacentMines) {
            clicksCount++
            effectiveClicksCount++
            var hitMine = false
            var mineCoords: Pair<Int, Int>? = null

            val mutableGrid = grid.map { it.toMutableList() }.toMutableList()
            val chordsQueue = ArrayDeque<Pair<Int, Int>>()
            val visitedChords = mutableSetOf<Pair<Int, Int>>()
            chordsQueue.add(r to c)
            visitedChords.add(r to c)

            val zeroQueue = ArrayDeque<Pair<Int, Int>>()

            while (chordsQueue.isNotEmpty()) {
                val (currR, currC) = chordsQueue.removeFirst()
                val currNeighbors = getNeighbors(currR, currC)

                for ((nr, nc) in currNeighbors) {
                    val neighbor = mutableGrid[nr][nc]
                    if (!neighbor.isRevealed && !neighbor.isFlagged) {
                        if (neighbor.isMine) {
                            hitMine = true
                            mineCoords = nr to nc
                            mutableGrid[nr][nc] = neighbor.copy(isRevealed = true, isExplodedMine = true)
                        } else {
                            mutableGrid[nr][nc] = neighbor.copy(isRevealed = true, isHinted = false)
                            if (neighbor.adjacentMines == 0) {
                                zeroQueue.add(nr to nc)
                            } else if (repetitive) {
                                val nNeighbors = getNeighbors(nr, nc)
                                val nFlags = nNeighbors.count { (fnr, fnc) -> mutableGrid[fnr][fnc].isFlagged }
                                if (nFlags == neighbor.adjacentMines && (nr to nc) !in visitedChords) {
                                    visitedChords.add(nr to nc)
                                    chordsQueue.add(nr to nc)
                                }
                            }
                        }
                    }
                }

                if (hitMine) break
            }

            if (hitMine) {
                for (row in 0 until rows) {
                    for (col in 0 until cols) {
                        val curr = mutableGrid[row][col]
                        if (curr.isMine) {
                            mutableGrid[row][col] = curr.copy(isRevealed = true)
                        }
                    }
                }
                grid = mutableGrid.map { it.toList() }
                status = GameStatus.LOST
                return RevealResult.HitMine(mineCoords?.first ?: r, mineCoords?.second ?: c)
            }

            while (zeroQueue.isNotEmpty()) {
                val (currR, currC) = zeroQueue.removeFirst()
                for ((nr, nc) in getNeighbors(currR, currC)) {
                    val neighbor = mutableGrid[nr][nc]
                    if (!neighbor.isRevealed && !neighbor.isFlagged && !neighbor.isMine) {
                        mutableGrid[nr][nc] = neighbor.copy(isRevealed = true, isHinted = false)
                        if (neighbor.adjacentMines == 0) {
                            zeroQueue.add(nr to nc)
                        } else if (repetitive) {
                            val nNeighbors = getNeighbors(nr, nc)
                            val nFlags = nNeighbors.count { (fnr, fnc) -> mutableGrid[fnr][fnc].isFlagged }
                            if (nFlags == neighbor.adjacentMines && (nr to nc) !in visitedChords) {
                                visitedChords.add(nr to nc)
                                chordsQueue.add(nr to nc)
                            }
                        }
                    }
                }
            }

            grid = mutableGrid.map { it.toList() }

            if (checkWin()) {
                status = GameStatus.WON
                grid = grid.map { row ->
                    row.map { curr ->
                        if (curr.isMine && !curr.isFlagged) curr.copy(isFlagged = true) else curr
                    }
                }
                return RevealResult.Win
            }

            return RevealResult.Success
        }
        return RevealResult.NoOp
    }

    fun useSmartHint(): Pair<Int, Int>? {
        if (status != GameStatus.IN_PROGRESS && !isFirstClick) return null

        if (isFirstClick) {
            return Pair(rows / 2, cols / 2)
        }

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (cell.isRevealed && cell.adjacentMines > 0) {
                    val neighbors = getNeighbors(r, c)
                    val unrevealedUnflagged = neighbors.filter { (nr, nc) ->
                        val nCell = grid[nr][nc]
                        !nCell.isRevealed && !nCell.isFlagged
                    }
                    val flaggedNeighborsCount = neighbors.count { (nr, nc) -> grid[nr][nc].isFlagged }

                    if (flaggedNeighborsCount == cell.adjacentMines && unrevealedUnflagged.isNotEmpty()) {
                        for (n in unrevealedUnflagged) {
                            if (!grid[n.first][n.second].isMine) return n
                        }
                    }

                    if (unrevealedUnflagged.size == cell.adjacentMines - flaggedNeighborsCount && unrevealedUnflagged.isNotEmpty()) {
                        for (n in unrevealedUnflagged) {
                            if (grid[n.first][n.second].isMine) return n
                        }
                    }
                }
            }
        }

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (!cell.isRevealed && !cell.isFlagged && !cell.isMine) {
                    return Pair(r, c)
                }
            }
        }

        return null
    }

    fun magicWandReveal(): Boolean {
        if (status != GameStatus.IN_PROGRESS && !isFirstClick) return false
        val unrevealedSafe = mutableListOf<Pair<Int, Int>>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (!cell.isRevealed && !cell.isMine) {
                    unrevealedSafe.add(r to c)
                }
            }
        }
        if (unrevealedSafe.isEmpty()) return false
        val target = unrevealedSafe.random(Random)
        if (isFirstClick) {
            generateBoard(target.first, target.second)
            isFirstClick = false
            status = GameStatus.IN_PROGRESS
        }
        val mutableGrid = grid.map { it.toMutableList() }.toMutableList()
        revealFloodFill(mutableGrid, target.first, target.second)
        grid = mutableGrid.map { it.toList() }

        if (checkWin()) {
            status = GameStatus.WON
            grid = grid.map { row ->
                row.map { curr ->
                    if (curr.isMine && !curr.isFlagged) curr.copy(isFlagged = true) else curr
                }
            }
        }
        return true
    }

    fun revive(): Boolean {
        if (status != GameStatus.LOST) return false
        val mutableGrid = grid.map { it.toMutableList() }.toMutableList()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = mutableGrid[r][c]
                if (cell.isExplodedMine || (cell.isMine && cell.isRevealed && !cell.isFlagged)) {
                    mutableGrid[r][c] = cell.copy(isRevealed = false, isExplodedMine = false, isFlagged = true)
                }
            }
        }
        grid = mutableGrid.map { it.toList() }
        status = GameStatus.IN_PROGRESS
        return true
    }

    fun replaySameBoard(): Boolean {
        val mines = initialMinePositions ?: return false
        grid = List(rows) { r ->
            List(cols) { c -> Cell(row = r, col = c) }
        }
        status = GameStatus.NOT_STARTED
        isFirstClick = false
        clicksCount = 0
        effectiveClicksCount = 0
        generateBoard(0, 0, forcedMines = mines)
        status = GameStatus.IN_PROGRESS
        return true
    }

    fun restoreBoard(
        mines: Set<Pair<Int, Int>>,
        revealed: Set<Pair<Int, Int>>,
        flags: Set<Pair<Int, Int>>,
        questions: Set<Pair<Int, Int>>
    ) {
        initialMinePositions = mines
        isFirstClick = false
        val candidateGrid = List(rows) { r ->
            MutableList(cols) { c ->
                Cell(
                    row = r,
                    col = c,
                    isMine = (r to c) in mines,
                    isRevealed = (r to c) in revealed,
                    isFlagged = (r to c) in flags,
                    isQuestionMark = (r to c) in questions
                )
            }
        }
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (!candidateGrid[r][c].isMine) {
                    val count = getNeighbors(r, c).count { (nr, nc) -> (nr to nc) in mines }
                    candidateGrid[r][c] = candidateGrid[r][c].copy(adjacentMines = count)
                }
            }
        }
        grid = candidateGrid.map { it.toList() }
        threeBV = ThreeBVCalculator.calculate(grid, rows, cols)
        status = GameStatus.IN_PROGRESS
    }

    fun restoreUnstartedBoard(
        flags: Set<Pair<Int, Int>>,
        questions: Set<Pair<Int, Int>>
    ) {
        isFirstClick = true
        status = GameStatus.NOT_STARTED
        grid = List(rows) { r ->
            List(cols) { c ->
                Cell(
                    row = r,
                    col = c,
                    isFlagged = (r to c) in flags,
                    isQuestionMark = (r to c) in questions
                )
            }
        }
    }

    private fun checkWin(): Boolean {
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val cell = grid[r][c]
                if (!cell.isMine && !cell.isRevealed) return false
            }
        }
        return true
    }
}
