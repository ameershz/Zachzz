package com.example.minesweeper.model

data class Cell(
    val row: Int,
    val col: Int,
    val isMine: Boolean = false,
    val isRevealed: Boolean = false,
    val isFlagged: Boolean = false,
    val isQuestionMark: Boolean = false,
    val adjacentMines: Int = 0,
    val isExplodedMine: Boolean = false,
    val isHinted: Boolean = false
)

sealed class RevealResult {
    object Success : RevealResult()
    object Win : RevealResult()
    data class HitMine(val r: Int, val c: Int) : RevealResult()
    object NoOp : RevealResult()
}
