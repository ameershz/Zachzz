package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.CampaignLevels
import com.example.minesweeper.model.GameMode
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

@Composable
fun CampaignScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RetroLightGray)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("campaign_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = NavyPrimary
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "خريطة الحملة 🗺️",
                        color = NavyPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "15 مرحلة بتحديات متصاعدة وإحياء لمرة واحدة",
                        color = NavyPrimary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }

                // Inventory chips
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    InventoryChip(icon = "💡", count = uiState.campaignProgress.hintsInventory)
                    InventoryChip(icon = "🪄", count = uiState.campaignProgress.magicWandsInventory)
                }
            }

            // Levels List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(CampaignLevels.levels) { level ->
                    val isUnlocked = level.id <= uiState.campaignProgress.unlockedLevel
                    val stars = uiState.campaignProgress.starsPerLevel[level.id] ?: 0

                    CampaignLevelCard(
                        level = level,
                        isUnlocked = isUnlocked,
                        stars = stars,
                        onClick = {
                            if (isUnlocked) {
                                viewModel.startNewGame(
                                    mode = GameMode.CAMPAIGN,
                                    campaignLevel = level
                                )
                            }
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
private fun InventoryChip(icon: String, count: Int) {
    Box(
        modifier = Modifier
            .drawBehind {
                val stroke = 1.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(RetroPanelGray, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(icon, fontSize = 14.sp)
            Text(
                count.toString(),
                color = NavyPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun CampaignLevelCard(
    level: com.example.minesweeper.model.CampaignLevel,
    isUnlocked: Boolean,
    stars: Int,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("campaign_level_${level.id}")
            .drawBehind {
                val stroke = 2.dp.toPx()
                drawLine(if (isUnlocked) RetroWhiteHighlight else RetroDarkShadow, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(if (isUnlocked) RetroWhiteHighlight else RetroDarkShadow, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(if (isUnlocked) RetroPanelGray else Color(0xFFB0B0B0), RoundedCornerShape(4.dp))
            .clickable(enabled = isUnlocked, onClick = onClick)
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Stage Number Badge
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .drawBehind {
                        val stroke = 1.dp.toPx()
                        drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                        drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                        drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                        drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                    }
                    .background(if (isUnlocked) RetroLightGray else Color(0xFF9E9E9E), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (isUnlocked) {
                    Text(
                        text = level.id.toString(),
                        color = NavyPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "مغلق",
                        tint = NavyPrimary.copy(alpha = 0.5f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = level.nameAr,
                        color = if (isUnlocked) NavyPrimary else NavyPrimary.copy(alpha = 0.5f),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "${level.rows}×${level.cols} (${level.mines} لغم)",
                        color = if (isUnlocked) NavyPrimary.copy(alpha = 0.8f) else NavyPrimary.copy(alpha = 0.4f),
                        fontSize = 11.sp
                    )
                }

                Text(
                    text = level.descriptionAr,
                    color = if (isUnlocked) NavyPrimary.copy(alpha = 0.8f) else NavyPrimary.copy(alpha = 0.4f),
                    fontSize = 12.sp,
                    maxLines = 2
                )

                // Target Badges
                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (level.targetSeconds != null) {
                        TargetBadge("⏱️ ${level.targetSeconds} ثانية")
                    }
                    if (level.maxClicks != null) {
                        TargetBadge("🎯 أقصى ${level.maxClicks} نقرة")
                    }
                    if (level.rewardHints > 0) {
                        TargetBadge("+${level.rewardHints} 💡")
                    }
                    if (level.rewardWands > 0) {
                        TargetBadge("+${level.rewardWands} 🪄")
                    }
                }
            }

            // Stars earned
            if (isUnlocked) {
                Row {
                    repeat(3) { i ->
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (i < stars) Color(0xFFD4AF37) else RetroDarkShadow,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TargetBadge(text: String) {
    Box(
        modifier = Modifier
            .drawBehind {
                val stroke = 1.dp.toPx()
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
            }
            .background(RetroLightGray, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            color = NavyPrimary,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
