package com.example.minesweeper.model

data class SavedGameData(
    val difficulty: BoardDifficulty,
    val gameMode: GameMode,
    val rows: Int,
    val cols: Int,
    val totalMines: Int,
    val mineCoords: Set<Pair<Int, Int>>,
    val revealedCoords: Set<Pair<Int, Int>>,
    val flaggedCoords: Set<Pair<Int, Int>>,
    val questionCoords: Set<Pair<Int, Int>>,
    val timerSeconds: Int,
    val timerLimitSeconds: Int?,
    val isGuessFree: Boolean,
    val campaignLevelId: Int?,
    val hasStarted: Boolean
)
