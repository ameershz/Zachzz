package com.example.minesweeper.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.model.GameMode
import com.example.minesweeper.model.GameStatus

@Composable
fun ResultDialog(
    status: GameStatus,
    gameMode: GameMode,
    timeSeconds: Int,
    threeBV: Int,
    threeBVs: Float,
    clicksCount: Int,
    efficiencyPct: Float,
    canReviveInCampaign: Boolean,
    onRestart: () -> Unit,
    onHome: () -> Unit,
    onRevive: () -> Unit
) {
    val isWin = status == GameStatus.WON

    Dialog(onDismissRequest = {}) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    val stroke = 2.dp.toPx()
                    drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                    drawLine(RetroWhiteHighlight, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                    drawLine(RetroDarkShadow, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                    drawLine(RetroDarkShadow, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                }
                .background(RetroPanelGray, RoundedCornerShape(4.dp))
                .padding(16.dp)
                .testTag("result_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isWin) "🎉" else "💥",
                    fontSize = 48.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isWin) "مبروك! فوز ساحق" else "انفجر اللغم! حظ أوفر",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = NavyPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Stats breakdown box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .drawBehind {
                            val stroke = 1.dp.toPx()
                            drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                            drawLine(RetroDarkShadow, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                            drawLine(RetroWhiteHighlight, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                            drawLine(RetroWhiteHighlight, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                        }
                        .background(RetroLightGray, RoundedCornerShape(4.dp))
                        .padding(12.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatRow(label = "الوقت المستغرق:", value = "$timeSeconds ثانية")
                        StatRow(label = "مؤشر 3BV للوحة:", value = threeBV.toString())
                        if (isWin) {
                            StatRow(label = "سرعة 3BV/ثانية:", value = String.format("%.2f", threeBVs))
                            StatRow(label = "كفاءة النقرات:", value = "${efficiencyPct.toInt()}%")
                        }
                        StatRow(label = "إجمالي النقرات:", value = clicksCount.toString())
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Revive button in Campaign mode if eligible
                if (!isWin && gameMode == GameMode.CAMPAIGN && canReviveInCampaign) {
                    RetroButton(
                        onClick = onRevive,
                        containerColor = NavyPrimary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("campaign_revive_button")
                    ) {
                        Text("💖 إحياء فرصة ثانية (مرة واحدة)", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    RetroButton(
                        onClick = onHome,
                        containerColor = RetroLightGray,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("dialog_home_button")
                    ) {
                        Text("القائمة 🏠", color = NavyPrimary, fontWeight = FontWeight.Bold)
                    }

                    RetroButton(
                        onClick = onRestart,
                        containerColor = NavyPrimary,
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("dialog_restart_button")
                    ) {
                        Text("إعادة 🔄", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = NavyPrimary.copy(alpha = 0.8f), fontSize = 13.sp)
        Text(text = value, color = NavyPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}
