package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.minesweeper.model.ChordingTrigger
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

@Composable
fun SettingsScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    var showResetConfirmDialog by remember { mutableStateOf(false) }
    val settings = uiState.settings

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RetroLightGray)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(RetroPanelGray)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = NavyPrimary
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "إعدادات اللعبة ⚙️",
                        color = NavyPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "تخصيص الصوت، الاهتزاز وطريقة الكشف",
                        color = NavyPrimary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Chording Settings Card
                RetroBeveledCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "طريقة كشف المربعات المحيطة (Chording)",
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "عندما يكون الرقم محاطاً بالأعلام الصحيحة، كشف الباقي تلقائياً",
                            color = NavyPrimary.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        ChordingTrigger.values().forEach { trigger ->
                            val isSelected = settings.chordingTrigger == trigger
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updateSettings(settings.copy(chordingTrigger = trigger))
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = {
                                        viewModel.updateSettings(settings.copy(chordingTrigger = trigger))
                                    },
                                    colors = RadioButtonDefaults.colors(selectedColor = NavyPrimary)
                                )
                                Column(modifier = Modifier.padding(start = 8.dp)) {
                                    Text(
                                        text = trigger.titleAr,
                                        color = if (isSelected) NavyPrimary else NavyPrimary.copy(alpha = 0.8f),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = trigger.description,
                                        color = NavyPrimary.copy(alpha = 0.6f),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        SettingsToggleRow(
                            title = "كورد تكراري (تتابعي) 🔄",
                            description = "استمرار الكشف التلقائي المتتابع للأرقام المكتملة",
                            checked = settings.repetitiveChording,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(repetitiveChording = it)) }
                        )

                        SettingsToggleRow(
                            title = "كورد عند الاستكشاف 🔍",
                            description = "تنفيذ كورد تلقائي فور نقر رقم تنطبق عليه الأعلام مسبقاً",
                            checked = settings.chordingOnReveal,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(chordingOnReveal = it)) }
                        )

                        SettingsToggleRow(
                            title = "كورد وضع الأعلام 🚩",
                            description = "وضع أعلام تلقائياً على جيران الرقم إذا تساوى المتبقي مع ألغامه المطلوبة",
                            checked = settings.flagChording,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(flagChording = it)) }
                        )

                        if (settings.noFlagMode) {
                            Text(
                                text = "⚠️ وضع بلا أعلام (NF) مفعّل: يتم تعطيل الكورد المعتمد على الأعلام.",
                                color = Color(0xFFC0392B),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }

                // Audio & Haptics Card
                RetroBeveledCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "الأصوات والتفاعل",
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )

                        SettingsToggleRow(
                            title = "تأثيرات الصوت 🔊",
                            description = "تشغيل أصوات النقر، الفوز والانفجار",
                            checked = settings.soundEffectsEnabled,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(soundEffectsEnabled = it)) }
                        )

                        SettingsToggleRow(
                            title = "الاهتزاز (Haptics) 📳",
                            description = "اهتزاز خفيف عند الكشف ووضع الأعلام",
                            checked = settings.hapticFeedbackEnabled,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(hapticFeedbackEnabled = it)) }
                        )

                        SettingsToggleRow(
                            title = "قفل التكبير افتراضياً 🔍",
                            description = "منع التكبير التلقائي عند بدء اللعبة",
                            checked = settings.lockZoomByDefault,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(lockZoomByDefault = it)) }
                        )

                        SettingsToggleRow(
                            title = "تفعيل علامات الاستفهام ❓",
                            description = "دورة التبديل: فارغ ← علم ← ؟",
                            checked = settings.questionMarksEnabled,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(questionMarksEnabled = it)) }
                        )

                        SettingsToggleRow(
                            title = "وضع بلا أعلام (NF Mode) 🚫",
                            description = "منع وضع الأعلام نهائياً",
                            checked = settings.noFlagMode,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(noFlagMode = it)) }
                        )

                        SettingsToggleRow(
                            title = "إظهار 3BV أثناء اللعب",
                            description = "إظهار قيمة 3BV في شاشة اللعب",
                            checked = settings.show3bvDuringGame,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(show3bvDuringGame = it)) }
                        )
                        
                        SettingsToggleRow(
                            title = "التمرير بالقصور الذاتي 📜",
                            description = "استمرار التمرير بعد رفع الإصبع",
                            checked = settings.inertiaScrolling,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(inertiaScrolling = it)) }
                        )

                        SettingsToggleRow(
                            title = "تأكيد بدء لعبة جديدة ⚠️",
                            description = "إظهار تنبيه قبل إعادة اللعبة",
                            checked = settings.confirmNewGame,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(confirmNewGame = it)) }
                        )

                        SettingsToggleRow(
                            title = "إيقاف المؤقت عند الخمول ⏸️",
                            description = "إيقاف المؤقت إذا كان التطبيق في الخلفية",
                            checked = settings.pauseTimerOnIdle,
                            onCheckedChange = { viewModel.updateSettings(settings.copy(pauseTimerOnIdle = it)) }
                        )

                        // Long Press Duration Slider
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "مدة الضغط المطوّل ⏱️",
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "${settings.longPressDurationMs} مللي ثانية",
                                    color = NavyPrimary.copy(alpha = 0.8f),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Slider(
                                value = settings.longPressDurationMs.toFloat().coerceIn(150f, 800f),
                                onValueChange = { raw ->
                                    val snapped = (Math.round(raw / 50f) * 50).coerceIn(150, 800)
                                    viewModel.updateSettings(settings.copy(longPressDurationMs = snapped))
                                },
                                valueRange = 150f..800f,
                                steps = 12,
                                colors = SliderDefaults.colors(
                                    thumbColor = NavyPrimary,
                                    activeTrackColor = NavyPrimary,
                                    inactiveTrackColor = NavyPrimary.copy(alpha = 0.2f)
                                )
                            )
                        }

                    }
                }

                // Themes & Customization shortcut
                RetroBeveledCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(ScreenState.THEMES) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Palette,
                                contentDescription = "الثيمات",
                                tint = NavyPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "اختيار الثيم والمظهر (12 ثيم)",
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "اختر بين النمط الكلاسيكي، الليلي، نيون، والمزيد",
                                    color = NavyPrimary.copy(alpha = 0.7f),
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Text("◀", color = NavyPrimary, fontSize = 16.sp)
                    }
                }

                // About / Info Card
                RetroBeveledCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "حول",
                            tint = NavyPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "صائد الألغام — إصدار احترافي",
                                color = NavyPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "لعبة ألغام كلاسيكية بنمط ريترو أصيل",
                                color = NavyPrimary.copy(alpha = 0.7f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Reset Settings to Defaults Button
                RetroButton(
                    onClick = { showResetConfirmDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("reset_settings_button"),
                    containerColor = Color(0xFFC0392B)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "إعادة ضبط",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إعادة ضبط الإعدادات الافتراضية",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }

        if (showResetConfirmDialog) {
            Dialog(onDismissRequest = { showResetConfirmDialog = false }) {
                RetroBeveledCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(RetroPanelGray)
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "تأكيد إعادة الضبط ⚠️",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = NavyPrimary
                        )
                        Text(
                            text = "هل أنت متأكد من إعادة جميع الإعدادات إلى قيمها الافتراضية؟",
                            fontSize = 13.sp,
                            color = NavyPrimary.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            RetroButton(
                                onClick = { showResetConfirmDialog = false },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                            ) {
                                Text("إلغاء", color = NavyPrimary, fontWeight = FontWeight.Bold)
                            }
                            RetroButton(
                                onClick = {
                                    showResetConfirmDialog = false
                                    viewModel.resetSettings()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp),
                                containerColor = Color(0xFFC0392B)
                            ) {
                                Text("تأكيد الضبط", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = NavyPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Text(
                text = description,
                color = NavyPrimary.copy(alpha = 0.7f),
                fontSize = 11.sp
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = NavyPrimary
            )
        )
    }
}
