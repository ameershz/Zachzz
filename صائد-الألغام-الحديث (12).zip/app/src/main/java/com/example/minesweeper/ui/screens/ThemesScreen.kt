package com.example.minesweeper.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.minesweeper.model.AvailableThemes
import com.example.minesweeper.model.MinesweeperTheme
import com.example.minesweeper.ui.components.drawFlag
import com.example.minesweeper.ui.components.drawMine
import com.example.minesweeper.viewmodel.GameUiState
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

@Composable
fun ThemesScreen(
    uiState: GameUiState,
    viewModel: MinesweeperViewModel
) {
    BackHandler {
        viewModel.navigateTo(ScreenState.HOME)
    }

    val currentSelectedTheme = uiState.currentTheme

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(RetroLightGray)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenState.HOME) },
                    modifier = Modifier.testTag("themes_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = NavyPrimary
                    )
                }

                Column {
                    Text(
                        text = "ثيمات ومظهر اللوحة 🎨",
                        color = NavyPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "12 ثيم بألوان كلاسيكية مقاسة — جميعها مفتوحة مجاناً",
                        color = NavyPrimary.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
            }

            // Hero Active Theme Preview Banner
            RetroBeveledCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(RetroPanelGray)
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الثيم الحالي: ${currentSelectedTheme.name}",
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF2E7D32), RoundedCornerShape(12.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("نشط ومطبق ✔", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 4-cell live preview row of active theme
                    Row(
                        modifier = Modifier
                            .background(currentSelectedTheme.floor, RoundedCornerShape(8.dp))
                            .border(3.dp, currentSelectedTheme.cellDark, RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeSampleCell(theme = currentSelectedTheme, type = SampleType.UNREVEALED, size = 42.dp)
                        ThemeSampleCell(theme = currentSelectedTheme, type = SampleType.FLAG, size = 42.dp)
                        ThemeSampleCell(theme = currentSelectedTheme, type = SampleType.NUMBER, size = 42.dp, number = 2)
                        ThemeSampleCell(theme = currentSelectedTheme, type = SampleType.MINE, size = 42.dp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // 12 Themes List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(AvailableThemes.allThemes) { theme ->
                    val isSelected = theme.id == currentSelectedTheme.id

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("theme_card_${theme.index}")
                            .clickable { viewModel.selectTheme(theme) }
                            .drawBehind {
                                val stroke = if (isSelected) 3.dp.toPx() else 2.dp.toPx()
                                val light = if (isSelected) NavyPrimary else RetroWhiteHighlight
                                val dark = if (isSelected) NavyPrimary else RetroDarkShadow
                                drawLine(light, Offset(0f, 0f), Offset(size.width, 0f), strokeWidth = stroke)
                                drawLine(light, Offset(0f, 0f), Offset(0f, size.height), strokeWidth = stroke)
                                drawLine(dark, Offset(size.width, 0f), Offset(size.width, size.height), strokeWidth = stroke)
                                drawLine(dark, Offset(0f, size.height), Offset(size.width, size.height), strokeWidth = stroke)
                            }
                            .background(if (isSelected) Color(0xFFE2E8F0) else RetroPanelGray)
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Left Column: Index & Name
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(
                                            if (isSelected) NavyPrimary else RetroDarkShadow,
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${theme.index}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                Column {
                                    Text(
                                        text = theme.name,
                                        color = NavyPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    if (isSelected) {
                                        Text(
                                            text = "مطبق حالياً ✔",
                                            color = Color(0xFF2E7D32),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            // Right: 4 mini sample squares (unrevealed, flag, number, mine)
                            Row(
                                modifier = Modifier
                                    .background(theme.floor, RoundedCornerShape(6.dp))
                                    .border(1.5.dp, theme.cellDark, RoundedCornerShape(6.dp))
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                ThemeSampleCell(theme = theme, type = SampleType.UNREVEALED, size = 26.dp)
                                ThemeSampleCell(theme = theme, type = SampleType.FLAG, size = 26.dp)
                                ThemeSampleCell(theme = theme, type = SampleType.NUMBER, size = 26.dp, number = 1)
                                ThemeSampleCell(theme = theme, type = SampleType.MINE, size = 26.dp)
                            }
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}

private enum class SampleType {
    UNREVEALED, FLAG, NUMBER, MINE
}

@Composable
private fun ThemeSampleCell(
    theme: MinesweeperTheme,
    type: SampleType,
    size: Dp,
    number: Int = 1
) {
    Canvas(modifier = Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val bevel = (w * 0.12f).coerceAtLeast(1f)

        when (type) {
            SampleType.UNREVEALED -> {
                drawSampleUnrevealed(theme, w, h, bevel)
            }
            SampleType.FLAG -> {
                drawSampleUnrevealed(theme, w, h, bevel)
                drawFlag(theme.flagColor, theme.flagStand, w, h)
            }
            SampleType.NUMBER -> {
                drawRect(color = theme.floor, topLeft = Offset.Zero, size = Size(w, h))
                val numColor = theme.numberColors.getOrElse(number - 1) { Color.Black }
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = numColor.hashCode()
                        textSize = h * 0.72f
                        isAntiAlias = true
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                        textAlign = android.graphics.Paint.Align.CENTER
                    }
                    val yPos = (h / 2) - ((paint.descent() + paint.ascent()) / 2)
                    drawText("$number", w / 2, yPos, paint)
                }
            }
            SampleType.MINE -> {
                drawRect(color = theme.floor, topLeft = Offset.Zero, size = Size(w, h))
                drawMine(theme.mineColor, w, h)
            }
        }
    }
}

private fun DrawScope.drawSampleUnrevealed(
    theme: MinesweeperTheme,
    w: Float,
    h: Float,
    bevel: Float
) {
    drawRect(color = theme.cellFace, topLeft = Offset.Zero, size = Size(w, h))
    // Light top/left
    drawRect(color = theme.cellLight, topLeft = Offset.Zero, size = Size(w, bevel))
    drawRect(color = theme.cellLight, topLeft = Offset.Zero, size = Size(bevel, h))
    // Dark bottom/right
    drawRect(color = theme.cellDark, topLeft = Offset(0f, h - bevel), size = Size(w, bevel))
    drawRect(color = theme.cellDark, topLeft = Offset(w - bevel, 0f), size = Size(bevel, h))
}
