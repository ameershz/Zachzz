package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
      primary = Color(0xFF1C2A39),
      secondary = Color(0xFF2E7D32),
      background = Color(0xFFC0C0C0),
      surface = Color(0xFFD6D6D6),
      onPrimary = Color.White,
      onSurface = Color(0xFF1C2A39)
  )

private val LightColorScheme =
  lightColorScheme(
      primary = Color(0xFF1C2A39),
      secondary = Color(0xFF2E7D32),
      background = Color(0xFFC0C0C0),
      surface = Color(0xFFD6D6D6),
      onPrimary = Color.White,
      onSurface = Color(0xFF1C2A39)
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
