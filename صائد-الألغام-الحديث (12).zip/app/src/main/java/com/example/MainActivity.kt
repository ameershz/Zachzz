package com.example

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.minesweeper.ui.screens.CampaignScreen
import com.example.minesweeper.ui.screens.GameScreen
import com.example.minesweeper.ui.screens.HomeScreen
import com.example.minesweeper.ui.screens.SettingsScreen
import com.example.minesweeper.ui.screens.StatsScreen
import com.example.minesweeper.ui.screens.ThemesScreen
import com.example.minesweeper.ui.screens.TournamentsScreen
import com.example.minesweeper.viewmodel.MinesweeperViewModel
import com.example.minesweeper.viewmodel.ScreenState

class MainActivity : ComponentActivity() {

    private val viewModel: MinesweeperViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            // RTL Layout direction for complete Arabic support
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = Color(0xFF1C2A39),
                        secondary = Color(0xFF2E7D32),
                        background = Color(0xFFC0C0C0),
                        surface = Color(0xFFD6D6D6)
                    )
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = Color(0xFFC0C0C0)
                    ) {
                        when (uiState.currentScreen) {
                            ScreenState.HOME -> HomeScreen(uiState = uiState, viewModel = viewModel)
                            ScreenState.GAME -> GameScreen(uiState = uiState, viewModel = viewModel)
                            ScreenState.CAMPAIGN -> CampaignScreen(uiState = uiState, viewModel = viewModel)
                            ScreenState.TOURNAMENTS -> TournamentsScreen(viewModel = viewModel)
                            ScreenState.THEMES -> ThemesScreen(uiState = uiState, viewModel = viewModel)
                            ScreenState.STATS -> StatsScreen(uiState = uiState, viewModel = viewModel)
                            ScreenState.SETTINGS -> SettingsScreen(uiState = uiState, viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.onActivityPause()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (viewModel.isVolumeKeyToggleEnabled() && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            viewModel.toggleFlagMode()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
