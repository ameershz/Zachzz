package com.example.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.manager.AiCoreEngine
import com.example.core.manager.EngineBenchmark
import com.example.core.modules.InferenceResponse
import com.example.core.modules.ModelStats
import com.example.core.modules.ModuleType
import com.example.core.training.TrainingProgress
import com.example.data.AppDatabase
import com.example.data.NeuralCoreRepository
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.KnowledgeDocEntity
import com.example.data.entity.ModelCheckpointEntity
import com.example.data.entity.TrainingSampleEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray

class NeuralCoreViewModel(application: Application) : AndroidViewModel(application) {

    val engine = AiCoreEngine()
    private val database = AppDatabase.getInstance(application)
    val repository = NeuralCoreRepository(database)

    val activeModuleType: StateFlow<ModuleType> = engine.activeModuleType

    val chatMessages: StateFlow<List<ChatMessageEntity>> = repository.chatMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val knowledgeDocuments: StateFlow<List<KnowledgeDocEntity>> = repository.knowledgeDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trainingSamples: StateFlow<List<TrainingSampleEntity>> = activeModuleType
        .flatMapLatest { module -> repository.getTrainingSamples(module.name) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val checkpoints: StateFlow<List<ModelCheckpointEntity>> = activeModuleType
        .flatMapLatest { module -> repository.getCheckpoints(module.name) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val trainingProgress: StateFlow<TrainingProgress> = engine.fineTuner.progress
    val bulkImportProgress: StateFlow<com.example.core.importer.BulkImportProgress> = engine.bulkImporter.progress

    private val _isInferring = MutableStateFlow(false)
    val isInferring: StateFlow<Boolean> = _isInferring.asStateFlow()

    private val _modelStats = MutableStateFlow(engine.getStats())
    val modelStats: StateFlow<ModelStats> = _modelStats.asStateFlow()

    private val _engineBenchmark = MutableStateFlow<EngineBenchmark?>(null)
    val engineBenchmark: StateFlow<EngineBenchmark?> = _engineBenchmark.asStateFlow()

    // Configurable Inference Hyper-parameters
    var temperature: Float = 0.7f
    var topK: Int = 5
    var learningRate: Float = 0.008f
    var targetEpochs: Int = 25

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty { text ->
                engine.semanticRag.computeEmbedding(text).data.clone()
            }
            refreshStats()
        }
    }

    fun switchModule(type: ModuleType) {
        engine.switchModule(type)
        refreshStats()
    }

    fun refreshStats() {
        _modelStats.value = engine.getStats()
    }

    fun sendPrompt(prompt: String) {
        if (prompt.isBlank() || _isInferring.value) return

        viewModelScope.launch {
            _isInferring.value = true
            try {
                // Collect knowledge documents content to inject as local RAG context
                val docs = knowledgeDocuments.value.map { it.rawContent }
                val response: InferenceResponse = engine.executeInference(
                    prompt = prompt,
                    temperature = temperature,
                    topK = topK,
                    contextDocs = docs
                )

                val reasoningJson = JSONArray(response.reasoningChain).toString()
                val chatEntity = ChatMessageEntity(
                    prompt = prompt.trim(),
                    response = response.outputText,
                    reasoningChainJson = reasoningJson,
                    moduleType = engine.activeModuleType.value.name,
                    latencyMs = response.latencyMs,
                    tokensGenerated = response.tokensGenerated,
                    tokensPerSecond = response.tokensPerSecond,
                    confidence = response.confidence
                )
                repository.saveMessage(chatEntity)
                refreshStats()
            } finally {
                _isInferring.value = false
            }
        }
    }

    fun startTraining() {
        if (trainingProgress.value.isRunning) return

        viewModelScope.launch {
            val samples = trainingSamples.value.map { it.inputPrompt to it.targetOutput }
            if (samples.isEmpty()) return@launch

            val active = engine.getActiveModule()
            engine.fineTuner.train(
                module = active,
                dataset = samples,
                epochs = targetEpochs,
                learningRate = learningRate,
                onEpochEnd = { _, _ ->
                    refreshStats()
                }
            )
            refreshStats()
        }
    }

    fun stopTraining() {
        engine.fineTuner.stop()
    }

    fun addTrainingSample(input: String, target: String) {
        if (input.isBlank() || target.isBlank()) return
        viewModelScope.launch {
            repository.addTrainingSample(activeModuleType.value.name, input.trim(), target.trim())
        }
    }

    fun deleteTrainingSample(id: Long) {
        viewModelScope.launch {
            repository.deleteTrainingSample(id)
        }
    }

    fun addKnowledgeDocument(title: String, content: String) {
        if (title.isBlank() || content.isBlank()) return
        viewModelScope.launch {
            val vector = engine.semanticRag.computeEmbedding(content).data.clone()
            repository.saveDocument(title.trim(), content.trim(), vector)
        }
    }

    fun deleteKnowledgeDocument(id: Long) {
        viewModelScope.launch {
            repository.deleteDocument(id)
        }
    }

    fun createCheckpoint(versionTag: String) {
        viewModelScope.launch {
            val active = engine.getActiveModule()
            val serialized = active.exportWeights()
            val stats = active.getStats()
            val checkpoint = ModelCheckpointEntity(
                moduleType = active.type.name,
                versionTag = versionTag.ifBlank { "v1.0-${System.currentTimeMillis() % 1000}" },
                serializedWeightsJson = serialized,
                parameterCount = stats.parameterCount,
                epochsTrained = stats.trainedEpochs,
                recordedLoss = stats.averageLoss,
                isActive = true
            )
            repository.saveCheckpoint(checkpoint)
        }
    }

    fun restoreCheckpoint(checkpoint: ModelCheckpointEntity) {
        viewModelScope.launch {
            val active = engine.getActiveModule()
            active.importWeights(checkpoint.serializedWeightsJson)
            refreshStats()
        }
    }

    fun deleteCheckpoint(id: Long) {
        viewModelScope.launch {
            repository.deleteCheckpoint(id)
        }
    }

    fun resetWeights() {
        engine.getActiveModule().resetWeights()
        refreshStats()
    }

    fun runBenchmark() {
        viewModelScope.launch {
            _engineBenchmark.value = engine.runBenchmark()
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    // --- Bulk Dataset & Document Importer Operations ---

    fun readUriContent(uri: Uri): Pair<String, String>? {
        return try {
            val contentResolver = getApplication<Application>().contentResolver
            var displayName = "imported_file"
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    displayName = cursor.getString(nameIndex)
                }
            }
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            displayName to text
        } catch (_: Exception) {
            null
        }
    }

    fun importFineTuningDataset(uri: Uri, runTraining: Boolean = true) {
        viewModelScope.launch {
            val fileData = readUriContent(uri) ?: return@launch
            val (name, text) = fileData
            val isCsv = name.endsWith(".csv", true)
            importFineTuningContent(text, if (isCsv) "csv" else "jsonl", runTraining)
        }
    }

    fun importFineTuningContent(content: String, format: String, runTraining: Boolean = true) {
        viewModelScope.launch {
            val pairs = if (format.equals("csv", true)) {
                engine.bulkImporter.parseCsv(content)
            } else {
                engine.bulkImporter.parseJsonl(content)
            }

            if (pairs.isEmpty()) return@launch

            val activeType = activeModuleType.value.name
            val sampleEntities = pairs.map { (p, t) ->
                TrainingSampleEntity(
                    moduleType = activeType,
                    inputPrompt = p,
                    targetOutput = t
                )
            }
            repository.saveTrainingSamples(sampleEntities)

            if (runTraining) {
                engine.bulkImporter.executeStreamingTraining(
                    module = engine.getActiveModule(),
                    dataset = pairs,
                    epochs = targetEpochs,
                    learningRate = learningRate
                )
            }
            refreshStats()
        }
    }

    fun importRagDocument(uri: Uri) {
        viewModelScope.launch {
            val fileData = readUriContent(uri) ?: return@launch
            val (name, text) = fileData
            importRagContent(name, text)
        }
    }

    fun importRagContent(title: String, content: String) {
        viewModelScope.launch {
            if (content.isBlank()) return@launch
            val docEntities = engine.bulkImporter.ingestDocumentChunks(
                rawTitle = title.ifBlank { "Imported Document" },
                rawText = content
            )
            repository.saveDocuments(docEntities)
        }
    }

    fun startRawTextPretraining(uri: Uri, epochs: Int = 2) {
        viewModelScope.launch {
            val fileData = readUriContent(uri) ?: return@launch
            val (_, text) = fileData
            startRawTextPretrainingContent(text, epochs)
        }
    }

    fun startRawTextPretrainingContent(text: String, epochs: Int = 2) {
        viewModelScope.launch {
            if (text.isBlank()) return@launch
            engine.bulkImporter.executeRawTextPretraining(
                module = engine.getActiveModule(),
                rawText = text,
                epochs = epochs,
                learningRate = learningRate
            )
            refreshStats()
        }
    }

    fun stopBulkOperation() {
        engine.bulkImporter.stop()
        engine.fineTuner.stop()
    }
}
