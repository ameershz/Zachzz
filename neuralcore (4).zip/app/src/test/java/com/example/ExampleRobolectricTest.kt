package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.modules.SemanticRagModule
import com.example.core.tensor.ArabicBpeTokenizer
import com.example.core.tensor.Tensor
import com.example.core.tensor.Tokenizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("NeuralCore", appName)
  }

  @Test
  fun `tensor matrix multiplication is mathematically sound`() {
    val a = Tensor(2, 2, floatArrayOf(1f, 2f, 3f, 4f))
    val b = Tensor(2, 2, floatArrayOf(2f, 0f, 1f, 2f))
    val c = a.matmul(b)

    assertEquals(4f, c[0, 0], 1e-5f)
    assertEquals(4f, c[0, 1], 1e-5f)
    assertEquals(10f, c[1, 0], 1e-5f)
    assertEquals(8f, c[1, 1], 1e-5f)
  }

  @Test
  fun `tokenizer encodes and decodes correctly`() {
    val tokenizer = Tokenizer()
    val encoded = tokenizer.encode("neural core active")
    assertTrue(encoded.isNotEmpty())
    val decoded = tokenizer.decode(encoded)
    assertTrue(decoded.contains("neural"))
  }

  @Test
  fun `arabic text detection and normalization work reliably`() {
    assertTrue(Tokenizer.isArabic("الذكاء الاصطناعي"))
    assertTrue(Tokenizer.isArabic("مرحبا"))
    assertFalse(Tokenizer.isArabic("Hello world 123"))

    val withTashkeel = "ذَكَاءٌ"
    val withoutTashkeel = "ذكاء"
    assertEquals(Tokenizer.normalizeArabic(withTashkeel), Tokenizer.normalizeArabic(withoutTashkeel))
  }

  @Test
  fun `arabic text is encoded and decoded without unknown tokens`() {
    val tokenizer = Tokenizer()
    val arabicInput = "النواة العصبية تعمل بكفاءة عالية على الهاتف"
    val encoded = tokenizer.encode(arabicInput, autoLearn = true)

    // Ensure none of the tokens mapped to UNK_ID (1)
    for (id in encoded) {
      assertTrue("Token should not be UNK_ID", id != Tokenizer.UNK_ID)
    }

    val decoded = tokenizer.decode(encoded)
    assertTrue(decoded.contains("النواة") || decoded.contains("العصبية"))
  }

  @Test
  fun `arabic semantic vector embedding generates valid normalized tensor`() {
    val tokenizer = ArabicBpeTokenizer()
    val semanticModule = SemanticRagModule(embeddingDim = 32, tokenizer = tokenizer)
    val embedding = semanticModule.computeEmbedding("حالة النظام المحلي والخصوصية بدون إنترنت")

    assertEquals(1, embedding.rows)
    assertEquals(32, embedding.cols)
    // Unit norm check
    assertEquals(1.0f, embedding.l2Norm(), 1e-3f)
  }
}
