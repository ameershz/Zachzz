package com.example

import com.example.core.modules.InferenceRequest
import com.example.core.modules.ScaledTransformerModule
import com.example.core.modules.SemanticRagModule
import com.example.core.tensor.ArabicBpeTokenizer
import com.example.core.tensor.NativeNeonBridge
import com.example.core.tensor.Tensor
import com.example.core.training.ContextInjector
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class ExampleUnitTest {

    @Test
    fun testArabicBpeTokenizerMorphology() {
        val tokenizer = ArabicBpeTokenizer()

        // Test Arabic prefix/suffix extraction
        val segments = tokenizer.segmentArabicWord("بالبيانات")
        assertTrue("Segments should break prefix 'بال'", segments.contains("بال") || segments.contains("ال"))

        // Test encoding and decoding
        val text = "الذكاء الاصطناعي في هاتفك يعمل بأمان"
        val ids = tokenizer.encode(text)
        assertTrue(ids.isNotEmpty())
        for (id in ids) {
            assertNotEquals("Should not contain unknown token", ArabicBpeTokenizer.UNK_ID, id)
        }

        val decoded = tokenizer.decode(ids)
        assertTrue(decoded.contains("الذكاء") || decoded.contains("ذكاء"))
    }

    @Test
    fun testRagSimilarityThresholdFilter() {
        val semanticModule = SemanticRagModule()
        val injector = ContextInjector(semanticModule)

        // Query about AI
        val query = "الذكاء الاصطناعي والمعالجة العصبية"

        // Candidate documents: one relevant, one completely irrelevant
        val relevantDoc = "بنية نواة الذكاء الاصطناعي تدعم عمليات مصفوفات التنسور السريعة على معالج الهاتف"
        val irrelevantDoc = "وصفة كعكة الشوكولاتة اللذيذة بالسكر والكاكاو في الفرن"

        val relevantEmb = injector.embedText(relevantDoc)
        val irrelevantEmb = injector.embedText(irrelevantDoc)

        val items = listOf(
            Triple(1L, relevantDoc, relevantEmb),
            Triple(2L, irrelevantDoc, irrelevantEmb)
        )

        val filtered = runBlocking {
            injector.retrieveRelevant(query, items, topK = 3, threshold = 0.55f)
        }

        // Must strictly reject any document below 0.55 (55%)
        for (item in filtered) {
            assertTrue("Similarity must be >= 0.55", item.similarityScore >= 0.55f)
            assertFalse("Irrelevant doc must be filtered out", item.content.contains("كعكة الشوكولاتة"))
        }
    }

    @Test
    fun testRepetitionPenaltySuppression() {
        val logits = Tensor(1, 10, FloatArray(10) { 2.0f })
        val history = listOf(3, 3, 3) // Token 3 repeated multiple times
        val blocked = setOf(3)

        val sampled = logits.sampleWithRepetitionPenalty(
            k = 10,
            temperature = 0.7f,
            repetitionPenalty = 1.5f,
            generatedTokensHistory = history,
            blockedTokens = blocked,
            random = Random(42)
        )

        assertNotEquals("Repeated/blocked token must not be sampled", 3, sampled)
    }

    @Test
    fun testScaledTransformerArchitectureParameters() {
        val scaledModule = ScaledTransformerModule(
            dModel = 128,
            dFf = 512,
            numLayers = 4,
            maxSeqLen = 128
        )

        val paramCount = scaledModule.calculateTotalParameters()
        // Must be greater than 1 million parameters
        assertTrue("Parameter count should be scaled > 1,000,000, got: $paramCount", paramCount >= 1_000_000)
    }

    @Test
    fun testNeonAcceleratedMatmulMath() {
        val a = floatArrayOf(
            1f, 2f,
            3f, 4f
        )
        val b = floatArrayOf(
            2f, 0f,
            1f, 2f
        )
        // Expected: [1*2 + 2*1, 1*0 + 2*2] = [4, 4]
        //           [3*2 + 4*1, 3*0 + 4*2] = [10, 8]
        val c = NativeNeonBridge.acceleratedMatmul(a, b, 2, 2, 2)
        assertEquals(4f, c[0], 1e-4f)
        assertEquals(4f, c[1], 1e-4f)
        assertEquals(10f, c[2], 1e-4f)
        assertEquals(8f, c[3], 1e-4f)
    }

    @Test
    fun testBulkJsonlParsing() {
        val semanticModule = SemanticRagModule()
        val injector = ContextInjector(semanticModule)
        val importer = com.example.core.importer.BulkDatasetImporter(semanticModule, injector)

        val jsonl = """
            {"prompt": "ما هو الذكاء المحلي؟", "target": "محرك تنسور يعمل على معالج الهاتف"}
            {"input": "system status", "output": "optimal local"}
            malformed row that should be ignored
            {"instruction": "explain neon", "response": "ARM SIMD vector math"}
        """.trimIndent()

        val parsed = importer.parseJsonl(jsonl)
        assertEquals(3, parsed.size)
        assertEquals("ما هو الذكاء المحلي؟", parsed[0].first)
        assertEquals("محرك تنسور يعمل على معالج الهاتف", parsed[0].second)
        assertEquals("system status", parsed[1].first)
        assertEquals("optimal local", parsed[1].second)
    }

    @Test
    fun testBulkCsvParsing() {
        val semanticModule = SemanticRagModule()
        val injector = ContextInjector(semanticModule)
        val importer = com.example.core.importer.BulkDatasetImporter(semanticModule, injector)

        val csv = """
            prompt,target
            "query 1","result 1"
            "query 2","result 2"
        """.trimIndent()

        val parsed = importer.parseCsv(csv)
        assertEquals(2, parsed.size)
        assertEquals("query 1", parsed[0].first)
        assertEquals("result 1", parsed[0].second)
    }

    @Test
    fun testRawTextPretrainPairExtraction() {
        val semanticModule = SemanticRagModule()
        val injector = ContextInjector(semanticModule)
        val importer = com.example.core.importer.BulkDatasetImporter(semanticModule, injector)

        val rawText = "تعمل النواة العصبية على معالجة البيانات المعقدة بكفاءة عالية وبدون إنترنت."
        val pairs = importer.extractRawTextPretrainPairs(rawText, windowSize = 4, stride = 1)
        assertTrue("Should extract causal language modeling pairs", pairs.isNotEmpty())
    }

    @Test
    fun testBulkDocumentChunking() {
        val semanticModule = SemanticRagModule()
        val injector = ContextInjector(semanticModule)
        val importer = com.example.core.importer.BulkDatasetImporter(semanticModule, injector)

        val longMarkdown = (1..50).joinToString(" ") { "المعالجة العصبية المحلية رقم $it" }
        val entities = runBlocking {
            importer.ingestDocumentChunks("Manual.md", longMarkdown, chunkSize = 20, overlap = 5)
        }
        assertTrue("Should produce multiple semantic chunks", entities.size > 1)
        assertTrue("Chunk vectors should be non-empty", entities[0].embeddingVectorStr.isNotBlank())
    }

    @Test
    fun testNoRawTokenIdsInDecode() {
        val tokenizer = ArabicBpeTokenizer()
        // Test decoding sequence with arbitrarily high token IDs like 1710, 2199
        val tokenIds = intArrayOf(1710, 2199, 12, 45, 100)
        val decoded = tokenizer.decode(tokenIds)

        assertFalse("Decoded text should never contain raw [tok_N] placeholder", decoded.contains("[tok_"))
        assertTrue("Decoded text should be non-empty", decoded.isNotBlank())
    }

    @Test
    fun testAdaptiveLearningRateScheduler() {
        val baseLr = 0.008f
        val totalEpochs = 25

        // Epoch 1 (Warmup)
        val lr1 = com.example.core.training.LocalFineTuner.computeScheduledLearningRate(baseLr, 1, totalEpochs)
        // Epoch 3 (End of Warmup)
        val lr3 = com.example.core.training.LocalFineTuner.computeScheduledLearningRate(baseLr, 3, totalEpochs)
        // Epoch 25 (End of Cosine Decay)
        val lr25 = com.example.core.training.LocalFineTuner.computeScheduledLearningRate(baseLr, 25, totalEpochs)

        assertTrue("Warmup should start lower than peak baseLr", lr1 < lr3)
        assertTrue("Cosine decay at final epoch should reach lower rate", lr25 < lr3)
        assertTrue("LR should remain strictly positive", lr25 > 0f)
    }
}
