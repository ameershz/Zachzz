package com.example

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.NeuralCoreViewModel
import com.example.ui.screens.ConsoleScreen
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.KnowledgeScreen
import com.example.ui.screens.ModelsScreen
import com.example.ui.screens.TrainingScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextTertiary

enum class AppTab(val label: String, val labelAr: String, val icon: ImageVector) {
    CONSOLE("Console", "الطرفية", Icons.Default.Terminal),
    MODELS("Models", "النماذج", Icons.Default.Layers),
    TRAINING("Training", "التدريب", Icons.Default.FitnessCenter),
    KNOWLEDGE("Knowledge", "المعرفة", Icons.Default.Hub),
    DIAGNOSTICS("Diagnostics", "التشخيص", Icons.Default.Assessment)
}

@Composable
fun NeuralCoreApp(
    viewModel: NeuralCoreViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by rememberSaveable { mutableStateOf(AppTab.CONSOLE) }

    // Intercept back button to return to Console if on another tab
    BackHandler(enabled = selectedTab != AppTab.CONSOLE) {
        selectedTab = AppTab.CONSOLE
    }

    val activeType by viewModel.activeModuleType.collectAsStateWithLifecycle()
    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val trainingSamples by viewModel.trainingSamples.collectAsStateWithLifecycle()
    val knowledgeDocs by viewModel.knowledgeDocuments.collectAsStateWithLifecycle()
    val checkpoints by viewModel.checkpoints.collectAsStateWithLifecycle()
    val stats by viewModel.modelStats.collectAsStateWithLifecycle()
    val progress by viewModel.trainingProgress.collectAsStateWithLifecycle()
    val isInferring by viewModel.isInferring.collectAsStateWithLifecycle()
    val benchmark by viewModel.engineBenchmark.collectAsStateWithLifecycle()

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(SurfaceDark)) {
        val isWideScreen = maxWidth > 600.dp

        if (isWideScreen) {
            // Adaptive Tablet / Foldable layout with NavigationRail
            Row(modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
                NavigationRail(
                    containerColor = SurfaceCard,
                    contentColor = TextPrimary,
                    modifier = Modifier.fillMaxHeight()
                ) {
                    AppTab.values().forEach { tab ->
                        val selected = selectedTab == tab
                        NavigationRailItem(
                            selected = selected,
                            onClick = { selectedTab = tab },
                            icon = { Icon(imageVector = tab.icon, contentDescription = tab.label) },
                            label = { Text(text = tab.label, fontSize = 10.sp) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = CyberCyan,
                                selectedTextColor = CyberCyan,
                                indicatorColor = CyberCyan.copy(alpha = 0.2f),
                                unselectedIconColor = TextTertiary,
                                unselectedTextColor = TextTertiary
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    ScreenContent(
                        tab = selectedTab,
                        viewModel = viewModel,
                        activeType = activeType,
                        messages = messages,
                        trainingSamples = trainingSamples,
                        knowledgeDocs = knowledgeDocs,
                        checkpoints = checkpoints,
                        stats = stats,
                        progress = progress,
                        isInferring = isInferring,
                        benchmark = benchmark
                    )
                }
            }
        } else {
            // Phone Portrait layout with Bottom NavigationBar
            Scaffold(
                containerColor = SurfaceDark,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    NavigationBar(
                        containerColor = SurfaceCard,
                        tonalElevation = 6.dp,
                        modifier = Modifier
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .testTag("main_navigation_bar")
                    ) {
                        AppTab.values().forEach { tab ->
                            val selected = selectedTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = { Icon(imageVector = tab.icon, contentDescription = tab.label) },
                                label = { Text(text = tab.label, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberCyan.copy(alpha = 0.2f),
                                    unselectedIconColor = TextTertiary,
                                    unselectedTextColor = TextTertiary
                                ),
                                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    ScreenContent(
                        tab = selectedTab,
                        viewModel = viewModel,
                        activeType = activeType,
                        messages = messages,
                        trainingSamples = trainingSamples,
                        knowledgeDocs = knowledgeDocs,
                        checkpoints = checkpoints,
                        stats = stats,
                        progress = progress,
                        isInferring = isInferring,
                        benchmark = benchmark
                    )
                }
            }
        }
    }
}

@Composable
private fun ScreenContent(
    tab: AppTab,
    viewModel: NeuralCoreViewModel,
    activeType: com.example.core.modules.ModuleType,
    messages: List<com.example.data.entity.ChatMessageEntity>,
    trainingSamples: List<com.example.data.entity.TrainingSampleEntity>,
    knowledgeDocs: List<com.example.data.entity.KnowledgeDocEntity>,
    checkpoints: List<com.example.data.entity.ModelCheckpointEntity>,
    stats: com.example.core.modules.ModelStats,
    progress: com.example.core.training.TrainingProgress,
    isInferring: Boolean,
    benchmark: com.example.core.manager.EngineBenchmark?
) {
    when (tab) {
        AppTab.CONSOLE -> ConsoleScreen(
            viewModel = viewModel,
            messages = messages,
            activeModuleType = activeType,
            isInferring = isInferring
        )
        AppTab.MODELS -> ModelsScreen(
            viewModel = viewModel,
            activeType = activeType,
            stats = stats,
            checkpoints = checkpoints
        )
        AppTab.TRAINING -> TrainingScreen(
            viewModel = viewModel,
            activeType = activeType,
            progress = progress,
            samples = trainingSamples
        )
        AppTab.KNOWLEDGE -> KnowledgeScreen(
            viewModel = viewModel,
            documents = knowledgeDocs
        )
        AppTab.DIAGNOSTICS -> DiagnosticsScreen(
            viewModel = viewModel,
            benchmark = benchmark
        )
    }
}
