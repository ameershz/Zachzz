package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.modules.ModuleType
import com.example.core.tensor.Tokenizer
import com.example.data.entity.ChatMessageEntity
import com.example.ui.NeuralCoreViewModel
import com.example.ui.components.NeuralHeader
import com.example.ui.components.StatChip
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeuralViolet
import com.example.ui.theme.PulseAmber
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import org.json.JSONArray

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConsoleScreen(
    viewModel: NeuralCoreViewModel,
    messages: List<ChatMessageEntity>,
    activeModuleType: ModuleType,
    isInferring: Boolean,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    var isArabicMode by rememberSaveable { mutableStateOf(false) }
    val listState = rememberLazyListState()

    // Dynamic RTL detection based on current input text or explicit toggle
    val isCurrentInputArabic = remember(inputText, isArabicMode) {
        isArabicMode || Tokenizer.isArabic(inputText)
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
            .imePadding()
    ) {
        val moduleDisplayName = if (isArabicMode) activeModuleType.titleAr else activeModuleType.title
        NeuralHeader(
            activeModuleName = moduleDisplayName,
            isArabic = isArabicMode
        )

        // Subheader with Quick Status, Language Toggle & Clear
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatChip(
                    label = if (isArabicMode) "النمط" else "MODE",
                    value = if (isArabicMode) activeModuleType.badgeAr else activeModuleType.badge
                )
                Spacer(modifier = Modifier.width(6.dp))
                StatChip(
                    label = if (isArabicMode) "المعاملات" else "PARAMS",
                    value = "${activeModuleType.defaultParametersCount / 1000}K",
                    color = NeuralViolet
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Arabic / English Language Toggle Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isArabicMode) CyberCyan.copy(alpha = 0.2f) else SurfaceElevated)
                        .border(1.dp, if (isArabicMode) CyberCyan else SurfaceBorder, RoundedCornerShape(12.dp))
                        .clickable { isArabicMode = !isArabicMode }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("language_toggle_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "Toggle Language",
                            tint = if (isArabicMode) CyberCyan else TextTertiary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isArabicMode) "عربي" else "EN",
                            color = if (isArabicMode) CyberCyan else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (messages.isNotEmpty()) {
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = { viewModel.clearChatHistory() },
                        modifier = Modifier.size(32.dp).testTag("clear_history_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear History",
                            tint = TextTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Messages list
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (messages.isEmpty()) {
                EmptyConsolePlaceholder(
                    activeType = activeModuleType,
                    isArabicMode = isArabicMode,
                    onPromptSelect = { preset -> inputText = preset }
                )
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        ChatMessageItem(message = msg)
                    }
                    if (isInferring) {
                        item {
                            InferringLoadingIndicator(
                                activeType = activeModuleType,
                                isArabic = isArabicMode || isCurrentInputArabic
                            )
                        }
                    }
                }
            }
        }

        // Quick suggestions row (English & Arabic presets)
        val quickPrompts = if (isArabicMode) {
            when (activeModuleType) {
                ModuleType.TEXT_TRANSFORMER -> listOf("حالة النظام المحلي", "الذكاء الاصطناعي على الهاتف", "كيف يعمل التنسور العصبي؟")
                ModuleType.SEMANTIC_RAG -> listOf("كيف يحمي النظام الخصوصية؟", "ما هي متطلبات المعالجة المحلية؟", "ملخص بنية النواة العصبية")
                ModuleType.REASONING_ENGINE -> listOf("هل المعالجة المحلية آمنة وخاصة بالكامل؟", "هل التدريب المحلي يغير أوزان النموذج؟", "هل يعمل الذكاء بدون إنترنت؟")
                ModuleType.PATTERN_CLASSIFIER -> listOf("اشرح بنية النظام العصبي", "ابدأ تدريب أوزان النموذج المحلي", "تنبيه أمني محلي")
            }
        } else {
            when (activeModuleType) {
                ModuleType.TEXT_TRANSFORMER -> listOf("neural core status", "حالة النظام المحلي", "local ai performance")
                ModuleType.SEMANTIC_RAG -> listOf("How does NeuralCore protect privacy?", "كيف يحمي النظام الخصوصية؟", "Summarize local architecture")
                ModuleType.REASONING_ENGINE -> listOf("Is on-device inference completely private?", "هل المعالجة المحلية آمنة وخاصة؟", "Does tensor backprop alter weights?")
                ModuleType.PATTERN_CLASSIFIER -> listOf("explain system architecture", "اشرح بنية النظام", "start training epoch with learning rate 0.01")
            }
        }

        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickPrompts.take(3).forEach { prompt ->
                val promptArabic = Tokenizer.isArabic(prompt)
                CompositionLocalProvider(LocalLayoutDirection provides if (promptArabic) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceCard)
                            .border(0.5.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                            .clickable { inputText = prompt }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = if (promptArabic) prompt else "» $prompt",
                            color = CyberCyan.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            fontFamily = if (promptArabic) FontFamily.Default else FontFamily.Monospace,
                            textAlign = if (promptArabic) TextAlign.Right else TextAlign.Left
                        )
                    }
                }
            }
        }

        // Input Bar with RTL Layout Provider
        Surface(
            color = SurfaceCard,
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CompositionLocalProvider(
                    LocalLayoutDirection provides if (isCurrentInputArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                text = if (isCurrentInputArabic) "اكتب استعلامك للنواة العصبية..." else "Execute ${activeModuleType.title} prompt...",
                                color = TextTertiary,
                                fontSize = 13.sp,
                                textAlign = if (isCurrentInputArabic) TextAlign.Right else TextAlign.Left
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("prompt_input_field"),
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = SurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = SurfaceDark,
                            unfocusedContainerColor = SurfaceDark
                        ),
                        maxLines = 3,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 13.sp,
                            textAlign = if (isCurrentInputArabic) TextAlign.Right else TextAlign.Left
                        )
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(
                            if (inputText.isNotBlank() && !isInferring) {
                                Brush.linearGradient(listOf(CyberCyan, NeuralViolet))
                            } else {
                                Brush.linearGradient(listOf(SurfaceElevated, SurfaceBorder))
                            }
                        )
                        .clickable(enabled = inputText.isNotBlank() && !isInferring) {
                            val text = inputText
                            inputText = ""
                            viewModel.sendPrompt(text)
                        }
                        .testTag("send_prompt_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isInferring) {
                        CircularProgressIndicator(
                            color = CyberCyan,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(20.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Run Inference",
                            tint = if (inputText.isNotBlank()) MaterialTheme.colorScheme.onPrimary else TextTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageItem(message: ChatMessageEntity) {
    var expandedReasoning by remember { mutableStateOf(false) }

    val isPromptArabic = remember(message.prompt) { Tokenizer.isArabic(message.prompt) }
    val isResponseArabic = remember(message.response) { Tokenizer.isArabic(message.response) }

    val reasoningList = remember(message.reasoningChainJson) {
        try {
            val arr = JSONArray(message.reasoningChainJson)
            List(arr.length()) { i -> arr.getString(i) }
        } catch (_: Exception) {
            emptyList<String>()
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        // User Query Bubble with RTL support
        CompositionLocalProvider(
            LocalLayoutDirection provides if (isPromptArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = if (isPromptArabic) Arrangement.Start else Arrangement.End
            ) {
                Box(
                    modifier = Modifier
                        .clip(
                            if (isPromptArabic) {
                                RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
                            } else {
                                RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
                            }
                        )
                        .background(SurfaceElevated)
                        .border(
                            1.dp, SurfaceBorder,
                            if (isPromptArabic) {
                                RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
                            } else {
                                RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
                            }
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = message.prompt,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = if (isPromptArabic) TextAlign.Right else TextAlign.Left
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // AI Core Response Card with RTL support
        CompositionLocalProvider(
            LocalLayoutDirection provides if (isResponseArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp))
                    .background(SurfaceCard)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp))
                    .padding(14.dp)
            ) {
                Column {
                    // Telemetry Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = message.moduleType.replace("_", " "),
                                color = CyberCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = null,
                                tint = TextTertiary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "${message.latencyMs}ms",
                                color = TextTertiary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "${"%.1f".format(message.tokensPerSecond)} tok/s",
                                color = NeonEmerald,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Model Text Output with native text alignment
                    Text(
                        text = message.response,
                        color = TextPrimary,
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        fontFamily = if (isResponseArabic) FontFamily.Default else if (message.moduleType == ModuleType.REASONING_ENGINE.name || message.moduleType == ModuleType.PATTERN_CLASSIFIER.name) FontFamily.Monospace else FontFamily.Default,
                        textAlign = if (isResponseArabic) TextAlign.Right else TextAlign.Left
                    )

                    // Reasoning Chain Accordion
                    if (reasoningList.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(SurfaceDark)
                                .border(0.5.dp, SurfaceBorder, RoundedCornerShape(8.dp))
                                .clickable { expandedReasoning = !expandedReasoning }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Psychology,
                                            contentDescription = null,
                                            tint = NeuralViolet,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isResponseArabic) "سلسلة التنسور المنطقية (${reasoningList.size} خطوات)" else "Local Tensor Chain (${reasoningList.size} steps)",
                                            color = NeuralViolet,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = if (isResponseArabic) FontFamily.Default else FontFamily.Monospace
                                        )
                                    }
                                    Icon(
                                        imageVector = if (expandedReasoning) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = null,
                                        tint = TextTertiary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                AnimatedVisibility(
                                    visible = expandedReasoning,
                                    enter = fadeIn() + expandVertically(),
                                    exit = fadeOut() + shrinkVertically()
                                ) {
                                    Column(modifier = Modifier.padding(top = 8.dp)) {
                                        reasoningList.forEach { step ->
                                            val isStepArabic = Tokenizer.isArabic(step)
                                            CompositionLocalProvider(
                                                LocalLayoutDirection provides if (isStepArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                                            ) {
                                                Text(
                                                    text = "• $step",
                                                    color = TextSecondary,
                                                    fontSize = 10.sp,
                                                    lineHeight = 15.sp,
                                                    fontFamily = if (isStepArabic) FontFamily.Default else FontFamily.Monospace,
                                                    textAlign = if (isStepArabic) TextAlign.Right else TextAlign.Left,
                                                    modifier = Modifier.padding(vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InferringLoadingIndicator(
    activeType: ModuleType,
    isArabic: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceCard)
            .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        CompositionLocalProvider(
            LocalLayoutDirection provides if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    color = CyberCyan,
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = if (isArabic) "جاري تفعيل مصفوفات التنسور..." else "Computing tensor activations...",
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = if (isArabic) FontFamily.Default else FontFamily.Monospace
                    )
                    Text(
                        text = if (isArabic) "معالجة ${activeType.titleAr} محلياً على أنوية معالج الهاتف" else "Executing ${activeType.title} locally on phone CPU",
                        color = TextTertiary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyConsolePlaceholder(
    activeType: ModuleType,
    isArabicMode: Boolean,
    onPromptSelect: (String) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(SurfaceElevated)
                    .border(1.dp, CyberCyan.copy(alpha = 0.4f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(30.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (isArabicMode) activeType.titleAr else activeType.title,
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isArabicMode) activeType.descriptionAr else activeType.description,
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp,
                modifier = Modifier.fillMaxWidth(0.9f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = if (isArabicMode) "جرّب استعلاماً نموذجياً" else "TRY PRESET PROMPT",
                color = TextTertiary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            val samplePrompt = if (isArabicMode) {
                when (activeType) {
                    ModuleType.TEXT_TRANSFORMER -> "حالة النظام المحلي"
                    ModuleType.SEMANTIC_RAG -> "كيف يحمي النظام الخصوصية؟"
                    ModuleType.REASONING_ENGINE -> "هل المعالجة المحلية آمنة وخاصة بالكامل؟"
                    ModuleType.PATTERN_CLASSIFIER -> "اشرح بنية النظام العصبي"
                }
            } else {
                when (activeType) {
                    ModuleType.TEXT_TRANSFORMER -> "neural core status"
                    ModuleType.SEMANTIC_RAG -> "How does NeuralCore protect privacy?"
                    ModuleType.REASONING_ENGINE -> "Is on-device inference completely private?"
                    ModuleType.PATTERN_CLASSIFIER -> "explain system architecture"
                }
            }

            val isSampleArabic = Tokenizer.isArabic(samplePrompt)
            CompositionLocalProvider(
                LocalLayoutDirection provides if (isSampleArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
                        .clickable { onPromptSelect(samplePrompt) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = if (isSampleArabic) samplePrompt else "» $samplePrompt",
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontFamily = if (isSampleArabic) FontFamily.Default else FontFamily.Monospace
                    )
                }
            }
        }
    }
}
