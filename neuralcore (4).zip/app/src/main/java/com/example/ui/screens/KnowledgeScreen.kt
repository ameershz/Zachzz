package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Search
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BulkImportProgressBar
import com.example.ui.components.BulkImporterModalDialog
import com.example.ui.components.BulkImportTargetMode
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.tensor.Tensor
import com.example.core.tensor.Tokenizer
import com.example.data.entity.KnowledgeDocEntity
import com.example.ui.NeuralCoreViewModel
import com.example.ui.components.NeuralHeader
import com.example.ui.components.StatChip
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeuralViolet
import com.example.ui.theme.PulseAmber
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

@Composable
fun KnowledgeScreen(
    viewModel: NeuralCoreViewModel,
    documents: List<KnowledgeDocEntity>,
    modifier: Modifier = Modifier
) {
    var showAddDocDialog by remember { mutableStateOf(false) }
    var newDocTitle by remember { mutableStateOf("") }
    var newDocContent by remember { mutableStateOf("") }

    val bulkProgress by viewModel.bulkImportProgress.collectAsStateWithLifecycle()
    var showBulkDialog by remember { mutableStateOf(false) }

    var searchQuery by remember { mutableStateOf("") }

    // On-device vector similarity search over local documents
    val searchResults = remember(searchQuery, documents) {
        if (searchQuery.isBlank() || documents.isEmpty()) {
            emptyList()
        } else {
            val queryEmb = viewModel.engine.semanticRag.computeEmbedding(searchQuery)
            documents.mapNotNull { doc ->
                try {
                    val floats = doc.embeddingVectorStr.split(",").map { it.toFloat() }.toFloatArray()
                    val docEmb = Tensor(1, floats.size, floats)
                    val similarity = queryEmb.cosineSimilarity(docEmb)
                    doc to similarity
                } catch (_: Exception) {
                    null
                }
            }.sortedByDescending { it.second }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SurfaceDark)
    ) {
        NeuralHeader(activeModuleName = "Context-Injection & Local Vector Store")

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (bulkProgress.isRunning) {
                item {
                    BulkImportProgressBar(
                        progress = bulkProgress,
                        onStopClick = { viewModel.stopBulkOperation() }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
                // Context-Injection Info Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(NeuralViolet.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hub,
                                contentDescription = null,
                                tint = NeuralViolet,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "ON-DEVICE VECTOR RAG INDEX",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Knowledge snippets are embedded into 48D dense vectors and searched locally via k-NN Cosine Similarity.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            // Interactive Local Vector Search Tester
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceCard)
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "TEST VECTOR SIMILARITY QUERY",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        val isSearchAr = Tokenizer.isArabic(searchQuery)
                        CompositionLocalProvider(
                            LocalLayoutDirection provides if (isSearchAr) LayoutDirection.Rtl else LayoutDirection.Ltr
                        ) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = {
                                    Text(
                                        text = "Search knowledge / ابحث في المعرفة المحلية...",
                                        color = TextTertiary,
                                        fontSize = 12.sp,
                                        textAlign = if (isSearchAr) TextAlign.Right else TextAlign.Left
                                    )
                                },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                                },
                                modifier = Modifier.fillMaxWidth().testTag("vector_search_input"),
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberCyan,
                                    unfocusedBorderColor = SurfaceBorder
                                ),
                                textStyle = MaterialTheme.typography.bodyMedium.copy(
                                    textAlign = if (isSearchAr) TextAlign.Right else TextAlign.Left
                                ),
                                singleLine = true
                            )
                        }

                        if (searchResults.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "TOP COSINE SIMILARITY MATCHES:",
                                color = CyberCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            searchResults.take(2).forEach { (doc, score) ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(SurfaceDark)
                                        .border(0.5.dp, SurfaceBorder, RoundedCornerShape(8.dp))
                                        .padding(8.dp)
                                ) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = doc.title, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(
                                                text = "${"%.1f".format(score * 100)}% Match",
                                                color = if (score > 0.4f) NeonEmerald else PulseAmber,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(text = doc.rawContent, color = TextSecondary, fontSize = 10.sp, maxLines = 2)
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }
                }
            }

            // Documents List Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "STORED KNOWLEDGE BASES (${documents.size})",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { showBulkDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.15f), contentColor = CyberCyan),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("bulk_import_docs_button")
                        ) {
                            Icon(imageVector = Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "Import (TXT/MD)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { showAddDocDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = SurfaceDark),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("add_knowledge_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "Add Doc", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (documents.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(SurfaceCard)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No custom knowledge documents indexed. Add documents to enrich local inference.",
                            color = TextTertiary,
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                items(documents, key = { it.id }) { doc ->
                    val isDocTitleAr = Tokenizer.isArabic(doc.title)
                    val isDocContentAr = Tokenizer.isArabic(doc.rawContent)
                    val isDocAr = isDocTitleAr || isDocContentAr

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceCard)
                            .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        CompositionLocalProvider(
                            LocalLayoutDirection provides if (isDocAr) LayoutDirection.Rtl else LayoutDirection.Ltr
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = doc.title,
                                        color = CyberCyan,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = if (isDocAr) TextAlign.Right else TextAlign.Left
                                    )

                                    IconButton(
                                        onClick = { viewModel.deleteKnowledgeDocument(doc.id) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete document",
                                            tint = TextTertiary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = doc.rawContent,
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp,
                                    textAlign = if (isDocAr) TextAlign.Right else TextAlign.Left
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    StatChip(
                                        label = if (isDocAr) "المتجه" else "VECTOR",
                                        value = "48-dim Float32",
                                        color = NeuralViolet
                                    )
                                    StatChip(
                                        label = if (isDocAr) "التخزين" else "INDEXED",
                                        value = "Room SQLite",
                                        color = NeonEmerald
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Add Knowledge Dialog (Bilingual & RTL Support)
    if (showAddDocDialog) {
        val isTitleAr = Tokenizer.isArabic(newDocTitle)
        val isContentAr = Tokenizer.isArabic(newDocContent)

        AlertDialog(
            onDismissRequest = { showAddDocDialog = false },
            title = {
                Text(
                    text = "Ingest Knowledge Document / إضافة مستند معرفي",
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = "Text will be tokenized, projected into dense vector space, and indexed locally for on-device RAG.\nسيتم تجزئة النص وإسقاطه في فضاء شعاعي وتخزينه محلياً.",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    CompositionLocalProvider(
                        LocalLayoutDirection provides if (isTitleAr) LayoutDirection.Rtl else LayoutDirection.Ltr
                    ) {
                        OutlinedTextField(
                            value = newDocTitle,
                            onValueChange = { newDocTitle = it },
                            placeholder = { Text("Document Title / عنوان المستند", color = TextTertiary, fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = SurfaceBorder
                            ),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                textAlign = if (isTitleAr) TextAlign.Right else TextAlign.Left
                            ),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    CompositionLocalProvider(
                        LocalLayoutDirection provides if (isContentAr) LayoutDirection.Rtl else LayoutDirection.Ltr
                    ) {
                        OutlinedTextField(
                            value = newDocContent,
                            onValueChange = { newDocContent = it },
                            placeholder = { Text("Full document content / محتوى المستند الكامل...", color = TextTertiary, fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth().height(120.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = SurfaceBorder
                            ),
                            textStyle = MaterialTheme.typography.bodyMedium.copy(
                                textAlign = if (isContentAr) TextAlign.Right else TextAlign.Left
                            ),
                            maxLines = 5
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addKnowledgeDocument(newDocTitle, newDocContent)
                        newDocTitle = ""
                        newDocContent = ""
                        showAddDocDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = SurfaceDark)
                ) {
                    Text("Embed & Ingest / تضمين وحفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDocDialog = false }) {
                    Text("Cancel / إلغاء", color = TextSecondary)
                }
            },
            containerColor = SurfaceElevated
        )
    }

    BulkImporterModalDialog(
        isOpen = showBulkDialog,
        onDismiss = { showBulkDialog = false },
        targetMode = BulkImportTargetMode.KNOWLEDGE_RAG,
        onImportFile = { uri ->
            viewModel.importRagDocument(uri)
        },
        onImportContent = { title, content, _ ->
            viewModel.importRagContent(title, content)
        },
        onPretrainRawText = {}
    )
}
