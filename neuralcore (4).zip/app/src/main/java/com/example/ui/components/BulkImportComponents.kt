package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.importer.BulkDatasetImporter
import com.example.core.importer.BulkImportProgress
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeuralViolet
import com.example.ui.theme.PulseAmber
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary

/**
 * Animated real-time background operation progress card.
 * Displays during asynchronous batch imports, dataset streaming, and raw text pre-training.
 */
@Composable
fun BulkImportProgressBar(
    progress: BulkImportProgress,
    onStopClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = progress.isRunning,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceElevated)
                .border(1.dp, CyberCyan.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .padding(14.dp)
                .testTag("bulk_import_progress_card")
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = CyberCyan,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = progress.operation,
                            color = CyberCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (progress.throughputPerSec > 0f) {
                            Text(
                                text = "${"%.1f".format(progress.throughputPerSec)} op/s",
                                color = NeonEmerald,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                        IconButton(
                            onClick = onStopClick,
                            modifier = Modifier.size(24.dp).testTag("stop_bulk_operation_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop operation",
                                tint = ErrorCrimson,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { (progress.percentage / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = CyberCyan,
                    trackColor = SurfaceDark
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${progress.processed}/${progress.total} (${"%.1f".format(progress.percentage)}%)",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    if (progress.currentLoss > 0f) {
                        Text(
                            text = "Loss: ${"%.4f".format(progress.currentLoss)}",
                            color = PulseAmber,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                if (progress.statusMessage.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = progress.statusMessage,
                        color = TextTertiary,
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * Universal Bulk Dataset & Document Importer Dialog.
 * Allows picking external files (.jsonl, .csv, .txt, .md), pasting raw content, or loading sample presets.
 */
@Composable
fun BulkImporterModalDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    targetMode: BulkImportTargetMode,
    onImportFile: (Uri) -> Unit,
    onImportContent: (title: String, content: String, format: String) -> Unit,
    onPretrainRawText: (content: String) -> Unit
) {
    if (!isOpen) return

    var selectedTab by remember { mutableIntStateOf(0) } // 0: File Picker, 1: Paste Text, 2: Presets
    var pastedContent by remember { mutableStateOf("") }
    var pastedTitle by remember { mutableStateOf("") }
    var selectedFormat by remember { mutableStateOf(if (targetMode == BulkImportTargetMode.KNOWLEDGE_RAG) "md" else "jsonl") }

    // Android System File Picker Launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            onImportFile(uri)
            onDismiss()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = when (targetMode) {
                            BulkImportTargetMode.TRAINING_DATASET -> "Bulk Fine-Tuning Importer"
                            BulkImportTargetMode.KNOWLEDGE_RAG -> "Bulk RAG Ingestion"
                            BulkImportTargetMode.RAW_PRETRAIN -> "Raw Text Pre-Training Engine"
                        },
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextTertiary, modifier = Modifier.size(18.dp))
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Tab Selection Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfaceDark)
                        .padding(2.dp)
                ) {
                    listOf("Select File", "Paste Text", "Presets").forEachIndexed { idx, label ->
                        val isSelected = selectedTab == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) SurfaceElevated else Color.Transparent)
                                .clickable { selectedTab = idx }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) CyberCyan else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                when (selectedTab) {
                    0 -> {
                        // File Picker Option
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .border(1.dp, SurfaceBorder, RoundedCornerShape(10.dp))
                                .background(SurfaceCard)
                                .padding(20.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.UploadFile,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = when (targetMode) {
                                    BulkImportTargetMode.TRAINING_DATASET -> "Import .JSONL or .CSV dataset"
                                    BulkImportTargetMode.KNOWLEDGE_RAG -> "Import .TXT or .MD documents"
                                    BulkImportTargetMode.RAW_PRETRAIN -> "Import raw .TXT text corpus"
                                },
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Select any file from your Android storage to stream directly into the local AI core",
                                color = TextTertiary,
                                fontSize = 11.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = {
                                    val mimeTypes = when (targetMode) {
                                        BulkImportTargetMode.TRAINING_DATASET -> arrayOf("*/*")
                                        BulkImportTargetMode.KNOWLEDGE_RAG -> arrayOf("text/*", "application/octet-stream")
                                        BulkImportTargetMode.RAW_PRETRAIN -> arrayOf("text/*")
                                    }
                                    filePickerLauncher.launch(mimeTypes)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = SurfaceDark),
                                modifier = Modifier.testTag("open_file_picker_button")
                            ) {
                                Text("Browse Storage Files", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    1 -> {
                        // Direct Paste Text / Markdown / JSONL
                        Column {
                            if (targetMode == BulkImportTargetMode.KNOWLEDGE_RAG) {
                                OutlinedTextField(
                                    value = pastedTitle,
                                    onValueChange = { pastedTitle = it },
                                    label = { Text("Document Title", fontSize = 11.sp) },
                                    placeholder = { Text("e.g. Architecture Guide.md", fontSize = 11.sp) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = CyberCyan,
                                        unfocusedBorderColor = SurfaceBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("jsonl", "csv", "md", "txt").forEach { fmt ->
                                    val isFmtSelected = selectedFormat == fmt
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isFmtSelected) CyberCyan.copy(alpha = 0.2f) else SurfaceElevated)
                                            .border(0.5.dp, if (isFmtSelected) CyberCyan else SurfaceBorder, RoundedCornerShape(6.dp))
                                            .clickable { selectedFormat = fmt }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = fmt.uppercase(),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isFmtSelected) CyberCyan else TextTertiary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = pastedContent,
                                onValueChange = { pastedContent = it },
                                label = { Text("Paste Data / Document Content", fontSize = 11.sp) },
                                placeholder = {
                                    Text(
                                        when (selectedFormat) {
                                            "jsonl" -> "{\"prompt\": \"...\", \"target\": \"...\"}\n{\"prompt\": \"...\", \"target\": \"...\"}"
                                            "csv" -> "prompt,target\n\"query 1\",\"answer 1\"\n\"query 2\",\"answer 2\""
                                            else -> "# Title\nParagraphs of content for chunking or pre-training..."
                                        },
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                },
                                maxLines = 8,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .testTag("pasted_dataset_input"),
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberCyan,
                                    unfocusedBorderColor = SurfaceBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    if (pastedContent.isNotBlank()) {
                                        if (targetMode == BulkImportTargetMode.RAW_PRETRAIN) {
                                            onPretrainRawText(pastedContent)
                                        } else {
                                            onImportContent(
                                                pastedTitle.ifBlank { "Pasted Corpus" },
                                                pastedContent,
                                                selectedFormat
                                            )
                                        }
                                        onDismiss()
                                    }
                                },
                                enabled = pastedContent.isNotBlank(),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = SurfaceDark),
                                modifier = Modifier.fillMaxWidth().testTag("execute_pasted_import_button")
                            ) {
                                Text(
                                    text = if (targetMode == BulkImportTargetMode.RAW_PRETRAIN) "Run Unsupervised Pre-Training" else "Import & Ingest Data",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    2 -> {
                        // Instant Preset Corpora
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            PresetItem(
                                title = "Arabic Conversational Pairs (JSONL)",
                                desc = "5 high-quality supervised prompt-target pairs for Arabic dialogue",
                                tag = "JSONL",
                                accent = CyberCyan,
                                onSelect = {
                                    onImportContent("Arabic Conversation", BulkDatasetImporter.SAMPLE_JSONL_ARABIC_CONVERSATION, "jsonl")
                                    onDismiss()
                                }
                            )

                            PresetItem(
                                title = "Technical AI Q&A Dataset (CSV)",
                                desc = "4 prompt-target pairs covering SIMD NEON, RAG, and repetition penalty",
                                tag = "CSV",
                                accent = NeuralViolet,
                                onSelect = {
                                    onImportContent("Technical Dataset", BulkDatasetImporter.SAMPLE_CSV_TECHNICAL_PAIRS, "csv")
                                    onDismiss()
                                }
                            )

                            PresetItem(
                                title = "NeuralCore Architecture Manual (Markdown)",
                                desc = "Full Markdown guide chunked into context windows with 48D embeddings",
                                tag = "RAG MD",
                                accent = NeonEmerald,
                                onSelect = {
                                    onImportContent("NeuralCore Manual.md", BulkDatasetImporter.SAMPLE_RAG_MARKDOWN_GUIDE, "md")
                                    onDismiss()
                                }
                            )

                            PresetItem(
                                title = "Arabic Grammar Corpus (Raw Text Pre-Training)",
                                desc = "Unstructured text for causal next-token sequence optimization",
                                tag = "PRE-TRAIN",
                                accent = PulseAmber,
                                onSelect = {
                                    onPretrainRawText(BulkDatasetImporter.SAMPLE_RAW_TEXT_CORPUS)
                                    onDismiss()
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextTertiary, fontSize = 12.sp)
            }
        },
        containerColor = SurfaceCard,
        shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun PresetItem(
    title: String,
    desc: String,
    tag: String,
    accent: Color,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceElevated)
            .border(0.5.dp, SurfaceBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onSelect)
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Text(text = desc, color = TextTertiary, fontSize = 10.sp, maxLines = 1)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(accent.copy(alpha = 0.15f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(text = tag, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

enum class BulkImportTargetMode {
    TRAINING_DATASET,
    KNOWLEDGE_RAG,
    RAW_PRETRAIN
}
