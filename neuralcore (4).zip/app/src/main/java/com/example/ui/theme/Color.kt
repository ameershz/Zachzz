package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00F0FF)
val CyberCyanMuted = Color(0xFF00A8B5)
val CyberCyanContainer = Color(0xFF003840)

val NeuralViolet = Color(0xFFA855F7)
val NeuralVioletMuted = Color(0xFF7C3AED)
val NeuralVioletContainer = Color(0xFF3B1861)

val BackgroundDark = Color(0xFF080B10)
val SurfaceDark = Color(0xFF0F141D)
val SurfaceCard = Color(0xFF161E2C)
val SurfaceElevated = Color(0xFF1E283A)
val SurfaceBorder = Color(0xFF26334A)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val NeonEmerald = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF064E3B)

val PulseAmber = Color(0xFFF59E0B)
val AmberContainer = Color(0xFF451A03)

val ErrorCrimson = Color(0xFFEF4444)
val ErrorContainer = Color(0xFF450A0A)
