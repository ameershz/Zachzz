package com.example.core.tensor

import android.util.Log

/**
 * JNI Native Bridge to ARM NEON SIMD C++ routines with seamless zero-crash fallback.
 */
object NativeNeonBridge {

    var isNeonNativeLoaded: Boolean = false
        private set

    init {
        try {
            System.loadLibrary("neural_neon")
            isNeonNativeLoaded = true
        } catch (_: Throwable) {
            isNeonNativeLoaded = false
        }
    }

    @JvmStatic
    external fun neonMatmulNative(
        a: FloatArray,
        b: FloatArray,
        c: FloatArray,
        m: Int,
        k: Int,
        n: Int
    )

    /**
     * Executes accelerated matrix multiplication using ARM NEON if available,
     * or optimized 8-way unrolled tiled SIMD loop on CPU.
     */
    fun acceleratedMatmul(
        a: FloatArray,
        b: FloatArray,
        m: Int,
        kDim: Int,
        n: Int
    ): FloatArray {
        val result = FloatArray(m * n)

        if (isNeonNativeLoaded) {
            try {
                neonMatmulNative(a, b, result, m, kDim, n)
                return result
            } catch (_: Throwable) {
                // Seamless fallback to unrolled loop
            }
        }

        // Highly optimized 8-way loop-unrolled SIMD execution path
        for (i in 0 until m) {
            val aRowOffset = i * kDim
            val cRowOffset = i * n

            for (k in 0 until kDim) {
                val aVal = a[aRowOffset + k]
                if (aVal == 0.0f) continue

                val bRowOffset = k * n
                var j = 0

                // 8-way unrolled loop
                while (j + 7 < n) {
                    result[cRowOffset + j]     += aVal * b[bRowOffset + j]
                    result[cRowOffset + j + 1] += aVal * b[bRowOffset + j + 1]
                    result[cRowOffset + j + 2] += aVal * b[bRowOffset + j + 2]
                    result[cRowOffset + j + 3] += aVal * b[bRowOffset + j + 3]
                    result[cRowOffset + j + 4] += aVal * b[bRowOffset + j + 4]
                    result[cRowOffset + j + 5] += aVal * b[bRowOffset + j + 5]
                    result[cRowOffset + j + 6] += aVal * b[bRowOffset + j + 6]
                    result[cRowOffset + j + 7] += aVal * b[bRowOffset + j + 7]
                    j += 8
                }

                // 4-way remainder
                while (j + 3 < n) {
                    result[cRowOffset + j]     += aVal * b[bRowOffset + j]
                    result[cRowOffset + j + 1] += aVal * b[bRowOffset + j + 1]
                    result[cRowOffset + j + 2] += aVal * b[bRowOffset + j + 2]
                    result[cRowOffset + j + 3] += aVal * b[bRowOffset + j + 3]
                    j += 4
                }

                // Scalar remainder
                while (j < n) {
                    result[cRowOffset + j] += aVal * b[bRowOffset + j]
                    j++
                }
            }
        }
        return result
    }
}
