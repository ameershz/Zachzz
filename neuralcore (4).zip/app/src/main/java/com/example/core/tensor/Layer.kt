package com.example.core.tensor

import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Base neural layer interface supporting forward inference and backward backpropagation.
 */
interface NeuralLayer {
    fun forward(input: Tensor): Tensor
    fun backward(gradOutput: Tensor): Tensor
    fun getParameters(): List<Tensor>
    fun getGradients(): List<Tensor>
    fun resetGradients()
}

/**
 * Fully Connected / Dense Linear Layer:
 * Y = X * W + B
 * Supports forward pass and analytical backpropagation for on-device local training.
 */
class LinearLayer(
    val inFeatures: Int,
    val outFeatures: Int,
    random: Random = Random(System.currentTimeMillis())
) : NeuralLayer {

    // Weight matrix: [inFeatures x outFeatures]
    var weights: Tensor = Tensor.xavier(inFeatures, outFeatures, random)
    // Bias vector: [1 x outFeatures]
    var bias: Tensor = Tensor.zeros(1, outFeatures)

    // Cached state for backpropagation
    private var lastInput: Tensor? = null

    // Gradients
    var gradWeights: Tensor = Tensor.zeros(inFeatures, outFeatures)
    var gradBias: Tensor = Tensor.zeros(1, outFeatures)

    override fun forward(input: Tensor): Tensor {
        require(input.cols == inFeatures) {
            "Input feature mismatch: expected cols=$inFeatures, got ${input.cols}"
        }
        lastInput = input
        // (batch x inFeatures) matmul (inFeatures x outFeatures) = (batch x outFeatures)
        val linear = input.matmul(weights)
        return linear + bias
    }

    override fun backward(gradOutput: Tensor): Tensor {
        val input = lastInput ?: error("forward() must be called before backward()")
        require(gradOutput.cols == outFeatures) {
            "gradOutput shape mismatch: expected cols=$outFeatures, got ${gradOutput.cols}"
        }

        // gradWeights = input.T * gradOutput : [inFeatures x batch] * [batch x outFeatures] = [inFeatures x outFeatures]
        val inputT = input.transpose()
        val dW = inputT.matmul(gradOutput)
        gradWeights = gradWeights + dW

        // gradBias = sum over rows of gradOutput
        for (r in 0 until gradOutput.rows) {
            val rOffset = r * gradOutput.cols
            for (c in 0 until gradOutput.cols) {
                gradBias[c] = gradBias[c] + gradOutput.data[rOffset + c]
            }
        }

        // gradInput = gradOutput * weights.T : [batch x outFeatures] * [outFeatures x inFeatures] = [batch x inFeatures]
        val weightsT = weights.transpose()
        return gradOutput.matmul(weightsT)
    }

    override fun getParameters(): List<Tensor> = listOf(weights, bias)

    override fun getGradients(): List<Tensor> = listOf(gradWeights, gradBias)

    override fun resetGradients() {
        gradWeights = Tensor.zeros(inFeatures, outFeatures)
        gradBias = Tensor.zeros(1, outFeatures)
    }
}

/**
 * Trainable Embedding layer converting discrete token IDs into continuous dense vectors.
 */
class EmbeddingLayer(
    val vocabSize: Int,
    val embeddingDim: Int,
    random: Random = Random(42)
) {
    // [vocabSize x embeddingDim]
    var weights: Tensor = Tensor.xavier(vocabSize, embeddingDim, random)
    var gradWeights: Tensor = Tensor.zeros(vocabSize, embeddingDim)

    private var lastTokenId: Int = -1

    fun forward(tokenId: Int): Tensor {
        val safeId = tokenId.coerceIn(0, vocabSize - 1)
        lastTokenId = safeId
        val vector = FloatArray(embeddingDim)
        val offset = safeId * embeddingDim
        System.arraycopy(weights.data, offset, vector, 0, embeddingDim)
        return Tensor(1, embeddingDim, vector)
    }

    fun backward(gradOutput: Tensor) {
        if (lastTokenId in 0 until vocabSize) {
            val offset = lastTokenId * embeddingDim
            for (c in 0 until embeddingDim) {
                gradWeights.data[offset + c] += gradOutput.data[c]
            }
        }
    }

    fun resetGradients() {
        gradWeights = Tensor.zeros(vocabSize, embeddingDim)
    }
}

/**
 * Scaled Dot-Product Self-Attention Layer for sequence contextualization:
 * Attention(Q, K, V) = softmax(Q * K^T / sqrt(d_k)) * V
 */
class ScaledDotProductAttention(
    val dim: Int,
    random: Random = Random(1337)
) {
    val qProj = LinearLayer(dim, dim, random)
    val kProj = LinearLayer(dim, dim, random)
    val vProj = LinearLayer(dim, dim, random)
    val outProj = LinearLayer(dim, dim, random)

    val scale: Float = 1.0f / sqrt(dim.toFloat())

    fun forward(sequence: Tensor): Tensor {
        // sequence is [seqLen x dim]
        val q = qProj.forward(sequence)
        val k = kProj.forward(sequence)
        val v = vProj.forward(sequence)

        // Q * K^T: [seqLen x dim] * [dim x seqLen] = [seqLen x seqLen]
        val scores = q.matmul(k.transpose()) * scale
        val attentionWeights = scores.softmax()

        // context: [seqLen x seqLen] * [seqLen x dim] = [seqLen x dim]
        val context = attentionWeights.matmul(v)
        return outProj.forward(context)
    }
}
