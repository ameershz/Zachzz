package com.example.core.modules

enum class ModuleType(
    val title: String,
    val subtitle: String,
    val description: String,
    val badge: String,
    val titleAr: String,
    val subtitleAr: String,
    val descriptionAr: String,
    val badgeAr: String,
    val defaultParametersCount: Int
) {
    TEXT_TRANSFORMER(
        title = "Scaled Neural Transformer",
        subtitle = "1.58M Conversational Core",
        description = "Deep 4-block transformer (1.58M parameters) with Arabic morphological BPE tokenization, strict repetition penalty (1.35), and ARM NEON acceleration.",
        badge = "1.58M Core",
        titleAr = "المحول العصبي الموسع",
        subtitleAr = "نواة حوارية بـ 1.58 مليون معامل",
        descriptionAr = "محول عميق بـ 4 طبقات (1.58 مليون معامل) مع تحليل BPE للصرف العربي، ومنع التكرار وحلقات الدوران اللانهائية، وتسريع ARM NEON.",
        badgeAr = "نواة 1.58M",
        defaultParametersCount = 1578424
    ),
    SEMANTIC_RAG(
        title = "Semantic RAG & Vector Engine",
        subtitle = "Dense Memory & Retrieval",
        description = "Encodes text into multi-dimensional vector embeddings, performs local k-NN cosine distance search, and injects dynamic context.",
        badge = "Memory",
        titleAr = "محرك البحث الدلالي والشعاعي",
        subtitleAr = "الذاكرة الكثيفة والاسترجاع",
        descriptionAr = "تضمين النصوص في متجهات شعاعية وبحث فائق السرعة عبر تشابه جيب التمام k-NN مع حقن السياق المحلي بدون إنترنت.",
        badgeAr = "ذاكرة",
        defaultParametersCount = 24500
    ),
    REASONING_ENGINE(
        title = "Adaptive Reasoning Core",
        subtitle = "Probabilistic State & Logic Graph",
        description = "Evaluates hypotheses using confidence-calibrated graph nodes, multi-step deductive chains, and Bayesian rule weights.",
        badge = "Reasoning",
        titleAr = "نواة الاستنتاج والمنطق التكيفي",
        subtitleAr = "رسم بياني منطقي احتمالي",
        descriptionAr = "تقييم الفرضيات واستنتاج سلاسل التفكير خطوة بخطوة مع معايرة درجات الثقة وأوزان بايز الاحتمالية.",
        badgeAr = "استنتاج",
        defaultParametersCount = 18600
    ),
    PATTERN_CLASSIFIER(
        title = "Neural Pattern Classifier",
        subtitle = "Supervised Multi-Layer Perceptron",
        description = "High-speed intent, sentiment, and query anomaly detection using deep dense layers with real-time on-device training.",
        badge = "Classifier",
        titleAr = "مصنف الأنماط والنوايا العصبية",
        subtitleAr = "بيرسبترون عميق متعدد الطبقات",
        descriptionAr = "كشف النوايا والاستعلامات والشذوذ فائق السرعة عبر طبقات كثيفة مع تدريب إشرافي مباشر على الجهاز.",
        badgeAr = "مصنف",
        defaultParametersCount = 31200
    )
}
