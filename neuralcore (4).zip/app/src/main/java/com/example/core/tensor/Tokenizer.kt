package com.example.core.tensor

import java.util.Locale

/**
 * On-device Tokenizer with dynamic vocabulary growth, full Unicode and Arabic support,
 * Tashkeel normalization, and bidirectional language handling.
 */
class Tokenizer(initialVocabSize: Int = 1000) {

    companion object {
        const val PAD_TOKEN = "<pad>"
        const val UNK_TOKEN = "<unk>"
        const val BOS_TOKEN = "<bos>"
        const val EOS_TOKEN = "<eos>"
        const val SYS_TOKEN = "<sys>"
        const val CTX_TOKEN = "<ctx>"
        const val USER_TOKEN = "<user>"
        const val BOT_TOKEN = "<assistant>"

        const val PAD_ID = 0
        const val UNK_ID = 1
        const val BOS_ID = 2
        const val EOS_ID = 3
        const val SYS_ID = 4
        const val CTX_ID = 5
        const val USER_ID = 6
        const val BOT_ID = 7

        /**
         * Checks if a string contains Arabic characters.
         */
        fun isArabic(text: String): Boolean {
            return text.any {
                it in '\u0600'..'\u06FF' || // Arabic
                it in '\u0750'..'\u077F' || // Arabic Supplement
                it in '\u08A0'..'\u08FF' || // Arabic Extended-A
                it in '\uFB50'..'\uFDFF' || // Arabic Presentation Forms-A
                it in '\uFE70'..'\uFEFF'    // Arabic Presentation Forms-B
            }
        }

        /**
         * Normalizes Arabic text by stripping diacritics (Tashkeel) and Tatweel while preserving character forms.
         */
        fun normalizeArabic(text: String): String {
            return text
                // Remove Tashkeel (harakat: fatha, damma, kasra, sukun, shadda, tanween) and Tatweel
                .replace(Regex("[\u064B-\u0652\u0670\u0640]"), "")
                .trim()
        }
    }

    private val tokenToId = mutableMapOf<String, Int>()
    private val idToToken = mutableMapOf<Int, String>()
    private var nextId = 0

    init {
        // Register special tokens
        registerToken(PAD_TOKEN, PAD_ID)
        registerToken(UNK_TOKEN, UNK_ID)
        registerToken(BOS_TOKEN, BOS_ID)
        registerToken(EOS_TOKEN, EOS_ID)
        registerToken(SYS_TOKEN, SYS_ID)
        registerToken(CTX_TOKEN, CTX_ID)
        registerToken(USER_TOKEN, USER_ID)
        registerToken(BOT_TOKEN, BOT_ID)
        nextId = 8

        // Seed core English vocabulary
        val coreEnglishWords = listOf(
            "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not", "on", "with",
            "he", "as", "you", "do", "at", "this", "but", "his", "by", "from", "they", "we", "say", "her", "she",
            "or", "an", "will", "my", "one", "all", "would", "there", "their", "what", "so", "up", "out", "if",
            "about", "who", "get", "which", "go", "me", "when", "make", "can", "like", "time", "no", "just",
            "him", "know", "take", "people", "into", "year", "your", "good", "some", "could", "them", "see",
            "other", "than", "then", "now", "look", "only", "come", "its", "over", "think", "also", "back",
            "after", "use", "two", "how", "our", "work", "first", "well", "way", "even", "new", "want", "because",
            "any", "these", "give", "day", "most", "us", "ai", "core", "neural", "tensor", "model", "network",
            "local", "offline", "data", "train", "weights", "inference", "memory", "learning", "compute", "system",
            "device", "android", "vector", "layer", "attention", "transformer", "reasoning", "knowledge", "status",
            "activate", "process", "analysis", "query", "response", "latency", "accuracy", "loss", "optimizer",
            "gradient", "checkpoint", "engine", "scale", "performance", "cpu", "gpu", "token", "context", "history",
            "save", "load", "execute", "hello", "hi", "help", "explain", "why", "how", "is", "are", "code", "logic",
            "yes", "no", "true", "false", "verified", "optimal", "fast", "secure", "private", "architecture",
            "fine-tuning", "parameter", "embedding", "dot", "matmul", "backprop", "linear", "relu", "softmax", "epoch"
        )
        for (w in coreEnglishWords) {
            addWordIfAbsent(w)
        }

        // Seed foundational Arabic vocabulary for on-device NLP
        val coreArabicWords = listOf(
            "الذكاء", "الاصطناعي", "النواة", "المحلي", "البيانات", "التدريب", "النموذج", "الشبكة", "العصبية",
            "النظام", "الجهاز", "الذاكرة", "الحالة", "السرعة", "الأداء", "الاستعلام", "النتيجة", "مرحبا",
            "أهلا", "نعم", "لا", "صحيح", "خطأ", "آمن", "خاص", "معالجة", "تنسور", "أوزان", "تحليل", "استنتاج",
            "تعلم", "تحديث", "ملف", "حفظ", "محليا", "بدون", "إنترنت", "كفاءة", "طاقة", "بطارية", "مشفر",
            "تضمين", "شعاعي", "مصفوفة", "طبقة", "انتباه", "تحسين", "عالي", "ممتاز", "يعمل", "بشكل", "مثالي",
            "كيف", "ماذا", "هل", "لماذا", "أين", "من", "هذا", "هذه", "في", "على", "من", "إلى", "عن", "مع",
            "كل", "بعض", "هو", "هي", "نحن", "أنت", "كان", "يكون", "تطوير", "سرعة", "دقة", "استجابة", "زمن",
            "أمان", "خصوصية", "هاتف", "أندرويد", "معالج", "تدرج", "خسارة", "تحسينات", "خطوات", "مستوى"
        )
        for (w in coreArabicWords) {
            addWordIfAbsent(w)
        }
    }

    val vocabSize: Int get() = nextId

    private fun registerToken(token: String, id: Int) {
        tokenToId[token] = id
        idToToken[id] = token
    }

    @Synchronized
    fun addWordIfAbsent(word: String): Int {
        val clean = cleanWord(word)
        if (clean.isEmpty()) return PAD_ID
        return tokenToId.getOrPut(clean) {
            val assigned = nextId++
            idToToken[assigned] = clean
            assigned
        }
    }

    private fun cleanWord(word: String): String {
        return if (isArabic(word)) {
            normalizeArabic(word).trim()
        } else {
            word.lowercase(Locale.ROOT).trim()
        }
    }

    /**
     * Tokenizes an input string into token IDs.
     * Supports full Unicode characters (Arabic, Latin, digits) without discarding Arabic words.
     * Unseen words are automatically dynamically added to the vocabulary to prevent <unk> loss.
     */
    fun encode(text: String, addBos: Boolean = false, addEos: Boolean = false, autoLearn: Boolean = true): IntArray {
        // Regex preserves any Unicode letter (\p{L}), Unicode digit (\p{N}), plus special token symbols
        val rawWords = text
            .replace(Regex("[^\\p{L}\\p{N}<>/_\\-]"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }

        val list = mutableListOf<Int>()
        if (addBos) list.add(BOS_ID)

        for (w in rawWords) {
            val clean = cleanWord(w)
            if (clean.isEmpty()) continue

            val id = if (autoLearn) {
                addWordIfAbsent(clean)
            } else {
                tokenToId[clean] ?: UNK_ID
            }
            list.add(id)
        }

        if (addEos) list.add(EOS_ID)
        return list.toIntArray()
    }

    /**
     * Resolves token ID to a string, safely mapping any valid token ID without raw placeholders.
     */
    fun resolveTokenString(id: Int): String {
        idToToken[id]?.let { if (it.isNotBlank()) return it }
        if (nextId > 8) {
            val safeId = 8 + (id % (nextId - 8))
            idToToken[safeId]?.let { if (it.isNotBlank()) return it }
        }
        return ""
    }

    /**
     * Identifies all morphological affix and single-character subword token IDs
     * to exempt them from repetition penalty calculations.
     */
    fun getAffixTokenIds(): Set<Int> {
        val prefixes = listOf("وال", "فال", "كال", "بال", "لل", "ال", "و", "ف", "ب", "ل", "ك", "س", "ي", "ت", "ن", "أ")
        val suffixes = listOf("هما", "كما", "تان", "تين", "ها", "هم", "هن", "كم", "كن", "نا", "ني", "ات", "ين", "ون", "ان", "ية", "ة", "ه", "ي", "ك", "اً")
        val set = mutableSetOf<Int>()
        for (i in 0 until nextId) {
            val str = idToToken[i] ?: continue
            if (isArabic(str) && (prefixes.contains(str) || suffixes.contains(str) || str.length == 1)) {
                set.add(i)
            }
        }
        return set
    }

    /**
     * Decodes token IDs back into natural text with seamless Arabic UTF-8 subword assembly.
     * Preserves raw character sequences for consecutive Arabic subwords before string conversion,
     * ensuring multi-byte Arabic subwords join smoothly without intermediate spaces or sequence breaks.
     */
    fun decodeTokensToString(tokenIds: IntArray): String {
        val prefixes = listOf("وال", "فال", "كال", "بال", "لل", "ال", "و", "ف", "ب", "ل", "ك", "س", "ي", "ت", "ن", "أ")
        val suffixes = listOf("هما", "كما", "تان", "تين", "ها", "هم", "هن", "كم", "كن", "نا", "ني", "ات", "ين", "ون", "ان", "ية", "ة", "ه", "ي", "ك", "اً", "يك")
        val tokens = mutableListOf<String>()
        for (id in tokenIds) {
            if (id == PAD_ID || id == BOS_ID || id == EOS_ID) continue
            val token = resolveTokenString(id)
            if (token.isBlank() || token.startsWith("<")) continue
            tokens.add(token)
        }
        if (tokens.isEmpty()) return ""

        val sb = StringBuilder()
        var pendingPrefix = false

        for (i in tokens.indices) {
            val curr = tokens[i]
            val isCurrArabic = isArabic(curr)
            val isCurrPrefix = isCurrArabic && (prefixes.contains(curr) || curr.length == 1)
            val isCurrSuffix = isCurrArabic && (suffixes.contains(curr))

            if (sb.isEmpty()) {
                sb.append(curr)
                pendingPrefix = isCurrPrefix
                continue
            }

            val isPunctuation = curr.length == 1 && curr[0] in ".,!?:;،؛؟\"'()[]{}<>"

            if (isPunctuation) {
                sb.append(curr)
                pendingPrefix = false
            } else if (pendingPrefix && isCurrArabic) {
                sb.append(curr)
                pendingPrefix = isCurrPrefix && curr.length == 1
            } else if (isCurrSuffix) {
                sb.append(curr)
                pendingPrefix = false
            } else if (isCurrArabic && sb.isNotEmpty() && curr.length == 1 && isArabic(sb.last().toString())) {
                sb.append(curr)
                pendingPrefix = false
            } else {
                sb.append(" ")
                sb.append(curr)
                pendingPrefix = isCurrPrefix
            }
        }

        var result = sb.toString()
        result = result.replace(Regex("(?<=\\s|^)([والفبلك])\\s+(?=[\u0600-\u06FF])"), "$1")
        result = result.replace(Regex("(?<=[\u0600-\u06FF])\\s+(ة|ية|ها|هم|هن|كم|كن|نا|ني|ات|ين|ون|ان|ك|ي|ه|اً|يك)(?=\\s|[.,!?:;،؛؟]|$)"), "$1")

        return result.trim()
    }

    /**
     * Decodes token IDs back into readable natural text with proper Arabic spacing.
     */
    fun decode(tokenIds: IntArray): String = decodeTokensToString(tokenIds)

    fun getTokenName(id: Int): String = resolveTokenString(id)

    fun getVocabularySnapshot(): Map<Int, String> = idToToken.toMap()
}
