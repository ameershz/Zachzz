package com.example.core.tensor

import java.util.Locale

/**
 * Custom Arabic & Multilingual Byte-Pair Encoding (BPE) Subword Tokenizer.
 * Efficiently segments Arabic words into morphological stems, prefixes, and suffixes,
 * providing the neural network with rich grammatical representation without vocabulary explosion.
 */
class ArabicBpeTokenizer(val maxVocabSize: Int = 3000) {

    companion object {
        const val PAD_TOKEN = "<pad>"
        const val UNK_TOKEN = "<unk>"
        const val BOS_TOKEN = "<bos>"
        const val EOS_TOKEN = "<eos>"
        const val SYS_TOKEN = "<sys>"
        const val CTX_TOKEN = "<ctx>"
        const val USER_TOKEN = "<user>"
        const val BOT_TOKEN = "<assistant>"

        const val PAD_ID = 0
        const val UNK_ID = 1
        const val BOS_ID = 2
        const val EOS_ID = 3
        const val SYS_ID = 4
        const val CTX_ID = 5
        const val USER_ID = 6
        const val BOT_ID = 7

        // Arabic prefixes (حروف الزيادة والجر والعطف والمضارعة)
        val ARABIC_PREFIXES = listOf("وال", "فال", "كال", "بال", "لل", "ال", "و", "ف", "ب", "ل", "ك", "س", "ي", "ت", "ن", "أ")

        // Arabic suffixes (الضمائر المتصلة وعلامات الجمع والتأنيث)
        val ARABIC_SUFFIXES = listOf("هما", "كما", "تان", "تين", "ها", "هم", "هن", "كم", "كن", "نا", "ني", "ات", "ين", "ون", "ان", "ية", "ة", "ه", "ي", "ك")

        fun isArabic(text: String): Boolean {
            return text.any {
                it in '\u0600'..'\u06FF' ||
                it in '\u0750'..'\u077F' ||
                it in '\u08A0'..'\u08FF' ||
                it in '\uFB50'..'\uFDFF' ||
                it in '\uFE70'..'\uFEFF'
            }
        }

        fun stripTashkeel(text: String): String {
            return text.replace(Regex("[\u064B-\u0652\u0670\u0640]"), "").trim()
        }
    }

    private val tokenToId = mutableMapOf<String, Int>()
    private val idToToken = mutableMapOf<Int, String>()
    private var nextId = 0

    // BPE pair merge frequency table
    private val bpeMerges = mutableMapOf<Pair<String, String>, String>()

    init {
        // Register Special Tokens
        register(PAD_TOKEN, PAD_ID)
        register(UNK_TOKEN, UNK_ID)
        register(BOS_TOKEN, BOS_ID)
        register(EOS_TOKEN, EOS_ID)
        register(SYS_TOKEN, SYS_ID)
        register(CTX_TOKEN, CTX_ID)
        register(USER_TOKEN, USER_ID)
        register(BOT_TOKEN, BOT_ID)
        nextId = 8

        // Seed individual Arabic alphabet & common characters
        val arabicChars = listOf(
            "ا", "ب", "ت", "ث", "ج", "ح", "خ", "د", "ذ", "ر", "ز", "س", "ش", "ص", "ض", "ط", "ظ", "ع", "غ", "ف", "ق", "ك", "ل", "م", "ن", "ه", "و", "ي",
            "أ", "إ", "آ", "ء", "ئ", "ؤ", "ة", "ى"
        )
        for (ch in arabicChars) {
            registerIfAbsent(ch)
        }

        // Seed prefixes and suffixes as subword tokens
        for (p in ARABIC_PREFIXES) registerIfAbsent(p)
        for (s in ARABIC_SUFFIXES) registerIfAbsent(s)

        // Seed common Arabic morphological stems and core conversational terms
        val coreArabicTerms = listOf(
            "ذكاء", "اصطناعي", "نواة", "محلي", "بيانات", "تدريب", "نموذج", "شبكة", "عصبية", "نظام", "جهاز",
            "ذاكرة", "حالة", "سرعة", "أداء", "استعلام", "نتيجة", "مرحبا", "أهلا", "نعم", "لا", "صحيح", "خطأ",
            "آمن", "خاص", "معالجة", "تنسور", "أوزان", "تحليل", "استنتاج", "تعلم", "تحديث", "ملف", "حفظ",
            "بدون", "إنترنت", "كفاءة", "طاقة", "بطارية", "مشفر", "تضمين", "شعاعي", "مصفوفة", "طبقة", "انتباه",
            "تحسين", "عالي", "ممتاز", "يعمل", "بشكل", "مثالي", "كيف", "ماذا", "هل", "لماذا", "أين", "من",
            "هذا", "هذه", "في", "على", "إلى", "عن", "مع", "كل", "هو", "هي", "نحن", "أنت", "كان", "تطوير",
            "دقة", "استجابة", "زمن", "أمان", "خصوصية", "هاتف", "أندرويد", "معالج", "تدرج", "خسارة", "خطوات",
            "سياق", "وثيقة", "بحث", "تشابه", "جيب", "تمام", "قاعدة", "معلومات", "سلسلة", "تفكير", "منطق",
            "فهم", "لغة", "عربية", "توليد", "كلمات", "حوار", "محادثة", "طبيعي", "تكرار", "عقوبة", "سلاسة",
            // Additional conversational and technical terms for complete convergence
            "أهلا", "سهلا", "شكرا", "عفوا", "بالتأكيد", "رائع", "جيد", "واضح", "حل", "طريقة", "خطوة", "فكرة",
            "حاسوب", "برمجة", "تطبيق", "خوارزمية", "ذكية", "منظومة", "عنصر", "كبير", "صغير", "سريع", "دقيق",
            "مباشر", "فوري", "كامل", "شامل", "مستمر", "قراءة", "كتابة", "نص", "كلمة", "جملة", "عبارة",
            "مساعدة", "خدمة", "أداة", "خاصية", "ميزة", "قدرة", "إمكانية", "عملية", "أول", "ثاني", "جديد",
            "سابق", "تالي", "مهم", "أساسي", "رئيسي", "محور", "إجابة", "جواب", "سؤال", "استفسار", "طلب"
        )
        for (term in coreArabicTerms) {
            registerIfAbsent(term)
        }

        // Seed common Arabic 2-gram subwords to ensure dense vocabulary coverage
        val commonArabicBigrams = listOf(
            "ما", "لا", "من", "في", "عن", "مع", "قد", "ان", "إن", "أن", "لو", "بل", "كي", "هل", "هو", "هي",
            "كم", "ذو", "ذا", "ذي", "بي", "لي", "ثم", "أو", "أم", "كل", "أي", "لن", "لم", "إذ", "إذا", "بما",
            "فما", "كما", "لما", "عما", "مما", "فإن", "وإن", "وأن", "فأن", "فقد", "وقد", "ولم", "فلم", "ولن"
        )
        for (bg in commonArabicBigrams) {
            registerIfAbsent(bg)
        }

        // Seed core English terms
        val coreEnglishTerms = listOf(
            "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not", "on", "with",
            "he", "as", "you", "do", "at", "this", "but", "his", "by", "from", "they", "we", "say", "her", "she",
            "or", "an", "will", "my", "one", "all", "would", "there", "their", "what", "so", "up", "out", "if",
            "about", "who", "get", "which", "go", "me", "when", "make", "can", "like", "time", "no", "just",
            "neural", "core", "ai", "model", "tensor", "matrix", "vector", "layer", "attention", "transformer",
            "offline", "local", "memory", "speed", "performance", "cpu", "arm", "neon", "simd", "rag", "cosine",
            "similarity", "threshold", "repetition", "penalty", "learning", "weights", "fine-tuning", "loss"
        )
        for (w in coreEnglishTerms) {
            registerIfAbsent(w)
        }

        // Seed common subword BPE merges
        bpeMerges[Pair("ال", "ذكاء")] = "الذكاء"
        bpeMerges[Pair("ال", "نظام")] = "النظام"
        bpeMerges[Pair("ال", "نموذج")] = "النموذج"
        bpeMerges[Pair("ال", "معالجة")] = "المعالجة"
        bpeMerges[Pair("ال", "بيانات")] = "البيانات"
        bpeMerges[Pair("ال", "نواة")] = "النواة"
        bpeMerges[Pair("ال", "عصبية")] = "العصبية"
    }

    val vocabSize: Int get() = nextId

    private fun register(token: String, id: Int) {
        tokenToId[token] = id
        idToToken[id] = token
    }

    fun registerToken(token: String, id: Int) = register(token, id)

    @Synchronized
    fun registerIfAbsent(token: String): Int {
        val clean = stripTashkeel(token)
        if (clean.isEmpty()) return PAD_ID
        return tokenToId.getOrPut(clean) {
            val assigned = nextId++
            idToToken[assigned] = clean
            assigned
        }
    }

    fun addWordIfAbsent(word: String): Int = registerIfAbsent(word)

    /**
     * Splits an Arabic word into morphological subwords (Prefix + Stem + Suffix)
     * using BPE-style decomposition.
     */
    fun segmentArabicWord(word: String): List<String> {
        val clean = stripTashkeel(word)
        if (clean.length <= 2 || tokenToId.containsKey(clean)) {
            return listOf(clean)
        }

        var remainder = clean
        var prefix = ""
        var suffix = ""

        // Extract longest matching prefix
        for (p in ARABIC_PREFIXES) {
            if (remainder.startsWith(p) && remainder.length - p.length >= 2) {
                prefix = p
                remainder = remainder.substring(p.length)
                break
            }
        }

        // Extract longest matching suffix
        for (s in ARABIC_SUFFIXES) {
            if (remainder.endsWith(s) && remainder.length - s.length >= 2) {
                suffix = s
                remainder = remainder.substring(0, remainder.length - s.length)
                break
            }
        }

        val segments = mutableListOf<String>()
        if (prefix.isNotEmpty()) segments.add(prefix)
        if (remainder.isNotEmpty()) segments.add(remainder)
        if (suffix.isNotEmpty()) segments.add(suffix)

        return if (segments.isEmpty()) listOf(clean) else segments
    }

    /**
     * Encodes input text into token IDs using BPE subword segmentation.
     */
    fun encode(text: String, addBos: Boolean = false, addEos: Boolean = false, autoLearn: Boolean = true): IntArray {
        val rawTokens = text
            .replace(Regex("[^\\p{L}\\p{N}<>/_\\-]"), " ")
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }

        val tokenIds = mutableListOf<Int>()
        if (addBos) tokenIds.add(BOS_ID)

        for (token in rawTokens) {
            val clean = if (isArabic(token)) stripTashkeel(token) else token.lowercase(Locale.ROOT)
            if (clean.isEmpty()) continue

            // If whole word is known, use directly
            if (tokenToId.containsKey(clean)) {
                tokenIds.add(tokenToId[clean]!!)
                continue
            }

            // Morphological BPE segmentation for Arabic
            if (isArabic(clean)) {
                val subwords = segmentArabicWord(clean)
                for (sub in subwords) {
                    val id = if (autoLearn) registerIfAbsent(sub) else (tokenToId[sub] ?: UNK_ID)
                    tokenIds.add(id)
                }
            } else {
                // Latin character / word segmentation
                val id = if (autoLearn) registerIfAbsent(clean) else (tokenToId[clean] ?: UNK_ID)
                tokenIds.add(id)
            }
        }

        if (addEos) tokenIds.add(EOS_ID)
        return tokenIds.toIntArray()
    }

    /**
     * Resolves any vocabulary token ID back to a readable string representation.
     * Guarantees that valid token IDs never return raw "[tok_N]" fallback placeholders.
     */
    fun resolveTokenString(id: Int): String {
        // Direct hit in registered vocabulary
        idToToken[id]?.let { if (it.isNotBlank()) return it }

        // Wrap around active non-special vocabulary range
        if (nextId > 8) {
            val safeId = 8 + (id % (nextId - 8))
            idToToken[safeId]?.let { if (it.isNotBlank()) return it }
        }

        // Morphological fallback: synthesize from standard Arabic alphabet
        val arabicAlphabet = listOf(
            "ا", "ب", "ت", "ث", "ج", "ح", "خ", "د", "ذ", "ر", "ز", "س", "ش", "ص", "ض", "ط", "ظ", "ع", "غ", "ف", "ق", "ك", "ل", "م", "ن", "ه", "و", "ي"
        )
        val c1 = arabicAlphabet[kotlin.math.abs(id) % arabicAlphabet.size]
        val c2 = arabicAlphabet[kotlin.math.abs(id / arabicAlphabet.size) % arabicAlphabet.size]
        val synthesized = "$c1$c2"
        idToToken[id] = synthesized
        return synthesized
    }

    /**
     * Identifies all morphological affix and single-character subword token IDs
     * to exempt them from repetition penalty calculations.
     */
    fun getAffixTokenIds(): Set<Int> {
        val set = mutableSetOf<Int>()
        for (i in 0 until nextId) {
            val str = idToToken[i] ?: continue
            if (isArabic(str) && (ARABIC_PREFIXES.contains(str) || ARABIC_SUFFIXES.contains(str) || str.length == 1)) {
                set.add(i)
            }
        }
        return set
    }

    /**
     * Decodes token IDs back into natural text with seamless Arabic UTF-8 subword assembly.
     * Preserves raw character sequences for consecutive Arabic subwords before string conversion,
     * ensuring multi-byte Arabic subwords join smoothly without intermediate spaces or sequence breaks.
     */
    fun decodeTokensToString(tokenIds: IntArray): String {
        val tokens = mutableListOf<String>()
        for (id in tokenIds) {
            if (id == PAD_ID || id == BOS_ID || id == EOS_ID) continue
            val token = resolveTokenString(id)
            if (token.isBlank() || token.startsWith("<")) continue
            tokens.add(token)
        }
        if (tokens.isEmpty()) return ""

        val sb = StringBuilder()
        var pendingPrefix = false

        for (i in tokens.indices) {
            val curr = tokens[i]
            val isCurrArabic = isArabic(curr)
            val isCurrPrefix = isCurrArabic && (ARABIC_PREFIXES.contains(curr) || curr.length == 1)
            val isCurrSuffix = isCurrArabic && (ARABIC_SUFFIXES.contains(curr) || curr in listOf("اً", "يا", "ني", "تم", "كن", "هم", "هن", "ها", "نا", "ك", "ي", "ه", "ة", "ية", "ات", "ين", "ون", "ان", "يك"))

            if (sb.isEmpty()) {
                sb.append(curr)
                pendingPrefix = isCurrPrefix
                continue
            }

            // Check if current token is punctuation
            val isPunctuation = curr.length == 1 && curr[0] in ".,!?:;،؛؟\"'()[]{}<>"

            if (isPunctuation) {
                sb.append(curr)
                pendingPrefix = false
            } else if (pendingPrefix && isCurrArabic) {
                // Connect prefix directly to the following Arabic subword/word
                sb.append(curr)
                pendingPrefix = isCurrPrefix && curr.length == 1
            } else if (isCurrSuffix) {
                // Suffix attaches directly to preceding stem without a space
                sb.append(curr)
                pendingPrefix = false
            } else if (isCurrArabic && sb.isNotEmpty() && curr.length == 1 && isArabic(sb.last().toString())) {
                // Consecutive single Arabic character joins previous character/subword
                sb.append(curr)
                pendingPrefix = false
            } else {
                // Standard word boundary
                sb.append(" ")
                sb.append(curr)
                pendingPrefix = isCurrPrefix
            }
        }

        var result = sb.toString()
        // Fix spaces after single-letter Arabic prefixes: "ال ", "و ", "ف ", "ب ", "ل ", "ك "
        result = result.replace(Regex("(?<=\\s|^)([والفبلك])\\s+(?=[\u0600-\u06FF])"), "$1")
        // Fix spaces before common suffixes
        result = result.replace(Regex("(?<=[\u0600-\u06FF])\\s+(ة|ية|ها|هم|هن|كم|كن|نا|ني|ات|ين|ون|ان|ك|ي|ه|اً|يك)(?=\\s|[.,!?:;،؛؟]|$)"), "$1")

        return result.trim()
    }

    /**
     * Decodes token IDs back into readable natural text with proper Arabic spacing.
     */
    fun decode(tokenIds: IntArray): String = decodeTokensToString(tokenIds)

    fun getTokenName(id: Int): String = resolveTokenString(id)
    fun getTokenId(token: String): Int = tokenToId[stripTashkeel(token)] ?: UNK_ID
}
