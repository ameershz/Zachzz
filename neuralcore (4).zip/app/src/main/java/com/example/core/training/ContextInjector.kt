package com.example.core.training

import com.example.core.modules.SemanticRagModule
import com.example.core.tensor.Tensor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class InjectedContext(
    val docId: Long,
    val title: String,
    val content: String,
    val similarityScore: Float
)

/**
 * On-device Context-Injection engine.
 * Embeds knowledge chunks into local vector indices and injects relevant snippets
 * into inference pipelines without external servers.
 */
class ContextInjector(
    private val semanticModule: SemanticRagModule
) {
    /**
     * Splits a document into overlapping semantic chunks
     */
    fun chunkDocument(text: String, chunkSize: Int = 180, overlap: Int = 30): List<String> {
        val words = text.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size <= chunkSize) return listOf(text.trim())

        val chunks = mutableListOf<String>()
        var start = 0
        while (start < words.size) {
            val end = (start + chunkSize).coerceAtMost(words.size)
            val chunk = words.subList(start, end).joinToString(" ")
            chunks.add(chunk)
            if (end == words.size) break
            start += (chunkSize - overlap)
        }
        return chunks
    }

    /**
     * Generates vector embeddings for a chunk using on-device Semantic RAG weights
     */
    fun embedText(text: String): FloatArray {
        val tensor = semanticModule.computeEmbedding(text)
        return tensor.data.clone()
    }

    companion object {
        const val RAG_SIMILARITY_THRESHOLD = 0.55f // 55% similarity filter
    }

    /**
     * Searches top-K chunks from an in-memory or database list.
     * Strictly enforces the RAG Similarity Threshold: rejects any document with Cosine Similarity < 0.55 (55%).
     */
    suspend fun retrieveRelevant(
        query: String,
        knowledgeItems: List<Triple<Long, String, FloatArray>>, // (id, text, embedding)
        topK: Int = 3,
        threshold: Float = RAG_SIMILARITY_THRESHOLD
    ): List<InjectedContext> = withContext(Dispatchers.Default) {
        if (knowledgeItems.isEmpty()) return@withContext emptyList()

        val queryEmb = semanticModule.computeEmbedding(query)
        val scored = knowledgeItems.map { (id, text, embData) ->
            val embTensor = Tensor(1, embData.size, embData)
            val sim = queryEmb.cosineSimilarity(embTensor)
            InjectedContext(
                docId = id,
                title = "Knowledge #$id",
                content = text,
                similarityScore = sim
            )
        }

        // Filter out any document below 0.55 (55% threshold)
        scored.filter { it.similarityScore >= threshold }
            .sortedByDescending { it.similarityScore }
            .take(topK)
    }

    /**
     * Filters candidate document texts against a query.
     * Prevents retrieval or context injection of any document if Cosine Similarity is below 0.55 (55%).
     */
    fun filterRelevantDocs(
        query: String,
        docs: List<String>,
        threshold: Float = RAG_SIMILARITY_THRESHOLD
    ): List<String> {
        if (docs.isEmpty()) return emptyList()
        val queryEmb = semanticModule.computeEmbedding(query)
        return docs.mapNotNull { doc ->
            val docEmb = semanticModule.computeEmbedding(doc)
            val sim = queryEmb.cosineSimilarity(docEmb)
            if (sim >= threshold) doc to sim else null
        }.sortedByDescending { it.second }.map { it.first }
    }
}
