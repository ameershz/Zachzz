package com.example.core.tensor

import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

interface Optimizer {
    fun step(layers: List<NeuralLayer>)
}

/**
 * Stochastic Gradient Descent with Momentum and Gradient Clipping.
 */
class SgdOptimizer(
    var learningRate: Float = 0.01f,
    var momentum: Float = 0.9f,
    val maxGradNorm: Float = 5.0f
) : Optimizer {
    private val velocityMap = mutableMapOf<Tensor, Tensor>()

    override fun step(layers: List<NeuralLayer>) {
        for (layer in layers) {
            val params = layer.getParameters()
            val grads = layer.getGradients()

            for (i in params.indices) {
                val p = params[i]
                val g = grads[i]

                // Gradient clipping
                val norm = g.l2Norm()
                val scale = if (norm > maxGradNorm && norm > 0f) maxGradNorm / norm else 1.0f

                val v = velocityMap.getOrPut(p) { Tensor.zeros(p.rows, p.cols) }

                for (idx in 0 until p.size) {
                    val clippedGrad = g.data[idx] * scale
                    v.data[idx] = momentum * v.data[idx] + learningRate * clippedGrad
                    p.data[idx] -= v.data[idx]
                }
            }
            layer.resetGradients()
        }
    }
}

/**
 * Adam Optimizer (Adaptive Moment Estimation) for rapid, stable on-device weight convergence.
 */
class AdamOptimizer(
    var learningRate: Float = 0.005f,
    val beta1: Float = 0.9f,
    val beta2: Float = 0.999f,
    val epsilon: Float = 1e-8f
) : Optimizer {
    private var stepCount: Int = 0
    private val mStates = mutableMapOf<Tensor, Tensor>()
    private val vStates = mutableMapOf<Tensor, Tensor>()

    override fun step(layers: List<NeuralLayer>) {
        stepCount++
        val b1Correction = 1.0f - beta1.toDouble().pow(stepCount.toDouble()).toFloat()
        val b2Correction = 1.0f - beta2.toDouble().pow(stepCount.toDouble()).toFloat()

        for (layer in layers) {
            val params = layer.getParameters()
            val grads = layer.getGradients()

            for (i in params.indices) {
                val p = params[i]
                val g = grads[i]

                val m = mStates.getOrPut(p) { Tensor.zeros(p.rows, p.cols) }
                val v = vStates.getOrPut(p) { Tensor.zeros(p.rows, p.cols) }

                for (idx in 0 until p.size) {
                    val gradVal = g.data[idx]
                    // Update biased first moment estimate
                    m.data[idx] = beta1 * m.data[idx] + (1f - beta1) * gradVal
                    // Update biased second raw moment estimate
                    v.data[idx] = beta2 * v.data[idx] + (1f - beta2) * (gradVal * gradVal)

                    // Compute bias-corrected first and second moment estimates
                    val mHat = m.data[idx] / b1Correction
                    val vHat = v.data[idx] / b2Correction

                    // Update parameters
                    p.data[idx] -= (learningRate * mHat) / (sqrt(vHat) + epsilon)
                }
            }
            layer.resetGradients()
        }
    }
}
