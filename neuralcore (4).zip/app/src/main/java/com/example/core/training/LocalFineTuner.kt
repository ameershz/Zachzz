package com.example.core.training

import com.example.core.modules.AiModule
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

data class TrainingProgress(
    val isRunning: Boolean = false,
    val currentEpoch: Int = 0,
    val totalEpochs: Int = 0,
    val currentLoss: Float = 0f,
    val lossHistory: List<Float> = emptyList(),
    val statusMessage: String = "Idle",
    val deltaWeights: Float = 0f
)

/**
 * On-device Trainer & Fine-Tuner running purely in Kotlin coroutines.
 * Enables live supervised gradient updates, loss tracking, and parameter adaptation without cloud.
 */
class LocalFineTuner {

    private val _progress = MutableStateFlow(TrainingProgress())
    val progress: StateFlow<TrainingProgress> = _progress.asStateFlow()

    @Volatile
    private var isCancelled: Boolean = false

    suspend fun train(
        module: AiModule,
        dataset: List<Pair<String, String>>,
        epochs: Int = 25,
        learningRate: Float = 0.008f,
        onEpochEnd: (epoch: Int, loss: Float) -> Unit = { _, _ -> }
    ): List<Float> = withContext(Dispatchers.Default) {
        if (dataset.isEmpty()) return@withContext emptyList()

        isCancelled = false
        val lossHistory = mutableListOf<Float>()

        _progress.value = TrainingProgress(
            isRunning = true,
            currentEpoch = 0,
            totalEpochs = epochs,
            currentLoss = 0.5f,
            lossHistory = emptyList(),
            statusMessage = "Initializing on-device adaptive gradient descent for ${module.type.title}..."
        )

        val statsBefore = module.getStats()

        for (epoch in 1..epochs) {
            if (isCancelled) {
                _progress.value = _progress.value.copy(
                    isRunning = false,
                    statusMessage = "Training interrupted by user."
                )
                break
            }

            // Adaptive Learning Rate: Warmup + Cosine Annealing decay
            val scheduledLr = computeScheduledLearningRate(learningRate, epoch, epochs)

            var epochLossSum = 0f
            for ((input, target) in dataset) {
                if (isCancelled) break
                val stepLoss = module.trainStep(input, target, scheduledLr)
                epochLossSum += stepLoss
            }

            val avgEpochLoss = epochLossSum / dataset.size
            lossHistory.add(avgEpochLoss)

            val statsNow = module.getStats()
            val weightDelta = kotlin.math.abs(statsNow.meanWeightValue - statsBefore.meanWeightValue)

            _progress.value = TrainingProgress(
                isRunning = true,
                currentEpoch = epoch,
                totalEpochs = epochs,
                currentLoss = avgEpochLoss,
                lossHistory = lossHistory.toList(),
                statusMessage = "Epoch $epoch/$epochs • Loss: ${"%.4f".format(avgEpochLoss)} • LR: ${"%.5f".format(scheduledLr)}",
                deltaWeights = weightDelta
            )

            onEpochEnd(epoch, avgEpochLoss)
        }

        _progress.value = _progress.value.copy(
            isRunning = false,
            statusMessage = "Training completed! Model weights converged on device."
        )

        lossHistory
    }

    fun stop() {
        isCancelled = true
    }

    companion object {
        /**
         * Adaptive Learning Rate Scheduler:
         * 1. Linear Warmup (first 10-15% of epochs) to stabilize initial gradients.
         * 2. Cosine Annealing Decay down to 10% base LR to allow precise parameter convergence.
         */
        fun computeScheduledLearningRate(baseLr: Float, currentEpoch: Int, totalEpochs: Int): Float {
            if (totalEpochs <= 1) return baseLr
            val warmupEpochs = kotlin.math.min(3, kotlin.math.max(1, totalEpochs / 6))
            if (currentEpoch <= warmupEpochs) {
                // Linear Warmup: ramp up from 30% of baseLr to 100% of baseLr
                val warmupFactor = 0.3f + 0.7f * (currentEpoch.toFloat() / warmupEpochs)
                return (baseLr * warmupFactor).coerceAtLeast(1e-5f)
            }
            // Cosine Annealing Decay
            val decayEpochs = kotlin.math.max(1, totalEpochs - warmupEpochs)
            val progress = ((currentEpoch - warmupEpochs).toFloat() / decayEpochs).coerceIn(0f, 1f)
            val minLr = baseLr * 0.10f
            val cosineDecay = 0.5f * (1.0f + kotlin.math.cos(Math.PI * progress).toFloat())
            return (minLr + (baseLr - minLr) * cosineDecay).coerceAtLeast(1e-5f)
        }
    }
}
