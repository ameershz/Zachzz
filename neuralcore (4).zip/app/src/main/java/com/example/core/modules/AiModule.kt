package com.example.core.modules

import com.example.core.tensor.Tensor

data class InferenceRequest(
    val prompt: String,
    val temperature: Float = 0.7f,
    val topK: Int = 5,
    val maxTokens: Int = 48,
    val contextDocs: List<String> = emptyList(),
    val confidenceThreshold: Float = 0.5f
)

data class InferenceResponse(
    val outputText: String,
    val reasoningChain: List<String> = emptyList(),
    val tokensGenerated: Int,
    val latencyMs: Long,
    val tokensPerSecond: Float,
    val confidence: Float,
    val embeddingVector: FloatArray? = null,
    val contextUsed: List<String> = emptyList()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as InferenceResponse
        return outputText == other.outputText && latencyMs == other.latencyMs
    }

    override fun hashCode(): Int {
        return outputText.hashCode() + latencyMs.hashCode()
    }
}

data class ModelStats(
    val parameterCount: Int,
    val layerCount: Int,
    val memorySizeBytes: Long,
    val averageLoss: Float,
    val trainedEpochs: Int,
    val weightSparsityPercent: Float,
    val meanWeightValue: Float,
    val stdDevWeightValue: Float
)

/**
 * Base contract for modular, swappable on-device AI modules.
 */
interface AiModule {
    val type: ModuleType

    /**
     * Executes local inference on CPU without internet.
     */
    suspend fun process(request: InferenceRequest): InferenceResponse

    /**
     * Performs an on-device local supervised gradient update.
     * Returns the computed loss for this training step.
     */
    suspend fun trainStep(input: String, target: String, learningRate: Float = 0.01f): Float

    /**
     * Returns runtime parameter stats, memory footprint, and weight metrics.
     */
    fun getStats(): ModelStats

    /**
     * Serializes model weights to JSON for Room storage / checkpointing.
     */
    fun exportWeights(): String

    /**
     * Restores model weights from JSON checkpoint.
     */
    fun importWeights(serialized: String): Boolean

    /**
     * Resets weights to initial base state.
     */
    fun resetWeights()
}
