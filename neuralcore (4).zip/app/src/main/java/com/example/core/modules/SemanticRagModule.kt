package com.example.core.modules

import com.example.core.tensor.AdamOptimizer
import com.example.core.tensor.ArabicBpeTokenizer
import com.example.core.tensor.LinearLayer
import com.example.core.tensor.Tensor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * On-device Semantic Vector Embedding and Retrieval-Augmented Generation (RAG) Core.
 * Computes high-dimensional vector representations, ranks document similarities via cosine distance,
 * and produces grounded responses from local knowledge.
 *
 * Strictly enforces a Cosine Similarity Threshold of 0.55 (55%) to reject irrelevant context.
 */
class SemanticRagModule(
    val embeddingDim: Int = 48,
    val tokenizer: ArabicBpeTokenizer = ArabicBpeTokenizer()
) : AiModule {

    companion object {
        const val RAG_SIMILARITY_THRESHOLD = 0.55f // 55% similarity filter
    }

    override val type: ModuleType = ModuleType.SEMANTIC_RAG

    // Embedding projection tensor layers
    private var projLayer1 = LinearLayer(tokenizer.maxVocabSize, embeddingDim, Random(441))
    private var projLayer2 = LinearLayer(embeddingDim, embeddingDim, Random(442))
    private val optimizer = AdamOptimizer(learningRate = 0.008f)

    private var trainedEpochs: Int = 0
    private var lastLoss: Float = 0.28f

    override suspend fun process(request: InferenceRequest): InferenceResponse = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val queryEmbedding = computeEmbedding(request.prompt)
        val reasoning = mutableListOf<String>()

        reasoning.add("Computed ${embeddingDim}D query vector (L2 norm: ${"%.3f".format(queryEmbedding.l2Norm())})")

        // Search candidate context documents with strict 0.55 (55%) Cosine Similarity filter
        val matchedDocs = mutableListOf<Pair<String, Float>>()
        var rejectedCount = 0
        if (request.contextDocs.isNotEmpty()) {
            for (doc in request.contextDocs) {
                val docEmb = computeEmbedding(doc)
                val similarity = queryEmbedding.cosineSimilarity(docEmb)
                if (similarity >= RAG_SIMILARITY_THRESHOLD) {
                    matchedDocs.add(doc to similarity)
                } else {
                    rejectedCount++
                }
            }
            matchedDocs.sortByDescending { it.second }
        }

        val topDocs = matchedDocs.take(3)
        val isArabic = ArabicBpeTokenizer.isArabic(request.prompt)

        if (topDocs.isEmpty()) {
            if (request.contextDocs.isNotEmpty()) {
                reasoning.add(
                    if (isArabic) "تم استبعاد $rejectedCount وثيقة (أقل من عتبة التشابه 0.55 / 55%) لمنع السياق غير الدقيق"
                    else "Excluded $rejectedCount documents below 0.55 (55%) similarity threshold to prevent hallucination"
                )
            } else {
                reasoning.add(if (isArabic) "لا توجد وثائق سياق محلية مقدمة" else "No candidate context documents provided")
            }
        } else {
            for ((doc, sim) in topDocs) {
                val preview = if (doc.length > 50) doc.take(47) + "..." else doc
                reasoning.add(
                    if (isArabic) "تطابق دلالي موثق [${"%.2f".format(sim)} >= 0.55]: \"$preview\""
                    else "Cosine match [${"%.2f".format(sim)} >= 0.55]: \"$preview\""
                )
            }
            if (rejectedCount > 0) {
                reasoning.add(
                    if (isArabic) "تم حجب $rejectedCount وثيقة إضافية أقل من عتبة 55%"
                    else "Filtered out $rejectedCount candidate documents below 55% similarity"
                )
            }
        }

        // Formulate synthesized response based on matched context (guaranteed >= 55% threshold)
        val output = buildString {
            if (isArabic) {
                if (topDocs.isNotEmpty()) {
                    append("تم العثور على تطابق دلالي محلي موثوق (${"%.1f".format(topDocs[0].second * 100)}% صلة دلالية >= 55%):\n\n")
                    append(topDocs[0].first.trim())
                    if (topDocs.size > 1) {
                        append("\n\nسياق إضافي معتمد (>= 55%):\n• ").append(topDocs[1].first.trim())
                    }
                } else {
                    append("الملف الدلالي المحلي للنواة العصبية:\n")
                    append("تم إسقاط الاستعلام في الفضاء الشعاعي بـ ${embeddingDim} بُعداً.\n")
                    append("ملاحظة العتبة: لم تتجاوز أي وثيقة عتبة التشابه الدلالي (0.55 / 55%). تم منع حقن السياق لحماية دقة الاستجابة.\n")
                    append("الاستنتاج: تمت المعالجة محلياً عبر معالج الجهاز وبدون إنترنت.")
                }
            } else {
                if (topDocs.isNotEmpty()) {
                    append("Semantic RAG match verified (${"%.1f".format(topDocs[0].second * 100)}% cosine relevance >= 55%):\n\n")
                    append(topDocs[0].first.trim())
                    if (topDocs.size > 1) {
                        append("\n\nRelated Knowledge (>= 55%):\n• ").append(topDocs[1].first.trim())
                    }
                } else {
                    append("Synthesized Semantic Profile:\n")
                    append("Threshold Check: Candidate documents did not meet the >= 0.55 (55%) similarity threshold. Unrelated context injection suppressed.\n")
                    append("Input vector clustered near: [")
                    val topFeatures = queryEmbedding.data.indices
                        .sortedByDescending { kotlin.math.abs(queryEmbedding.data[it]) }
                        .take(4)
                        .joinToString(", ") { "dim_$it: ${"%.2f".format(queryEmbedding.data[it])}" }
                    append(topFeatures).append("]\n")
                    append("Inference: Query processed through local vector space with zero internet connectivity.")
                }
            }
        }

        val latency = max(1L, System.currentTimeMillis() - startTime)
        val tokensEstimated = output.split(" ").size
        val tps = (tokensEstimated.toFloat() / (latency / 1000f)).coerceAtLeast(1.0f)

        InferenceResponse(
            outputText = output,
            reasoningChain = reasoning,
            tokensGenerated = tokensEstimated,
            latencyMs = latency,
            tokensPerSecond = tps,
            confidence = if (topDocs.isNotEmpty()) topDocs[0].second.coerceIn(0.5f, 0.98f) else 0.75f,
            embeddingVector = queryEmbedding.data.clone(),
            contextUsed = topDocs.map { it.first }
        )
    }

    /**
     * Projects token bag-of-words through linear projection into dense unit-norm embedding
     */
    fun computeEmbedding(text: String): Tensor {
        val tokens = tokenizer.encode(text)
        val bow = FloatArray(projLayer1.inFeatures)
        if (tokens.isEmpty()) {
            bow[ArabicBpeTokenizer.PAD_ID] = 1.0f
        } else {
            val weight = 1.0f / sqrt(tokens.size.toFloat())
            for (t in tokens) {
                val safeT = t % projLayer1.inFeatures
                bow[safeT] += weight
            }
        }
        val inTensor = Tensor(1, projLayer1.inFeatures, bow)
        val h1 = projLayer1.forward(inTensor).relu()
        val h2 = projLayer2.forward(h1)
        return h2.normalized()
    }

    override suspend fun trainStep(input: String, target: String, learningRate: Float): Float = withContext(Dispatchers.Default) {
        optimizer.learningRate = learningRate
        val inEmb = computeEmbedding(input)
        val targetEmb = computeEmbedding(target)

        // Loss: 1 - cosine_similarity (pushes aligned pairs closer together in vector space)
        val sim = inEmb.cosineSimilarity(targetEmb)
        val loss = (1.0f - sim).coerceAtLeast(0.0f)

        // Gradient backprop
        val diff = Tensor(1, embeddingDim, FloatArray(embeddingDim) { i -> inEmb[i] - targetEmb[i] })
        val gradH1 = projLayer2.backward(diff)
        projLayer1.backward(gradH1)

        optimizer.step(listOf(projLayer2, projLayer1))

        trainedEpochs++
        lastLoss = (lastLoss * 0.8f) + (loss * 0.2f)
        lastLoss
    }

    override fun getStats(): ModelStats {
        val totalParams = (projLayer1.weights.size + projLayer1.bias.size) +
                (projLayer2.weights.size + projLayer2.bias.size)

        var zeroCount = 0
        var sum = 0.0
        val allWeights = projLayer1.weights.data + projLayer2.weights.data
        for (w in allWeights) {
            if (kotlin.math.abs(w) < 1e-4f) zeroCount++
            sum += w
        }
        val mean = (sum / allWeights.size).toFloat()

        var sumSq = 0.0
        for (w in allWeights) {
            val d = w - mean
            sumSq += d * d
        }
        val std = sqrt(sumSq / allWeights.size).toFloat()

        return ModelStats(
            parameterCount = totalParams,
            layerCount = 2,
            memorySizeBytes = totalParams * 4L,
            averageLoss = lastLoss,
            trainedEpochs = trainedEpochs,
            weightSparsityPercent = (zeroCount.toFloat() / allWeights.size) * 100f,
            meanWeightValue = mean,
            stdDevWeightValue = std
        )
    }

    override fun exportWeights(): String {
        val obj = JSONObject()
        obj.put("module", type.name)
        obj.put("epochs", trainedEpochs)
        obj.put("loss", lastLoss.toDouble())
        return obj.toString()
    }

    override fun importWeights(serialized: String): Boolean {
        return try {
            val obj = JSONObject(serialized)
            trainedEpochs = obj.optInt("epochs", 0)
            lastLoss = obj.optDouble("loss", 0.3).toFloat()
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun resetWeights() {
        projLayer1 = LinearLayer(tokenizer.vocabSize + 20, embeddingDim, Random(441))
        projLayer2 = LinearLayer(embeddingDim, embeddingDim, Random(442))
        trainedEpochs = 0
        lastLoss = 0.32f
    }
}
