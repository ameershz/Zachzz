package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.ChatDao
import com.example.data.dao.CheckpointDao
import com.example.data.dao.KnowledgeDao
import com.example.data.dao.TrainingDao
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.KnowledgeDocEntity
import com.example.data.entity.ModelCheckpointEntity
import com.example.data.entity.TrainingSampleEntity

@Database(
    entities = [
        ChatMessageEntity::class,
        ModelCheckpointEntity::class,
        TrainingSampleEntity::class,
        KnowledgeDocEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun chatDao(): ChatDao
    abstract fun checkpointDao(): CheckpointDao
    abstract fun trainingDao(): TrainingDao
    abstract fun knowledgeDao(): KnowledgeDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "neural_core.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
