package com.example.data

import com.example.core.modules.ModuleType
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.KnowledgeDocEntity
import com.example.data.entity.ModelCheckpointEntity
import com.example.data.entity.TrainingSampleEntity
import kotlinx.coroutines.flow.Flow

class NeuralCoreRepository(private val database: AppDatabase) {

    val chatMessages: Flow<List<ChatMessageEntity>> = database.chatDao().getAllMessages()
    val knowledgeDocuments: Flow<List<KnowledgeDocEntity>> = database.knowledgeDao().getAllDocuments()

    fun getTrainingSamples(moduleType: String): Flow<List<TrainingSampleEntity>> =
        database.trainingDao().getSamplesForModule(moduleType)

    fun getCheckpoints(moduleType: String): Flow<List<ModelCheckpointEntity>> =
        database.checkpointDao().getCheckpointsForModule(moduleType)

    suspend fun saveMessage(message: ChatMessageEntity): Long =
        database.chatDao().insertMessage(message)

    suspend fun clearHistory() =
        database.chatDao().clearHistory()

    suspend fun saveDocument(title: String, content: String, vector: FloatArray): Long {
        val vectorStr = vector.joinToString(",")
        val doc = KnowledgeDocEntity(
            title = title,
            rawContent = content,
            embeddingVectorStr = vectorStr
        )
        return database.knowledgeDao().insertDocument(doc)
    }

    suspend fun saveDocuments(docs: List<KnowledgeDocEntity>) =
        database.knowledgeDao().insertAll(docs)

    suspend fun deleteDocument(id: Long) =
        database.knowledgeDao().deleteDocument(id)

    suspend fun addTrainingSample(moduleType: String, input: String, target: String): Long {
        val sample = TrainingSampleEntity(
            moduleType = moduleType,
            inputPrompt = input,
            targetOutput = target
        )
        return database.trainingDao().insertSample(sample)
    }

    suspend fun saveTrainingSamples(samples: List<TrainingSampleEntity>) =
        database.trainingDao().insertAll(samples)

    suspend fun deleteTrainingSample(id: Long) =
        database.trainingDao().deleteSample(id)

    suspend fun updateSampleLoss(id: Long, loss: Float) =
        database.trainingDao().updateLoss(id, loss)

    suspend fun saveCheckpoint(checkpoint: ModelCheckpointEntity): Long =
        database.checkpointDao().insertCheckpoint(checkpoint)

    suspend fun deleteCheckpoint(id: Long) =
        database.checkpointDao().deleteCheckpoint(id)

    suspend fun seedInitialDataIfEmpty(vectorGenerator: (String) -> FloatArray) {
        if (database.knowledgeDao().getDocumentCount() == 0) {
            val defaultDocs = listOf(
                "NeuralCore Architecture" to "NeuralCore operates 100% on-device on Android without external APIs or cloud dependence. Features dense tensor matrix operations, custom layer backpropagation, and local vector retrieval.",
                "Energy Efficiency & Thermal Throttling" to "Local inference minimizes battery consumption by executing compact 32-dimensional attention projections and INT8 quantized tensors across ARM CPU cores.",
                "Privacy Invariant" to "All conversational telemetry, fine-tuned weights, and vector indices remain encrypted inside local SQLite Room storage and never leave the device.",
                // Arabic Knowledge Documents
                "بنية نواة الذكاء الاصطناعي (NeuralCore)" to "تعمل نواة NeuralCore محلياً بالكامل على أجهزة أندرويد بدون إنترنت وبدون أي واجهات برمجة سحابية. تدعم عمليات مصفوفات التنسور السريعة والتدريب والتضمين الشعاعي على معالج الهاتف.",
                "الخصوصية والأمان بدون إنترنت" to "تبقى كافة المحادثات والأوزان الدقيقة والتضمينات مشفرة داخل قاعدة بيانات SQLite Room المحلية على الهاتف ولا تخرج منه إطلاقاً.",
                "كفاءة الطاقة والمعالجة المحلية" to "تم تحسين العمليات الرياضية وحسابات الانتباه الذاتي لتعمل بأعلى سرعة وأقل استهلاك لبطارية الهاتف وبدون تسخين المعالج."
            )
            for ((title, content) in defaultDocs) {
                val vec = vectorGenerator(content)
                saveDocument(title, content, vec)
            }

            // Seed initial training samples (English & Arabic)
            val starterSamples = listOf(
                TrainingSampleEntity(
                    moduleType = ModuleType.TEXT_TRANSFORMER.name,
                    inputPrompt = "neural core status",
                    targetOutput = "optimal verified online"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.TEXT_TRANSFORMER.name,
                    inputPrompt = "حالة النظام المحلي",
                    targetOutput = "يعمل محليا بكفاءة وأمان تام"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.TEXT_TRANSFORMER.name,
                    inputPrompt = "local ai performance",
                    targetOutput = "fast high speed cpu tensor"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.TEXT_TRANSFORMER.name,
                    inputPrompt = "الذكاء الاصطناعي على الهاتف",
                    targetOutput = "سريع ومحمي بدون إنترنت"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.PATTERN_CLASSIFIER.name,
                    inputPrompt = "explain the system architecture",
                    targetOutput = "QUERY_KNOWLEDGE"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.PATTERN_CLASSIFIER.name,
                    inputPrompt = "اشرح بنية النظام العصبي",
                    targetOutput = "استعلام_المعرفة"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.PATTERN_CLASSIFIER.name,
                    inputPrompt = "start training epoch with learning rate 0.01",
                    targetOutput = "TRAINING_REQUEST"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.PATTERN_CLASSIFIER.name,
                    inputPrompt = "ابدأ تدريب أوزان النموذج المحلي",
                    targetOutput = "طلب_تدريب"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.REASONING_ENGINE.name,
                    inputPrompt = "Is on-device inference completely private?",
                    targetOutput = "true"
                ),
                TrainingSampleEntity(
                    moduleType = ModuleType.REASONING_ENGINE.name,
                    inputPrompt = "هل المعالجة المحلية على الجهاز آمنة وخاصة بالكامل؟",
                    targetOutput = "صحيح"
                )
            )
            database.trainingDao().insertAll(starterSamples)
        }
    }
}
