package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.ChatMessageEntity
import com.example.data.entity.KnowledgeDocEntity
import com.example.data.entity.ModelCheckpointEntity
import com.example.data.entity.TrainingSampleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearHistory()
}

@Dao
interface CheckpointDao {
    @Query("SELECT * FROM model_checkpoints WHERE moduleType = :moduleType ORDER BY timestamp DESC")
    fun getCheckpointsForModule(moduleType: String): Flow<List<ModelCheckpointEntity>>

    @Query("SELECT * FROM model_checkpoints ORDER BY timestamp DESC")
    fun getAllCheckpoints(): Flow<List<ModelCheckpointEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCheckpoint(checkpoint: ModelCheckpointEntity): Long

    @Query("DELETE FROM model_checkpoints WHERE id = :id")
    suspend fun deleteCheckpoint(id: Long)

    @Query("SELECT * FROM model_checkpoints WHERE moduleType = :moduleType ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestCheckpoint(moduleType: String): ModelCheckpointEntity?
}

@Dao
interface TrainingDao {
    @Query("SELECT * FROM training_samples WHERE moduleType = :moduleType ORDER BY timestamp DESC")
    fun getSamplesForModule(moduleType: String): Flow<List<TrainingSampleEntity>>

    @Query("SELECT * FROM training_samples ORDER BY timestamp DESC")
    fun getAllSamples(): Flow<List<TrainingSampleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSample(sample: TrainingSampleEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(samples: List<TrainingSampleEntity>)

    @Query("DELETE FROM training_samples WHERE id = :id")
    suspend fun deleteSample(id: Long)

    @Query("UPDATE training_samples SET lastLossRecorded = :loss WHERE id = :id")
    suspend fun updateLoss(id: Long, loss: Float)
}

@Dao
interface KnowledgeDao {
    @Query("SELECT * FROM knowledge_documents ORDER BY timestamp DESC")
    fun getAllDocuments(): Flow<List<KnowledgeDocEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(doc: KnowledgeDocEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(documents: List<KnowledgeDocEntity>)

    @Query("DELETE FROM knowledge_documents WHERE id = :id")
    suspend fun deleteDocument(id: Long)

    @Query("SELECT COUNT(*) FROM knowledge_documents")
    suspend fun getDocumentCount(): Int
}
