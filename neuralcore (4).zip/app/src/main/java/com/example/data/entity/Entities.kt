package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val prompt: String,
    val response: String,
    val reasoningChainJson: String,
    val moduleType: String,
    val latencyMs: Long,
    val tokensGenerated: Int,
    val tokensPerSecond: Float,
    val confidence: Float,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "model_checkpoints")
data class ModelCheckpointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val moduleType: String,
    val versionTag: String,
    val serializedWeightsJson: String,
    val parameterCount: Int,
    val epochsTrained: Int,
    val recordedLoss: Float,
    val timestamp: Long = System.currentTimeMillis(),
    val isActive: Boolean = false
)

@Entity(tableName = "training_samples")
data class TrainingSampleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val moduleType: String,
    val inputPrompt: String,
    val targetOutput: String,
    val lastLossRecorded: Float = 0f,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "knowledge_documents")
data class KnowledgeDocEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val rawContent: String,
    val embeddingVectorStr: String, // Comma-delimited float values
    val category: String = "General",
    val timestamp: Long = System.currentTimeMillis()
)
