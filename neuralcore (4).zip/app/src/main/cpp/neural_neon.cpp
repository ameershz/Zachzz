#include <jni.h>
#include <cmath>

#if defined(__ARM_NEON) || defined(__ARM_NEON__)
#include <arm_neon.h>
#endif

extern "C" {

/**
 * High-performance ARM NEON accelerated Matrix Multiplication:
 * C [M x N] = A [M x K] * B [K x N]
 * Optimized with 4-lane float32 SIMD registers and 8-way loop unrolling.
 */
JNIEXPORT void JNICALL
Java_com_example_core_tensor_NativeNeonBridge_neonMatmulNative(
        JNIEnv *env,
        jclass clazz,
        jfloatArray aArray,
        jfloatArray bArray,
        jfloatArray cArray,
        jint m,
        jint kDim,
        jint n) {

    jfloat *a = env->GetFloatArrayElements(aArray, nullptr);
    jfloat *b = env->GetFloatArrayElements(bArray, nullptr);
    jfloat *c = env->GetFloatArrayElements(cArray, nullptr);

#if defined(__ARM_NEON) || defined(__ARM_NEON__)
    // ARM NEON SIMD Accelerated Implementation
    for (int i = 0; i < m; ++i) {
        const float *aRow = &a[i * kDim];
        float *cRow = &c[i * n];

        for (int k = 0; k < kDim; ++k) {
            float aVal = aRow[k];
            if (aVal == 0.0f) continue;

            float32x4_t aVec = vdupq_n_f32(aVal);
            const float *bRow = &b[k * n];

            int j = 0;
            // 8-way SIMD unrolled loop (32 floats per iteration)
            for (; j + 7 < n; j += 8) {
                float32x4_t cVec0 = vld1q_f32(&cRow[j]);
                float32x4_t bVec0 = vld1q_f32(&bRow[j]);
                cVec0 = vmlaq_f32(cVec0, aVec, bVec0);
                vst1q_f32(&cRow[j], cVec0);

                float32x4_t cVec1 = vld1q_f32(&cRow[j + 4]);
                float32x4_t bVec1 = vld1q_f32(&bRow[j + 4]);
                cVec1 = vmlaq_f32(cVec1, aVec, bVec1);
                vst1q_f32(&cRow[j + 4], cVec1);
            }

            // 4-way SIMD loop remainder
            for (; j + 3 < n; j += 4) {
                float32x4_t cVec = vld1q_f32(&cRow[j]);
                float32x4_t bVec = vld1q_f32(&bRow[j]);
                cVec = vmlaq_f32(cVec, aVec, bVec);
                vst1q_f32(&cRow[j], cVec);
            }

            // Scalar remainder
            for (; j < n; ++j) {
                cRow[j] += aVal * bRow[j];
            }
        }
    }
#else
    // Fallback vectorized CPU path for x86/x86_64 host emulators
    for (int i = 0; i < m; ++i) {
        const float *aRow = &a[i * kDim];
        float *cRow = &c[i * n];
        for (int k = 0; k < kDim; ++k) {
            float aVal = aRow[k];
            if (aVal == 0.0f) continue;
            const float *bRow = &b[k * n];
            int j = 0;
            for (; j + 3 < n; j += 4) {
                cRow[j]     += aVal * bRow[j];
                cRow[j + 1] += aVal * bRow[j + 1];
                cRow[j + 2] += aVal * bRow[j + 2];
                cRow[j + 3] += aVal * bRow[j + 3];
            }
            for (; j < n; ++j) {
                cRow[j] += aVal * bRow[j];
            }
        }
    }
#endif

    env->ReleaseFloatArrayElements(aArray, a, JNI_ABORT);
    env->ReleaseFloatArrayElements(bArray, b, JNI_ABORT);
    env->ReleaseFloatArrayElements(cArray, c, 0);
}

}
