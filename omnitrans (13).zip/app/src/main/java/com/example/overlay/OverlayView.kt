package com.example.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.Toast

@SuppressLint("ViewConstructor")
class OverlayView(
    context: Context,
    private val windowManager: WindowManager,
    private val onDismissCallback: () -> Unit
) : View(context) {

    enum class UIState {
        IDLE,
        STATE_SCANNING,
        STATE_DETECTION,
        STATE_TRANSLATION
    }

    private var currentState: UIState = UIState.IDLE
    private var isAttached = false

    private var detectedBoxes: List<Rect> = emptyList()
    private var translatedBlocks: List<InPlaceTranslatedBlock> = emptyList()

    private var bitmapWidth: Int = 1080
    private var bitmapHeight: Int = 1920

    // 1. System Window Insets Tracking (Top status bar & Left navigation bar padding)
    private var insetLeft: Float = 0f
    private var insetTop: Float = 0f

    private var onOpenDetailCardAction: ((String, String) -> Unit)? = null

    // Cache of corrected hit rects for touch & click interaction
    private val scaledHitRects = mutableListOf<Pair<RectF, InPlaceTranslatedBlock>>()

    // State 1: Scanning Animation
    private var scanProgress: Float = 0f
    private var scanAnimator: ValueAnimator? = null

    private val scanLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        strokeWidth = dpToPx(2.5f)
        style = Paint.Style.STROKE
    }

    private val scanGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    // State 2: Green Detection Border Paint (#00FF66, 2dp Stroke)
    private val greenBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpToPx(2f)
        color = Color.parseColor("#00FF66")
    }

    private val greenFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#2200FF66")
    }

    // State 3: Solid Dark Mask Background (#121212 / #1A1A2E)
    private val bgMaskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#F2121212")
    }

    // Arabic text paint with RTL formatting support
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
    }

    // Top Action Bar Rects
    private val topBarRect = RectF()
    private val copyBtnRect = RectF()
    private val cardBtnRect = RectF()
    private val closeBtnRect = RectF()

    private val topBarBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F21A1A2E")
        style = Paint.Style.FILL
    }

    private val btnBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    // Swipe-Up to Dismiss (Gesture Control)
    private val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onFling(
            e1: MotionEvent?,
            e2: MotionEvent,
            velocityX: Float,
            velocityY: Float
        ): Boolean {
            if (e1 == null) return false
            val diffY = e2.y - e1.y
            if (diffY < -80 || velocityY < -600f) {
                triggerDismissAnimation()
                return true
            }
            return false
        }
    })

    init {
        fitsSystemWindows = false

        // 1. Capture exact system window insets
        setOnApplyWindowInsetsListener { _, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val systemInsets = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                insetLeft = systemInsets.left.toFloat()
                insetTop = systemInsets.top.toFloat()
            } else {
                @Suppress("DEPRECATION")
                insetLeft = insets.systemWindowInsetLeft.toFloat()
                @Suppress("DEPRECATION")
                insetTop = insets.systemWindowInsetTop.toFloat()
            }
            post { invalidate() }
            insets
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration?) {
        super.onConfigurationChanged(newConfig)
        post {
            requestApplyInsets()
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        invalidate()
    }

    // ==========================================
    // STATE_SCANNING: Start Top-to-Bottom Laser
    // ==========================================
    fun startScanning(bmpWidth: Int, bmpHeight: Int) {
        this.bitmapWidth = bmpWidth.coerceAtLeast(1)
        this.bitmapHeight = bmpHeight.coerceAtLeast(1)
        this.currentState = UIState.STATE_SCANNING
        this.detectedBoxes = emptyList()
        this.translatedBlocks = emptyList()
        this.translationY = 0f
        this.alpha = 1f

        attachToWindow()

        scanAnimator?.cancel()
        scanAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.RESTART
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                scanProgress = animator.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    // ==========================================
    // STATE_DETECTION: Draw Green Borders
    // ==========================================
    fun showDetected(boxes: List<Rect>, bmpWidth: Int, bmpHeight: Int) {
        scanAnimator?.cancel()
        this.bitmapWidth = bmpWidth.coerceAtLeast(1)
        this.bitmapHeight = bmpHeight.coerceAtLeast(1)
        this.detectedBoxes = boxes
        this.currentState = UIState.STATE_DETECTION

        attachToWindow()
        invalidate()
    }

    // ==========================================
    // STATE_TRANSLATION: Mask + Centered Arabic
    // ==========================================
    fun showTranslated(
        blocks: List<InPlaceTranslatedBlock>,
        bmpWidth: Int,
        bmpHeight: Int,
        onOpenDetailCard: (String, String) -> Unit
    ) {
        scanAnimator?.cancel()
        this.bitmapWidth = bmpWidth.coerceAtLeast(1)
        this.bitmapHeight = bmpHeight.coerceAtLeast(1)
        this.translatedBlocks = blocks
        this.onOpenDetailCardAction = onOpenDetailCard
        this.currentState = UIState.STATE_TRANSLATION

        attachToWindow()
        invalidate()
    }

    // ==========================================
    // 2. Inset-Corrected Bounding Box Formula
    // ==========================================
    private fun transformBoundingBox(ocrRect: Rect, scaleX: Float, scaleY: Float): RectF {
        val mappedLeft = (ocrRect.left * scaleX) - insetLeft
        val mappedTop = (ocrRect.top * scaleY) - insetTop
        val mappedRight = (ocrRect.right * scaleX) - insetLeft
        val mappedBottom = (ocrRect.bottom * scaleY) - insetTop
        return RectF(mappedLeft, mappedTop, mappedRight, mappedBottom)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val viewW = if (width > 0) width.toFloat() else context.resources.displayMetrics.widthPixels.toFloat()
        val viewH = if (height > 0) height.toFloat() else context.resources.displayMetrics.heightPixels.toFloat()

        val scaleX = viewW / bitmapWidth.toFloat()
        val scaleY = viewH / bitmapHeight.toFloat()

        when (currentState) {
            UIState.STATE_SCANNING -> {
                drawScanningEffect(canvas, viewW, viewH)
            }
            UIState.STATE_DETECTION -> {
                drawDetectionState(canvas, scaleX, scaleY, viewW, viewH)
            }
            UIState.STATE_TRANSLATION -> {
                drawTranslationState(canvas, scaleX, scaleY, viewW, viewH)
            }
            UIState.IDLE -> {}
        }
    }

    // ----------------------------------------------------
    // STATE_SCANNING: Laser Line with Glow
    // ----------------------------------------------------
    private fun drawScanningEffect(canvas: Canvas, canvasW: Float, canvasH: Float) {
        val lineY = scanProgress * canvasH
        val glowHeight = dpToPx(40f)

        val gradient = LinearGradient(
            0f, lineY - glowHeight,
            0f, lineY,
            Color.TRANSPARENT,
            Color.parseColor("#4400E5FF"),
            Shader.TileMode.CLAMP
        )
        scanGlowPaint.shader = gradient
        canvas.drawRect(0f, (lineY - glowHeight).coerceAtLeast(0f), canvasW, lineY, scanGlowPaint)

        canvas.drawLine(0f, lineY, canvasW, lineY, scanLinePaint)
        drawCenterPill(canvas, canvasW, "🔍 جارِ مسح وترجمة الشاشة...")
    }

    // ----------------------------------------------------
    // STATE_DETECTION: 2dp Thin Green Borders
    // ----------------------------------------------------
    private fun drawDetectionState(
        canvas: Canvas,
        scaleX: Float,
        scaleY: Float,
        canvasW: Float,
        canvasH: Float
    ) {
        val cornerRadius = dpToPx(3f)

        for (rawBox in detectedBoxes) {
            val correctedRect = transformBoundingBox(rawBox, scaleX, scaleY)
            correctedRect.left = correctedRect.left.coerceIn(0f, canvasW)
            correctedRect.top = correctedRect.top.coerceIn(0f, canvasH)
            correctedRect.right = correctedRect.right.coerceIn(0f, canvasW)
            correctedRect.bottom = correctedRect.bottom.coerceIn(0f, canvasH)

            canvas.drawRoundRect(correctedRect, cornerRadius, cornerRadius, greenFillPaint)
            canvas.drawRoundRect(correctedRect, cornerRadius, cornerRadius, greenBorderPaint)
        }

        drawCenterPill(canvas, canvasW, "✨ تم اكتشاف ${detectedBoxes.size} نصوص • جارِ الترجمة...")
    }

    // ----------------------------------------------------
    // STATE_TRANSLATION: Dark Solid Mask + Centered Arabic
    // ----------------------------------------------------
    private fun drawTranslationState(
        canvas: Canvas,
        scaleX: Float,
        scaleY: Float,
        canvasW: Float,
        canvasH: Float
    ) {
        if (translatedBlocks.isEmpty()) return

        scaledHitRects.clear()
        val cornerRadius = dpToPx(3f)

        for (block in translatedBlocks) {
            val rawBox = block.boundingBox

            // Precise Inset-Corrected Bounding Box
            val correctedRect = transformBoundingBox(rawBox, scaleX, scaleY)

            val boxWidth = (correctedRect.width()).coerceAtLeast(dpToPx(16f))
            val boxHeight = (correctedRect.height()).coerceAtLeast(dpToPx(14f))

            val clampedLeft = correctedRect.left.coerceIn(0f, canvasW - boxWidth)
            val clampedTop = correctedRect.top.coerceIn(0f, canvasH - boxHeight)
            val finalRect = RectF(clampedLeft, clampedTop, clampedLeft + boxWidth, clampedTop + boxHeight)

            scaledHitRects.add(Pair(finalRect, block))

            // 1. Solid Dark Background Mask
            bgMaskPaint.color = if (block.isShowingOriginal) Color.parseColor("#F22D303E") else Color.parseColor("#F2121212")
            canvas.drawRoundRect(finalRect, cornerRadius, cornerRadius, bgMaskPaint)

            // 2. Centered Arabic Text with Dynamic Font Scaling
            val displayText = if (block.isShowingOriginal) block.originalText else block.translatedText
            val horizontalPadding = dpToPx(3f)
            val availableTextWidth = (finalRect.width() - (horizontalPadding * 2)).toInt().coerceAtLeast(10)

            val optimalFontSize = calculateOptimalFontSize(
                text = displayText,
                availableWidth = availableTextWidth,
                availableHeight = (finalRect.height() - dpToPx(2f)).toInt()
            )

            textPaint.textSize = optimalFontSize
            textPaint.color = if (block.isShowingOriginal) Color.parseColor("#FFD54F") else Color.WHITE

            val staticLayout = createStaticLayout(displayText, textPaint, availableTextWidth)

            val layoutHeight = staticLayout.height
            val verticalOffset = finalRect.top + ((finalRect.height() - layoutHeight) / 2f).coerceAtLeast(0f)
            val horizontalOffset = finalRect.left + horizontalPadding

            canvas.save()
            canvas.translate(horizontalOffset, verticalOffset)
            staticLayout.draw(canvas)
            canvas.restore()
        }

        drawTopControlBar(canvas, canvasW)
    }

    private fun drawCenterPill(canvas: Canvas, canvasW: Float, message: String) {
        val pillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E61A1A2E")
            style = Paint.Style.FILL
        }
        val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#4400E5FF")
            style = Paint.Style.STROKE
            strokeWidth = dpToPx(1f)
        }
        textPaint.textSize = dpToPx(12f)
        textPaint.color = Color.parseColor("#00E5FF")

        val textWidth = textPaint.measureText(message)
        val pillW = textWidth + dpToPx(32f)
        val pillH = dpToPx(36f)
        val pillLeft = (canvasW - pillW) / 2f
        val pillTop = dpToPx(48f)
        val pillRect = RectF(pillLeft, pillTop, pillLeft + pillW, pillTop + pillH)

        canvas.drawRoundRect(pillRect, dpToPx(18f), dpToPx(18f), pillPaint)
        canvas.drawRoundRect(pillRect, dpToPx(18f), dpToPx(18f), pillStroke)
        canvas.drawText(message, pillLeft + dpToPx(16f), pillTop + dpToPx(22.5f), textPaint)
    }

    private fun drawTopControlBar(canvas: Canvas, canvasW: Float) {
        val barW = dpToPx(256f)
        val barH = dpToPx(36f)
        val barLeft = (canvasW - barW) / 2f
        val barTop = dpToPx(44f)
        topBarRect.set(barLeft, barTop, barLeft + barW, barTop + barH)

        canvas.drawRoundRect(topBarRect, dpToPx(18f), dpToPx(18f), topBarBgPaint)

        textPaint.textSize = dpToPx(11f)
        textPaint.color = Color.parseColor("#00E5FF")
        val countStr = "⚡ ${translatedBlocks.size} • ⬆ اسحب للإغلاق"
        canvas.drawText(countStr, barLeft + dpToPx(12f), barTop + dpToPx(22.5f), textPaint)

        val btnH = dpToPx(24f)
        val btnY = barTop + (barH - btnH) / 2f

        // Copy Button
        val copyW = dpToPx(46f)
        val copyX = barLeft + barW - dpToPx(96f)
        copyBtnRect.set(copyX, btnY, copyX + copyW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#3300FF66")
        canvas.drawRoundRect(copyBtnRect, dpToPx(12f), dpToPx(12f), btnBgPaint)
        textPaint.textSize = dpToPx(10f)
        textPaint.color = Color.parseColor("#00FF66")
        canvas.drawText("نسخ", copyX + dpToPx(13f), btnY + dpToPx(16f), textPaint)

        // Card Button
        val cardW = dpToPx(44f)
        val cardX = copyX + copyW + dpToPx(4f)
        cardBtnRect.set(cardX, btnY, cardX + cardW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#33B388FF")
        canvas.drawRoundRect(cardBtnRect, dpToPx(12f), dpToPx(12f), btnBgPaint)
        textPaint.color = Color.parseColor("#B388FF")
        canvas.drawText("بطاقة", cardX + dpToPx(9f), btnY + dpToPx(16f), textPaint)
    }

    private fun calculateOptimalFontSize(text: CharSequence, availableWidth: Int, availableHeight: Int): Float {
        var sizeSp = when {
            availableHeight >= dpToPx(48f) -> 14f
            availableHeight >= dpToPx(32f) -> 12f
            availableHeight >= dpToPx(22f) -> 10.5f
            availableHeight >= dpToPx(16f) -> 9.5f
            else -> 8.5f
        }

        var pxSize = dpToPx(sizeSp)
        textPaint.textSize = pxSize

        for (i in 0 until 4) {
            val layout = createStaticLayout(text, textPaint, availableWidth)
            if (layout.height <= availableHeight || sizeSp <= 7.5f) {
                break
            }
            sizeSp -= 1f
            pxSize = dpToPx(sizeSp)
            textPaint.textSize = pxSize
        }

        return pxSize
    }

    private fun createStaticLayout(text: CharSequence, paint: TextPaint, width: Int): StaticLayout {
        val safeWidth = width.coerceAtLeast(10)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, safeWidth)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, 1.0f)
                .setIncludePad(false)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(
                text,
                paint,
                safeWidth,
                Layout.Alignment.ALIGN_CENTER,
                1.0f,
                0f,
                false
            )
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (gestureDetector.onTouchEvent(event)) {
            return true
        }

        if (event.action == MotionEvent.ACTION_UP) {
            val x = event.x
            val y = event.y

            if (copyBtnRect.contains(x, y)) {
                val fullAr = translatedBlocks.joinToString("\n\n") { it.translatedText }
                copyToClipboard("Translations", fullAr)
                Toast.makeText(context, "تم نسخ جميع الترجمات (${translatedBlocks.size})", Toast.LENGTH_SHORT).show()
                return true
            }

            if (cardBtnRect.contains(x, y)) {
                val fullEn = translatedBlocks.joinToString("\n\n") { it.originalText }
                val fullAr = translatedBlocks.joinToString("\n\n") { it.translatedText }
                dismiss()
                onOpenDetailCardAction?.invoke(fullEn, fullAr)
                return true
            }

            if (topBarRect.contains(x, y)) {
                return true
            }

            for ((rectF, block) in scaledHitRects) {
                if (rectF.contains(x, y)) {
                    block.isShowingOriginal = !block.isShowingOriginal
                    invalidate()
                    return true
                }
            }

            triggerDismissAnimation()
            return true
        }
        return true
    }

    fun triggerDismissAnimation() {
        if (!isAttached) return
        animate()
            .translationY(-height.toFloat().coerceAtLeast(dpToPx(600f)))
            .alpha(0f)
            .setDuration(260)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction {
                dismiss()
            }
            .start()
    }

    // 3. WindowManager Setup
    private fun attachToWindow() {
        if (isAttached) return

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        try {
            windowManager.addView(this, layoutParams)
            isAttached = true
            requestApplyInsets()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismiss() {
        scanAnimator?.cancel()
        scanAnimator = null
        if (isAttached) {
            try {
                windowManager.removeView(this)
            } catch (_: Exception) {}
            isAttached = false
            currentState = UIState.IDLE
            detectedBoxes = emptyList()
            translatedBlocks = emptyList()
            scaledHitRects.clear()
            translationY = 0f
            alpha = 1f
            onDismissCallback()
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    private fun dpToPx(dp: Float): Float {
        return dp * context.resources.displayMetrics.density
    }

    fun isShowing(): Boolean = isAttached && currentState != UIState.IDLE
}
