package com.example.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast

@SuppressLint("ViewConstructor")
class InPlaceOverlayCanvasView(
    context: Context,
    private val windowManager: WindowManager,
    private val onDismissCallback: () -> Unit
) : View(context) {

    private var isAttached = false
    private var translatedBlocks: List<InPlaceTranslatedBlock> = emptyList()

    private var bitmapWidth: Int = 1080
    private var bitmapHeight: Int = 1920

    private var onOpenDetailCardAction: ((String, String) -> Unit)? = null

    // Cache of scaled hit rects for touch detection
    private val scaledHitRects = mutableListOf<Pair<RectF, InPlaceTranslatedBlock>>()

    // Paints
    private val scrimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#12000000") // Very subtle contrast scrim
        style = Paint.Style.FILL
    }

    private val bgMaskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F50A0E18") // Solid high-opacity masking background
        style = Paint.Style.FILL
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dpToPx(1.2f)
        color = Color.parseColor("#00E5FF")
    }

    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.DEFAULT_BOLD
    }

    private val tagPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676")
        textSize = dpToPx(9f)
        typeface = Typeface.DEFAULT_BOLD
    }

    // Top Control Bar Rects
    private val topBarRect = RectF()
    private val copyBtnRect = RectF()
    private val cardBtnRect = RectF()
    private val closeBtnRect = RectF()

    private val topBarBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F2090D18")
        style = Paint.Style.FILL
    }

    private val topBarBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3300E5FF")
        style = Paint.Style.STROKE
        strokeWidth = dpToPx(1f)
    }

    private val btnBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun show(
        blocks: List<InPlaceTranslatedBlock>,
        bmpWidth: Int,
        bmpHeight: Int,
        onOpenDetailCard: (String, String) -> Unit
    ) {
        this.translatedBlocks = blocks
        this.bitmapWidth = bmpWidth.coerceAtLeast(1)
        this.bitmapHeight = bmpHeight.coerceAtLeast(1)
        this.onOpenDetailCardAction = onOpenDetailCard

        attachToWindow()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        if (translatedBlocks.isEmpty()) return

        // 1. Draw subtle background scrim
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), scrimPaint)

        // 2. Calculate Exact Coordinate Scaling
        val displayW = width.toFloat()
        val displayH = height.toFloat()
        val scaleX = displayW / bitmapWidth.toFloat()
        val scaleY = displayH / bitmapHeight.toFloat()

        scaledHitRects.clear()

        // 3. Render Each Scaled In-Place Translated Text Box
        val cornerRadius = dpToPx(6f)
        val padX = dpToPx(4f)
        val padY = dpToPx(2f)

        for (block in translatedBlocks) {
            val rawBox = block.boundingBox

            // Scale bounding box coordinates accurately
            val scaledLeft = (rawBox.left * scaleX) - padX
            val scaledTop = (rawBox.top * scaleY) - padY
            val scaledRight = (rawBox.right * scaleX) + padX
            val scaledBottom = (rawBox.bottom * scaleY) + padY

            // Ensure minimum width & height for legibility
            val minW = dpToPx(60f)
            val minH = dpToPx(24f)

            val boxWidth = (scaledRight - scaledLeft).coerceAtLeast(minW)
            val boxHeight = (scaledBottom - scaledTop).coerceAtLeast(minH)

            val clampedLeft = scaledLeft.coerceIn(dpToPx(4f), displayW - boxWidth - dpToPx(4f))
            val clampedTop = scaledTop.coerceIn(dpToPx(60f), displayH - boxHeight - dpToPx(4f))
            val rectF = RectF(clampedLeft, clampedTop, clampedLeft + boxWidth, clampedTop + boxHeight)

            scaledHitRects.add(Pair(rectF, block))

            // A. Draw Masking Background
            bgMaskPaint.color = if (block.isShowingOriginal) Color.parseColor("#F51A1828") else Color.parseColor("#F5090F1C")
            canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, bgMaskPaint)

            // B. Draw Border
            borderPaint.color = if (block.isShowingOriginal) Color.parseColor("#FFD54F") else Color.parseColor("#00E5FF")
            canvas.drawRoundRect(rectF, cornerRadius, cornerRadius, borderPaint)

            // C. Render Translated Text with Auto-Fitted StaticLayout
            val displayText = if (block.isShowingOriginal) block.originalText else block.translatedText
            val availableTextWidth = (rectF.width() - dpToPx(12f)).toInt().coerceAtLeast(20)

            // Dynamic Font Sizing
            val targetFontSizeSp = when {
                rectF.height() >= dpToPx(60f) -> 14f
                rectF.height() >= dpToPx(40f) -> 12.5f
                rectF.height() >= dpToPx(28f) -> 11f
                else -> 9.5f
            }
            textPaint.textSize = dpToPx(targetFontSizeSp)
            textPaint.color = if (block.isShowingOriginal) Color.parseColor("#FFD54F") else Color.WHITE

            val staticLayout = createStaticLayout(displayText, textPaint, availableTextWidth)

            val layoutHeight = staticLayout.height
            val verticalOffset = rectF.top + ((rectF.height() - layoutHeight) / 2f).coerceAtLeast(dpToPx(2f))
            val horizontalOffset = rectF.left + dpToPx(6f)

            canvas.save()
            canvas.translate(horizontalOffset, verticalOffset)
            staticLayout.draw(canvas)
            canvas.restore()

            // D. Draw mini status indicator ("AR" / "EN")
            tagPaint.color = if (block.isShowingOriginal) Color.parseColor("#FFD54F") else Color.parseColor("#00E676")
            val tagText = if (block.isShowingOriginal) "EN" else "AR"
            canvas.drawText(tagText, rectF.right - dpToPx(16f), rectF.bottom - dpToPx(4f), tagPaint)
        }

        // 4. Draw Floating Top Control Bar
        drawTopControlBar(canvas)
    }

    private fun drawTopControlBar(canvas: Canvas) {
        val barW = dpToPx(260f)
        val barH = dpToPx(42f)
        val barLeft = (width - barW) / 2f
        val barTop = dpToPx(38f)
        topBarRect.set(barLeft, barTop, barLeft + barW, barTop + barH)

        // Bar background
        canvas.drawRoundRect(topBarRect, dpToPx(21f), dpToPx(21f), topBarBgPaint)
        canvas.drawRoundRect(topBarRect, dpToPx(21f), dpToPx(21f), topBarBorderPaint)

        // Count Text
        textPaint.textSize = dpToPx(12f)
        textPaint.color = Color.parseColor("#00E5FF")
        val countStr = "⚡ ${translatedBlocks.size}"
        canvas.drawText(countStr, barLeft + dpToPx(14f), barTop + dpToPx(26f), textPaint)

        // Buttons
        val btnH = dpToPx(26f)
        val btnY = barTop + (barH - btnH) / 2f

        // Copy Btn
        val copyW = dpToPx(52f)
        val copyX = barLeft + dpToPx(70f)
        copyBtnRect.set(copyX, btnY, copyX + copyW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#2200E676")
        canvas.drawRoundRect(copyBtnRect, dpToPx(13f), dpToPx(13f), btnBgPaint)
        textPaint.textSize = dpToPx(10.5f)
        textPaint.color = Color.parseColor("#00E676")
        canvas.drawText("نسخ", copyX + dpToPx(16f), btnY + dpToPx(17f), textPaint)

        // Card Btn
        val cardW = dpToPx(56f)
        val cardX = copyX + copyW + dpToPx(6f)
        cardBtnRect.set(cardX, btnY, cardX + cardW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#22B388FF")
        canvas.drawRoundRect(cardBtnRect, dpToPx(13f), dpToPx(13f), btnBgPaint)
        textPaint.color = Color.parseColor("#B388FF")
        canvas.drawText("بطاقة", cardX + dpToPx(14f), btnY + dpToPx(17f), textPaint)

        // Close Btn
        val closeW = dpToPx(34f)
        val closeX = cardX + cardW + dpToPx(6f)
        closeBtnRect.set(closeX, btnY, closeX + closeW, btnY + btnH)
        btnBgPaint.color = Color.parseColor("#22FF5252")
        canvas.drawRoundRect(closeBtnRect, dpToPx(13f), dpToPx(13f), btnBgPaint)
        textPaint.color = Color.parseColor("#FF5252")
        canvas.drawText("✕", closeX + dpToPx(11f), btnY + dpToPx(17f), textPaint)
    }

    private fun createStaticLayout(text: CharSequence, paint: TextPaint, width: Int): StaticLayout {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setLineSpacing(0f, 1.05f)
                .setIncludePad(false)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(
                text,
                paint,
                width,
                Layout.Alignment.ALIGN_CENTER,
                1.05f,
                0f,
                false
            )
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP) {
            val x = event.x
            val y = event.y

            // 1. Check Top Bar Button Clicks
            if (copyBtnRect.contains(x, y)) {
                val fullAr = translatedBlocks.joinToString("\n\n") { it.translatedText }
                copyToClipboard("Translations", fullAr)
                Toast.makeText(context, "تم نسخ جميع الترجمات (${translatedBlocks.size})", Toast.LENGTH_SHORT).show()
                return true
            }

            if (cardBtnRect.contains(x, y)) {
                val fullEn = translatedBlocks.joinToString("\n\n") { it.originalText }
                val fullAr = translatedBlocks.joinToString("\n\n") { it.translatedText }
                dismiss()
                onOpenDetailCardAction?.invoke(fullEn, fullAr)
                return true
            }

            if (closeBtnRect.contains(x, y)) {
                dismiss()
                return true
            }

            if (topBarRect.contains(x, y)) {
                return true // Consume tap on bar
            }

            // 2. Check Click on Individual Translated Bounding Boxes
            for ((rectF, block) in scaledHitRects) {
                if (rectF.contains(x, y)) {
                    block.isShowingOriginal = !block.isShowingOriginal
                    invalidate()
                    return true
                }
            }

            // 3. Tapping anywhere outside blocks closes the overlay
            dismiss()
            return true
        }
        return true
    }

    private fun attachToWindow() {
        if (isAttached) return

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        try {
            windowManager.addView(this, windowParams)
            isAttached = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun dismiss() {
        if (isAttached) {
            try {
                windowManager.removeView(this)
            } catch (_: Exception) {}
            isAttached = false
            translatedBlocks = emptyList()
            scaledHitRects.clear()
            onDismissCallback()
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    private fun dpToPx(dp: Float): Float {
        return dp * context.resources.displayMetrics.density
    }

    fun isShowing(): Boolean = isAttached
}
