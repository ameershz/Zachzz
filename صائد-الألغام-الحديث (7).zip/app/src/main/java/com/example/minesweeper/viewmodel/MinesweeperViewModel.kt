package com.example.minesweeper.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.minesweeper.audio.SoundHapticManager
import com.example.minesweeper.data.PreferencesManager
import com.example.minesweeper.engine.MinesweeperEngine
import com.example.minesweeper.model.AvailableThemes
import com.example.minesweeper.model.BoardDifficulty
import com.example.minesweeper.model.CampaignLevel
import com.example.minesweeper.model.CampaignLevels
import com.example.minesweeper.model.CampaignProgress
import com.example.minesweeper.model.Cell
import com.example.minesweeper.model.DailyStreakState
import com.example.minesweeper.model.DifficultyStats
import com.example.minesweeper.model.GameMode
import com.example.minesweeper.model.GameStatus
import com.example.minesweeper.model.MatchRecord
import com.example.minesweeper.model.MinesweeperTheme
import com.example.minesweeper.model.SettingsState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class ScreenState {
    HOME,
    GAME,
    CAMPAIGN,
    TOURNAMENTS,
    THEMES,
    STATS,
    SETTINGS
}

data class GameUiState(
    val currentScreen: ScreenState = ScreenState.HOME,
    val gameMode: GameMode = GameMode.CLASSIC,
    val difficulty: BoardDifficulty = BoardDifficulty.BEGINNER,
    val customRows: Int = 10,
    val customCols: Int = 10,
    val customMines: Int = 15,
    val isGuessFree: Boolean = false,
    val grid: List<List<Cell>> = emptyList(),
    val gameStatus: GameStatus = GameStatus.NOT_STARTED,
    val remainingMines: Int = 10,
    val timerSeconds: Int = 0,
    val timerLimitSeconds: Int? = null,
    val isFlagMode: Boolean = false,
    val isInteractingWithBoard: Boolean = false,
    val isZoomLocked: Boolean = false,
    val threeBV: Int = 0,
    val threeBVs: Float = 0f,
    val clicksCount: Int = 0,
    val effectiveClicksCount: Int = 0,
    val efficiencyPct: Float = 0f,
    // Campaign specific
    val currentCampaignLevel: CampaignLevel? = null,
    val hasUsedReviveInCurrentGame: Boolean = false,
    val lastExplodedCoord: Pair<Int, Int>? = null,
    // Results dialog
    val showResultDialog: Boolean = false,
    // Tutorial
    val showTutorial: Boolean = false,
    // Settings & State
    val settings: SettingsState = SettingsState(),
    val currentTheme: MinesweeperTheme = AvailableThemes.ClassicRetro,
    val dailyStreak: DailyStreakState = DailyStreakState(),
    val campaignProgress: CampaignProgress = CampaignProgress(),
    val statsBeginner: DifficultyStats = DifficultyStats(),
    val statsIntermediate: DifficultyStats = DifficultyStats(),
    val statsExpert: DifficultyStats = DifficultyStats(),
    val statsCustom: DifficultyStats = DifficultyStats(),
    val matchHistory: List<MatchRecord> = emptyList(),
    val dailyClaimRewardMessage: String? = null,
    val gameId: Int = 0
)

class MinesweeperViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = PreferencesManager(application)
    private val soundHaptic = SoundHapticManager(application)

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private var engine: MinesweeperEngine? = null
    private var timerJob: Job? = null

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        val loadedSettings = prefs.loadSettings()
        val theme = AvailableThemes.getThemeById(loadedSettings.selectedThemeId)
        soundHaptic.soundEnabled = loadedSettings.soundEffectsEnabled
        soundHaptic.hapticEnabled = loadedSettings.hapticFeedbackEnabled

        val streak = prefs.loadDailyStreak()
        val campProgress = prefs.loadCampaignProgress()
        val showTut = !prefs.hasCompletedTutorial()

        _uiState.update {
            it.copy(
                settings = loadedSettings,
                currentTheme = theme,
                dailyStreak = streak,
                campaignProgress = campProgress,
                isZoomLocked = loadedSettings.lockZoomByDefault,
                isGuessFree = loadedSettings.guessFreeOptionEnabled,
                showTutorial = showTut,
                statsBeginner = prefs.loadStats(BoardDifficulty.BEGINNER),
                statsIntermediate = prefs.loadStats(BoardDifficulty.INTERMEDIATE),
                statsExpert = prefs.loadStats(BoardDifficulty.EXPERT),
                statsCustom = prefs.loadStats(BoardDifficulty.CUSTOM),
                matchHistory = prefs.loadMatchHistory()
            )
        }
    }

    fun navigateTo(screen: ScreenState) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun startNewGame(
        difficulty: BoardDifficulty = _uiState.value.difficulty,
        mode: GameMode = GameMode.CLASSIC,
        campaignLevel: CampaignLevel? = null,
        customRows: Int = _uiState.value.customRows,
        customCols: Int = _uiState.value.customCols,
        customMines: Int = _uiState.value.customMines,
        guessFree: Boolean = _uiState.value.isGuessFree
    ) {
        timerJob?.cancel()

        val (defRows, defCols) = difficulty.getDimensions()

        val rows = when {
            campaignLevel != null -> campaignLevel.rows
            difficulty == BoardDifficulty.CUSTOM -> customRows
            else -> defRows
        }
        val cols = when {
            campaignLevel != null -> campaignLevel.cols
            difficulty == BoardDifficulty.CUSTOM -> customCols
            else -> defCols
        }
        val mines = when {
            campaignLevel != null -> campaignLevel.mines
            difficulty == BoardDifficulty.CUSTOM -> customMines
            else -> difficulty.defaultMines
        }

        val newEngine = MinesweeperEngine(
            rows = rows,
            cols = cols,
            totalMines = mines,
            isGuessFreeRequested = guessFree
        )
        engine = newEngine

        _uiState.update {
            it.copy(
                gameId = it.gameId + 1,
                currentScreen = ScreenState.GAME,
                gameMode = mode,
                difficulty = difficulty,
                customRows = customRows,
                customCols = customCols,
                customMines = customMines,
                isGuessFree = guessFree,
                grid = newEngine.grid,
                gameStatus = GameStatus.NOT_STARTED,
                remainingMines = mines,
                timerSeconds = 0,
                timerLimitSeconds = campaignLevel?.targetSeconds ?: if (mode == GameMode.TIMER) 120 else null,
                isFlagMode = false,
                isInteractingWithBoard = false,
                threeBV = 0,
                threeBVs = 0f,
                clicksCount = 0,
                effectiveClicksCount = 0,
                efficiencyPct = 0f,
                currentCampaignLevel = campaignLevel,
                hasUsedReviveInCurrentGame = false,
                lastExplodedCoord = null,
                showResultDialog = false
            )
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                if (_uiState.value.gameStatus == GameStatus.IN_PROGRESS) {
                    val nextTime = _uiState.value.timerSeconds + 1
                    val limit = _uiState.value.timerLimitSeconds

                    if (limit != null && nextTime >= limit) {
                        // Timer ran out!
                        handleTimeOut()
                        break
                    } else {
                        _uiState.update { it.copy(timerSeconds = nextTime) }
                    }
                } else {
                    break
                }
            }
        }
    }

    private fun handleTimeOut() {
        soundHaptic.playExplosionSound()
        _uiState.update {
            it.copy(
                gameStatus = GameStatus.LOST,
                showResultDialog = true
            )
        }
    }

    fun onCellClick(r: Int, c: Int) {
        val eng = engine ?: return
        if (_uiState.value.gameStatus == GameStatus.WON || _uiState.value.gameStatus == GameStatus.LOST) return

        if (_uiState.value.isFlagMode) {
            onCellFlag(r, c)
            return
        }

        val wasFirstClick = eng.isFirstClick
        val result = eng.revealCell(r, c)

        if (wasFirstClick && eng.status == GameStatus.IN_PROGRESS) {
            startTimer()
        }

        handleRevealResult(result, r, c)
    }

    fun setInteractingWithBoard(interacting: Boolean) {
        _uiState.update { it.copy(isInteractingWithBoard = interacting) }
    }

    fun onCellFlag(r: Int, c: Int) {
        val eng = engine ?: return
        if (_uiState.value.gameStatus == GameStatus.WON || _uiState.value.gameStatus == GameStatus.LOST) return

        val flagged = eng.toggleFlag(r, c)
        soundHaptic.playFlagSound()
        updateEngineState()
    }

    fun onCellChord(r: Int, c: Int) {
        val eng = engine ?: return
        if (_uiState.value.gameStatus != GameStatus.IN_PROGRESS) return

        val result = eng.chordCell(r, c)
        soundHaptic.playChordSound()
        handleRevealResult(result, r, c)
    }

    private fun handleRevealResult(result: MinesweeperEngine.RevealResult, r: Int, c: Int) {
        val eng = engine ?: return
        when (result) {
            is MinesweeperEngine.RevealResult.Success -> {
                soundHaptic.playRevealSound()
                updateEngineState()
            }
            is MinesweeperEngine.RevealResult.HitMine -> {
                timerJob?.cancel()
                soundHaptic.playExplosionSound()
                _uiState.update {
                    it.copy(
                        grid = eng.grid,
                        gameStatus = GameStatus.LOST,
                        clicksCount = eng.clicksCount,
                        lastExplodedCoord = r to c,
                        showResultDialog = true
                    )
                }
                saveMatchStats(won = false)
            }
            is MinesweeperEngine.RevealResult.Win -> {
                timerJob?.cancel()
                soundHaptic.playWinSound()
                updateEngineState()
                _uiState.update {
                    it.copy(
                        gameStatus = GameStatus.WON,
                        showResultDialog = true
                    )
                }
                saveMatchStats(won = true)
                handleCampaignWin()
            }
            MinesweeperEngine.RevealResult.NoOp -> {}
        }
    }

    private fun updateEngineState() {
        val eng = engine ?: return
        val timeSec = _uiState.value.timerSeconds
        val threeBV = eng.threeBV
        val threeBVs = if (timeSec > 0 && threeBV > 0) threeBV.toFloat() / timeSec else 0f
        val efficiency = if (eng.clicksCount > 0 && threeBV > 0) (threeBV.toFloat() / eng.clicksCount) * 100f else 0f

        _uiState.update {
            it.copy(
                grid = eng.grid,
                remainingMines = eng.remainingMines,
                gameStatus = eng.status,
                threeBV = threeBV,
                threeBVs = threeBVs,
                clicksCount = eng.clicksCount,
                effectiveClicksCount = eng.effectiveClicksCount,
                efficiencyPct = efficiency
            )
        }
    }

    private fun saveMatchStats(won: Boolean) {
        val st = _uiState.value
        val eng = engine ?: return
        prefs.recordGameResult(
            difficulty = st.difficulty,
            won = won,
            timeSeconds = st.timerSeconds,
            threeBV = eng.threeBV,
            threeBVs = if (st.timerSeconds > 0) eng.threeBV.toFloat() / st.timerSeconds else 0f,
            clicks = eng.clicksCount,
            efficiencyPct = if (eng.clicksCount > 0) (eng.threeBV.toFloat() / eng.clicksCount) * 100f else 0f
        )
        // Refresh local stats
        _uiState.update {
            it.copy(
                statsBeginner = prefs.loadStats(BoardDifficulty.BEGINNER),
                statsIntermediate = prefs.loadStats(BoardDifficulty.INTERMEDIATE),
                statsExpert = prefs.loadStats(BoardDifficulty.EXPERT),
                statsCustom = prefs.loadStats(BoardDifficulty.CUSTOM),
                matchHistory = prefs.loadMatchHistory()
            )
        }
    }

    private fun handleCampaignWin() {
        val currentLvl = _uiState.value.currentCampaignLevel ?: return
        val currentProg = _uiState.value.campaignProgress

        val nextLevel = maxOf(currentProg.unlockedLevel, currentLvl.id + 1)
        val newStars = currentProg.starsPerLevel.toMutableMap()
        newStars[currentLvl.id] = 3 // 3 stars on clearing

        val newProg = currentProg.copy(
            unlockedLevel = nextLevel,
            starsPerLevel = newStars,
            hintsInventory = currentProg.hintsInventory + currentLvl.rewardHints,
            magicWandsInventory = currentProg.magicWandsInventory + currentLvl.rewardWands
        )
        prefs.saveCampaignProgress(newProg)
        _uiState.update { it.copy(campaignProgress = newProg) }
    }

    fun useSmartHint() {
        val eng = engine ?: return
        if (_uiState.value.campaignProgress.hintsInventory <= 0) return

        val hint = eng.useSmartHint()
        if (hint != null) {
            soundHaptic.playBoostSound()
            val newProg = _uiState.value.campaignProgress.copy(
                hintsInventory = _uiState.value.campaignProgress.hintsInventory - 1
            )
            prefs.saveCampaignProgress(newProg)
            _uiState.update {
                it.copy(
                    grid = eng.grid,
                    campaignProgress = newProg
                )
            }
        }
    }

    fun useMagicWand() {
        val eng = engine ?: return
        if (_uiState.value.campaignProgress.magicWandsInventory <= 0) return

        val revealed = eng.useMagicWand()
        if (revealed.isNotEmpty()) {
            soundHaptic.playBoostSound()
            val newProg = _uiState.value.campaignProgress.copy(
                magicWandsInventory = _uiState.value.campaignProgress.magicWandsInventory - 1
            )
            prefs.saveCampaignProgress(newProg)
            updateEngineState()
            _uiState.update { it.copy(campaignProgress = newProg) }
            if (eng.status == GameStatus.WON) {
                timerJob?.cancel()
                soundHaptic.playWinSound()
                _uiState.update { it.copy(showResultDialog = true) }
                saveMatchStats(true)
                handleCampaignWin()
            }
        }
    }

    fun reviveInCampaign(): Boolean {
        val eng = engine ?: return false
        val coord = _uiState.value.lastExplodedCoord ?: return false
        if (_uiState.value.hasUsedReviveInCurrentGame) return false

        val revived = eng.revive(coord.first, coord.second)
        if (revived) {
            _uiState.update {
                it.copy(
                    grid = eng.grid,
                    gameStatus = GameStatus.IN_PROGRESS,
                    hasUsedReviveInCurrentGame = true,
                    showResultDialog = false
                )
            }
            startTimer()
            return true
        }
        return false
    }

    fun toggleFlagMode() {
        _uiState.update { it.copy(isFlagMode = !it.isFlagMode) }
    }

    fun toggleZoomLock() {
        _uiState.update { it.copy(isZoomLocked = !it.isZoomLocked) }
    }

    fun dismissResultDialog() {
        _uiState.update { it.copy(showResultDialog = false) }
    }

    fun isVolumeKeyToggleEnabled(): Boolean {
        return _uiState.value.settings.volumeKeyToggleEnabled
    }

    fun claimDailyReward() {
        val (newStreak, reward) = prefs.claimDailyReward()
        val campProg = prefs.loadCampaignProgress()
        val msg = "تم استلام: +${reward.first} تلميح و +${reward.second} عصا سحرية!"
        _uiState.update {
            it.copy(
                dailyStreak = newStreak,
                campaignProgress = campProg,
                dailyClaimRewardMessage = msg
            )
        }
    }

    fun clearDailyMessage() {
        _uiState.update { it.copy(dailyClaimRewardMessage = null) }
    }

    fun updateSettings(newSettings: SettingsState) {
        val oldSettings = _uiState.value.settings
        prefs.saveSettings(newSettings)
        val theme = AvailableThemes.getThemeById(newSettings.selectedThemeId)
        soundHaptic.soundEnabled = newSettings.soundEffectsEnabled
        soundHaptic.hapticEnabled = newSettings.hapticFeedbackEnabled
        _uiState.update {
            it.copy(
                settings = newSettings,
                currentTheme = theme,
                isGuessFree = newSettings.guessFreeOptionEnabled
            )
        }

        if (oldSettings.portraitExpertOrientation != newSettings.portraitExpertOrientation &&
            _uiState.value.difficulty == BoardDifficulty.EXPERT &&
            _uiState.value.gameStatus == GameStatus.NOT_STARTED
        ) {
            startNewGame(difficulty = BoardDifficulty.EXPERT)
        }
    }

    fun selectTheme(theme: MinesweeperTheme) {
        val updated = _uiState.value.settings.copy(selectedThemeId = theme.id)
        updateSettings(updated)
    }

    fun completeTutorial() {
        prefs.setTutorialCompleted(true)
        _uiState.update { it.copy(showTutorial = false) }
    }

    fun showTutorialAgain() {
        _uiState.update { it.copy(showTutorial = true) }
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
        soundHaptic.release()
    }
}
