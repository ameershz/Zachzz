#ifndef NEURALCORE_LLAMA_BRIDGE_H
#define NEURALCORE_LLAMA_BRIDGE_H

#include <jni.h>
#include <string>
#include <vector>
#include <memory>
#include <atomic>
#include <android/log.h>

#define TAG "NeuralCore-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)

/**
 * Model state representation holding configuration, runtime context,
 * and memory metrics.
 */
struct LlamaModelContext {
    std::string modelPath;
    int nCtx;
    int nThreads;
    int nGpuLayers;
    size_t allocatedBytes;
    std::atomic<bool> isLoaded;
    std::atomic<bool> cancelRequested;

    LlamaModelContext() : nCtx(2048), nThreads(4), nGpuLayers(0), allocatedBytes(0), isLoaded(false), cancelRequested(false) {}
};

#endif // NEURALCORE_LLAMA_BRIDGE_H
