package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.neuralcore.ui.MainViewModel
import com.example.neuralcore.ui.components.ChatView
import com.example.neuralcore.ui.components.HardwareStatsDialog
import com.example.neuralcore.ui.components.HeaderHUD
import com.example.neuralcore.ui.components.ModelManagerSheet
import com.example.neuralcore.ui.components.ModelSelectorDropdown
import com.example.neuralcore.ui.components.SettingsSheet
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeuralCoreTheme
import com.example.ui.theme.PlasmaViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NeuralCoreTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CyberBackground
                ) {
                    NeuralCoreMainScreen(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NeuralCoreMainScreen(viewModel: MainViewModel) {
    val engineState by viewModel.engineState.collectAsState()
    val availableModels by viewModel.availableModels.collectAsState()
    val selectedModel by viewModel.selectedModel.collectAsState()
    val memoryMetrics by viewModel.memoryMetrics.collectAsState()
    val inferenceSpeed by viewModel.inferenceSpeed.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val parameters by viewModel.parameters.collectAsState()
    val isModelManagerOpen by viewModel.isModelManagerOpen.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val isExecutingTool by viewModel.isExecutingTool.collectAsState()

    var showHardwareStats by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        containerColor = CyberBackground,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(PlasmaViolet.copy(alpha = 0.2f))
                                .border(1.dp, ElectricCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = "NeuralCore Logo",
                                tint = ElectricCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column {
                            Text(
                                text = "NEURALCORE",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary,
                                letterSpacing = 1.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = "OFFLINE LLM • AGENT OS",
                                fontSize = 8.sp,
                                color = NeonEmerald,
                                letterSpacing = 0.5.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showHardwareStats = true },
                        modifier = Modifier.testTag("hardware_stats_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = "NDK & Hardware Telemetry",
                            tint = ElectricCyan
                        )
                    }

                    IconButton(
                        onClick = { viewModel.clearChat() },
                        modifier = Modifier.testTag("clear_chat_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear Chat History",
                            tint = TextMuted
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberBackground,
                    titleContentColor = TextPrimary,
                    actionIconContentColor = TextSecondary
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Dropdown Model Selector (Top)
            ModelSelectorDropdown(
                selectedModel = selectedModel,
                availableModels = availableModels,
                onSelectModel = { viewModel.selectAndLoadModel(it) },
                onUnloadModel = { viewModel.unloadCurrentModel() },
                onOpenModelManager = { viewModel.openModelManager() },
                onOpenSettings = { viewModel.openSettings() },
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )

            // Header HUD Banner (100% LOCAL, tok/s, RAM Gauge)
            HeaderHUD(
                engineState = engineState,
                memoryMetrics = memoryMetrics,
                inferenceSpeed = inferenceSpeed,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Main Chat Area
            ChatView(
                messages = chatMessages,
                inputText = inputText,
                engineState = engineState,
                isExecutingTool = isExecutingTool,
                onInputTextChanged = { viewModel.onInputTextChanged(it) },
                onSendMessage = { viewModel.sendMessage(it) },
                onStopGeneration = { viewModel.stopGeneration() },
                modifier = Modifier.weight(1f)
            )
        }
    }

    // Modal Bottom Sheets
    ModelManagerSheet(
        isOpen = isModelManagerOpen,
        availableModels = availableModels,
        selectedModel = selectedModel,
        onDismiss = { viewModel.closeModelManager() },
        onSelectModel = {
            viewModel.selectAndLoadModel(it)
            viewModel.closeModelManager()
        },
        onUnloadModel = {
            viewModel.unloadCurrentModel()
            viewModel.closeModelManager()
        },
        onRescan = { viewModel.rescanStorage() },
        onImportFile = { file ->
            viewModel.importModelFile(file)
            viewModel.closeModelManager()
        },
        onGenerateSample = { name, sizeMb ->
            viewModel.generateSampleGguf(name, sizeMb)
            viewModel.closeModelManager()
        }
    )

    SettingsSheet(
        isOpen = isSettingsOpen,
        parameters = parameters,
        onDismiss = { viewModel.closeSettings() },
        onParametersChanged = { viewModel.updateParameters(it) }
    )

    HardwareStatsDialog(
        isOpen = showHardwareStats,
        metrics = memoryMetrics,
        onDismiss = { showHardwareStats = false }
    )
}
