package com.example.neuralcore.data.nativebridge

import android.util.Log

object NativeLlamaBridge {
    private const val TAG = "NativeLlamaBridge"
    private var isNativeLibLoaded = false

    init {
        try {
            System.loadLibrary("llama-android")
            isNativeLibLoaded = true
            Log.i(TAG, "Native library libllama-android.so loaded successfully.")
        } catch (e: UnsatisfiedLinkError) {
            Log.w(TAG, "Native library libllama-android.so not available. Running in local simulated execution mode: ${e.message}")
            isNativeLibLoaded = false
        } catch (e: Throwable) {
            Log.e(TAG, "Unexpected error loading native library: ${e.message}", e)
            isNativeLibLoaded = false
        }
    }

    fun isLoaded(): Boolean = isNativeLibLoaded

    // Native C++ JNI Functions
    external fun nativeInitModel(modelPath: String, nCtx: Int, nThreads: Int, nGpuLayers: Int): Long
    external fun nativeFreeModel(handle: Long)
    external fun nativeStopGeneration(handle: Long)
    external fun nativeGetAllocatedBytes(handle: Long): Long
    external fun nativeGetSystemInfo(): String

    // Safe wrappers with fallback handling
    fun initModelSafe(modelPath: String, nCtx: Int, nThreads: Int, nGpuLayers: Int): Long {
        return if (isNativeLibLoaded) {
            try {
                nativeInitModel(modelPath, nCtx, nThreads, nGpuLayers)
            } catch (e: Throwable) {
                Log.e(TAG, "Error in nativeInitModel: ${e.message}", e)
                0L
            }
        } else {
            // Emulated handle for local testing
            0xDEADBEEFL
        }
    }

    fun freeModelSafe(handle: Long) {
        if (isNativeLibLoaded && handle != 0L && handle != 0xDEADBEEFL) {
            try {
                nativeFreeModel(handle)
            } catch (e: Throwable) {
                Log.e(TAG, "Error in nativeFreeModel: ${e.message}", e)
            }
        }
    }

    fun stopGenerationSafe(handle: Long) {
        if (isNativeLibLoaded && handle != 0L && handle != 0xDEADBEEFL) {
            try {
                nativeStopGeneration(handle)
            } catch (e: Throwable) {
                Log.e(TAG, "Error in nativeStopGeneration: ${e.message}", e)
            }
        }
    }

    fun getAllocatedBytesSafe(handle: Long): Long {
        return if (isNativeLibLoaded && handle != 0L && handle != 0xDEADBEEFL) {
            try {
                nativeGetAllocatedBytes(handle)
            } catch (e: Throwable) {
                0L
            }
        } else {
            0L
        }
    }

    fun getSystemInfoSafe(): String {
        return if (isNativeLibLoaded) {
            try {
                nativeGetSystemInfo()
            } catch (e: Throwable) {
                "CPU Cores: ${Runtime.getRuntime().availableProcessors()} | Kotlin LLM Runtime"
            }
        } else {
            "CPU Cores: ${Runtime.getRuntime().availableProcessors()} | Arch: ${android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"} | NEON/FP16"
        }
    }
}
