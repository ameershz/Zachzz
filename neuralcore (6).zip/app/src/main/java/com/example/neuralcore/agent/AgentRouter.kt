package com.example.neuralcore.agent

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log
import com.example.neuralcore.model.ToolCallData
import org.json.JSONObject
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.DecimalFormat

class AgentRouter(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private var isTorchOn = false

    /**
     * Intercepts LLM text output for tool calling format.
     * Supports ```json { "action": ... } ``` or raw JSON.
     */
    fun extractToolCall(rawText: String): ToolCallPayload? {
        val trimmed = rawText.trim()

        // 1. Try to extract from Markdown code block
        val jsonPattern = Regex("```(?:json)?\\s*(\\{[\\s\\S]*?\\})\\s*```", RegexOption.MULTILINE)
        val match = jsonPattern.find(trimmed)
        val candidateJson = match?.groupValues?.get(1) ?: trimmed

        // 2. Parse JSON
        return try {
            val jsonObject = JSONObject(candidateJson)
            if (jsonObject.has("action")) {
                val action = jsonObject.getString("action")
                val params = if (jsonObject.has("parameters")) {
                    jsonObject.getJSONObject("parameters")
                } else if (jsonObject.has("params")) {
                    jsonObject.getJSONObject("params")
                } else {
                    jsonObject
                }
                ToolCallPayload(action = action, parameters = params, rawJson = candidateJson)
            } else {
                null
            }
        } catch (e: Exception) {
            // Not a valid tool json
            null
        }
    }

    /**
     * Executes the intercepted tool call and returns a structured ToolCallData.
     */
    suspend fun executeTool(payload: ToolCallPayload): ToolCallData {
        val action = payload.action.lowercase().trim()
        val params = payload.parameters

        return try {
            when (action) {
                "flashlight", "torch", "toggle_flashlight" -> executeFlashlight(params)
                "get_battery_status", "battery", "battery_status" -> executeBatteryStatus()
                "scan_network", "network_info", "wifi_info", "get_network_info" -> executeNetworkScan()
                "get_storage_info", "storage_space", "storage" -> executeStorageInfo()
                "get_device_specs", "device_specs", "system_info", "hardware_specs" -> executeDeviceSpecs()
                "vibrate_device", "vibrate", "haptic" -> executeVibrate(params)
                "open_settings", "settings" -> executeOpenSettings(params)
                "set_device_timer", "timer", "set_timer" -> executeSetTimer(params)
                else -> ToolCallData(
                    action = action,
                    rawJson = payload.rawJson,
                    executionResult = "Unknown or unsupported tool action: '$action'",
                    isSuccess = false,
                    iconName = "help_outline",
                    title = "Unrecognized Action"
                )
            }
        } catch (e: Throwable) {
            Log.e("AgentRouter", "Tool execution error: ${e.message}", e)
            ToolCallData(
                action = action,
                rawJson = payload.rawJson,
                executionResult = "Error executing tool '$action': ${e.localizedMessage}",
                isSuccess = false,
                iconName = "error",
                title = "Execution Failed"
            )
        }
    }

    // --- Tool Implementations ---

    private fun executeFlashlight(params: JSONObject): ToolCallData {
        if (cameraManager == null) {
            return ToolCallData(
                action = "flashlight",
                rawJson = params.toString(),
                executionResult = "Camera service unavailable on this device.",
                isSuccess = false,
                iconName = "flash_off",
                title = "Flashlight Unavailable"
            )
        }

        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                val flashAvailable = chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                flashAvailable && facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList.firstOrNull()

            if (cameraId == null) {
                return ToolCallData(
                    action = "flashlight",
                    rawJson = params.toString(),
                    executionResult = "No camera with LED flash found.",
                    isSuccess = false,
                    iconName = "flash_off",
                    title = "Flashlight Not Found"
                )
            }

            val desiredState = params.optString("state", "toggle").lowercase()
            val turnOn = when (desiredState) {
                "on", "true", "enable" -> true
                "off", "false", "disable" -> false
                else -> !isTorchOn
            }

            cameraManager.setTorchMode(cameraId, turnOn)
            isTorchOn = turnOn

            return ToolCallData(
                action = "flashlight",
                rawJson = params.toString(),
                executionResult = if (turnOn) "Device Flashlight (Torch) turned ON." else "Device Flashlight (Torch) turned OFF.",
                isSuccess = true,
                iconName = if (turnOn) "flashlight_on" else "flashlight_off",
                title = if (turnOn) "Torch Activated" else "Torch Deactivated",
                details = mapOf(
                    "State" to if (turnOn) "Active (ON)" else "Inactive (OFF)",
                    "Camera ID" to cameraId
                )
            )
        } catch (e: CameraAccessException) {
            return ToolCallData(
                action = "flashlight",
                rawJson = params.toString(),
                executionResult = "Flashlight access failed: ${e.message}",
                isSuccess = false,
                iconName = "flash_off",
                title = "Torch Error"
            )
        }
    }

    private fun executeBatteryStatus(): ToolCallData {
        val batteryIntent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )

        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 0

        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val chargePlug = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        val plugType = when (chargePlug) {
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Wall Charger"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> if (isCharging) "Connected" else "Discharging"
        }

        val tempTenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempCelsius = tempTenths / 10.0
        val voltageMv = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val health = when (batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheated"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            else -> "Normal"
        }

        val resultStr = "Battery: $batteryPct% | $plugType | ${tempCelsius}°C | Health: $health"

        return ToolCallData(
            action = "get_battery_status",
            rawJson = "{}",
            executionResult = resultStr,
            isSuccess = true,
            iconName = "battery_charging_full",
            title = "Battery Telemetry",
            details = mapOf(
                "Level" to "$batteryPct%",
                "Charging Status" to if (isCharging) "Charging ($plugType)" else "On Battery",
                "Temperature" to String.format("%.1f°C", tempCelsius),
                "Voltage" to "${voltageMv} mV",
                "Health" to health
            )
        )
    }

    private fun executeNetworkScan(): ToolCallData {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = connectivityManager?.activeNetwork
        val caps = connectivityManager?.getNetworkCapabilities(activeNetwork)

        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val isCellular = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        val isEthernet = caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true

        val connectionType = when {
            isWifi -> "Wi-Fi"
            isCellular -> "Cellular (5G/LTE)"
            isEthernet -> "Ethernet"
            else -> "Disconnected / Offline"
        }

        var ipAddress = "127.0.0.1"
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val netInterface = interfaces.nextElement()
                val addresses = netInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val addr = addresses.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        ipAddress = addr.hostAddress ?: "127.0.0.1"
                        break
                    }
                }
            }
        } catch (e: Exception) {
            ipAddress = "127.0.0.1"
        }

        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val linkSpeed = wifiManager?.connectionInfo?.linkSpeed?.let { "$it Mbps" } ?: "N/A"

        return ToolCallData(
            action = "scan_network",
            rawJson = "{}",
            executionResult = "Active Network: $connectionType | Local IPv4: $ipAddress | Link Speed: $linkSpeed",
            isSuccess = true,
            iconName = if (isWifi) "wifi" else "signal_cellular_alt",
            title = "Network Diagnostics",
            details = mapOf(
                "Connection" to connectionType,
                "Local IP" to ipAddress,
                "Link Speed" to linkSpeed,
                "Internet" to if (caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true) "Available" else "Local Only"
            )
        )
    }

    private fun executeStorageInfo(): ToolCallData {
        val internalStat = StatFs(Environment.getDataDirectory().path)
        val blockSize = internalStat.blockSizeLong
        val totalBlocks = internalStat.blockCountLong
        val availableBlocks = internalStat.availableBlocksLong

        val totalBytes = totalBlocks * blockSize
        val freeBytes = availableBlocks * blockSize
        val usedBytes = totalBytes - freeBytes
        val usedPercent = if (totalBytes > 0) ((usedBytes.toDouble() / totalBytes) * 100).toInt() else 0

        val df = DecimalFormat("#,##0.#")
        val totalGb = df.format(totalBytes / (1024.0 * 1024.0 * 1024.0))
        val freeGb = df.format(freeBytes / (1024.0 * 1024.0 * 1024.0))
        val usedGb = df.format(usedBytes / (1024.0 * 1024.0 * 1024.0))

        return ToolCallData(
            action = "get_storage_info",
            rawJson = "{}",
            executionResult = "Internal Storage: $freeGb GB free out of $totalGb GB ($usedPercent% used)",
            isSuccess = true,
            iconName = "sd_storage",
            title = "Storage Overview",
            details = mapOf(
                "Free Space" to "$freeGb GB",
                "Used Space" to "$usedGb GB ($usedPercent%)",
                "Total Capacity" to "$totalGb GB"
            )
        )
    }

    private fun executeDeviceSpecs(): ToolCallData {
        val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager?.getMemoryInfo(memInfo)

        val totalRamGb = String.format("%.1f GB", memInfo.totalMem / (1024.0 * 1024.0 * 1024.0))
        val availRamGb = String.format("%.1f GB", memInfo.availMem / (1024.0 * 1024.0 * 1024.0))
        val cpuCores = Runtime.getRuntime().availableProcessors()
        val abis = Build.SUPPORTED_ABIS.joinToString(", ")

        return ToolCallData(
            action = "get_device_specs",
            rawJson = "{}",
            executionResult = "Device: ${Build.MANUFACTURER} ${Build.MODEL} | Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | RAM: $availRamGb / $totalRamGb | CPU: $cpuCores cores ($abis)",
            isSuccess = true,
            iconName = "memory",
            title = "Device Hardware Specs",
            details = mapOf(
                "Device" to "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}",
                "OS Version" to "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                "Total RAM" to totalRamGb,
                "Available RAM" to availRamGb,
                "CPU Cores" to "$cpuCores Cores",
                "ABI Architecture" to abis
            )
        )
    }

    private fun executeVibrate(params: JSONObject): ToolCallData {
        val durationMs = params.optLong("duration_ms", 300L)
        val pattern = params.optString("pattern", "single").lowercase()

        if (vibrator == null || !vibrator.hasVibrator()) {
            return ToolCallData(
                action = "vibrate_device",
                rawJson = params.toString(),
                executionResult = "Haptic vibrator hardware not present.",
                isSuccess = false,
                iconName = "vibration",
                title = "Vibrator Not Found"
            )
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            when (pattern) {
                "sos" -> {
                    val timings = longArrayOf(0, 150, 100, 150, 100, 150, 250, 400, 150, 400, 150, 400, 250, 150, 100, 150, 100, 150)
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, -1))
                }
                "pulse" -> {
                    val timings = longArrayOf(0, 100, 100, 100, 100, 100)
                    vibrator.vibrate(VibrationEffect.createWaveform(timings, -1))
                }
                else -> {
                    vibrator.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            }
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(durationMs)
        }

        return ToolCallData(
            action = "vibrate_device",
            rawJson = params.toString(),
            executionResult = "Haptic feedback triggered ($pattern, ${durationMs}ms).",
            isSuccess = true,
            iconName = "vibration",
            title = "Haptic Feedback Fired",
            details = mapOf(
                "Pattern" to pattern.uppercase(),
                "Duration" to "${durationMs}ms"
            )
        )
    }

    private fun executeOpenSettings(params: JSONObject): ToolCallData {
        val screen = params.optString("screen", "general").lowercase()
        val intentAction = when (screen) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }

        val intent = Intent(intentAction).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)

        return ToolCallData(
            action = "open_settings",
            rawJson = params.toString(),
            executionResult = "Opened system settings screen: $screen",
            isSuccess = true,
            iconName = "settings",
            title = "System Settings Opened",
            details = mapOf("Screen" to screen.uppercase())
        )
    }

    private fun executeSetTimer(params: JSONObject): ToolCallData {
        val seconds = params.optInt("seconds", 60)
        val label = params.optString("label", "NeuralCore Agent Timer")

        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, label)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return try {
            context.startActivity(intent)
            ToolCallData(
                action = "set_device_timer",
                rawJson = params.toString(),
                executionResult = "Timer started for $seconds seconds: '$label'",
                isSuccess = true,
                iconName = "timer",
                title = "Device Timer Set",
                details = mapOf(
                    "Length" to "$seconds s",
                    "Label" to label
                )
            )
        } catch (e: Exception) {
            ToolCallData(
                action = "set_device_timer",
                rawJson = params.toString(),
                executionResult = "Could not start timer directly: ${e.message}",
                isSuccess = false,
                iconName = "timer",
                title = "Timer Action Failed"
            )
        }
    }
}

data class ToolCallPayload(
    val action: String,
    val parameters: JSONObject,
    val rawJson: String
)
