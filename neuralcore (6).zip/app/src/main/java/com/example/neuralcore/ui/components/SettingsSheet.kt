package com.example.neuralcore.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.neuralcore.model.ModelParameters
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.PlasmaViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(
    isOpen: Boolean,
    parameters: ModelParameters,
    onDismiss: () -> Unit,
    onParametersChanged: (ModelParameters) -> Unit
) {
    if (!isOpen) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()

    var temp by remember(parameters) { mutableFloatStateOf(parameters.temperature) }
    var topP by remember(parameters) { mutableFloatStateOf(parameters.topP) }
    var threads by remember(parameters) { mutableIntStateOf(parameters.cpuThreads) }
    var ctxSize by remember(parameters) { mutableIntStateOf(parameters.contextSize) }
    var toolCallingEnabled by remember(parameters) { mutableStateOf(parameters.enableToolCalling) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = CyberSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(scrollState)
                .testTag("settings_sheet")
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = PlasmaViolet,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "LLAMA INFERENCE PARAMETERS",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        letterSpacing = 0.5.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tool Calling Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberCard)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "AI Agent Tool Calling",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonEmerald
                    )
                    Text(
                        text = "Intercepts JSON device commands (Torch, Battery, Network, Storage, Haptics).",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }

                Switch(
                    checked = toolCallingEnabled,
                    onCheckedChange = {
                        toolCallingEnabled = it
                        onParametersChanged(parameters.copy(enableToolCalling = it))
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = NeonEmerald
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Temperature Slider
            ParameterSlider(
                title = "Temperature",
                valueDisplay = String.format("%.2f", temp),
                value = temp,
                range = 0.1f..1.5f,
                onValueChange = {
                    temp = it
                    onParametersChanged(parameters.copy(temperature = it))
                },
                description = "Controls creativity vs deterministic output (0.2 = code/tools, 0.7 = chat)"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Top-P Slider
            ParameterSlider(
                title = "Top-P (Nucleus Sampling)",
                valueDisplay = String.format("%.2f", topP),
                value = topP,
                range = 0.1f..1.0f,
                onValueChange = {
                    topP = it
                    onParametersChanged(parameters.copy(topP = it))
                },
                description = "Filters candidate tokens based on cumulative probability mass"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // CPU Threads Slider
            ParameterSlider(
                title = "CPU Inference Threads (n_threads)",
                valueDisplay = "$threads Cores",
                value = threads.toFloat(),
                range = 1f..8f,
                steps = 6,
                onValueChange = {
                    threads = it.toInt()
                    onParametersChanged(parameters.copy(cpuThreads = it.toInt()))
                },
                description = "Number of active POSIX threads for matrix GEMM multiplication"
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Context Window
            ParameterSlider(
                title = "Context Size (n_ctx)",
                valueDisplay = "$ctxSize Tokens",
                value = ctxSize.toFloat(),
                range = 512f..4096f,
                steps = 6,
                onValueChange = {
                    ctxSize = ((it / 512).toInt() * 512).coerceIn(512, 4096)
                    onParametersChanged(parameters.copy(contextSize = ctxSize))
                },
                description = "KV Cache allocated in device unified RAM (~1MB per 1k context)"
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ParameterSlider(
    title: String,
    valueDisplay: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    description: String,
    steps: Int = 0,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CyberCard)
            .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = valueDisplay,
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                color = ElectricCyan,
                fontFamily = FontFamily.Monospace
            )
        }

        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = ElectricCyan,
                activeTrackColor = ElectricCyan,
                inactiveTrackColor = Color(0xFF1E2C3F)
            )
        )

        Text(
            text = description,
            fontSize = 10.sp,
            color = TextMuted
        )
    }
}
