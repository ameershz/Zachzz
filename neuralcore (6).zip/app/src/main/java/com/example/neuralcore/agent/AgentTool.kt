package com.example.neuralcore.agent

data class ToolDefinition(
    val name: String,
    val displayName: String,
    val description: String,
    val category: String,
    val exampleCall: String,
    val icon: String
)

object AvailableTools {
    val list = listOf(
        ToolDefinition(
            name = "flashlight",
            displayName = "Flashlight / Torch",
            description = "Control the physical device LED flash (turn ON, OFF, or toggle).",
            category = "Hardware",
            exampleCall = """{"action": "flashlight", "parameters": {"state": "on"}}""",
            icon = "flashlight_on"
        ),
        ToolDefinition(
            name = "get_battery_status",
            displayName = "Battery Diagnostics",
            description = "Get real-time battery level percentage, charging status, temperature, and health.",
            category = "Telemetry",
            exampleCall = """{"action": "get_battery_status", "parameters": {}}""",
            icon = "battery_charging_full"
        ),
        ToolDefinition(
            name = "scan_network",
            displayName = "Network Diagnostic",
            description = "Inspect Wi-Fi / Cellular connection, local IP address, link speed, and gateway.",
            category = "Network",
            exampleCall = """{"action": "scan_network", "parameters": {}}""",
            icon = "wifi"
        ),
        ToolDefinition(
            name = "get_storage_info",
            displayName = "Storage Space",
            description = "Check internal storage and SD card total space, free capacity, and usage.",
            category = "System",
            exampleCall = """{"action": "get_storage_info", "parameters": {}}""",
            icon = "sd_storage"
        ),
        ToolDefinition(
            name = "get_device_specs",
            displayName = "Device & SoC Specs",
            description = "Query processor architecture, CPU cores, total RAM, OS version, and model info.",
            category = "Hardware",
            exampleCall = """{"action": "get_device_specs", "parameters": {}}""",
            icon = "memory"
        ),
        ToolDefinition(
            name = "vibrate_device",
            displayName = "Haptic Vibration",
            description = "Trigger tactile vibration feedback patterns (single, pulse, or SOS).",
            category = "Hardware",
            exampleCall = """{"action": "vibrate_device", "parameters": {"duration_ms": 300, "pattern": "pulse"}}""",
            icon = "vibration"
        ),
        ToolDefinition(
            name = "open_settings",
            displayName = "System Settings",
            description = "Open Android system settings panel (Wi-Fi, Display, Battery, Sound).",
            category = "OS",
            exampleCall = """{"action": "open_settings", "parameters": {"screen": "wifi"}}""",
            icon = "settings"
        ),
        ToolDefinition(
            name = "set_device_timer",
            displayName = "Device Timer",
            description = "Set countdown timer or alarm on the device.",
            category = "Productivity",
            exampleCall = """{"action": "set_device_timer", "parameters": {"seconds": 60, "label": "Deep Work"}}""",
            icon = "timer"
        )
    )
}
