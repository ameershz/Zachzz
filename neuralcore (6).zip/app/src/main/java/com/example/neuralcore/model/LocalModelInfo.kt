package com.example.neuralcore.model

import java.io.File
import java.text.DecimalFormat

data class LocalModelInfo(
    val id: String,
    val name: String,
    val filename: String,
    val absolutePath: String,
    val sizeBytes: Long,
    val quantization: String,
    val parameterCount: String,
    val contextWindow: Int = 2048,
    val isLoaded: Boolean = false,
    val isAvailableOnDisk: Boolean = true,
    val sourceLocation: String = "Internal / Download",
    val description: String = ""
) {
    val formattedSize: String
        get() = formatBytes(sizeBytes)

    val estimatedRamUsageMb: Int
        get() = ((sizeBytes / (1024 * 1024)) * 1.15).toInt() + (contextWindow * 512 / 1024)

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
            val df = DecimalFormat("#,##0.#")
            return "${df.format(bytes / Math.pow(1024.0, digitGroups.toDouble()))} ${units[digitGroups]}"
        }

        fun fromFile(file: File): LocalModelInfo {
            val name = file.nameWithoutExtension
            val quant = parseQuantization(file.name)
            val params = parseParamCount(file.name)
            return LocalModelInfo(
                id = file.absolutePath.hashCode().toString(),
                name = formatDisplayName(file.name),
                filename = file.name,
                absolutePath = file.absolutePath,
                sizeBytes = file.length(),
                quantization = quant,
                parameterCount = params,
                contextWindow = 2048,
                isLoaded = false,
                isAvailableOnDisk = file.exists(),
                sourceLocation = file.parent ?: "Storage"
            )
        }

        fun parseQuantization(filename: String): String {
            val upper = filename.uppercase()
            return when {
                upper.contains("Q4_K_M") -> "Q4_K_M"
                upper.contains("Q4_K_S") -> "Q4_K_S"
                upper.contains("Q4_0") -> "Q4_0"
                upper.contains("Q4_1") -> "Q4_1"
                upper.contains("Q5_K_M") -> "Q5_K_M"
                upper.contains("Q5_K_S") -> "Q5_K_S"
                upper.contains("Q8_0") -> "Q8_0"
                upper.contains("F16") -> "F16"
                upper.contains("Q2_K") -> "Q2_K"
                upper.contains("Q3_K_M") -> "Q3_K_M"
                upper.contains("IQ4_XS") -> "IQ4_XS"
                else -> "GGUF Quant"
            }
        }

        fun parseParamCount(filename: String): String {
            val lower = filename.lowercase()
            return when {
                lower.contains("1.5b") -> "1.5B"
                lower.contains("1b") || lower.contains("1.1b") || lower.contains("1.2b") -> "1B"
                lower.contains("2b") || lower.contains("2.5b") -> "2B"
                lower.contains("3b") || lower.contains("3.2b") || lower.contains("3.8b") -> "3B"
                lower.contains("7b") || lower.contains("8b") -> "7B"
                lower.contains("0.5b") || lower.contains("500m") -> "0.5B"
                else -> "1.5B-3B"
            }
        }

        private fun formatDisplayName(filename: String): String {
            var clean = filename.replace(".gguf", "", ignoreCase = true)
            clean = clean.replace("-instruct", " (Instruct)", ignoreCase = true)
            clean = clean.replace("-chat", " (Chat)", ignoreCase = true)
            return clean
        }
    }
}
