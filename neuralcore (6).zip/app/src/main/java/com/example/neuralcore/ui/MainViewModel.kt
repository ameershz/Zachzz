package com.example.neuralcore.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.neuralcore.agent.AgentRouter
import com.example.neuralcore.data.EngineState
import com.example.neuralcore.data.LlamaEngine
import com.example.neuralcore.data.SystemMemoryMetrics
import com.example.neuralcore.model.ChatMessage
import com.example.neuralcore.model.LocalModelInfo
import com.example.neuralcore.model.MessageRole
import com.example.neuralcore.model.ModelParameters
import com.example.neuralcore.model.ToolCallData
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = LlamaEngine(application)
    private val agentRouter = AgentRouter(application)

    val engineState: StateFlow<EngineState> = engine.engineState
    val availableModels: StateFlow<List<LocalModelInfo>> = engine.availableModels
    val selectedModel: StateFlow<LocalModelInfo?> = engine.selectedModel
    val memoryMetrics: StateFlow<SystemMemoryMetrics> = engine.memoryMetrics
    val inferenceSpeed: StateFlow<Float> = engine.lastInferenceSpeed

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _parameters = MutableStateFlow(ModelParameters())
    val parameters: StateFlow<ModelParameters> = _parameters.asStateFlow()

    private val _isModelManagerOpen = MutableStateFlow(false)
    val isModelManagerOpen: StateFlow<Boolean> = _isModelManagerOpen.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _isExecutingTool = MutableStateFlow(false)
    val isExecutingTool: StateFlow<Boolean> = _isExecutingTool.asStateFlow()

    init {
        // Welcome message explaining offline edge setup
        _chatMessages.value = listOf(
            ChatMessage(
                role = MessageRole.ASSISTANT,
                content = "⚡ **NeuralCore Edge Engine Ready.**\n\n- Running 100% offline via `llama.cpp`.\n- No data leaves this device.\n- Autonomous Agent Tool Calling enabled (Torch, Battery, Network, Storage, Haptics).\n\nSelect a `.gguf` model from the dropdown above to begin.",
                modelName = "NeuralCore Core",
                tokensPerSecond = 0f
            )
        )
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text
    }

    fun openModelManager() {
        _isModelManagerOpen.value = true
        engine.refreshAvailableModels()
    }

    fun closeModelManager() {
        _isModelManagerOpen.value = false
    }

    fun openSettings() {
        _isSettingsOpen.value = true
    }

    fun closeSettings() {
        _isSettingsOpen.value = false
    }

    fun updateParameters(params: ModelParameters) {
        _parameters.value = params
    }

    fun selectAndLoadModel(model: LocalModelInfo) {
        viewModelScope.launch {
            val previousName = selectedModel.value?.name ?: "None"
            val success = engine.loadModel(model, _parameters.value)
            if (success) {
                appendSystemMessage("🔄 Model switched from **$previousName** to **${model.name}** [${model.quantization}, ${model.formattedSize}]. Old memory released.")
            } else {
                appendSystemMessage("⚠️ Failed to load model: ${model.name}")
            }
        }
    }

    fun unloadCurrentModel() {
        viewModelScope.launch {
            val currentName = selectedModel.value?.name ?: "Model"
            engine.unloadActiveModel()
            appendSystemMessage("⏹️ **$currentName** unloaded from RAM. Memory freed.")
        }
    }

    fun rescanStorage() {
        engine.refreshAvailableModels()
    }

    fun importModelFile(file: File) {
        val model = engine.addCustomModelFile(file)
        selectAndLoadModel(model)
    }

    fun generateSampleGguf(name: String, sizeMb: Int) {
        val file = engine.createSampleGgufFile(name, sizeMb)
        val model = engine.addCustomModelFile(file)
        selectAndLoadModel(model)
    }

    fun sendMessage(userText: String = _inputText.value) {
        val prompt = userText.trim()
        if (prompt.isEmpty() || engineState.value == EngineState.GENERATING) return

        _inputText.value = ""

        // Append user message
        val userMsg = ChatMessage(
            role = MessageRole.USER,
            content = prompt
        )
        _chatMessages.value = _chatMessages.value + userMsg

        val currentModel = selectedModel.value
        val modelName = currentModel?.name ?: "Offline Engine"

        // Prepare placeholder for assistant streaming
        val assistantMsgId = java.util.UUID.randomUUID().toString()
        val initialAssistantMsg = ChatMessage(
            id = assistantMsgId,
            role = MessageRole.ASSISTANT,
            content = "",
            modelName = modelName,
            isStreaming = true
        )
        _chatMessages.value = _chatMessages.value + initialAssistantMsg

        viewModelScope.launch {
            val fullResponseBuilder = StringBuilder()
            val startTime = System.currentTimeMillis()
            var tokenCount = 0

            engine.generateStreaming(prompt, _parameters.value).collect { token ->
                tokenCount++
                fullResponseBuilder.append(token)
                val fullText = fullResponseBuilder.toString()
                val elapsedSec = (System.currentTimeMillis() - startTime) / 1000f
                val currentSpeed = if (elapsedSec > 0.1f) tokenCount / elapsedSec else 0f

                _chatMessages.value = _chatMessages.value.map { msg ->
                    if (msg.id == assistantMsgId) {
                        msg.copy(
                            content = fullText,
                            tokenCount = tokenCount,
                            tokensPerSecond = currentSpeed,
                            generationLatencyMs = System.currentTimeMillis() - startTime
                        )
                    } else {
                        msg
                    }
                }
            }

            // Finished streaming text, check for Agent Tool Call
            val finalText = fullResponseBuilder.toString()
            val latency = System.currentTimeMillis() - startTime
            val finalSpeed = if (latency > 0) (tokenCount * 1000f / latency) else 0f

            val toolPayload = if (_parameters.value.enableToolCalling) {
                agentRouter.extractToolCall(finalText)
            } else {
                null
            }

            var toolResultData: ToolCallData? = null
            if (toolPayload != null) {
                _isExecutingTool.value = true
                toolResultData = agentRouter.executeTool(toolPayload)
                _isExecutingTool.value = false
            }

            _chatMessages.value = _chatMessages.value.map { msg ->
                if (msg.id == assistantMsgId) {
                    msg.copy(
                        content = finalText,
                        tokenCount = tokenCount,
                        tokensPerSecond = finalSpeed,
                        generationLatencyMs = latency,
                        isStreaming = false,
                        toolCall = toolResultData
                    )
                } else {
                    msg
                }
            }
        }
    }

    fun stopGeneration() {
        engine.stopGeneration()
    }

    fun clearChat() {
        _chatMessages.value = emptyList()
    }

    private fun appendSystemMessage(content: String) {
        _chatMessages.value = _chatMessages.value + ChatMessage(
            role = MessageRole.SYSTEM,
            content = content
        )
    }
}
