package com.example.neuralcore.model

import java.util.UUID

enum class MessageRole {
    USER,
    ASSISTANT,
    SYSTEM,
    TOOL_ACTION
}

data class ToolCallData(
    val action: String,
    val rawJson: String,
    val executionResult: String,
    val isSuccess: Boolean = true,
    val iconName: String = "bolt",
    val title: String = "Device Action",
    val details: Map<String, String> = emptyMap()
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val tokensPerSecond: Float = 0f,
    val generationLatencyMs: Long = 0L,
    val tokenCount: Int = 0,
    val modelName: String = "",
    val toolCall: ToolCallData? = null,
    val isStreaming: Boolean = false
)
