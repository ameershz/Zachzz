package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Cyberpunk & Sci-Fi Dark Palette
val CyberBlack = Color(0xFF07090E)
val CyberBackground = Color(0xFF0A0E17)
val CyberSurface = Color(0xFF101726)
val CyberSurfaceVariant = Color(0xFF182235)
val CyberCard = Color(0xFF141C2B)
val CyberCardBorder = Color(0xFF223249)

val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanGlow = Color(0x3300E5FF)
val NeonEmerald = Color(0xFF00E676)
val NeonEmeraldGlow = Color(0x3300E676)
val PlasmaViolet = Color(0xFF7C4DFF)
val PlasmaVioletGlow = Color(0x337C4DFF)
val AmberGlow = Color(0xFFFFAB00)
val LaserRed = Color(0xFFFF5252)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF586069)
val ToolBadgeBackground = Color(0xFF132338)
