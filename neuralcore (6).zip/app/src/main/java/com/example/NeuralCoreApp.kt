package com.example

import android.app.Application
import android.util.Log

class NeuralCoreApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i("NeuralCoreApp", "NeuralCore Engine initialized on ${android.os.Build.MODEL}")
    }
}
