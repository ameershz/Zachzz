package com.example

import com.example.neuralcore.agent.AgentRouter
import com.example.neuralcore.model.LocalModelInfo
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun parseQuantization_identifiesCorrectQuantType() {
        assertEquals("Q4_K_M", LocalModelInfo.parseQuantization("qwen2.5-1.5b-instruct-q4_k_m.gguf"))
        assertEquals("Q8_0", LocalModelInfo.parseQuantization("llama-3.2-1b-instruct-q8_0.gguf"))
        assertEquals("Q5_K_M", LocalModelInfo.parseQuantization("smollm2-1.7b-q5_k_m.gguf"))
    }

    @Test
    fun parseParamCount_identifiesCorrectModelSize() {
        assertEquals("1.5B", LocalModelInfo.parseParamCount("qwen2.5-1.5b-instruct-q4_k_m.gguf"))
        assertEquals("1B", LocalModelInfo.parseParamCount("llama-3.2-1b-instruct-q4_k_m.gguf"))
        assertEquals("3B", LocalModelInfo.parseParamCount("llama-3.2-3b-instruct-q4_k_m.gguf"))
    }

    @Test
    fun formatBytes_convertsToReadableUnits() {
        val oneGb = 1024L * 1024L * 1024L
        val formatted = LocalModelInfo.formatBytes(oneGb)
        assertTrue(formatted.contains("1") && formatted.contains("GB"))
    }
}

