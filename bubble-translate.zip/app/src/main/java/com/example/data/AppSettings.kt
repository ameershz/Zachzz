package com.example.data

import com.example.model.TranslationMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * مدير إعدادات التطبيق المشتركة بين واجهة المستخدم والخدمة العائمة
 */
object AppSettings {
    // الوضع المختار حالياً
    private val _selectedMode = MutableStateFlow(TranslationMode.OFFLINE)
    val selectedMode: StateFlow<TranslationMode> = _selectedMode.asStateFlow()

    // لغة المصدر (افتراضياً: إنجليزية en)
    private val _sourceLanguage = MutableStateFlow("en")
    val sourceLanguage: StateFlow<String> = _sourceLanguage.asStateFlow()

    // لغة الهدف (افتراضياً: عربية ar)
    private val _targetLanguage = MutableStateFlow("ar")
    val targetLanguage: StateFlow<String> = _targetLanguage.asStateFlow()

    // حالة تشغيل الخدمة العائمة
    private val _isServiceActive = MutableStateFlow(false)
    val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

    // آخر حالة أو رسالة للترجمة
    private val _statusMessage = MutableStateFlow("جاهز للاستخدام")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    fun setMode(mode: TranslationMode) {
        _selectedMode.value = mode
    }

    fun setSourceLanguage(lang: String) {
        _sourceLanguage.value = lang
    }

    fun setTargetLanguage(lang: String) {
        _targetLanguage.value = lang
    }

    fun setServiceActive(active: Boolean) {
        _isServiceActive.value = active
    }

    fun setStatusMessage(msg: String) {
        _statusMessage.value = msg
    }
}
