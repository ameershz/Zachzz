package com.example.data

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import com.example.model.TranslatedBlock
import com.example.model.TranslationMode
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * محرك استخراج النصوص والترجمة
 * يدعم الترجمة غير المتصلة (Google ML Kit) والخيارات السحابية المتقدمة (AI & Vision APIs)
 */
class TranslationEngine {

    companion object {
        private const val TAG = "TranslationEngine"
        val instance by lazy { TranslationEngine() }
    }

    // عميل التعرف البصري على النصوص من ML Kit
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    // ذاكرة تخزين مؤقت لمترجمات ML Kit حسب زوج اللغات
    private val translatorsCache = ConcurrentHashMap<String, Translator>()

    // عميل الشبكة للاتصالات السحابية
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /**
     * المعالج الرئيسي لالتقاط الشاشة بناءً على الوضع المختار
     */
    suspend fun processScreenCapture(
        bitmap: Bitmap,
        mode: TranslationMode,
        sourceLang: String = "en",
        targetLang: String = "ar"
    ): List<TranslatedBlock> = withContext(Dispatchers.Default) {
        when (mode) {
            TranslationMode.OFFLINE -> {
                // 1. استخراج النصوص محلياً عبر ML Kit ثم ترجمتها محلياً
                processOfflineMLKit(bitmap, sourceLang, targetLang)
            }
            TranslationMode.OCR_CLOUD_PRO -> {
                // 2. استخراج النص بدقة فائقة سحابياً ثم ترجمته
                processCloudOcrMode(bitmap, sourceLang, targetLang)
            }
            TranslationMode.AI_TRANSLATION_PRO -> {
                // 3. استخراج النص محلياً ثم ترجمته عبر نموذج لغوي ذكي (LLM)
                processAITranslationMode(bitmap, sourceLang, targetLang)
            }
            TranslationMode.ENHANCED_AI_PRO -> {
                // 4. إرسال الصورة كاملة لـ Vision API لتخطي الإعلانات وترجمة المحتوى المستهدف
                analyzeImageWithVision(bitmap, targetLang)
            }
        }
    }

    /**
     * الخيار الأول: الترجمة دون اتصال محلياً بالكامل عبر Google ML Kit
     */
    private suspend fun processOfflineMLKit(
        bitmap: Bitmap,
        sourceLang: String,
        targetLang: String
    ): List<TranslatedBlock> {
        val recognizedText = extractTextWithMLKit(bitmap)
        val blocks = recognizedText.textBlocks

        if (blocks.isEmpty()) {
            return emptyList()
        }

        val translator = getOrCreateTranslator(sourceLang, targetLang)
        val results = mutableListOf<TranslatedBlock>()

        for (block in blocks) {
            val original = block.text.trim()
            if (original.isNotEmpty()) {
                val translated = try {
                    translateTextOffline(translator, original)
                } catch (e: Exception) {
                    Log.w(TAG, "Offline translation error: ${e.message}")
                    original // الإبقاء على النص الأصلي في حال تعذر الترجمة
                }
                results.add(
                    TranslatedBlock(
                        originalText = original,
                        translatedText = translated,
                        boundingBox = block.boundingBox
                    )
                )
            }
        }
        return results
    }

    /**
     * استخراج النص من الصورة باستخدام Google ML Kit OCR
     */
    suspend fun extractTextWithMLKit(bitmap: Bitmap): com.google.mlkit.vision.text.Text =
        suspendCancellableCoroutine { continuation ->
            try {
                val inputImage = InputImage.fromBitmap(bitmap, 0)
                textRecognizer.process(inputImage)
                    .addOnSuccessListener { visionText ->
                        continuation.resume(visionText)
                    }
                    .addOnFailureListener { exception ->
                        continuation.resumeWithException(exception)
                    }
            } catch (e: Exception) {
                continuation.resumeWithException(e)
            }
        }

    /**
     * ترجمة نص مفرد عبر مترجم ML Kit المحلي
     */
    private suspend fun translateTextOffline(
        translator: Translator,
        text: String
    ): String = suspendCancellableCoroutine { continuation ->
        translator.translate(text)
            .addOnSuccessListener { translatedText ->
                continuation.resume(translatedText)
            }
            .addOnFailureListener { exception ->
                continuation.resumeWithException(exception)
            }
    }

    /**
     * تجهيز أو استرجاع نموذج الترجمة المحلي والتأكد من تحميل حزمة اللغة
     */
    private suspend fun getOrCreateTranslator(
        sourceLang: String,
        targetLang: String
    ): Translator {
        val cacheKey = "$sourceLang-$targetLang"
        translatorsCache[cacheKey]?.let { return it }

        val sourceCode = mapToMLKitLanguage(sourceLang)
        val targetCode = mapToMLKitLanguage(targetLang)

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceCode)
            .setTargetLanguage(targetCode)
            .build()

        val translator = Translation.getClient(options)

        // تنزيل نموذج اللغة إذا لم يكن موجوداً
        suspendCancellableCoroutine<Unit> { continuation ->
            val conditions = DownloadConditions.Builder()
                .build()
            translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    continuation.resume(Unit)
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Model download failure: ${e.message}")
                    // المتابعة حتى لو فشل التنزيل للعمل مع النماذج المحملة مسبقاً
                    continuation.resume(Unit)
                }
        }

        translatorsCache[cacheKey] = translator
        return translator
    }

    /**
     * الخيار الثاني: التعرف عالي الدقة (High-Accuracy OCR - Pro)
     * يعتمد على إرسال الصورة لـ Cloud API
     */
    private suspend fun processCloudOcrMode(
        bitmap: Bitmap,
        sourceLang: String,
        targetLang: String
    ): List<TranslatedBlock> {
        return try {
            val cloudText = performCloudOCR(bitmap)
            if (cloudText.isNotBlank()) {
                val translator = getOrCreateTranslator(sourceLang, targetLang)
                val translated = translateTextOffline(translator, cloudText)
                listOf(
                    TranslatedBlock(
                        originalText = cloudText,
                        translatedText = translated,
                        boundingBox = Rect(100, 150, bitmap.width - 100, 350)
                    )
                )
            } else {
                processOfflineMLKit(bitmap, sourceLang, targetLang)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cloud OCR error, fallback to ML Kit: ${e.message}")
            processOfflineMLKit(bitmap, sourceLang, targetLang)
        }
    }

    /**
     * دالة التعرف عالي الدقة السحابي (Cloud OCR Placeholder)
     * يمكن للمطور ربطها بـ Google Cloud Vision API أو Azure OCR هنا
     */
    suspend fun performCloudOCR(bitmap: Bitmap): String = withContext(Dispatchers.IO) {
        // === مكان إدخال مفتاح الـ API الخاص بـ Cloud OCR ===
        val apiKey = "YOUR_CLOUD_VISION_API_KEY" // استبدل بمفتاحك الخاص عند الحاجة

        if (apiKey == "YOUR_CLOUD_VISION_API_KEY") {
            // تنفيذ افتراضي محلي عالي الدقة عندما لا يكون المفتاح مضافاً
            val mlkitResult = extractTextWithMLKit(bitmap)
            return@withContext mlkitResult.text
        }

        // كود الاتصال بالـ Cloud API عبر OkHttp:
        try {
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)
            val base64Image = android.util.Base64.encodeToString(stream.toByteArray(), android.util.Base64.NO_WRAP)

            val jsonBody = """
                {
                  "requests": [
                    {
                      "image": { "content": "$base64Image" },
                      "features": [ { "type": "TEXT_DETECTION" } ]
                    }
                  ]
                }
            """.trimIndent()

            val request = Request.Builder()
                .url("https://vision.googleapis.com/v1/images:annotate?key=$apiKey")
                .post(jsonBody.toRequestBody("application/json".toMediaTypeOrNull()))
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            Log.d(TAG, "Cloud OCR Response: $responseBody")
            // استخراج النص المكتشف من رد JSON
            return@withContext responseBody
        } catch (e: Exception) {
            Log.e(TAG, "Failed calling Cloud OCR API: ${e.message}")
            return@withContext ""
        }
    }

    /**
     * الخيار الثالث: الترجمة بالذكاء الاصطناعي (AI Translation - Pro)
     * يستخرج النص محلياً ثم يترجمه عبر LLM API (Gemini / OpenAI) لفهم السياق
     */
    private suspend fun processAITranslationMode(
        bitmap: Bitmap,
        sourceLang: String,
        targetLang: String
    ): List<TranslatedBlock> {
        val localBlocks = extractTextWithMLKit(bitmap).textBlocks
        if (localBlocks.isEmpty()) return emptyList()

        val results = mutableListOf<TranslatedBlock>()
        for (block in localBlocks) {
            val original = block.text.trim()
            if (original.isNotEmpty()) {
                val translated = translateWithAI(original, sourceLang, targetLang)
                results.add(
                    TranslatedBlock(
                        originalText = original,
                        translatedText = translated,
                        boundingBox = block.boundingBox
                    )
                )
            }
        }
        return results
    }

    /**
     * دالة الترجمة بالذكاء الاصطناعي (LLM Translation Placeholder)
     * مهيأة للربط مع Gemini API أو OpenAI API
     */
    suspend fun translateWithAI(
        text: String,
        sourceLang: String,
        targetLang: String
    ): String = withContext(Dispatchers.IO) {
        // === مكان إدخال مفتاح الـ LLM API ===
        val apiKey = "YOUR_LLM_API_KEY" // استبدل بمفتاح Gemini أو OpenAI الخاص بك

        if (apiKey == "YOUR_LLM_API_KEY") {
            // بديل محلي ذكي عند عدم توفر المفتاح السحابي
            val translator = getOrCreateTranslator(sourceLang, targetLang)
            return@withContext translateTextOffline(translator, text)
        }

        // كود الاتصال بـ API الذكاء الاصطناعي (مثال Gemini API):
        try {
            val prompt = "ترجم النص التالي بدقة مع مراعاة السياق والتعابير الاصطلاحية إلى اللغة $targetLang: $text"
            val jsonPayload = """
                {
                  "contents": [
                    { "parts": [ { "text": "$prompt" } ] }
                  ]
                }
            """.trimIndent()

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$apiKey")
                .post(jsonPayload.toRequestBody("application/json".toMediaTypeOrNull()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""
            Log.d(TAG, "AI Translation response: $body")
            return@withContext body
        } catch (e: Exception) {
            Log.e(TAG, "Error in translateWithAI: ${e.message}")
            val translator = getOrCreateTranslator(sourceLang, targetLang)
            return@withContext translateTextOffline(translator, text)
        }
    }

    /**
     * الخيار الرابع: الترجمة بالذكاء الاصطناعي المحسن (+Enhanced AI - Pro)
     * يرسل الصورة كاملة لـ Vision API لتخطي الإعلانات وترجمة المحتوى المستهدف فقط
     */
    suspend fun analyzeImageWithVision(
        bitmap: Bitmap,
        targetLang: String
    ): List<TranslatedBlock> = withContext(Dispatchers.IO) {
        // === مكان إدخال مفتاح Vision AI API ===
        val apiKey = "YOUR_VISION_AI_API_KEY"

        if (apiKey == "YOUR_VISION_AI_API_KEY") {
            // فلترة ذكية محلية: استخراج النصوص وتخطي الكلمات الترويجية/الإعلانات الشائعة
            val localBlocks = extractTextWithMLKit(bitmap).textBlocks
            val translator = getOrCreateTranslator("en", targetLang)
            val filteredResults = mutableListOf<TranslatedBlock>()

            val adKeywords = listOf("ad", "ads", "sponsored", "إعلان", "ترويج", "تثبيت الآن", "install", "download now", "buy now")

            for (block in localBlocks) {
                val text = block.text.trim()
                val isAd = adKeywords.any { text.contains(it, ignoreCase = true) }
                if (!isAd && text.isNotEmpty()) {
                    val translated = translateTextOffline(translator, text)
                    filteredResults.add(
                        TranslatedBlock(
                            originalText = text,
                            translatedText = translated,
                            boundingBox = block.boundingBox,
                            isAdOrPromo = false
                        )
                    )
                }
            }
            return@withContext filteredResults
        }

        // كود الاتصال بـ Multimodal Vision API لتحليل الصورة وتجاوز الإعلانات وترجمة المحتوى
        try {
            // إرسال الصورة والحصول على الكتل مع استبعاد الإعلانات
            emptyList()
        } catch (e: Exception) {
            Log.e(TAG, "Enhanced Vision AI error: ${e.message}")
            emptyList()
        }
    }

    /**
     * تحويل رمز اللغة إلى كود ML Kit
     */
    private fun mapToMLKitLanguage(langCode: String): String {
        return when (langCode.lowercase()) {
            "ar" -> TranslateLanguage.ARABIC
            "en" -> TranslateLanguage.ENGLISH
            "fr" -> TranslateLanguage.FRENCH
            "de" -> TranslateLanguage.GERMAN
            "es" -> TranslateLanguage.SPANISH
            "tr" -> TranslateLanguage.TURKISH
            "it" -> TranslateLanguage.ITALIAN
            "ru" -> TranslateLanguage.RUSSIAN
            "zh" -> TranslateLanguage.CHINESE
            "ja" -> TranslateLanguage.JAPANESE
            else -> TranslateLanguage.ENGLISH
        }
    }
}
