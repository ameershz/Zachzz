package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.AppSettings
import com.example.data.TranslationEngine
import com.example.model.TranslationMode
import com.example.service.FloatingService
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldTertiary
import com.example.ui.theme.IndigoSecondary
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val isServiceActive by AppSettings.isServiceActive.collectAsStateWithLifecycle()
    val currentMode by AppSettings.selectedMode.collectAsStateWithLifecycle()
    val sourceLang by AppSettings.sourceLanguage.collectAsStateWithLifecycle()
    val targetLang by AppSettings.targetLanguage.collectAsStateWithLifecycle()

    // فحص إذن الظهور فوق التطبيقات (Overlay Permission)
    var hasOverlayPermission by remember {
        mutableStateOf(Settings.canDrawOverlays(context))
    }

    // تحديث حالة إذن الـ Overlay عند الرجوع للتطبيق
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = Settings.canDrawOverlays(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // مشغل إذن الإشعارات (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* تم التعامل مع النتيجة */ }

    // مشغل إذن تسجيل الشاشة (MediaProjection)
    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(context, FloatingService::class.java).apply {
                action = FloatingService.ACTION_START
                putExtra(FloatingService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(FloatingService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
            Toast.makeText(context, "تم تفعيل فقاعة الترجمة بنجاح!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "تم إلغاء إذن تسجيل الشاشة", Toast.LENGTH_SHORT).show()
        }
    }

    // دالة بدء تشغيل الخدمة
    fun startFloatingService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (!Settings.canDrawOverlays(context)) {
            Toast.makeText(context, "يرجى منح إذن الظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            context.startActivity(intent)
            return
        }

        val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    // دالة إيقاف الخدمة
    fun stopFloatingService() {
        val serviceIntent = Intent(context, FloatingService::class.java).apply {
            action = FloatingService.ACTION_STOP
        }
        context.startService(serviceIntent)
        AppSettings.setServiceActive(false)
        Toast.makeText(context, "تم إيقاف الخدمة العائمة", Toast.LENGTH_SHORT).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(CyanPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = "Logo",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Bubble Translate",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "مترجم الشاشة العائم الذكي",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // 1. تنبيه إذن الـ Overlay إذا لم يكن ممنوحاً
            if (!hasOverlayPermission) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().testTag("overlay_permission_warning")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "إذن الظهور فوق التطبيقات مطلوب",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Text(
                                    text = "يلزم منح الصلاحية لظهور زر الترجمة العائم فوق الشاشة",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val intent = Intent(
                                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                        Uri.parse("package:${context.packageName}")
                                    )
                                    context.startActivity(intent)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier.testTag("request_overlay_button")
                            ) {
                                Text("تفعيل", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 2. بطاقة حالة الخدمة وزر التفعيل الرئيسي (Hero Status Card)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isServiceActive) {
                            IndigoSecondary.copy(alpha = 0.15f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // شارة الحالة
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(24.dp))
                                .background(
                                    if (isServiceActive) EmeraldTertiary.copy(alpha = 0.2f)
                                    else Color.Gray.copy(alpha = 0.15f)
                                )
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isServiceActive) EmeraldTertiary else Color.Gray)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isServiceActive) "الخدمة نشطة والفقاعة تطفو" else "الخدمة متوقفة",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = if (isServiceActive) EmeraldTertiary else Color.Gray
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = if (isServiceActive)
                                "الفقاعة ظاهرة على حافة الشاشة. اضغط عليها في أي تطبيق لترجمة النصوص فوراً."
                            else
                                "اضغط زر التشغيل لبدء الفقاعة العائمة وترجمة أي شاشة بنقرة واحدة.",
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        // زر التحكم الرئيسي
                        Button(
                            onClick = {
                                if (isServiceActive) {
                                    stopFloatingService()
                                } else {
                                    startFloatingService()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isServiceActive) Color(0xFFE11D48) else CyanPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("toggle_service_button")
                        ) {
                            Icon(
                                imageVector = if (isServiceActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isServiceActive) "إيقاف الخدمة العائمة" else "تشغيل الخدمة والفقاعة",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }

            // 3. اختيار اللغات (Source & Target Languages)
            item {
                LanguageSelectorSection(
                    sourceLang = sourceLang,
                    targetLang = targetLang,
                    onSourceChanged = { AppSettings.setSourceLanguage(it) },
                    onTargetChanged = { AppSettings.setTargetLanguage(it) }
                )
            }

            // 4. خيارات أوضاع الترجمة الأربعة (Translation Modes)
            item {
                Text(
                    text = "وضع الترجمة المختار",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )
            }

            // سرد الأوضاع الأربعة
            items(TranslationMode.values().size) { index ->
                val mode = TranslationMode.values()[index]
                val isSelected = currentMode == mode

                TranslationModeCard(
                    mode = mode,
                    isSelected = isSelected,
                    onSelect = { AppSettings.setMode(mode) }
                )
            }

            // 5. تجربة فورية للترجمة داخل التطبيق (In-App Live Translation Demo)
            item {
                InteractiveTestCard(
                    currentMode = currentMode,
                    sourceLang = sourceLang,
                    targetLang = targetLang
                )
            }

            // 6. دليل الاستخدام السريع
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = CyanPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "كيفية الاستخدام؟",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "1. قم بتفعيل الخدمة العائمة عبر الزر في الأعلى.\n" +
                                    "2. ستظهر فقاعة زرقاء عائمة يمكنك تحريكها بحرية.\n" +
                                    "3. افتح أي تطبيق، لعبة، أو كتاب إلكتروني واضغط على الفقاعة.\n" +
                                    "4. سيتم التقاط الشاشة وترجمة جميع الكلمات وعرضها كطبقة شفافة فوق النص الأصلي فوراً.",
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

/**
 * قسم تحديد لغة المصدر والهدف مع زر التبديل
 */
@Composable
fun LanguageSelectorSection(
    sourceLang: String,
    targetLang: String,
    onSourceChanged: (String) -> Unit,
    onTargetChanged: (String) -> Unit
) {
    val languages = listOf(
        "en" to "الإنجليزية (English)",
        "ar" to "العربية (Arabic)",
        "fr" to "الفرنسية (French)",
        "de" to "الألمانية (German)",
        "es" to "الإسبانية (Spanish)",
        "tr" to "التركية (Turkish)",
        "ja" to "اليابانية (Japanese)",
        "zh" to "الصينية (Chinese)"
    )

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "إعدادات اللغات",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // لغة المصدر
                LanguageDropdown(
                    label = "من:",
                    selectedCode = sourceLang,
                    languages = languages,
                    onSelect = onSourceChanged,
                    modifier = Modifier.weight(1f)
                )

                // زر التبديل
                IconButton(
                    onClick = {
                        val temp = sourceLang
                        onSourceChanged(targetLang)
                        onTargetChanged(temp)
                    },
                    modifier = Modifier.padding(horizontal = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = "تبديل اللغات",
                        tint = CyanPrimary
                    )
                }

                // لغة الهدف
                LanguageDropdown(
                    label = "إلى:",
                    selectedCode = targetLang,
                    languages = languages,
                    onSelect = onTargetChanged,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun LanguageDropdown(
    label: String,
    selectedCode: String,
    languages: List<Pair<String, String>>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    val currentLabel = languages.find { it.first == selectedCode }?.second ?: selectedCode

    Box(modifier = modifier) {
        Column {
            Text(text = label, fontSize = 12.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = true }
                    .padding(vertical = 2.dp)
            ) {
                Text(
                    text = currentLabel.substringBefore(" ("),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                )
            }
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            languages.forEach { (code, name) ->
                DropdownMenuItem(
                    text = { Text(name) },
                    onClick = {
                        onSelect(code)
                        expanded = false
                    }
                )
            }
        }
    }
}

/**
 * بطاقة تمثل وضع ترجمة فردي
 */
@Composable
fun TranslationModeCard(
    mode: TranslationMode,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) CyanPrimary else Color.Transparent,
        label = "border_color"
    )

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) {
                CyanPrimary.copy(alpha = 0.08f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onSelect() }
            .testTag("mode_${mode.id}_card")
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // أيقونة الوضع
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isSelected) CyanPrimary.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.surfaceVariant
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = mode.icon,
                    contentDescription = null,
                    tint = if (isSelected) CyanPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // الوصف والعناوين
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = mode.titleAr,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    // شارة Pro أو مجاني
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (mode.isPro) IndigoSecondary.copy(alpha = 0.15f)
                                else EmeraldTertiary.copy(alpha = 0.15f)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = mode.badge,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (mode.isPro) IndigoSecondary else EmeraldTertiary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = mode.descriptionAr,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // مؤشر التحديد
            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "تم التحديد",
                    tint = CyanPrimary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

/**
 * بطاقة اختبار فوري للترجمة داخل التطبيق للتحقق من عمل ML Kit
 */
@Composable
fun InteractiveTestCard(
    currentMode: TranslationMode,
    sourceLang: String,
    targetLang: String
) {
    var sampleInput by remember {
        mutableStateOf("Bubble Translate makes reading foreign apps effortless and fast!")
    }
    var translatedResult by remember { mutableStateOf("") }
    var isTranslating by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "اختبار فوري للمحرك على الجهاز",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = CyanPrimary
            )
            Text(
                text = "جرب ترجمة هذا النص مباشرة باستخدام محرك ML Kit المحلي",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = sampleInput,
                onValueChange = { sampleInput = it },
                label = { Text("النص التجريبي") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    coroutineScope.launch {
                        isTranslating = true
                        try {
                            translatedResult = TranslationEngine.instance.translateWithAI(
                                text = sampleInput,
                                sourceLang = sourceLang,
                                targetLang = targetLang
                            )
                        } catch (e: Exception) {
                            translatedResult = "خطأ في الترجمة: ${e.message}"
                        } finally {
                            isTranslating = false
                        }
                    }
                },
                enabled = !isTranslating && sampleInput.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isTranslating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("جاري المعالجة...")
                } else {
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ترجمة تجريبية الآن")
                }
            }

            AnimatedVisibility(visible = translatedResult.isNotBlank()) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Text(
                        text = "النتيجة المترجمة:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldTertiary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = translatedResult,
                            modifier = Modifier.padding(12.dp),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
