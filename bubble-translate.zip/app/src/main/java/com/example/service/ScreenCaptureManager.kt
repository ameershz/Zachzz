package com.example.service

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * مدير التقاط لقطات الشاشة باستخدام MediaProjection و ImageReader
 * يتعامل مع أبعاد الشاشة ومطابقة البكسلات وتوليد Bitmap خالي من التشوه
 */
class ScreenCaptureManager(
    private val context: Context,
    private val mediaProjection: MediaProjection
) {

    companion object {
        private const val TAG = "ScreenCaptureManager"
    }

    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var screenWidth: Int = 1080
    private var screenHeight: Int = 1920
    private var screenDensity: Int = 420

    private val backgroundHandler = Handler(Looper.getMainLooper())

    init {
        updateScreenDimensions()
        setupVirtualDisplay()
    }

    /**
     * حساب أبعاد وكثافة شاشة الجهاز الحالية بدقة
     */
    private fun updateScreenDimensions() {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        if (screenWidth <= 0) screenWidth = 1080
        if (screenHeight <= 0) screenHeight = 1920
        if (screenDensity <= 0) screenDensity = 420

        Log.d(TAG, "Screen dimensions: ${screenWidth}x${screenHeight}, density: $screenDensity")
    }

    /**
     * إعداد VirtualDisplay و ImageReader لاستقبال إطارات الشاشة
     */
    private fun setupVirtualDisplay() {
        try {
            imageReader?.close()
            virtualDisplay?.release()

            imageReader = ImageReader.newInstance(
                screenWidth,
                screenHeight,
                PixelFormat.RGBA_8888,
                2
            )

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "BubbleTranslateCapture",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                backgroundHandler
            )
            Log.d(TAG, "VirtualDisplay created successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing VirtualDisplay: ${e.message}", e)
        }
    }

    /**
     * التقاط صورة الشاشة الحالية وإرجاعها كـ Bitmap
     */
    suspend fun captureScreen(): Bitmap? = withContext(Dispatchers.Default) {
        try {
            // انتظار قصير للتأكد من اكتمال رسم الشاشة
            delay(150)

            val reader = imageReader ?: run {
                setupVirtualDisplay()
                delay(150)
                imageReader
            } ?: return@withContext null

            // محاولة الحصول على أحدث إطار متاح
            var image: Image? = null
            withTimeoutOrNull(1500) {
                while (image == null) {
                    image = reader.acquireLatestImage()
                    if (image == null) {
                        delay(40)
                    }
                }
            }

            if (image == null) {
                Log.w(TAG, "Failed to acquire image frame from ImageReader within timeout")
                return@withContext null
            }

            val img = image!!
            val planes = img.planes
            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            // إنشاء Bitmap بحجم المخزن المؤقت مع مراعاة rowPadding
            val paddedBitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            paddedBitmap.copyPixelsFromBuffer(buffer)
            img.close()

            // قص الـ Bitmap للحجم الفعلي للشاشة للتخلص من الهوامش الزائدة
            val finalBitmap = if (paddedBitmap.width > screenWidth) {
                val cropped = Bitmap.createBitmap(paddedBitmap, 0, 0, screenWidth, screenHeight)
                if (cropped != paddedBitmap) {
                    paddedBitmap.recycle()
                }
                cropped
            } else {
                paddedBitmap
            }

            Log.d(TAG, "Screen captured successfully: ${finalBitmap.width}x${finalBitmap.height}")
            return@withContext finalBitmap
        } catch (e: Exception) {
            Log.e(TAG, "Exception during screen capture: ${e.message}", e)
            return@withContext null
        }
    }

    /**
     * تحرير موارد تسجيل الشاشة والذاكرة
     */
    fun release() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
            mediaProjection.stop()
            Log.d(TAG, "ScreenCaptureManager resources released")
        } catch (e: Exception) {
            Log.w(TAG, "Error during cleanup: ${e.message}")
        }
    }
}
