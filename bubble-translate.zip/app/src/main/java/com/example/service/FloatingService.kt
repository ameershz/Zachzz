package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.AppSettings
import com.example.data.TranslationEngine
import com.example.model.TranslatedBlock
import com.example.model.TranslationMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * الخدمة الخلفية المسؤولة عن إدارة الزر العائم والتقاط الشاشة والترجمة
 */
class FloatingService : Service() {

    companion object {
        private const val TAG = "FloatingService"
        const val CHANNEL_ID = "BubbleTranslateChannel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.service.START"
        const val ACTION_STOP = "com.example.service.STOP"
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager

    private var mediaProjection: MediaProjection? = null
    private var screenCaptureManager: ScreenCaptureManager? = null

    // الزر العائم
    private var bubbleView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    // الطبقة الشفافة لعرض نتائج الترجمة
    private var overlayContainer: View? = null

    private var screenWidth = 1080
    private var screenHeight = 1920

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        updateScreenMetrics()
        createNotificationChannel()
    }

    private fun updateScreenMetrics() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        if (action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // تشغيل كـ Foreground Service
        startForegroundServiceNotification()

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultCode != 0 && resultData != null) {
            setupMediaProjection(resultCode, resultData)
        }

        showFloatingBubble()
        AppSettings.setServiceActive(true)

        return START_STICKY
    }

    /**
     * إعداد قنوات الإشعارات والبدء كـ Foreground Service مع MediaProjection type
     */
    private fun startForegroundServiceNotification() {
        val stopIntent = Intent(this, FloatingService::class.java).apply {
            this.action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openAppIntent = Intent(this, MainActivity::class.java)
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("مترجم الشاشة العائم يعمل")
            .setContentText("اضغط على الفقاعة لترجمة محتوى الشاشة فوراً")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(openAppPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف الخدمة", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة ترجمة الشاشة العائمة",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار استمرار عمل الفقاعة العائمة للترجمة"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * تهيئة MediaProjection و ScreenCaptureManager
     */
    private fun setupMediaProjection(resultCode: Int, resultData: Intent) {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)

        mediaProjection?.let { projection ->
            screenCaptureManager = ScreenCaptureManager(this, projection)
            Log.d(TAG, "MediaProjection & ScreenCaptureManager initialized successfully")
        }
    }

    /**
     * إنشاء وعرض الزر العائم (Floating Bubble)
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun showFloatingBubble() {
        if (bubbleView != null) return

        val density = resources.displayMetrics.density
        val bubbleSize = (64 * density).toInt()

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        bubbleParams = WindowManager.LayoutParams(
            bubbleSize,
            bubbleSize,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenWidth - bubbleSize - (16 * density).toInt())
            y = (screenHeight * 0.35).toInt()
        }

        // تصميم الزر العائم برمجياً بمظهر عصري جذاب
        val bubbleLayout = FrameLayout(this).apply {
            val bg = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(Color.parseColor("#0284C7"), Color.parseColor("#4F46E5"))
                orientation = GradientDrawable.Orientation.TL_BR
                setStroke((2 * density).toInt(), Color.WHITE)
            }
            background = bg
            elevation = 16f * density
        }

        val iconView = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_search)
            setColorFilter(Color.WHITE)
            val padding = (14 * density).toInt()
            setPadding(padding, padding, padding, padding)
        }
        bubbleLayout.addView(
            iconView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                Gravity.CENTER
            )
        )

        // معالجة السحب والضغط (Drag & Drop + Click)
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isClick = true
        val clickThreshold = 10 * density

        bubbleLayout.setOnTouchListener { _, event ->
            val params = bubbleParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isClick = true
                    bubbleLayout.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (abs(dx) > clickThreshold || abs(dy) > clickThreshold) {
                        isClick = false
                    }
                    params.x = (initialX + dx).toInt()
                    params.y = (initialY + dy).toInt()
                    try {
                        windowManager.updateViewLayout(bubbleLayout, params)
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to update bubble position: ${e.message}")
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    bubbleLayout.animate().scaleX(1.0f).scaleY(1.0f).setDuration(120).start()
                    if (isClick) {
                        triggerVibration()
                        onBubbleClicked()
                    } else {
                        // إرساء الفقاعة على أقرب حافة جانبية للشاشة
                        snapBubbleToEdge(bubbleLayout, params)
                    }
                    true
                }
                else -> false
            }
        }

        bubbleView = bubbleLayout
        try {
            windowManager.addView(bubbleView, bubbleParams)
            Log.d(TAG, "Floating bubble added to WindowManager")
        } catch (e: Exception) {
            Log.e(TAG, "Error adding bubble view: ${e.message}", e)
        }
    }

    /**
     * إرساء الفقاعة برفق على الحافة اليمنى أو اليسرى للشاشة
     */
    private fun snapBubbleToEdge(view: View, params: WindowManager.LayoutParams) {
        val density = resources.displayMetrics.density
        val margin = (12 * density).toInt()
        val targetX = if (params.x + view.width / 2 < screenWidth / 2) {
            margin
        } else {
            screenWidth - view.width - margin
        }
        params.x = targetX
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: Exception) {
            Log.w(TAG, "Error snapping bubble: ${e.message}")
        }
    }

    /**
     * عند الضغط على الفقاعة:
     * 1. إخفاء الفقاعة مؤقتاً
     * 2. التقاط صورة الشاشة
     * 3. إعادة الفقاعة
     * 4. استخراج وترجمة النص وعرض الطبقة الشفافة
     */
    private fun onBubbleClicked() {
        serviceScope.launch {
            // إخفاء مؤقت للفقاعة حتى لا تشوه لقطة الشاشة
            bubbleView?.visibility = View.INVISIBLE
            delay(80)

            val captureManager = screenCaptureManager
            if (captureManager == null) {
                bubbleView?.visibility = View.VISIBLE
                Toast.makeText(
                    this@FloatingService,
                    "يرجى فتح التطبيق ومنح إذن التقاط الشاشة أولاً",
                    Toast.LENGTH_LONG
                ).show()
                return@launch
            }

            // التقاط الشاشة
            val bitmap = captureManager.captureScreen()
            bubbleView?.visibility = View.VISIBLE

            if (bitmap == null) {
                Toast.makeText(
                    this@FloatingService,
                    "تعذر التقاط محتوى الشاشة، تحقق من الأذونات",
                    Toast.LENGTH_SHORT
                ).show()
                return@launch
            }

            // إظهار واجهة مؤشر الترجمة جاري العمل
            showLoadingOverlay()

            val mode = AppSettings.selectedMode.value
            val sourceLang = AppSettings.sourceLanguage.value
            val targetLang = AppSettings.targetLanguage.value

            val translatedBlocks = try {
                TranslationEngine.instance.processScreenCapture(
                    bitmap = bitmap,
                    mode = mode,
                    sourceLang = sourceLang,
                    targetLang = targetLang
                )
            } catch (e: Exception) {
                Log.e(TAG, "Translation error: ${e.message}", e)
                emptyList()
            }

            // إزالة مؤشر التحميل وعرض طبقة النتائج الشفافة
            hideOverlay()
            if (translatedBlocks.isEmpty()) {
                Toast.makeText(
                    this@FloatingService,
                    "لم يتم العثور على نصوص قابلة للترجمة في الشاشة الحالية",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                showTranslatedOverlay(translatedBlocks, mode)
            }
        }
    }

    /**
     * عرض مؤشر تحميل أنيق فوق الشاشة أثناء معالجة الترجمة
     */
    private fun showLoadingOverlay() {
        hideOverlay()

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val density = resources.displayMetrics.density
        val loadingBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding((24 * density).toInt(), (16 * density).toInt(), (24 * density).toInt(), (16 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EE1E293B"))
                cornerRadius = 24 * density
            }
        }

        val progressBar = ProgressBar(this).apply {
            val size = (28 * density).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginEnd = (14 * density).toInt()
            }
        }

        val statusText = TextView(this).apply {
            text = "جاري ترجمة الشاشة..."
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
        }

        loadingBox.addView(progressBar)
        loadingBox.addView(statusText)

        overlayContainer = loadingBox
        try {
            windowManager.addView(overlayContainer, params)
        } catch (e: Exception) {
            Log.e(TAG, "Error showing loading overlay: ${e.message}")
        }
    }

    /**
     * عرض الطبقة الشفافة (Transparent Overlay) وترجمة النصوص فوق الشاشة الأصلية
     */
    private fun showTranslatedOverlay(blocks: List<TranslatedBlock>, mode: TranslationMode) {
        hideOverlay()

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        val density = resources.displayMetrics.density

        // الحاوية الأساسية الشفافة
        val rootLayout = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#44000000")) // عتامة شفافة 25%
            setOnClickListener { hideOverlay() }
        }

        // عرض مربعات النصوص المترجمة مباشرة في مكانها الأصلي (Bounding Boxes Overlay)
        val textCanvasView = object : View(this) {
            private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#DD0F172A")
                style = Paint.Style.FILL
            }
            private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#38BDF8")
                strokeWidth = 2 * density
                style = Paint.Style.STROKE
            }
            private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 14f * density
                typeface = Typeface.DEFAULT_BOLD
            }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                for (block in blocks) {
                    val box = block.boundingBox ?: continue
                    // رسم خلفية الصندوق
                    val radius = 6 * density
                    canvas.drawRoundRect(
                        box.left.toFloat() - 4 * density,
                        box.top.toFloat() - 2 * density,
                        box.right.toFloat() + 4 * density,
                        box.bottom.toFloat() + 2 * density,
                        radius,
                        radius,
                        boxPaint
                    )
                    canvas.drawRoundRect(
                        box.left.toFloat() - 4 * density,
                        box.top.toFloat() - 2 * density,
                        box.right.toFloat() + 4 * density,
                        box.bottom.toFloat() + 2 * density,
                        radius,
                        radius,
                        strokePaint
                    )
                    // رسم النص المترجم
                    val drawText = if (block.translatedText.length > 25) {
                        block.translatedText.take(22) + "..."
                    } else {
                        block.translatedText
                    }
                    val textY = box.centerY() + (textPaint.textSize / 3)
                    canvas.drawText(drawText, box.left.toFloat(), textY, textPaint)
                }
            }
        }
        rootLayout.addView(
            textCanvasView,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )

        // بطاقة سفلية عائمة تعرض قائمة النتائج بشكل كامل ومنسق
        val resultsCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F81E293B"))
                cornerRadii = floatArrayOf(
                    24 * density, 24 * density,
                    24 * density, 24 * density,
                    0f, 0f, 0f, 0f
                )
            }
            setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (20 * density).toInt())
            isClickable = true
        }

        // شريط الرأس للبطاقة
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleView = TextView(this).apply {
            text = "الترجمة الفورية (${mode.titleAr})"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        // زر نسخ الكل
        val copyBtn = TextView(this).apply {
            text = "نسخ النص"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 13f
            setPadding((8 * density).toInt(), (4 * density).toInt(), (8 * density).toInt(), (4 * density).toInt())
            setOnClickListener {
                val allText = blocks.joinToString("\n\n") { it.translatedText }
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Bubble Translation", allText))
                Toast.makeText(this@FloatingService, "تم نسخ الترجمة للحافظة", Toast.LENGTH_SHORT).show()
            }
        }

        // زر إغلاق
        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.LTGRAY)
            textSize = 18f
            setPadding((12 * density).toInt(), (4 * density).toInt(), (4 * density).toInt(), (4 * density).toInt())
            setOnClickListener { hideOverlay() }
        }

        headerLayout.addView(titleView)
        headerLayout.addView(copyBtn)
        headerLayout.addView(closeBtn)
        resultsCard.addView(headerLayout)

        // فاصل
        val divider = View(this).apply {
            setBackgroundColor(Color.parseColor("#334155"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (1 * density).toInt()).apply {
                topMargin = (10 * density).toInt()
                bottomMargin = (10 * density).toInt()
            }
        }
        resultsCard.addView(divider)

        // قائمة كتل النصوص المترجمة قابلة للتمرير
        val scrollView = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (screenHeight * 0.35).toInt()
            )
        }

        val blocksListLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        for ((index, item) in blocks.withIndex()) {
            val itemBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((12 * density).toInt(), (10 * density).toInt(), (12 * density).toInt(), (10 * density).toInt())
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#15233D"))
                    cornerRadius = 12 * density
                }
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = (8 * density).toInt()
                }
            }

            // النص المترجم
            val translatedTv = TextView(this).apply {
                text = item.translatedText
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
            }

            // النص الأصلي
            val originalTv = TextView(this).apply {
                text = "الأصل: ${item.originalText}"
                setTextColor(Color.parseColor("#94A3B8"))
                textSize = 12f
                setPadding(0, (4 * density).toInt(), 0, 0)
            }

            itemBox.addView(translatedTv)
            itemBox.addView(originalTv)
            blocksListLayout.addView(itemBox)
        }

        scrollView.addView(blocksListLayout)
        resultsCard.addView(scrollView)

        // وضع البطاقة أسفل الشاشة
        val cardParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        )
        rootLayout.addView(resultsCard, cardParams)

        overlayContainer = rootLayout
        try {
            windowManager.addView(overlayContainer, params)
        } catch (e: Exception) {
            Log.e(TAG, "Error displaying translation overlay: ${e.message}")
        }
    }

    /**
     * إغلاق وحذف الطبقة الشفافة
     */
    private fun hideOverlay() {
        overlayContainer?.let { container ->
            try {
                windowManager.removeView(container)
            } catch (e: Exception) {
                Log.w(TAG, "Failed to remove overlay container: ${e.message}")
            }
            overlayContainer = null
        }
    }

    private fun triggerVibration() {
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(30)
            }
        } catch (e: Exception) {
            // تجاهل أخطاء الاهتزاز
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        hideOverlay()

        bubbleView?.let { bubble ->
            try {
                windowManager.removeView(bubble)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing bubble: ${e.message}")
            }
            bubbleView = null
        }

        screenCaptureManager?.release()
        screenCaptureManager = null

        AppSettings.setServiceActive(false)
        Log.d(TAG, "FloatingService destroyed")
    }
}
