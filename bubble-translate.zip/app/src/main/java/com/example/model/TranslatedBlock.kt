package com.example.model

import android.graphics.Rect

/**
 * يمثل كتلة نصية تم استخراجها من الشاشة وترجمتها
 */
data class TranslatedBlock(
    val originalText: String,
    val translatedText: String,
    val boundingBox: Rect?,
    val isAdOrPromo: Boolean = false,
    val confidence: Float = 1.0f
)
