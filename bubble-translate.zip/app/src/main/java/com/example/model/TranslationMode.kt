package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.OfflineBolt
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * أوضاع الترجمة المتاحة في تطبيق Bubble Translate
 */
enum class TranslationMode(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val descriptionAr: String,
    val isPro: Boolean,
    val badge: String
) {
    OFFLINE(
        id = "offline",
        titleAr = "الترجمة دون اتصال",
        titleEn = "Offline ML Kit",
        descriptionAr = "معالجة فورية على الجهاز دون استهلاك بيانات باستخدام Google ML Kit",
        isPro = false,
        badge = "محلي مجاني"
    ),
    OCR_CLOUD_PRO(
        id = "ocr_cloud_pro",
        titleAr = "التعرف عالي الدقة",
        titleEn = "High-Accuracy OCR - Pro",
        descriptionAr = "استخراج نصوص دقيق بالاعتماد على خوارزميات Cloud Vision السحابية",
        isPro = true,
        badge = "Pro"
    ),
    AI_TRANSLATION_PRO(
        id = "ai_translation_pro",
        titleAr = "الترجمة بالذكاء الاصطناعي",
        titleEn = "AI Translation - Pro",
        descriptionAr = "ترجمة سياقية ذكية تحافظ على المعنى الاصطلاحي عبر نماذج LLM",
        isPro = true,
        badge = "Pro AI"
    ),
    ENHANCED_AI_PRO(
        id = "enhanced_ai_pro",
        titleAr = "الترجمة بالذكاء الاصطناعي المحسن",
        titleEn = "+Enhanced AI - Pro",
        descriptionAr = "تحليل الصورة وتجاوز الإعلانات والمحتوى الترويجي وترجمة النص الأساسي فقط",
        isPro = true,
        badge = "Vision AI+"
    );

    val icon: ImageVector
        get() = when (this) {
            OFFLINE -> Icons.Default.OfflineBolt
            OCR_CLOUD_PRO -> Icons.Default.CloudDone
            AI_TRANSLATION_PRO -> Icons.Default.AutoAwesome
            ENHANCED_AI_PRO -> Icons.Default.Visibility
        }
}
