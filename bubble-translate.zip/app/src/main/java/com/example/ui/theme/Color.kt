package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyanPrimary = Color(0xFF0284C7)
val CyanPrimaryDark = Color(0xFF38BDF8)
val IndigoSecondary = Color(0xFF6366F1)
val EmeraldTertiary = Color(0xFF10B981)

val DarkBackground = Color(0xFF0B132B)
val DarkSurface = Color(0xFF1C2541)
val DarkSurfaceVariant = Color(0xFF243356)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
