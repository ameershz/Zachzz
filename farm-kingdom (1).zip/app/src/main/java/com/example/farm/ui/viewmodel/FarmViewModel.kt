package com.example.farm.ui.viewmodel

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.farm.auth.AuthManager
import com.example.farm.auth.AuthState
import com.example.farm.data.local.FarmDatabase
import com.example.farm.data.local.FarmPlotEntity
import com.example.farm.data.remote.ConnectionState
import com.example.farm.data.remote.FirestoreDataSource
import com.example.farm.data.remote.NetworkStatusObserver
import com.example.farm.data.repository.FarmRepository
import com.example.farm.ui.localization.GameStrings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab {
    FARM,
    SHOP,
    PRODUCTION,
    ORDERS,
    PROFILE,
    SETTINGS,
    SILO,
    VISIT_PLAYERS,
    VISITING_FARM
}

class FarmViewModel(application: Application) : AndroidViewModel(application) {
    private val db = FarmDatabase.getDatabase(application)
    val firestoreDataSource = FirestoreDataSource(application)
    val networkObserver = NetworkStatusObserver(application)
    val authManager = AuthManager(application)

    val repository = FarmRepository(db, firestoreDataSource, networkObserver)

    val authState: StateFlow<AuthState> = authManager.authState
    val connectionState: StateFlow<ConnectionState> = networkObserver.connectionStatus
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ConnectionState.ONLINE)
    val syncingState: StateFlow<Boolean> = repository.syncingState

    val player = repository.player.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val plots = repository.plots.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val inventory = repository.inventory.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val animals = repository.animals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val productionBuildings = repository.productionBuildings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val dailyReward = repository.dailyReward.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val buildings = repository.buildings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val orders = repository.orders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val quests = repository.quests.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val transactions = repository.recentTransactions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Phase 5 Social & Visiting State
    private val _publicProfiles = MutableStateFlow<List<com.example.farm.data.model.PublicProfile>>(emptyList())
    val publicProfiles: StateFlow<List<com.example.farm.data.model.PublicProfile>> = _publicProfiles.asStateFlow()

    private val _visitingProfile = MutableStateFlow<com.example.farm.data.model.PublicProfile?>(null)
    val visitingProfile: StateFlow<com.example.farm.data.model.PublicProfile?> = _visitingProfile.asStateFlow()

    private val _visitingFarm = MutableStateFlow<com.example.farm.data.model.PublicFarm?>(null)
    val visitingFarm: StateFlow<com.example.farm.data.model.PublicFarm?> = _visitingFarm.asStateFlow()

    private val _isVisitingLoading = MutableStateFlow(false)
    val isVisitingLoading: StateFlow<Boolean> = _isVisitingLoading.asStateFlow()

    private val _isLiking = MutableStateFlow(false)
    val isLiking: StateFlow<Boolean> = _isLiking.asStateFlow()


    private val _currentTab = MutableStateFlow(MainTab.FARM)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _selectedPlotForPlanting = MutableStateFlow<FarmPlotEntity?>(null)
    val selectedPlotForPlanting: StateFlow<FarmPlotEntity?> = _selectedPlotForPlanting.asStateFlow()

    private val _currentTime = MutableStateFlow(System.currentTimeMillis())
    val currentTime: StateFlow<Long> = _currentTime.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _levelUpDialog = MutableStateFlow<Int?>(null)
    val levelUpDialog: StateFlow<Int?> = _levelUpDialog.asStateFlow()

    init {
        // Real-time ticking loop every 1s
        viewModelScope.launch {
            while (true) {
                _currentTime.value = System.currentTimeMillis()
                repository.checkAndUpdateGrowthTimestamps()
                delay(1000L)
            }
        }

        // Observe authState changes to attach or detach repository user session
        viewModelScope.launch {
            authManager.authState.collect { state ->
                when (state) {
                    is AuthState.Authenticated -> {
                        repository.attachUserSession(
                            uid = state.user.uid,
                            displayName = state.user.displayName ?: "Farmer",
                            scope = viewModelScope
                        )
                    }
                    is AuthState.Unauthenticated -> {
                        repository.detachUserSession()
                    }
                    else -> Unit
                }
            }
        }

        authManager.attemptAutoSignIn(viewModelScope)
    }

    fun setTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun openPlantingSheet(plot: FarmPlotEntity) {
        _selectedPlotForPlanting.value = plot
    }

    fun closePlantingSheet() {
        _selectedPlotForPlanting.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun dismissLevelUpDialog() {
        _levelUpDialog.value = null
    }

    fun signInWithGoogle(activity: Activity) {
        authManager.signInWithGoogle(activity, viewModelScope)
    }

    fun signOut() {
        authManager.signOut(viewModelScope)
        repository.detachUserSession()
        showToast(if (isArabic()) "تم تسجيل الخروج بنجاح" else "Signed out successfully")
    }

    // GAME ACTIONS

    fun plantCrop(plotIndex: Int, cropId: String) {
        viewModelScope.launch {
            val result = repository.plantCrop(plotIndex, cropId)
            closePlantingSheet()
            if (result.isSuccess) {
                showToast(GameStrings.t("crop_planted_success", isArabic()))
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Failed to plant crop")
            }
        }
    }

    fun harvestCrop(plotIndex: Int) {
        viewModelScope.launch {
            val result = repository.harvestCrop(plotIndex)
            if (result.isSuccess) {
                val harvest = result.getOrNull()
                val cropName = if (isArabic()) harvest?.cropNameAr else harvest?.cropNameEn
                showToast("${GameStrings.t("harvest_success", isArabic())}: $cropName (+${harvest?.xpGained} XP)")
                if (harvest?.leveledUp == true) {
                    _levelUpDialog.value = harvest.newLevel
                }
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Harvest failed")
            }
        }
    }

    fun harvestAllReady() {
        viewModelScope.launch {
            val result = repository.harvestAllReadyPlots()
            if (result.isSuccess) {
                val count = result.getOrNull() ?: 0
                if (count > 0) {
                    showToast(if (isArabic()) "تم حصاد $count محاصيل بنجاح! 🌾" else "Harvested $count crops! 🌾")
                } else {
                    showToast(if (isArabic()) "لا توجد محاصيل جاهزة للحصاد حالياً" else "No crops ready to harvest right now")
                }
            }
        }
    }

    fun buySeeds(cropId: String, quantity: Int = 1) {
        viewModelScope.launch {
            val result = repository.buySeeds(cropId, quantity)
            if (result.isSuccess) {
                showToast(GameStrings.t("seed_purchased_success", isArabic()))
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Purchase failed")
            }
        }
    }

    fun sellItem(itemId: String, quantity: Int = 1) {
        viewModelScope.launch {
            val result = repository.sellItem(itemId, quantity)
            if (result.isSuccess) {
                val earned = result.getOrNull() ?: 0
                showToast("${GameStrings.t("crop_sold_success", isArabic())} (+$earned Coins)")
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Sale failed")
            }
        }
    }

    fun buyAnimal(animalType: String) {
        viewModelScope.launch {
            val result = repository.buyAnimal(animalType)
            if (result.isSuccess) {
                showToast(if (isArabic()) "مبروك! تم شراء الحيوان بنجاح 🐾" else "Animal adopted successfully! 🐾")
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Failed to buy animal")
            }
        }
    }

    fun feedAnimal(animalId: String) {
        viewModelScope.launch {
            val result = repository.feedAnimal(animalId)
            if (result.isSuccess) {
                showToast(if (isArabic()) "تم إطعام الحيوان! بدأ الإنتاج ⏳" else "Animal fed! Production started ⏳")
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Failed to feed animal")
            }
        }
    }

    fun collectAnimalProduct(animalId: String) {
        viewModelScope.launch {
            val result = repository.collectAnimalProduct(animalId)
            if (result.isSuccess) {
                val res = result.getOrNull()
                val name = if (isArabic()) res?.cropNameAr else res?.cropNameEn
                showToast(if (isArabic()) "تم جمع $name (+${res?.xpGained} خبرة)! ✨" else "Collected $name (+${res?.xpGained} XP)! ✨")
                if (res?.leveledUp == true) {
                    _levelUpDialog.value = res.newLevel
                }
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Collection failed")
            }
        }
    }

    fun unlockBuilding(buildingId: String) {
        viewModelScope.launch {
            val result = repository.unlockBuilding(buildingId)
            if (result.isSuccess) {
                showToast(if (isArabic()) "تهانينا! تم بناء المصنع بنجاح 🏗️" else "Building constructed successfully! 🏗️")
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Failed to build")
            }
        }
    }

    fun startProduction(buildingId: String, recipeId: String) {
        viewModelScope.launch {
            val result = repository.startProduction(buildingId, recipeId)
            if (result.isSuccess) {
                showToast(if (isArabic()) "بدأت عملية الصناعة! ⏱️" else "Crafting started! ⏱️")
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Failed to start production")
            }
        }
    }

    fun collectProduction(buildingId: String) {
        viewModelScope.launch {
            val result = repository.collectProduction(buildingId)
            if (result.isSuccess) {
                val res = result.getOrNull()
                val name = if (isArabic()) res?.cropNameAr else res?.cropNameEn
                showToast(if (isArabic()) "تم استلام $name (+${res?.xpGained} خبرة)! 🥖" else "Crafted $name (+${res?.xpGained} XP)! 🥖")
                if (res?.leveledUp == true) {
                    _levelUpDialog.value = res.newLevel
                }
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Failed to collect")
            }
        }
    }

    fun claimDailyReward() {
        viewModelScope.launch {
            val result = repository.claimDailyReward()
            if (result.isSuccess) {
                val res = result.getOrNull()
                showToast(if (isArabic()) "تم استلام مكافأة اليوم ${res?.day} (+${res?.coins} ذهب، +${res?.gems} مجوهرات)! 🎁" else "Claimed Day ${res?.day} Reward (+${res?.coins} Coins, +${res?.gems} Gems)! 🎁")
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Reward not available yet")
            }
        }
    }

    fun upgradeSilo() {
        viewModelScope.launch {
            val result = repository.upgradeSilo()
            if (result.isSuccess) {
                val newCap = result.getOrNull()
                showToast("${GameStrings.t("silo_upgraded_success", isArabic())}: $newCap")
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Upgrade failed")
            }
        }
    }

    fun expandLand(plotIndex: Int) {
        viewModelScope.launch {
            val result = repository.expandLand(plotIndex)
            if (result.isSuccess) {
                showToast(GameStrings.t("plot_unlocked_success", isArabic()))
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Expansion failed")
            }
        }
    }

    fun completeOrder(orderId: String) {
        viewModelScope.launch {
            val result = repository.completeOrder(orderId)
            if (result.isSuccess) {
                val harvest = result.getOrNull()
                showToast("${GameStrings.t("order_completed_success", isArabic())} (+${harvest?.xpGained} XP)")
                if (harvest?.leveledUp == true) {
                    _levelUpDialog.value = harvest.newLevel
                }
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Order fulfillment failed")
            }
        }
    }

    fun claimQuest(questId: String) {
        viewModelScope.launch {
            val result = repository.claimQuest(questId)
            if (result.isSuccess) {
                val harvest = result.getOrNull()
                showToast("${GameStrings.t("quest_claimed_success", isArabic())} (+${harvest?.xpGained} XP)")
                if (harvest?.leveledUp == true) {
                    _levelUpDialog.value = harvest.newLevel
                }
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Quest claim failed")
            }
        }
    }

    fun toggleLanguage() {
        val current = player.value?.language ?: "ar"
        val next = if (current == "ar") "en" else "ar"
        viewModelScope.launch {
            repository.updatePreferences(language = next)
        }
    }

    fun toggleSound() {
        val current = player.value?.soundEnabled ?: true
        viewModelScope.launch {
            repository.updatePreferences(soundEnabled = !current)
        }
    }

    fun toggleHaptic() {
        val current = player.value?.hapticEnabled ?: true
        viewModelScope.launch {
            repository.updatePreferences(hapticEnabled = !current)
        }
    }

    fun updateFarmName(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val result = repository.updatePreferences(farmName = name.trim())
            if (result.isSuccess) {
                showToast(if (isArabic()) "تم حفظ اسم المزرعة بنجاح! 🌾" else "Farm name saved! 🌾")
            }
        }
    }

    // PHASE 5: Social & Farm Visiting Methods
    fun loadPublicProfiles() {
        viewModelScope.launch {
            _isVisitingLoading.value = true
            repository.publishCurrentPlayerPublicProfile()
            val result = repository.refreshPublicProfiles()
            if (result.isSuccess) {
                _publicProfiles.value = result.getOrDefault(emptyList())
            }
            _isVisitingLoading.value = false
        }
    }

    fun visitPlayerFarm(profile: com.example.farm.data.model.PublicProfile) {
        viewModelScope.launch {
            _visitingProfile.value = profile
            _currentTab.value = MainTab.VISITING_FARM
            _isVisitingLoading.value = true

            // Record visit asynchronously
            repository.recordFarmVisit(profile.uid)

            val result = repository.getPublicFarmSnapshot(profile.uid)
            if (result.isSuccess) {
                _visitingFarm.value = result.getOrNull()
            } else {
                showToast(result.exceptionOrNull()?.message ?: "Failed to load farm snapshot")
            }
            _isVisitingLoading.value = false
        }
    }

    fun likeVisitedFarm() {
        val currentVisiting = _visitingProfile.value ?: return
        if (currentVisiting.isLikedByMe || _isLiking.value) return

        viewModelScope.launch {
            _isLiking.value = true
            val result = repository.likePlayerFarm(currentVisiting.uid)
            if (result.isSuccess && result.getOrDefault(false)) {
                _visitingProfile.value = currentVisiting.copy(
                    likeCount = currentVisiting.likeCount + 1,
                    isLikedByMe = true
                )
                showToast(String.format(GameStrings.t("liked_success", isArabic()), currentVisiting.displayName))
            } else {
                showToast(GameStrings.t("already_liked", isArabic()))
            }
            _isLiking.value = false
        }
    }

    fun returnToMyFarm() {
        _visitingProfile.value = null
        _visitingFarm.value = null
        _currentTab.value = MainTab.FARM
    }

    private fun isArabic(): Boolean {
        return player.value?.language == "ar"
    }
}

