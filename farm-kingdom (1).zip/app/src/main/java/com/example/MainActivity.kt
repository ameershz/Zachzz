package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.farm.auth.AuthState
import com.example.farm.data.remote.ConnectionState
import com.example.farm.ui.components.BottomNavBar
import com.example.farm.ui.components.LevelUpDialog
import com.example.farm.ui.components.SeedPlantingSheet
import com.example.farm.ui.components.TopFarmBar
import com.example.farm.ui.screens.AuthScreen
import com.example.farm.ui.screens.FarmGridScreen
import com.example.farm.ui.screens.OrdersScreen
import com.example.farm.ui.screens.ProductionScreen
import com.example.farm.ui.screens.ProfileScreen
import com.example.farm.ui.screens.SettingsScreen
import com.example.farm.ui.screens.ShopScreen
import com.example.farm.ui.screens.SiloScreen
import com.example.farm.ui.screens.VisitPlayersScreen
import com.example.farm.ui.screens.VisitingFarmScreen
import com.example.farm.ui.viewmodel.FarmViewModel
import com.example.farm.ui.viewmodel.MainTab

import com.example.ui.theme.FarmGoldWheat
import com.example.ui.theme.FarmGreenDark
import com.example.ui.theme.FarmKingdomTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val viewModel: FarmViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val authState by viewModel.authState.collectAsStateWithLifecycle()
            val player by viewModel.player.collectAsStateWithLifecycle()
            val isAr = (player?.language ?: "ar") == "ar"

            FarmKingdomTheme {
                CompositionLocalProvider(
                    LocalLayoutDirection provides (if (isAr) LayoutDirection.Rtl else LayoutDirection.Ltr)
                ) {
                    when (authState) {
                        is AuthState.Authenticated -> {
                            FarmGameApp(viewModel = viewModel, activity = this@MainActivity)
                        }
                        is AuthState.Initializing -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(FarmGreenDark),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = FarmGoldWheat)
                            }
                        }
                        else -> {
                            AuthScreen(
                                authState = authState,
                                isAr = isAr,
                                onSignInClicked = { activity -> viewModel.signInWithGoogle(activity) },
                                onToggleLanguage = { viewModel.toggleLanguage() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FarmGameApp(viewModel: FarmViewModel, activity: ComponentActivity) {
    val authState by viewModel.authState.collectAsStateWithLifecycle()
    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val isSyncing by viewModel.syncingState.collectAsStateWithLifecycle()
    val player by viewModel.player.collectAsStateWithLifecycle()
    val plots by viewModel.plots.collectAsStateWithLifecycle()
    val inventory by viewModel.inventory.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val quests by viewModel.quests.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()

    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val selectedPlotForPlanting by viewModel.selectedPlotForPlanting.collectAsStateWithLifecycle()
    val currentTime by viewModel.currentTime.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val levelUpDialog by viewModel.levelUpDialog.collectAsStateWithLifecycle()

    // Phase 5 Social States
    val publicProfiles by viewModel.publicProfiles.collectAsStateWithLifecycle()
    val visitingProfile by viewModel.visitingProfile.collectAsStateWithLifecycle()
    val visitingFarm by viewModel.visitingFarm.collectAsStateWithLifecycle()
    val isVisitingLoading by viewModel.isVisitingLoading.collectAsStateWithLifecycle()
    val isLiking by viewModel.isLiking.collectAsStateWithLifecycle()

    val isAr = (player?.language ?: "ar") == "ar"

    // Load public profiles when navigating to VISIT_PLAYERS
    LaunchedEffect(currentTab) {
        if (currentTab == MainTab.VISIT_PLAYERS) {
            viewModel.loadPublicProfiles()
        }
    }

    // Back button handling
    BackHandler(enabled = currentTab != MainTab.FARM) {
        if (currentTab == MainTab.VISITING_FARM) {
            viewModel.returnToMyFarm()
        } else {
            viewModel.setTab(MainTab.FARM)
        }
    }


    // Auto-dismiss toast
    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            delay(2800L)
            viewModel.clearToast()
        }
    }

    Scaffold(
        topBar = {
            TopFarmBar(
                player = player,
                onToggleLanguage = { viewModel.toggleLanguage() },
                onToggleSound = { viewModel.toggleSound() },
                isOnline = connectionState == ConnectionState.ONLINE,
                isSyncing = isSyncing
            )
        },
        bottomBar = {
            BottomNavBar(
                selectedTab = currentTab,
                onTabSelected = { viewModel.setTab(it) },
                isAr = isAr
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Tab Content
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    MainTab.FARM -> FarmGridScreen(
                        player = player,
                        plots = plots,
                        currentTime = currentTime,
                        isAr = isAr,
                        onPlantClick = { viewModel.openPlantingSheet(it) },
                        onHarvestClick = { viewModel.harvestCrop(it) },
                        onUnlockClick = { viewModel.expandLand(it) },
                        onHarvestAllClick = { viewModel.harvestAllReady() }
                    )
                    MainTab.SHOP -> ShopScreen(
                        player = player,
                        inventory = inventory,
                        isAr = isAr,
                        onBuySeed = { cropId, qty -> viewModel.buySeeds(cropId, qty) },
                        onBuyAnimal = { animalType -> viewModel.buyAnimal(animalType) },
                        onUnlockBuilding = { bId -> viewModel.unlockBuilding(bId) },
                        onUpgradeSilo = { viewModel.upgradeSilo() }
                    )
                    MainTab.PRODUCTION -> ProductionScreen(
                        viewModel = viewModel
                    )
                    MainTab.SILO -> SiloScreen(
                        player = player,
                        inventory = inventory,
                        isAr = isAr,
                        onSellItem = { itemId, qty -> viewModel.sellItem(itemId, qty) },
                        onUpgradeStorage = { viewModel.upgradeSilo() }
                    )
                    MainTab.ORDERS -> OrdersScreen(
                        orders = orders,
                        quests = quests,
                        inventory = inventory,
                        isAr = isAr,
                        onDeliverOrder = { viewModel.completeOrder(it) },
                        onClaimQuest = { viewModel.claimQuest(it) }
                    )
                    MainTab.PROFILE -> ProfileScreen(
                        viewModel = viewModel,
                        onSaveFarmName = { viewModel.updateFarmName(it) }
                    )
                    MainTab.SETTINGS -> SettingsScreen(
                        player = player,
                        isAr = isAr,
                        userEmail = (authState as? AuthState.Authenticated)?.user?.email,
                        onToggleSound = { viewModel.toggleSound() },
                        onToggleHaptic = { viewModel.toggleHaptic() },
                        onToggleLanguage = { viewModel.toggleLanguage() },
                        onResetGame = { viewModel.signOut() },
                        onSignOut = { viewModel.signOut() }
                    )
                    MainTab.VISIT_PLAYERS -> VisitPlayersScreen(
                        publicProfiles = publicProfiles,
                        isLoading = isVisitingLoading,
                        isAr = isAr,
                        onVisitFarm = { profile -> viewModel.visitPlayerFarm(profile) },
                        onSearchQueryChange = { }
                    )
                    MainTab.VISITING_FARM -> {
                        visitingProfile?.let { prof ->
                            VisitingFarmScreen(
                                profile = prof,
                                farm = visitingFarm,
                                isLoading = isVisitingLoading,
                                isLiking = isLiking,
                                isAr = isAr,
                                onLikeClick = { viewModel.likeVisitedFarm() },
                                onBackToMyFarm = { viewModel.returnToMyFarm() }
                            )
                        }
                    }
                }
            }


            // In-Game Toast Banner
            AnimatedVisibility(
                visible = toastMessage != null,
                enter = slideInVertically { -it } + fadeIn(),
                exit = slideOutVertically { -it } + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(FarmGreenDark.copy(alpha = 0.95f))
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = toastMessage ?: "",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }

    // Modal Seed Planting Bottom Sheet
    selectedPlotForPlanting?.let { plot ->
        SeedPlantingSheet(
            plot = plot,
            inventory = inventory,
            isAr = isAr,
            onPlantSeed = { cropId -> viewModel.plantCrop(plot.plotIndex, cropId) },
            onDismiss = { viewModel.closePlantingSheet() },
            onGoToShop = {
                viewModel.closePlantingSheet()
                viewModel.setTab(MainTab.SHOP)
            }
        )
    }

    // Level Up Celebratory Dialog
    levelUpDialog?.let { newLevel ->
        LevelUpDialog(
            newLevel = newLevel,
            isAr = isAr,
            onDismiss = { viewModel.dismissLevelUpDialog() }
        )
    }
}
