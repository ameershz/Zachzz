package com.example.model

data class PlayerProfile(
    val playerId: String = "player_${System.currentTimeMillis() % 100000}",
    val username: String = "RedFinger#42",
    val avatarEmoji: String = "🔴",
    val isGuest: Boolean = true,
    val isOnlineSynced: Boolean = false,
    val coins: Long = 0L,
    val xp: Long = 0L,
    val level: Int = 1,
    val totalPresses: Long = 0L,
    val currentStreak: Int = 1,
    val highestStreak: Int = 1,
    val lastActiveEpochDay: Long = 0L,
    val equippedSkinId: String = "skin_classic_red",
    val unlockedSkinIds: Set<String> = setOf("skin_classic_red"),
    val unlockedAchievementIds: Set<String> = emptySet(),
    val claimedAchievementIds: Set<String> = emptySet(),
    val completedDailyChallenges: Int = 0,
    val rulesSurfaced: Int = 0,
    val rulesSucceeded: Int = 0
)

data class LevelInfo(
    val level: Int,
    val currentXpInLevel: Long,
    val xpNeededForNextLevel: Long,
    val progressFraction: Float
)
