package com.example.model

data class LeaderboardEntry(
    val rank: Int,
    val username: String,
    val avatarEmoji: String,
    val level: Int,
    val totalPresses: Long,
    val score: Long,
    val isCurrentPlayer: Boolean = false
)

data class GameEvent(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val iconEmoji: String,
    val coinsMultiplier: Float = 1.0f,
    val xpMultiplier: Float = 1.0f,
    val specialRuleBonus: Float = 1.0f,
    val isFeatured: Boolean = true,
    val durationHoursRemaining: Int = 18
)
