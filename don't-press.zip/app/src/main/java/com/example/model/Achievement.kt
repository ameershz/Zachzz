package com.example.model

enum class AchievementCategory(val labelEn: String, val labelAr: String) {
    PRESSES("Presses", "الضغطات"),
    RULES("Challenges", "التحديات"),
    STREAK("Streak", "الأيام المتتالية"),
    ECONOMY("Wealth", "الثروة"),
    COLLECTION("Skins", "المظاهر")
}

data class Achievement(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val category: AchievementCategory,
    val targetGoal: Long,
    val rewardCoins: Long,
    val rewardXp: Long,
    val iconEmoji: String
)

object DefaultAchievements {
    val ALL = listOf(
        // Presses
        Achievement(
            id = "ach_first_press",
            titleEn = "The First Step",
            titleAr = "الخطوة الأولى",
            descriptionEn = "Press the forbidden button for the first time.",
            descriptionAr = "اضغط على الزر المحرم للمرة الأولى.",
            category = AchievementCategory.PRESSES,
            targetGoal = 1L,
            rewardCoins = 25L,
            rewardXp = 50L,
            iconEmoji = "👆"
        ),
        Achievement(
            id = "ach_press_100",
            titleEn = "Addicted Finger",
            titleAr = "إصبع مدمن",
            descriptionEn = "Press the button 100 times.",
            descriptionAr = "اضغط على الزر 100 مرة.",
            category = AchievementCategory.PRESSES,
            targetGoal = 100L,
            rewardCoins = 100L,
            rewardXp = 150L,
            iconEmoji = "🔥"
        ),
        Achievement(
            id = "ach_press_1000",
            titleEn = "Button Smasher",
            titleAr = "محطم الأزرار",
            descriptionEn = "Reach 1,000 total presses.",
            descriptionAr = "صل إلى 1,000 ضغطة إجمالية.",
            category = AchievementCategory.PRESSES,
            targetGoal = 1000L,
            rewardCoins = 500L,
            rewardXp = 600L,
            iconEmoji = "⚡"
        ),
        Achievement(
            id = "ach_press_5000",
            titleEn = "Legendary Tapper",
            titleAr = "الضاغط الأسطوري",
            descriptionEn = "Reach 5,000 total presses.",
            descriptionAr = "صل إلى 5,000 ضغطة إجمالية.",
            category = AchievementCategory.PRESSES,
            targetGoal = 5000L,
            rewardCoins = 2000L,
            rewardXp = 2500L,
            iconEmoji = "👑"
        ),

        // Rules
        Achievement(
            id = "ach_survive_rules_5",
            titleEn = "Rule Follower",
            titleAr = "ملتزم بالقواعد",
            descriptionEn = "Successfully complete 5 tricky rules.",
            descriptionAr = "أكمل بنجاح 5 قواعد وتحديات متغيرة.",
            category = AchievementCategory.RULES,
            targetGoal = 5L,
            rewardCoins = 150L,
            rewardXp = 200L,
            iconEmoji = "🎯"
        ),
        Achievement(
            id = "ach_survive_rules_25",
            titleEn = "Master of Chaos",
            titleAr = "سيد الفوضى",
            descriptionEn = "Successfully complete 25 tricky rules.",
            descriptionAr = "أكمل بنجاح 25 تحدياً متغيراً.",
            category = AchievementCategory.RULES,
            targetGoal = 25L,
            rewardCoins = 750L,
            rewardXp = 1000L,
            iconEmoji = "🧠"
        ),

        // Streak
        Achievement(
            id = "ach_streak_3",
            titleEn = "Coming Back",
            titleAr = "العودة المستمرة",
            descriptionEn = "Log in 3 days in a row.",
            descriptionAr = "سجل الدخول 3 أيام متتالية.",
            category = AchievementCategory.STREAK,
            targetGoal = 3L,
            rewardCoins = 200L,
            rewardXp = 250L,
            iconEmoji = "📅"
        ),
        Achievement(
            id = "ach_streak_7",
            titleEn = "Dedicated Buttoner",
            titleAr = "مخلص للزر",
            descriptionEn = "Achieve a full 7-day streak.",
            descriptionAr = "حقق سلسلة 7 أيام متتالية كاملة.",
            category = AchievementCategory.STREAK,
            targetGoal = 7L,
            rewardCoins = 800L,
            rewardXp = 1200L,
            iconEmoji = "🌟"
        ),

        // Economy
        Achievement(
            id = "ach_coins_500",
            titleEn = "Pocket Money",
            titleAr = "مصروف الجيب",
            descriptionEn = "Earn a total of 500 Coins.",
            descriptionAr = "اجمع 500 عملة إجمالاً.",
            category = AchievementCategory.ECONOMY,
            targetGoal = 500L,
            rewardCoins = 100L,
            rewardXp = 150L,
            iconEmoji = "🪙"
        ),
        Achievement(
            id = "ach_coins_5000",
            titleEn = "Button Millionaire",
            titleAr = "مليونير الأزرار",
            descriptionEn = "Earn a total of 5,000 Coins.",
            descriptionAr = "اجمع 5,000 عملة إجمالاً.",
            category = AchievementCategory.ECONOMY,
            targetGoal = 5000L,
            rewardCoins = 1500L,
            rewardXp = 2000L,
            iconEmoji = "💰"
        ),

        // Collection
        Achievement(
            id = "ach_skins_2",
            titleEn = "Wardrobe Upgrade",
            titleAr = "تجديد المظهر",
            descriptionEn = "Unlock at least 2 button skins.",
            descriptionAr = "افتح مظهرين على الأقل للزر.",
            category = AchievementCategory.COLLECTION,
            targetGoal = 2L,
            rewardCoins = 300L,
            rewardXp = 400L,
            iconEmoji = "🎨"
        ),
        Achievement(
            id = "ach_skins_5",
            titleEn = "Fashion Icon",
            titleAr = "أيقونة الأناقة",
            descriptionEn = "Unlock at least 5 button skins.",
            descriptionAr = "افتح 5 مظاهر مختلفة للزر.",
            category = AchievementCategory.COLLECTION,
            targetGoal = 5L,
            rewardCoins = 2000L,
            rewardXp = 2500L,
            iconEmoji = "✨"
        )
    )
}
