package com.example.model

enum class RuleType {
    NORMAL,
    DONT_PRESS,
    SPEED_FRENZY,
    REVERSE_PSYCHOLOGY,
    COLOR_SWITCH,
    BOMB_TICKER,
    GOLDEN_RUSH,
    DECOY_BUTTON
}

enum class RuleState {
    IDLE,
    ACTIVE,
    SUCCEEDED,
    FAILED
}

data class ActiveRule(
    val type: RuleType,
    val titleEn: String,
    val titleAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val durationMs: Long,
    val timeRemainingMs: Long,
    val targetTaps: Int = 0,
    val currentTaps: Int = 0,
    val rewardCoins: Long = 0L,
    val rewardXp: Long = 0L,
    val penaltyCoins: Long = 0L,
    val state: RuleState = RuleState.ACTIVE,
    // Special states
    val isTargetGreen: Boolean = false,
    val targetExactSecond: Float = 1.0f,
    val decoyRealIndex: Int = 0
)
