package com.example.model

enum class ChallengeType {
    REACH_PRESSES,
    SURVIVE_RULES,
    WIN_SPEED_FRENZY,
    DEFUSE_BOMBS,
    EARN_COINS
}

data class DailyChallenge(
    val id: String,
    val dateString: String,
    val titleEn: String,
    val titleAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val type: ChallengeType,
    val targetGoal: Int,
    val currentProgress: Int,
    val rewardCoins: Long,
    val rewardXp: Long,
    val isCompleted: Boolean,
    val isClaimed: Boolean
)
