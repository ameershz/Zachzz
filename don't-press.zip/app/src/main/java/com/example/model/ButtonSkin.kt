package com.example.model

import androidx.compose.ui.graphics.Color

enum class SkinRarity(val label: String, val badgeColor: Color) {
    COMMON("Common", Color(0xFF9E9E9E)),
    RARE("Rare", Color(0xFF00B0FF)),
    EPIC("Epic", Color(0xFFD500F9)),
    LEGENDARY("Legendary", Color(0xFFFFAB00))
}

data class ButtonSkin(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val descriptionEn: String,
    val descriptionAr: String,
    val rarity: SkinRarity,
    val priceCoins: Long,
    val primaryColor: Color,
    val secondaryColor: Color,
    val accentColor: Color,
    val glowColor: Color,
    val coinsMultiplier: Float = 1.0f,
    val xpMultiplier: Float = 1.0f,
    val iconEmoji: String
)

object DefaultSkins {
    val ALL = listOf(
        ButtonSkin(
            id = "skin_classic_red",
            nameEn = "Classic Red",
            nameAr = "الأحمر الكلاسيكي",
            descriptionEn = "The iconic red arcade button. Tempting and timeless.",
            descriptionAr = "الزر الأحمر الكلاسيكي الأيقوني. مغرٍ ولا يقاوم.",
            rarity = SkinRarity.COMMON,
            priceCoins = 0L,
            primaryColor = Color(0xFFFF2A55),
            secondaryColor = Color(0xFFBA0F33),
            accentColor = Color(0xFFFF6E8A),
            glowColor = Color(0x80FF2A55),
            coinsMultiplier = 1.0f,
            xpMultiplier = 1.0f,
            iconEmoji = "🔴"
        ),
        ButtonSkin(
            id = "skin_cyber_neon",
            nameEn = "Cyber Neon",
            nameAr = "النيون السيبراني",
            descriptionEn = "Charged with high-voltage cyan light and digital pulses.",
            descriptionAr = "مشحون بنور سماوي فائق وطاقة رقمية.",
            rarity = SkinRarity.RARE,
            priceCoins = 250L,
            primaryColor = Color(0xFF00E5FF),
            secondaryColor = Color(0xFF0091EA),
            accentColor = Color(0xFF80D8FF),
            glowColor = Color(0x9900E5FF),
            coinsMultiplier = 1.2f,
            xpMultiplier = 1.1f,
            iconEmoji = "💠"
        ),
        ButtonSkin(
            id = "skin_molten_gold",
            nameEn = "Molten Gold",
            nameAr = "الذهب المنصهر",
            descriptionEn = "Forged from pure aurum. Grants +30% coins per tap!",
            descriptionAr = "مصنوع من الذهب الخالص. يمنح +30% عملات إضافية!",
            rarity = SkinRarity.EPIC,
            priceCoins = 1000L,
            primaryColor = Color(0xFFFFD700),
            secondaryColor = Color(0xFFFF8F00),
            accentColor = Color(0xFFFFF176),
            glowColor = Color(0x99FFD700),
            coinsMultiplier = 1.3f,
            xpMultiplier = 1.15f,
            iconEmoji = "👑"
        ),
        ButtonSkin(
            id = "skin_glacial_ice",
            nameEn = "Glacial Ice",
            nameAr = "الجليد القطبي",
            descriptionEn = "Sub-zero crystalline core with frosty vapor.",
            descriptionAr = "بلورة جليدية تحت الصفر مع بخار متجمد.",
            rarity = SkinRarity.RARE,
            priceCoins = 500L,
            primaryColor = Color(0xFF40C4FF),
            secondaryColor = Color(0xFF0091EA),
            accentColor = Color(0xFFE0F7FA),
            glowColor = Color(0x8040C4FF),
            coinsMultiplier = 1.15f,
            xpMultiplier = 1.25f,
            iconEmoji = "❄️"
        ),
        ButtonSkin(
            id = "skin_deep_galaxy",
            nameEn = "Deep Galaxy",
            nameAr = "المجرة العميقة",
            descriptionEn = "Contains the cosmic swirl of distant nebulas.",
            descriptionAr = "يحوي دوامة كونية من السدم والمجرات البعيدة.",
            rarity = SkinRarity.EPIC,
            priceCoins = 2000L,
            primaryColor = Color(0xFF7C4DFF),
            secondaryColor = Color(0xFF311B92),
            accentColor = Color(0xFFEA80FC),
            glowColor = Color(0x997C4DFF),
            coinsMultiplier = 1.35f,
            xpMultiplier = 1.35f,
            iconEmoji = "🌌"
        ),
        ButtonSkin(
            id = "skin_matrix_glitch",
            nameEn = "Matrix Glitch",
            nameAr = "خلل المصفوفة",
            descriptionEn = "An anomaly in the mainframe. Flickers with hacker code.",
            descriptionAr = "خلل برمجي في النظام الرئيسي يلمع بشفرات الاختراق.",
            rarity = SkinRarity.EPIC,
            priceCoins = 1500L,
            primaryColor = Color(0xFF00E676),
            secondaryColor = Color(0xFF1B5E20),
            accentColor = Color(0xFFB9F6CA),
            glowColor = Color(0x8000E676),
            coinsMultiplier = 1.25f,
            xpMultiplier = 1.3f,
            iconEmoji = "👾"
        ),
        ButtonSkin(
            id = "skin_infernal_fire",
            nameEn = "Infernal Fire",
            nameAr = "اللهب الحارق",
            descriptionEn = "Pulsing with volcanic magma and fiery flares.",
            descriptionAr = "ينبض بحمم بركانية ونار متقدة.",
            rarity = SkinRarity.LEGENDARY,
            priceCoins = 4000L,
            primaryColor = Color(0xFFFF3D00),
            secondaryColor = Color(0xFFDD2C00),
            accentColor = Color(0xFFFFAB91),
            glowColor = Color(0x99FF3D00),
            coinsMultiplier = 1.5f,
            xpMultiplier = 1.4f,
            iconEmoji = "🔥"
        ),
        ButtonSkin(
            id = "skin_rainbow_prism",
            nameEn = "Prism Spectrum",
            nameAr = "الطيف المنشوري",
            descriptionEn = "The ultimate kaleidoscope button. Radiates prismatic energy.",
            descriptionAr = "الزر الأسطوري المتلون بطيف الألوان المشعة.",
            rarity = SkinRarity.LEGENDARY,
            priceCoins = 7500L,
            primaryColor = Color(0xFFFF4081),
            secondaryColor = Color(0xFF651FFF),
            accentColor = Color(0xFF00E5FF),
            glowColor = Color(0xAAFF4081),
            coinsMultiplier = 1.75f,
            xpMultiplier = 1.75f,
            iconEmoji = "🌈"
        )
    )

    fun getSkin(id: String): ButtonSkin {
        return ALL.firstOrNull { it.id == id } ?: ALL.first()
    }
}
