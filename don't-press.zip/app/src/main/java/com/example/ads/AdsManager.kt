package com.example.ads

import android.app.Activity
import kotlinx.coroutines.delay

interface AdsManager {
    fun isRewardedAdReady(): Boolean
    suspend fun showRewardedAd(activity: Activity, onRewardGranted: () -> Unit, onAdClosed: () -> Unit)
}

class PlaceholderAdsManager : AdsManager {
    private var isAdReady: Boolean = true

    override fun isRewardedAdReady(): Boolean = isAdReady

    override suspend fun showRewardedAd(
        activity: Activity,
        onRewardGranted: () -> Unit,
        onAdClosed: () -> Unit
    ) {
        // Simulated rewarded ad playback (e.g. ready for Google Mobile Ads AdMob SDK)
        delay(1200L)
        onRewardGranted()
        onAdClosed()
    }
}
