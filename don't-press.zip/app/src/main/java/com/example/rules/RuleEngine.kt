package com.example.rules

import com.example.model.ActiveRule
import com.example.model.RuleState
import com.example.model.RuleType
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

class RuleEngine(
    private val scope: CoroutineScope,
    private val onRuleCompleted: (ActiveRule, isSuccess: Boolean) -> Unit
) {

    private val _currentRule = MutableStateFlow<ActiveRule?>(null)
    val currentRule: StateFlow<ActiveRule?> = _currentRule.asStateFlow()

    private var timerJob: Job? = null

    fun triggerRandomRule() {
        if (_currentRule.value != null) return

        val candidateTypes = listOf(
            RuleType.DONT_PRESS,
            RuleType.SPEED_FRENZY,
            RuleType.REVERSE_PSYCHOLOGY,
            RuleType.COLOR_SWITCH,
            RuleType.BOMB_TICKER,
            RuleType.GOLDEN_RUSH,
            RuleType.DECOY_BUTTON
        )
        val selectedType = candidateTypes.random()
        startRule(selectedType)
    }

    fun startRule(type: RuleType) {
        timerJob?.cancel()

        val rule = when (type) {
            RuleType.DONT_PRESS -> ActiveRule(
                type = RuleType.DONT_PRESS,
                titleEn = "DON'T PRESS!",
                titleAr = "إياك والضغط!",
                descriptionEn = "Resist the urge! Do not touch the button for 4 seconds!",
                descriptionAr = "قاوم الرغبة! لا تلمس الزر إطلاقاً لمدة 4 ثوانٍ!",
                durationMs = 4000L,
                timeRemainingMs = 4000L,
                rewardCoins = 120L,
                rewardXp = 150L,
                penaltyCoins = 30L
            )
            RuleType.SPEED_FRENZY -> ActiveRule(
                type = RuleType.SPEED_FRENZY,
                titleEn = "SPEED FRENZY!",
                titleAr = "فورة السرعة!",
                descriptionEn = "Tap rapidly 10 times before the timer runs out!",
                descriptionAr = "اضغط بسرعة 10 مرات متتالية قبل نفاد الوقت!",
                durationMs = 4000L,
                timeRemainingMs = 4000L,
                targetTaps = 10,
                currentTaps = 0,
                rewardCoins = 150L,
                rewardXp = 200L,
                penaltyCoins = 0L
            )
            RuleType.REVERSE_PSYCHOLOGY -> ActiveRule(
                type = RuleType.REVERSE_PSYCHOLOGY,
                titleEn = "TRICKY LOGIC!",
                titleAr = "منطق مخادع!",
                descriptionEn = "DO NOT NOT PRESS ME!",
                descriptionAr = "أرجوك لا لا تضغط عليّ!",
                durationMs = 3500L,
                timeRemainingMs = 3500L,
                rewardCoins = 100L,
                rewardXp = 120L,
                penaltyCoins = 25L
            )
            RuleType.COLOR_SWITCH -> ActiveRule(
                type = RuleType.COLOR_SWITCH,
                titleEn = "COLOR SWITCH!",
                titleAr = "تبديل الألوان!",
                descriptionEn = "WAIT FOR GREEN! Pressing on red causes failure!",
                descriptionAr = "انتظر اللون الأخضر! الضغط على الأحمر يسبب الفشل!",
                durationMs = 5000L,
                timeRemainingMs = 5000L,
                isTargetGreen = false,
                rewardCoins = 140L,
                rewardXp = 160L,
                penaltyCoins = 30L
            )
            RuleType.BOMB_TICKER -> ActiveRule(
                type = RuleType.BOMB_TICKER,
                titleEn = "DEFUSE THE BOMB!",
                titleAr = "إبطال القنبلة!",
                descriptionEn = "Press when the countdown hits exactly 1.0s!",
                descriptionAr = "اضغط عندما يصل العداد إلى 1.0 ثانية تماماً!",
                durationMs = 3500L,
                timeRemainingMs = 3500L,
                targetExactSecond = 1.0f,
                rewardCoins = 250L,
                rewardXp = 300L,
                penaltyCoins = 40L
            )
            RuleType.GOLDEN_RUSH -> ActiveRule(
                type = RuleType.GOLDEN_RUSH,
                titleEn = "GOLDEN TOUCH!",
                titleAr = "اللمسة الذهبية!",
                descriptionEn = "5X COINS ON EVERY TAP! Mash the button!",
                descriptionAr = "5 أضعاف العملات لكل ضغطة! اضغط بأقصى سرعة!",
                durationMs = 6000L,
                timeRemainingMs = 6000L,
                rewardCoins = 100L,
                rewardXp = 100L,
                penaltyCoins = 0L
            )
            RuleType.DECOY_BUTTON -> ActiveRule(
                type = RuleType.DECOY_BUTTON,
                titleEn = "DECOY TRAP!",
                titleAr = "فخ الزر المزيف!",
                descriptionEn = "One is REAL, one is GLITCHED. Pick wisely!",
                descriptionAr = "أحدهما حقيقي والآخر مزيف. اختر بذكاء!",
                durationMs = 5000L,
                timeRemainingMs = 5000L,
                decoyRealIndex = Random.nextInt(2),
                rewardCoins = 180L,
                rewardXp = 200L,
                penaltyCoins = 25L
            )
            RuleType.NORMAL -> return
        }

        _currentRule.value = rule
        startTimerLoop(rule)
    }

    private fun startTimerLoop(rule: ActiveRule) {
        timerJob = scope.launch {
            val startTime = System.currentTimeMillis()
            val totalDuration = rule.durationMs
            val colorSwitchGreenDelay = if (rule.type == RuleType.COLOR_SWITCH) 2200L else -1L

            while (isActive) {
                delay(50L)
                val elapsed = System.currentTimeMillis() - startTime
                val remaining = (totalDuration - elapsed).coerceAtLeast(0L)

                val current = _currentRule.value ?: break
                if (current.state != RuleState.ACTIVE) break

                // Special handling: color switch turns green after delay
                val isGreen = if (current.type == RuleType.COLOR_SWITCH) {
                    elapsed >= colorSwitchGreenDelay
                } else false

                _currentRule.value = current.copy(
                    timeRemainingMs = remaining,
                    isTargetGreen = isGreen
                )

                if (remaining <= 0L) {
                    // Timer expired!
                    handleTimerExpired(current)
                    break
                }
            }
        }
    }

    /**
     * Called when the main button is pressed while a rule is active.
     * Returns true if normal tap should also be counted, or false if rule consumed it.
     */
    fun onButtonTapped(decoyChoiceIndex: Int? = null): Boolean {
        val rule = _currentRule.value ?: return true
        if (rule.state != RuleState.ACTIVE) return true

        when (rule.type) {
            RuleType.DONT_PRESS -> {
                // VIOLATION! Pressed during "Don't press"
                endRule(rule, isSuccess = false)
                return false
            }

            RuleType.SPEED_FRENZY -> {
                val newTaps = rule.currentTaps + 1
                if (newTaps >= rule.targetTaps) {
                    endRule(rule.copy(currentTaps = newTaps), isSuccess = true)
                } else {
                    _currentRule.value = rule.copy(currentTaps = newTaps)
                }
                return true
            }

            RuleType.REVERSE_PSYCHOLOGY -> {
                // "Do not not press" means press! Player pressed!
                endRule(rule, isSuccess = true)
                return true
            }

            RuleType.COLOR_SWITCH -> {
                if (rule.isTargetGreen) {
                    // Good job! Pressed while green
                    endRule(rule, isSuccess = true)
                } else {
                    // Pressed while red! Failed!
                    endRule(rule, isSuccess = false)
                }
                return false
            }

            RuleType.BOMB_TICKER -> {
                val remainingSeconds = rule.timeRemainingMs / 1000.0f
                if (remainingSeconds in 0.8f..1.2f) {
                    endRule(rule, isSuccess = true)
                } else {
                    endRule(rule, isSuccess = false)
                }
                return false
            }

            RuleType.GOLDEN_RUSH -> {
                // Just keep tapping for 5x coins!
                return true
            }

            RuleType.DECOY_BUTTON -> {
                if (decoyChoiceIndex != null) {
                    val isReal = decoyChoiceIndex == rule.decoyRealIndex
                    endRule(rule, isSuccess = isReal)
                }
                return false
            }

            RuleType.NORMAL -> return true
        }
    }

    private fun handleTimerExpired(rule: ActiveRule) {
        when (rule.type) {
            RuleType.DONT_PRESS -> {
                // Succeeded! The player resisted pressing!
                endRule(rule, isSuccess = true)
            }
            RuleType.GOLDEN_RUSH -> {
                // Golden rush finished normally
                endRule(rule, isSuccess = true)
            }
            RuleType.SPEED_FRENZY,
            RuleType.REVERSE_PSYCHOLOGY,
            RuleType.COLOR_SWITCH,
            RuleType.BOMB_TICKER,
            RuleType.DECOY_BUTTON -> {
                // Timed out without meeting conditions
                endRule(rule, isSuccess = false)
            }
            RuleType.NORMAL -> {}
        }
    }

    private fun endRule(rule: ActiveRule, isSuccess: Boolean) {
        timerJob?.cancel()
        val finalState = if (isSuccess) RuleState.SUCCEEDED else RuleState.FAILED
        val finishedRule = rule.copy(state = finalState)
        _currentRule.value = finishedRule

        onRuleCompleted(finishedRule, isSuccess)

        // Reset to null after brief feedback display
        scope.launch {
            delay(1600L)
            if (_currentRule.value?.state != RuleState.ACTIVE) {
                _currentRule.value = null
            }
        }
    }

    fun dismissRule() {
        timerJob?.cancel()
        _currentRule.value = null
    }
}
