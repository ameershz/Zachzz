package com.example.analytics

import android.util.Log

interface AnalyticsTracker {
    fun logEvent(name: String, params: Map<String, Any> = emptyMap())
}

class GameAnalytics : AnalyticsTracker {
    override fun logEvent(name: String, params: Map<String, Any>) {
        Log.d("GameAnalytics", "Event: $name | Params: $params")
    }
}
