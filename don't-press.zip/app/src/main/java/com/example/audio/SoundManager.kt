package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

class SoundManager {

    var isSoundEnabled: Boolean = true
    private val scope = CoroutineScope(Dispatchers.Default)

    private val sampleRate = 44100

    fun playClick() {
        if (!isSoundEnabled) return
        scope.launch {
            // Quick punchy mechanical click: pitch drop 600Hz -> 150Hz over 50ms
            val durationMs = 50
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / numSamples
                val freq = 600.0 * (1.0 - t * 0.75)
                val envelope = (1.0 - t) * (1.0 - t)
                val sample = sin(2.0 * Math.PI * freq * i / sampleRate) * envelope
                buffer[i] = (sample * Short.MAX_VALUE * 0.8).toInt().toShort()
            }
            playPcm(buffer)
        }
    }

    fun playCoin() {
        if (!isSoundEnabled) return
        scope.launch {
            // Bright coin ping: 987Hz -> 1318Hz
            val durationMs = 120
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val buffer = ShortArray(numSamples)
            val half = numSamples / 2

            for (i in 0 until numSamples) {
                val freq = if (i < half) 987.77 else 1318.51
                val progress = (i % half).toDouble() / half
                val envelope = 1.0 - progress
                val sample = sin(2.0 * Math.PI * freq * i / sampleRate) * envelope
                buffer[i] = (sample * Short.MAX_VALUE * 0.6).toInt().toShort()
            }
            playPcm(buffer)
        }
    }

    fun playBuzzer() {
        if (!isSoundEnabled) return
        scope.launch {
            // Low warning buzzer: 140Hz with square-like harmonics for 250ms
            val durationMs = 250
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val t = i.toDouble() / numSamples
                val envelope = if (t > 0.8) (1.0 - t) / 0.2 else 1.0
                val sine1 = sin(2.0 * Math.PI * 140.0 * i / sampleRate)
                val sine2 = sin(2.0 * Math.PI * 280.0 * i / sampleRate) * 0.5
                val sample = (sine1 + sine2) * envelope
                buffer[i] = (sample * Short.MAX_VALUE * 0.7).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }
            playPcm(buffer)
        }
    }

    fun playSuccess() {
        if (!isSoundEnabled) return
        scope.launch {
            // Ascending major chord fanfare (C5, E5, G5, C6)
            val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.50)
            val noteDurationMs = 80
            val totalSamples = (sampleRate * (noteDurationMs * notes.size / 1000.0)).toInt()
            val buffer = ShortArray(totalSamples)
            val samplesPerNote = totalSamples / notes.size

            for (n in notes.indices) {
                val freq = notes[n]
                val offset = n * samplesPerNote
                for (i in 0 until samplesPerNote) {
                    val progress = i.toDouble() / samplesPerNote
                    val envelope = (1.0 - progress * 0.7)
                    val sample = sin(2.0 * Math.PI * freq * i / sampleRate) * envelope
                    buffer[offset + i] = (sample * Short.MAX_VALUE * 0.6).toInt().toShort()
                }
            }
            playPcm(buffer)
        }
    }

    fun playGlitch() {
        if (!isSoundEnabled) return
        scope.launch {
            // Cyber static noise burst
            val durationMs = 80
            val numSamples = (sampleRate * (durationMs / 1000.0)).toInt()
            val buffer = ShortArray(numSamples)

            for (i in 0 until numSamples) {
                val noise = (Random.nextDouble() * 2.0 - 1.0)
                val envelope = 1.0 - (i.toDouble() / numSamples)
                buffer[i] = (noise * envelope * Short.MAX_VALUE * 0.4).toInt().toShort()
            }
            playPcm(buffer)
        }
    }

    private fun playPcm(buffer: ShortArray) {
        try {
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()
            // Release track after it finishes playing
            scope.launch {
                val playTimeMs = (buffer.size * 1000L / sampleRate) + 50L
                kotlinx.coroutines.delay(playTimeMs)
                try {
                    audioTrack.stop()
                    audioTrack.release()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            // AudioTrack unavailable or device muted
        }
    }
}
