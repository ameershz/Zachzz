package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AiChallengeService {

    private val wittyFallbackQuotesEn = listOf(
        "I dare you to keep your hands in your pockets.",
        "Your finger is twitching. I can see it.",
        "Whatever happens next... it's completely on you.",
        "Scientists spent years building this. Please don't break it.",
        "Did you really open this app just to tap a circle?",
        "Warning: The button is observing your psychological patience.",
        "Every tap echoes across the digital cosmos.",
        "Just five more seconds of peace... or tap?",
        "The red paint is still drying. Please don't touch!"
    )

    private val wittyFallbackQuotesAr = listOf(
        "أتحداك أن تبقي يديك في جيبك لعشر ثوانٍ فقط.",
        "أشعر بحركة إصبعك وهو يقترب... لا تفعلها!",
        "كل ما سيحدث لاحقاً... يقع على مسؤوليتك تماماً.",
        "أمضى العلماء سنوات في برمجة هذا الزر... أرجوك لا تلمسه.",
        "هل فتحت التطبيق حقاً لمجرد النقر على دائرة حمراء؟",
        "تحذير: الزر يراقب مدى صبرك النفسي الآن.",
        "كل ضغطة تصدر صدى في الفضاء السيبراني.",
        "خمس ثوانٍ فقط من الهدوء... أم ستضغط؟",
        "الطلاء الأحمر ما زال رطباً، إياك ولمسه!"
    )

    fun getRandomWittyQuote(isArabic: Boolean): String {
        return if (isArabic) {
            wittyFallbackQuotesAr.random()
        } else {
            wittyFallbackQuotesEn.random()
        }
    }

    suspend fun generateDynamicRuleCommentary(ruleName: String, isArabic: Boolean): String = withContext(Dispatchers.IO) {
        // If Gemini API Key is configured in BuildConfig, this service can query AI Studio
        // Otherwise, it returns polished procedural responses immediately without network lag
        val apiKey = try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            field.get(null) as? String ?: ""
        } catch (_: Exception) {
            ""
        }
        if (apiKey.isNotEmpty()) {
            // Safe AI generator placeholder hook
        }
        return@withContext if (isArabic) {
            "تحدي جديد قادم: استعد لـ $ruleName!"
        } else {
            "Incoming dynamic rule: Prepare for $ruleName!"
        }
    }
}
