package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.DailyChallenge
import com.example.model.ChallengeType
import com.example.model.PlayerProfile
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GameDataStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("dont_press_game_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PLAYER_ID = "player_id"
        private const val KEY_USERNAME = "username"
        private const val KEY_AVATAR = "avatar_emoji"
        private const val KEY_COINS = "coins"
        private const val KEY_XP = "xp"
        private const val KEY_LEVEL = "level"
        private const val KEY_TOTAL_PRESSES = "total_presses"
        private const val KEY_CURRENT_STREAK = "current_streak"
        private const val KEY_HIGHEST_STREAK = "highest_streak"
        private const val KEY_LAST_ACTIVE_EPOCH_DAY = "last_active_epoch_day"
        private const val KEY_EQUIPPED_SKIN = "equipped_skin"
        private const val KEY_UNLOCKED_SKINS = "unlocked_skins"
        private const val KEY_UNLOCKED_ACHIEVEMENTS = "unlocked_achievements"
        private const val KEY_CLAIMED_ACHIEVEMENTS = "claimed_achievements"
        private const val KEY_COMPLETED_CHALLENGES = "completed_challenges"
        private const val KEY_RULES_SURFACED = "rules_surfaced"
        private const val KEY_RULES_SUCCEEDED = "rules_succeeded"

        private const val KEY_SOUND_ENABLED = "setting_sound_enabled"
        private const val KEY_VIBRATION_ENABLED = "setting_vibration_enabled"
        private const val KEY_LANGUAGE = "setting_language"

        private const val KEY_DAILY_CHALLENGE_JSON = "daily_challenge_json"
    }

    fun loadProfile(): PlayerProfile {
        val playerId = prefs.getString(KEY_PLAYER_ID, null) ?: "player_${(1000..9999).random()}"
        val username = prefs.getString(KEY_USERNAME, "RedButtonMaster") ?: "RedButtonMaster"
        val avatar = prefs.getString(KEY_AVATAR, "🔴") ?: "🔴"
        val coins = prefs.getLong(KEY_COINS, 0L)
        val xp = prefs.getLong(KEY_XP, 0L)
        val level = prefs.getInt(KEY_LEVEL, 1)
        val totalPresses = prefs.getLong(KEY_TOTAL_PRESSES, 0L)
        val currentStreak = prefs.getInt(KEY_CURRENT_STREAK, 1)
        val highestStreak = prefs.getInt(KEY_HIGHEST_STREAK, 1)
        val lastActiveDay = prefs.getLong(KEY_LAST_ACTIVE_EPOCH_DAY, 0L)
        val equippedSkin = prefs.getString(KEY_EQUIPPED_SKIN, "skin_classic_red") ?: "skin_classic_red"

        val unlockedSkins = prefs.getStringSet(KEY_UNLOCKED_SKINS, setOf("skin_classic_red")) ?: setOf("skin_classic_red")
        val unlockedAchievements = prefs.getStringSet(KEY_UNLOCKED_ACHIEVEMENTS, emptySet()) ?: emptySet()
        val claimedAchievements = prefs.getStringSet(KEY_CLAIMED_ACHIEVEMENTS, emptySet()) ?: emptySet()

        val completedChallenges = prefs.getInt(KEY_COMPLETED_CHALLENGES, 0)
        val rulesSurfaced = prefs.getInt(KEY_RULES_SURFACED, 0)
        val rulesSucceeded = prefs.getInt(KEY_RULES_SUCCEEDED, 0)

        return PlayerProfile(
            playerId = playerId,
            username = username,
            avatarEmoji = avatar,
            isGuest = true,
            coins = coins,
            xp = xp,
            level = level,
            totalPresses = totalPresses,
            currentStreak = currentStreak,
            highestStreak = highestStreak,
            lastActiveEpochDay = lastActiveDay,
            equippedSkinId = equippedSkin,
            unlockedSkinIds = unlockedSkins,
            unlockedAchievementIds = unlockedAchievements,
            claimedAchievementIds = claimedAchievements,
            completedDailyChallenges = completedChallenges,
            rulesSurfaced = rulesSurfaced,
            rulesSucceeded = rulesSucceeded
        )
    }

    fun saveProfile(profile: PlayerProfile) {
        prefs.edit()
            .putString(KEY_PLAYER_ID, profile.playerId)
            .putString(KEY_USERNAME, profile.username)
            .putString(KEY_AVATAR, profile.avatarEmoji)
            .putLong(KEY_COINS, profile.coins)
            .putLong(KEY_XP, profile.xp)
            .putInt(KEY_LEVEL, profile.level)
            .putLong(KEY_TOTAL_PRESSES, profile.totalPresses)
            .putInt(KEY_CURRENT_STREAK, profile.currentStreak)
            .putInt(KEY_HIGHEST_STREAK, profile.highestStreak)
            .putLong(KEY_LAST_ACTIVE_EPOCH_DAY, profile.lastActiveEpochDay)
            .putString(KEY_EQUIPPED_SKIN, profile.equippedSkinId)
            .putStringSet(KEY_UNLOCKED_SKINS, profile.unlockedSkinIds)
            .putStringSet(KEY_UNLOCKED_ACHIEVEMENTS, profile.unlockedAchievementIds)
            .putStringSet(KEY_CLAIMED_ACHIEVEMENTS, profile.claimedAchievementIds)
            .putInt(KEY_COMPLETED_CHALLENGES, profile.completedDailyChallenges)
            .putInt(KEY_RULES_SURFACED, profile.rulesSurfaced)
            .putInt(KEY_RULES_SUCCEEDED, profile.rulesSucceeded)
            .apply()
    }

    fun loadDailyChallenge(todayString: String): DailyChallenge {
        val rawJson = prefs.getString(KEY_DAILY_CHALLENGE_JSON, null)
        if (rawJson != null) {
            try {
                val obj = JSONObject(rawJson)
                if (obj.optString("dateString") == todayString) {
                    return DailyChallenge(
                        id = obj.getString("id"),
                        dateString = todayString,
                        titleEn = obj.getString("titleEn"),
                        titleAr = obj.getString("titleAr"),
                        descriptionEn = obj.getString("descriptionEn"),
                        descriptionAr = obj.getString("descriptionAr"),
                        type = ChallengeType.valueOf(obj.getString("type")),
                        targetGoal = obj.getInt("targetGoal"),
                        currentProgress = obj.getInt("currentProgress"),
                        rewardCoins = obj.getLong("rewardCoins"),
                        rewardXp = obj.getLong("rewardXp"),
                        isCompleted = obj.getBoolean("isCompleted"),
                        isClaimed = obj.getBoolean("isClaimed")
                    )
                }
            } catch (_: Exception) {}
        }

        // Generate deterministic daily challenge based on date hash
        val seed = todayString.hashCode()
        val types = ChallengeType.values()
        val selectedType = types[kotlin.math.abs(seed) % types.size]

        val challenge = when (selectedType) {
            ChallengeType.REACH_PRESSES -> DailyChallenge(
                id = "challenge_$todayString",
                dateString = todayString,
                titleEn = "Daily Stamina",
                titleAr = "تحمل اليوم",
                descriptionEn = "Press the button 150 times today.",
                descriptionAr = "اضغط على الزر 150 مرة اليوم.",
                type = ChallengeType.REACH_PRESSES,
                targetGoal = 150,
                currentProgress = 0,
                rewardCoins = 300L,
                rewardXp = 450L,
                isCompleted = false,
                isClaimed = false
            )
            ChallengeType.SURVIVE_RULES -> DailyChallenge(
                id = "challenge_$todayString",
                dateString = todayString,
                titleEn = "Rules Survivor",
                titleAr = "ناجي القواعد",
                descriptionEn = "Survive 5 tricky dynamic rules.",
                descriptionAr = "انجح في اجتياز 5 قواعد ديناميكية.",
                type = ChallengeType.SURVIVE_RULES,
                targetGoal = 5,
                currentProgress = 0,
                rewardCoins = 400L,
                rewardXp = 500L,
                isCompleted = false,
                isClaimed = false
            )
            ChallengeType.WIN_SPEED_FRENZY -> DailyChallenge(
                id = "challenge_$todayString",
                dateString = todayString,
                titleEn = "Rapid Fire",
                titleAr = "إطلاق ناري سريع",
                descriptionEn = "Beat 2 Speed Frenzy events.",
                descriptionAr = "تغلب على حدثين من فورة السرعة.",
                type = ChallengeType.WIN_SPEED_FRENZY,
                targetGoal = 2,
                currentProgress = 0,
                rewardCoins = 350L,
                rewardXp = 400L,
                isCompleted = false,
                isClaimed = false
            )
            ChallengeType.DEFUSE_BOMBS -> DailyChallenge(
                id = "challenge_$todayString",
                dateString = todayString,
                titleEn = "Bomb Technician",
                titleAr = "خبير المفرقعات",
                descriptionEn = "Defuse 2 countdown bombs safely.",
                descriptionAr = "أبطل قنبلتين مؤقتتين بأمان.",
                type = ChallengeType.DEFUSE_BOMBS,
                targetGoal = 2,
                currentProgress = 0,
                rewardCoins = 500L,
                rewardXp = 600L,
                isCompleted = false,
                isClaimed = false
            )
            ChallengeType.EARN_COINS -> DailyChallenge(
                id = "challenge_$todayString",
                dateString = todayString,
                titleEn = "Daily Wealth",
                titleAr = "ثروة اليوم",
                descriptionEn = "Collect 200 coins through active play.",
                descriptionAr = "اجمع 200 عملة من خلال اللعب.",
                type = ChallengeType.EARN_COINS,
                targetGoal = 200,
                currentProgress = 0,
                rewardCoins = 300L,
                rewardXp = 350L,
                isCompleted = false,
                isClaimed = false
            )
        }
        saveDailyChallenge(challenge)
        return challenge
    }

    fun saveDailyChallenge(challenge: DailyChallenge) {
        val obj = JSONObject().apply {
            put("id", challenge.id)
            put("dateString", challenge.dateString)
            put("titleEn", challenge.titleEn)
            put("titleAr", challenge.titleAr)
            put("descriptionEn", challenge.descriptionEn)
            put("descriptionAr", challenge.descriptionAr)
            put("type", challenge.type.name)
            put("targetGoal", challenge.targetGoal)
            put("currentProgress", challenge.currentProgress)
            put("rewardCoins", challenge.rewardCoins)
            put("rewardXp", challenge.rewardXp)
            put("isCompleted", challenge.isCompleted)
            put("isClaimed", challenge.isClaimed)
        }
        prefs.edit().putString(KEY_DAILY_CHALLENGE_JSON, obj.toString()).apply()
    }

    fun isSoundEnabled(): Boolean = prefs.getBoolean(KEY_SOUND_ENABLED, true)
    fun setSoundEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()

    fun isVibrationEnabled(): Boolean = prefs.getBoolean(KEY_VIBRATION_ENABLED, true)
    fun setVibrationEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_VIBRATION_ENABLED, enabled).apply()

    fun getLanguage(): String = prefs.getString(KEY_LANGUAGE, "en") ?: "en"
    fun setLanguage(lang: String) = prefs.edit().putString(KEY_LANGUAGE, lang).apply()

    fun clearAllData() {
        prefs.edit().clear().apply()
    }
}
