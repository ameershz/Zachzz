package com.example.data

import com.example.model.LeaderboardEntry
import com.example.model.PlayerProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class LeaderboardRepository {

    private val simulatedTopPlayers = listOf(
        LeaderboardEntry(1, "RedVortex", "👑", 48, 89420L, 145000L),
        LeaderboardEntry(2, "TouchMaster", "⚡", 42, 65200L, 98400L),
        LeaderboardEntry(3, "NeverTapper", "🛡️", 37, 43100L, 71200L),
        LeaderboardEntry(4, "CyberGhost", "👾", 34, 38900L, 59800L),
        LeaderboardEntry(5, "ButtonLord", "💎", 29, 29400L, 46700L),
        LeaderboardEntry(6, "SolarFlare", "🔥", 25, 21800L, 35100L),
        LeaderboardEntry(7, "ZenFinger", "🧘", 21, 16200L, 26400L),
        LeaderboardEntry(8, "PixelHero", "🎮", 18, 12500L, 19800L),
        LeaderboardEntry(9, "VoidWalker", "🌌", 14, 8900L, 14200L),
        LeaderboardEntry(10, "ShadowClicker", "🥷", 11, 5600L, 9100L)
    )

    fun getLeaderboard(player: PlayerProfile, isDaily: Boolean = false): List<LeaderboardEntry> {
        val list = simulatedTopPlayers.toMutableList()

        val playerScore = player.totalPresses * 2 + player.xp
        val playerEntry = LeaderboardEntry(
            rank = 0,
            username = player.username,
            avatarEmoji = player.avatarEmoji,
            level = player.level,
            totalPresses = player.totalPresses,
            score = playerScore,
            isCurrentPlayer = true
        )

        // Insert player into ranking
        list.add(playerEntry)
        val sorted = list.sortedByDescending { it.score }

        return sorted.mapIndexed { index, entry ->
            entry.copy(rank = index + 1)
        }
    }
}
