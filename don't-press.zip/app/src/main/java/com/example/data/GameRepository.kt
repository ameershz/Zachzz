package com.example.data

import android.content.Context
import com.example.config.GameConfig
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class GameRepository(context: Context) {

    private val dataStore = GameDataStore(context)

    private val _playerProfile = MutableStateFlow(dataStore.loadProfile())
    val playerProfile: StateFlow<PlayerProfile> = _playerProfile.asStateFlow()

    private val todayString: String
        get() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private val todayEpochDay: Long
        get() = System.currentTimeMillis() / (1000L * 60L * 60L * 24L)

    private val _dailyChallenge = MutableStateFlow(dataStore.loadDailyChallenge(todayString))
    val dailyChallenge: StateFlow<DailyChallenge> = _dailyChallenge.asStateFlow()

    init {
        checkDailyStreakLogin()
    }

    private fun checkDailyStreakLogin() {
        val current = _playerProfile.value
        val lastDay = current.lastActiveEpochDay
        val today = todayEpochDay

        if (lastDay == 0L) {
            // First ever login
            updateProfile { it.copy(lastActiveEpochDay = today, currentStreak = 1) }
        } else if (today > lastDay) {
            val daysDiff = today - lastDay
            val newStreak = if (daysDiff == 1L) {
                current.currentStreak + 1
            } else {
                1 // Missed one or more days
            }
            val newHighest = maxOf(newStreak, current.highestStreak)
            updateProfile {
                it.copy(
                    lastActiveEpochDay = today,
                    currentStreak = newStreak,
                    highestStreak = newHighest
                )
            }
        }
    }

    fun updateProfile(transform: (PlayerProfile) -> PlayerProfile): PlayerProfile {
        val updated = transform(_playerProfile.value)
        _playerProfile.value = updated
        dataStore.saveProfile(updated)
        return updated
    }

    /**
     * Awards coins and XP with skin and event multipliers.
     * Returns Triple(actualCoinsAdded, actualXpAdded, didLevelUp: Boolean)
     */
    fun awardRewards(
        baseCoins: Long,
        baseXp: Long,
        coinsMultiplier: Float = 1.0f,
        xpMultiplier: Float = 1.0f
    ): Triple<Long, Long, Boolean> {
        val current = _playerProfile.value
        val skin = DefaultSkins.getSkin(current.equippedSkinId)

        val totalCoinsMultiplier = skin.coinsMultiplier * coinsMultiplier
        val totalXpMultiplier = skin.xpMultiplier * xpMultiplier

        val finalCoins = (baseCoins * totalCoinsMultiplier).toLong().coerceAtLeast(1L)
        val finalXp = (baseXp * totalXpMultiplier).toLong().coerceAtLeast(1L)

        val newTotalCoins = current.coins + finalCoins
        val newTotalXp = current.xp + finalXp

        val (newLevel, _, _) = GameConfig.calculateLevelInfo(newTotalXp)
        val didLevelUp = newLevel > current.level

        val updated = updateProfile {
            it.copy(
                coins = newTotalCoins,
                xp = newTotalXp,
                level = newLevel
            )
        }

        // Check achievements progress
        checkAchievements(updated)

        return Triple(finalCoins, finalXp, didLevelUp)
    }

    fun recordPress(): Triple<Long, Long, Boolean> {
        val current = _playerProfile.value
        val updatedPresses = current.totalPresses + 1L

        updateProfile { it.copy(totalPresses = updatedPresses) }

        // Update daily challenge if REACH_PRESSES
        val challenge = _dailyChallenge.value
        if (challenge.type == ChallengeType.REACH_PRESSES && !challenge.isCompleted) {
            val newProg = challenge.currentProgress + 1
            val completed = newProg >= challenge.targetGoal
            val updatedChallenge = challenge.copy(
                currentProgress = newProg,
                isCompleted = completed
            )
            _dailyChallenge.value = updatedChallenge
            dataStore.saveDailyChallenge(updatedChallenge)
        }

        return awardRewards(GameConfig.BASE_TAP_COINS, GameConfig.BASE_TAP_XP)
    }

    fun applyPenalty(coinsLost: Long) {
        updateProfile {
            it.copy(coins = (it.coins - coinsLost).coerceAtLeast(0L))
        }
    }

    fun recordRuleCompleted(isSuccess: Boolean) {
        val current = _playerProfile.value
        val updated = updateProfile {
            it.copy(
                rulesSurfaced = it.rulesSurfaced + 1,
                rulesSucceeded = if (isSuccess) it.rulesSucceeded + 1 else it.rulesSucceeded
            )
        }

        if (isSuccess) {
            val challenge = _dailyChallenge.value
            if (challenge.type == ChallengeType.SURVIVE_RULES && !challenge.isCompleted) {
                val newProg = challenge.currentProgress + 1
                val completed = newProg >= challenge.targetGoal
                val updatedChallenge = challenge.copy(
                    currentProgress = newProg,
                    isCompleted = completed
                )
                _dailyChallenge.value = updatedChallenge
                dataStore.saveDailyChallenge(updatedChallenge)
            }
        }

        checkAchievements(updated)
    }

    fun recordSpeedFrenzyWon() {
        val challenge = _dailyChallenge.value
        if (challenge.type == ChallengeType.WIN_SPEED_FRENZY && !challenge.isCompleted) {
            val newProg = challenge.currentProgress + 1
            val completed = newProg >= challenge.targetGoal
            val updatedChallenge = challenge.copy(
                currentProgress = newProg,
                isCompleted = completed
            )
            _dailyChallenge.value = updatedChallenge
            dataStore.saveDailyChallenge(updatedChallenge)
        }
    }

    fun recordBombDefused() {
        val challenge = _dailyChallenge.value
        if (challenge.type == ChallengeType.DEFUSE_BOMBS && !challenge.isCompleted) {
            val newProg = challenge.currentProgress + 1
            val completed = newProg >= challenge.targetGoal
            val updatedChallenge = challenge.copy(
                currentProgress = newProg,
                isCompleted = completed
            )
            _dailyChallenge.value = updatedChallenge
            dataStore.saveDailyChallenge(updatedChallenge)
        }
    }

    fun claimDailyChallengeReward(): Boolean {
        val challenge = _dailyChallenge.value
        if (challenge.isCompleted && !challenge.isClaimed) {
            val updatedChallenge = challenge.copy(isClaimed = true)
            _dailyChallenge.value = updatedChallenge
            dataStore.saveDailyChallenge(updatedChallenge)

            awardRewards(challenge.rewardCoins, challenge.rewardXp)
            updateProfile { it.copy(completedDailyChallenges = it.completedDailyChallenges + 1) }
            return true
        }
        return false
    }

    fun buySkin(skin: ButtonSkin): Boolean {
        val current = _playerProfile.value
        if (current.unlockedSkinIds.contains(skin.id)) return true
        if (current.coins >= skin.priceCoins) {
            updateProfile {
                it.copy(
                    coins = it.coins - skin.priceCoins,
                    unlockedSkinIds = it.unlockedSkinIds + skin.id,
                    equippedSkinId = skin.id
                )
            }
            checkAchievements(_playerProfile.value)
            return true
        }
        return false
    }

    fun equipSkin(skinId: String) {
        val current = _playerProfile.value
        if (current.unlockedSkinIds.contains(skinId)) {
            updateProfile { it.copy(equippedSkinId = skinId) }
        }
    }

    fun claimAchievement(achievementId: String): Boolean {
        val current = _playerProfile.value
        val ach = DefaultAchievements.ALL.firstOrNull { it.id == achievementId } ?: return false

        if (current.unlockedAchievementIds.contains(achievementId) &&
            !current.claimedAchievementIds.contains(achievementId)
        ) {
            updateProfile {
                it.copy(claimedAchievementIds = it.claimedAchievementIds + achievementId)
            }
            awardRewards(ach.rewardCoins, ach.rewardXp)
            return true
        }
        return false
    }

    private fun checkAchievements(profile: PlayerProfile) {
        val newUnlocked = profile.unlockedAchievementIds.toMutableSet()

        for (ach in DefaultAchievements.ALL) {
            if (newUnlocked.contains(ach.id)) continue

            val reached = when (ach.category) {
                AchievementCategory.PRESSES -> profile.totalPresses >= ach.targetGoal
                AchievementCategory.RULES -> profile.rulesSucceeded.toLong() >= ach.targetGoal
                AchievementCategory.STREAK -> profile.currentStreak.toLong() >= ach.targetGoal
                AchievementCategory.ECONOMY -> profile.coins >= ach.targetGoal
                AchievementCategory.COLLECTION -> profile.unlockedSkinIds.size.toLong() >= ach.targetGoal
            }

            if (reached) {
                newUnlocked.add(ach.id)
            }
        }

        if (newUnlocked.size != profile.unlockedAchievementIds.size) {
            updateProfile { it.copy(unlockedAchievementIds = newUnlocked) }
        }
    }

    fun isSoundEnabled(): Boolean = dataStore.isSoundEnabled()
    fun setSoundEnabled(enabled: Boolean) = dataStore.setSoundEnabled(enabled)

    fun isVibrationEnabled(): Boolean = dataStore.isVibrationEnabled()
    fun setVibrationEnabled(enabled: Boolean) = dataStore.setVibrationEnabled(enabled)

    fun getLanguage(): String = dataStore.getLanguage()
    fun setLanguage(lang: String) = dataStore.setLanguage(lang)

    fun resetAllData() {
        dataStore.clearAllData()
        _playerProfile.value = dataStore.loadProfile()
        _dailyChallenge.value = dataStore.loadDailyChallenge(todayString)
    }
}
