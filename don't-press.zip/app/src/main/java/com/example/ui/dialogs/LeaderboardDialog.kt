package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.LeaderboardEntry
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MoltenGold

@Composable
fun LeaderboardDialog(
    entries: List<LeaderboardEntry>,
    isArabic: Boolean,
    onTabSelected: (isDaily: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isArabic) "🏆 لوحة الصدارة العالمية" else "🏆 Global Leaderboard",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Tabs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DarkCard,
                    contentColor = Color(0xFF00E5FF),
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = {
                            selectedTab = 0
                            onTabSelected(false)
                        },
                        text = {
                            Text(
                                text = if (isArabic) "كل الأوقات" else "All-Time",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            onTabSelected(true)
                        },
                        text = {
                            Text(
                                text = if (isArabic) "تحدي اليوم" else "Daily",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Leaderboard List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(entries) { entry ->
                        LeaderboardRow(entry = entry, isArabic = isArabic)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("close_leaderboard_button")
                ) {
                    Text(
                        text = if (isArabic) "إغلاق" else "Close",
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun LeaderboardRow(entry: LeaderboardEntry, isArabic: Boolean) {
    val rankBadge = when (entry.rank) {
        1 -> "🥇"
        2 -> "🥈"
        3 -> "🥉"
        else -> "#${entry.rank}"
    }

    val backgroundColor = if (entry.isCurrentPlayer) {
        Color(0xFF1E294B)
    } else {
        DarkCard
    }

    val borderColor = if (entry.isCurrentPlayer) {
        Color(0xFF00E5FF)
    } else {
        Color.Transparent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(backgroundColor)
            .border(1.dp, borderColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Rank
        Text(
            text = rankBadge,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = if (entry.rank <= 3) MoltenGold else Color(0xFF94A3B8),
            modifier = Modifier.width(36.dp)
        )

        // Avatar
        Text(
            text = entry.avatarEmoji,
            fontSize = 20.sp
        )

        Spacer(modifier = Modifier.width(10.dp))

        // Username & Level
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = entry.username,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (entry.isCurrentPlayer) Color(0xFF00E5FF) else Color.White
                )
                if (entry.isCurrentPlayer) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isArabic) "(أنت)" else "(YOU)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00E676)
                    )
                }
            }
            Text(
                text = "${if (isArabic) "المستوى" else "LVL"} ${entry.level} • ${entry.totalPresses} ${if (isArabic) "ضغطة" else "taps"}",
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
            )
        }

        // Score
        Text(
            text = "${entry.score}",
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MoltenGold
        )
    }
}
