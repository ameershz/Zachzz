package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.config.GameConfig
import com.example.model.DefaultSkins
import com.example.model.RuleType
import com.example.ui.components.BigRedButton
import com.example.ui.components.DecoyGameView
import com.example.ui.components.RulePromptBanner
import com.example.ui.components.TopStatusBar
import com.example.ui.dialogs.*
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkVoid
import com.example.ui.theme.MoltenGold
import com.example.ui.viewmodel.GameViewModel

@Composable
fun GameScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.playerProfile.collectAsStateWithLifecycle()
    val activeRule by viewModel.activeRule.collectAsStateWithLifecycle()
    val dailyChallenge by viewModel.dailyChallenge.collectAsStateWithLifecycle()
    val activeEvents by viewModel.activeEvents.collectAsStateWithLifecycle()
    val leaderboardEntries by viewModel.leaderboardEntries.collectAsStateWithLifecycle()
    val currentQuote by viewModel.currentQuote.collectAsStateWithLifecycle()
    val particles by viewModel.particles.collectAsStateWithLifecycle()
    val comboCount by viewModel.comboCount.collectAsStateWithLifecycle()
    val levelUpLevel by viewModel.levelUpDialogLevel.collectAsStateWithLifecycle()
    val showAntiCheat by viewModel.showAntiCheatDialog.collectAsStateWithLifecycle()
    val currentLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()

    val isArabic = currentLanguage == "ar"
    val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    // Dialog state
    var showChallengeDialog by remember { mutableStateOf(false) }
    var showLeaderboardDialog by remember { mutableStateOf(false) }
    var showShopDialog by remember { mutableStateOf(false) }
    var showAchievementsDialog by remember { mutableStateOf(false) }
    var showEventsDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    val equippedSkin = remember(profile.equippedSkinId) {
        DefaultSkins.getSkin(profile.equippedSkinId)
    }

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            containerColor = DarkVoid,
            modifier = modifier.fillMaxSize()
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                DarkVoid,
                                DarkSurface.copy(alpha = 0.5f),
                                DarkVoid
                            )
                        )
                    ),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top HUD Bar
                TopStatusBar(
                    profile = profile,
                    isSoundOn = viewModel.soundManager.isSoundEnabled,
                    isVibrationOn = viewModel.hapticsManager.isVibrationEnabled,
                    onToggleSound = { viewModel.toggleSound() },
                    onToggleVibration = { viewModel.toggleVibration() },
                    onOpenSettings = { showSettingsDialog = true }
                )

                // Event ticker & Witty Button Quote
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                ) {
                    val featuredEvent = activeEvents.firstOrNull()
                    if (featuredEvent != null) {
                        Surface(
                            color = Color(0xFF241604),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .clickable { showEventsDialog = true }
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            ) {
                                Text(text = featuredEvent.iconEmoji, fontSize = 13.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isArabic) featuredEvent.titleAr else featuredEvent.titleEn,
                                    fontSize = 11.sp,
                                    color = MoltenGold,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "(${featuredEvent.coinsMultiplier}x Coins)",
                                    fontSize = 10.sp,
                                    color = Color(0xFFFDE68A)
                                )
                            }
                        }
                    }

                    // Sarcastic / witty quote
                    Text(
                        text = "“$currentQuote”",
                        fontSize = 13.sp,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                    )
                }

                // Rule Prompt Banner
                RulePromptBanner(
                    activeRule = activeRule,
                    isArabic = isArabic
                )

                // Centerpiece Button or Decoy View
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    if (activeRule?.type == RuleType.DECOY_BUTTON) {
                        DecoyGameView(
                            isArabic = isArabic,
                            onChoiceMade = { choice ->
                                viewModel.onDecoyTapped(choice)
                            }
                        )
                    } else {
                        BigRedButton(
                            skin = equippedSkin,
                            activeRule = activeRule,
                            particles = particles,
                            isArabic = isArabic,
                            onPress = { viewModel.onMainButtonPress() }
                        )
                    }
                }

                // Combo Badge
                AnimatedVisibility(
                    visible = comboCount >= 5,
                    enter = scaleIn() + fadeIn(),
                    exit = scaleOut() + fadeOut()
                ) {
                    val multiplier = GameConfig.getComboMultiplier(comboCount)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFFFF2A55), Color(0xFFFF9100))
                                )
                            )
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (isArabic) "كومبو x$multiplier! ($comboCount ضغطة) 🔥" else "COMBO x$multiplier! ($comboCount Taps) 🔥",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bottom Action Bar
                BottomNavBar(
                    isArabic = isArabic,
                    challengeHasClaim = dailyChallenge.isCompleted && !dailyChallenge.isClaimed,
                    achievementsHasClaim = profile.unlockedAchievementIds.size > profile.claimedAchievementIds.size,
                    onOpenDaily = { showChallengeDialog = true },
                    onOpenLeaderboard = {
                        viewModel.refreshLeaderboard()
                        showLeaderboardDialog = true
                    },
                    onOpenShop = { showShopDialog = true },
                    onOpenAchievements = { showAchievementsDialog = true },
                    onOpenEvents = { showEventsDialog = true }
                )
            }
        }
    }

    // Dialogs
    if (showChallengeDialog) {
        DailyChallengeDialog(
            challenge = dailyChallenge,
            currentStreak = profile.currentStreak,
            isArabic = isArabic,
            onClaimChallenge = { viewModel.claimDailyChallenge() },
            onDismiss = { showChallengeDialog = false }
        )
    }

    if (showLeaderboardDialog) {
        LeaderboardDialog(
            entries = leaderboardEntries,
            isArabic = isArabic,
            onTabSelected = { isDaily -> viewModel.refreshLeaderboard(isDaily) },
            onDismiss = { showLeaderboardDialog = false }
        )
    }

    if (showShopDialog) {
        SkinsShopDialog(
            profile = profile,
            isArabic = isArabic,
            onBuySkin = { skin -> viewModel.buySkin(skin) },
            onEquipSkin = { skinId -> viewModel.equipSkin(skinId) },
            onDismiss = { showShopDialog = false }
        )
    }

    if (showAchievementsDialog) {
        AchievementsDialog(
            profile = profile,
            isArabic = isArabic,
            onClaimAchievement = { achId -> viewModel.claimAchievement(achId) },
            onDismiss = { showAchievementsDialog = false }
        )
    }

    if (showEventsDialog) {
        EventsDialog(
            events = activeEvents,
            isArabic = isArabic,
            onDismiss = { showEventsDialog = false }
        )
    }

    if (showSettingsDialog) {
        ProfileSettingsDialog(
            profile = profile,
            isSoundOn = viewModel.soundManager.isSoundEnabled,
            isVibrationOn = viewModel.hapticsManager.isVibrationEnabled,
            currentLanguage = currentLanguage,
            onToggleSound = { viewModel.toggleSound() },
            onToggleVibration = { viewModel.toggleVibration() },
            onSetLanguage = { lang -> viewModel.setLanguage(lang) },
            onSaveProfile = { name, avatar -> viewModel.updateProfile(name, avatar) },
            onResetProgress = { viewModel.resetAllGameProgress() },
            onDismiss = { showSettingsDialog = false }
        )
    }

    if (levelUpLevel != null) {
        LevelUpDialog(
            level = levelUpLevel!!,
            isArabic = isArabic,
            onDismiss = { viewModel.dismissLevelUpDialog() }
        )
    }

    if (showAntiCheat) {
        AntiCheatDialog(
            isArabic = isArabic,
            onVerify = { viewModel.dismissAntiCheat() }
        )
    }
}

@Composable
fun BottomNavBar(
    isArabic: Boolean,
    challengeHasClaim: Boolean,
    achievementsHasClaim: Boolean,
    onOpenDaily: () -> Unit,
    onOpenLeaderboard: () -> Unit,
    onOpenShop: () -> Unit,
    onOpenAchievements: () -> Unit,
    onOpenEvents: () -> Unit
) {
    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavButton(
                icon = "🎯",
                label = if (isArabic) "التحدي" else "Daily",
                hasBadge = challengeHasClaim,
                testTag = "nav_daily_button",
                onClick = onOpenDaily
            )
            NavButton(
                icon = "🏆",
                label = if (isArabic) "المتصدرون" else "Ranks",
                testTag = "nav_leaderboard_button",
                onClick = onOpenLeaderboard
            )
            NavButton(
                icon = "🎨",
                label = if (isArabic) "المظاهر" else "Skins",
                testTag = "nav_shop_button",
                onClick = onOpenShop
            )
            NavButton(
                icon = "🎖️",
                label = if (isArabic) "الإنجازات" else "Badges",
                hasBadge = achievementsHasClaim,
                testTag = "nav_achievements_button",
                onClick = onOpenAchievements
            )
            NavButton(
                icon = "⚡",
                label = if (isArabic) "الفعاليات" else "Events",
                testTag = "nav_events_button",
                onClick = onOpenEvents
            )
        }
    }
}

@Composable
fun NavButton(
    icon: String,
    label: String,
    hasBadge: Boolean = false,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box {
                Text(text = icon, fontSize = 22.sp)
                if (hasBadge) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .align(Alignment.TopEnd)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(Color(0xFFFF2A55))
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFCBD5E1)
            )
        }
    }
}
