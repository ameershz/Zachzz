package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.PlayerProfile
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MoltenGold

@Composable
fun ProfileSettingsDialog(
    profile: PlayerProfile,
    isSoundOn: Boolean,
    isVibrationOn: Boolean,
    currentLanguage: String,
    onToggleSound: () -> Unit,
    onToggleVibration: () -> Unit,
    onSetLanguage: (String) -> Unit,
    onSaveProfile: (username: String, avatar: String) -> Unit,
    onResetProgress: () -> Unit,
    onDismiss: () -> Unit
) {
    val isArabic = currentLanguage == "ar"

    var usernameInput by remember { mutableStateOf(profile.username) }
    var selectedAvatar by remember { mutableStateOf(profile.avatarEmoji) }
    var showResetConfirm by remember { mutableStateOf(false) }
    var showPrivacyPolicy by remember { mutableStateOf(false) }

    val avatars = listOf("🔴", "👑", "⚡", "👾", "🔥", "💎", "🚀", "🥷", "🧘", "🦾")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isArabic) "⚙️ الملف الشخصي والإعدادات" else "⚙️ Profile & Settings",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Avatar Picker
                Text(
                    text = if (isArabic) "اختر صورتك الرمزية:" else "Choose Avatar:",
                    fontSize = 13.sp,
                    color = Color(0xFF94A3B8),
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(avatars) { av ->
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (selectedAvatar == av) Color(0xFF00E5FF) else DarkCard)
                                .clickable { selectedAvatar = av },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = av, fontSize = 22.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Username TextField
                OutlinedTextField(
                    value = usernameInput,
                    onValueChange = { if (it.length <= 16) usernameInput = it },
                    label = { Text(if (isArabic) "اسم اللاعب" else "Player Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF282E47)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("username_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { onSaveProfile(usernameInput, selectedAvatar) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_profile_button")
                ) {
                    Text(
                        text = if (isArabic) "حفظ التعديلات" else "Save Changes",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color(0xFF282E47))
                Spacer(modifier = Modifier.height(14.dp))

                // Preferences: Audio & Vibration
                Text(
                    text = if (isArabic) "التفضيلات والتجربة:" else "Preferences:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isArabic) "المؤثرات الصوتية" else "Sound Effects",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Switch(
                        checked = isSoundOn,
                        onCheckedChange = { onToggleSound() }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isArabic) "الاهتزاز والتفاعل اللمسي" else "Haptics & Vibration",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Switch(
                        checked = isVibrationOn,
                        onCheckedChange = { onToggleVibration() }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Language Selector
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isArabic) "اللغة / Language" else "Language / اللغة",
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Row {
                        FilterChip(
                            selected = currentLanguage == "en",
                            onClick = { onSetLanguage("en") },
                            label = { Text("English") }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        FilterChip(
                            selected = currentLanguage == "ar",
                            onClick = { onSetLanguage("ar") },
                            label = { Text("العربية") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color(0xFF282E47))
                Spacer(modifier = Modifier.height(14.dp))

                // Statistics Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = if (isArabic) "📊 إحصائيات اللعب الحية:" else "📊 Lifetime Statistics:",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        StatRow(label = if (isArabic) "إجمالي الضغطات:" else "Total Presses:", value = "${profile.totalPresses}")
                        StatRow(label = if (isArabic) "المستوى الحالي:" else "Current Level:", value = "${profile.level}")
                        StatRow(label = if (isArabic) "السلسلة الحالية:" else "Current Streak:", value = "${profile.currentStreak} 🔥")
                        StatRow(label = if (isArabic) "أعلى سلسلة:" else "Best Streak:", value = "${profile.highestStreak} 🔥")
                        StatRow(label = if (isArabic) "القواعد المنجزة:" else "Rules Succeeded:", value = "${profile.rulesSucceeded}")
                        StatRow(label = if (isArabic) "المظاهر المفتوحة:" else "Skins Unlocked:", value = "${profile.unlockedSkinIds.size}")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Privacy & Terms
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TextButton(onClick = { showPrivacyPolicy = true }) {
                        Text(text = if (isArabic) "سياسة الخصوصية" else "Privacy Policy", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    }
                    TextButton(onClick = { showPrivacyPolicy = true }) {
                        Text(text = if (isArabic) "شروط الخدمة" else "Terms of Service", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Reset Progress
                OutlinedButton(
                    onClick = { showResetConfirm = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = if (isArabic) "إعادة تعيين تقدم اللعبة" else "Reset Game Progress")
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isArabic) "DON'T PRESS 🔴 • الإصدار 1.0.0 (APK Ready)" else "DON'T PRESS 🔴 • Version 1.0.0 (APK Ready)",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("close_settings_button")
                ) {
                    Text(text = if (isArabic) "إغلاق" else "Close", color = Color.White)
                }
            }
        }
    }

    if (showResetConfirm) {
        AlertDialog(
            onDismissRequest = { showResetConfirm = false },
            title = { Text(if (isArabic) "تأكيد إعادة التعيين" else "Confirm Reset") },
            text = {
                Text(if (isArabic) "هل أنت متأكد من رغبتك في مسح كل التقدم والمظاهر والعملات؟ لا يمكن التراجع عن هذا الإجراء." else "Are you sure you want to reset all progress, skins, and coins? This action is irreversible.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onResetProgress()
                        showResetConfirm = false
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed)
                ) {
                    Text(if (isArabic) "نعم، أعد التعيين" else "Yes, Reset All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirm = false }) {
                    Text(if (isArabic) "إلغاء" else "Cancel")
                }
            }
        )
    }

    if (showPrivacyPolicy) {
        AlertDialog(
            onDismissRequest = { showPrivacyPolicy = false },
            title = { Text(if (isArabic) "سياسة الخصوصية والشروط" else "Privacy & Terms") },
            text = {
                Text(
                    if (isArabic)
                        "لعبة DON'T PRESS تحترم خصوصيتك تماماً.\n• لا نقوم بجمع أو بيع أي بيانات شخصية.\n• يتم حفظ تقدمك محلياً على جهازك بشكل آمن.\n• التطبيق جاهز للتصدير والتثبيت كحزمة Android APK دون أي برمجيات تتبع خبيثة."
                    else
                        "DON'T PRESS respects your privacy.\n• No personal data is collected or sold.\n• Your game progress is stored securely on your device.\n• Safe for all ages, optimized for Android APK packaging."
                )
            },
            confirmButton = {
                Button(onClick = { showPrivacyPolicy = false }) {
                    Text(if (isArabic) "حسناً" else "OK")
                }
            }
        )
    }
}

@Composable
fun StatRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = Color(0xFF94A3B8), fontSize = 12.sp)
        Text(text = value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}
