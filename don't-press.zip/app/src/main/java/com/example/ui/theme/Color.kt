package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkVoid = Color(0xFF090A10)
val DarkSurface = Color(0xFF131522)
val DarkCard = Color(0xFF1B1E30)
val DarkBorder = Color(0xFF282E47)

val CrimsonRed = Color(0xFFFF2A55)
val CrimsonRedDark = Color(0xFFBA0F33)
val CrimsonGlow = Color(0x66FF2A55)

val CyberCyan = Color(0xFF00F0FF)
val MoltenGold = Color(0xFFFFD700)
val EmeraldGreen = Color(0xFF00E676)
val ElectricPurple = Color(0xFF9D4EDD)
val HazardYellow = Color(0xFFFFCC00)
val GlitchOrange = Color(0xFFFF6D00)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF94A3B8)
val TextDisabled = Color(0xFF5A667E)
