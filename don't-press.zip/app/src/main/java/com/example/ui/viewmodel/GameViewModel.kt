package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiChallengeService
import com.example.analytics.GameAnalytics
import com.example.audio.SoundManager
import com.example.config.GameConfig
import com.example.data.GameRepository
import com.example.data.LeaderboardRepository
import com.example.haptics.HapticsManager
import com.example.model.*
import com.example.rules.RuleEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

data class FloatingParticle(
    val id: Long,
    val text: String,
    val xOffset: Float,
    val yOffset: Float,
    val colorHex: Long = 0xFFFFD700
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    val repository = GameRepository(application)
    val soundManager = SoundManager().apply {
        isSoundEnabled = repository.isSoundEnabled()
    }
    val hapticsManager = HapticsManager(application).apply {
        isVibrationEnabled = repository.isVibrationEnabled()
    }
    val analytics = GameAnalytics()
    val aiService = AiChallengeService()
    val leaderboardRepository = LeaderboardRepository()

    // State
    val playerProfile: StateFlow<PlayerProfile> = repository.playerProfile
    val dailyChallenge: StateFlow<DailyChallenge> = repository.dailyChallenge

    private val _activeEvents = MutableStateFlow(GameConfig.DEFAULT_EVENTS)
    val activeEvents: StateFlow<List<GameEvent>> = _activeEvents.asStateFlow()

    private val _leaderboardEntries = MutableStateFlow<List<LeaderboardEntry>>(emptyList())
    val leaderboardEntries: StateFlow<List<LeaderboardEntry>> = _leaderboardEntries.asStateFlow()

    // Witty quote on screen
    private val _currentQuote = MutableStateFlow("")
    val currentQuote: StateFlow<String> = _currentQuote.asStateFlow()

    // Floating animation feedback particles
    private val _particles = MutableStateFlow<List<FloatingParticle>>(emptyList())
    val particles: StateFlow<List<FloatingParticle>> = _particles.asStateFlow()

    // Combo
    private val _comboCount = MutableStateFlow(0)
    val comboCount: StateFlow<Int> = _comboCount.asStateFlow()
    private var comboDecayJob: Job? = null

    // Anti-Cheat / Rate Limiter
    private val tapTimestamps = mutableListOf<Long>()
    private val _showAntiCheatDialog = MutableStateFlow(false)
    val showAntiCheatDialog: StateFlow<Boolean> = _showAntiCheatDialog.asStateFlow()

    // Level-up celebration dialog
    private val _levelUpDialogLevel = MutableStateFlow<Int?>(null)
    val levelUpDialogLevel: StateFlow<Int?> = _levelUpDialogLevel.asStateFlow()

    // Language state
    private val _currentLanguage = MutableStateFlow(repository.getLanguage())
    val currentLanguage: StateFlow<String> = _currentLanguage.asStateFlow()

    // Taps countdown until next random rule
    private var tapsUntilNextRule = Random.nextInt(
        GameConfig.MIN_TAPS_BETWEEN_RULES,
        GameConfig.MAX_TAPS_BETWEEN_RULES
    )

    // Rule Engine
    val ruleEngine = RuleEngine(
        scope = viewModelScope,
        onRuleCompleted = { rule, isSuccess ->
            onRuleFinished(rule, isSuccess)
        }
    )
    val activeRule: StateFlow<ActiveRule?> = ruleEngine.currentRule

    init {
        refreshQuote()
        refreshLeaderboard()
    }

    fun isArabic(): Boolean = _currentLanguage.value == "ar"

    fun refreshQuote() {
        _currentQuote.value = aiService.getRandomWittyQuote(isArabic())
    }

    fun refreshLeaderboard(isDaily: Boolean = false) {
        _leaderboardEntries.value = leaderboardRepository.getLeaderboard(playerProfile.value, isDaily)
    }

    fun onMainButtonPress() {
        // Anti-cheat verification
        val now = System.currentTimeMillis()
        tapTimestamps.add(now)
        tapTimestamps.removeAll { now - it > 1000L }
        if (tapTimestamps.size > GameConfig.MAX_TAPS_PER_SECOND) {
            _showAntiCheatDialog.value = true
            soundManager.playBuzzer()
            hapticsManager.vibrateHeavy()
            return
        }

        // Haptic & Sound
        soundManager.playClick()
        hapticsManager.vibrateClick()

        // Update combo
        val currentCombo = _comboCount.value + 1
        _comboCount.value = currentCombo
        resetComboTimer()

        // Check if rule consumed the press
        val active = activeRule.value
        val ruleShouldCountNormal = ruleEngine.onButtonTapped()

        if (active != null && !ruleShouldCountNormal) {
            // Rule consumed the tap
            return
        }

        // Normal tap processing
        val (coinsAdded, xpAdded, didLevelUp) = if (active?.type == RuleType.GOLDEN_RUSH) {
            // 5x Golden multiplier
            repository.awardRewards(
                GameConfig.BASE_TAP_COINS * 5,
                GameConfig.BASE_TAP_XP * 3
            )
        } else {
            val comboMult = GameConfig.getComboMultiplier(currentCombo)
            repository.recordPress().let { (c, x, lUp) ->
                Triple(c * comboMult, x, lUp)
            }
        }

        // Sound effect for coins on combo or golden
        if (currentCombo % 10 == 0 || active?.type == RuleType.GOLDEN_RUSH) {
            soundManager.playCoin()
        }

        // Floating particle feedback
        spawnParticle("+$coinsAdded 🪙", isCrit = currentCombo >= 15)

        if (didLevelUp) {
            triggerLevelUp(playerProfile.value.level)
        }

        // Rule trigger countdown
        if (activeRule.value == null) {
            tapsUntilNextRule--
            if (tapsUntilNextRule <= 0) {
                tapsUntilNextRule = Random.nextInt(
                    GameConfig.MIN_TAPS_BETWEEN_RULES,
                    GameConfig.MAX_TAPS_BETWEEN_RULES
                )
                ruleEngine.triggerRandomRule()
                soundManager.playGlitch()
                hapticsManager.vibrateGlitch()
            }
        }

        analytics.logEvent("button_pressed", mapOf("combo" to currentCombo))
    }

    fun onDecoyTapped(choiceIndex: Int) {
        ruleEngine.onButtonTapped(decoyChoiceIndex = choiceIndex)
    }

    private fun onRuleFinished(rule: ActiveRule, isSuccess: Boolean) {
        repository.recordRuleCompleted(isSuccess)

        if (isSuccess) {
            soundManager.playSuccess()
            hapticsManager.vibrateSuccess()

            val (_, _, didLevelUp) = repository.awardRewards(rule.rewardCoins, rule.rewardXp)
            spawnParticle("+${rule.rewardCoins} 🪙 SUCCESS!", isCrit = true)

            when (rule.type) {
                RuleType.SPEED_FRENZY -> repository.recordSpeedFrenzyWon()
                RuleType.BOMB_TICKER -> repository.recordBombDefused()
                else -> {}
            }

            if (didLevelUp) {
                triggerLevelUp(playerProfile.value.level)
            }
        } else {
            soundManager.playBuzzer()
            hapticsManager.vibrateHeavy()

            if (rule.penaltyCoins > 0) {
                repository.applyPenalty(rule.penaltyCoins)
                spawnParticle("-${rule.penaltyCoins} 🪙 PENALTY", isCrit = false, isPenalty = true)
            }
        }

        refreshQuote()
        refreshLeaderboard()
    }

    private fun resetComboTimer() {
        comboDecayJob?.cancel()
        comboDecayJob = viewModelScope.launch {
            delay(GameConfig.COMBO_DECAY_MS)
            _comboCount.value = 0
        }
    }

    private fun spawnParticle(text: String, isCrit: Boolean, isPenalty: Boolean = false) {
        val colorHex = when {
            isPenalty -> 0xFFFF2A55
            isCrit -> 0xFF00F0FF
            else -> 0xFFFFD700
        }
        val p = FloatingParticle(
            id = System.nanoTime(),
            text = text,
            xOffset = (Random.nextFloat() - 0.5f) * 160f,
            yOffset = -Random.nextFloat() * 60f,
            colorHex = colorHex
        )
        _particles.value = _particles.value + p
        viewModelScope.launch {
            delay(900L)
            _particles.value = _particles.value.filter { it.id != p.id }
        }
    }

    private fun triggerLevelUp(level: Int) {
        _levelUpDialogLevel.value = level
        soundManager.playSuccess()
        hapticsManager.vibrateSuccess()
        val bonus = GameConfig.levelUpRewardCoins(level)
        repository.awardRewards(bonus, 0L)
    }

    fun dismissLevelUpDialog() {
        _levelUpDialogLevel.value = null
    }

    fun dismissAntiCheat() {
        _showAntiCheatDialog.value = false
        tapTimestamps.clear()
    }

    fun claimDailyChallenge() {
        if (repository.claimDailyChallengeReward()) {
            soundManager.playSuccess()
            hapticsManager.vibrateSuccess()
            spawnParticle("CHALLENGE CLAIMED! 🎯", isCrit = true)
            refreshLeaderboard()
        }
    }

    fun buySkin(skin: ButtonSkin) {
        if (repository.buySkin(skin)) {
            soundManager.playCoin()
            hapticsManager.vibrateSuccess()
            analytics.logEvent("skin_purchased", mapOf("skinId" to skin.id))
        }
    }

    fun equipSkin(skinId: String) {
        repository.equipSkin(skinId)
        soundManager.playClick()
        hapticsManager.vibrateClick()
    }

    fun claimAchievement(achievementId: String) {
        if (repository.claimAchievement(achievementId)) {
            soundManager.playSuccess()
            hapticsManager.vibrateSuccess()
            spawnParticle("ACHIEVEMENT UNLOCKED! 🎖️", isCrit = true)
            analytics.logEvent("achievement_unlocked", mapOf("achId" to achievementId))
        }
    }

    fun toggleSound() {
        val current = soundManager.isSoundEnabled
        val newState = !current
        soundManager.isSoundEnabled = newState
        repository.setSoundEnabled(newState)
        if (newState) soundManager.playClick()
    }

    fun toggleVibration() {
        val current = hapticsManager.isVibrationEnabled
        val newState = !current
        hapticsManager.isVibrationEnabled = newState
        repository.setVibrationEnabled(newState)
        if (newState) hapticsManager.vibrateClick()
    }

    fun setLanguage(lang: String) {
        _currentLanguage.value = lang
        repository.setLanguage(lang)
        refreshQuote()
    }

    fun updateProfile(username: String, avatar: String) {
        repository.updateProfile {
            it.copy(username = username.trim().ifEmpty { it.username }, avatarEmoji = avatar)
        }
        refreshLeaderboard()
    }

    fun resetAllGameProgress() {
        repository.resetAllData()
        _comboCount.value = 0
        ruleEngine.dismissRule()
        refreshLeaderboard()
    }
}
