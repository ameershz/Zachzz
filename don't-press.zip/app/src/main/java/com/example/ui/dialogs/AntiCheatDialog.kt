package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldGreen

@Composable
fun AntiCheatDialog(
    isArabic: Boolean,
    onVerify: () -> Unit
) {
    Dialog(onDismissRequest = { /* Force interaction */ }) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "🤖", fontSize = 42.sp)

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isArabic) "مهلاً، سرعة نقرات خارقة!" else "Whoa, Superhuman Speed!",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFF2A55)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isArabic)
                        "نظام الحماية رصد ضغطات سريعة جداً تفوق سرعة الأصابع البشرية. اضغط على الزر أدناه لتأكيد أنك إنسان حقيقي!"
                    else
                        "Our security detected taps faster than ordinary fingers! Please tap below to confirm you are a real human:",
                    fontSize = 13.sp,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onVerify,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("verify_human_button")
                ) {
                    Text(
                        text = if (isArabic) "أنا إنسان، دعني ألعب! ✋" else "I am human, let me play! ✋",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
