package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveRule
import com.example.model.RuleState
import com.example.model.RuleType

@Composable
fun RulePromptBanner(
    activeRule: ActiveRule?,
    isArabic: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = activeRule != null,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        if (activeRule == null) return@AnimatedVisibility

        val progress = if (activeRule.durationMs > 0) {
            (activeRule.timeRemainingMs.toFloat() / activeRule.durationMs.toFloat()).coerceIn(0f, 1f)
        } else 1f

        val bannerColor = when (activeRule.state) {
            RuleState.SUCCEEDED -> Color(0xFF00E676)
            RuleState.FAILED -> Color(0xFFFF1744)
            RuleState.ACTIVE -> when (activeRule.type) {
                RuleType.DONT_PRESS -> Color(0xFFFF2A55)
                RuleType.GOLDEN_RUSH -> Color(0xFFFFD700)
                RuleType.SPEED_FRENZY -> Color(0xFF00E5FF)
                RuleType.BOMB_TICKER -> Color(0xFFFF9100)
                RuleType.COLOR_SWITCH -> if (activeRule.isTargetGreen) Color(0xFF00E676) else Color(0xFFFF2A55)
                else -> Color(0xFF9D4EDD)
            }
            RuleState.IDLE -> Color.Gray
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(bannerColor.copy(alpha = 0.25f), Color(0xFF131522))
                    )
                )
                .border(2.dp, bannerColor.copy(alpha = 0.8f), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Title
                val title = when (activeRule.state) {
                    RuleState.SUCCEEDED -> if (isArabic) "نجاح رائع! ✨" else "SUCCESS! ✨"
                    RuleState.FAILED -> if (isArabic) "فشلت! ❌" else "FAILED! ❌"
                    else -> if (isArabic) activeRule.titleAr else activeRule.titleEn
                }

                Text(
                    text = title,
                    color = bannerColor,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Description
                val desc = when (activeRule.state) {
                    RuleState.SUCCEEDED -> if (isArabic) "حصلت على مكافأة التحدي!" else "Reward granted!"
                    RuleState.FAILED -> if (isArabic) "تم تطبيق العقوبة!" else "Rule was broken!"
                    else -> if (isArabic) activeRule.descriptionAr else activeRule.descriptionEn
                }

                Text(
                    text = desc,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )

                if (activeRule.state == RuleState.ACTIVE) {
                    Spacer(modifier = Modifier.height(8.dp))

                    // Dynamic detail ticker (e.g. speed frenzy tap counter or bomb seconds)
                    if (activeRule.type == RuleType.SPEED_FRENZY) {
                        Text(
                            text = "${activeRule.currentTaps} / ${activeRule.targetTaps}",
                            color = Color(0xFF00E5FF),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    } else if (activeRule.type == RuleType.BOMB_TICKER) {
                        val secs = String.format("%.1fs", activeRule.timeRemainingMs / 1000f)
                        Text(
                            text = "⏱️ $secs",
                            color = Color(0xFFFF9100),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    // Countdown bar
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = bannerColor,
                        trackColor = Color(0xFF1B1E30)
                    )
                }
            }
        }
    }
}
