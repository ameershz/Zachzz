package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.config.GameConfig
import com.example.model.DailyChallenge
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MoltenGold

@Composable
fun DailyChallengeDialog(
    challenge: DailyChallenge,
    currentStreak: Int,
    isArabic: Boolean,
    onClaimChallenge: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Text(
                    text = if (isArabic) "🎯 التحدي اليومي وسلسلة الدخول" else "🎯 Daily Challenge & Streak",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Streak Calendar Section
                Text(
                    text = if (isArabic) "سلسلة تسجيل الدخول: $currentStreak أيام متتالية 🔥" else "Login Streak: $currentStreak Days 🔥",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFFF9100)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // 7 Days Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    for (day in 1..7) {
                        val isDayPassedOrCurrent = day <= (currentStreak % 7).let { if (it == 0 && currentStreak > 0) 7 else it }
                        val (coins, _) = GameConfig.DAILY_STREAK_REWARDS[day - 1]

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isDayPassedOrCurrent) Color(0xFF2E2406) else DarkCard)
                                .border(
                                    width = 1.dp,
                                    color = if (isDayPassedOrCurrent) MoltenGold else Color.Transparent,
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "D$day",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDayPassedOrCurrent) MoltenGold else Color.Gray
                            )
                            Text(
                                text = if (day == 7) "👑" else "🪙",
                                fontSize = 14.sp
                            )
                            Text(
                                text = "+$coins",
                                fontSize = 9.sp,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider(color = Color(0xFF282E47))
                Spacer(modifier = Modifier.height(16.dp))

                // Today's Challenge Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (isArabic) challenge.titleAr else challenge.titleEn,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00E5FF)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isArabic) challenge.descriptionAr else challenge.descriptionEn,
                            fontSize = 13.sp,
                            color = Color(0xFFCBD5E1),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Progress
                        val progressFraction = (challenge.currentProgress.toFloat() / challenge.targetGoal.toFloat()).coerceIn(0f, 1f)
                        LinearProgressIndicator(
                            progress = { progressFraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(CircleShape),
                            color = EmeraldGreen,
                            trackColor = Color(0xFF0C0E17)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${challenge.currentProgress} / ${challenge.targetGoal}",
                            fontSize = 12.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        // Reward tags
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "+${challenge.rewardCoins} 🪙", color = MoltenGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(text = "+${challenge.rewardXp} XP 🚀", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action Button
                if (challenge.isCompleted && !challenge.isClaimed) {
                    Button(
                        onClick = onClaimChallenge,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("claim_daily_challenge_button")
                    ) {
                        Text(
                            text = if (isArabic) "استلام المكافأة!" else "Claim Reward!",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else if (challenge.isClaimed) {
                    Text(
                        text = if (isArabic) "✅ تم استلام تحدي اليوم" else "✅ Completed & Claimed",
                        color = EmeraldGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                } else {
                    Text(
                        text = if (isArabic) "⏳ التحدي قيد التقدم" else "⏳ Challenge in Progress",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_challenge_dialog_button")
                ) {
                    Text(
                        text = if (isArabic) "إغلاق" else "Close",
                        color = Color(0xFF94A3B8)
                    )
                }
            }
        }
    }
}
