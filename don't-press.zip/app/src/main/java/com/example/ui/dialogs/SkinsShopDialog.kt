package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ButtonSkin
import com.example.model.DefaultSkins
import com.example.model.PlayerProfile
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MoltenGold

@Composable
fun SkinsShopDialog(
    profile: PlayerProfile,
    isArabic: Boolean,
    onBuySkin: (ButtonSkin) -> Unit,
    onEquipSkin: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var previewSkin by remember {
        mutableStateOf(DefaultSkins.getSkin(profile.equippedSkinId))
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header with Coins
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isArabic) "🎨 متجر المظاهر" else "🎨 Skins Shop",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🪙", fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${profile.coins}",
                            color = MoltenGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Live Preview Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // 3D Preview Orb
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(
                                            previewSkin.accentColor,
                                            previewSkin.primaryColor,
                                            previewSkin.secondaryColor
                                        )
                                    )
                                )
                                .border(3.dp, previewSkin.glowColor, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = previewSkin.iconEmoji, fontSize = 28.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (isArabic) previewSkin.nameAr else previewSkin.nameEn,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Text(
                            text = if (isArabic) previewSkin.descriptionAr else previewSkin.descriptionEn,
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Multipliers
                        Row {
                            Text(
                                text = "🪙 +${((previewSkin.coinsMultiplier - 1f) * 100).toInt()}% Coins",
                                fontSize = 11.sp,
                                color = MoltenGold,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "🚀 +${((previewSkin.xpMultiplier - 1f) * 100).toInt()}% XP",
                                fontSize = 11.sp,
                                color = Color(0xFF00E5FF),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Action for previewed skin
                        val isOwned = profile.unlockedSkinIds.contains(previewSkin.id)
                        val isEquipped = profile.equippedSkinId == previewSkin.id

                        when {
                            isEquipped -> {
                                Text(
                                    text = if (isArabic) "✅ مفعّل حالياً" else "✅ Currently Equipped",
                                    color = EmeraldGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            isOwned -> {
                                Button(
                                    onClick = { onEquipSkin(previewSkin.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                                    modifier = Modifier.testTag("equip_skin_button")
                                ) {
                                    Text(
                                        text = if (isArabic) "تفعيل" else "Equip",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            else -> {
                                val canAfford = profile.coins >= previewSkin.priceCoins
                                Button(
                                    onClick = { onBuySkin(previewSkin) },
                                    enabled = canAfford,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MoltenGold,
                                        disabledContainerColor = Color(0xFF333333)
                                    ),
                                    modifier = Modifier.testTag("buy_skin_button")
                                ) {
                                    Text(
                                        text = if (isArabic) "شراء بـ ${previewSkin.priceCoins} 🪙" else "Buy for ${previewSkin.priceCoins} 🪙",
                                        color = if (canAfford) Color.Black else Color.Gray,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Skins Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.weight(1f),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(DefaultSkins.ALL) { skin ->
                        val isSelected = previewSkin.id == skin.id
                        val isOwned = profile.unlockedSkinIds.contains(skin.id)
                        val isEquipped = profile.equippedSkinId == skin.id

                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkCard),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF282E47),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable { previewSkin = skin }
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.radialGradient(
                                                listOf(skin.primaryColor, skin.secondaryColor)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = skin.iconEmoji, fontSize = 20.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isArabic) skin.nameAr else skin.nameEn,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = when {
                                        isEquipped -> if (isArabic) "مفعّل" else "Equipped"
                                        isOwned -> if (isArabic) "مملوك" else "Owned"
                                        else -> "${skin.priceCoins} 🪙"
                                    },
                                    fontSize = 10.sp,
                                    color = if (isEquipped) EmeraldGreen else if (isOwned) Color(0xFF00E5FF) else MoltenGold,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("close_shop_button")
                ) {
                    Text(
                        text = if (isArabic) "إغلاق" else "Close",
                        color = Color.White
                    )
                }
            }
        }
    }
}
