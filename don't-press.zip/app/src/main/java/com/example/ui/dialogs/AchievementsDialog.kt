package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Achievement
import com.example.model.AchievementCategory
import com.example.model.DefaultAchievements
import com.example.model.PlayerProfile
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.MoltenGold

@Composable
fun AchievementsDialog(
    profile: PlayerProfile,
    isArabic: Boolean,
    onClaimAchievement: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf<AchievementCategory?>(null) }

    val filteredAchievements = remember(selectedCategory) {
        if (selectedCategory == null) DefaultAchievements.ALL
        else DefaultAchievements.ALL.filter { it.category == selectedCategory }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkSurface),
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isArabic) "🎖️ الإنجازات والجوائز" else "🎖️ Achievements",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Categories Row
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        FilterChip(
                            selected = selectedCategory == null,
                            onClick = { selectedCategory = null },
                            label = { Text(if (isArabic) "الكل" else "All") }
                        )
                    }
                    items(AchievementCategory.values()) { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(if (isArabic) category.labelAr else category.labelEn) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredAchievements) { ach ->
                        val isUnlocked = profile.unlockedAchievementIds.contains(ach.id)
                        val isClaimed = profile.claimedAchievementIds.contains(ach.id)

                        val currentProgress = when (ach.category) {
                            AchievementCategory.PRESSES -> profile.totalPresses
                            AchievementCategory.RULES -> profile.rulesSucceeded.toLong()
                            AchievementCategory.STREAK -> profile.currentStreak.toLong()
                            AchievementCategory.ECONOMY -> profile.coins
                            AchievementCategory.COLLECTION -> profile.unlockedSkinIds.size.toLong()
                        }

                        val progressFraction = (currentProgress.toFloat() / ach.targetGoal.toFloat()).coerceIn(0f, 1f)

                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkCard),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(
                                    width = 1.dp,
                                    color = if (isUnlocked && !isClaimed) MoltenGold else Color(0xFF282E47),
                                    shape = RoundedCornerShape(14.dp)
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = ach.iconEmoji, fontSize = 28.sp)
                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isArabic) ach.titleAr else ach.titleEn,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (isArabic) ach.descriptionAr else ach.descriptionEn,
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))

                                    LinearProgressIndicator(
                                        progress = { progressFraction },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(5.dp)
                                            .clip(CircleShape),
                                        color = if (isUnlocked) EmeraldGreen else Color(0xFF00E5FF),
                                        trackColor = Color(0xFF0C0E17)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                when {
                                    isClaimed -> {
                                        Text(
                                            text = "✅",
                                            fontSize = 16.sp
                                        )
                                    }
                                    isUnlocked -> {
                                        Button(
                                            onClick = { onClaimAchievement(ach.id) },
                                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.testTag("claim_ach_${ach.id}")
                                        ) {
                                            Text(
                                                text = "+${ach.rewardCoins}🪙",
                                                color = Color.Black,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                    else -> {
                                        Text(
                                            text = "${currentProgress.coerceAtMost(ach.targetGoal)}/${ach.targetGoal}",
                                            color = Color.Gray,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("close_achievements_button")
                ) {
                    Text(
                        text = if (isArabic) "إغلاق" else "Close",
                        color = Color.White
                    )
                }
            }
        }
    }
}
