package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ActiveRule
import com.example.model.ButtonSkin
import com.example.model.RuleType
import com.example.ui.viewmodel.FloatingParticle
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BigRedButton(
    skin: ButtonSkin,
    activeRule: ActiveRule?,
    particles: List<FloatingParticle>,
    isArabic: Boolean,
    onPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "button_scale"
    )

    // Pulsing aura animation
    val infiniteTransition = rememberInfiniteTransition(label = "aura_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    // Dynamic button colors depending on rule
    val isGoldenRush = activeRule?.type == RuleType.GOLDEN_RUSH
    val isDontPress = activeRule?.type == RuleType.DONT_PRESS
    val isColorSwitchGreen = activeRule?.type == RuleType.COLOR_SWITCH && activeRule.isTargetGreen

    val primaryColor = when {
        isGoldenRush -> Color(0xFFFFD700)
        isColorSwitchGreen -> Color(0xFF00E676)
        isDontPress -> Color(0xFFFF1744)
        else -> skin.primaryColor
    }

    val secondaryColor = when {
        isGoldenRush -> Color(0xFFFF8F00)
        isColorSwitchGreen -> Color(0xFF00B0FF)
        isDontPress -> Color(0xFFB71C1C)
        else -> skin.secondaryColor
    }

    val glowColor = when {
        isGoldenRush -> Color(0x99FFD700)
        isColorSwitchGreen -> Color(0x9900E676)
        isDontPress -> Color(0xAAFF1744)
        else -> skin.glowColor
    }

    Box(
        modifier = modifier
            .size(280.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer pulsing energy ring
        Canvas(
            modifier = Modifier
                .size(270.dp)
                .scale(pulseScale)
        ) {
            drawCircle(
                color = glowColor.copy(alpha = pulseAlpha),
                radius = size.minDimension / 2
            )
        }

        // Metal / Carbon Bezel Base
        Box(
            modifier = Modifier
                .size(240.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF2E334D), Color(0xFF141724), Color(0xFF0C0E17))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            // Hazard / Warning ring when DON'T PRESS is active
            if (isDontPress) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 8.dp.toPx()
                    drawCircle(
                        color = Color(0xFFFFCC00),
                        radius = (size.minDimension - strokeWidth) / 2,
                        style = Stroke(width = strokeWidth)
                    )
                }
            }

            // The main interactive 3D Dome
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .scale(scale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                skin.accentColor,
                                primaryColor,
                                secondaryColor
                            ),
                            center = Offset(100f, 70f),
                            radius = 180f
                        )
                    )
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                isPressed = true
                                onPress()
                                tryAwaitRelease()
                                isPressed = false
                            }
                        )
                    }
                    .testTag("main_game_button"),
                contentAlignment = Alignment.Center
            ) {
                // Top Gloss Reflection
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp)
                ) {
                    drawArc(
                        color = Color.White.copy(alpha = 0.35f),
                        startAngle = 190f,
                        sweepAngle = 160f,
                        useCenter = false,
                        style = Stroke(width = 10.dp.toPx())
                    )
                }

                // Center Text / Icon
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (isGoldenRush) "🪙" else skin.iconEmoji,
                        fontSize = 36.sp
                    )

                    val buttonLabel = when {
                        isDontPress -> if (isArabic) "لا تضغط!" else "DON'T!"
                        isGoldenRush -> if (isArabic) "5X ذهب!" else "5X GOLD!"
                        isColorSwitchGreen -> if (isArabic) "اضغط الآن!" else "TAP NOW!"
                        else -> if (isArabic) "إياك والضغط" else "DON'T PRESS"
                    }

                    Text(
                        text = buttonLabel,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Floating particles on taps
        particles.forEach { particle ->
            FloatingParticleView(particle = particle)
        }
    }
}

@Composable
fun FloatingParticleView(particle: FloatingParticle) {
    val animProgress = remember { Animatable(0f) }

    LaunchedEffect(particle.id) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(800, easing = LinearOutSlowInEasing)
        )
    }

    val alpha = 1f - animProgress.value
    val yOffset = particle.yOffset - (animProgress.value * 70f)

    Box(
        modifier = Modifier
            .offset(x = particle.xOffset.dp, y = yOffset.dp)
    ) {
        Text(
            text = particle.text,
            color = Color(particle.colorHex).copy(alpha = alpha),
            fontSize = 19.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}
