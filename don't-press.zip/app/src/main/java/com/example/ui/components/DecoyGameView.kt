package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface

@Composable
fun DecoyGameView(
    isArabic: Boolean,
    onChoiceMade: (choiceIndex: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(20.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = if (isArabic) "أي الزرين هو الحقيقي؟" else "WHICH BUTTON IS REAL?",
                color = Color(0xFF00E5FF),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Button Option 1
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0xFFFF5252), Color(0xFFD50000), Color(0xFF5D0000))
                            )
                        )
                        .clickable { onChoiceMade(0) }
                        .testTag("decoy_choice_0"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "1️⃣",
                        fontSize = 32.sp
                    )
                }

                // Button Option 2
                Box(
                    modifier = Modifier
                        .size(110.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0xFFFF5252), Color(0xFFD50000), Color(0xFF5D0000))
                            )
                        )
                        .clickable { onChoiceMade(1) }
                        .testTag("decoy_choice_1"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "2️⃣",
                        fontSize = 32.sp
                    )
                }
            }
        }
    }
}
