package com.example.config

import kotlin.math.pow

object GameConfig {

    // Base Tap Economics
    const val BASE_TAP_COINS = 1L
    const val BASE_TAP_XP = 2L

    // Combo system
    const val COMBO_DECAY_MS = 1800L
    const val MAX_COMBO_MULTIPLIER = 5

    fun getComboMultiplier(comboCount: Int): Int {
        return when {
            comboCount >= 50 -> 5
            comboCount >= 30 -> 4
            comboCount >= 15 -> 3
            comboCount >= 5 -> 2
            else -> 1
        }
    }

    // Level progression: XP needed to go from level L to L+1
    fun xpRequiredForLevel(level: Int): Long {
        if (level <= 1) return 100L
        return (100.0 * (level.toDouble()).pow(1.35)).toLong()
    }

    fun calculateLevelInfo(totalXp: Long): Triple<Int, Long, Long> {
        var currentLevel = 1
        var remainingXp = totalXp

        while (true) {
            val needed = xpRequiredForLevel(currentLevel)
            if (remainingXp >= needed) {
                remainingXp -= needed
                currentLevel++
            } else {
                return Triple(currentLevel, remainingXp, needed)
            }
        }
    }

    fun levelUpRewardCoins(level: Int): Long {
        return level * 100L
    }

    // Daily Streak 7-day schedule (Coins, XP)
    val DAILY_STREAK_REWARDS = listOf(
        Pair(50L, 100L),    // Day 1
        Pair(100L, 200L),   // Day 2
        Pair(200L, 350L),   // Day 3
        Pair(350L, 500L),   // Day 4
        Pair(500L, 750L),   // Day 5
        Pair(800L, 1000L),  // Day 6
        Pair(1500L, 2500L)  // Day 7
    )

    // Security & Anti-Cheat: Max taps in 1 second window
    const val MAX_TAPS_PER_SECOND = 22

    // Rules interval: trigger a rule every N taps or random intervals
    const val MIN_TAPS_BETWEEN_RULES = 15
    const val MAX_TAPS_BETWEEN_RULES = 35

    // Built-in Events
    val DEFAULT_EVENTS = listOf(
        com.example.model.GameEvent(
            id = "evt_weekend_mayhem",
            titleEn = "Weekend Mayhem",
            titleAr = "فوضى عطلة نهاية الأسبوع",
            descriptionEn = "Double Coins on all presses & rules!",
            descriptionAr = "مضاعفة العملات لكل الضغطات والتحديات!",
            iconEmoji = "⚡",
            coinsMultiplier = 2.0f,
            xpMultiplier = 1.0f,
            durationHoursRemaining = 24
        ),
        com.example.model.GameEvent(
            id = "evt_xp_overdrive",
            titleEn = "XP Overdrive",
            titleAr = "طفرة الخبرة",
            descriptionEn = "1.5x XP across all activities!",
            descriptionAr = "1.5 ضعف نقاط الخبرة في جميع الأنشطة!",
            iconEmoji = "🚀",
            coinsMultiplier = 1.0f,
            xpMultiplier = 1.5f,
            durationHoursRemaining = 12
        ),
        com.example.model.GameEvent(
            id = "evt_golden_hour",
            titleEn = "Golden Hour",
            titleAr = "الساعة الذهبية",
            descriptionEn = "Golden Touch events appear 3x more frequently!",
            descriptionAr = "تحديات اللمسة الذهبية تظهر بتكرار 3 أضعاف!",
            iconEmoji = "✨",
            coinsMultiplier = 1.5f,
            xpMultiplier = 1.2f,
            durationHoursRemaining = 6
        )
    )
}
