package com.example.billing

interface BillingManager {
    fun purchaseItem(skuId: String, onComplete: (Boolean) -> Unit)
}

class PlaceholderBillingManager : BillingManager {
    override fun purchaseItem(skuId: String, onComplete: (Boolean) -> Unit) {
        // Safe placeholder for Google Play Billing Library
        onComplete(true)
    }
}
