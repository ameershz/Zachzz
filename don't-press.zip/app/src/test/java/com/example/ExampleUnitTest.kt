package com.example

import com.example.config.GameConfig
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testComboMultiplier() {
        assertEquals(1, GameConfig.getComboMultiplier(0))
        assertEquals(2, GameConfig.getComboMultiplier(6))
        assertEquals(3, GameConfig.getComboMultiplier(16))
        assertEquals(4, GameConfig.getComboMultiplier(32))
        assertEquals(5, GameConfig.getComboMultiplier(55))
    }

    @Test
    fun testLevelCalculations() {
        val (level1, xp1, needed1) = GameConfig.calculateLevelInfo(50L)
        assertEquals(1, level1)
        assertEquals(50L, xp1)
        assertEquals(100L, needed1)

        val (level2, xp2, _) = GameConfig.calculateLevelInfo(150L)
        assertEquals(2, level2)
        assertEquals(50L, xp2)
    }
}
