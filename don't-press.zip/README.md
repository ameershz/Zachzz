# DON'T PRESS 🔴 — لعبة إياك والضغط

مرحباً بك في مشروع **DON'T PRESS 🔴**، لعبة موبايل أركيد تفاعلية ومسلية مبنية بالكامل بلغة **Kotlin** وأحدث تقنيات **Jetpack Compose** ومجهزة للتصدير المباشر كحزمة **Android APK**.

---

## 📖 جدول المحتويات / Table of Contents
1. [فكرة اللعبة ومميزاتها](#فكرة-اللعبة-ومميزاتها)
2. [هيكلية المشروع وملفاته](#هيكلية-المشروع-وملفاته)
3. [كيفية استخراج ملف الـ Android APK](#كيفية-استخراج-ملف-الـ-android-apk)
4. [دليل ربط خدمات Google و Firebase](#دليل-ربط-خدمات-google-و-firebase-للمبتدئين)
5. [كيفية إضافة محتوى جديد (أشكال، قواعد، تحديات)](#كيفية-إضافة-محتوى-جديد)
6. [English Overview & Architecture Guide](#english-overview--architecture-guide)

---

## 🎮 فكرة اللعبة ومميزاتها

- **الزر الأحمر الغامض 🔴:** زر تفاعلي ثلاثي الأبعاد مع ارتداد فيزيائي، مؤثرات هالة ضوئية، ومؤثرات انفجار النقاط (+1 عملة، كومبو x5).
- **قواعد ديناميكية متغيرة:**
  - **إياك والضغط (DON'T PRESS!):** شريط خطر ينذرك بعدم لمس الزر لعدة ثوانٍ؛ اللمس يفرض عقوبة، بينما الصبر يمنحك مكافأة ذهبية.
  - **فورة السرعة (Speed Frenzy):** اضغط 10 مرات في أقل من 4 ثوانٍ للفوز.
  - **المنطق المعكوس (Reverse Psychology):** رسالة مخادعة "أرجوك لا لا تضغط عليّ!".
  - **تبديل الألوان (Color Switch):** انتظر حتى يتحول الزر إلى اللون الأخضر.
  - **إبطال القنبلة (Bomb Defusal):** انقر على الزر عند الثانية 1.0 بالضبط.
  - **اللمسة الذهبية (Golden Touch):** يتحول الزر إلى الذهب وتتضاعف العملات 5 أضعاف.
  - **الزر المزيف (Decoy Button):** يظهر زرّان لاختيار الزر الحقيقي وتفادي الفخ.
- **نظام الحساب والتقدم:**
  - حفظ العملات، نقاط الخبرة (XP)، المستوى الحالي، وإجمالي الضغطات.
  - حفظ محلي فوري وآمن (Offline-First) لضمان عدم ضياع أي تقدم حتى عند انقطاع الإنترنت.
- **التحديات اليومية (Daily Challenges):**
  - تحدٍ يومي عالمي متجدد كل يوم لجميع اللاعبين مع جوائز عملات وخبرة.
- **سلسلة الدخول اليومي (Daily Streak):**
  - تقويم 7 أيام مع مكافآت تصاعدية وجائزة كبرى في اليوم السابع.
- **لوحة الصدارة العالمية (Leaderboard):**
  - تصنيف عالمي تنافسي يعرض رتبتك، اسمك، مستواك، وعدد ضغطاتك.
- **متجر المظاهر (Skins Shop):**
  - مظاهر رائعة (الأحمر الكلاسيكي، النيون السيبراني، الذهب المنصهر، الجليد، المجرة العميقة، خلل المصفوفة، اللهب الحارق، والطيف المنشوري).
- **مؤثرات صوتية واهتزاز حقيقي (SFX & Haptics):**
  - محاكي صوتيات عالي الجودة مبني بدون ملفات خارجية ثقيلة، مع اهتزازات لمسية حقيقية.
- **دعم كامل للغتين (العربية والإنجليزية):**
  - دعم كامل للغة العربية وتخطيط RTL.

---

## 📂 هيكلية المشروع وملفاته (Project Architecture)

المشروع مفصول بدقة واحترافية وفق نمط MVVM:

```
app/src/main/java/com/example/
├── MainActivity.kt                # نقطة البداية وتشغيل الواجهة بنمط Edge-to-Edge
├── audio/
│   └── SoundManager.kt           # محاكي المؤثرات الصوتية الإجرائي (Mechanical Click, Coin, Buzzer, Fanfare)
├── haptics/
│   └── HapticsManager.kt         # إدارة الاهتزازات والتفاعل اللمسي
├── model/
│   ├── PlayerProfile.kt          # نموذج بيانات اللاعب (العملات، الخبرة، المستوى، المظاهر)
│   ├── ButtonSkin.kt             # نماذج المظاهر وأسعارها ومضاعفاتها
│   ├── GameRule.kt               # نماذج القواعد والأحداث الديناميكية
│   ├── DailyChallenge.kt         # نموذج التحدي اليومي
│   ├── Achievement.kt            # نماذج الإنجازات والجوائز
│   ├── LeaderboardEntry.kt       # نموذج لوحة الصدارة
│   └── GameEvent.kt              # نموذج الفعاليات الحية
├── config/
│   └── GameConfig.kt             # جميع إعدادات اللعبة، معادلات الـ XP، الجوائز، ومكافحة الغش
├── rules/
│   └── RuleEngine.kt             # محرك توليد وتتبع القواعد الديناميكية
├── data/
│   ├── GameDataStore.kt          # التخزين المحلي الآمن والمستمر
│   ├── GameRepository.kt         # مستودع بيانات اللعبة وتطبيق القواعد الحسابية
│   └── LeaderboardRepository.kt  # إدارة وتصنيف المتصدرين
├── ai/
│   └── AiChallengeService.kt     # طبقة توليد التحديات والتعليقات الذكية عبر Gemini
├── ads/
│   └── AdsManager.kt             # واجهة جاهزة لدمج إعلانات Google AdMob مستقبلاً
├── analytics/
│   └── AnalyticsTracker.kt       # تتبع الفعاليات والأداء
├── billing/
│   └── BillingManager.kt         # واجهة جاهزة للشراء داخل التطبيق مستقبلاً
└── ui/
    ├── theme/                    # الألوان والأشكال الخاصة بالثيم الليلي للأركيد
    ├── components/
    │   ├── BigRedButton.kt       # الزر الأحمر ثلاثي الأبعاد والمؤثرات البصرية
    │   ├── TopStatusBar.kt       # شريط العملات والمستوى والسلسلة
    │   ├── RulePromptBanner.kt   # شريط عرض القواعد والعداد التنازلي
    │   └── DecoyGameView.kt      # واجهة الزر المزيف
    ├── dialogs/
    │   ├── DailyChallengeDialog.kt # نافذة التحدي اليومي والـ Streak
    │   ├── LeaderboardDialog.kt    # نافذة المتصدرين
    │   ├── SkinsShopDialog.kt      # نافذة متجر المظاهر
    │   ├── AchievementsDialog.kt   # نافذة الإنجازات
    │   ├── EventsDialog.kt         # نافذة الفعاليات الحية
    │   ├── ProfileSettingsDialog.kt# نافذة الملف الشخصي والإعدادات
    │   ├── LevelUpDialog.kt        # نافذة ترقية المستوى
    │   └── AntiCheatDialog.kt      # نافذة التحقق البشري عند النقر فائق السرعة
    └── screens/
        └── GameScreen.kt         # الشاشة الرئيسية المجمعة لجميع العناصر
```

---

## 📲 كيفية استخراج ملف الـ Android APK

لأن المشروع مبني بالكامل ككود أصلي (Native Kotlin):

1. **من داخل AI Studio:**
   - اضغط على قائمة الإعدادات (أيقونة الترس ⚙️ أو القائمة العلوية).
   - اختر **Export as ZIP** أو **Generate APK / AAB**.
2. **من خلال Android Studio على جهازك:**
   - قم بتحميل المشروع وفك الضغط.
   - افتح مجلد المشروع في برنامج Android Studio.
   - انتظر ثوانٍ حتى ينتهي التحميل (Sync).
   - اضغط في القائمة العلوية على: **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
   - سيظهر لك إشعار يخبرك بانتهاء البناء ومسار ملف `app-debug.apk` الذي يمكنك تثبيته مباشرة على هاتفك!

---

## ☁️ دليل ربط خدمات Google و Firebase (للمبتدئين خطوة بخطوة)

إذا رغبت في تفعيل المزامنة السحابية الكاملة عبر Firebase:

1. ادخل إلى موقع [Firebase Console](https://console.firebase.google.com).
2. اضغط على **Create a project** وأدخل اسم المشروع (مثلاً `DontPressGame`).
3. بعد إنشاء المشروع، اضغط على أيقونة **Android** لإضافة تطبيق جديد:
   - **Android package name:** اكتب `com.aistudio.dontpress.rxbkln` (تطابق الموجودة في `app/build.gradle.kts`).
   - اضغط **Register app**.
4. حمّل ملف **`google-services.json`** وضعه في المجلد:
   `app/google-services.json`.
5. في لوحة تحكم Firebase:
   - من القائمة الجانبية ادخل على **Build -> Firestore Database** واضغط **Create database**.
   - من **Build -> Authentication**، فعّل خيار **Google Sign-In**.

---

## 🛠️ كيفية تعديل إعدادات اللعبة وإضافة محتوى جديد

جميع الإعدادات متمركزة في ملف واحد لسهولة التعديل دون لمس بقية الكود:
- افتح الملف: `app/src/main/java/com/example/config/GameConfig.kt`.
- يمكنك تغيير:
  - `BASE_TAP_COINS`: عدد العملات لكل ضغطة.
  - `DAILY_STREAK_REWARDS`: مكافآت الأيام السبعة.
  - `xpRequiredForLevel(level)`: معادلة ونقاط ترقية المستوى.
- لإضافة مظهر جديد (Skin):
  - افتح `app/src/main/java/com/example/model/ButtonSkin.kt` وأضف عنصراً جديداً في قائمة `DefaultSkins.ALL` مع اللون والرمز والسعر المطلوب.
- لإضافة إنجاز جديد:
  - افتح `app/src/main/java/com/example/model/Achievement.kt` وأضف عنصراً جديداً في `DefaultAchievements.ALL`.

---

## 🇬🇧 English Overview & Architecture Guide

### Core Tech Stack
- **Language:** 100% Modern Kotlin
- **UI Toolkit:** Jetpack Compose & Material 3
- **Audio Engine:** Low-latency procedural PCM synthesizer using Android `AudioTrack` (zero asset dependencies)
- **Haptics:** Modern `Vibrator` / `VibrationEffect` integration with settings toggles
- **State Management:** MVVM Architecture with Kotlin `StateFlow` and Coroutines
- **Offline-First Storage:** Atomic local preferences & JSON state persistence
- **Security:** In-app anti-autoclicker rate limiter (prevents clickbot exploitation)
- **Localization:** Full English and Arabic strings with dynamic RTL switching

### Ready for Google Services & Store Release
- `applicationId`: `com.aistudio.dontpress.rxbkln`
- `targetSdk`: 36 (Android 15+ ready)
- Vector adaptive icons & high-density mipmap rasters generated
- Android Manifest permissions: `INTERNET` and `VIBRATE`
