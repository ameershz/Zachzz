package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppSettings
import com.example.ui.MainViewModel
import com.example.ui.components.GlowCard
import com.example.ui.theme.ArabicGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Overlay & Engine Settings",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // 1. Floating Bubble Appearance Card
        GlowCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.DisplaySettings, contentDescription = null, tint = CyberCyan)
                Text("Floating Bubble Appearance", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bubble Size Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Bubble Diameter", color = TextPrimary, fontSize = 13.sp)
                    Text("${settings.bubbleSizeDp} dp", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Slider(
                    value = settings.bubbleSizeDp.toFloat(),
                    onValueChange = { viewModel.updateSettings(settings.copy(bubbleSizeDp = it.toInt())) },
                    valueRange = 44f..80f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = CyberCyan,
                        activeTrackColor = CyberCyan,
                        inactiveTrackColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.testTag("slider_bubble_size")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Bubble Opacity Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Bubble Opacity", color = TextPrimary, fontSize = 13.sp)
                    Text("${(settings.bubbleOpacity * 100).toInt()}%", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Slider(
                    value = settings.bubbleOpacity,
                    onValueChange = { viewModel.updateSettings(settings.copy(bubbleOpacity = it)) },
                    valueRange = 0.5f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = CyberCyan,
                        activeTrackColor = CyberCyan,
                        inactiveTrackColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.testTag("slider_bubble_opacity")
                )
            }
        }

        // 2. Overlay Typography & Zoom
        GlowCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.FormatSize, contentDescription = null, tint = NeonEmerald)
                Text("Translation Card Typography", color = NeonEmerald, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Font Size Slider
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Default Font Size", color = TextPrimary, fontSize = 13.sp)
                    Text("${settings.overlayFontSizeSp} sp", color = NeonEmerald, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Slider(
                    value = settings.overlayFontSizeSp.toFloat(),
                    onValueChange = { viewModel.updateSettings(settings.copy(overlayFontSizeSp = it.toInt())) },
                    valueRange = 12f..24f,
                    steps = 5,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonEmerald,
                        activeTrackColor = NeonEmerald,
                        inactiveTrackColor = DarkSurfaceElevated
                    ),
                    modifier = Modifier.testTag("slider_font_size")
                )
            }
        }

        // 3. System & Feedback Behaviors
        GlowCard {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Vibration, contentDescription = null, tint = NeonPurple)
                Text("Interaction & Haptics", color = NeonPurple, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Haptic Feedback Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Vibration on Tap", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("Provide gentle tactile feedback when capturing screen", color = TextMuted, fontSize = 11.sp)
                }
                Switch(
                    checked = settings.enableHaptics,
                    onCheckedChange = { viewModel.updateSettings(settings.copy(enableHaptics = it)) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NeonPurple,
                        checkedTrackColor = NeonPurple.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.testTag("switch_haptics")
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Offline Dictionary Fallback Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Offline Dictionary Fallback", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("Instant vocabulary mapping when ML model is offline", color = TextMuted, fontSize = 11.sp)
                }
                Switch(
                    checked = settings.useOfflineFallback,
                    onCheckedChange = { viewModel.updateSettings(settings.copy(useOfflineFallback = it)) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NeonEmerald,
                        checkedTrackColor = NeonEmerald.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.testTag("switch_offline_fallback")
                )
            }
        }

        // 4. Reset Defaults Button
        OutlinedButton(
            onClick = { viewModel.updateSettings(AppSettings()) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_reset_settings"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.RestartAlt, contentDescription = null, tint = TextMuted)
            Text("Reset All Settings to Default", color = TextSecondary, modifier = Modifier.padding(start = 8.dp))
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
