package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.OmniTransApplication
import com.example.data.model.AppSettings
import com.example.data.model.TranslationHistoryItem
import com.example.engine.ModelDownloadState
import com.example.service.FloatingOverlayService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as OmniTransApplication
    private val repository = app.translationRepository
    private val translationEngine = app.translationEngine
    private val ocrEngine = app.ocrEngine

    // Service state
    val isServiceRunning: StateFlow<Boolean> = FloatingOverlayService.isServiceRunning

    // Overlay Permission status
    private val _hasOverlayPermission = MutableStateFlow(checkOverlayPermission())
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    // Model Download State
    val modelDownloadState: StateFlow<ModelDownloadState> = translationEngine.downloadState

    // Settings
    val settings: StateFlow<AppSettings> = repository.settings

    // History filter & search
    val searchQuery = MutableStateFlow("")
    val selectedTab = MutableStateFlow(0) // 0: Dashboard, 1: History, 2: Guide, 3: Settings
    val filterOnlyFavorites = MutableStateFlow(false)

    val historyItems: StateFlow<List<TranslationHistoryItem>> = combine(
        searchQuery,
        filterOnlyFavorites
    ) { query, favoritesOnly ->
        Pair(query, favoritesOnly)
    }.flatMapLatest { (query, favoritesOnly) ->
        if (query.isNotBlank()) {
            repository.searchHistory(query)
        } else if (favoritesOnly) {
            repository.favoriteHistory
        } else {
            repository.allHistory
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val historyCount: StateFlow<Int> = repository.historyCount.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    // Quick Sandbox Translation State
    val sandboxInput = MutableStateFlow("Press Start Game to enter the dungeon and claim your reward.")
    val sandboxTranslated = MutableStateFlow("اضغط على ابدأ اللعبة لدخول الكهف واستلام مكافأتك.")
    val isTranslatingSandbox = MutableStateFlow(false)

    // Image Sandbox OCR State
    val pickedImageUri = MutableStateFlow<Uri?>(null)
    val imageOcrOriginal = MutableStateFlow("")
    val imageOcrTranslated = MutableStateFlow("")
    val isProcessingImage = MutableStateFlow(false)

    init {
        checkModelStatus()
    }

    fun refreshOverlayPermission() {
        _hasOverlayPermission.value = checkOverlayPermission()
    }

    private fun checkOverlayPermission(): Boolean {
        return Settings.canDrawOverlays(getApplication())
    }

    fun checkModelStatus() {
        viewModelScope.launch {
            translationEngine.isModelDownloaded()
        }
    }

    fun downloadArabicModel(wifiOnly: Boolean = false) {
        viewModelScope.launch {
            translationEngine.checkAndDownloadModel(wifiOnly)
        }
    }

    fun translateSandboxText() {
        val input = sandboxInput.value.trim()
        if (input.isEmpty()) return

        viewModelScope.launch {
            isTranslatingSandbox.value = true
            val result = translationEngine.translate(input)
            sandboxTranslated.value = result
            isTranslatingSandbox.value = false
            repository.saveTranslation(input, result, "Quick Sandbox")
        }
    }

    fun processImageUri(uri: Uri) {
        pickedImageUri.value = uri
        viewModelScope.launch(Dispatchers.IO) {
            isProcessingImage.value = true
            try {
                val bitmap: Bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(getApplication<Application>().contentResolver, uri)) { decoder, _, _ ->
                        decoder.isMutableRequired = true
                    }
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(getApplication<Application>().contentResolver, uri)
                }

                val ocrResult = ocrEngine.recognizeText(bitmap)
                if (ocrResult.isSuccessful && ocrResult.fullText.isNotBlank()) {
                    imageOcrOriginal.value = ocrResult.fullText
                    val translated = translationEngine.translate(ocrResult.fullText)
                    imageOcrTranslated.value = translated
                    repository.saveTranslation(ocrResult.fullText, translated, "Image Scanner")
                } else {
                    imageOcrOriginal.value = "No readable English text detected."
                    imageOcrTranslated.value = "لم يتم العثور على نص إنجليزي مقروء."
                }
            } catch (e: Exception) {
                imageOcrOriginal.value = "Failed to load image: ${e.message}"
                imageOcrTranslated.value = "فشل في معالجة الصورة."
            } finally {
                isProcessingImage.value = false
            }
        }
    }

    fun toggleFavorite(item: TranslationHistoryItem) {
        viewModelScope.launch {
            repository.toggleFavorite(item.id, item.isFavorite)
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            repository.deleteItem(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    fun updateSettings(newSettings: AppSettings) {
        repository.updateSettings(newSettings)
    }
}
