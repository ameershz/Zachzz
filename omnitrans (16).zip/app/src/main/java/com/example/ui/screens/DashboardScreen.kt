package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.engine.ModelDownloadState
import com.example.ui.MainViewModel
import com.example.ui.components.GlowCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.TranslationResultPairCard
import com.example.ui.theme.ArabicGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    onRequestMediaProjection: () -> Unit,
    onStopService: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val isServiceRunning by viewModel.isServiceRunning.collectAsStateWithLifecycle()
    val hasOverlayPermission by viewModel.hasOverlayPermission.collectAsStateWithLifecycle()
    val modelState by viewModel.modelDownloadState.collectAsStateWithLifecycle()
    val historyCount by viewModel.historyCount.collectAsStateWithLifecycle()

    val sandboxInput by viewModel.sandboxInput.collectAsStateWithLifecycle()
    val sandboxTranslated by viewModel.sandboxTranslated.collectAsStateWithLifecycle()
    val isTranslatingSandbox by viewModel.isTranslatingSandbox.collectAsStateWithLifecycle()

    val imageOriginal by viewModel.imageOcrOriginal.collectAsStateWithLifecycle()
    val imageTranslated by viewModel.imageOcrTranslated.collectAsStateWithLifecycle()
    val isProcessingImage by viewModel.isProcessingImage.collectAsStateWithLifecycle()

    // Photo picker for OCR image test
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.processImageUri(it) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Card
        HeroHeader(
            isServiceRunning = isServiceRunning,
            historyCount = historyCount,
            onToggleService = {
                if (isServiceRunning) {
                    onStopService()
                } else {
                    if (!hasOverlayPermission) {
                        Toast.makeText(context, "Please enable 'Draw over other apps' permission first", Toast.LENGTH_LONG).show()
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    } else {
                        onRequestMediaProjection()
                    }
                }
            }
        )

        // System Requirements & Permission Checklist
        PermissionsChecklistCard(
            hasOverlay = hasOverlayPermission,
            modelState = modelState,
            onGrantOverlay = {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                )
                context.startActivity(intent)
            },
            onDownloadModel = { viewModel.downloadArabicModel(wifiOnly = false) }
        )

        // Live Quick Translator Sandbox
        LiveSandboxCard(
            inputText = sandboxInput,
            translatedText = sandboxTranslated,
            isTranslating = isTranslatingSandbox,
            onInputChange = { viewModel.sandboxInput.value = it },
            onTranslate = { viewModel.translateSandboxText() }
        )

        // Image & Game Screenshot Scanner Test
        ScreenshotScannerCard(
            isProcessing = isProcessingImage,
            originalText = imageOriginal,
            translatedText = imageTranslated,
            onPickImage = { imagePickerLauncher.launch("image/*") }
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun HeroHeader(
    isServiceRunning: Boolean,
    historyCount: Int,
    onToggleService: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isServiceRunning) NeonEmerald.copy(alpha = 0.6f) else CyberCyan.copy(alpha = 0.3f),
                RoundedCornerShape(22.dp)
            )
            .shadow(12.dp, RoundedCornerShape(22.dp)),
        shape = RoundedCornerShape(22.dp),
        color = DarkSurfaceElevated
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    Brush.linearGradient(listOf(CyberCyan, NeonPurple)),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Ω", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                        Text(
                            text = "OmniTrans",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "Game & Screen Translator (EN ➜ AR)",
                        fontSize = 12.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                StatusBadge(
                    label = "Service",
                    isActive = isServiceRunning,
                    activeText = "RUNNING",
                    inactiveText = "STOPPED"
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Master Toggle Button
            Button(
                onClick = onToggleService,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("btn_master_toggle"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isServiceRunning) Color(0xFFE53935) else CyberCyan,
                    contentColor = if (isServiceRunning) Color.White else Color(0xFF00363D)
                )
            ) {
                Icon(
                    imageVector = if (isServiceRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isServiceRunning) "Stop Floating Translator" else "Start Floating Translator",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (isServiceRunning) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Floating bubble is visible on your screen. Tap it while playing any game!",
                    color = NeonEmerald,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
private fun PermissionsChecklistCard(
    hasOverlay: Boolean,
    modelState: ModelDownloadState,
    onGrantOverlay: () -> Unit,
    onDownloadModel: () -> Unit
) {
    GlowCard {
        Text(
            text = "SYSTEM & ENGINE STATUS",
            color = CyberCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        // 1. Overlay Permission Item
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = if (hasOverlay) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (hasOverlay) NeonEmerald else ArabicGold,
                    modifier = Modifier.size(20.dp)
                )
                Column {
                    Text(
                        text = "Display Over Other Apps",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (hasOverlay) "Permission Granted" else "Required for floating bubble",
                        color = if (hasOverlay) NeonEmerald else TextMuted,
                        fontSize = 11.sp
                    )
                }
            }

            if (!hasOverlay) {
                OutlinedButton(
                    onClick = onGrantOverlay,
                    modifier = Modifier.testTag("btn_grant_overlay"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Grant", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 2. ML Kit Arabic Offline Model
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = when (modelState) {
                        is ModelDownloadState.Ready -> Icons.Default.CheckCircle
                        is ModelDownloadState.Downloading -> Icons.Default.CloudDownload
                        else -> Icons.Default.CloudDownload
                    },
                    contentDescription = null,
                    tint = when (modelState) {
                        is ModelDownloadState.Ready -> NeonEmerald
                        is ModelDownloadState.Downloading -> CyberCyan
                        else -> ArabicGold
                    },
                    modifier = Modifier.size(20.dp)
                )
                Column {
                    Text(
                        text = "Offline Arabic Translation Model",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = when (modelState) {
                            is ModelDownloadState.Ready -> "Model Ready (High Precision)"
                            is ModelDownloadState.Downloading -> "Downloading model (~30MB)..."
                            is ModelDownloadState.Error -> "Offline fallback dictionary active"
                            else -> "Offline fallback active (Download model for best results)"
                        },
                        color = when (modelState) {
                            is ModelDownloadState.Ready -> NeonEmerald
                            is ModelDownloadState.Downloading -> CyberCyan
                            else -> TextMuted
                        },
                        fontSize = 11.sp
                    )
                }
            }

            if (modelState !is ModelDownloadState.Ready) {
                if (modelState is ModelDownloadState.Downloading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.dp,
                        color = CyberCyan
                    )
                } else {
                    OutlinedButton(
                        onClick = onDownloadModel,
                        modifier = Modifier.testTag("btn_download_model"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Download", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveSandboxCard(
    inputText: String,
    translatedText: String,
    isTranslating: Boolean,
    onInputChange: (String) -> Unit,
    onTranslate: () -> Unit
) {
    GlowCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LIVE TRANSLATION SANDBOX",
                color = NeonPurple,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Test Engine",
                color = TextMuted,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = inputText,
            onValueChange = onInputChange,
            label = { Text("English Game / Screen Text") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("input_sandbox_text"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyberCyan,
                unfocusedBorderColor = DarkSurfaceBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedLabelColor = CyberCyan,
                unfocusedLabelColor = TextMuted
            ),
            shape = RoundedCornerShape(12.dp),
            maxLines = 3
        )

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onTranslate,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_translate_sandbox"),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
        ) {
            if (isTranslating) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Translate Text", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (translatedText.isNotBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(NeonEmerald.copy(alpha = 0.12f))
                    .border(1.dp, NeonEmerald.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text(
                    text = "الترجمة الفورية",
                    color = NeonEmerald,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = translatedText,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.End
                )
            }
        }
    }
}

@Composable
private fun ScreenshotScannerCard(
    isProcessing: Boolean,
    originalText: String,
    translatedText: String,
    onPickImage: () -> Unit
) {
    GlowCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SCREENSHOT OCR SCANNER",
                color = ArabicGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            Icon(Icons.Default.Image, contentDescription = null, tint = ArabicGold, modifier = Modifier.size(18.dp))
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Pick any game screenshot or photo to test the ML Kit OCR text detection and Arabic translation.",
            color = TextSecondary,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onPickImage,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("btn_pick_screenshot"),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C384F))
        ) {
            if (isProcessing) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = CyberCyan, strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Scanning image OCR...", fontSize = 13.sp)
            } else {
                Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp), tint = CyberCyan)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Select Screenshot from Gallery", fontSize = 13.sp, color = TextPrimary)
            }
        }

        if (originalText.isNotBlank()) {
            Spacer(modifier = Modifier.height(12.dp))
            TranslationResultPairCard(
                originalText = originalText,
                translatedText = translatedText,
                sourceContext = "Gallery Screenshot"
            )
        }
    }
}
