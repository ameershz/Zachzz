package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Cyber Gaming Palette
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanGlow = Color(0x3300E5FF)
val NeonEmerald = Color(0xFF00E676)
val NeonPurple = Color(0xFFB388FF)
val NeonPink = Color(0xFFFF4081)
val ElectricBlue = Color(0xFF2979FF)

// Dark Theme Surfaces
val DarkBackground = Color(0xFF090B10)
val DarkSurface = Color(0xFF131722)
val DarkSurfaceElevated = Color(0xFF1C2233)
val DarkSurfaceBorder = Color(0xFF2E3852)

// Text Colors
val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF9AA7C2)
val TextMuted = Color(0xFF627191)

// Arabic Accent Tag Color
val ArabicGold = Color(0xFFFFD54F)
val ArabicGoldGlow = Color(0x33FFD54F)

// Overlay specific
val OverlayCardBg = Color(0xEE0D111A)
val OverlayBorder = Color(0x8800E5FF)
