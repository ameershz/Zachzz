package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlowCard
import com.example.ui.theme.ArabicGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun GameGuideScreen(modifier: Modifier = Modifier) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Game Translation Guide",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // 1. Gesture Controls Card
        GlowCard(borderColor = CyberCyan.copy(alpha = 0.4f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.TouchApp, contentDescription = null, tint = CyberCyan)
                Text("Floating Bubble Controls", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            GuideStepItem(
                number = "1",
                title = "Single Tap to Translate Screen",
                desc = "Instantly captures and OCR-scans whatever is on your display and shows the Arabic translation overlay window."
            )

            Spacer(modifier = Modifier.height(10.dp))

            GuideStepItem(
                number = "2",
                title = "Drag to Reposition",
                desc = "Move the bubble to any corner of your screen so it never blocks your game buttons, joystick, or mini-map."
            )

            Spacer(modifier = Modifier.height(10.dp))

            GuideStepItem(
                number = "3",
                title = "Long Press to Open App",
                desc = "Hold down the bubble for 1 second to return directly to OmniTrans control hub and translation history."
            )
        }

        // 2. Gaming Terms Quick Reference
        GlowCard(borderColor = NeonEmerald.copy(alpha = 0.4f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Gamepad, contentDescription = null, tint = NeonEmerald)
                Text("Common Gaming Vocab (English ➜ Arabic)", color = NeonEmerald, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            val terms = listOf(
                "Health (HP)" to "نقاط الصحة",
                "Mana (MP)" to "نقاط السحر",
                "Attack / ATK" to "هجوم",
                "Defense / DEF" to "دفاع",
                "Critical Damage" to "ضرر ضربة حرجة",
                "Inventory" to "الحقيبة / المخزون",
                "Skill Tree" to "شجرة المهارات",
                "Cooldown" to "فترة التهدئة",
                "Quest / Mission" to "المهمة",
                "Claim Rewards" to "استلام المكافآت",
                "Victory / Defeat" to "انتصار / هزيمة"
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                terms.forEach { (en, ar) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF161C2C))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(en, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(ar, color = NeonEmerald, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun GuideStepItem(number: String, title: String, desc: String) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .background(CyberCyan.copy(alpha = 0.2f), CircleShape)
                .border(1.dp, CyberCyan, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(number, color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Column {
            Text(title, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(desc, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}
