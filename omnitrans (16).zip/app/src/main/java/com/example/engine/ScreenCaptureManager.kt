package com.example.engine

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class ScreenCaptureManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val projectionManager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    private val handler = Handler(Looper.getMainLooper())

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 1080
    private var screenHeight = 1920
    private var screenDensity = DisplayMetrics.DENSITY_DEFAULT

    fun initProjection(resultCode: Int, data: Intent): Boolean {
        return try {
            stopProjection()
            mediaProjection = projectionManager.getMediaProjection(resultCode, data)
            mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    super.onStop()
                    releaseVirtualDisplay()
                }
            }, handler)
            mediaProjection != null
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    private fun updateScreenMetrics() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val windowMetrics = windowManager.currentWindowMetrics
                val bounds = windowMetrics.bounds
                screenWidth = bounds.width().coerceAtLeast(480)
                screenHeight = bounds.height().coerceAtLeast(800)
                screenDensity = context.resources.configuration.densityDpi
            } else {
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getRealMetrics(metrics)
                screenWidth = metrics.widthPixels.coerceAtLeast(480)
                screenHeight = metrics.heightPixels.coerceAtLeast(800)
                screenDensity = metrics.densityDpi
            }
        } catch (e: Exception) {
            val metrics = context.resources.displayMetrics
            screenWidth = metrics.widthPixels.coerceAtLeast(480)
            screenHeight = metrics.heightPixels.coerceAtLeast(800)
            screenDensity = metrics.densityDpi
        }
    }

    @SuppressLint("WrongConstant")
    private fun setupVirtualDisplay() {
        releaseVirtualDisplay()
        updateScreenMetrics()

        try {
            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
            virtualDisplay = mediaProjection?.createVirtualDisplay(
                "OmniTransVirtualDisplay",
                screenWidth,
                screenHeight,
                screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader?.surface,
                null,
                handler
            )
        } catch (e: Exception) {
            e.printStackTrace()
            releaseVirtualDisplay()
        }
    }

    suspend fun captureScreen(): Bitmap? = withContext(Dispatchers.Default) {
        if (mediaProjection == null) {
            return@withContext null
        }

        try {
            setupVirtualDisplay()

            // Wait briefly for the first valid frame from the VirtualDisplay
            var bitmap: Bitmap? = null
            withTimeoutOrNull(1400) {
                for (i in 0 until 14) {
                    val reader = imageReader ?: break
                    val image = try {
                        reader.acquireLatestImage()
                    } catch (e: Exception) {
                        null
                    }

                    if (image != null) {
                        try {
                            bitmap = convertImageToBitmap(image)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        } finally {
                            try {
                                image.close()
                            } catch (_: Exception) {}
                        }
                        if (bitmap != null) {
                            break
                        }
                    }
                    delay(80)
                }
            }

            releaseVirtualDisplay()
            bitmap
        } catch (e: Exception) {
            e.printStackTrace()
            releaseVirtualDisplay()
            null
        }
    }

    private fun convertImageToBitmap(image: Image): Bitmap? {
        return try {
            val planes = image.planes
            if (planes.isEmpty()) return null

            val buffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val width = screenWidth + if (pixelStride > 0) rowPadding / pixelStride else 0
            val height = screenHeight

            val rawBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            buffer.rewind()
            rawBitmap.copyPixelsFromBuffer(buffer)

            if (rowPadding > 0 && width > screenWidth) {
                val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, screenWidth, screenHeight)
                rawBitmap.recycle()
                cropped
            } else {
                rawBitmap
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun releaseVirtualDisplay() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {}
    }

    fun stopProjection() {
        releaseVirtualDisplay()
        try {
            mediaProjection?.stop()
            mediaProjection = null
        } catch (_: Exception) {}
    }

    fun isProjectionActive(): Boolean = mediaProjection != null
}
