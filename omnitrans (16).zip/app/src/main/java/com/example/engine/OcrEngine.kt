package com.example.engine

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

data class OcrBlock(
    val text: String,
    val boundingBox: Rect?,
    val lines: List<String>
)

data class OcrResult(
    val fullText: String,
    val blocks: List<OcrBlock>,
    val blockCount: Int,
    val isSuccessful: Boolean,
    val errorMessage: String? = null
)

class OcrEngine {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognizeText(bitmap: Bitmap): OcrResult = withContext(Dispatchers.Default) {
        try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val visionText: Text = recognizer.process(image).await()

            val blocks = mutableListOf<OcrBlock>()
            val fullTextBuilder = StringBuilder()

            for (block in visionText.textBlocks) {
                val blockText = block.text.trim()
                if (blockText.isNotEmpty()) {
                    val lines = block.lines.map { it.text.trim() }.filter { it.isNotEmpty() }
                    blocks.add(
                        OcrBlock(
                            text = blockText,
                            boundingBox = block.boundingBox,
                            lines = lines
                        )
                    )
                    if (fullTextBuilder.isNotEmpty()) {
                        fullTextBuilder.append("\n\n")
                    }
                    fullTextBuilder.append(blockText)
                }
            }

            val resultText = fullTextBuilder.toString().trim()
            OcrResult(
                fullText = resultText,
                blocks = blocks,
                blockCount = blocks.size,
                isSuccessful = true
            )
        } catch (e: Exception) {
            OcrResult(
                fullText = "",
                blocks = emptyList(),
                blockCount = 0,
                isSuccessful = false,
                errorMessage = e.localizedMessage ?: "OCR recognition failed"
            )
        }
    }

    fun close() {
        try {
            recognizer.close()
        } catch (_: Exception) {}
    }
}
