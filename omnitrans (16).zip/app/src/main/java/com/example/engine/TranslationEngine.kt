package com.example.engine

import android.content.Context
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

sealed class ModelDownloadState {
    data object Idle : ModelDownloadState()
    data object Downloading : ModelDownloadState()
    data object Ready : ModelDownloadState()
    data class Error(val message: String) : ModelDownloadState()
}

class TranslationEngine(private val context: Context) {

    private val options by lazy {
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ENGLISH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    }

    private val translator: Translator by lazy { Translation.getClient(options) }
    private val modelManager by lazy { RemoteModelManager.getInstance() }
    private val arabicModel by lazy { TranslateRemoteModel.Builder(TranslateLanguage.ARABIC).build() }

    private val _downloadState = MutableStateFlow<ModelDownloadState>(ModelDownloadState.Idle)
    val downloadState: StateFlow<ModelDownloadState> = _downloadState.asStateFlow()

    // Rich offline Gaming and UI Dictionary for instant fallback
    private val offlineGameDictionary = mapOf(
        // Gaming Menu & UI
        "start game" to "بدء اللعبة",
        "start" to "ابدأ",
        "play" to "لعب",
        "continue" to "متابعة",
        "resume" to "استئناف",
        "pause" to "إيقاف مؤقت",
        "quit" to "خروج",
        "exit" to "خروج",
        "settings" to "الإعدادات",
        "options" to "الخيارات",
        "controls" to "أزرار التحكم",
        "sound" to "الصوت",
        "music" to "الموسيقى",
        "graphics" to "الرسوميات",
        "language" to "اللغة",
        "restart" to "إعادة تشغيل",
        "retry" to "إعادة المحاولة",
        "game over" to "انتهت اللعبة",
        "victory" to "انتصار!",
        "defeat" to "هزيمة",
        "winner" to "الفائز",
        "loser" to "الخاسر",
        "loading" to "جارِ التحميل...",
        "save" to "حفظ",
        "load" to "تحميل",
        "auto save" to "حفظ تلقائي",
        "main menu" to "القائمة الرئيسية",
        "back" to "رجوع",
        "confirm" to "تأكيد",
        "cancel" to "إلغاء",
        "accept" to "قبول",
        "decline" to "رفض",
        "skip" to "تخطي",
        "next" to "التالي",
        "previous" to "السابق",

        // Stats & Attributes
        "health" to "الصحة (HP)",
        "hp" to "نقاط الصحة",
        "mana" to "المانا (MP)",
        "mp" to "نقاط السحر",
        "stamina" to "التحمل / اللياقة",
        "energy" to "الطاقة",
        "attack" to "الهجوم",
        "atk" to "هجوم",
        "defense" to "الدفاع",
        "def" to "دفاع",
        "speed" to "السرعة",
        "agility" to "الرشاقة",
        "strength" to "القوة",
        "power" to "القدرة / القوة",
        "intelligence" to "الذكاء",
        "critical" to "ضربة حرجة",
        "critical damage" to "ضرر حرج",
        "damage" to "الضرر",
        "shield" to "الدرع",
        "armor" to "الدرع الواقي",
        "level" to "المستوى",
        "level up" to "ارتقاء في المستوى!",
        "exp" to "نقاط الخبرة",
        "experience" to "الخبرة",
        "score" to "النتيجة",
        "rank" to "الرتبة",

        // RPG, Inventory & Items
        "inventory" to "الحقيبة / المخزون",
        "items" to "العناصر",
        "equipment" to "العتاد والمعدات",
        "weapon" to "السلاح",
        "sword" to "سيف",
        "bow" to "قوس",
        "gun" to "سلاح ناري",
        "potion" to "جرعة علاجية",
        "health potion" to "جرعة صحة",
        "mana potion" to "جرعة مانا",
        "gold" to "ذهب",
        "coins" to "عملات معدنية",
        "gems" to "جواهر",
        "diamonds" to "ألماس",
        "shop" to "المتجر",
        "store" to "المتجر",
        "buy" to "شراء",
        "sell" to "بيع",
        "upgrade" to "ترقية",
        "craft" to "صناعة",
        "skills" to "المهارات",
        "skill tree" to "شجرة المهارات",
        "cooldown" to "فترة التهدئة",
        "quest" to "المهمة",
        "quests" to "المهام",
        "mission" to "المهمة",
        "reward" to "المكافأة",
        "rewards" to "المكافآت",
        "claim" to "استلام",
        "claim all" to "استلام الكل",
        "daily reward" to "مكافأة يومية",
        "map" to "الخريطة",
        "dungeon" to "السراديب / الكهف",
        "boss" to "زعيم المرحلة",
        "enemy" to "عدو",
        "target" to "الهدف",

        // Common General Dialogue & Instructions
        "press any key to start" to "اضغط على أي زر للبدء",
        "tap anywhere to continue" to "اضغط في أي مكان للمتابعة",
        "are you sure?" to "هل أنت متأكد؟",
        "no internet connection" to "لا يوجد اتصال بالإنترنت",
        "connecting" to "جارِ الاتصال...",
        "success" to "تمت العملية بنجاح",
        "failed" to "فشلت العملية",
        "error" to "خطأ",
        "warning" to "تحذير",
        "tip" to "نصيحة",
        "hint" to "تلميح"
    )

    suspend fun checkAndDownloadModel(wifiOnly: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        try {
            _downloadState.value = ModelDownloadState.Downloading
            val conditionsBuilder = DownloadConditions.Builder()
            if (wifiOnly) {
                conditionsBuilder.requireWifi()
            }
            val conditions = conditionsBuilder.build()

            translator.downloadModelIfNeeded(conditions).await()
            _downloadState.value = ModelDownloadState.Ready
            true
        } catch (e: Exception) {
            _downloadState.value = ModelDownloadState.Error(e.localizedMessage ?: "Failed to download model")
            false
        }
    }

    suspend fun isModelDownloaded(): Boolean = withContext(Dispatchers.IO) {
        try {
            val downloaded = modelManager.isModelDownloaded(arabicModel).await()
            if (downloaded) {
                _downloadState.value = ModelDownloadState.Ready
            }
            downloaded
        } catch (_: Exception) {
            false
        }
    }

    suspend fun translate(text: String): String = withContext(Dispatchers.Default) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return@withContext ""

        // 1. Try ML Kit Translate
        try {
            val result = translator.translate(trimmed).await()
            if (result.isNotBlank()) {
                return@withContext result
            }
        } catch (_: Exception) {
            // ML Kit model might not be downloaded yet or failed, proceed to fallback
        }

        // 2. Offline Fallback using Dictionary & Tokenizer
        translateOfflineFallback(trimmed)
    }

    private fun translateOfflineFallback(text: String): String {
        val lower = text.lowercase().trim()

        // Exact match
        offlineGameDictionary[lower]?.let { return it }

        // Line-by-line check
        val lines = text.split("\n")
        if (lines.size > 1) {
            return lines.joinToString("\n") { line ->
                val lineLower = line.lowercase().trim()
                offlineGameDictionary[lineLower] ?: translatePhraseWords(line)
            }
        }

        return translatePhraseWords(text)
    }

    private fun translatePhraseWords(phrase: String): String {
        var translated = phrase
        // Replace known phrases sorted by length descending so multi-word keys match first
        val sortedKeys = offlineGameDictionary.keys.sortedByDescending { it.length }
        for (key in sortedKeys) {
            val regex = Regex("(?i)\\b" + Regex.escape(key) + "\\b")
            if (regex.containsMatchIn(translated)) {
                val replacement = offlineGameDictionary[key] ?: key
                translated = regex.replace(translated, replacement)
            }
        }
        return translated
    }

    fun close() {
        try {
            translator.close()
        } catch (_: Exception) {}
    }
}
