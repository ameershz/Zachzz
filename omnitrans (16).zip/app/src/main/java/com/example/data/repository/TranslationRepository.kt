package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.TranslationDao
import com.example.data.model.AppSettings
import com.example.data.model.TranslationHistoryItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class TranslationRepository(
    private val translationDao: TranslationDao,
    context: Context
) {
    private val prefs: SharedPreferences = context.getSharedPreferences("omnitrans_prefs", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    val allHistory: Flow<List<TranslationHistoryItem>> = translationDao.getAllHistory()
    val favoriteHistory: Flow<List<TranslationHistoryItem>> = translationDao.getFavoriteHistory()
    val historyCount: Flow<Int> = translationDao.getCount()

    fun searchHistory(query: String): Flow<List<TranslationHistoryItem>> {
        return translationDao.searchHistory(query)
    }

    suspend fun saveTranslation(original: String, translated: String, sourceContext: String = "Screen Capture"): Long {
        val wordCount = original.trim().split("\\s+".toRegex()).size
        val item = TranslationHistoryItem(
            originalText = original.trim(),
            translatedText = translated.trim(),
            sourceLanguage = "en",
            targetLanguage = "ar",
            timestamp = System.currentTimeMillis(),
            sourceContext = sourceContext,
            isFavorite = false,
            wordCount = wordCount
        )
        return translationDao.insertItem(item)
    }

    suspend fun toggleFavorite(id: Long, currentStatus: Boolean) {
        translationDao.setFavorite(id, !currentStatus)
    }

    suspend fun deleteItem(id: Long) {
        translationDao.deleteById(id)
    }

    suspend fun clearHistory() {
        translationDao.clearAll()
    }

    private fun loadSettings(): AppSettings {
        return AppSettings(
            bubbleSizeDp = prefs.getInt("bubble_size", 56),
            bubbleOpacity = prefs.getFloat("bubble_opacity", 0.95f),
            overlayFontSizeSp = prefs.getInt("overlay_font_size", 16),
            autoDismissSeconds = prefs.getInt("auto_dismiss", 0),
            enableHaptics = prefs.getBoolean("enable_haptics", true),
            keepScreenAwake = prefs.getBoolean("keep_awake", true),
            highContrastMode = prefs.getBoolean("high_contrast", true),
            copyOnTranslate = prefs.getBoolean("copy_on_translate", false),
            useOfflineFallback = prefs.getBoolean("use_offline_fallback", true)
        )
    }

    fun updateSettings(newSettings: AppSettings) {
        prefs.edit()
            .putInt("bubble_size", newSettings.bubbleSizeDp)
            .putFloat("bubble_opacity", newSettings.bubbleOpacity)
            .putInt("overlay_font_size", newSettings.overlayFontSizeSp)
            .putInt("auto_dismiss", newSettings.autoDismissSeconds)
            .putBoolean("enable_haptics", newSettings.enableHaptics)
            .putBoolean("keep_awake", newSettings.keepScreenAwake)
            .putBoolean("high_contrast", newSettings.highContrastMode)
            .putBoolean("copy_on_translate", newSettings.copyOnTranslate)
            .putBoolean("use_offline_fallback", newSettings.useOfflineFallback)
            .apply()
        _settings.value = newSettings
    }
}
