package com.example.data.model

data class AppSettings(
    val bubbleSizeDp: Int = 56,
    val bubbleOpacity: Float = 0.95f,
    val overlayFontSizeSp: Int = 16,
    val autoDismissSeconds: Int = 0, // 0 means persistent until closed
    val enableHaptics: Boolean = true,
    val keepScreenAwake: Boolean = true,
    val highContrastMode: Boolean = true,
    val copyOnTranslate: Boolean = false,
    val useOfflineFallback: Boolean = true
)
