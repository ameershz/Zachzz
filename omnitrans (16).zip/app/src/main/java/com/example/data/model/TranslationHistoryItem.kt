package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "translation_history")
data class TranslationHistoryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val originalText: String,
    val translatedText: String,
    val sourceLanguage: String = "en",
    val targetLanguage: String = "ar",
    val timestamp: Long = System.currentTimeMillis(),
    val sourceContext: String = "Screen Capture",
    val isFavorite: Boolean = false,
    val wordCount: Int = 0
)
