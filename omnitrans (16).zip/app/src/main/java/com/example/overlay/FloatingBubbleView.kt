package com.example.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.abs

@SuppressLint("ViewConstructor")
class FloatingBubbleView(
    context: Context,
    private val windowManager: WindowManager,
    val layoutParams: WindowManager.LayoutParams,
    private val onBubbleClick: () -> Unit,
    private val onBubbleLongClick: () -> Unit
) : View(context) {

    enum class State {
        IDLE,
        CAPTURING,
        TRANSLATING,
        ERROR
    }

    var currentState: State = State.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    // Drawing Paints
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#101524")
    }

    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.parseColor("#00E5FF")
    }

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 12f
        color = Color.parseColor("#4400E5FF")
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 34f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val subTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676")
        textSize = 22f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val spinnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#00E676")
    }

    private var rotationAngle = 0f
    private val rotationAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 1000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            rotationAngle = it.animatedValue as Float
            invalidate()
        }
    }

    // Touch & Drag Handling
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private val touchSlop = 14

    init {
        rotationAnimator.start()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (width.coerceAtMost(height) / 2f) - 10f

        // 1. Draw outer glow ring
        canvas.drawCircle(cx, cy, radius + 2f, glowPaint)

        // 2. Draw background by state
        when (currentState) {
            State.IDLE -> bgPaint.color = Color.parseColor("#0D111A")
            State.CAPTURING -> bgPaint.color = Color.parseColor("#15233D")
            State.TRANSLATING -> bgPaint.color = Color.parseColor("#1B2A1E")
            State.ERROR -> bgPaint.color = Color.parseColor("#331111")
        }
        canvas.drawCircle(cx, cy, radius, bgPaint)

        // 3. Draw dynamic border
        borderPaint.color = when (currentState) {
            State.IDLE -> Color.parseColor("#00E5FF")
            State.CAPTURING -> Color.parseColor("#B388FF")
            State.TRANSLATING -> Color.parseColor("#00E676")
            State.ERROR -> Color.parseColor("#FF5252")
        }
        canvas.drawCircle(cx, cy, radius, borderPaint)

        // 4. Draw content / animation based on state
        if (currentState == State.CAPTURING || currentState == State.TRANSLATING) {
            val rect = RectF(cx - radius + 8f, cy - radius + 8f, cx + radius - 8f, cy + radius - 8f)
            spinnerPaint.color = if (currentState == State.CAPTURING) Color.parseColor("#B388FF") else Color.parseColor("#00E676")
            canvas.drawArc(rect, rotationAngle, 100f, false, spinnerPaint)

            val statusText = if (currentState == State.CAPTURING) "SCAN" else "ترجمة"
            val textY = cy - ((textPaint.descent() + textPaint.ascent()) / 2)
            canvas.drawText(statusText, cx, textY, textPaint.apply { textSize = 26f })
        } else {
            val topTextY = cy - 6f
            val bottomTextY = cy + 24f

            textPaint.textSize = 32f
            textPaint.color = Color.WHITE
            canvas.drawText("EN", cx, topTextY, textPaint)

            subTextPaint.color = Color.parseColor("#00E5FF")
            canvas.drawText("AR ع", cx, bottomTextY, subTextPaint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = layoutParams.x
                initialY = layoutParams.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                isDragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (event.rawX - initialTouchX).toInt()
                val dy = (event.rawY - initialTouchY).toInt()

                if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                    isDragging = true
                }

                if (isDragging) {
                    layoutParams.x = initialX + dx
                    layoutParams.y = initialY + dy
                    try {
                        windowManager.updateViewLayout(this, layoutParams)
                    } catch (_: Exception) {}
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!isDragging) {
                    triggerHaptic()
                    onBubbleClick()
                } else {
                    snapToEdge()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun snapToEdge() {
        val displayMetrics = context.resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val targetX = if (layoutParams.x + width / 2 < screenWidth / 2) 20 else screenWidth - width - 20

        val animator = ValueAnimator.ofInt(layoutParams.x, targetX)
        animator.duration = 200
        animator.addUpdateListener {
            layoutParams.x = it.animatedValue as Int
            try {
                windowManager.updateViewLayout(this, layoutParams)
            } catch (_: Exception) {}
        }
        animator.start()
    }

    private fun triggerHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(35)
            }
        } catch (_: Exception) {}
    }

    fun destroy() {
        rotationAnimator.cancel()
    }
}
