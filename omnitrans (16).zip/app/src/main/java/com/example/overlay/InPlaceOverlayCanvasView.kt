package com.example.overlay

import android.content.Context
import android.view.WindowManager

/**
 * Typealias / Subclass wrapper linking InPlaceOverlayCanvasView directly to the unified OverlayView.
 */
typealias InPlaceOverlayCanvasView = OverlayView
