package com.example.overlay

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class OverlayResultsWindow(
    private val context: Context,
    private val windowManager: WindowManager,
    private val onDismiss: () -> Unit,
    private val onSaveHistory: (String, String) -> Unit
) {
    private var rootView: View? = null
    private var layoutParams: WindowManager.LayoutParams? = null

    private var currentEnglishText: String = ""
    private var currentArabicText: String = ""
    private var currentFontSizeSp: Float = 15f

    private var arabicTextView: TextView? = null
    private var englishTextView: TextView? = null

    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    fun show(english: String, arabic: String) {
        currentEnglishText = english.ifBlank { "(No English text detected on screen)" }
        currentArabicText = arabic.ifBlank { "(لم يتم العثور على نص للترجمة)" }

        if (rootView != null) {
            updateContent(currentEnglishText, currentArabicText)
            return
        }

        val displayMetrics = context.resources.displayMetrics
        val windowWidth = (displayMetrics.widthPixels * 0.90f).toInt().coerceAtMost(dpToPx(480))

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        layoutParams = WindowManager.LayoutParams(
            windowWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP
            y = dpToPx(80)
        }

        // Build UI container
        val cardLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(16), dpToPx(12), dpToPx(16), dpToPx(16))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E60D121F")) // Dark translucent glass
                cornerRadius = dpToPx(18).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#4400E5FF"))
            }
            elevation = dpToPx(12).toFloat()
        }

        // Header (Draggable)
        val headerLayout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dpToPx(10))
        }

        val dragHandle = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(dpToPx(36), dpToPx(4)).apply {
                gravity = Gravity.CENTER
                setMargins(0, 0, dpToPx(10), 0)
            }
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#66FFFFFF"))
                cornerRadius = dpToPx(2).toFloat()
            }
        }

        val titleText = TextView(context).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            text = "OmniTrans • EN ➜ AR"
            setTextColor(Color.parseColor("#00E5FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
        }

        // Font Size Zoom Buttons
        val zoomMinusBtn = createSmallButton("A-") {
            if (currentFontSizeSp > 12f) {
                currentFontSizeSp -= 2f
                applyFontSize()
            }
        }

        val zoomPlusBtn = createSmallButton("A+") {
            if (currentFontSizeSp < 24f) {
                currentFontSizeSp += 2f
                applyFontSize()
            }
        }

        val closeBtn = TextView(context).apply {
            text = "✕"
            setTextColor(Color.parseColor("#FF5252"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            setTypeface(Typeface.DEFAULT_BOLD)
            setPadding(dpToPx(10), dpToPx(4), dpToPx(8), dpToPx(4))
            setOnClickListener { dismiss() }
        }

        headerLayout.addView(dragHandle)
        headerLayout.addView(titleText)
        headerLayout.addView(zoomMinusBtn)
        headerLayout.addView(zoomPlusBtn)
        headerLayout.addView(closeBtn)

        // Setup Drag on Header
        var initialX = 0
        var initialY = 0
        var touchStartX = 0f
        var touchStartY = 0f
        headerLayout.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams?.x ?: 0
                    initialY = layoutParams?.y ?: 0
                    touchStartX = event.rawX
                    touchStartY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    layoutParams?.let { lp ->
                        lp.x = initialX + (event.rawX - touchStartX).toInt()
                        lp.y = initialY + (event.rawY - touchStartY).toInt()
                        rootView?.let { rv -> windowManager.updateViewLayout(rv, lp) }
                    }
                    true
                }
                else -> false
            }
        }

        // Scrollable Results Box
        val scrollView = ScrollView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(240)
            )
            isVerticalScrollBarEnabled = true
        }

        val contentLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }

        // Arabic Section (Main)
        val arabicCard = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2600E676"))
                cornerRadius = dpToPx(10).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#5500E676"))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, dpToPx(10))
            }
        }

        val arabicHeader = TextView(context).apply {
            text = "الترجمة العربية"
            setTextColor(Color.parseColor("#00E676"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.END
        }

        arabicTextView = TextView(context).apply {
            text = currentArabicText
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, currentFontSizeSp + 1f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.END
            setLineSpacing(dpToPx(3).toFloat(), 1.15f)
            setTextIsSelectable(true)
        }

        arabicCard.addView(arabicHeader)
        arabicCard.addView(arabicTextView)

        // English Section
        val englishCard = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(12), dpToPx(10), dpToPx(12), dpToPx(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1F1E293B"))
                cornerRadius = dpToPx(10).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#33FFFFFF"))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val englishHeader = TextView(context).apply {
            text = "Detected English"
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
        }

        englishTextView = TextView(context).apply {
            text = currentEnglishText
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, currentFontSizeSp - 1f)
            setLineSpacing(dpToPx(2).toFloat(), 1.1f)
            setTextIsSelectable(true)
        }

        englishCard.addView(englishHeader)
        englishCard.addView(englishTextView)

        contentLayout.addView(arabicCard)
        contentLayout.addView(englishCard)
        scrollView.addView(contentLayout)

        // Bottom Action Bar
        val bottomActions = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, dpToPx(10), 0, 0)
        }

        val copyArabicBtn = createActionButton("نسخ الترجمة", "#00E676") {
            copyToClipboard("Arabic Translation", currentArabicText)
            Toast.makeText(context, "تم نسخ النص العربي", Toast.LENGTH_SHORT).show()
        }

        val copyEnglishBtn = createActionButton("Copy EN", "#94A3B8") {
            copyToClipboard("English Text", currentEnglishText)
            Toast.makeText(context, "Copied English text", Toast.LENGTH_SHORT).show()
        }

        bottomActions.addView(copyEnglishBtn)
        bottomActions.addView(copyArabicBtn)

        cardLayout.addView(headerLayout)
        cardLayout.addView(scrollView)
        cardLayout.addView(bottomActions)

        rootView = cardLayout
        try {
            windowManager.addView(rootView, layoutParams)
        } catch (_: Exception) {}
    }

    private fun updateContent(english: String, arabic: String) {
        currentEnglishText = english
        currentArabicText = arabic
        englishTextView?.text = english
        arabicTextView?.text = arabic
    }

    private fun applyFontSize() {
        arabicTextView?.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentFontSizeSp + 1f)
        englishTextView?.setTextSize(TypedValue.COMPLEX_UNIT_SP, currentFontSizeSp - 1f)
    }

    private fun createSmallButton(label: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            setTextColor(Color.parseColor("#00E5FF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2200E5FF"))
                cornerRadius = dpToPx(6).toFloat()
            }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, dpToPx(6), 0)
            }
            layoutParams = params
            setOnClickListener { onClick() }
        }
    }

    private fun createActionButton(label: String, colorHex: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            setTextColor(Color.parseColor(colorHex))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dpToPx(12), dpToPx(6), dpToPx(12), dpToPx(6))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#22" + colorHex.removePrefix("#")))
                cornerRadius = dpToPx(8).toFloat()
                setStroke(dpToPx(1), Color.parseColor("#44" + colorHex.removePrefix("#")))
            }
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dpToPx(8), 0, 0, 0)
            }
            layoutParams = params
            setOnClickListener { onClick() }
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * context.resources.displayMetrics.density).toInt()
    }

    fun dismiss() {
        if (rootView != null) {
            try {
                windowManager.removeView(rootView)
            } catch (_: Exception) {}
            rootView = null
            onDismiss()
        }
    }

    fun isShowing(): Boolean = rootView != null
}
