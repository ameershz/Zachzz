package com.example.overlay

import android.graphics.Rect

data class InPlaceTranslatedBlock(
    val id: Int,
    val originalText: String,
    val translatedText: String,
    val boundingBox: Rect,
    var isShowingOriginal: Boolean = false
)
