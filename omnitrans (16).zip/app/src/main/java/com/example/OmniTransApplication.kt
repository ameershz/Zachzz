package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.TranslationRepository
import com.example.engine.OcrEngine
import com.example.engine.ScreenCaptureManager
import com.example.engine.TranslationEngine

class OmniTransApplication : Application() {

    val database by lazy { AppDatabase.getDatabase(this) }
    val translationRepository by lazy { TranslationRepository(database.translationDao(), this) }
    val ocrEngine by lazy { OcrEngine() }
    val translationEngine by lazy { TranslationEngine(this) }
    val screenCaptureManager by lazy { ScreenCaptureManager(this) }

    override fun onCreate() {
        super.onCreate()
    }

    override fun onTerminate() {
        super.onTerminate()
        ocrEngine.close()
        translationEngine.close()
        screenCaptureManager.stopProjection()
    }
}
