package com.example.data.repository

import com.example.data.local.dao.BikeSettingsDao
import com.example.data.local.dao.OilChangeDao
import com.example.data.local.dao.ShiftDao
import com.example.data.local.dao.TuningNoteDao
import com.example.data.local.entity.BikeSettingsEntity
import com.example.data.local.entity.OilChangeEntity
import com.example.data.local.entity.ShiftEntity
import com.example.data.local.entity.TuningNoteEntity
import kotlinx.coroutines.flow.Flow

class CaptainRepository(
    private val shiftDao: ShiftDao,
    private val oilChangeDao: OilChangeDao,
    private val tuningNoteDao: TuningNoteDao,
    private val bikeSettingsDao: BikeSettingsDao
) {
    // Shifts
    val allShifts: Flow<List<ShiftEntity>> = shiftDao.getAllShifts()

    suspend fun insertShift(shift: ShiftEntity): Long = shiftDao.insertShift(shift)

    suspend fun updateShift(shift: ShiftEntity) = shiftDao.updateShift(shift)

    suspend fun deleteShift(shift: ShiftEntity) = shiftDao.deleteShift(shift)

    suspend fun deleteShiftById(id: Long) = shiftDao.deleteShiftById(id)

    // Oil Changes
    val allOilChanges: Flow<List<OilChangeEntity>> = oilChangeDao.getAllOilChanges()

    val latestOilChange: Flow<OilChangeEntity?> = oilChangeDao.getLatestOilChange()

    suspend fun insertOilChange(oilChange: OilChangeEntity): Long {
        val id = oilChangeDao.insertOilChange(oilChange)
        // Also update bike settings last oil odometer and current odometer if higher
        val currentSetting = bikeSettingsDao.getSettings()
        // Odometer is updated to at least the change odometer
        bikeSettingsDao.updateCurrentOdometer(oilChange.odometerKm)
        return id
    }

    suspend fun deleteOilChange(oilChange: OilChangeEntity) = oilChangeDao.deleteOilChange(oilChange)

    // Tuning Notes
    val allTuningNotes: Flow<List<TuningNoteEntity>> = tuningNoteDao.getAllTuningNotes()

    fun getTuningNotesByCategory(category: String): Flow<List<TuningNoteEntity>> =
        tuningNoteDao.getNotesByCategory(category)

    suspend fun insertTuningNote(note: TuningNoteEntity): Long = tuningNoteDao.insertTuningNote(note)

    suspend fun updateTuningNote(note: TuningNoteEntity) = tuningNoteDao.updateTuningNote(note)

    suspend fun deleteTuningNote(note: TuningNoteEntity) = tuningNoteDao.deleteTuningNote(note)

    // Bike Settings
    val bikeSettings: Flow<BikeSettingsEntity?> = bikeSettingsDao.getSettings()

    suspend fun updateOdometer(newKm: Int) {
        bikeSettingsDao.updateCurrentOdometer(newKm)
    }

    suspend fun updateShiftState(isActive: Boolean, startTime: Long) {
        bikeSettingsDao.updateShiftState(isActive, startTime)
    }

    suspend fun saveBikeSettings(settings: BikeSettingsEntity) {
        bikeSettingsDao.insertOrUpdate(settings)
    }
}
