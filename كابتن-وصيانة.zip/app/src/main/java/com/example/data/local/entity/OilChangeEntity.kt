package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "oil_changes")
data class OilChangeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateMillis: Long = System.currentTimeMillis(),
    val odometerKm: Int = 0,
    val nextDueKm: Int = 0,
    val oilBrand: String = "Bajaj DTS-i 20W50",
    val filterChanged: Boolean = true,
    val cost: Double = 0.0,
    val notes: String = ""
)
