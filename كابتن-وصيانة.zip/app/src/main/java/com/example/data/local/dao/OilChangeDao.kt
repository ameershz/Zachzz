package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.OilChangeEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OilChangeDao {
    @Query("SELECT * FROM oil_changes ORDER BY dateMillis DESC")
    fun getAllOilChanges(): Flow<List<OilChangeEntity>>

    @Query("SELECT * FROM oil_changes ORDER BY odometerKm DESC LIMIT 1")
    fun getLatestOilChange(): Flow<OilChangeEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOilChange(oilChange: OilChangeEntity): Long

    @Delete
    suspend fun deleteOilChange(oilChange: OilChangeEntity)

    @Query("DELETE FROM oil_changes WHERE id = :id")
    suspend fun deleteOilChangeById(id: Long)
}
