package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.BikeSettingsEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BikeSettingsDao {
    @Query("SELECT * FROM bike_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<BikeSettingsEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(settings: BikeSettingsEntity)

    @Query("UPDATE bike_settings SET currentOdometerKm = :newOdo WHERE id = 1")
    suspend fun updateCurrentOdometer(newOdo: Int)

    @Query("UPDATE bike_settings SET eveningShiftActive = :isActive, shiftStartTimestamp = :startTime WHERE id = 1")
    suspend fun updateShiftState(isActive: Boolean, startTime: Long)
}
