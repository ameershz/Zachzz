package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.BikeSettingsDao
import com.example.data.local.dao.OilChangeDao
import com.example.data.local.dao.ShiftDao
import com.example.data.local.dao.TuningNoteDao
import com.example.data.local.entity.BikeSettingsEntity
import com.example.data.local.entity.OilChangeEntity
import com.example.data.local.entity.ShiftEntity
import com.example.data.local.entity.TuningNoteEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ShiftEntity::class,
        OilChangeEntity::class,
        TuningNoteEntity::class,
        BikeSettingsEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun shiftDao(): ShiftDao
    abstract fun oilChangeDao(): OilChangeDao
    abstract fun tuningNoteDao(): TuningNoteDao
    abstract fun bikeSettingsDao(): BikeSettingsDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "captain_maintenance_db"
                )
                    .addCallback(DatabaseCallback())
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        prepopulateData(database)
                    }
                }
            }

            private suspend fun prepopulateData(database: AppDatabase) {
                // Initialize default bike settings
                val initialOdo = 14850
                database.bikeSettingsDao().insertOrUpdate(
                    BikeSettingsEntity(
                        id = 1,
                        currentOdometerKm = initialOdo,
                        oilIntervalKm = 1200,
                        lastOilOdometerKm = 14000,
                        eveningShiftActive = false,
                        shiftStartTimestamp = 0L,
                        shiftGoalOrders = 16,
                        shiftGoalEarnings = 380.0
                    )
                )

                // Prepopulate initial oil change
                val now = System.currentTimeMillis()
                val oneDay = 86_400_000L
                database.oilChangeDao().insertOilChange(
                    OilChangeEntity(
                        dateMillis = now - (14 * oneDay),
                        odometerKm = 14000,
                        nextDueKm = 15200,
                        oilBrand = "Bajaj DTS-i 20W50 10,000",
                        filterChanged = true,
                        cost = 140.0,
                        notes = "تغيير زيت دوري مع الفلتر الأصلي باجاج بوكسر 150"
                    )
                )

                // Prepopulate default tuning notes
                val defaultNotes = listOf(
                    TuningNoteEntity(
                        dateMillis = now - (5 * oneDay),
                        category = "CARBURETOR",
                        title = "وزنية إبرة الكابريتر (Needle Jet)",
                        settingValue = "السنة الثالثة (الوسط)",
                        notes = "الخانة الوسطى (Notch 3) تعطي أفضل توازن بين توفير البنزين واستجابة السحب مع حمولة صندوق الدليفري والسرعة على الطرق الدائرية.",
                        bikeOdometerKm = 14600
                    ),
                    TuningNoteEntity(
                        dateMillis = now - (7 * oneDay),
                        category = "AIR_SCREW",
                        title = "إعداد برغي الهواء والسلانسيه (Idle / Air Screw)",
                        settingValue = "2.25 لفة للخارج (1400 RPM)",
                        notes = "ربط برغي الهواء حتى القاع برفق ثم فكه لفتين وربع. سرعة السلانسيه 1400 د/د لضمان عدم توقف المحرك أثناء التوقف في إشارات المساء وتشغيل كشاف الدراجة.",
                        bikeOdometerKm = 14450
                    ),
                    TuningNoteEntity(
                        dateMillis = now - (10 * oneDay),
                        category = "CLUTCH",
                        title = "معايرة خلوص مقبض الكلج (Clutch Free Play)",
                        settingValue = "12 ملم خلوص حر",
                        notes = "معايرة بكرة السلك لتوفير 10-15 ملم حرية حركة في يد الدبرياج قبل بداية الفصل. يحمي أسطوانات الكلتش من التفويت ويسهل فصل التعشيق (المور) بالزحام.",
                        bikeOdometerKm = 14200
                    ),
                    TuningNoteEntity(
                        dateMillis = now - (12 * oneDay),
                        category = "GENERAL_SPECS",
                        title = "معايرة ضغط هواء الإطارات للبوكسر",
                        settingValue = "أمامي 25 PSI / خلفي 32 PSI",
                        notes = "الضغط الخلفي 32 رطل لكل بوصة مربعة مناسب لتحمل وزن صندوق التوصيل وحقيبة الطلبات دون تأثر استهلاك البنزين وتماسك الدراجة.",
                        bikeOdometerKm = 14100
                    )
                )
                database.tuningNoteDao().insertAll(defaultNotes)

                // Prepopulate some recent shifts for realistic first launch experience
                database.shiftDao().insertShift(
                    ShiftEntity(
                        dateMillis = now - (1 * oneDay),
                        startTime = "15:00",
                        endTime = "00:00",
                        ordersCount = 18,
                        grossEarnings = 420.0,
                        tips = 65.0,
                        fuelExpense = 70.0,
                        otherExpenses = 15.0,
                        netEarnings = 400.0,
                        notes = "شفت ممتاز في وسط البلد والمهندسين، حركة الطلبات كانت سريعة"
                    )
                )
                database.shiftDao().insertShift(
                    ShiftEntity(
                        dateMillis = now - (2 * oneDay),
                        startTime = "15:30",
                        endTime = "23:45",
                        ordersCount = 15,
                        grossEarnings = 360.0,
                        tips = 45.0,
                        fuelExpense = 60.0,
                        otherExpenses = 10.0,
                        netEarnings = 335.0,
                        notes = "طلبات عشاء متتالية من 8 إلى 11 مساءً"
                    )
                )
            }
        }
    }
}
