package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "shifts")
data class ShiftEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateMillis: Long = System.currentTimeMillis(),
    val startTime: String = "15:00",
    val endTime: String = "00:00",
    val ordersCount: Int = 0,
    val grossEarnings: Double = 0.0,
    val tips: Double = 0.0,
    val fuelExpense: Double = 0.0,
    val otherExpenses: Double = 0.0,
    val netEarnings: Double = 0.0,
    val notes: String = ""
)
