package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tuning_notes")
data class TuningNoteEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dateMillis: Long = System.currentTimeMillis(),
    val category: String = "CARBURETOR", // CARBURETOR, AIR_SCREW, CLUTCH, GENERAL_SPECS
    val title: String = "",
    val settingValue: String = "",
    val notes: String = "",
    val bikeOdometerKm: Int = 0
)
