package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bike_settings")
data class BikeSettingsEntity(
    @PrimaryKey
    val id: Int = 1,
    val currentOdometerKm: Int = 14500,
    val oilIntervalKm: Int = 1200, // Recommended for Bajaj Boxer 150
    val lastOilOdometerKm: Int = 13800,
    val eveningShiftActive: Boolean = false,
    val shiftStartTimestamp: Long = 0L,
    val shiftGoalOrders: Int = 15,
    val shiftGoalEarnings: Double = 350.0
)
