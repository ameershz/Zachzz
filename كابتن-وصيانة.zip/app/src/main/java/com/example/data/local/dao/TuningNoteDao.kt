package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.TuningNoteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TuningNoteDao {
    @Query("SELECT * FROM tuning_notes ORDER BY dateMillis DESC")
    fun getAllTuningNotes(): Flow<List<TuningNoteEntity>>

    @Query("SELECT * FROM tuning_notes WHERE category = :category ORDER BY dateMillis DESC")
    fun getNotesByCategory(category: String): Flow<List<TuningNoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTuningNote(note: TuningNoteEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(notes: List<TuningNoteEntity>)

    @Update
    suspend fun updateTuningNote(note: TuningNoteEntity)

    @Delete
    suspend fun deleteTuningNote(note: TuningNoteEntity)

    @Query("DELETE FROM tuning_notes WHERE id = :id")
    suspend fun deleteTuningNoteById(id: Long)
}
