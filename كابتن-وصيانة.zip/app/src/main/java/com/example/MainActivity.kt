package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainAppScreen
import com.example.ui.theme.CaptainMaintenanceTheme
import com.example.ui.viewmodel.CaptainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CaptainMaintenanceTheme(darkTheme = true) {
                val viewModel: CaptainViewModel = viewModel(
                    factory = CaptainViewModel.provideFactory(application)
                )
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}
