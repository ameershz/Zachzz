package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.BuildCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.OilChangeEntity
import com.example.data.local.entity.TuningNoteEntity
import com.example.ui.screens.components.BoxerQuickSpecCard
import com.example.ui.screens.components.DialogAddOilChange
import com.example.ui.screens.components.DialogAddTuningNote
import com.example.ui.screens.components.DialogUpdateOdometer
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.BoxerCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.CaptainViewModel
import com.example.ui.viewmodel.OilAlertStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaintenanceScreen(
    viewModel: CaptainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Oil Log, 1 = Mechanical Tuning Notes
    val oilStatus by viewModel.oilStatus.collectAsState()
    val allOilChanges by viewModel.allOilChanges.collectAsState()
    val allTuningNotes by viewModel.allTuningNotes.collectAsState()

    var showAddOilDialog by remember { mutableStateOf(false) }
    var showAddTuningDialog by remember { mutableStateOf(false) }
    var showUpdateOdoDialog by remember { mutableStateOf(false) }

    var oilToDelete by remember { mutableStateOf<OilChangeEntity?>(null) }
    var tuningToDelete by remember { mutableStateOf<TuningNoteEntity?>(null) }
    var tuningFilterCategory by remember { mutableStateOf("ALL") }

    Scaffold(
        modifier = modifier.testTag("maintenance_screen"),
        containerColor = DarkBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (selectedTab == 0) showAddOilDialog = true
                    else showAddTuningDialog = true
                },
                containerColor = if (selectedTab == 0) BoxerAmber else BoxerCyan,
                contentColor = DarkBackground,
                modifier = Modifier.testTag("fab_add_maintenance")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (selectedTab == 0) "تغيير زيت" else "ملاحظة ضبط",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Header
            Column(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(BoxerAmber, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "باجاج بوكسر 150",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = DarkBackground
                        )
                    }
                    Text(
                        text = "صيانة الدراجة والميكانيكا",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkTextPrimary
                    )
                }
                Text(
                    text = "سجل تغيير الزيت وضبط الكابريتر وبرغي الهواء والكلج",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary
                )
            }

            // Top Tab Row
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = DarkTextPrimary,
                indicator = { tabPositions ->
                    if (selectedTab < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = if (selectedTab == 0) BoxerAmber else BoxerCyan,
                            height = 3.dp
                        )
                    }
                },
                divider = { HorizontalDivider(color = DarkOutline) }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.Opacity,
                                contentDescription = null,
                                tint = if (selectedTab == 0) BoxerAmber else DarkTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "سجل تغيير الزيت",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 0) BoxerAmber else DarkTextSecondary
                            )
                        }
                    },
                    modifier = Modifier.testTag("tab_oil_log")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.BuildCircle,
                                contentDescription = null,
                                tint = if (selectedTab == 1) BoxerCyan else DarkTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "الضبط الميكانيكي",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 1) BoxerCyan else DarkTextSecondary
                            )
                        }
                    },
                    modifier = Modifier.testTag("tab_tuning_notes")
                )
            }

            // Tab Content
            when (selectedTab) {
                0 -> OilLogTabContent(
                    oilStatus = oilStatus,
                    oilChanges = allOilChanges,
                    onAddOilClick = { showAddOilDialog = true },
                    onUpdateOdoClick = { showUpdateOdoDialog = true },
                    onDeleteOil = { oilToDelete = it }
                )
                1 -> TuningNotesTabContent(
                    allNotes = allTuningNotes,
                    activeFilter = tuningFilterCategory,
                    onFilterChange = { tuningFilterCategory = it },
                    onAddNoteClick = { showAddTuningDialog = true },
                    onDeleteNote = { tuningToDelete = it }
                )
            }
        }
    }

    // Dialogs
    if (showAddOilDialog) {
        DialogAddOilChange(
            initialOdometer = oilStatus.currentOdo,
            onDismiss = { showAddOilDialog = false },
            onSave = { odo, brand, filter, cost, notes, interval ->
                viewModel.addOilChange(
                    odometerKm = odo,
                    oilBrand = brand,
                    filterChanged = filter,
                    cost = cost,
                    notes = notes,
                    customIntervalKm = interval
                )
                showAddOilDialog = false
            }
        )
    }

    if (showAddTuningDialog) {
        DialogAddTuningNote(
            currentBikeOdometer = oilStatus.currentOdo,
            onDismiss = { showAddTuningDialog = false },
            onSave = { category, title, settingValue, notes, odo ->
                viewModel.addTuningNote(
                    category = category,
                    title = title,
                    settingValue = settingValue,
                    notes = notes,
                    bikeOdo = odo
                )
                showAddTuningDialog = false
            }
        )
    }

    if (showUpdateOdoDialog) {
        DialogUpdateOdometer(
            currentOdometer = oilStatus.currentOdo,
            onDismiss = { showUpdateOdoDialog = false },
            onConfirm = { newKm ->
                viewModel.updateCurrentOdometer(newKm)
                showUpdateOdoDialog = false
            }
        )
    }

    // Delete Oil Dialog
    oilToDelete?.let { oil ->
        AlertDialog(
            onDismissRequest = { oilToDelete = null },
            title = { Text("حذف سجل الزيت", color = DarkTextPrimary) },
            text = { Text("هل تريد حذف سجل تغيير الزيت عند عداد ${oil.odometerKm} كم؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteOilChange(oil)
                        oilToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { oilToDelete = null }) { Text("إلغاء") }
            },
            containerColor = DarkSurface
        )
    }

    // Delete Tuning Note Dialog
    tuningToDelete?.let { note ->
        AlertDialog(
            onDismissRequest = { tuningToDelete = null },
            title = { Text("حذف ملاحظة الضبط", color = DarkTextPrimary) },
            text = { Text("هل تريد حذف الملاحظة الميكانيكية '${note.title}'؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTuningNote(note)
                        tuningToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { tuningToDelete = null }) { Text("إلغاء") }
            },
            containerColor = DarkSurface
        )
    }
}

@Composable
private fun OilLogTabContent(
    oilStatus: com.example.ui.viewmodel.OilStatus,
    oilChanges: List<OilChangeEntity>,
    onAddOilClick: () -> Unit,
    onUpdateOdoClick: () -> Unit,
    onDeleteOil: (OilChangeEntity) -> Unit
) {
    val alertColor = when (oilStatus.alertStatus) {
        OilAlertStatus.SAFE -> ProfitGreen
        OilAlertStatus.WARNING -> WarningAmber
        OilAlertStatus.OVERDUE -> ExpenseRed
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, alertColor.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "حالة زيت محرك البوكسر الحالية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkTextPrimary
                            )
                            Text(
                                text = "سعة التغيير: 1.0 لتر (1000 مل) 20W50 4T",
                                fontSize = 12.sp,
                                color = BoxerCyan
                            )
                        }

                        IconButton(onClick = onUpdateOdoClick) {
                            Icon(
                                Icons.Default.Speed,
                                contentDescription = "تحديث العداد",
                                tint = BoxerAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "المسافة حتى التغيير القادم:",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )
                            Text(
                                text = if (oilStatus.remainingKm >= 0) {
                                    "${oilStatus.remainingKm} كم متبقي"
                                } else {
                                    "تجاوز الموعد بـ ${-oilStatus.remainingKm} كم!"
                                },
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = alertColor
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "العداد الحالي: ${oilStatus.currentOdo} كم",
                                fontSize = 12.sp,
                                color = DarkTextSecondary
                            )
                            Text(
                                text = "التغيير القادم: ${oilStatus.nextDueOdo} كم",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = BoxerAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { oilStatus.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = alertColor,
                        trackColor = DarkSurfaceHighlight
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onAddOilClick,
                            colors = ButtonDefaults.buttonColors(containerColor = BoxerAmber, contentColor = DarkBackground),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تسجيل تغيير جديد", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onUpdateOdoClick,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = BoxerCyan)
                        ) {
                            Text("تحديث العداد")
                        }
                    }
                }
            }
        }

        // Quick spec card
        item {
            BoxerQuickSpecCard()
        }

        // Oil Changes History List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سجل غيارات الزيت السابقة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DarkTextPrimary
                )
                Text(
                    text = "${oilChanges.size} غيار",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary
                )
            }
        }

        if (oilChanges.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Opacity, contentDescription = null, tint = BoxerAmber, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("لا يوجد سجلات غيار زيت سابقة", color = DarkTextPrimary, fontWeight = FontWeight.Bold)
                        Text("سجل أول غيار زيت لدراجتك لتفعيل التنبيهات", fontSize = 12.sp, color = DarkTextSecondary)
                    }
                }
            }
        } else {
            items(oilChanges, key = { it.id }) { oil ->
                OilChangeItemCard(
                    oil = oil,
                    onDelete = { onDeleteOil(oil) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}

@Composable
private fun OilChangeItemCard(
    oil: OilChangeEntity,
    onDelete: () -> Unit
) {
    val dateFormatter = remember { SimpleDateFormat("yyyy/MM/dd", Locale.US) }
    val dateStr = remember(oil.dateMillis) { dateFormatter.format(Date(oil.dateMillis)) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(BoxerAmber.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(6.dp)
                    ) {
                        Icon(
                            Icons.Default.Opacity,
                            contentDescription = null,
                            tint = BoxerAmber,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Column {
                        Text(
                            text = oil.oilBrand,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = DarkTextPrimary
                        )
                        Text(
                            text = "تاريخ التغيير: $dateStr",
                            fontSize = 11.sp,
                            color = DarkTextSecondary
                        )
                    }
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = DarkTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceVariant)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "تم التغيير عند عداد:", fontSize = 11.sp, color = DarkTextSecondary)
                    Text(
                        text = "${oil.odometerKm} كم",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = BoxerCyan
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "التغيير القادم الموصى به:", fontSize = 11.sp, color = DarkTextSecondary)
                    Text(
                        text = "${oil.nextDueKm} كم",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = BoxerAmber
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = if (oil.filterChanged) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (oil.filterChanged) ProfitGreen else DarkTextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (oil.filterChanged) "تم تغيير الفلتر" else "بدون تغيير الفلتر",
                        fontSize = 11.sp,
                        color = if (oil.filterChanged) ProfitGreen else DarkTextMuted
                    )
                }

                if (oil.cost > 0) {
                    Text(
                        text = "التكلفة: ${String.format(Locale.US, "%.0f ج.م", oil.cost)}",
                        fontSize = 11.sp,
                        color = DarkTextSecondary
                    )
                }
            }

            if (oil.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = oil.notes,
                    fontSize = 11.sp,
                    color = DarkTextMuted
                )
            }
        }
    }
}

@Composable
private fun TuningNotesTabContent(
    allNotes: List<TuningNoteEntity>,
    activeFilter: String,
    onFilterChange: (String) -> Unit,
    onAddNoteClick: () -> Unit,
    onDeleteNote: (TuningNoteEntity) -> Unit
) {
    val filteredNotes = remember(allNotes, activeFilter) {
        if (activeFilter == "ALL") allNotes
        else allNotes.filter { it.category == activeFilter }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Quick spec reference
        item {
            BoxerQuickSpecCard()
        }

        // Category Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = activeFilter == "ALL",
                    onClick = { onFilterChange("ALL") },
                    label = { Text("الكل (${allNotes.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BoxerCyan.copy(alpha = 0.25f),
                        selectedLabelColor = BoxerCyan
                    )
                )
                FilterChip(
                    selected = activeFilter == "CARBURETOR",
                    onClick = { onFilterChange("CARBURETOR") },
                    label = { Text("الكابريتر", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BoxerAmber.copy(alpha = 0.25f),
                        selectedLabelColor = BoxerAmber
                    )
                )
                FilterChip(
                    selected = activeFilter == "AIR_SCREW",
                    onClick = { onFilterChange("AIR_SCREW") },
                    label = { Text("برغي الهواء", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BoxerCyan.copy(alpha = 0.25f),
                        selectedLabelColor = BoxerCyan
                    )
                )
                FilterChip(
                    selected = activeFilter == "CLUTCH",
                    onClick = { onFilterChange("CLUTCH") },
                    label = { Text("الكلج", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = ProfitGreen.copy(alpha = 0.25f),
                        selectedLabelColor = ProfitGreen
                    )
                )
            }
        }

        if (filteredNotes.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.BuildCircle, contentDescription = null, tint = BoxerCyan, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("لا توجد ملاحظات مسجلة في هذا القسم", color = DarkTextPrimary, fontWeight = FontWeight.Bold)
                        Text("اضغط على الزر الدائري بالأسفل لإضافة ملاحظة ميكانيكية جديدة", fontSize = 12.sp, color = DarkTextSecondary)
                    }
                }
            }
        } else {
            items(filteredNotes, key = { it.id }) { note ->
                TuningNoteItemCard(
                    note = note,
                    onDelete = { onDeleteNote(note) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(60.dp))
        }
    }
}

@Composable
private fun TuningNoteItemCard(
    note: TuningNoteEntity,
    onDelete: () -> Unit
) {
    val dateFormatter = remember { SimpleDateFormat("yyyy/MM/dd", Locale.US) }
    val dateStr = remember(note.dateMillis) { dateFormatter.format(Date(note.dateMillis)) }

    val (categoryColor, categoryLabel) = when (note.category) {
        "CARBURETOR" -> Pair(BoxerAmber, "وزنية الكابريتر")
        "AIR_SCREW" -> Pair(BoxerCyan, "برغي الهواء والسلانسيه")
        "CLUTCH" -> Pair(ProfitGreen, "معايرة مقبض الكلج")
        else -> Pair(DarkTextSecondary, "مواصفات عامة")
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(categoryColor.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = categoryLabel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = categoryColor
                        )
                    }
                    Text(
                        text = dateStr,
                        fontSize = 11.sp,
                        color = DarkTextMuted
                    )
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "حذف",
                        tint = DarkTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = note.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DarkTextPrimary
            )

            if (note.settingValue.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الإعداد / الوزنية:",
                            fontSize = 12.sp,
                            color = DarkTextSecondary
                        )
                        Text(
                            text = note.settingValue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = categoryColor
                        )
                    }
                }
            }

            if (note.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = note.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkTextSecondary,
                    lineHeight = 18.sp
                )
            }

            if (note.bikeOdometerKm > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Default.Speed, contentDescription = null, tint = DarkTextMuted, modifier = Modifier.size(12.dp))
                    Text(
                        text = "عداد الدراجة عند الضبط: ${note.bikeOdometerKm} كم",
                        fontSize = 10.sp,
                        color = DarkTextMuted
                    )
                }
            }
        }
    }
}
