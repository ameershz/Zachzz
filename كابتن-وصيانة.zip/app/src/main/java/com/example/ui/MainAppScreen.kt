package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.AttachMoney
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.MaintenanceScreen
import com.example.ui.screens.ShiftsScreen
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.BoxerCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.CaptainViewModel
import com.example.ui.viewmodel.OilAlertStatus

sealed class Screen(val index: Int, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector, val tag: String) {
    data object Dashboard : Screen(0, "الرئيسية", Icons.Filled.Speed, Icons.Outlined.Speed, "nav_dashboard")
    data object Shifts : Screen(1, "الشفتات والأرباح", Icons.Filled.AttachMoney, Icons.Outlined.AttachMoney, "nav_shifts")
    data object Maintenance : Screen(2, "صيانة البوكسر", Icons.Filled.Build, Icons.Outlined.Build, "nav_maintenance")
}

@Composable
fun MainAppScreen(
    viewModel: CaptainViewModel,
    modifier: Modifier = Modifier
) {
    var currentScreenIndex by rememberSaveable { mutableIntStateOf(0) }
    val oilStatus by viewModel.oilStatus.collectAsState()

    // Back handling: If on Shifts or Maintenance, back button goes to Dashboard
    BackHandler(enabled = currentScreenIndex != 0) {
        currentScreenIndex = 0
    }

    val screens = listOf(
        Screen.Dashboard,
        Screen.Shifts,
        Screen.Maintenance
    )

    // Ensure Arabic layout RTL direction is provided
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = modifier.fillMaxSize(),
            containerColor = DarkBackground,
            contentWindowInsets = WindowInsets.navigationBars,
            bottomBar = {
                NavigationBar(
                    containerColor = DarkSurface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("bottom_nav_bar")
                ) {
                    screens.forEach { screen ->
                        val isSelected = currentScreenIndex == screen.index
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentScreenIndex = screen.index },
                            icon = {
                                if (screen is Screen.Maintenance && oilStatus.alertStatus != OilAlertStatus.SAFE) {
                                    BadgedBox(
                                        badge = {
                                            Badge(
                                                containerColor = if (oilStatus.alertStatus == OilAlertStatus.OVERDUE) ExpenseRed else WarningAmber
                                            )
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                            contentDescription = screen.title
                                        )
                                    }
                                } else {
                                    Icon(
                                        imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                        contentDescription = screen.title
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = DarkBackground,
                                selectedTextColor = BoxerAmber,
                                unselectedIconColor = DarkTextMuted,
                                unselectedTextColor = DarkTextSecondary,
                                indicatorColor = BoxerAmber
                            ),
                            modifier = Modifier.testTag(screen.tag)
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                AnimatedContent(
                    targetState = currentScreenIndex,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "screen_transition"
                ) { targetIndex ->
                    when (targetIndex) {
                        0 -> DashboardScreen(
                            viewModel = viewModel,
                            onNavigateToShifts = { currentScreenIndex = 1 },
                            onNavigateToMaintenance = { currentScreenIndex = 2 }
                        )
                        1 -> ShiftsScreen(viewModel = viewModel)
                        2 -> MaintenanceScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
