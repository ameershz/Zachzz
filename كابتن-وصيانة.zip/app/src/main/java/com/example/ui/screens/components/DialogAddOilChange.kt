package com.example.ui.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.BoxerCyan
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.ProfitGreen

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DialogAddOilChange(
    initialOdometer: Int,
    onDismiss: () -> Unit,
    onSave: (
        odometerKm: Int,
        oilBrand: String,
        filterChanged: Boolean,
        cost: Double,
        notes: String,
        intervalKm: Int
    ) -> Unit
) {
    var odoText by remember { mutableStateOf(initialOdometer.toString()) }
    var selectedBrand by remember { mutableStateOf("Bajaj DTS-i 20W50") }
    var customBrandText by remember { mutableStateOf("") }
    var filterChanged by remember { mutableStateOf(true) }
    var selectedInterval by remember { mutableStateOf(1200) }
    var costText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }

    val oilBrands = listOf(
        "Bajaj DTS-i 20W50",
        "Shell Advance 20W50",
        "Motul 3000 4T",
        "Castrol Activ 4T",
        "مخصص / نوع آخر"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("dialog_add_oil_change"),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(BoxerAmber.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = null,
                        tint = BoxerAmber
                    )
                }
                Column {
                    Text(
                        text = "تسجيل تغيير زيت المحرك",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = "باجاج بوكسر 150 (الكمية: 1.0 لتر)",
                        style = MaterialTheme.typography.bodySmall,
                        color = BoxerCyan
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Odometer reading
                OutlinedTextField(
                    value = odoText,
                    onValueChange = { odoText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("قراءة العداد الحالية (كم)") },
                    leadingIcon = {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = BoxerAmber)
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_oil_odometer"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerAmber,
                        unfocusedBorderColor = DarkOutline
                    )
                )

                // Oil Brands Chips
                Text(
                    text = "نوع الزيت المستخدم:",
                    style = MaterialTheme.typography.labelMedium,
                    color = DarkTextSecondary
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    oilBrands.forEach { brand ->
                        FilterChip(
                            selected = selectedBrand == brand,
                            onClick = { selectedBrand = brand },
                            label = { Text(brand, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BoxerAmber.copy(alpha = 0.25f),
                                selectedLabelColor = BoxerAmber
                            )
                        )
                    }
                }

                if (selectedBrand == "مخصص / نوع آخر") {
                    OutlinedTextField(
                        value = customBrandText,
                        onValueChange = { customBrandText = it },
                        label = { Text("اكتب اسم الزيت واللزوجة") },
                        placeholder = { Text("مثال: فالفولين 20W50") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BoxerCyan,
                            unfocusedBorderColor = DarkOutline
                        )
                    )
                }

                // Interval chips
                Text(
                    text = "المسافة حتى التغيير القادم:",
                    style = MaterialTheme.typography.labelMedium,
                    color = DarkTextSecondary
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(1000, 1200, 1500).forEach { interval ->
                        FilterChip(
                            selected = selectedInterval == interval,
                            onClick = { selectedInterval = interval },
                            label = { Text("$interval كم", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BoxerCyan.copy(alpha = 0.25f),
                                selectedLabelColor = BoxerCyan
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Filter changed toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { filterChanged = !filterChanged }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = filterChanged,
                        onCheckedChange = { filterChanged = it },
                        colors = CheckboxDefaults.colors(
                            checkedColor = ProfitGreen,
                            uncheckedColor = DarkOutline
                        )
                    )
                    Column {
                        Text(
                            text = "تم تغيير فلتر الزيت أيضاً",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = DarkTextPrimary
                        )
                        Text(
                            text = "ينصح بتغييره مع كل غيار زيت أو غيارين بالبوكسر",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted
                        )
                    }
                }

                // Cost and Notes
                OutlinedTextField(
                    value = costText,
                    onValueChange = { costText = it },
                    label = { Text("تكلفة الزيت والفلتر (اختياري)") },
                    placeholder = { Text("150.0") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerAmber,
                        unfocusedBorderColor = DarkOutline
                    )
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("ملاحظات إضافية") },
                    placeholder = { Text("تنظيف مصفاة الزيت السفلية، إلخ") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerAmber,
                        unfocusedBorderColor = DarkOutline
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val odo = odoText.toIntOrNull() ?: initialOdometer
                    val cost = costText.toDoubleOrNull() ?: 0.0
                    val brand = if (selectedBrand == "مخصص / نوع آخر") {
                        customBrandText.ifBlank { "زيت 20W50" }
                    } else selectedBrand

                    onSave(odo, brand, filterChanged, cost, notesText, selectedInterval)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BoxerAmber,
                    contentColor = DarkSurface
                ),
                modifier = Modifier.testTag("btn_save_oil_change")
            ) {
                Text("حفظ التغيير", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkTextSecondary)
            ) {
                Text("إلغاء")
            }
        },
        containerColor = DarkSurface
    )
}
