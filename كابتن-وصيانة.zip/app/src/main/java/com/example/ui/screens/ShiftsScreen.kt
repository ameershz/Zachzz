package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.ShiftEntity
import com.example.ui.screens.components.DialogAddShift
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.BoxerCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.viewmodel.CaptainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShiftsScreen(
    viewModel: CaptainViewModel,
    modifier: Modifier = Modifier
) {
    val allShifts by viewModel.allShifts.collectAsState()
    var selectedFilterDays by remember { mutableIntStateOf(7) } // 7 = week, 30 = month, 0 = all
    var showAddDialog by remember { mutableStateOf(false) }
    var shiftToDelete by remember { mutableStateOf<ShiftEntity?>(null) }

    val filteredShifts by remember(allShifts, selectedFilterDays) {
        derivedStateOf {
            if (selectedFilterDays == 0) {
                allShifts
            } else {
                val cutoff = System.currentTimeMillis() - (selectedFilterDays * 86_400_000L)
                allShifts.filter { it.dateMillis >= cutoff }
            }
        }
    }

    val periodSummary = remember(filteredShifts) {
        val totalGross = filteredShifts.sumOf { it.grossEarnings }
        val totalTips = filteredShifts.sumOf { it.tips }
        val totalFuel = filteredShifts.sumOf { it.fuelExpense + it.otherExpenses }
        val totalNet = filteredShifts.sumOf { it.netEarnings }
        val totalOrders = filteredShifts.sumOf { it.ordersCount }
        val avgPerOrder = if (totalOrders > 0) totalNet / totalOrders else 0.0
        val avgPerShift = if (filteredShifts.isNotEmpty()) totalNet / filteredShifts.size else 0.0

        object {
            val net = totalNet
            val gross = totalGross
            val tips = totalTips
            val fuel = totalFuel
            val orders = totalOrders
            val count = filteredShifts.size
            val avgOrder = avgPerOrder
            val avgShift = avgPerShift
        }
    }

    Scaffold(
        modifier = modifier.testTag("shifts_screen"),
        containerColor = DarkBackground,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = BoxerAmber,
                contentColor = DarkBackground,
                modifier = Modifier.testTag("fab_add_shift")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("شفت جديد", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Title
            item {
                Column {
                    Text(
                        text = "إدارة الشفتات والأرباح",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = "متابعة أرباح التوصيل، الإكراميات، ومصروف البنزين اليومي",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                }
            }

            // Period Filters (Week, Month, All)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedFilterDays == 7,
                        onClick = { selectedFilterDays = 7 },
                        label = { Text("أرباح الأسبوع (7 أيام)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BoxerAmber.copy(alpha = 0.25f),
                            selectedLabelColor = BoxerAmber
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedFilterDays == 30,
                        onClick = { selectedFilterDays = 30 },
                        label = { Text("أرباح الشهر (30 يوم)") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BoxerCyan.copy(alpha = 0.25f),
                            selectedLabelColor = BoxerCyan
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = selectedFilterDays == 0,
                        onClick = { selectedFilterDays = 0 },
                        label = { Text("الكل (${allShifts.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ProfitGreen.copy(alpha = 0.25f),
                            selectedLabelColor = ProfitGreen
                        ),
                        modifier = Modifier.weight(0.8f)
                    )
                }
            }

            // Aggregated Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (selectedFilterDays) {
                                    7 -> "إجمالي الأرباح الأسبوعية"
                                    30 -> "إجمالي الأرباح الشهرية"
                                    else -> "إجمالي كافة الشفتات المسجلة"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkTextPrimary
                            )
                            Box(
                                modifier = Modifier
                                    .background(DarkSurfaceVariant, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${periodSummary.count} شفتات",
                                    fontSize = 11.sp,
                                    color = BoxerCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Big Net Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (periodSummary.net >= 0) ProfitGreen.copy(alpha = 0.12f)
                                    else ExpenseRed.copy(alpha = 0.12f)
                                )
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "صافي الربح التراكمي",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = DarkTextSecondary
                                    )
                                    Text(
                                        text = "متوسط ${String.format(Locale.US, "%.1f", periodSummary.avgShift)} ج.م لكل شفت",
                                        fontSize = 11.sp,
                                        color = DarkTextMuted
                                    )
                                }
                                Text(
                                    text = String.format(Locale.US, "%.1f ج.م", periodSummary.net),
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (periodSummary.net >= 0) ProfitGreen else ExpenseRed
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // 4 Statistics Rows
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatItem(label = "إجمالي الطلبات", value = "${periodSummary.orders} طلب")
                            StatItem(
                                label = "دخل التطبيق",
                                value = String.format(Locale.US, "%.0f ج.م", periodSummary.gross)
                            )
                        }

                        HorizontalDivider(color = DarkOutline, modifier = Modifier.padding(vertical = 8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatItem(
                                label = "إكراميات إضافية",
                                value = String.format(Locale.US, "%.0f ج.م", periodSummary.tips)
                            )
                            StatItem(
                                label = "بنزين ومصاريف",
                                value = String.format(Locale.US, "%.0f ج.م", periodSummary.fuel)
                            )
                        }
                    }
                }
            }

            // Shifts List Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "سجل الأيام والشفتات السابقة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = "${filteredShifts.size} سجل",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                }
            }

            if (filteredShifts.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                Icons.Default.DirectionsBike,
                                contentDescription = null,
                                tint = BoxerAmber,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "لا توجد شفتات مسجلة في هذه الفترة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DarkTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "اضغط على زر (شفت جديد) بالأسفل لتسجيل أرباح اليوم",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )
                        }
                    }
                }
            } else {
                items(filteredShifts, key = { it.id }) { shift ->
                    ShiftItemCard(
                        shift = shift,
                        onDelete = { shiftToDelete = shift }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Add Shift Dialog
    if (showAddDialog) {
        DialogAddShift(
            onDismiss = { showAddDialog = false },
            onSave = { date, start, end, orders, gross, tips, fuel, other, notes, dist ->
                viewModel.addShift(
                    dateMillis = date,
                    startTime = start,
                    endTime = end,
                    ordersCount = orders,
                    grossEarnings = gross,
                    tips = tips,
                    fuelExpense = fuel,
                    otherExpenses = other,
                    notes = notes,
                    distanceCoveredKm = dist
                )
                showAddDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    shiftToDelete?.let { shift ->
        AlertDialog(
            onDismissRequest = { shiftToDelete = null },
            title = { Text("حذف الشفت", color = DarkTextPrimary) },
            text = { Text("هل أنت متأكد من حذف بيانات شفت هذا اليوم؟ لا يمكن التراجع عن هذا الإجراء.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteShift(shift)
                        shiftToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed)
                ) {
                    Text("حذف")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { shiftToDelete = null }) {
                    Text("إلغاء")
                }
            },
            containerColor = DarkSurface
        )
    }
}

@Composable
private fun ShiftItemCard(
    shift: ShiftEntity,
    onDelete: () -> Unit
) {
    val dateFormatter = remember { SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")) }
    val formattedDate = remember(shift.dateMillis) {
        dateFormatter.format(Date(shift.dateMillis))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("item_shift_${shift.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Date, Shift time, Delete button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(BoxerAmber.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(6.dp)
                    ) {
                        Icon(
                            Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = BoxerAmber,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Column {
                        Text(
                            text = formattedDate,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = DarkTextPrimary
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = BoxerCyan,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "من ${shift.startTime} إلى ${shift.endTime}",
                                fontSize = 11.sp,
                                color = BoxerCyan
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "حذف الشفت",
                        tint = DarkTextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Net Profit Banner
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkSurfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(BoxerCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${shift.ordersCount} طلبات",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BoxerCyan
                        )
                    }
                    Text(
                        text = "صافي الربح:",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                }
                Text(
                    text = String.format(Locale.US, "%.1f ج.م", shift.netEarnings),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (shift.netEarnings >= 0) ProfitGreen else ExpenseRed
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Breakdown row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "دخل: ${String.format(Locale.US, "%.0f", shift.grossEarnings)}",
                    fontSize = 11.sp,
                    color = DarkTextSecondary
                )
                Text(
                    text = "+ إكراميات: ${String.format(Locale.US, "%.0f", shift.tips)}",
                    fontSize = 11.sp,
                    color = BoxerAmber
                )
                Text(
                    text = "- بنزين ومصاريف: ${String.format(Locale.US, "%.0f", shift.fuelExpense + shift.otherExpenses)}",
                    fontSize = 11.sp,
                    color = ExpenseRed
                )
            }

            if (shift.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        Icons.Default.Notes,
                        contentDescription = null,
                        tint = DarkTextMuted,
                        modifier = Modifier.size(12.dp)
                    )
                    Text(
                        text = shift.notes,
                        fontSize = 11.sp,
                        color = DarkTextMuted,
                        maxLines = 2
                    )
                }
            }
        }
    }
}

@Composable
private fun StatItem(label: String, value: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(text = "$label:", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = DarkTextPrimary)
    }
}
