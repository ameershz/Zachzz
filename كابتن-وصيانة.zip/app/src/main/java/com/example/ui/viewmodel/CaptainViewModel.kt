package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.BikeSettingsEntity
import com.example.data.local.entity.OilChangeEntity
import com.example.data.local.entity.ShiftEntity
import com.example.data.local.entity.TuningNoteEntity
import com.example.data.repository.CaptainRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class TodaySummary(
    val gross: Double = 0.0,
    val tips: Double = 0.0,
    val fuel: Double = 0.0,
    val net: Double = 0.0,
    val orders: Int = 0,
    val hasShiftToday: Boolean = false
)

enum class OilAlertStatus {
    SAFE,       // More than 200 km left
    WARNING,    // Between 0 and 200 km left
    OVERDUE     // Past due
}

data class OilStatus(
    val currentOdo: Int = 14850,
    val lastChangedOdo: Int = 14000,
    val nextDueOdo: Int = 15200,
    val remainingKm: Int = 350,
    val intervalKm: Int = 1200,
    val progress: Float = 0.70f,
    val alertStatus: OilAlertStatus = OilAlertStatus.SAFE
)

data class PeriodSummary(
    val totalNet: Double = 0.0,
    val totalGross: Double = 0.0,
    val totalTips: Double = 0.0,
    val totalFuel: Double = 0.0,
    val totalOrders: Int = 0,
    val shiftCount: Int = 0,
    val avgPerOrder: Double = 0.0
)

class CaptainViewModel(
    application: Application,
    private val repository: CaptainRepository
) : AndroidViewModel(application) {

    val allShifts: StateFlow<List<ShiftEntity>> = repository.allShifts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOilChanges: StateFlow<List<OilChangeEntity>> = repository.allOilChanges
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestOilChange: StateFlow<OilChangeEntity?> = repository.latestOilChange
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allTuningNotes: StateFlow<List<TuningNoteEntity>> = repository.allTuningNotes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bikeSettings: StateFlow<BikeSettingsEntity> = repository.bikeSettings
        .combine(MutableStateFlow(Unit)) { settings, _ ->
            settings ?: BikeSettingsEntity()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BikeSettingsEntity())

    // Oil calculation state
    val oilStatus: StateFlow<OilStatus> = combine(
        bikeSettings,
        latestOilChange
    ) { settings, latestOil ->
        val currentOdo = settings.currentOdometerKm
        val lastChangeOdo = latestOil?.odometerKm ?: settings.lastOilOdometerKm
        val interval = settings.oilIntervalKm
        val nextDue = latestOil?.nextDueKm ?: (lastChangeOdo + interval)
        val remaining = nextDue - currentOdo
        val distanceTraveledSinceChange = (currentOdo - lastChangeOdo).coerceAtLeast(0)
        val progress = if (interval > 0) {
            (distanceTraveledSinceChange.toFloat() / interval.toFloat()).coerceIn(0f, 1f)
        } else 0f

        val status = when {
            remaining <= 0 -> OilAlertStatus.OVERDUE
            remaining <= 200 -> OilAlertStatus.WARNING
            else -> OilAlertStatus.SAFE
        }

        OilStatus(
            currentOdo = currentOdo,
            lastChangedOdo = lastChangeOdo,
            nextDueOdo = nextDue,
            remainingKm = remaining,
            intervalKm = interval,
            progress = progress,
            alertStatus = status
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), OilStatus())

    // Today's summary
    val todaySummary: StateFlow<TodaySummary> = allShifts.combine(MutableStateFlow(Unit)) { shifts, _ ->
        val calNow = Calendar.getInstance()
        val todayYear = calNow.get(Calendar.YEAR)
        val todayDay = calNow.get(Calendar.DAY_OF_YEAR)

        val todayShifts = shifts.filter { shift ->
            val calShift = Calendar.getInstance().apply { timeInMillis = shift.dateMillis }
            calShift.get(Calendar.YEAR) == todayYear && calShift.get(Calendar.DAY_OF_YEAR) == todayDay
        }

        if (todayShifts.isEmpty()) {
            TodaySummary()
        } else {
            val gross = todayShifts.sumOf { it.grossEarnings }
            val tips = todayShifts.sumOf { it.tips }
            val fuel = todayShifts.sumOf { it.fuelExpense + it.otherExpenses }
            val net = todayShifts.sumOf { it.netEarnings }
            val orders = todayShifts.sumOf { it.ordersCount }
            TodaySummary(
                gross = gross,
                tips = tips,
                fuel = fuel,
                net = net,
                orders = orders,
                hasShiftToday = true
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TodaySummary())

    // Filtered Period summary (week / month / all)
    fun getSummaryForDays(days: Int): PeriodSummary {
        val shifts = allShifts.value
        val cutoff = if (days > 0) {
            System.currentTimeMillis() - (days * 86_400_000L)
        } else 0L

        val filtered = if (days > 0) shifts.filter { it.dateMillis >= cutoff } else shifts
        val totalGross = filtered.sumOf { it.grossEarnings }
        val totalTips = filtered.sumOf { it.tips }
        val totalFuel = filtered.sumOf { it.fuelExpense + it.otherExpenses }
        val totalNet = filtered.sumOf { it.netEarnings }
        val totalOrders = filtered.sumOf { it.ordersCount }
        val avg = if (totalOrders > 0) totalNet / totalOrders else 0.0

        return PeriodSummary(
            totalNet = totalNet,
            totalGross = totalGross,
            totalTips = totalTips,
            totalFuel = totalFuel,
            totalOrders = totalOrders,
            shiftCount = filtered.size,
            avgPerOrder = avg
        )
    }

    // Actions
    fun addShift(
        dateMillis: Long,
        startTime: String,
        endTime: String,
        ordersCount: Int,
        grossEarnings: Double,
        tips: Double,
        fuelExpense: Double,
        otherExpenses: Double,
        notes: String,
        distanceCoveredKm: Int = 0
    ) {
        viewModelScope.launch {
            val netEarnings = (grossEarnings + tips) - (fuelExpense + otherExpenses)
            val shift = ShiftEntity(
                dateMillis = dateMillis,
                startTime = startTime,
                endTime = endTime,
                ordersCount = ordersCount,
                grossEarnings = grossEarnings,
                tips = tips,
                fuelExpense = fuelExpense,
                otherExpenses = otherExpenses,
                netEarnings = netEarnings,
                notes = notes
            )
            repository.insertShift(shift)

            // If user logged distance covered in this shift, increment bike odometer
            if (distanceCoveredKm > 0) {
                val current = bikeSettings.value.currentOdometerKm
                repository.updateOdometer(current + distanceCoveredKm)
            }
        }
    }

    fun deleteShift(shift: ShiftEntity) {
        viewModelScope.launch {
            repository.deleteShift(shift)
        }
    }

    fun deleteShiftById(id: Long) {
        viewModelScope.launch {
            repository.deleteShiftById(id)
        }
    }

    fun addOilChange(
        odometerKm: Int,
        oilBrand: String,
        filterChanged: Boolean,
        cost: Double,
        notes: String,
        customIntervalKm: Int = 1200
    ) {
        viewModelScope.launch {
            val nextDue = odometerKm + customIntervalKm
            val oilChange = OilChangeEntity(
                dateMillis = System.currentTimeMillis(),
                odometerKm = odometerKm,
                nextDueKm = nextDue,
                oilBrand = oilBrand.ifBlank { "Bajaj DTS-i 20W50" },
                filterChanged = filterChanged,
                cost = cost,
                notes = notes
            )
            repository.insertOilChange(oilChange)

            // Update settings
            val currentSettings = bikeSettings.value
            repository.saveBikeSettings(
                currentSettings.copy(
                    currentOdometerKm = maxOf(currentSettings.currentOdometerKm, odometerKm),
                    lastOilOdometerKm = odometerKm,
                    oilIntervalKm = customIntervalKm
                )
            )
        }
    }

    fun deleteOilChange(oilChange: OilChangeEntity) {
        viewModelScope.launch {
            repository.deleteOilChange(oilChange)
        }
    }

    fun updateCurrentOdometer(newKm: Int) {
        viewModelScope.launch {
            repository.updateOdometer(newKm)
        }
    }

    fun addTuningNote(
        category: String,
        title: String,
        settingValue: String,
        notes: String,
        bikeOdo: Int
    ) {
        viewModelScope.launch {
            val note = TuningNoteEntity(
                dateMillis = System.currentTimeMillis(),
                category = category,
                title = title,
                settingValue = settingValue,
                notes = notes,
                bikeOdometerKm = if (bikeOdo > 0) bikeOdo else bikeSettings.value.currentOdometerKm
            )
            repository.insertTuningNote(note)
        }
    }

    fun deleteTuningNote(note: TuningNoteEntity) {
        viewModelScope.launch {
            repository.deleteTuningNote(note)
        }
    }

    fun toggleEveningShift() {
        viewModelScope.launch {
            val current = bikeSettings.value
            val isNowActive = !current.eveningShiftActive
            val startTs = if (isNowActive) System.currentTimeMillis() else 0L
            repository.updateShiftState(isNowActive, startTs)
        }
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getDatabase(application)
                    val repo = CaptainRepository(
                        shiftDao = db.shiftDao(),
                        oilChangeDao = db.oilChangeDao(),
                        tuningNoteDao = db.tuningNoteDao(),
                        bikeSettingsDao = db.bikeSettingsDao()
                    )
                    return CaptainViewModel(application, repo) as T
                }
            }
    }
}
