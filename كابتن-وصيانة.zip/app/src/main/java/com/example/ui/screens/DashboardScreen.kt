package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.NightlightRound
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.screens.components.BoxerQuickSpecCard
import com.example.ui.screens.components.DialogAddOilChange
import com.example.ui.screens.components.DialogAddShift
import com.example.ui.screens.components.DialogUpdateOdometer
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.BoxerCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ProfitGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.CaptainViewModel
import com.example.ui.viewmodel.OilAlertStatus
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: CaptainViewModel,
    onNavigateToShifts: () -> Unit,
    onNavigateToMaintenance: () -> Unit,
    modifier: Modifier = Modifier
) {
    val todaySummary by viewModel.todaySummary.collectAsState()
    val oilStatus by viewModel.oilStatus.collectAsState()
    val bikeSettings by viewModel.bikeSettings.collectAsState()

    var showAddShiftDialog by remember { mutableStateOf(false) }
    var showAddOilDialog by remember { mutableStateOf(false) }
    var showUpdateOdoDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner with Night Delivery Theme
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.boxer_banner),
                        contentDescription = "دراجة باجاج بوكسر في الشفت المسائي",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    // Dark gradient scrim
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        DarkBackground.copy(alpha = 0.85f),
                                        DarkBackground
                                    )
                                )
                            )
                    )
                    // Banner text overlay
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(BoxerAmber, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "باجاج بوكسر 150",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkBackground
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .background(BoxerCyan.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .border(1.dp, BoxerCyan.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        Icons.Default.NightlightRound,
                                        contentDescription = null,
                                        tint = BoxerCyan,
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Text(
                                        text = "3 عصراً - 12 ليلاً",
                                        fontSize = 11.sp,
                                        color = BoxerCyan,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "كابتن وصيانة",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = DarkTextPrimary
                        )
                        Text(
                            text = "شفت المساء وأرباح اليوم وصيانة الموتوسيكل",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextSecondary
                        )
                    }
                }
            }
        }

        // Active Evening Shift Status Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (bikeSettings.eveningShiftActive) {
                        BoxerAmber.copy(alpha = 0.12f)
                    } else {
                        DarkSurfaceVariant
                    }
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (bikeSettings.eveningShiftActive) BoxerAmber.copy(alpha = 0.5f) else DarkOutline
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(
                                    if (bikeSettings.eveningShiftActive) BoxerAmber else DarkSurfaceHighlight,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (bikeSettings.eveningShiftActive) Icons.Default.DirectionsBike else Icons.Default.NightlightRound,
                                contentDescription = null,
                                tint = if (bikeSettings.eveningShiftActive) DarkBackground else BoxerAmber,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = if (bikeSettings.eveningShiftActive) "شفت المساء قيد العمل الآن" else "شفت المساء (3م - 12ص)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (bikeSettings.eveningShiftActive) BoxerAmber else DarkTextPrimary
                            )
                            Text(
                                text = if (bikeSettings.eveningShiftActive) "الله يرزقك ويحفظك على الطريق يا كابتن" else "اضغط لبدء الشفت المسائي",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )
                        }
                    }

                    Button(
                        onClick = { viewModel.toggleEveningShift() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (bikeSettings.eveningShiftActive) ExpenseRed else BoxerAmber,
                            contentColor = DarkBackground
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_toggle_shift")
                    ) {
                        Icon(
                            imageVector = if (bikeSettings.eveningShiftActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (bikeSettings.eveningShiftActive) "إنهاء" else "بدء الشفت",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Today's Earnings Summary Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_today_earnings"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(ProfitGreen.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                    .padding(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.AttachMoney,
                                    contentDescription = null,
                                    tint = ProfitGreen
                                )
                            }
                            Column {
                                Text(
                                    text = "ملخص أرباح اليوم",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkTextPrimary
                                )
                                Text(
                                    text = if (todaySummary.hasShiftToday) "${todaySummary.orders} طلبات مسجلة اليوم" else "لم يتم تسجيل شفت اليوم بعد",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DarkTextSecondary
                                )
                            }
                        }

                        FilledTonalButton(
                            onClick = { showAddShiftDialog = true },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = BoxerAmber.copy(alpha = 0.2f),
                                contentColor = BoxerAmber
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("btn_quick_add_shift")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تسجيل شفت", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Net profit highlight
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceVariant)
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "صافي ربح اليوم الحقيقي",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = DarkTextSecondary
                                )
                                Text(
                                    text = "(بعد خصم البنزين والمصاريف)",
                                    fontSize = 11.sp,
                                    color = DarkTextMuted
                                )
                            }
                            Text(
                                text = String.format(Locale.US, "%.1f ج.م", todaySummary.net),
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (todaySummary.net >= 0) ProfitGreen else ExpenseRed
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4 Key Metrics Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricSmallBox(
                            label = "دخل التوصيل",
                            value = String.format(Locale.US, "%.0f", todaySummary.gross),
                            icon = Icons.Default.ShoppingBag,
                            tint = BoxerCyan,
                            modifier = Modifier.weight(1f)
                        )
                        MetricSmallBox(
                            label = "الإكراميات",
                            value = String.format(Locale.US, "%.0f", todaySummary.tips),
                            icon = Icons.Default.AttachMoney,
                            tint = BoxerAmber,
                            modifier = Modifier.weight(1f)
                        )
                        MetricSmallBox(
                            label = "بنزين البوكسر",
                            value = String.format(Locale.US, "%.0f", todaySummary.fuel),
                            icon = Icons.Default.LocalGasStation,
                            tint = ExpenseRed,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Engine Oil Alert Card
        item {
            val alertColor by animateColorAsState(
                targetValue = when (oilStatus.alertStatus) {
                    OilAlertStatus.SAFE -> ProfitGreen
                    OilAlertStatus.WARNING -> WarningAmber
                    OilAlertStatus.OVERDUE -> ExpenseRed
                },
                label = "oil_alert_color"
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("card_oil_alert"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (oilStatus.alertStatus != OilAlertStatus.SAFE) alertColor else DarkOutline
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .background(alertColor.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                    .padding(6.dp)
                            ) {
                                Icon(
                                    imageVector = when (oilStatus.alertStatus) {
                                        OilAlertStatus.SAFE -> Icons.Default.CheckCircle
                                        OilAlertStatus.WARNING -> Icons.Default.NotificationsActive
                                        OilAlertStatus.OVERDUE -> Icons.Default.Warning
                                    },
                                    contentDescription = null,
                                    tint = alertColor
                                )
                            }
                            Column {
                                Text(
                                    text = "تنبيه زيت المحرك (Engine Oil)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = DarkTextPrimary
                                )
                                Text(
                                    text = "باجاج بوكسر 150 (زيت 20W50 - 1.0L)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BoxerCyan
                                )
                            }
                        }

                        // Badge status
                        Box(
                            modifier = Modifier
                                .background(alertColor.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = when (oilStatus.alertStatus) {
                                    OilAlertStatus.SAFE -> "الزيت ممتاز"
                                    OilAlertStatus.WARNING -> "تغيير قريب!"
                                    OilAlertStatus.OVERDUE -> "تغيير فوري مطلوب!"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = alertColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Remaining Distance Display
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = "المسافة المتبقية لتغيير الزيت:",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )
                            Text(
                                text = if (oilStatus.remainingKm >= 0) {
                                    "${oilStatus.remainingKm} كم متبقي"
                                } else {
                                    "تجاوز الموعد بـ ${-oilStatus.remainingKm} كم!"
                                },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = alertColor
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "العداد الحالي: ${oilStatus.currentOdo} كم",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )
                            Text(
                                text = "الموعد القادم: ${oilStatus.nextDueOdo} كم",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color = BoxerAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Progress bar
                    LinearProgressIndicator(
                        progress = { oilStatus.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = alertColor,
                        trackColor = DarkSurfaceHighlight
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showAddOilDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = alertColor,
                                contentColor = DarkBackground
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_log_oil_now")
                        ) {
                            Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تسجيل تغيير زيت", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { showUpdateOdoDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = BoxerAmber),
                            modifier = Modifier.testTag("btn_quick_update_odo")
                        ) {
                            Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تحديث العداد")
                        }
                    }
                }
            }
        }

        // Quick Boxer Mechanical Health Pills
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToMaintenance() },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkOutline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "ملاحظات الضبط الميكانيكي (باجاج بوكسر)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = DarkTextPrimary
                        )
                        Text(
                            text = "عرض الكل ←",
                            style = MaterialTheme.typography.labelSmall,
                            color = BoxerCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TuningPill(
                            title = "الكابريتر",
                            value = "إبرة Notch 3",
                            sub = "سحب اقتصادي",
                            modifier = Modifier.weight(1f)
                        )
                        TuningPill(
                            title = "برغي الهواء",
                            value = "2.25 لفة",
                            sub = "1400 RPM",
                            modifier = Modifier.weight(1f)
                        )
                        TuningPill(
                            title = "مقبض الكلج",
                            value = "12 مم خلوص",
                            sub = "فصل سلس",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Quick Boxer Specifications Reference
        item {
            BoxerQuickSpecCard()
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Dialogs
    if (showAddShiftDialog) {
        DialogAddShift(
            onDismiss = { showAddShiftDialog = false },
            onSave = { date, start, end, orders, gross, tips, fuel, other, notes, dist ->
                viewModel.addShift(
                    dateMillis = date,
                    startTime = start,
                    endTime = end,
                    ordersCount = orders,
                    grossEarnings = gross,
                    tips = tips,
                    fuelExpense = fuel,
                    otherExpenses = other,
                    notes = notes,
                    distanceCoveredKm = dist
                )
                showAddShiftDialog = false
            }
        )
    }

    if (showAddOilDialog) {
        DialogAddOilChange(
            initialOdometer = oilStatus.currentOdo,
            onDismiss = { showAddOilDialog = false },
            onSave = { odo, brand, filter, cost, notes, interval ->
                viewModel.addOilChange(
                    odometerKm = odo,
                    oilBrand = brand,
                    filterChanged = filter,
                    cost = cost,
                    notes = notes,
                    customIntervalKm = interval
                )
                showAddOilDialog = false
            }
        )
    }

    if (showUpdateOdoDialog) {
        DialogUpdateOdometer(
            currentOdometer = oilStatus.currentOdo,
            onDismiss = { showUpdateOdoDialog = false },
            onConfirm = { newKm ->
                viewModel.updateCurrentOdometer(newKm)
                showUpdateOdoDialog = false
            }
        )
    }
}

@Composable
private fun MetricSmallBox(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkSurfaceVariant)
            .padding(10.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
                Text(text = label, fontSize = 11.sp, color = DarkTextSecondary)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DarkTextPrimary
            )
        }
    }
}

@Composable
private fun TuningPill(
    title: String,
    value: String,
    sub: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceVariant)
            .border(1.dp, DarkOutline, RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(text = title, fontSize = 11.sp, color = DarkTextSecondary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = BoxerAmber
            )
            Text(text = sub, fontSize = 10.sp, color = DarkTextMuted)
        }
    }
}
