package com.example.ui.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary

@Composable
fun DialogUpdateOdometer(
    currentOdometer: Int,
    onDismiss: () -> Unit,
    onConfirm: (newOdometer: Int) -> Unit
) {
    var odoText by remember { mutableStateOf(currentOdometer.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("dialog_update_odometer"),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(BoxerAmber.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = BoxerAmber
                    )
                }
                Column {
                    Text(
                        text = "تحديث عداد الدراجة",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = "باجاج بوكسر Bajaj Boxer",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "أدخل قراءة عداد الكيلومتر الحالية لدراجتك لتحديث حساب موعد تغيير الزيت:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = DarkTextSecondary
                )
                OutlinedTextField(
                    value = odoText,
                    onValueChange = { odoText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("العداد الحالي (كم)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_update_odometer"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerAmber,
                        unfocusedBorderColor = DarkOutline
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val odo = odoText.toIntOrNull() ?: currentOdometer
                    onConfirm(odo)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BoxerAmber,
                    contentColor = DarkSurface
                ),
                modifier = Modifier.testTag("btn_confirm_odometer")
            ) {
                Text("تحديث العداد", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkTextSecondary)
            ) {
                Text("إلغاء")
            }
        },
        containerColor = DarkSurface
    )
}
