package com.example.ui.screens.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.BoxerCyan
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary

@Composable
fun BoxerQuickSpecCard() {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(BoxerAmber.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = BoxerAmber
                        )
                    }
                    Column {
                        Text(
                            text = "كتالوج معايير باجاج بوكسر 150 السريع",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = DarkTextPrimary
                        )
                        Text(
                            text = "أهم الأرقام القياسية للميكانيكا والصيانة الليلية",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextSecondary
                        )
                    }
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = BoxerAmber
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    HorizontalDivider(color = DarkOutline, modifier = Modifier.padding(bottom = 10.dp))

                    SpecItem(
                        label = "زيت المحرك (Engine Oil):",
                        value = "1.0 لتر (1000 مل) - لزوجة 20W50 4T",
                        hint = "التغيير الموصى به: كل 1000 إلى 1200 كم"
                    )
                    SpecItem(
                        label = "برغي الهواء (Air Screw):",
                        value = "2.25 إلى 2.5 لفة للخارج",
                        hint = "لوزنية احتراق مثالية وتجنب خمول المحرك"
                    )
                    SpecItem(
                        label = "سرعة السلانسيه (Idle RPM):",
                        value = "1400 ± 100 دورة/دقيقة",
                        hint = "يضبط بعد تسخين المحرك جيداً"
                    )
                    SpecItem(
                        label = "خلوص مقبض الكلج (Clutch Play):",
                        value = "10 - 15 ملم عند طرف الذراع",
                        hint = "يحمي أسطوانات الدبرياج من التآكل السريع"
                    )
                    SpecItem(
                        label = "ضغط الإطارات (Tire Pressure):",
                        value = "أمامي 25 PSI / خلفي 32 PSI",
                        hint = "الخلفي 32 مع صندوق التوصيل وحمولة الدليفري"
                    )
                    SpecItem(
                        label = "شمعة الاحتراق (Spark Plug):",
                        value = "خلوص 0.7 - 0.8 ملم",
                        hint = "نوع Champion PRZ9HC أو Bosch UR4AC"
                    )
                    SpecItem(
                        label = "خلوص التاكيهات (Valves):",
                        value = "سحب 0.05 مم / عادم 0.10 مم",
                        hint = "يتم الضبط والمحرك بارد تماماً"
                    )
                    SpecItem(
                        label = "خلوص السلسلة (Drive Chain):",
                        value = "خلوص 20 - 30 ملم",
                        hint = "تشحيم دوري كل 500 كم لشفتات المساء"
                    )
                }
            }
        }
    }
}

@Composable
private fun SpecItem(label: String, value: String, hint: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = DarkTextSecondary
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = BoxerCyan
            )
        }
        Text(
            text = hint,
            fontSize = 11.sp,
            color = DarkTextMuted,
            modifier = Modifier.padding(top = 1.dp)
        )
    }
}
