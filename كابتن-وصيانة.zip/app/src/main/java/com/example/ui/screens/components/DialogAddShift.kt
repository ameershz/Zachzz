package com.example.ui.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.BoxerCyan
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DarkTextMuted
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ProfitGreen
import java.util.Locale

@Composable
fun DialogAddShift(
    onDismiss: () -> Unit,
    onSave: (
        dateMillis: Long,
        startTime: String,
        endTime: String,
        ordersCount: Int,
        grossEarnings: Double,
        tips: Double,
        fuelExpense: Double,
        otherExpenses: Double,
        notes: String,
        distanceKm: Int
    ) -> Unit
) {
    var isEveningPreset by remember { mutableStateOf(true) }
    var startTime by remember { mutableStateOf("15:00") }
    var endTime by remember { mutableStateOf("00:00") }

    var ordersText by remember { mutableStateOf("") }
    var grossText by remember { mutableStateOf("") }
    var tipsText by remember { mutableStateOf("") }
    var fuelText by remember { mutableStateOf("") }
    var otherExpenseText by remember { mutableStateOf("") }
    var distanceText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }

    val calculatedNet by remember {
        derivedStateOf {
            val gross = grossText.toDoubleOrNull() ?: 0.0
            val tips = tipsText.toDoubleOrNull() ?: 0.0
            val fuel = fuelText.toDoubleOrNull() ?: 0.0
            val other = otherExpenseText.toDoubleOrNull() ?: 0.0
            (gross + tips) - (fuel + other)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("dialog_add_shift"),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(BoxerAmber.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AttachMoney,
                        contentDescription = null,
                        tint = BoxerAmber
                    )
                }
                Column {
                    Text(
                        text = "تسجيل شفت جديد",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = "أرباح وتفاصيل شفت التوصيل",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Preset selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = isEveningPreset,
                        onClick = {
                            isEveningPreset = true
                            startTime = "15:00"
                            endTime = "00:00"
                        },
                        label = { Text("شفت مسائي (3م - 12ص)", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BoxerAmber.copy(alpha = 0.25f),
                            selectedLabelColor = BoxerAmber
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = !isEveningPreset,
                        onClick = { isEveningPreset = false },
                        label = { Text("وقت مخصص", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BoxerCyan.copy(alpha = 0.25f),
                            selectedLabelColor = BoxerCyan
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                if (!isEveningPreset) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = startTime,
                            onValueChange = { startTime = it },
                            label = { Text("من الساعة") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BoxerAmber,
                                unfocusedBorderColor = DarkOutline
                            )
                        )
                        OutlinedTextField(
                            value = endTime,
                            onValueChange = { endTime = it },
                            label = { Text("إلى الساعة") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BoxerAmber,
                                unfocusedBorderColor = DarkOutline
                            )
                        )
                    }
                }

                // Orders count & Gross revenue
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = ordersText,
                        onValueChange = { ordersText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("عدد الطلبات") },
                        placeholder = { Text("15") },
                        leadingIcon = {
                            Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = BoxerCyan)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_orders_count"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BoxerCyan,
                            unfocusedBorderColor = DarkOutline
                        )
                    )
                    OutlinedTextField(
                        value = grossText,
                        onValueChange = { grossText = it },
                        label = { Text("أرباح التوصيل") },
                        placeholder = { Text("350.0") },
                        leadingIcon = {
                            Icon(Icons.Default.AttachMoney, contentDescription = null, tint = ProfitGreen)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_gross_earnings"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ProfitGreen,
                            unfocusedBorderColor = DarkOutline
                        )
                    )
                }

                // Tips & Fuel
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = tipsText,
                        onValueChange = { tipsText = it },
                        label = { Text("الإكراميات (Tips)") },
                        placeholder = { Text("40.0") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_tips"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BoxerAmber,
                            unfocusedBorderColor = DarkOutline
                        )
                    )
                    OutlinedTextField(
                        value = fuelText,
                        onValueChange = { fuelText = it },
                        label = { Text("بنزين البوكسر") },
                        placeholder = { Text("50.0") },
                        leadingIcon = {
                            Icon(Icons.Default.LocalGasStation, contentDescription = null, tint = ExpenseRed)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_fuel_expense"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ExpenseRed,
                            unfocusedBorderColor = DarkOutline
                        )
                    )
                }

                // Other expenses & Distance covered
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = otherExpenseText,
                        onValueChange = { otherExpenseText = it },
                        label = { Text("مصاريف أخرى") },
                        placeholder = { Text("10.0") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DarkOutline,
                            unfocusedBorderColor = DarkOutline
                        )
                    )
                    OutlinedTextField(
                        value = distanceText,
                        onValueChange = { distanceText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("مسافة الشفت (كم)") },
                        placeholder = { Text("65") },
                        leadingIcon = {
                            Icon(Icons.Default.DirectionsBike, contentDescription = null, tint = BoxerCyan)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("input_shift_distance"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BoxerCyan,
                            unfocusedBorderColor = DarkOutline
                        )
                    )
                }

                // Notes
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("ملاحظات الشفت (مناطق العمل، الزحمة...)") },
                    leadingIcon = {
                        Icon(Icons.Default.Notes, contentDescription = null, tint = DarkTextMuted)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerAmber,
                        unfocusedBorderColor = DarkOutline
                    )
                )

                // Net Profit Preview Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (calculatedNet >= 0) {
                            ProfitGreen.copy(alpha = 0.12f)
                        } else {
                            ExpenseRed.copy(alpha = 0.12f)
                        }
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "صافي الربح المتوقع:",
                                style = MaterialTheme.typography.bodyMedium,
                                color = DarkTextSecondary
                            )
                            Text(
                                text = "الدخل + الإكراميات - البنزين والمصاريف",
                                style = MaterialTheme.typography.labelSmall,
                                color = DarkTextMuted
                            )
                        }
                        Text(
                            text = String.format(Locale.US, "%.1f", calculatedNet),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (calculatedNet >= 0) ProfitGreen else ExpenseRed
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val orders = ordersText.toIntOrNull() ?: 0
                    val gross = grossText.toDoubleOrNull() ?: 0.0
                    val tips = tipsText.toDoubleOrNull() ?: 0.0
                    val fuel = fuelText.toDoubleOrNull() ?: 0.0
                    val other = otherExpenseText.toDoubleOrNull() ?: 0.0
                    val distance = distanceText.toIntOrNull() ?: 0

                    onSave(
                        System.currentTimeMillis(),
                        startTime,
                        endTime,
                        orders,
                        gross,
                        tips,
                        fuel,
                        other,
                        notesText,
                        distance
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BoxerAmber,
                    contentColor = DarkSurface
                ),
                modifier = Modifier.testTag("btn_save_shift")
            ) {
                Text("حفظ الشفت", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkTextSecondary)
            ) {
                Text("إلغاء")
            }
        },
        containerColor = DarkSurface
    )
}
