package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Midnight Theme for Evening Delivery Captains (Bajaj Boxer)
val BoxerAmber = Color(0xFFFFB300)
val BoxerAmberDark = Color(0xFFFF8F00)
val BoxerAmberLight = Color(0xFFFFD54F)

val BoxerCyan = Color(0xFF00E5FF)
val BoxerCyanDark = Color(0xFF00B0FF)
val BoxerTeal = Color(0xFF00B4D8)

val DarkBackground = Color(0xFF0D1117)
val DarkSurface = Color(0xFF161B22)
val DarkSurfaceVariant = Color(0xFF21262D)
val DarkSurfaceHighlight = Color(0xFF2D333B)

val DarkTextPrimary = Color(0xFFF0F6FC)
val DarkTextSecondary = Color(0xFF8B949E)
val DarkTextMuted = Color(0xFF6E7681)
val DarkOutline = Color(0xFF30363D)

val ProfitGreen = Color(0xFF00E676)
val ProfitGreenContainer = Color(0xFF0F381E)
val ExpenseRed = Color(0xFFFF5252)
val ExpenseRedContainer = Color(0xFF381515)
val WarningAmber = Color(0xFFFFAB00)
val WarningAmberContainer = Color(0xFF3E2800)
val InfoBlue = Color(0xFF40C4FF)
