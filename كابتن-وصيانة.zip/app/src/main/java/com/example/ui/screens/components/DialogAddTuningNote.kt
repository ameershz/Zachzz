package com.example.ui.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BuildCircle
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BoxerAmber
import com.example.ui.theme.BoxerCyan
import com.example.ui.theme.DarkOutline
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DialogAddTuningNote(
    currentBikeOdometer: Int,
    onDismiss: () -> Unit,
    onSave: (
        category: String,
        title: String,
        settingValue: String,
        notes: String,
        odometer: Int
    ) -> Unit
) {
    var selectedCategory by remember { mutableStateOf("CARBURETOR") }
    var titleText by remember { mutableStateOf("") }
    var settingValueText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var odoText by remember { mutableStateOf(currentBikeOdometer.toString()) }

    val categories = listOf(
        Triple("CARBURETOR", "وزنية الكابريتر", "وضع الإبرة والبيك"),
        Triple("AIR_SCREW", "برغي الهواء والسلانسيه", "عدد اللفات والـ RPM"),
        Triple("CLUTCH", "معايرة مقبض الكلج", "خلوص الذراع والسلك"),
        Triple("GENERAL_SPECS", "صيانة أخرى للبوكسر", "شمعة، جنزير، صمامات")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("dialog_add_tuning_note"),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(BoxerCyan.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BuildCircle,
                        contentDescription = null,
                        tint = BoxerCyan
                    )
                }
                Column {
                    Text(
                        text = "تسجيل ضبط ميكانيكي",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = DarkTextPrimary
                    )
                    Text(
                        text = "ملاحظات وزنية باجاج بوكسر 150",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Category Selector
                Text(
                    text = "قسم الضبط الميكانيكي:",
                    style = MaterialTheme.typography.labelMedium,
                    color = DarkTextSecondary
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { (catKey, catLabel, _) ->
                        FilterChip(
                            selected = selectedCategory == catKey,
                            onClick = {
                                selectedCategory = catKey
                                if (titleText.isBlank()) {
                                    titleText = when (catKey) {
                                        "CARBURETOR" -> "وزنية كابريتر البوكسر"
                                        "AIR_SCREW" -> "وزنية برغي الهواء والسلانسيه"
                                        "CLUTCH" -> "معايرة خلوص الكلج"
                                        else -> "ملاحظة ميكانيكية"
                                    }
                                }
                            },
                            label = { Text(catLabel, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BoxerCyan.copy(alpha = 0.25f),
                                selectedLabelColor = BoxerCyan
                            )
                        )
                    }
                }

                // Title
                OutlinedTextField(
                    value = titleText,
                    onValueChange = { titleText = it },
                    label = { Text("عنوان الملاحظة") },
                    placeholder = {
                        Text(
                            when (selectedCategory) {
                                "CARBURETOR" -> "مثال: إبرة الكابريتر بالصيف"
                                "AIR_SCREW" -> "مثال: ضبط السلانسيه بعد التنظيف"
                                "CLUTCH" -> "مثال: تغيير سلك الدبرياج الجديد"
                                else -> "مثال: شد جنزير الدراجة"
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_tuning_title"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerCyan,
                        unfocusedBorderColor = DarkOutline
                    )
                )

                // Setting / Value
                OutlinedTextField(
                    value = settingValueText,
                    onValueChange = { settingValueText = it },
                    label = { Text("قيمة أو وزنية الضبط") },
                    placeholder = {
                        Text(
                            when (selectedCategory) {
                                "CARBURETOR" -> "مثال: السنة 3 من الأعلى (وسط)"
                                "AIR_SCREW" -> "مثال: 2.25 لفة للخارج - 1400 RPM"
                                "CLUTCH" -> "مثال: خلوص 12 ملم عند رأس المقبض"
                                else -> "مثال: 28 PSI خلفي / 25 أمامي"
                            }
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_tuning_value"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerAmber,
                        unfocusedBorderColor = DarkOutline
                    )
                )

                // Odometer reading
                OutlinedTextField(
                    value = odoText,
                    onValueChange = { odoText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("قراءة العداد عند الضبط (كم)") },
                    leadingIcon = {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = BoxerCyan)
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerCyan,
                        unfocusedBorderColor = DarkOutline
                    )
                )

                // Detailed notes
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("الملاحظات وتجربة القيادة") },
                    placeholder = {
                        Text("مثال: السحب ممتاز واختفى التقطيع عند التسارع، استهلاك البنزين طبيعي...")
                    },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BoxerAmber,
                        unfocusedBorderColor = DarkOutline
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val odo = odoText.toIntOrNull() ?: currentBikeOdometer
                    val title = titleText.ifBlank {
                        when (selectedCategory) {
                            "CARBURETOR" -> "وزنية الكابريتر"
                            "AIR_SCREW" -> "وزنية برغي الهواء"
                            "CLUTCH" -> "معايرة مقبض الكلج"
                            else -> "ضبط ميكانيكي"
                        }
                    }
                    onSave(selectedCategory, title, settingValueText, notesText, odo)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = BoxerCyan,
                    contentColor = DarkSurface
                ),
                modifier = Modifier.testTag("btn_save_tuning_note")
            ) {
                Text("حفظ الملاحظة", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DarkTextSecondary)
            ) {
                Text("إلغاء")
            }
        },
        containerColor = DarkSurface
    )
}
